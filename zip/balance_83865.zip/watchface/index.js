﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_uvi_text_text_img = ''
        let normal_date_img_date_year = ''
        let normal_date_img_date_month = ''
        let normal_date_month_separator_img = ''
        let normal_date_img_date_day = ''
        let normal_date_day_separator_img = ''
        let normal_date_img_date_week_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_city_name_text = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_icon_img = ''
        let normal_distance_text_text_img = ''
        let normal_step_linear_scale = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_digital_clock_minute_separator_img = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_uvi_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 53,
              y: 148,
              font_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.UVI,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 268,
              year_startY: 391,
              year_sc_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              year_tc_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              year_en_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              year_zero: 1,
              year_space: -5,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 206,
              month_startY: 392,
              month_sc_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              month_tc_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              month_en_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              month_zero: 1,
              month_space: -5,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_month_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 255,
              y: 392,
              src: 't_se.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 145,
              day_startY: 392,
              day_sc_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              day_tc_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              day_en_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              day_zero: 1,
              day_space: -5,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_day_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 192,
              y: 392,
              src: 't_se.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 179,
              y: 433,
              week_en: ["Sem (01).png","Sem (02).png","Sem (03).png","Sem (04).png","Sem (05).png","Sem (06).png","Sem (07).png"],
              week_tc: ["Sem (01).png","Sem (02).png","Sem (03).png","Sem (04).png","Sem (05).png","Sem (06).png","Sem (07).png"],
              week_sc: ["Sem (01).png","Sem (02).png","Sem (03).png","Sem (04).png","Sem (05).png","Sem (06).png","Sem (07).png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 399,
              y: 313,
              image_array: ["moon_01.png","moon_02.png","moon_03.png","moon_04.png","moon_05.png","moon_06.png","moon_07.png","moon_08.png","moon_09.png","moon_10.png","moon_11.png","moon_12.png","moon_13.png","moon_14.png","moon_15.png","moon_16.png","moon_17.png","moon_18.png","moon_19.png","moon_20.png","moon_21.png","moon_22.png","moon_23.png","moon_24.png","moon_25.png","moon_26.png","moon_27.png","moon_28.png","moon_29.png","moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 43,
              y: 295,
              font_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              padding: false,
              h_space: -8,
              unit_sc: 'date_10.png',
              unit_tc: 'date_10.png',
              unit_en: 'date_10.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 31,
              y: 195,
              image_array: ["BAT (01).png","BAT (02).png","BAT (03).png","BAT (04).png","BAT (05).png","BAT (06).png","BAT (07).png","BAT (08).png","BAT (09).png","BAT (10).png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 132,
              y: 9,
              w: 216,
              h: 41,
              text_size: 29,
              char_space: 0,
              line_space: 0,
              color: 0xFFFF0000,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 336,
              y: 180,
              font_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              padding: false,
              h_space: -5,
              unit_sc: 'num_12.png',
              unit_tc: 'num_12.png',
              unit_en: 'num_12.png',
              negative_image: 'num_13.png',
              invalid_image: 'num_13.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 342,
              y: 231,
              image_array: ["weather_01.png","weather_02.png","weather_03.png","weather_04.png","weather_05.png","weather_06.png","weather_07.png","weather_08.png","weather_09.png","weather_10.png","weather_11.png","weather_12.png","weather_13.png","weather_14.png","weather_15.png","weather_16.png","weather_17.png","weather_18.png","weather_19.png","weather_20.png","weather_21.png","weather_22.png","weather_23.png","weather_24.png","weather_25.png","weather_26.png","weather_27.png","weather_28.png","weather_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 179,
              y: 190,
              font_array: ["time_10.png","time_11.png","time_12.png","time_13.png","time_14.png","time_15.png","time_16.png","time_17.png","time_18.png","time_19.png"],
              padding: false,
              h_space: -5,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 249,
              y: 194,
              src: 't_mi.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 146,
              y: 240,
              font_array: ["time_10.png","time_11.png","time_12.png","time_13.png","time_14.png","time_15.png","time_16.png","time_17.png","time_18.png","time_19.png"],
              padding: false,
              h_space: -5,
              unit_sc: 't_km.png',
              unit_tc: 't_km.png',
              unit_en: 't_km.png',
              imperial_unit_sc: 't_mi.png',
              imperial_unit_tc: 't_mi.png',
              imperial_unit_en: 't_mi.png',
              dot_image: 't_se.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            if (screenType != hmSetting.screen_type.AOD) {
              normal_step_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // normal_step_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 122,
              // start_y: 339,
              // color: 0xFFD50000,
              // lenght: 157,
              // line_width: 25,
              // line_cap: Flat,
              // vertical: False,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 181,
              y: 294,
              font_array: ["time_10.png","time_11.png","time_12.png","time_13.png","time_14.png","time_15.png","time_16.png","time_17.png","time_18.png","time_19.png"],
              padding: false,
              h_space: -5,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 120,
              y: 338,
              src: 'overlay.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 125,
              hour_startY: 79,
              hour_array: ["time_00.png","time_01.png","time_02.png","time_03.png","time_04.png","time_05.png","time_06.png","time_07.png","time_08.png","time_09.png"],
              hour_zero: 1,
              hour_space: -5,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 255,
              minute_startY: 79,
              minute_array: ["time_00.png","time_01.png","time_02.png","time_03.png","time_04.png","time_05.png","time_06.png","time_07.png","time_08.png","time_09.png"],
              minute_zero: 1,
              minute_space: -5,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 380,
              second_startY: 104,
              second_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              second_zero: 1,
              second_space: -6,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 117,
              y: 112,
              src: 'pointer.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_minute_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 249,
              y: 112,
              src: 'pointer.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 0,
              // disconneсnt_toast_text: Bluetooth OFF,
              // conneсnt_vibrate_type: 0,
              // conneсnt_toast_text: Bluetooth ON,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              console.log('checkConnection()');
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  hmUI.showToast({text: "Bluetooth OFF"});
                  vibro(0);
                }
                if(status) {
                  hmUI.showToast({text: "Bluetooth ON"});
                  vibro(0);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              if (scene != 1) timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function

            function scale_call() {
              console.log('scale_call()');

              console.log('Weather city name');
              let weatherData = weatherSensor.getForecastWeather();
              normal_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_ls_normal_step = progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_linear_scale
                  // initial parameters
                  let start_x_normal_step = 122;
                  let start_y_normal_step = 339;
                  let lenght_ls_normal_step = 157;
                  let line_width_ls_normal_step = 25;
                  let color_ls_normal_step = 0xFFD50000;
                  
                  // calculated parameters
                  let start_x_normal_step_draw = start_x_normal_step;
                  let start_y_normal_step_draw = start_y_normal_step;
                  lenght_ls_normal_step = lenght_ls_normal_step * progress_ls_normal_step;
                  let lenght_ls_normal_step_draw = lenght_ls_normal_step;
                  let line_width_ls_normal_step_draw = line_width_ls_normal_step;
                  if (lenght_ls_normal_step < 0){
                    lenght_ls_normal_step_draw = -lenght_ls_normal_step;
                    start_x_normal_step_draw = start_x_normal_step - lenght_ls_normal_step_draw;
                  };
                  
                  normal_step_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_step_draw,
                    y: start_y_normal_step_draw,
                    w: lenght_ls_normal_step_draw,
                    h: line_width_ls_normal_step_draw,
                    color: color_ls_normal_step,
                  });
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                checkConnection();
                stopVibro();

              }),
              pause_call: (function () {
                console.log('pause_call()');
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
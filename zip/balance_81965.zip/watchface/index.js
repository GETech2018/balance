﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js
		function click_COLOR() {
            normal_stress_icon_img.setProperty(hmUI.prop.VISIBLE, true);
			Button_1.setProperty(hmUI.prop.VISIBLE, true);
			Button_2.setProperty(hmUI.prop.VISIBLE, true);
			Button_3.setProperty(hmUI.prop.VISIBLE, true);
			Button_4.setProperty(hmUI.prop.VISIBLE, true);
			Button_5.setProperty(hmUI.prop.VISIBLE, true);
			Button_6.setProperty(hmUI.prop.VISIBLE, true);
			Button_7.setProperty(hmUI.prop.VISIBLE, true);
			Button_8.setProperty(hmUI.prop.VISIBLE, true);
			Button_9.setProperty(hmUI.prop.VISIBLE, true);
			Button_10.setProperty(hmUI.prop.VISIBLE, false);
			Button_11.setProperty(hmUI.prop.VISIBLE, false);
			Button_12.setProperty(hmUI.prop.VISIBLE, false);
			Button_13.setProperty(hmUI.prop.VISIBLE, false);
			Button_14.setProperty(hmUI.prop.VISIBLE, false);
			Button_15.setProperty(hmUI.prop.VISIBLE, false);
			Button_16.setProperty(hmUI.prop.VISIBLE, false);
			Button_17.setProperty(hmUI.prop.VISIBLE, false);
			Button_18.setProperty(hmUI.prop.VISIBLE, false);
			Button_19.setProperty(hmUI.prop.VISIBLE, false);
			Button_20.setProperty(hmUI.prop.VISIBLE, false);
			Button_21.setProperty(hmUI.prop.VISIBLE, false);
            hmUI.showToast({text: 'CHOOSE YOUR COLOR'});
        }

        function CHOOSE_COLOR(){
			normal_stress_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			Button_1.setProperty(hmUI.prop.VISIBLE, false);
			Button_2.setProperty(hmUI.prop.VISIBLE, false);
			Button_3.setProperty(hmUI.prop.VISIBLE, false);
			Button_4.setProperty(hmUI.prop.VISIBLE, false);
			Button_5.setProperty(hmUI.prop.VISIBLE, false);
			Button_6.setProperty(hmUI.prop.VISIBLE, false);
			Button_7.setProperty(hmUI.prop.VISIBLE, false);
			Button_8.setProperty(hmUI.prop.VISIBLE, false);
			Button_9.setProperty(hmUI.prop.VISIBLE, false);
			Button_10.setProperty(hmUI.prop.VISIBLE, true);
			Button_11.setProperty(hmUI.prop.VISIBLE, true);
			Button_12.setProperty(hmUI.prop.VISIBLE, true);
			Button_13.setProperty(hmUI.prop.VISIBLE, true);
			Button_14.setProperty(hmUI.prop.VISIBLE, true);
			Button_15.setProperty(hmUI.prop.VISIBLE, true);
			Button_16.setProperty(hmUI.prop.VISIBLE, true);
			Button_17.setProperty(hmUI.prop.VISIBLE, true);
			Button_18.setProperty(hmUI.prop.VISIBLE, true);
			Button_19.setProperty(hmUI.prop.VISIBLE, true);
			Button_20.setProperty(hmUI.prop.VISIBLE, true);
			Button_21.setProperty(hmUI.prop.VISIBLE, true);
        }
		
		function click_COLOR1() {
            
			normal_background_bg.setProperty(hmUI.prop.MORE, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFFFF8000',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			hmUI.showToast({text: 'O R A N G E'});
			
			setTimeout(function(){
			CHOOSE_COLOR();
			}, 500);
        }
		
		function click_COLOR2() {
            
			normal_background_bg.setProperty(hmUI.prop.MORE, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFF008080',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			hmUI.showToast({text: 'T E A L'});
			
			setTimeout(function(){
			CHOOSE_COLOR();
			}, 500);
        }
		
		function click_COLOR3() {
            
			normal_background_bg.setProperty(hmUI.prop.MORE, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFF808000',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			hmUI.showToast({text: 'O L I V E'});
			
			setTimeout(function(){
			CHOOSE_COLOR();
			}, 500);
        }
		
		function click_COLOR4() {
            
			normal_background_bg.setProperty(hmUI.prop.MORE, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFF800000',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			hmUI.showToast({text: 'M A R O O N'});
			
			setTimeout(function(){
			CHOOSE_COLOR();
			}, 500);
        }
		
		function click_COLOR5() {
            
			normal_background_bg.setProperty(hmUI.prop.MORE, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFF00FFFF',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			hmUI.showToast({text: 'A Q U A'});
			
			setTimeout(function(){
			CHOOSE_COLOR();
			}, 500);
        }
		
		function click_COLOR6() {
            
			normal_background_bg.setProperty(hmUI.prop.MORE, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFF008000',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			hmUI.showToast({text: 'G R E E N'});
			
			setTimeout(function(){
			CHOOSE_COLOR();
			}, 500);
        }
		
		function click_COLOR7() {
            
			normal_background_bg.setProperty(hmUI.prop.MORE, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFFFFFF00',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			hmUI.showToast({text: 'Y E L L O W'});
			
			setTimeout(function(){
			CHOOSE_COLOR();
			}, 500);
        }
		
		function click_COLOR8() {
            
			normal_background_bg.setProperty(hmUI.prop.MORE, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFFFF0000',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			hmUI.showToast({text: 'R E D'});
			
			setTimeout(function(){
			CHOOSE_COLOR();
			}, 500);
        }
		
		function click_COLOR9() {
            
			normal_background_bg.setProperty(hmUI.prop.MORE, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFFFFFFFF',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			hmUI.showToast({text: 'W H I T E'});
			
			setTimeout(function(){
			CHOOSE_COLOR();
			}, 500);
        }
        // end user_functions.js

        let normal_background_bg = ''
        let normal_image_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_day_month_year_font = ''
        let normal_timerTimeUpdate = undefined;
        let normal_heart_rate_circle_scale = ''
        let normal_heart_rate_text_font = ''
        let normal_distance_current_text_font = ''
        let normal_step_linear_scale = ''
        let normal_step_current_text_font = ''
        let normal_battery_circle_scale = ''
        let normal_battery_current_text_font = ''
        let normal_battery_icon_img = ''
        let normal_system_disconnect_img = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_time_hour_text_font = ''
        let normal_time_minute_text_font = ''
        let normal_time_second_text_font = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_stress_icon_img = ''
        let idle_background_bg = ''
        let idle_battery_linear_scale = ''
        let idle_battery_icon_img = ''
        let idle_battery_current_text_font = ''
        let idle_system_disconnect_img = ''
        let idle_time_hour_text_font = ''
        let idle_timerTimeUpdate = undefined;
        let idle_time_minute_text_font = ''
        let idle_digital_clock_img_time_AmPm = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let Button_7 = ''
        let Button_8 = ''
        let Button_9 = ''
        let Button_10 = ''
        let Button_11 = ''
        let Button_12 = ''
        let Button_13 = ''
        let Button_14 = ''
        let Button_15 = ''
        let Button_16 = ''
        let Button_17 = ''
        let Button_18 = ''
        let Button_19 = ''
        let Button_20 = ''
        let Button_21 = ''
        let timeSensor = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            // FontName: walkway.ttf; FontSize: 30
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 424,
              h: 37,
              text_size: 30,
              char_space: 1,
              line_space: 0,
              font: 'fonts/walkway.ttf',
              color: 0xFFC0C0C0,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: walkway.ttf; FontSize: 36; Cache: full
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 43,
              h: 43,
              text_size: 36,
              char_space: 2,
              line_space: 0,
              font: 'fonts/walkway.ttf',
              color: 0xFFC0C0C0,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: walkway.ttf; FontSize: 48
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 687,
              h: 61,
              text_size: 48,
              char_space: 2,
              line_space: 0,
              font: 'fonts/walkway.ttf',
              color: 0xFFC0C0C0,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: walkway.ttf; FontSize: 120
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 1625,
              h: 151,
              text_size: 120,
              char_space: 2,
              line_space: 0,
              font: 'fonts/walkway.ttf',
              color: 0xFFC0C0C0,
              align_h: hmUI.align.RIGHT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: walkway.ttf; FontSize: 60
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 901,
              h: 75,
              text_size: 60,
              char_space: 4,
              line_space: 0,
              font: 'fonts/walkway.ttf',
              color: 0xFFC0C0C0,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFFFF8000',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'mask.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 334,
              y: 92,
              image_array: ["weatherl_00.png","weatherl_01.png","weatherl_02.png","weatherl_03.png","weatherl_04.png","weatherl_05.png","weatherl_06.png","weatherl_07.png","weatherl_08.png","weatherl_09.png","weatherl_10.png","weatherl_11.png","weatherl_12.png","weatherl_13.png","weatherl_14.png","weatherl_15.png","weatherl_16.png","weatherl_17.png","weatherl_18.png","weatherl_19.png","weatherl_20.png","weatherl_21.png","weatherl_22.png","weatherl_23.png","weatherl_24.png","weatherl_25.png","weatherl_26.png","weatherl_27.png","weatherl_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            let screenType = hmSetting.getScreenType();
            normal_day_month_year_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 150,
              y: 50,
              w: 180,
              h: 30,
              text_size: 30,
              char_space: 1,
              line_space: 0,
              font: 'fonts/walkway.ttf',
              color: 0xFFC0C0C0,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              // padding: true,
              // unit_type: 1,
              // unit_string: ·,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_heart_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 240,
              // center_y: 240,
              // start_angle: 117,
              // end_angle: 63,
              // radius: 220,
              // line_width: 14,
              // line_cap: Flat,
              // color: 0xFF212121,
              // mirror: False,
              // inversion: True,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_heart_rate_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 240,
              center_y: 240,
              start_angle: 63,
              end_angle: 117,
              radius: 213,
              line_width: 14,
              corner_flag: 3,
              color: 0xFF212121,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const heart_rate = hmSensor.createSensor(hmSensor.id.HEART);
            heart_rate.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_heart_rate_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 293,
              y: 318,
              w: 150,
              h: 32,
              text_size: 30,
              char_space: 2,
              line_space: 0,
              font: 'fonts/walkway.ttf',
              color: 0xFFC0C0C0,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 165,
              y: 392,
              w: 150,
              h: 35,
              text_size: 36,
              char_space: 2,
              line_space: 0,
              font: 'fonts/walkway.ttf',
              color: 0xFFC0C0C0,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (screenType != hmSetting.screen_type.AOD) {
              normal_step_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // normal_step_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 168,
              // start_y: 361,
              // color: 0xFF212121,
              // lenght: 144,
              // line_width: 19,
              // line_cap: Flat,
              // vertical: False,
              // mirror: False,
              // inversion: True,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_step_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 165,
              y: 294,
              w: 150,
              h: 35,
              text_size: 48,
              char_space: 2,
              line_space: 0,
              font: 'fonts/walkway.ttf',
              color: 0xFFC0C0C0,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 240,
              // center_y: 240,
              // start_angle: -115,
              // end_angle: -61,
              // radius: 220,
              // line_width: 14,
              // line_cap: Flat,
              // color: 0xFF212121,
              // mirror: False,
              // inversion: True,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 240,
              center_y: 240,
              start_angle: -61,
              end_angle: -115,
              radius: 213,
              line_width: 14,
              corner_flag: 3,
              color: 0xFF212121,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 38,
              y: 318,
              w: 150,
              h: 32,
              text_size: 30,
              char_space: 2,
              line_space: 0,
              font: 'fonts/walkway.ttf',
              color: 0xFFC0C0C0,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'top.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 111,
              y: 92,
              src: 'st_bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'hand_sec.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 240,
              second_posY: 240,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_time_hour_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 79,
              y: 166,
              w: 148,
              h: 120,
              text_size: 120,
              char_space: 2,
              line_space: 0,
              font: 'fonts/walkway.ttf',
              color: 0xFFC0C0C0,
              align_h: hmUI.align.RIGHT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_time_minute_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 254,
              y: 166,
              w: 148,
              h: 120,
              text_size: 120,
              char_space: 2,
              line_space: 0,
              font: 'fonts/walkway.ttf',
              color: 0xFFC0C0C0,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_time_second_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 202,
              y: 113,
              w: 150,
              h: 60,
              text_size: 60,
              char_space: 4,
              line_space: 0,
              font: 'fonts/walkway.ttf',
              color: 0xFFC0C0C0,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 0,
              am_y: 0,
              am_sc_path: 'am.png',
              am_en_path: 'am.png',
              pm_x: 0,
              pm_y: 0,
              pm_sc_path: 'pm.png',
              pm_en_path: 'pm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'picker.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFFC0C0C0',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            if (screenType == hmSetting.screen_type.AOD) {
              idle_battery_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // idle_battery_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 168,
              // start_y: 361,
              // color: 0xFF212121,
              // lenght: 144,
              // line_width: 19,
              // line_cap: Flat,
              // vertical: False,
              // mirror: False,
              // inversion: True,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'aod.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 165,
              y: 318,
              w: 150,
              h: 32,
              text_size: 30,
              char_space: 2,
              line_space: 0,
              font: 'fonts/walkway.ttf',
              color: 0xFFC0C0C0,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 223,
              y: 128,
              src: 'st_bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_time_hour_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 79,
              y: 160,
              w: 150,
              h: 130,
              text_size: 120,
              char_space: 2,
              line_space: 0,
              font: 'fonts/walkway.ttf',
              color: 0xFFC0C0C0,
              align_h: hmUI.align.RIGHT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              // padding: true,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_time_minute_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 254,
              y: 160,
              w: 150,
              h: 130,
              text_size: 120,
              char_space: 2,
              line_space: 0,
              font: 'fonts/walkway.ttf',
              color: 0xFFC0C0C0,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              // padding: true,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 0,
              am_y: 0,
              am_sc_path: 'am.png',
              am_en_path: 'am.png',
              pm_x: 0,
              pm_y: 0,
              pm_sc_path: 'pm.png',
              pm_en_path: 'pm.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 107,
              y: 110,
              w: 80,
              h: 80,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                				click_COLOR1();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 200,
              y: 110,
              w: 80,
              h: 80,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                				click_COLOR2();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 296,
              y: 110,
              w: 80,
              h: 80,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                				click_COLOR3();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 107,
              y: 200,
              w: 80,
              h: 80,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                				click_COLOR4();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 200,
              y: 200,
              w: 80,
              h: 80,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                				click_COLOR5();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 296,
              y: 200,
              w: 80,
              h: 80,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                				click_COLOR6();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_7 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 107,
              y: 290,
              w: 80,
              h: 80,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                				click_COLOR7();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_8 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 200,
              y: 290,
              w: 80,
              h: 80,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                				click_COLOR8();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_9 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 296,
              y: 290,
              w: 80,
              h: 80,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                				click_COLOR9();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_10 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 190,
              y: 385,
              w: 100,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'SportStatusScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_11 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 190,
              y: 300,
              w: 100,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'activityAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_12 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 190,
              y: 25,
              w: 100,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_13 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 285,
              y: 188,
              w: 80,
              h: 80,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'CountdownAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_14 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 115,
              y: 188,
              w: 80,
              h: 80,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'TomatoMainScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_15 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 200,
              y: 90,
              w: 80,
              h: 80,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'StopWatchScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_16 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 340,
              y: 50,
              w: 80,
              h: 80,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'WeatherScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_17 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 60,
              y: 50,
              w: 80,
              h: 80,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'FindPhoneScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_18 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 340,
              y: 310,
              w: 60,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'heart_app_Screen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_19 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 80,
              y: 310,
              w: 60,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PowerSaveHintScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_20 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 60,
              y: 370,
              w: 60,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'SportListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_21 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 360,
              y: 370,
              w: 60,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                				click_COLOR();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            console.log('user_script_end.js');
            // start user_script_end.js
			let cc = 0
			if (cc ==0 ){
			  normal_stress_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			  Button_1.setProperty(hmUI.prop.VISIBLE, false);
			  Button_2.setProperty(hmUI.prop.VISIBLE, false);
			  Button_3.setProperty(hmUI.prop.VISIBLE, false);
			  Button_4.setProperty(hmUI.prop.VISIBLE, false);
			  Button_5.setProperty(hmUI.prop.VISIBLE, false);
			  Button_6.setProperty(hmUI.prop.VISIBLE, false);
			  Button_7.setProperty(hmUI.prop.VISIBLE, false);
			  Button_8.setProperty(hmUI.prop.VISIBLE, false);
			  Button_9.setProperty(hmUI.prop.VISIBLE, false);
			cc = 1;
			}
            // end user_script_end.js

            //start of ignored block
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              console.log('day/month/year font');
              if (updateHour) {
                let normal_DayStr = timeSensor.day.toString();
                let normal_MonthStr = timeSensor.month.toString();
                let normal_YearStr = timeSensor.year.toString();
                normal_DayStr = normal_DayStr.padStart(2, '0');
                normal_MonthStr = normal_MonthStr.padStart(2, '0');
                let normal_DayMonthYearStr = '--';
                const dateFormat = hmSetting.getDateFormat();
                if (dateFormat == 0) {
                  normal_DayMonthYearStr = normal_YearStr + '·' + normal_MonthStr + '·' + normal_DayStr;
                }
                if (dateFormat == 1) {
                  normal_DayMonthYearStr = normal_DayStr + '·' + normal_MonthStr + '·' + normal_YearStr;
                }
                if (dateFormat == 2) {
                  normal_DayMonthYearStr = normal_MonthStr + '·' + normal_DayStr + '·' + normal_YearStr;
                }
                normal_day_month_year_font.setProperty(hmUI.prop.TEXT, normal_DayMonthYearStr );
              };

              console.log('hour font');
              if (updateHour) {
                let normal_hourStr = format_hour.toString();
                normal_hourStr = normal_hourStr.padStart(2, '0');
                normal_time_hour_text_font.setProperty(hmUI.prop.TEXT, normal_hourStr );
              };

              console.log('minute font');
              if (updateMinute) {
                let normal_minuteStr = minute.toString();
                normal_minuteStr = normal_minuteStr.padStart(2, '0');
                normal_time_minute_text_font.setProperty(hmUI.prop.TEXT, normal_minuteStr );
              };

              console.log('second font');
                let normal_secondStr = second.toString();
                normal_secondStr = normal_secondStr.padStart(2, '0');
                normal_time_second_text_font.setProperty(hmUI.prop.TEXT, normal_secondStr );
              console.log('hour font');
              if (updateHour) {
                let idle_hourStr = format_hour.toString();
                idle_hourStr = idle_hourStr.padStart(2, '0');
                idle_time_hour_text_font.setProperty(hmUI.prop.TEXT, idle_hourStr );
              };

              console.log('minute font');
              if (updateMinute) {
                let idle_minuteStr = minute.toString();
                idle_minuteStr = idle_minuteStr.padStart(2, '0');
                idle_time_minute_text_font.setProperty(hmUI.prop.TEXT, idle_minuteStr );
              };

            };

            //end of ignored block
            function scale_call() {
              console.log('scale_call()');

                console.log('update scales HEART');
                
                let valueHeartRate = heart_rate.last;
                let targetHeartRate = 179;
                let progressHeartRate = (valueHeartRate - 71)/(targetHeartRate - 71);
                if (progressHeartRate < 0) progressHeartRate = 0;
                if (progressHeartRate > 1) progressHeartRate = 1;
                let progress_cs_normal_heart_rate = 1 - progressHeartRate;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_heart_rate_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_heart_rate * 100);
                  if (normal_heart_rate_circle_scale) {
                    normal_heart_rate_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 240,
                      center_y: 240,
                      start_angle: 63,
                      end_angle: 117,
                      radius: 213,
                      line_width: 14,
                      corner_flag: 3,
                      color: 0xFF212121,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_ls_normal_step = 1 - progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_linear_scale
                  // initial parameters
                  let start_x_normal_step = 312;
                  let start_y_normal_step = 361;
                  let lenght_ls_normal_step = -144;
                  let line_width_ls_normal_step = 19;
                  let color_ls_normal_step = 0xFF212121;
                  
                  // calculated parameters
                  let start_x_normal_step_draw = start_x_normal_step;
                  let start_y_normal_step_draw = start_y_normal_step;
                  lenght_ls_normal_step = lenght_ls_normal_step * progress_ls_normal_step;
                  let lenght_ls_normal_step_draw = lenght_ls_normal_step;
                  let line_width_ls_normal_step_draw = line_width_ls_normal_step;
                  if (lenght_ls_normal_step < 0){
                    lenght_ls_normal_step_draw = -lenght_ls_normal_step;
                    start_x_normal_step_draw = start_x_normal_step - lenght_ls_normal_step_draw;
                  };
                  
                  normal_step_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_step_draw,
                    y: start_y_normal_step_draw,
                    w: lenght_ls_normal_step_draw,
                    h: line_width_ls_normal_step_draw,
                    color: color_ls_normal_step,
                  });
                };

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_cs_normal_battery = 1 - progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_battery * 100);
                  if (normal_battery_circle_scale) {
                    normal_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 240,
                      center_y: 240,
                      start_angle: -61,
                      end_angle: -115,
                      radius: 213,
                      line_width: 14,
                      corner_flag: 3,
                      color: 0xFF212121,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales BATTERY');
                let progress_ls_idle_battery = 1 - progressBattery;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_battery_linear_scale
                  // initial parameters
                  let start_x_idle_battery = 312;
                  let start_y_idle_battery = 361;
                  let lenght_ls_idle_battery = -144;
                  let line_width_ls_idle_battery = 19;
                  let color_ls_idle_battery = 0xFF212121;
                  
                  // calculated parameters
                  let start_x_idle_battery_draw = start_x_idle_battery;
                  let start_y_idle_battery_draw = start_y_idle_battery;
                  lenght_ls_idle_battery = lenght_ls_idle_battery * progress_ls_idle_battery;
                  let lenght_ls_idle_battery_draw = lenght_ls_idle_battery;
                  let line_width_ls_idle_battery_draw = line_width_ls_idle_battery;
                  if (lenght_ls_idle_battery < 0){
                    lenght_ls_idle_battery_draw = -lenght_ls_idle_battery;
                    start_x_idle_battery_draw = start_x_idle_battery - lenght_ls_idle_battery_draw;
                  };
                  
                  idle_battery_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_idle_battery_draw,
                    y: start_y_idle_battery_draw,
                    w: lenght_ls_idle_battery_draw,
                    h: line_width_ls_idle_battery_draw,
                    color: color_ls_idle_battery,
                  });
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                time_update(true, true);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerTimeUpdate) {
                    normal_timerTimeUpdate = timer.createTimer(0, 1000, (function (option) {
                      let updateHour = timeSensor.minute == 0;
                      let updateMinute = timeSensor.second < 2;
                      time_update(updateHour, updateMinute);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.AOD) {
                  if (!idle_timerTimeUpdate) {
                    idle_timerTimeUpdate = timer.createTimer(0, 1000, (function (option) {
                      let updateHour = timeSensor.minute == 0;
                      let updateMinute = timeSensor.second < 2;
                      time_update(updateHour, updateMinute);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerTimeUpdate) {
                  timer.stopTimer(normal_timerTimeUpdate);
                  normal_timerTimeUpdate = undefined;
                }
                if (idle_timerTimeUpdate) {
                  timer.stopTimer(idle_timerTimeUpdate);
                  idle_timerTimeUpdate = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_uvi_text_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_distance_text_separator_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_city_name_text = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_stress_text_text_img = ''
        let normal_stress_image_progress_img_level = ''
        let normal_digital_clock_img_time = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'celsiou.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_uvi_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 132,
              y: 195,
              font_array: ["Act_Font_01.png","Act_Font_02.png","Act_Font_03.png","Act_Font_04.png","Act_Font_05.png","Act_Font_06.png","Act_Font_07.png","Act_Font_08.png","Act_Font_09.png","Act_Font_10.png"],
              padding: false,
              h_space: -2,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.UVI,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 222,
              y: 421,
              font_array: ["Act_Font_01.png","Act_Font_02.png","Act_Font_03.png","Act_Font_04.png","Act_Font_05.png","Act_Font_06.png","Act_Font_07.png","Act_Font_08.png","Act_Font_09.png","Act_Font_10.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 202,
              y: 185,
              font_array: ["Act_Font_01.png","Act_Font_02.png","Act_Font_03.png","Act_Font_04.png","Act_Font_05.png","Act_Font_06.png","Act_Font_07.png","Act_Font_08.png","Act_Font_09.png","Act_Font_10.png"],
              padding: false,
              h_space: -1,
              dot_image: 'Act_Dot.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 253,
              y: 190,
              src: 'Act_KM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 218,
              y: 214,
              image_array: ["m01.png","m02.png","m03.png","m04.png","m05.png","m06.png","m07.png","m08.png","m09.png","m10.png","m11.png","m12.png","m13.png","m14.png","m15.png","m16.png","m17.png","m18.png","m19.png","m20.png","m21.png","m22.png","m23.png","m24.png","m25.png","m26.png","m27.png","m28.png","m29.png","m30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 160,
              y: 17,
              w: 150,
              h: 30,
              text_size: 22,
              char_space: 0,
              line_space: 0,
              color: 0xFF86A7D2,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.WRAP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 173,
              y: 113,
              font_array: ["Time_S1_01.png","Time_S1_02.png","Time_S1_03.png","Time_S1_04.png","Time_S1_05.png","Time_S1_06.png","Time_S1_07.png","Time_S1_08.png","Time_S1_09.png","Time_S1_10.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'shortcut_pointer.png',
              unit_tc: 'shortcut_pointer.png',
              unit_en: 'shortcut_pointer.png',
              negative_image: 'shortcut.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 51,
              y: 107,
              image_array: ["Weather_icon_01.png","Weather_icon_02.png","Weather_icon_03.png","Weather_icon_04.png","Weather_icon_05.png","Weather_icon_06.png","Weather_icon_07.png","Weather_icon_08.png","Weather_icon_09.png","Weather_icon_10.png","Weather_icon_11.png","Weather_icon_12.png","Weather_icon_13.png","Weather_icon_14.png","Weather_icon_15.png","Weather_icon_16.png","Weather_icon_17.png","Weather_icon_18.png","Weather_icon_19.png","Weather_icon_20.png","Weather_icon_21.png","Weather_icon_22.png","Weather_icon_23.png","Weather_icon_24.png","Weather_icon_25.png","Weather_icon_26.png","Weather_icon_27.png","Weather_icon_28.png","Weather_icon_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 169,
              y: 252,
              font_array: ["Act_Font_01.png","Act_Font_02.png","Act_Font_03.png","Act_Font_04.png","Act_Font_05.png","Act_Font_06.png","Act_Font_07.png","Act_Font_08.png","Act_Font_09.png","Act_Font_10.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'D (4).png',
              unit_tc: 'D (4).png',
              unit_en: 'D (4).png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 26,
              y: 264,
              image_array: ["vol001.png","vol002.png","vol003.png","vol004.png","vol005.png","vol006.png","vol007.png","vol008.png","vol009.png","vol010.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 128,
              y: 64,
              week_en: ["weekday_01.png","weekday_02.png","weekday_03.png","weekday_04.png","weekday_05.png","weekday_06.png","weekday_07.png"],
              week_tc: ["weekday_01.png","weekday_02.png","weekday_03.png","weekday_04.png","weekday_05.png","weekday_06.png","weekday_07.png"],
              week_sc: ["weekday_01.png","weekday_02.png","weekday_03.png","weekday_04.png","weekday_05.png","weekday_06.png","weekday_07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 317,
              month_startY: 108,
              month_sc_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_tc_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_en_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 283,
              day_startY: 152,
              day_sc_array: ["wite001.png","wite002.png","wite003.png","wite004.png","wite005.png","wite006.png","wite007.png","wite008.png","wite009.png","wite010.png"],
              day_tc_array: ["wite001.png","wite002.png","wite003.png","wite004.png","wite005.png","wite006.png","wite007.png","wite008.png","wite009.png","wite010.png"],
              day_en_array: ["wite001.png","wite002.png","wite003.png","wite004.png","wite005.png","wite006.png","wite007.png","wite008.png","wite009.png","wite010.png"],
              day_zero: 1,
              day_space: -47,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 280,
              y: 251,
              font_array: ["Act_Font_01.png","Act_Font_02.png","Act_Font_03.png","Act_Font_04.png","Act_Font_05.png","Act_Font_06.png","Act_Font_07.png","Act_Font_08.png","Act_Font_09.png","Act_Font_10.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'D (4).png',
              unit_tc: 'D (4).png',
              unit_en: 'D (4).png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STRESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 346,
              y: 264,
              image_array: ["vol001.png","vol002.png","vol003.png","vol004.png","vol005.png","vol006.png","vol007.png","vol008.png","vol009.png","vol010.png"],
              image_length: 10,
              type: hmUI.data_type.STRESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 65,
              hour_startY: 298,
              hour_array: ["redg001.png","redg002.png","redg003.png","redg004.png","redg005.png","redg006.png","redg007.png","redg008.png","redg009.png","redg010.png"],
              hour_zero: 1,
              hour_space: 3,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 245,
              minute_startY: 297,
              minute_array: ["redg_0001.png","redg_0002.png","redg_0003.png","redg_0004.png","redg_0005.png","redg_0006.png","redg_0007.png","redg_0008.png","redg_0009.png","redg_0010.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 402,
              second_startY: 300,
              second_array: ["dey001.png","dey002.png","dey003.png","dey004.png","dey005.png","dey006.png","dey007.png","dey008.png","dey009.png","dey010.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');

            function scale_call() {
              console.log('scale_call()');

              console.log('Weather city name');
              let weatherData = weatherSensor.getForecastWeather();
              normal_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
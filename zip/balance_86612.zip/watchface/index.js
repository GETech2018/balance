﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_frame_animation_1 = ''
        let normal_digital_clock_img_time = ''
        let normal_image_img = ''
        let idle_background_bg_img = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_week_img = ''
        let idle_battery_text_text_img = ''
        let idle_digital_clock_img_time = ''
        let Button_1 = ''
        let Button_2 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'A100_002.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_frame_animation_1 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
              x: 252,
              y: 178,
              anim_path: "animation",
              anim_ext: "png",
              anim_prefix: "A100",
              anim_fps: 15,
              anim_size: 21,
              repeat_count: 0,
              anim_repeat: true,
              anim_status:hmUI.anim_status.START,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 89,
              hour_startY: 175,
              hour_array: ["A100_045.png","A100_046.png","A100_047.png","A100_048.png","A100_049.png","A100_050.png","A100_051.png","A100_052.png","A100_053.png","A100_054.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 250,
              minute_startY: 175,
              minute_array: ["A100_045.png","A100_046.png","A100_047.png","A100_048.png","A100_049.png","A100_050.png","A100_051.png","A100_052.png","A100_053.png","A100_054.png"],
              minute_zero: 1,
              minute_space: -2,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: -22,
              second_startY: 202,
              second_array: ["A100_055.png","A100_056.png","A100_057.png","A100_058.png","A100_059.png","A100_060.png","A100_061.png","A100_062.png","A100_063.png","A100_064.png"],
              second_zero: 1,
              second_space: 243,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'BG.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'A100_002.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 176,
              day_startY: 101,
              day_sc_array: ["A100_024.png","A100_025.png","A100_026.png","A100_027.png","A100_028.png","A100_029.png","A100_030.png","A100_031.png","A100_032.png","A100_033.png"],
              day_tc_array: ["A100_024.png","A100_025.png","A100_026.png","A100_027.png","A100_028.png","A100_029.png","A100_030.png","A100_031.png","A100_032.png","A100_033.png"],
              day_en_array: ["A100_024.png","A100_025.png","A100_026.png","A100_027.png","A100_028.png","A100_029.png","A100_030.png","A100_031.png","A100_032.png","A100_033.png"],
              day_zero: 1,
              day_space: 9,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              // alpha: 188,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day.setAlpha(188);

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 267,
              y: 105,
              week_en: ["A100_038.png","A100_039.png","A100_040.png","A100_041.png","A100_042.png","A100_043.png","A100_044.png"],
              week_tc: ["A100_038.png","A100_039.png","A100_040.png","A100_041.png","A100_042.png","A100_043.png","A100_044.png"],
              week_sc: ["A100_038.png","A100_039.png","A100_040.png","A100_041.png","A100_042.png","A100_043.png","A100_044.png"],
              // alpha: 189,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img.setAlpha(189);

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 202,
              y: 352,
              font_array: ["A100_024.png","A100_025.png","A100_026.png","A100_027.png","A100_028.png","A100_029.png","A100_030.png","A100_031.png","A100_032.png","A100_033.png"],
              padding: false,
              h_space: 8,
              unit_sc: 'A100_035.png',
              unit_tc: 'A100_035.png',
              unit_en: 'A100_035.png',
              // alpha: 189,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img.setAlpha(189);

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 89,
              hour_startY: 175,
              hour_array: ["A100_045.png","A100_046.png","A100_047.png","A100_048.png","A100_049.png","A100_050.png","A100_051.png","A100_052.png","A100_053.png","A100_054.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 250,
              minute_startY: 175,
              minute_array: ["A100_045.png","A100_046.png","A100_047.png","A100_048.png","A100_049.png","A100_050.png","A100_051.png","A100_052.png","A100_053.png","A100_054.png"],
              minute_zero: 1,
              minute_space: -2,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: -22,
              second_startY: 202,
              second_array: ["A100_055.png","A100_056.png","A100_057.png","A100_058.png","A100_059.png","A100_060.png","A100_061.png","A100_062.png","A100_063.png","A100_064.png"],
              second_zero: 1,
              second_space: 243,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 132,
              y: 182,
              w: 103,
              h: 109,
              text: '',
              color: 0xFFFF8C00,
              text_size: 26,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'AlarmInfoScreen', native: true });
              }, // end func
              longpress_func: (button_widget) => {
                hmApp.startApp({url: 'Sleep_HomeScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 273,
              y: 182,
              w: 103,
              h: 109,
              text: '',
              color: 0xFFFF8C00,
              text_size: 26,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'CountdownAppScreen', native: true });
              }, // end func
              longpress_func: (button_widget) => {
                hmApp.startApp({url: 'StopWatchScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);

              }),
              pause_call: (function () {
                console.log('pause_call()');
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
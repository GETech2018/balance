﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_sun_high_text_font = ''
        let normal_sun_low_text_font = ''
        let normal_distance_current_text_font = ''
        let normal_step_current_text_font = ''
        let normal_heart_rate_text_font = ''
        let normal_calorie_current_text_font = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_date_img_date_year = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_font = ''
        let normal_battery_current_text_font = ''
        let normal_battery_image_progress_img_level = ''
        let normal_digital_clock_img_time = ''
        let normal_time_second_text_font = ''
        let normal_timerTimeUpdate = undefined;
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_date_img_date_year = ''
        let idle_date_img_date_month = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_week_img = ''
        let idle_digital_clock_img_time = ''
        let idle_time_second_text_font = ''
        let idle_timerTimeUpdate = undefined;
        let normal_step_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'FOND149.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 27,
              y: 150,
              w: 150,
              h: 30,
              text_size: 20,
              char_space: 0,
              line_space: 0,
              color: 0xFFFF8C00,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 399,
              y: 150,
              w: 150,
              h: 30,
              text_size: 20,
              char_space: 0,
              line_space: 0,
              color: 0xFFFF8C00,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 311,
              y: 367,
              w: 150,
              h: 30,
              text_size: 20,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              padding: true,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 20,
              y: 367,
              w: 150,
              h: 30,
              text_size: 20,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 368,
              y: 207,
              w: 150,
              h: 43,
              text_size: 24,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: -40,
              y: 207,
              w: 150,
              h: 46,
              text_size: 24,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 327,
              y: 396,
              src: 'BT1.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 125,
              y: 401,
              src: 'alarme.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 263,
              year_startY: 336,
              year_sc_array: ["chi-00.png","chi-01.png","chi-02.png","chi-03.png","chi-04.png","chi-05.png","chi-06.png","chi-07.png","chi-08.png","chi-09.png"],
              year_tc_array: ["chi-00.png","chi-01.png","chi-02.png","chi-03.png","chi-04.png","chi-05.png","chi-06.png","chi-07.png","chi-08.png","chi-09.png"],
              year_en_array: ["chi-00.png","chi-01.png","chi-02.png","chi-03.png","chi-04.png","chi-05.png","chi-06.png","chi-07.png","chi-08.png","chi-09.png"],
              year_zero: 1,
              year_space: 0,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 223,
              month_startY: 336,
              month_sc_array: ["chi-00.png","chi-01.png","chi-02.png","chi-03.png","chi-04.png","chi-05.png","chi-06.png","chi-07.png","chi-08.png","chi-09.png"],
              month_tc_array: ["chi-00.png","chi-01.png","chi-02.png","chi-03.png","chi-04.png","chi-05.png","chi-06.png","chi-07.png","chi-08.png","chi-09.png"],
              month_en_array: ["chi-00.png","chi-01.png","chi-02.png","chi-03.png","chi-04.png","chi-05.png","chi-06.png","chi-07.png","chi-08.png","chi-09.png"],
              month_zero: 1,
              month_space: 0,
              month_unit_sc: 'chi-10.png',
              month_unit_tc: 'chi-10.png',
              month_unit_en: 'chi-10.png',
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 183,
              day_startY: 336,
              day_sc_array: ["chi-00.png","chi-01.png","chi-02.png","chi-03.png","chi-04.png","chi-05.png","chi-06.png","chi-07.png","chi-08.png","chi-09.png"],
              day_tc_array: ["chi-00.png","chi-01.png","chi-02.png","chi-03.png","chi-04.png","chi-05.png","chi-06.png","chi-07.png","chi-08.png","chi-09.png"],
              day_en_array: ["chi-00.png","chi-01.png","chi-02.png","chi-03.png","chi-04.png","chi-05.png","chi-06.png","chi-07.png","chi-08.png","chi-09.png"],
              day_zero: 1,
              day_space: 0,
              day_unit_sc: 'chi-10.png',
              day_unit_tc: 'chi-10.png',
              day_unit_en: 'chi-10.png',
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 119,
              y: 279,
              week_en: ["sem01.png","sem02.png","sem03.png","sem04.png","sem05.png","sem06.png","sem07.png"],
              week_tc: ["sem01.png","sem02.png","sem03.png","sem04.png","sem05.png","sem06.png","sem07.png"],
              week_sc: ["sem01.png","sem02.png","sem03.png","sem04.png","sem05.png","sem06.png","sem07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 171,
              y: 1,
              image_array: ["meteo-01.png","meteo-02.png","meteo-03.png","meteo-04.png","meteo-05.png","meteo-06.png","meteo-07.png","meteo-08.png","meteo-09.png","meteo-10.png","meteo-11.png","meteo-12.png","meteo-13.png","meteo-14.png","meteo-15.png","meteo-16.png","meteo-17.png","meteo-18.png","meteo-19.png","meteo-20.png","meteo-21.png","meteo-22.png","meteo-23.png","meteo-24.png","meteo-25.png","meteo-26.png","meteo-27.png","meteo-28.png","meteo-29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 260,
              y: 35,
              w: 157,
              h: 45,
              text_size: 38,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 224,
              y: 412,
              w: 150,
              h: 30,
              text_size: 20,
              char_space: 0,
              line_space: 0,
              color: 0xFFF4DD06,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 195,
              y: 383,
              image_array: ["img_bat_1.png","img_bat_2.png","img_bat_3.png","img_bat_4.png","img_bat_5.png","img_bat_6.png","img_bat_7.png","img_bat_8.png","img_bat_9.png","img_bat_10.png","img_bat_11.png","img_bat_12.png","img_bat_13.png","img_bat_14.png","img_bat_15.png","img_bat_16.png","img_bat_17.png","img_bat_18.png"],
              image_length: 18,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 115,
              hour_startY: 159,
              hour_array: ["H001.png","H002.png","H003.png","H004.png","H005.png","H006.png","H007.png","H008.png","H009.png","H010.png"],
              hour_zero: 1,
              hour_space: 9,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 272,
              minute_startY: 159,
              minute_array: ["G001.png","G002.png","G003.png","G004.png","G005.png","G006.png","G007.png","G008.png","G009.png","G010.png"],
              minute_zero: 1,
              minute_space: 9,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            let screenType = hmSetting.getScreenType();
            normal_time_second_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 344,
              y: 229,
              w: 150,
              h: 30,
              text_size: 17,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 283,
              y: 358,
              src: 'BT1.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 183,
              y: 362,
              src: 'alarme.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 263,
              year_startY: 309,
              year_sc_array: ["chi-00.png","chi-01.png","chi-02.png","chi-03.png","chi-04.png","chi-05.png","chi-06.png","chi-07.png","chi-08.png","chi-09.png"],
              year_tc_array: ["chi-00.png","chi-01.png","chi-02.png","chi-03.png","chi-04.png","chi-05.png","chi-06.png","chi-07.png","chi-08.png","chi-09.png"],
              year_en_array: ["chi-00.png","chi-01.png","chi-02.png","chi-03.png","chi-04.png","chi-05.png","chi-06.png","chi-07.png","chi-08.png","chi-09.png"],
              year_zero: 1,
              year_space: 0,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 223,
              month_startY: 309,
              month_sc_array: ["chi-00.png","chi-01.png","chi-02.png","chi-03.png","chi-04.png","chi-05.png","chi-06.png","chi-07.png","chi-08.png","chi-09.png"],
              month_tc_array: ["chi-00.png","chi-01.png","chi-02.png","chi-03.png","chi-04.png","chi-05.png","chi-06.png","chi-07.png","chi-08.png","chi-09.png"],
              month_en_array: ["chi-00.png","chi-01.png","chi-02.png","chi-03.png","chi-04.png","chi-05.png","chi-06.png","chi-07.png","chi-08.png","chi-09.png"],
              month_zero: 1,
              month_space: 0,
              month_unit_sc: 'chi-10.png',
              month_unit_tc: 'chi-10.png',
              month_unit_en: 'chi-10.png',
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 184,
              day_startY: 309,
              day_sc_array: ["chi-00.png","chi-01.png","chi-02.png","chi-03.png","chi-04.png","chi-05.png","chi-06.png","chi-07.png","chi-08.png","chi-09.png"],
              day_tc_array: ["chi-00.png","chi-01.png","chi-02.png","chi-03.png","chi-04.png","chi-05.png","chi-06.png","chi-07.png","chi-08.png","chi-09.png"],
              day_en_array: ["chi-00.png","chi-01.png","chi-02.png","chi-03.png","chi-04.png","chi-05.png","chi-06.png","chi-07.png","chi-08.png","chi-09.png"],
              day_zero: 1,
              day_space: 0,
              day_unit_sc: 'chi-10.png',
              day_unit_tc: 'chi-10.png',
              day_unit_en: 'chi-10.png',
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 119,
              y: 253,
              week_en: ["sem01.png","sem02.png","sem03.png","sem04.png","sem05.png","sem06.png","sem07.png"],
              week_tc: ["sem01.png","sem02.png","sem03.png","sem04.png","sem05.png","sem06.png","sem07.png"],
              week_sc: ["sem01.png","sem02.png","sem03.png","sem04.png","sem05.png","sem06.png","sem07.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 145,
              hour_startY: 159,
              hour_array: ["H001.png","H002.png","H003.png","H004.png","H005.png","H006.png","H007.png","H008.png","H009.png","H010.png"],
              hour_zero: 1,
              hour_space: 9,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 253,
              minute_startY: 159,
              minute_array: ["G001.png","G002.png","G003.png","G004.png","G005.png","G006.png","G007.png","G008.png","G009.png","G010.png"],
              minute_zero: 1,
              minute_space: 9,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_time_second_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 346,
              y: 201,
              w: 150,
              h: 30,
              text_size: 20,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 9,
              // disconneсnt_toast_text: BT OFF,
              // conneсnt_vibrate_type: 9,
              // conneсnt_toast_text: BT ON,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              console.log('checkConnection()');
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  hmUI.showToast({text: "BT OFF"});
                  vibro(9);
                }
                if(status) {
                  hmUI.showToast({text: "BT ON"});
                  vibro(9);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              if (scene != 1) timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 56,
              y: 323,
              w: 75,
              h: 75,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 415,
              y: 203,
              w: 50,
              h: 100,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 125,
              y: 393,
              w: 50,
              h: 50,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            //start of ignored block
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              console.log('second font');
                let normal_secondStr = second.toString();
                normal_time_second_text_font.setProperty(hmUI.prop.TEXT, normal_secondStr );
              console.log('second font');
                let idle_secondStr = second.toString();
                idle_time_second_text_font.setProperty(hmUI.prop.TEXT, idle_secondStr );
            };

            //end of ignored block
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                time_update(true, true);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerTimeUpdate) {
                    normal_timerTimeUpdate = timer.createTimer(0, 1000, (function (option) {
                      let updateHour = timeSensor.minute == 0 && timeSensor.second < 2;
                      let updateMinute = timeSensor.second < 2;
                      time_update(updateHour, updateMinute);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.AOD) {
                  if (!idle_timerTimeUpdate) {
                    idle_timerTimeUpdate = timer.createTimer(0, 1000, (function (option) {
                      let updateHour = timeSensor.minute == 0 && timeSensor.second < 2;
                      let updateMinute = timeSensor.second < 2;
                      time_update(updateHour, updateMinute);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                checkConnection();
                stopVibro();

              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerTimeUpdate) {
                  timer.stopTimer(normal_timerTimeUpdate);
                  normal_timerTimeUpdate = undefined;
                }
                if (idle_timerTimeUpdate) {
                  timer.stopTimer(idle_timerTimeUpdate);
                  idle_timerTimeUpdate = undefined;
                }
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
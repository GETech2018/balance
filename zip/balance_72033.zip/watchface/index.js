/*
     * huamiOS bundle tool v1.0.17
     * Copyright © Huami. All Rights Reserved
*/
try {
  (() => {
    var __$$app$$__ = __$$hmAppManager$$__.currentApp;
    var __$$module$$__ = __$$app$$__.current;
    var h = new DeviceRuntimeCore.WidgetFactory(
      new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__),
      "drink"
    );
    ("use strict");

    const logger = DeviceRuntimeCore.HmLogger.getLogger("ageset");

    /*params声明*/
    let strPath = "images/";
    let pageX = 240;
    let pageY = 240;
    let arrTime = [];
    let arrEnWeek = [];
    let arrDate = [];
    let arrData = [];
    let arrReadi = [];
    let arrWeath = [];
    let arrMonth = [];
    let arrBat_L = [];
    let arrRead_L = [];
    let batFNum = null;
    let batSNum = null;
    let batTNum = null;

    for (let i = 1; i < 6; i++) {
      arrBat_L.push(strPath + "bat/" + i + ".png");
    }
    for (let i = 0; i < 9; i++) {
      arrRead_L.push(strPath + "readiness/" + i + ".png");
    }
    for (let i = 1; i < 8; i++) {
      arrEnWeek.push(strPath + "week/" + i + ".png");
    }
    for (let i = 0; i < 10; i++) {
      arrDate.push(strPath+"font/date_font/" + i + ".png");
      arrData.push(strPath+"font/data_font/" + i + ".png");
      arrReadi.push(strPath+"font/read_font/" + i + ".png");
      arrWeath.push(strPath+"font/weat_font/" + i + ".png");
    }
    for (let i = 1; i < 13; i++) {
      arrMonth.push(strPath+"month/" + i + ".png");
    }
    let objBg = {
      x:0,
      y:0,
      src:strPath +"bg.png",
      show_level:hmUI.show_level.ONLY_NORMAL
    }
    let objDate = {
      day_startX: 218,
      day_startY: 86,
      day_align: hmUI.align.LEFT,
      day_space: 0,
      day_zero: 1,
      day_en_array: arrDate,
      day_sc_array: arrDate,
      day_tc_array: arrDate,
      show_level: hmUI.show_level.ONLY_NORMAL
    };
    let objMonth = {
      month_startX:170,
      month_startY:132,
      month_align:hmUI.align.LEFT,
      month_en_array: arrMonth,
      month_sc_array: arrMonth,
      month_tc_array: arrMonth,
      month_is_character:true,
      show_level: hmUI.show_level.ONLY_NORMAL
    }
    let objPointer = {
      hour_centerX: pageX,
      hour_centerY: pageY,
      hour_posX: 22,
      hour_posY: 240,
      hour_path: strPath + "pointer/hour.png",
      minute_centerX: pageX,
      minute_centerY: pageY,
      minute_posX: 22,
      minute_posY: 240,
      minute_path: strPath + "pointer/min.png",
      second_centerX: pageX,
      second_centerY: pageY,
      second_posX: 22,
      second_posY: 240,
      second_path: strPath + "pointer/sec.png",
      show_level: hmUI.show_level.ONLY_NORMAL
    };
    let objAodPointer = {
      hour_centerX: pageX,
      hour_centerY: pageY,
      hour_posX: 22,
      hour_posY: 240,
      hour_path: strPath + "pointer/hour.png",
      minute_centerX: pageX,
      minute_centerY: pageY,
      minute_posX: 22,
      minute_posY: 240,
      minute_path: strPath + "pointer/min.png",
      show_level: hmUI.show_level.ONLY_AOD
    }

    __$$module$$__.module = DeviceRuntimeCore.WatchFace({

      /*get data */
      getFont(options) {
        let objConfig = {
          x: 0,
          y: 0,
          w: 0,
          type: "",
          font_array: arrData,
          h_space: 0,
          align_h: hmUI.align.CENTER_H,
          unit_sc: "",
          unit_tc: "",
          unit_en: "",
          invalid_image: "",
          dot_image:"",
          padding: !1,
          negative_image: "",
          show_level: hmUI.show_level.ONLY_NORMAL
        }
        for (let key in options) {
          if (key in objConfig) {
            objConfig[key] = options[key]
          }
        }
        for (let key in objConfig) {
          if (!objConfig[key]) {
            delete objConfig[key]
          }
        }
        let text = hmUI.createWidget(hmUI.widget.TEXT_IMG, objConfig)
      },
      /* get img */
      getIcon(options){
        let { x, y, src } = options;
        let icon = hmUI.createWidget(hmUI.widget.IMG,{
          x:x,
          y:y,
          src:src,
          show_level:hmUI.show_level.ONLY_NORMAL
        })
        return icon;
      },
      /* get week */
      getWeek(options){
        let { x, y, en, sc, tc, } = options;
        let config = hmUI.createWidget(hmUI.widget.IMG_WEEK,{
          x:x,
          y:y,
          week_en:en,
          week_tc:tc,
          week_sc:sc,
          show_level: hmUI.show_level.ONLY_NORMAL
        })
        return config;
      },
      /* 获取数据指针 */
      getDataPointet(options){
        let { x, y, type } = options
        let pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
          src: strPath + "pointer/pointer.png",
          center_x: x,
          center_y: y,
          x: 10,
          y: 86,
          type:type,
          invalid_visible:true,
          start_angle:0,
          end_angle:360,
          show_level: hmUI.show_level.ONLY_NORMAL
        })
      },
      /* 获取进度--电量/湿度/步数/卡路里 */
      getLevel(options) {
        let { x, y, arr, type } = options
        let progress = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
          x: x,
          y: y,
          image_array: arr,
          image_length: arr.length, //长度
          type: type,
          show_level: hmUI.show_level.ONLY_NORMAL
        })
      },
      /* click jump */
      changeClick(options){
        let { x, y, w, h, type} = options
        let click = hmUI.createWidget(hmUI.widget.IMG_CLICK,{
          x: x,
          y: y,
          w: w,
          h: h,
          type: type,
        })
      },

      init_view() {
        var that = this;
        var batterySensor = hmSensor.createSensor(hmSensor.id.BATTERY);
        /* bg */
        hmUI.createWidget(hmUI.widget.IMG, objBg );

        /* week */
        this.getWeek({x:82,y:-60,en:arrEnWeek,sc:arrEnWeek,tc:arrEnWeek});

        /* data */
        let timeDate = hmUI.createWidget(hmUI.widget.IMG_DATE, objDate);

        /* month */
        let timeMonth = hmUI.createWidget(hmUI.widget.IMG_DATE, objMonth);

        /* step data */
        this.getFont({ x:69, y:251, w:100, type: hmUI.data_type.STEP});

        /* heart data */
        this.getFont({ x:311, y:251, w:100, type: hmUI.data_type.HEART, invalid_image: strPath + "font/data_font/null.png",})

        /* weather data */
        this.getFont({ x:195, y:157, w:100, font_array: arrWeath, h_space: 3, type: hmUI.data_type.WEATHER_CURRENT,negative_image:strPath+"font/weat_font/fu.png", unit_sc: strPath + "font/weat_font/du.png", unit_tc: strPath + "font/weat_font/du.png", unit_en: strPath + "font/weat_font/du.png", invalid_image: strPath + "data_font/null.png",})

        /* readiness level */
        this.getIcon({ x:175, y:296, src: strPath +"readiness/0.png"});

        /* bat level */
        this.getIcon({ x:78, y:360, src: strPath +"bat/0.png"});

        /* readiness data */
        this.getFont({ x:191, y:337, w:100, font_array: arrReadi, type: hmUI.data_type.READINESS, invalid_image: strPath + "font/read_font/null.png",})

        /* Step_pointer */
        this.getDataPointet({ x: 118, y: 239, type: hmUI.data_type.STEP});

        /* HEART_pointer */
        this.getDataPointet({ x: 359, y: 239, type: hmUI.data_type.HEART});

        this.getLevel({x:175,y:296,arr:arrRead_L,type:hmUI.data_type.READINESS});
        this.getLevel({x:78,y:360,arr:arrBat_L,type:hmUI.data_type.BATTERY});

        /* Readiness_pointer */
        let pointers = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
          src: strPath + "pointer/data_p.png",
          center_x: 240,
          center_y: 363,
          x: 13,
          y: 60,
          type:hmUI.data_type.READINESS,
          invalid_visible:true,
          start_angle:-119, //236
          end_angle:119, //123
          show_level: hmUI.show_level.ONLY_NORMAL
        })

        batFNum = hmUI.createWidget(hmUI.widget.IMG, {x: 340,y: 374,src: strPath +"font/bat_font/1.png",show_level: hmUI.show_level.ONLY_NORMAL})
        batTNum = hmUI.createWidget(hmUI.widget.IMG, {x: 348,y: 367,src: strPath +"font/bat_font/0.png",show_level: hmUI.show_level.ONLY_NORMAL})
        batSNum = hmUI.createWidget(hmUI.widget.IMG, {x: 356,y: 360,src: strPath +"font/bat_font/0.png",show_level: hmUI.show_level.ONLY_NORMAL})

        batterySensor.addEventListener(hmSensor.event.CHANGE, function() {
          console.log("battery level changed to:"+batterySensor.current);
          getPower();
        });
        this.getIcon({ x:365, y:350, src: strPath +"font/bat_font/bai.png"});

        /* time */
        let timePointer = hmUI.createWidget(hmUI.widget.TIME_POINTER, objPointer);
        let timeAodPointer = hmUI.createWidget(hmUI.widget.TIME_POINTER, objAodPointer);

        /* hot jump */
         this.changeClick({ x:45, y:165, w: 150, h: 150, type: hmUI.data_type.STEP});
         this.changeClick({ x:285, y:165, w: 150, h: 150, type: hmUI.data_type.HEART});
         this.changeClick({ x:175, y:295, w: 130, h: 130, type: hmUI.data_type.READINESS});
         this.changeClick({ x:220, y:155, w: 45, h: 30, type: hmUI.data_type.WEATHER_CURRENT});

         this.changeClick({ x:100, y:355, w: 50, h: 40, type: hmUI.data_type.BATTERY});
         this.changeClick({ x:340, y:355, w: 40, h: 30, type: hmUI.data_type.BATTERY});


         /* 滑屏幕事件 */
         let widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
          resume_call: (function(){
            getPower();
          }),
          pause_call: (function () {
              console.log('ui pause');
          }),
      });

      function getPower() {
        let fist = parseInt((batterySensor.current % 100) / 10);
        let sec = parseInt(batterySensor.current % 10);

        if( batterySensor.current > 99 ){
          batFNum.setProperty(hmUI.prop.MORE,{src: strPath +"font/bat_font/1.png"})
          batTNum.setProperty(hmUI.prop.MORE,{src: strPath +"font/bat_font/0.png"})
          batSNum.setProperty(hmUI.prop.MORE,{src: strPath +"font/bat_font/0.png"})
        }else if (  batterySensor.current < 10 ){
          batTNum.setProperty(hmUI.prop.VISIBLE, false);
          batFNum.setProperty(hmUI.prop.VISIBLE, false);
          batSNum.setProperty(hmUI.prop.MORE,{x:354, y:362,src: strPath +"font/bat_font/"+batterySensor.current+".png"})
        }else {
          batTNum.setProperty(hmUI.prop.MORE,{src: strPath +"font/bat_font/"+fist+".png"})
          batSNum.setProperty(hmUI.prop.MORE,{src: strPath +"font/bat_font/"+sec+".png"})
          batFNum.setProperty(hmUI.prop.VISIBLE, false);
        }
      }

      },
      onInit() {
        console.log("index page.js on init invoke");
        this.init_view();
      },
      onReady() {
        console.log("index page.js on ready invoke");
      },
      onShow() {
        console.log("index page.js on show invoke");
      },
      onHide() {
        console.log("index page.js on hide invoke");
      },
      onDestory() {
        console.log("index page.js on destory invoke");
      },
    });
    /*
     * end js
     */
  })();
} catch (e) {
  console.log(e);
}

/*
** Facemaker bundle tool v0.0.3
* *huamiOS watchface js version v4.4.0.1
* *Copyright © Huami. All Rights Reserved
*/


try {
	(() => {
		var __$$app$$__ = __$$hmAppManager$$__.currentApp;
		var __$$module$$__ = __$$app$$__.current;

		//drink is a name,can modify
		var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

		'use strict';

		//dynamic modify start
		let normal_img0 = '';
		let normal_weather_imageset2 = '';
		let normal_temperature_current_imagecombo3 = '';
		let normal_temperature_low_imagecombo4 = '';
		let normal_temperature_high_imagecombo5 = '';
		let normal_img6 = '';
		let normal_steps_imagecombo8 = '';
		let normal_img9 = '';
		let normal_calories_imagecombo11 = '';
		let normal_img12 = '';
		let normal_distance_imagecombo14 = '';
		let normal_img15 = '';
		let normal_sleep_imagecombo17 = new Array(4);
		let normal_sleep_imagecombo17_padding = false;
		let normal_sleep_imagecombo17_array = ['0053.png','0054.png','0055.png','0056.png','0057.png','0058.png','0059.png','0060.png','0061.png','0062.png','0077.png'];
		let normal_img18 = '';
		let normal_heart_current_imagecombo20 = '';
		let normal_img21 = '';
		let normal_stress_imagecombo23 = '';
		let normal_img24 = '';
		let normal_bt_status26 = '';
		let normal_week_imageset28 = '';
		let normal_month_imageset29 = '';
		let normal_date_imagecombo30 = '';
		let normal_hour_imagecombo32 = '';
		let normal_minute_imagecombo33 = '';
		let normal_second_imagecombo34 = '';
		let normal_img35 = '';
		let normal_img36 = '';
		let normal_img37 = '';
		let normal_img38 = '';
		let normal_calories_shortcut41 = '';
		let normal_heart_shortcut42 = '';
		let normal_sleep_shortcut43 = '';
		let normal_steps_shortcut44 = '';
		let normal_stress_shortcut45 = '';
		let normal_weather_shortcut46 = '';
		let normal_alarm_shortcut47 = '';
		let normal_countdown_shortcut48 = '';
		let normal_calendar_shortcut49 = '';
		//dynamic modify end

		//not required
		const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

		__$$module$$__.module = DeviceRuntimeCore.WatchFace({
			init_view() {

				const sleepSensor = hmSensor.createSensor(hmSensor.id.SLEEP);
				let screenType = hmSetting.getScreenType();

				normal_img0 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					src: '0002.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_weather_imageset2 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
					x: 109,
					y: 25,
					image_array: ["0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0005.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png","0023.png","0024.png","0025.png","0026.png","0027.png","0003.png","0004.png","0006.png"],
					image_length: 29,
					type: hmUI.data_type.WEATHER_CURRENT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_temperature_current_imagecombo3 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 176,
					y: 44,
					font_array: ["0028.png","0029.png","0030.png","0031.png","0032.png","0033.png","0034.png","0035.png","0036.png","0037.png"],
					padding: false,
					h_space: -3,
					unit_sc: ["0039.png"],
					unit_tc: ["0039.png"],
					unit_en: ["0039.png"],
					negative_image: ["0038.png"],
					invalid_image: ["0038.png"],
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.WEATHER_CURRENT,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_temperature_low_imagecombo4 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 118,
					y: 91,
					font_array: ["0040.png","0041.png","0042.png","0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png"],
					padding: false,
					h_space: -3,
					unit_sc: ["0051.png"],
					unit_tc: ["0051.png"],
					unit_en: ["0051.png"],
					negative_image: ["0050.png"],
					invalid_image: ["0050.png"],
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.WEATHER_LOW,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_temperature_high_imagecombo5 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 184,
					y: 91,
					font_array: ["0040.png","0041.png","0042.png","0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png"],
					padding: false,
					h_space: -3,
					unit_sc: ["0051.png"],
					unit_tc: ["0051.png"],
					unit_en: ["0051.png"],
					negative_image: ["0050.png"],
					invalid_image: ["0050.png"],
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.WEATHER_HIGH,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img6 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 172,
					y: 91,
					w: 16,
					h: 38,
					src: '0052.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_steps_imagecombo8 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 72,
					y: 277,
					font_array: ["0053.png","0054.png","0055.png","0056.png","0057.png","0058.png","0059.png","0060.png","0061.png","0062.png"],
					padding: false,
					h_space: -3,
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.STEP,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img9 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 25,
					y: 280,
					w: 45,
					h: 35,
					src: '0063.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_calories_imagecombo11 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 86,
					y: 324,
					font_array: ["0064.png","0065.png","0066.png","0067.png","0068.png","0069.png","0070.png","0071.png","0072.png","0073.png"],
					padding: false,
					h_space: -3,
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.CAL,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img12 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 49,
					y: 325,
					w: 31,
					h: 37,
					src: '0074.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_distance_imagecombo14 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 110,
					y: 371,
					font_array: ["0064.png","0065.png","0066.png","0067.png","0068.png","0069.png","0070.png","0071.png","0072.png","0073.png"],
					padding: false,
					h_space: -3,
					dot_image: '0075.png',
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.DISTANCE,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img15 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 77,
					y: 374,
					w: 33,
					h: 33,
					src: '0076.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				for (let i = 0; i < normal_sleep_imagecombo17.length; i++) {
					normal_sleep_imagecombo17[i] = hmUI.createWidget(hmUI.widget.IMG, {
						x: 337 + i * 24,
						y: 133,
						w: 24,
						h: 45,
						enable: false,
						show_level: hmUI.show_level.ONLY_NORMAL,
					})

				}

				normal_img18 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 286,
					y: 132,
					w: 44,
					h: 49,
					src: '0078.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_heart_current_imagecombo20 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 331,
					y: 90,
					font_array: ["0079.png","0080.png","0081.png","0082.png","0083.png","0084.png","0085.png","0086.png","0087.png","0088.png"],
					padding: false,
					h_space: -3,
					invalid_image: '0089.png',
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.HEART,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img21 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 289,
					y: 91,
					w: 37,
					h: 37,
					src: '0090.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_stress_imagecombo23 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 317,
					y: 47,
					font_array: ["0079.png","0080.png","0081.png","0082.png","0083.png","0084.png","0085.png","0086.png","0087.png","0088.png"],
					padding: false,
					h_space: -3,
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.STRESS,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img24 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 286,
					y: 44,
					w: 30,
					h: 37,
					src: '0091.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_bt_status26 = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
					x: 165,
					y: 416,
					w: 46,
					h: 46,
					type: hmUI.system_status.DISCONNECT,
					src: '0092.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_week_imageset28 = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
					x: 294,
					y: 393,
					week_en: ["0093.png","0094.png","0095.png","0096.png","0097.png","0098.png","0099.png"],
					week_tc: ["0093.png","0094.png","0095.png","0096.png","0097.png","0098.png","0099.png"],
					week_sc: ["0093.png","0094.png","0095.png","0096.png","0097.png","0098.png","0099.png"],
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_month_imageset29 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
					month_startX: 349,
					month_startY: 364,
					month_sc_array: ["0100.png","0101.png","0102.png","0103.png","0104.png","0105.png","0106.png","0107.png","0108.png","0109.png","0110.png","0111.png"],
					month_tc_array: ["0100.png","0101.png","0102.png","0103.png","0104.png","0105.png","0106.png","0107.png","0108.png","0109.png","0110.png","0111.png"],
					month_en_array: ["0100.png","0101.png","0102.png","0103.png","0104.png","0105.png","0106.png","0107.png","0108.png","0109.png","0110.png","0111.png"],
					month_is_character: true,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_date_imagecombo30 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
					day_startX: 292,
					day_startY: 364,
					day_sc_array: ["0112.png","0113.png","0114.png","0115.png","0116.png","0117.png","0118.png","0119.png","0120.png","0121.png"],
					day_tc_array: ["0112.png","0113.png","0114.png","0115.png","0116.png","0117.png","0118.png","0119.png","0120.png","0121.png"],
					day_en_array: ["0112.png","0113.png","0114.png","0115.png","0116.png","0117.png","0118.png","0119.png","0120.png","0121.png"],
					day_zero: true,
					day_space: -3,
					day_align: hmUI.align.CENTER_H,
					day_is_character: false,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_hour_imagecombo32 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					hour_startX: 37,
					hour_startY: 129,
					hour_array: ["0122.png","0123.png","0124.png","0125.png","0126.png","0127.png","0128.png","0129.png","0130.png","0131.png"],
					hour_zero: true,
					hour_space: -15,
					hour_align: hmUI.align.CENTER_H,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_minute_imagecombo33 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					minute_startX: 265,
					minute_startY: 179,
					minute_array: ["0132.png","0133.png","0134.png","0135.png","0136.png","0137.png","0138.png","0139.png","0140.png","0141.png"],
					minute_zero: true,
					minute_space: -15,
					minute_align: hmUI.align.CENTER_H,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_second_imagecombo34 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					second_startX: 372,
					second_startY: 310,
					second_array: ["0142.png","0143.png","0144.png","0145.png","0146.png","0147.png","0148.png","0149.png","0150.png","0151.png"],
					second_zero: true,
					second_space: -9,
					second_align: hmUI.align.CENTER_H,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img35 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 301,
					y: 332,
					w: 64,
					h: 36,
					src: '0152.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img36 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 175,
					y: 0,
					w: 149,
					h: 480,
					src: '0153.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img37 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					src: '0154.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img38 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					src: '0155.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_calories_shortcut41 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 73,
					y: 325,
					w: 100,
					h: 37,
					src: '',
					type: hmUI.data_type.CAL,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_heart_shortcut42 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 301,
					y: 89,
					w: 100,
					h: 35,
					src: '',
					type: hmUI.data_type.HEART,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_sleep_shortcut43 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 310,
					y: 137,
					w: 100,
					h: 35,
					src: '',
					type: hmUI.data_type.SLEEP,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_steps_shortcut44 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 73,
					y: 280,
					w: 100,
					h: 35,
					src: '',
					type: hmUI.data_type.STEP,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_stress_shortcut45 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 283,
					y: 46,
					w: 100,
					h: 35,
					src: '',
					type: hmUI.data_type.STRESS,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_weather_shortcut46 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 133,
					y: 13,
					w: 100,
					h: 100,
					src: '',
					type: hmUI.data_type.WEATHER_CURRENT,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_alarm_shortcut47 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 97,
					y: 145,
					w: 100,
					h: 100,
					src: '',
					type: hmUI.data_type.ALARM_CLOCK,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_countdown_shortcut48 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 313,
					y: 193,
					w: 100,
					h: 100,
					src: '',
					type: hmUI.data_type.COUNT_DOWN,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_calendar_shortcut49 = hmUI.createWidget(hmUI.widget.BUTTON, {
					x: 277,
					y: 325,
					w: 100,
					h: 100,
					text: '',
					normal_src: '',
					press_src: '',
					click_func: () => {
						hmApp.startApp({ url: 'ScheduleCalScreen', native: true });
					},
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				function updateSleep() {
					let normal_sleep_imagecombo17_h = Math.floor(sleepSensor.getTotalTime() / 60).toString();
					let normal_sleep_imagecombo17_m = Math.floor(sleepSensor.getTotalTime() % 60).toString().padStart(2, '0');
					let normal_sleep_imagecombo17_current = (normal_sleep_imagecombo17_padding === true ? normal_sleep_imagecombo17_h.padStart(2, '0') : normal_sleep_imagecombo17_h) + ':' + normal_sleep_imagecombo17_m;
					let normal_sleep_imagecombo17_cp = (normal_sleep_imagecombo17_padding === true || normal_sleep_imagecombo17_h.length == 2) ? 2 : 1;
					for (let i = 0; i < normal_sleep_imagecombo17.length; i++) {
						if (i == normal_sleep_imagecombo17_cp) {
							normal_sleep_imagecombo17[i].setProperty(hmUI.prop.SRC, normal_sleep_imagecombo17_array[10]);
						} else {
							normal_sleep_imagecombo17[i].setProperty(hmUI.prop.SRC, normal_sleep_imagecombo17_array[normal_sleep_imagecombo17_current.toString().charAt(i)]);
						}
					}
				}

				sleepSensor.addEventListener(hmSensor.event.CHANGE, function() {
					updateSleep();
				});

				const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
					resume_call: (function () {
						updateSleep();
					}),
					pause_call: (function () {
					}),
				})
			},

		onInit() {
			console.log('index page.js on init invoke')
			this.init_view()
		},
		onReady() {
			console.log('index page.js on ready invoke')
		},
		onShow() {
			console.log('index page.js on show invoke')
		},
		onHide() {
			console.log('index page.js on hide invoke')
		},
		onDestroy() {
			console.log('index page.js on destroy invoke')
		},
	});	})()
} catch (e) {
	console.log(e)
}
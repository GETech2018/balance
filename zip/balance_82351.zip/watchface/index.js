﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_frame_animation_1 = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_step_current_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_date_img_date_year = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_week_img = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg_img = ''
        let idle_battery_text_text_img = ''
        let idle_battery_image_progress_img_level = ''
        let idle_weather_image_progress_img_level = ''
        let idle_temperature_high_text_img = ''
        let idle_temperature_low_text_img = ''
        let idle_temperature_current_text_img = ''
        let idle_calorie_current_text_img = ''
        let idle_step_current_text_img = ''
        let idle_heart_rate_text_text_img = ''
        let idle_date_img_date_year = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_month = ''
        let idle_date_img_date_week_img = ''
        let idle_digital_clock_img_time = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'background2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_frame_animation_1 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
              x: 253,
              y: -12,
              anim_path: "animation",
              anim_ext: "png",
              anim_prefix: "anim",
              anim_fps: 10,
              anim_size: 19,
              repeat_count: 0,
              anim_repeat: true,
              anim_status:hmUI.anim_status.START,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 221,
              y: 432,
              font_array: ["st0.png","st01.png","st02.png","st03.png","st04.png","st05.png","st06.png","st07.png","st08.png","st09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'PER.png',
              unit_tc: 'PER.png',
              unit_en: 'PER.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 174,
              y: 441,
              image_array: ["ba0.png","ba1.png","ba2.png","ba3.png","ba4.png"],
              image_length: 5,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 193,
              y: 28,
              image_array: ["w0.png","w1.png","w10.png","w11.png","w12.png","w13.png","w14.png","w15.png","w16.png","w17.png","w18.png","w19.png","w2.png","w20.png","w21.png","w22.png","w23.png","w24.png","w25.png","w26.png","w27.png","w28.png","w3.png","w4.png","w5.png","w6.png","w7.png","w8.png","w9.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 114,
              y: 47,
              font_array: ["st0.png","st01.png","st02.png","st03.png","st04.png","st05.png","st06.png","st07.png","st08.png","st09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'GRA-GRANDI.png',
              unit_tc: 'GRA-GRANDI.png',
              unit_en: 'GRA-GRANDI.png',
              negative_image: 'menomake.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 310,
              y: 382,
              font_array: ["st0.png","st01.png","st02.png","st03.png","st04.png","st05.png","st06.png","st07.png","st08.png","st09.png"],
              padding: false,
              h_space: -1,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 181,
              y: 382,
              font_array: ["st0.png","st01.png","st02.png","st03.png","st04.png","st05.png","st06.png","st07.png","st08.png","st09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 78,
              y: 382,
              font_array: ["st0.png","st01.png","st02.png","st03.png","st04.png","st05.png","st06.png","st07.png","st08.png","st09.png"],
              padding: false,
              h_space: -1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 382,
              year_startY: 304,
              year_sc_array: ["st0.png","st01.png","st02.png","st03.png","st04.png","st05.png","st06.png","st07.png","st08.png","st09.png"],
              year_tc_array: ["st0.png","st01.png","st02.png","st03.png","st04.png","st05.png","st06.png","st07.png","st08.png","st09.png"],
              year_en_array: ["st0.png","st01.png","st02.png","st03.png","st04.png","st05.png","st06.png","st07.png","st08.png","st09.png"],
              year_zero: 0,
              year_space: 0,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 85,
              day_startY: 304,
              day_sc_array: ["st0.png","st01.png","st02.png","st03.png","st04.png","st05.png","st06.png","st07.png","st08.png","st09.png"],
              day_tc_array: ["st0.png","st01.png","st02.png","st03.png","st04.png","st05.png","st06.png","st07.png","st08.png","st09.png"],
              day_en_array: ["st0.png","st01.png","st02.png","st03.png","st04.png","st05.png","st06.png","st07.png","st08.png","st09.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 256,
              month_startY: 304,
              month_sc_array: ["st0.png","st01.png","st02.png","st03.png","st04.png","st05.png","st06.png","st07.png","st08.png","st09.png"],
              month_tc_array: ["st0.png","st01.png","st02.png","st03.png","st04.png","st05.png","st06.png","st07.png","st08.png","st09.png"],
              month_en_array: ["st0.png","st01.png","st02.png","st03.png","st04.png","st05.png","st06.png","st07.png","st08.png","st09.png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 142,
              y: 121,
              week_en: ["settimana1.png","settimana2.png","settimana3.png","settimana4.png","settimana5.png","settimana6.png","settimana7.png"],
              week_tc: ["settimana1.png","settimana2.png","settimana3.png","settimana4.png","settimana5.png","settimana6.png","settimana7.png"],
              week_sc: ["settimana1.png","settimana2.png","settimana3.png","settimana4.png","settimana5.png","settimana6.png","settimana7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 49,
              hour_startY: 164,
              hour_array: ["z0.png","z1.png","z2.png","z3.png","z4.png","z5.png","z6.png","z7.png","z8.png","z9.png"],
              hour_zero: 1,
              hour_space: 9,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 189,
              minute_startY: 164,
              minute_array: ["z0.png","z1.png","z2.png","z3.png","z4.png","z5.png","z6.png","z7.png","z8.png","z9.png"],
              minute_zero: 1,
              minute_space: 6,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 323,
              second_startY: 164,
              second_array: ["z0.png","z1.png","z2.png","z3.png","z4.png","z5.png","z6.png","z7.png","z8.png","z9.png"],
              second_zero: 1,
              second_space: 4,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'aod2.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 221,
              y: 432,
              font_array: ["st0.png","st01.png","st02.png","st03.png","st04.png","st05.png","st06.png","st07.png","st08.png","st09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'PER.png',
              unit_tc: 'PER.png',
              unit_en: 'PER.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 174,
              y: 441,
              image_array: ["ba0.png","ba1.png","ba2.png","ba3.png","ba4.png"],
              image_length: 5,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 193,
              y: 28,
              image_array: ["w0.png","w1.png","w10.png","w11.png","w12.png","w13.png","w14.png","w15.png","w16.png","w17.png","w18.png","w19.png","w2.png","w20.png","w21.png","w22.png","w23.png","w24.png","w25.png","w26.png","w27.png","w28.png","w3.png","w4.png","w5.png","w6.png","w7.png","w8.png","w9.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 390,
              y: 91,
              font_array: ["MINI0.png","MINI01.png","MINI02.png","MINI03.png","MINI04.png","MINI05.png","MINI06.png","MINI07.png","MINI08.png","MINI09.png"],
              padding: false,
              h_space: -1,
              unit_sc: 'GRA.png',
              unit_tc: 'GRA.png',
              unit_en: 'GRA.png',
              negative_image: 'MENO.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 303,
              y: 91,
              font_array: ["MINI0.png","MINI01.png","MINI02.png","MINI03.png","MINI04.png","MINI05.png","MINI06.png","MINI07.png","MINI08.png","MINI09.png"],
              padding: false,
              h_space: -2,
              unit_sc: 'GRA.png',
              unit_tc: 'GRA.png',
              unit_en: 'GRA.png',
              negative_image: 'MENO.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 114,
              y: 47,
              font_array: ["st0.png","st01.png","st02.png","st03.png","st04.png","st05.png","st06.png","st07.png","st08.png","st09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'GRA-GRANDI.png',
              unit_tc: 'GRA-GRANDI.png',
              unit_en: 'GRA-GRANDI.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 310,
              y: 382,
              font_array: ["st0.png","st01.png","st02.png","st03.png","st04.png","st05.png","st06.png","st07.png","st08.png","st09.png"],
              padding: false,
              h_space: -1,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 181,
              y: 382,
              font_array: ["st0.png","st01.png","st02.png","st03.png","st04.png","st05.png","st06.png","st07.png","st08.png","st09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 78,
              y: 382,
              font_array: ["st0.png","st01.png","st02.png","st03.png","st04.png","st05.png","st06.png","st07.png","st08.png","st09.png"],
              padding: false,
              h_space: -1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 382,
              year_startY: 304,
              year_sc_array: ["st0.png","st01.png","st02.png","st03.png","st04.png","st05.png","st06.png","st07.png","st08.png","st09.png"],
              year_tc_array: ["st0.png","st01.png","st02.png","st03.png","st04.png","st05.png","st06.png","st07.png","st08.png","st09.png"],
              year_en_array: ["st0.png","st01.png","st02.png","st03.png","st04.png","st05.png","st06.png","st07.png","st08.png","st09.png"],
              year_zero: 0,
              year_space: 0,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 85,
              day_startY: 304,
              day_sc_array: ["st0.png","st01.png","st02.png","st03.png","st04.png","st05.png","st06.png","st07.png","st08.png","st09.png"],
              day_tc_array: ["st0.png","st01.png","st02.png","st03.png","st04.png","st05.png","st06.png","st07.png","st08.png","st09.png"],
              day_en_array: ["st0.png","st01.png","st02.png","st03.png","st04.png","st05.png","st06.png","st07.png","st08.png","st09.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 256,
              month_startY: 304,
              month_sc_array: ["st0.png","st01.png","st02.png","st03.png","st04.png","st05.png","st06.png","st07.png","st08.png","st09.png"],
              month_tc_array: ["st0.png","st01.png","st02.png","st03.png","st04.png","st05.png","st06.png","st07.png","st08.png","st09.png"],
              month_en_array: ["st0.png","st01.png","st02.png","st03.png","st04.png","st05.png","st06.png","st07.png","st08.png","st09.png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 142,
              y: 121,
              week_en: ["settimana1.png","settimana2.png","settimana3.png","settimana4.png","settimana5.png","settimana6.png","settimana7.png"],
              week_tc: ["settimana1.png","settimana2.png","settimana3.png","settimana4.png","settimana5.png","settimana6.png","settimana7.png"],
              week_sc: ["settimana1.png","settimana2.png","settimana3.png","settimana4.png","settimana5.png","settimana6.png","settimana7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 49,
              hour_startY: 164,
              hour_array: ["z0.png","z1.png","z2.png","z3.png","z4.png","z5.png","z6.png","z7.png","z8.png","z9.png"],
              hour_zero: 1,
              hour_space: 9,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 189,
              minute_startY: 164,
              minute_array: ["z0.png","z1.png","z2.png","z3.png","z4.png","z5.png","z6.png","z7.png","z8.png","z9.png"],
              minute_zero: 1,
              minute_space: 6,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 323,
              second_startY: 164,
              second_array: ["z0.png","z1.png","z2.png","z3.png","z4.png","z5.png","z6.png","z7.png","z8.png","z9.png"],
              second_zero: 1,
              second_space: 4,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);

              }),
              pause_call: (function () {
                console.log('pause_call()');
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
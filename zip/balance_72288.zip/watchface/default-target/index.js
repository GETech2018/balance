try {
    ((() => {
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        let normal$_$text_73064a646de047469a318db7b3f2040d = '';
        let normal$_$text_65ccda27366f4f0bbcd15731c44a28cf = '';
        let normal$_$text_ddbfd994ce0e46cd84fa539b64396812 = '';
        let normal$_$text_8f2a16e4fb4c478cb918d4604483fa59 = '';
        let normal$_$text_ccd9851aa6c545fca1635af6d7c71140 = '';
        let normal$_$text_1149859dfba6405da20e0bbb5bbb82a1 = '';
        let dateFormat = '';
        let dateFormatMap = '';
        let normal$_$text_fd361035a2cf4485a4d81e0a3c69d233 = '';
        let normal$_$text_15eff7fa829746aba19de6d9935e7aa6 = '';
        let normal$_$text_168d2410a2fb4469b7362cad67bc12ce = '';
        let idle$_$text_4e8db14d58754849854350af95a9c688 = '';
        let idle$_$text_2b77b95f27234b47abceab3bec8ab3d4 = '';
        let batterySensor = '';
        let heartSensor = '';
        let timeSensor = '';
        const logger = Logger.getLogger('watchface');
        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 480,
                    h: 480,
                    src: '2.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 10,
                    y: 10,
                    src: '3.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_73064a646de047469a318db7b3f2040d = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 107,
                    y: 214,
                    w: 100,
                    h: 40,
                    text: '[BATT_PER]',
                    color: '0xFFb06216',
                    text_size: 23,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_65ccda27366f4f0bbcd15731c44a28cf = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 114,
                    y: 190,
                    w: 100,
                    h: 40,
                    text: 'batt',
                    color: '0xFFa6a31b',
                    text_size: 23,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_ddbfd994ce0e46cd84fa539b64396812 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 246,
                    y: 178,
                    w: 100,
                    h: 40,
                    text: 'date',
                    color: '0xFFa6a31b',
                    text_size: 23,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_8f2a16e4fb4c478cb918d4604483fa59 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 247,
                    y: 256,
                    w: 100,
                    h: 40,
                    text: 'bpm',
                    color: '0xFFa6a31b',
                    text_size: 23,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_ccd9851aa6c545fca1635af6d7c71140 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 242,
                    y: 284,
                    w: 100,
                    h: 40,
                    text: '[HR]',
                    color: '0xFF105576',
                    text_size: 23,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    src: '4.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_1149859dfba6405da20e0bbb5bbb82a1 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 306,
                    y: 226,
                    w: 40,
                    h: 29,
                    text: '[DAY_Z]',
                    color: '0xFFb06216',
                    text_size: 23,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_fd361035a2cf4485a4d81e0a3c69d233 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 200,
                    y: 168,
                    w: 60,
                    h: 60,
                    text: '[HOUR_24_Z]',
                    color: '0xFFb06216',
                    text_size: 45,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 4,
                    y: 7,
                    src: '5.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 54,
                    y: 0,
                    src: '6.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_15eff7fa829746aba19de6d9935e7aa6 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 263,
                    y: 218,
                    w: 42,
                    h: 31,
                    text: '[MON_Z]',
                    color: '0xFF105576',
                    text_size: 23,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_168d2410a2fb4469b7362cad67bc12ce = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 200,
                    y: 241,
                    w: 60,
                    h: 60,
                    text: '[MIN_Z]',
                    color: '0xFF105576',
                    text_size: 45,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                    x: 4,
                    y: 7,
                    image_array: [
                        '7.png',
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png',
                        '12.png',
                        '13.png',
                        '14.png',
                        '15.png',
                        '16.png'
                    ],
                    image_length: 10,
                    type: hmUI.data_type.BATTERY,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                idle$_$text_4e8db14d58754849854350af95a9c688 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 169,
                    y: 180,
                    w: 127,
                    h: 60,
                    text: '[HOUR_24_Z]',
                    color: '0xFF686767',
                    text_size: 60,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_AOD
                });
                idle$_$text_2b77b95f27234b47abceab3bec8ab3d4 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 182,
                    y: 258,
                    w: 100,
                    h: 62,
                    text: '[MIN_Z]',
                    color: '0xFF686767',
                    text_size: 60,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_AOD
                });
                if (!batterySensor) {
                    batterySensor = hmSensor.createSensor(hmSensor.id.BATTERY);
                }
                if (!heartSensor) {
                    heartSensor = hmSensor.createSensor(hmSensor.id.HEART);
                }
                if (!timeSensor) {
                    timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
                }
                batterySensor.addEventListener(hmSensor.event.CHANGE, function () {
                    normal$_$text_73064a646de047469a318db7b3f2040d.setProperty(hmUI.prop.MORE, { text: `${ batterySensor.current }` });
                }), heartSensor.addEventListener(heartSensor.event.LAST, function () {
                    normal$_$text_ccd9851aa6c545fca1635af6d7c71140.setProperty(hmUI.prop.MORE, { text: `${ heartSensor.last }` });
                }), timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function () {
                    dateFormat = hmSetting.getDateFormat();
                    dateFormatMap = [
                        () => {
                            normal$_$text_1149859dfba6405da20e0bbb5bbb82a1.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.day).padStart(2, '0') }` });
                        },
                        () => {
                            normal$_$text_1149859dfba6405da20e0bbb5bbb82a1.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.day).padStart(2, '0') }` });
                        },
                        () => {
                            normal$_$text_1149859dfba6405da20e0bbb5bbb82a1.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.day).padStart(2, '0') }` });
                        }
                    ];
                    dateFormatMap[dateFormat]();
                    dateFormat = hmSetting.getDateFormat();
                    dateFormatMap = [
                        () => {
                            normal$_$text_15eff7fa829746aba19de6d9935e7aa6.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.month).padStart(2, '0') }` });
                        },
                        () => {
                            normal$_$text_15eff7fa829746aba19de6d9935e7aa6.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.month).padStart(2, '0') }` });
                        },
                        () => {
                            normal$_$text_15eff7fa829746aba19de6d9935e7aa6.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.month).padStart(2, '0') }` });
                        }
                    ];
                    dateFormatMap[dateFormat]();
                }), timeSensor.addEventListener(timeSensor.event.MINUTEEND, function () {
                    normal$_$text_fd361035a2cf4485a4d81e0a3c69d233.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.hour).padStart(2, '0') }` });
                    idle$_$text_4e8db14d58754849854350af95a9c688.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.hour).padStart(2, '0') }` });
                });
                normal$_$text_168d2410a2fb4469b7362cad67bc12ce.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.minute).padStart(2, '0') }` });
                idle$_$text_2b77b95f27234b47abceab3bec8ab3d4.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.minute).padStart(2, '0') }` });
                timer.createTimer(0, 1000, function (timeSensor2) {
                    normal$_$text_168d2410a2fb4469b7362cad67bc12ce.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor2.minute).padStart(2, '0') }` });
                    idle$_$text_2b77b95f27234b47abceab3bec8ab3d4.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor2.minute).padStart(2, '0') }` });
                }, timeSensor);
                hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
                    resume_call: function () {
                        normal$_$text_73064a646de047469a318db7b3f2040d.setProperty(hmUI.prop.MORE, { text: `${ batterySensor.current }` });
                        normal$_$text_65ccda27366f4f0bbcd15731c44a28cf.setProperty(hmUI.prop.MORE, { text: `batt` });
                        normal$_$text_ddbfd994ce0e46cd84fa539b64396812.setProperty(hmUI.prop.MORE, { text: `date` });
                        normal$_$text_8f2a16e4fb4c478cb918d4604483fa59.setProperty(hmUI.prop.MORE, { text: `bpm` });
                        normal$_$text_ccd9851aa6c545fca1635af6d7c71140.setProperty(hmUI.prop.MORE, { text: `${ heartSensor.last }` });
                        dateFormat = hmSetting.getDateFormat();
                        dateFormatMap = [
                            () => {
                                normal$_$text_1149859dfba6405da20e0bbb5bbb82a1.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.day).padStart(2, '0') }` });
                            },
                            () => {
                                normal$_$text_1149859dfba6405da20e0bbb5bbb82a1.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.day).padStart(2, '0') }` });
                            },
                            () => {
                                normal$_$text_1149859dfba6405da20e0bbb5bbb82a1.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.day).padStart(2, '0') }` });
                            }
                        ];
                        dateFormatMap[dateFormat]();
                        normal$_$text_fd361035a2cf4485a4d81e0a3c69d233.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.hour).padStart(2, '0') }` });
                        dateFormat = hmSetting.getDateFormat();
                        dateFormatMap = [
                            () => {
                                normal$_$text_15eff7fa829746aba19de6d9935e7aa6.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.month).padStart(2, '0') }` });
                            },
                            () => {
                                normal$_$text_15eff7fa829746aba19de6d9935e7aa6.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.month).padStart(2, '0') }` });
                            },
                            () => {
                                normal$_$text_15eff7fa829746aba19de6d9935e7aa6.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.month).padStart(2, '0') }` });
                            }
                        ];
                        dateFormatMap[dateFormat]();
                        normal$_$text_168d2410a2fb4469b7362cad67bc12ce.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.minute).padStart(2, '0') }` });
                        idle$_$text_4e8db14d58754849854350af95a9c688.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.hour).padStart(2, '0') }` });
                        idle$_$text_2b77b95f27234b47abceab3bec8ab3d4.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.minute).padStart(2, '0') }` });
                    }
                });
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })());
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
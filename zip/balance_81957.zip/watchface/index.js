﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_date_img_date_week_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_heart_rate_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_battery_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_system_clock_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_lock_img = ''
        let idle_background_bg_img = ''
        let idle_digital_clock_img_time = ''
        let normal_step_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: '2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 75,
              y: 66,
              image_array: ["moon_00.png","moon_01.png","moon_02.png","moon_03.png","moon_04.png","moon_05.png","moon_06.png","moon_07.png","moon_08.png","moon_09.png","moon_10.png","moon_11.png","moon_12.png","moon_13.png","moon_14.png","moon_15.png","moon_16.png","moon_17.png","moon_18.png","moon_19.png","moon_20.png","moon_21.png","moon_22.png","moon_23.png","moon_24.png","moon_25.png","moon_26.png","moon_27.png","moon_28.png","moon_29.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 398,
              month_startY: 303,
              month_sc_array: ["125.png","126.png","127.png","128.png","129.png","130.png","131.png","132.png","133.png","134.png"],
              month_tc_array: ["125.png","126.png","127.png","128.png","129.png","130.png","131.png","132.png","133.png","134.png"],
              month_en_array: ["125.png","126.png","127.png","128.png","129.png","130.png","131.png","132.png","133.png","134.png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.RIGHT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 334,
              day_startY: 303,
              day_sc_array: ["125.png","126.png","127.png","128.png","129.png","130.png","131.png","132.png","133.png","134.png"],
              day_tc_array: ["125.png","126.png","127.png","128.png","129.png","130.png","131.png","132.png","133.png","134.png"],
              day_en_array: ["125.png","126.png","127.png","128.png","129.png","130.png","131.png","132.png","133.png","134.png"],
              day_zero: 1,
              day_space: 0,
              day_unit_sc: '138.png',
              day_unit_tc: '138.png',
              day_unit_en: '138.png',
              day_align: hmUI.align.RIGHT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 214,
              hour_startY: 220,
              hour_array: ["digital_0.png","digital_1.png","digital_2.png","digital_3.png","digital_4.png","digital_5.png","digital_6.png","digital_7.png","digital_8.png","digital_9.png"],
              hour_zero: 0,
              hour_space: 8,
              hour_angle: 0,
              hour_unit_sc: 'digital_10.png',
              hour_unit_tc: 'digital_10.png',
              hour_unit_en: 'digital_10.png',
              hour_align: hmUI.align.RIGHT,

              minute_startX: 357,
              minute_startY: 220,
              minute_array: ["digital_0.png","digital_1.png","digital_2.png","digital_3.png","digital_4.png","digital_5.png","digital_6.png","digital_7.png","digital_8.png","digital_9.png"],
              minute_zero: 1,
              minute_space: 8,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.RIGHT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 168,
              am_y: 68,
              am_sc_path: '29.png',
              am_en_path: '29.png',
              pm_x: 189,
              pm_y: 96,
              pm_sc_path: '30.png',
              pm_en_path: '30.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 58,
              y: 355,
              week_en: ["day_01.png","day_02.png","day_03.png","day_04.png","day_05.png","day_06.png","day_07.png"],
              week_tc: ["day_01.png","day_02.png","day_03.png","day_04.png","day_05.png","day_06.png","day_07.png"],
              week_sc: ["day_01.png","day_02.png","day_03.png","day_04.png","day_05.png","day_06.png","day_07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 250,
              y: 351,
              image_array: ["weather_0.png","weather_1.png","weather_2.png","weather_3.png","weather_4.png","weather_5.png","weather_6.png","weather_7.png","weather_8.png","weather_9.png","weather_10.png","weather_11.png","weather_12.png","weather_13.png","weather_14.png","weather_15.png","weather_16.png","weather_17.png","weather_18.png","weather_19.png","weather_20.png","weather_21.png","weather_22.png","weather_23.png","weather_24.png","weather_25.png","weather_26.png","weather_27.png","weather_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 146,
              y: 358,
              font_array: ["125.png","126.png","127.png","128.png","129.png","130.png","131.png","132.png","133.png","134.png"],
              padding: false,
              h_space: 0,
              unit_sc: '115.png',
              unit_tc: '115.png',
              unit_en: '115.png',
              negative_image: '114.png',
              invalid_image: '113.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 198,
              y: 59,
              image_array: ["119.png","120.png","121.png","122.png","123.png","124.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 244,
              y: 74,
              font_array: ["125.png","126.png","127.png","128.png","129.png","130.png","131.png","132.png","133.png","134.png"],
              padding: false,
              h_space: 0,
              invalid_image: '135.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 191,
              y: 177,
              image_array: ["140.png","141.png","142.png","143.png","144.png","145.png","146.png","147.png","148.png","149.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 382,
              y: 174,
              font_array: ["89.png","90.png","91.png","92.png","93.png","94.png","95.png","96.png","97.png","98.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 172,
              y: 26,
              font_array: ["89.png","90.png","91.png","92.png","93.png","94.png","95.png","96.png","97.png","98.png"],
              padding: false,
              h_space: 0,
              invalid_image: '99.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'row_hour.png',
              hour_centerX: 103,
              hour_centerY: 243,
              hour_posX: 4,
              hour_posY: 60,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'row_min.png',
              minute_centerX: 103,
              minute_centerY: 243,
              minute_posX: 8,
              minute_posY: 81,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'row_sec.png',
              second_centerX: 103,
              second_centerY: 243,
              second_posX: 4,
              second_posY: 79,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 184,
              y: 307,
              src: '8.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 184,
              y: 307,
              src: '5.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 184,
              y: 307,
              src: '7.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: '154.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 202,
              hour_startY: 216,
              hour_array: ["digital_0.png","digital_1.png","digital_2.png","digital_3.png","digital_4.png","digital_5.png","digital_6.png","digital_7.png","digital_8.png","digital_9.png"],
              hour_zero: 0,
              hour_space: 8,
              hour_angle: 0,
              hour_unit_sc: 'digital_10.png',
              hour_unit_tc: 'digital_10.png',
              hour_unit_en: 'digital_10.png',
              hour_align: hmUI.align.RIGHT,

              minute_startX: 338,
              minute_startY: 216,
              minute_array: ["digital_0.png","digital_1.png","digital_2.png","digital_3.png","digital_4.png","digital_5.png","digital_6.png","digital_7.png","digital_8.png","digital_9.png"],
              minute_zero: 1,
              minute_space: 8,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 170,
              y: 0,
              w: 150,
              h: 65,
              src: '100.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 167,
              y: 344,
              w: 152,
              h: 62,
              src: '116.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 239,
              y: 65,
              w: 142,
              h: 66,
              src: '136.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
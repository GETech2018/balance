﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_step_circle_scale = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let normal_countdown_jumpable_img_click = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'Esfera SK3.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 240,
              // center_y: 239,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 237,
              // line_width: 42,
              // line_cap: Rounded,
              // color: 0xFF000000,
              // mirror: False,
              // inversion: True,
              // alpha: 255,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            let screenType = hmSetting.getScreenType();
            normal_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 240,
              center_y: 239,
              start_angle: 360,
              end_angle: 0,
              radius: 216,
              line_width: 42,
              corner_flag: 0,
              color: 0xFF000000,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 136,
              month_startY: 324,
              month_sc_array: ["DigS00.png","DigS01.png","DigS02.png","DigS03.png","DigS04.png","DigS05.png","DigS06.png","DigS07.png","DigS08.png","DigS09.png"],
              month_tc_array: ["DigS00.png","DigS01.png","DigS02.png","DigS03.png","DigS04.png","DigS05.png","DigS06.png","DigS07.png","DigS08.png","DigS09.png"],
              month_en_array: ["DigS00.png","DigS01.png","DigS02.png","DigS03.png","DigS04.png","DigS05.png","DigS06.png","DigS07.png","DigS08.png","DigS09.png"],
              month_zero: 0,
              month_space: 4,
              month_unit_sc: 'Icon-M.png',
              month_unit_tc: 'Icon-M.png',
              month_unit_en: 'Icon-M.png',
              month_align: hmUI.align.RIGHT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 251,
              day_startY: 324,
              day_sc_array: ["DigS00.png","DigS01.png","DigS02.png","DigS03.png","DigS04.png","DigS05.png","DigS06.png","DigS07.png","DigS08.png","DigS09.png"],
              day_tc_array: ["DigS00.png","DigS01.png","DigS02.png","DigS03.png","DigS04.png","DigS05.png","DigS06.png","DigS07.png","DigS08.png","DigS09.png"],
              day_en_array: ["DigS00.png","DigS01.png","DigS02.png","DigS03.png","DigS04.png","DigS05.png","DigS06.png","DigS07.png","DigS08.png","DigS09.png"],
              day_zero: 0,
              day_space: 6,
              day_unit_sc: 'Icon-D.png',
              day_unit_tc: 'Icon-D.png',
              day_unit_en: 'Icon-D.png',
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 143,
              y: 76,
              week_en: ["Week01.png","Week02.png","Week03.png","Week04.png","Week05.png","Week06.png","Week07.png"],
              week_tc: ["Week01.png","Week02.png","Week03.png","Week04.png","Week05.png","Week06.png","Week07.png"],
              week_sc: ["Week01.png","Week02.png","Week03.png","Week04.png","Week05.png","Week06.png","Week07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 0,
              am_y: 0,
              am_sc_path: 'PMw000.png',
              am_en_path: 'PMw000.png',
              pm_x: 66,
              pm_y: 170,
              pm_sc_path: 'PMw000.png',
              pm_en_path: 'PMw000.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 69,
              hour_startY: 197,
              hour_array: ["DigHM00.png","DigHM01.png","DigHM02.png","DigHM03.png","DigHM04.png","DigHM05.png","DigHM06.png","DigHM07.png","DigHM08.png","DigHM09.png"],
              hour_zero: 0,
              hour_space: 11,
              hour_angle: 0,
              hour_align: hmUI.align.RIGHT,

              minute_startX: 210,
              minute_startY: 196,
              minute_array: ["DigHM00.png","DigHM01.png","DigHM02.png","DigHM03.png","DigHM04.png","DigHM05.png","DigHM06.png","DigHM07.png","DigHM08.png","DigHM09.png"],
              minute_zero: 1,
              minute_space: 6,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 343,
              second_startY: 241,
              second_array: ["DigS00.png","DigS01.png","DigS02.png","DigS03.png","DigS04.png","DigS05.png","DigS06.png","DigS07.png","DigS08.png","DigS09.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 9,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              console.log('checkConnection()');
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  vibro(9);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              if (scene != 1) timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function
            console.log('Watch_Face.Shortcuts');

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 337,
              y: 200,
              w: 92,
              h: 53,
              src: 'TIMER.png',
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            function scale_call() {
              console.log('scale_call()');

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_cs_normal_step = 1 - progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_step * 100);
                  if (normal_step_circle_scale) {
                    normal_step_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 240,
                      center_y: 239,
                      start_angle: 360,
                      end_angle: 0,
                      radius: 216,
                      line_width: 42,
                      corner_flag: 0,
                      color: 0xFF000000,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                checkConnection();
                stopVibro();

              }),
              pause_call: (function () {
                console.log('pause_call()');
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
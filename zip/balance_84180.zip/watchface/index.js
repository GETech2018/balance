import * as view from "./view.js";

WatchFace({
  onInit() {
  },

  build() {
    view.buildView();
  },

  onDestroy() {
  },
})

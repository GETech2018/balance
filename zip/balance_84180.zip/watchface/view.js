import * as hmUI from "@zos/ui";
import { launchApp, SYSTEM_APP_CALENDAR, SYSTEM_APP_WORLD_CLOCK } from "@zos/router";

export function buildView() {

    console.log('in view buildview');

    hmUI.createWidget(hmUI.widget.IMG, {
        x: px(0),
        y: px(0),
        w: px(480),
        h: px(480),
        src: 'bg.png',
        show_level: hmUI.show_level.ONLY_NORMAL,
    });

    hmUI.createWidget(hmUI.widget.IMG, {
        x: px(195),
        y: px(212),
        w: px(53),
        h: px(56),
        src: 'time-colon.png',
        show_level: hmUI.show_level.ONLY_NORMAL,
    });

    hmUI.createWidget(hmUI.widget.IMG, {
        x: px(195),
        y: px(212),
        w: px(53),
        h: px(56),
        src: 'time-aod-colon.png',
        show_level: hmUI.show_level.ONLY_AOD,
    });

    const timeDigits = ['time-0.png', 'time-1.png', 'time-2.png', 'time-3.png', 'time-4.png', 'time-5.png', 'time-6.png', 'time-7.png', 'time-8.png', 'time-9.png'];
    const secDigits = ['sec-0.png', 'sec-1.png', 'sec-2.png', 'sec-3.png', 'sec-4.png', 'sec-5.png', 'sec-6.png', 'sec-7.png', 'sec-8.png', 'sec-9.png'];
    hmUI.createWidget(hmUI.widget.IMG_TIME, {
        hour_zero: 0,
        hour_startX: 80,
        hour_startY: 212,
        hour_array: timeDigits,
        hour_align: hmUI.align.RIGHT,
        hour_space: 8,
        minute_zero: 1,
        minute_startX: 246,
        minute_startY: 212,
        minute_array: timeDigits,
        minute_align: hmUI.align.RIGHT,
        minute_space: 8,
        second_zero: 1,
        second_startX: 392,
        second_startY: 218,
        second_array: secDigits,
        second_align: hmUI.align.RIGHT,
        second_space: 8,
        show_level: hmUI.show_level.ONLY_NORMAL
    });

    const timeDigitsAod = ['time-aod-0.png', 'time-aod-1.png', 'time-aod-2.png', 'time-aod-3.png', 'time-aod-4.png', 'time-aod-5.png', 'time-aod-6.png', 'time-aod-7.png', 'time-aod-8.png', 'time-aod-9.png'];
    hmUI.createWidget(hmUI.widget.IMG_TIME, {
        hour_zero: 0,
        hour_startX: 80,
        hour_startY: 212,
        hour_array: timeDigitsAod,
        hour_align: hmUI.align.RIGHT,
        hour_space: 8,
        minute_zero: 1,
        minute_startX: 246,
        minute_startY: 212,
        minute_array: timeDigitsAod,
        minute_align: hmUI.align.RIGHT,
        minute_space: 8,
        show_level: hmUI.show_level.ONLY_AOD
    });

    const weekDays = ['week-mon.png', 'week-tue.png', 'week-wed.png', 'week-thu.png', 'week-fri.png', 'week-sat.png', 'week-sun.png'];
    hmUI.createWidget(hmUI.widget.IMG_WEEK, {
        x: px(119),
        y: px(154),
        week_en: weekDays,
        show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD
    });

    const dayNumbers = ['day-0.png', 'day-1.png', 'day-2.png', 'day-3.png', 'day-4.png', 'day-5.png', 'day-6.png', 'day-7.png', 'day-8.png', 'day-9.png'];
    hmUI.createWidget(hmUI.widget.IMG_DATE, {
        day_startX: px(269),
        day_startY: px(154),
        day_align: hmUI.align.LEFT,
        day_space: 8,
        day_zero: 1,
        day_en_array: dayNumbers,
        show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
    });

    const hrNumbers = ['hr-0.png', 'hr-1.png', 'hr-2.png', 'hr-3.png', 'hr-4.png', 'hr-5.png', 'hr-6.png', 'hr-7.png', 'hr-8.png', 'hr-9.png'];
    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
        x: px(179),
        y: px(350),
        type: hmUI.data_type.HEART,
        font_array: hrNumbers,
        align_h: hmUI.align.LEFT,
        h_space: 8,
        invalid_image: 'hr-invalid.png',
        show_level: hmUI.show_level.ONLY_NORMAL,
    });

    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
        x: px(128),
        y: px(301),
        type: hmUI.data_type.WEATHER_CURRENT,
        font_array: hrNumbers,
        align_h: hmUI.align.LEFT,
        h_space: 8,
        invalid_image: 'hr-invalid.png',
        show_level: hmUI.show_level.ONLY_NORMAL,
    });

    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
        x: px(1),
        y: px(226),
        type: hmUI.data_type.COUNT_DOWN,
        font_array: hrNumbers,
        align_h: hmUI.align.CENTER_H,
        h_space: 8,
        invalid_image: 'timer-invalid.png',
        show_level: hmUI.show_level.ONLY_NORMAL
    });

    const topLeftMeters = ['meter/top-left-1.png', 'meter/top-left-2.png', 'meter/top-left-3.png', 'meter/top-left-4.png', 'meter/top-left-5.png', 'meter/top-left-6.png', 'meter/top-left-7.png', 'meter/top-left-8.png', 'meter/top-left-9.png', 'meter/top-left-10.png', 'meter/top-left-11.png', 'meter/top-left-12.png', 'meter/top-left-13.png', 'meter/top-left-14.png'];
    hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
        x: px(43),
        y: px(42),
        image_array: topLeftMeters,
        image_length: 14,
        type: hmUI.data_type.STEP,
        show_level: hmUI.show_level.ONLY_NORMAL,
    });

    const bottomLeftMeters = ['meter/bottom-left-1.png', 'meter/bottom-left-2.png', 'meter/bottom-left-3.png', 'meter/bottom-left-4.png', 'meter/bottom-left-5.png', 'meter/bottom-left-6.png', 'meter/bottom-left-7.png', 'meter/bottom-left-8.png', 'meter/bottom-left-9.png', 'meter/bottom-left-10.png', 'meter/bottom-left-11.png', 'meter/bottom-left-12.png', 'meter/bottom-left-13.png', 'meter/bottom-left-14.png'];
    hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
        x: px(43),
        y: px(283),
        image_array: bottomLeftMeters,
        image_length: 14,
        type: hmUI.data_type.FAT_BURNING,
        show_level: hmUI.show_level.ONLY_NORMAL,
    });

    const topRightMeters = ['meter/top-right-1.png', 'meter/top-right-2.png', 'meter/top-right-3.png', 'meter/top-right-4.png', 'meter/top-right-5.png', 'meter/top-right-6.png', 'meter/top-right-7.png', 'meter/top-right-8.png', 'meter/top-right-9.png', 'meter/top-right-10.png', 'meter/top-right-11.png', 'meter/top-right-12.png'];
    hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
        x: px(286),
        y: px(42),
        image_array: topRightMeters,
        image_length: 12,
        type: hmUI.data_type.STAND,
        show_level: hmUI.show_level.ONLY_NORMAL,
    });

    const batteryLevels = ['bolt-red.png', 'bolt-yellow.png', 'bolt-yellow.png', 'bolt-blue.png', 'bolt-blue.png', 'bolt-blue.png', 'bolt-blue.png', 'bolt-blue.png', 'bolt-blue.png', 'bolt-blue.png', 'bolt-blue.png', 'bolt-green.png', 'bolt-green.png', 'bolt-green.png'];
    hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
        x: px(295),
        y: px(387),
        image_array: batteryLevels,
        image_length: 14,
        type: hmUI.data_type.BATTERY,
        show_level: hmUI.show_level.ONLY_NORMAL
    });

    hmUI.createWidget(hmUI.widget.IMG_CLICK, {
        x: px(37),
        y: px(65),
        w: px(75),
        h: px(75),
        type: hmUI.data_type.STEP,
        show_level: hmUI.show_level.ONLY_NORMAL,
    });

    hmUI.createWidget(hmUI.widget.IMG_CLICK, {
        x: px(370),
        y: px(65),
        w: px(75),
        h: px(75),
        type: hmUI.data_type.STAND,
        show_level: hmUI.show_level.ONLY_NORMAL,
    });

    hmUI.createWidget(hmUI.widget.IMG_CLICK, {
        x: px(37),
        y: px(335),
        w: px(75),
        h: px(75),
        type: hmUI.data_type.FAT_BURNING,
        show_level: hmUI.show_level.ONLY_NORMAL,
    });

    hmUI.createWidget(hmUI.widget.IMG_CLICK, {
        x: px(130),
        y: px(341),
        w: px(112),
        h: px(42),
        type: hmUI.data_type.HEART,
        show_level: hmUI.show_level.ONLY_NORMAL,
    });

    hmUI.createWidget(hmUI.widget.IMG_CLICK, {
        x: px(90),
        y: px(293),
        w: px(104),
        h: px(42),
        type: hmUI.data_type.WEATHER_CURRENT,
        show_level: hmUI.show_level.ONLY_NORMAL,
    });

    hmUI.createWidget(hmUI.widget.IMG_CLICK, {
        x: px(0),
        y: px(208),
        w: px(50),
        h: px(63),
        type: hmUI.data_type.COUNT_DOWN,
        show_level: hmUI.show_level.ONLY_NORMAL,
    });

    hmUI.createWidget(hmUI.widget.IMG_CLICK, {
        x: px(277),
        y: px(377),
        w: px(75),
        h: px(75),
        type: hmUI.data_type.BATTERY,
        show_level: hmUI.show_level.ONLY_NORMAL,
    });
    
    hmUI.createWidget(hmUI.widget.BUTTON, {
        x: px(103),
        y: px(135),
        w: px(232),
        h: px(60),
        press_src: 'blank-10.png',
        normal_src: 'blank-10.png',
        text: '',
        color: 0xffff8c00,
        show_level: hmUI.show_level.ONLY_NORMAL,
        click_func: () => {
            launchApp({
                appId: SYSTEM_APP_CALENDAR,
                native: true
            });
        }
    });


    hmUI.createWidget(hmUI.widget.BUTTON, {
        x: px(78),
        y: px(203),
        w: px(292),
        h: px(75),
        press_src: 'blank-10.png',
        normal_src: 'blank-10.png',
        text: '',
        color: 0xffff8c00,
        show_level: hmUI.show_level.ONLY_NORMAL,
        click_func: () => {
            launchApp({
                appId: SYSTEM_APP_WORLD_CLOCK,
                native: true
            });
        }
    });

    hmUI.createWidget(hmUI.widget.IMG_STATUS, {
        x: px(350),
        y: px(343),
        type: hmUI.system_status.DISTURB,
        src: 'dnd-on.png',
        show_level: hmUI.show_level.ONLY_NORMAL,
    });

    hmUI.createWidget(hmUI.widget.IMG_STATUS, {
        x: px(376),
        y: px(312),
        type: hmUI.system_status.CLOCK,
        src: 'alarm-on.png',
        show_level: hmUI.show_level.ONLY_NORMAL,
    });

    hmUI.createWidget(hmUI.widget.IMG_STATUS, {
        x: px(381),
        y: px(347),
        type: hmUI.system_status.LOCK,
        src: 'lock-on.png',
        show_level: hmUI.show_level.ONLY_NORMAL,
    });
}

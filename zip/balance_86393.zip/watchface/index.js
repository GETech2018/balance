﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg = ''
        let normal_analog_clock_time_pointer_smooth_second = ''
        let normal_image_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_calorie_current_separator_img = ''
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_text_separator_img = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_step_icon_img = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_month_img = ''
        let normal_battery_icon_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_text_separator_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_date_img_date_week_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg = ''
        let idle_image_img = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_month_img = ''
        let idle_battery_text_text_img = ''
        let idle_battery_text_separator_img = ''
        let idle_battery_image_progress_img_level = ''
        let idle_date_img_date_week_img = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let normal_step_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_battery_jumpable_img_click = ''
        let normal_stand_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'H_Sefc.png',
              // center_x: 240,
              // center_y: 240,
              // x: 227,
              // y: 227,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_time_pointer_smooth_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'H_Sefc.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 227,
              second_posY: 227,
              fresh_frequency: 15,
              fresh_freqency: 15,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_smooth_second = hmUI.createWidget(hmUI.widget.SMOOTH_SECOND, {
              // type: 3,
              // fps: 15,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'WF71_.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 69,
              y: 319,
              image_array: ["Weather_37.png","Weather_38.png","Weather_39.png","Weather_40.png","Weather_41.png","Weather_42.png","Weather_43.png","Weather_44.png","Weather_45.png","Weather_46.png","Weather_47.png","Weather_48.png","Weather_49.png","Weather_50.png","Weather_51.png","Weather_52.png","Weather_53.png","Weather_54.png","Weather_55.png","Weather_56.png","Weather_57.png","Weather_58.png","Weather_59.png","Weather_60.png","Weather_61.png","Weather_62.png","Weather_63.png","Weather_64.png","Weather_65.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 42,
              y: 361,
              font_array: ["digit_01.png","digit_02.png","digit_03.png","digit_04.png","digit_05.png","digit_06.png","digit_07.png","digit_08.png","digit_09.png","digit_10.png"],
              padding: false,
              h_space: -6,
              unit_sc: 'WW_Deg.png',
              unit_tc: 'WW_Deg.png',
              unit_en: 'WW_Deg.png',
              imperial_unit_sc: 'WW_Deg.png',
              imperial_unit_tc: 'WW_Deg.png',
              imperial_unit_en: 'WW_Deg.png',
              negative_image: 'WW_Minus.png',
              invalid_image: 'WW_ERR.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const temperatureUnit = hmSetting.getTemperatureUnit();
            //#region temperatureUnit
            if (temperatureUnit == 1) {
              normal_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
                x: 42,
                y: 361,
                font_array: ["digit_01.png","digit_02.png","digit_03.png","digit_04.png","digit_05.png","digit_06.png","digit_07.png","digit_08.png","digit_09.png","digit_10.png"],
                padding: false,
                h_space: -6,
                unit_sc: 'WW_Deg.png',
                unit_tc: 'WW_Deg.png',
                unit_en: 'WW_Deg.png',
                imperial_unit_sc: 'WW_Deg.png',
                imperial_unit_tc: 'WW_Deg.png',
                imperial_unit_en: 'WW_Deg.png',
                negative_image: 'WW_Minus.png',
                invalid_image: 'WW_ERR.png',
                align_h: hmUI.align.CENTER_H,
                type: hmUI.data_type.WEATHER_CURRENT,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
            };
            //#endregion

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 341,
              y: 361,
              font_array: ["digit_01.png","digit_02.png","digit_03.png","digit_04.png","digit_05.png","digit_06.png","digit_07.png","digit_08.png","digit_09.png","digit_10.png"],
              padding: false,
              h_space: -6,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 371,
              y: 319,
              src: 'calories.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 333,
              y: 132,
              src: 'Heart_Prog_100.png',
              // alpha: 100,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_icon_img.setAlpha(100);

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 353,
              y: 258,
              font_array: ["digit_01.png","digit_02.png","digit_03.png","digit_04.png","digit_05.png","digit_06.png","digit_07.png","digit_08.png","digit_09.png","digit_10.png"],
              padding: false,
              h_space: -6,
              invalid_image: 'WW_ERR.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 370,
              y: 172,
              src: 'heart.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 333,
              y: 132,
              image_array: ["Heart_Prog_30.png","Heart_Prog_45.png","Heart_Prog_60.png","Heart_Prog_75.png","Heart_Prog_90.png","Heart_Prog_100.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 29,
              y: 132,
              src: 'progress_100.png',
              // alpha: 100,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img.setAlpha(100);

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 26,
              y: 258,
              font_array: ["digit_01.png","digit_02.png","digit_03.png","digit_04.png","digit_05.png","digit_06.png","digit_07.png","digit_08.png","digit_09.png","digit_10.png"],
              padding: false,
              h_space: -6,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 69,
              y: 172,
              src: 'sneaker.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 29,
              y: 132,
              image_array: ["progress_10.png","progress_20.png","progress_30.png","progress_40.png","progress_50.png","progress_60.png","progress_70.png","progress_80.png","progress_90.png","progress_100.png"],
              image_length: 10,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 213,
              day_startY: 386,
              day_sc_array: ["digit_01.png","digit_02.png","digit_03.png","digit_04.png","digit_05.png","digit_06.png","digit_07.png","digit_08.png","digit_09.png","digit_10.png"],
              day_tc_array: ["digit_01.png","digit_02.png","digit_03.png","digit_04.png","digit_05.png","digit_06.png","digit_07.png","digit_08.png","digit_09.png","digit_10.png"],
              day_en_array: ["digit_01.png","digit_02.png","digit_03.png","digit_04.png","digit_05.png","digit_06.png","digit_07.png","digit_08.png","digit_09.png","digit_10.png"],
              day_zero: 1,
              day_space: -6,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 205,
              month_startY: 423,
              month_sc_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_tc_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_en_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 121,
              y: 41,
              src: 'Battery_Prog_100.png',
              // alpha: 100,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img.setAlpha(100);

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 190,
              y: 72,
              font_array: ["Yellow_Dig_01.png","Yellow_Dig_02.png","Yellow_Dig_03.png","Yellow_Dig_04.png","Yellow_Dig_05.png","Yellow_Dig_06.png","Yellow_Dig_07.png","Yellow_Dig_08.png","Yellow_Dig_09.png","Yellow_Dig_10.png"],
              padding: false,
              h_space: -6,
              unit_sc: 'Percent.png',
              unit_tc: 'Percent.png',
              unit_en: 'Percent.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 160,
              y: 72,
              src: 'bolt.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 121,
              y: 41,
              image_array: ["Battery_Prog_10.png","Battery_Prog_20.png","Battery_Prog_30.png","Battery_Prog_40.png","Battery_Prog_50.png","Battery_Prog_60.png","Battery_Prog_70.png","Battery_Prog_80.png","Battery_Prog_90.png","Battery_Prog_100.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 183,
              y: 362,
              week_en: ["Day_01.png","Day_02.png","Day_03.png","Day_04.png","Day_05.png","Day_06.png","Day_07.png"],
              week_tc: ["Day_01.png","Day_02.png","Day_03.png","Day_04.png","Day_05.png","Day_06.png","Day_07.png"],
              week_sc: ["Day_01.png","Day_02.png","Day_03.png","Day_04.png","Day_05.png","Day_06.png","Day_07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 211,
              am_y: 160,
              am_sc_path: 'DT_AM.png',
              am_en_path: 'DT_AM.png',
              pm_x: 211,
              pm_y: 160,
              pm_sc_path: 'DT_PM.png',
              pm_en_path: 'DT_PM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 177,
              hour_startY: 196,
              hour_array: ["DT_digit_01.png","DT_digit_02.png","DT_digit_03.png","DT_digit_04.png","DT_digit_05.png","DT_digit_06.png","DT_digit_07.png","DT_digit_08.png","DT_digit_09.png","DT_digit_10.png"],
              hour_zero: 1,
              hour_space: -10,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 177,
              minute_startY: 280,
              minute_array: ["DT_digit_01.png","DT_digit_02.png","DT_digit_03.png","DT_digit_04.png","DT_digit_05.png","DT_digit_06.png","DT_digit_07.png","DT_digit_08.png","DT_digit_09.png","DT_digit_10.png"],
              minute_zero: 1,
              minute_space: -10,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'AOD.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 367,
              day_startY: 152,
              day_sc_array: ["digit_01.png","digit_02.png","digit_03.png","digit_04.png","digit_05.png","digit_06.png","digit_07.png","digit_08.png","digit_09.png","digit_10.png"],
              day_tc_array: ["digit_01.png","digit_02.png","digit_03.png","digit_04.png","digit_05.png","digit_06.png","digit_07.png","digit_08.png","digit_09.png","digit_10.png"],
              day_en_array: ["digit_01.png","digit_02.png","digit_03.png","digit_04.png","digit_05.png","digit_06.png","digit_07.png","digit_08.png","digit_09.png","digit_10.png"],
              day_zero: 1,
              day_space: -6,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 357,
              month_startY: 194,
              month_sc_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_tc_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_en_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 32,
              y: 258,
              font_array: ["digit_01.png","digit_02.png","digit_03.png","digit_04.png","digit_05.png","digit_06.png","digit_07.png","digit_08.png","digit_09.png","digit_10.png"],
              padding: false,
              h_space: -6,
              unit_sc: 'Percent.png',
              unit_tc: 'Percent.png',
              unit_en: 'Percent.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 69,
              y: 172,
              src: 'bolt.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 29,
              y: 132,
              image_array: ["progress_10.png","progress_20.png","progress_30.png","progress_40.png","progress_50.png","progress_60.png","progress_70.png","progress_80.png","progress_90.png","progress_100.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 335,
              y: 132,
              week_en: ["Day_01.png","Day_02.png","Day_03.png","Day_04.png","Day_05.png","Day_06.png","Day_07.png"],
              week_tc: ["Day_01.png","Day_02.png","Day_03.png","Day_04.png","Day_05.png","Day_06.png","Day_07.png"],
              week_sc: ["Day_01.png","Day_02.png","Day_03.png","Day_04.png","Day_05.png","Day_06.png","Day_07.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 211,
              am_y: 160,
              am_sc_path: 'DT_AM.png',
              am_en_path: 'DT_AM.png',
              pm_x: 211,
              pm_y: 160,
              pm_sc_path: 'DT_PM.png',
              pm_en_path: 'DT_PM.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 177,
              hour_startY: 196,
              hour_array: ["DT_digit_01.png","DT_digit_02.png","DT_digit_03.png","DT_digit_04.png","DT_digit_05.png","DT_digit_06.png","DT_digit_07.png","DT_digit_08.png","DT_digit_09.png","DT_digit_10.png"],
              hour_zero: 1,
              hour_space: -10,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 177,
              minute_startY: 280,
              minute_array: ["DT_digit_01.png","DT_digit_02.png","DT_digit_03.png","DT_digit_04.png","DT_digit_05.png","DT_digit_06.png","DT_digit_07.png","DT_digit_08.png","DT_digit_09.png","DT_digit_10.png"],
              minute_zero: 0,
              minute_space: -10,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 33,
              y: 130,
              w: 113,
              h: 113,
              src: '0_Empty.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 336,
              y: 130,
              w: 103,
              h: 103,
              src: '0_Empty.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 166,
              y: 10,
              w: 153,
              h: 103,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 190,
              y: 228,
              w: 103,
              h: 103,
              src: '0_Empty.png',
              type: hmUI.data_type.STAND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 183,
              y: 361,
              w: 113,
              h: 113,
              text: '',
              color: 0xFFFF8C00,
              text_size: 26,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 33,
              y: 309,
              w: 113,
              h: 113,
              text: '',
              color: 0xFFFF8C00,
              text_size: 26,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'WeatherScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_date_img_date_week_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_heart_rate_text_text_img = ''
        let normal_battery_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg_img = ''
        let idle_battery_text_text_img = ''
        let idle_digital_clock_img_time = ''
        let normal_step_jumpable_img_click = ''
        let normal_cal_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_battery_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 415,
              y: 185,
              src: '0082.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 385,
              y: 182,
              src: '0083.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 132,
              y: 48,
              week_en: ["week00.png","week01.png","week02.png","week03.png","week04.png","week05.png","week06.png"],
              week_tc: ["week00.png","week01.png","week02.png","week03.png","week04.png","week05.png","week06.png"],
              week_sc: ["week00.png","week01.png","week02.png","week03.png","week04.png","week05.png","week06.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 220,
              y: 13,
              image_array: ["Weather_icon_01.png","Weather_icon_02.png","Weather_icon_03.png","Weather_icon_04.png","Weather_icon_05.png","Weather_icon_06.png","Weather_icon_07.png","Weather_icon_08.png","Weather_icon_09.png","Weather_icon_10.png","Weather_icon_11.png","Weather_icon_12.png","Weather_icon_13.png","Weather_icon_14.png","Weather_icon_15.png","Weather_icon_16.png","Weather_icon_17.png","Weather_icon_18.png","Weather_icon_19.png","Weather_icon_20.png","Weather_icon_21.png","Weather_icon_22.png","Weather_icon_23.png","Weather_icon_24.png","Weather_icon_25.png","Weather_icon_26.png","Weather_icon_27.png","Weather_icon_28.png","Weather_icon_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 260,
              y: 108,
              font_array: ["step00.png","step01.png","step02.png","step03.png","step04.png","step05.png","step06.png","step07.png","step08.png","step09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'stopnie.png',
              unit_tc: 'stopnie.png',
              unit_en: 'stopnie.png',
              negative_image: 'minus.png',
              invalid_image: 'error.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 133,
              month_startY: 103,
              month_sc_array: ["month000.png","month001.png","month002.png","month003.png","month004.png","month005.png","month006.png","month007.png","month008.png","month009.png","month010.png","month011.png"],
              month_tc_array: ["month000.png","month001.png","month002.png","month003.png","month004.png","month005.png","month006.png","month007.png","month008.png","month009.png","month010.png","month011.png"],
              month_en_array: ["month000.png","month001.png","month002.png","month003.png","month004.png","month005.png","month006.png","month007.png","month008.png","month009.png","month010.png","month011.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 66,
              day_startY: 108,
              day_sc_array: ["step00.png","step01.png","step02.png","step03.png","step04.png","step05.png","step06.png","step07.png","step08.png","step09.png"],
              day_tc_array: ["step00.png","step01.png","step02.png","step03.png","step04.png","step05.png","step06.png","step07.png","step08.png","step09.png"],
              day_en_array: ["step00.png","step01.png","step02.png","step03.png","step04.png","step05.png","step06.png","step07.png","step08.png","step09.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.RIGHT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 98,
              y: 358,
              font_array: ["step00.png","step01.png","step02.png","step03.png","step04.png","step05.png","step06.png","step07.png","step08.png","step09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 302,
              y: 358,
              font_array: ["step00.png","step01.png","step02.png","step03.png","step04.png","step05.png","step06.png","step07.png","step08.png","step09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'procent.png',
              unit_tc: 'procent.png',
              unit_en: 'procent.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 174,
              y: 419,
              font_array: ["step00.png","step01.png","step02.png","step03.png","step04.png","step05.png","step06.png","step07.png","step08.png","step09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 40,
              hour_startY: 179,
              hour_array: ["hour00.png","hour01.png","hour02.png","hour03.png","hour04.png","hour05.png","hour06.png","hour07.png","hour08.png","hour09.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_unit_sc: 'dwukropek.png',
              hour_unit_tc: 'dwukropek.png',
              hour_unit_en: 'dwukropek.png',
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 231,
              minute_startY: 179,
              minute_array: ["minute00.png","minute01.png","minute02.png","minute03.png","minute04.png","minute05.png","minute06.png","minute07.png","minute08.png","minute09.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 387,
              second_startY: 250,
              second_array: ["step00.png","step01.png","step02.png","step03.png","step04.png","step05.png","step06.png","step07.png","step08.png","step09.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg_aod.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 302,
              y: 358,
              font_array: ["step00.png","step01.png","step02.png","step03.png","step04.png","step05.png","step06.png","step07.png","step08.png","step09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'procent.png',
              unit_tc: 'procent.png',
              unit_en: 'procent.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 40,
              hour_startY: 179,
              hour_array: ["hour00.png","hour01.png","hour02.png","hour03.png","hour04.png","hour05.png","hour06.png","hour07.png","hour08.png","hour09.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_unit_sc: 'dwukropek.png',
              hour_unit_tc: 'dwukropek.png',
              hour_unit_en: 'dwukropek.png',
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 231,
              minute_startY: 179,
              minute_array: ["minute00.png","minute01.png","minute02.png","minute03.png","minute04.png","minute05.png","minute06.png","minute07.png","minute08.png","minute09.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 190,
              y: 363,
              w: 107,
              h: 100,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_cal_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 378,
              y: 248,
              w: 69,
              h: 42,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 78,
              y: 310,
              w: 100,
              h: 100,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 311,
              y: 310,
              w: 100,
              h: 100,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 227,
              y: 28,
              w: 171,
              h: 124,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 377,
              y: 174,
              w: 69,
              h: 50,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
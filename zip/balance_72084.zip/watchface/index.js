try {
  (() => {
    var __$$app$$__ = __$$hmAppManager$$__.currentApp;

    var __$$module$$__ = __$$app$$__.current;
    var h = new DeviceRuntimeCore.WidgetFactory(
      new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__),
      "drink"
    );

    /*
     * huamiOS bundle tool v1.0.17
     * Copyright © Huami. All Rights Reserved
     * 天气 271F
     */
    ("use strict");

    console.log("----->>>current");
    console.log(__$$hmAppManager$$__.currentApp.pid);
    console.log(__$$hmAppManager$$__.currentApp.current);

    let dateWhiteArr = [];
    let timeArray = [];
    let weatherArr = [];
    let depleteArr = [];
    let stepArr = [];
    let humidityArr = [];
    let uviArr = [];
    let jumpLeft, jumpRight;

    __$$module$$__.module = DeviceRuntimeCore.WatchFace({
      init_view() {
        rootPath = "images/";
        for (let i = 0; i < 10; i++) {
          dateWhiteArr.push(rootPath + `dateWhite/${i}.png`);
          timeArray.push(rootPath + `timeArray/${i}.png`);
        }

        for (let i = 1; i <= 5; i++) {
          depleteArr.push(rootPath + `deplete/${i}.png`);
          stepArr.push(rootPath + `step/${i}.png`);
          humidityArr.push(rootPath + `humidity/${i}.png`);
          uviArr.push(rootPath + `uvi/${i}.png`);
        }

        for (let i = 0; i < 29; i++) {
          weatherArr.push(rootPath + `weather1/${i}.png`);
        }

        // 息屏状态
        var screenType = hmSetting.getScreenType();
        if (screenType == hmSetting.screen_type.AOD) {
          img_bg = hmUI.createWidget(hmUI.widget.IMG, {
            x: 0,
            y: 0,
            w: 480,
            h: 480,
            src: rootPath + "img/aod_bg.png",
          });
          hourPointer = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
            hour_centerX: 240,
            hour_centerY: 240,
            hour_posX: 9,
            hour_posY: 140,
            hour_path: rootPath + "img/hour.png",
          });
          minutePointer = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
            minute_centerX: 240,
            minute_centerY: 240,
            minute_posX: 9,
            minute_posY: 185,
            minute_path: rootPath + "img/min.png",
          });
        } else {
          // 亮屏状态
          img_bg = hmUI.createWidget(hmUI.widget.IMG, {
            x: 0,
            y: 0,
            w: 480,
            h: 480,
            src: rootPath + "img/bg.png",
            show_level: hmUI.show_level.ONLY_NORMAL,
          });
          //uvi
          let uviText = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
            x: 110,
            y: 61,
            type: hmUI.data_type.UVI, // 获取心率数字，自动获取
            font_array: dateWhiteArr, //心率数字图片
            invalid_image: rootPath + "dateWhite/none.png",
            h_space: 0, //数字之间的间隔
            align_h: hmUI.align.CENTER_H, //数字的对齐方式
            padding: false, //是否补零 true为补零
            isCharacter: true, //true为文字图片
            show_level: hmUI.show_level.ONLY_NORMAL,
          });
          //  心率
          let heartTxt = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
            x: 216,
            y: 104,
            type: hmUI.data_type.HEART, // 获取心率数字，自动获取
            font_array: dateWhiteArr, //心率数字图片
            h_space: 0, //数字之间的间隔
            invalid_image: rootPath + "dateWhite/none.png",
            align_h: hmUI.align.CENTER_H, //数字的对齐方式
            padding: false, //是否补零 true为补零
            isCharacter: true, //true为文字图片
            show_level: hmUI.show_level.ONLY_NORMAL,
          });
          //PAI
          let paiTxt = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
            x: 327,
            y: 61,
            type: hmUI.data_type.PAI_WEEKLY, // 获取心率数字，自动获取
            font_array: dateWhiteArr, //心率数字图片
            h_space: 0, //数字之间的间隔
            align_h: hmUI.align.CENTER_H, //数字的对齐方式
            padding: false, //是否补零 true为补零
            isCharacter: true, //true为文字图片
            show_level: hmUI.show_level.ONLY_NORMAL,
          });
          //HUMIDITY
          let humiTxt = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
            x: 92,
            y: 376,
            type: hmUI.data_type.HUMIDITY, // 获取心率数字，自动获取
            font_array: dateWhiteArr, //心率数字图片
            invalid_image: rootPath + "dateWhite/none.png",
            h_space: 0, //数字之间的间隔
            align_h: hmUI.align.CENTER_H, //数字的对齐方式
            padding: false, //是否补零 true为补零
            isCharacter: true, //true为文字图片
            unit_sc: rootPath + "dateWhite/unit_1.png",
            unit_tc: rootPath + "dateWhite/unit_1.png",
            unit_en: rootPath + "dateWhite/unit_1.png",
            show_level: hmUI.show_level.ONLY_NORMAL,
          });
          //battery
          let batteryTxt = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
            x: 318,
            y: 376,
            type: hmUI.data_type.BATTERY, // 获取心率数字，自动获取
            font_array: dateWhiteArr, //心率数字图片
            h_space: 0, //数字之间的间隔
            align_h: hmUI.align.CENTER_H, //数字的对齐方式
            padding: false, //是否补零 true为补零
            isCharacter: true, //true为文字图片
            unit_sc: rootPath + "dateWhite/unit_1.png",
            unit_tc: rootPath + "dateWhite/unit_1.png",
            unit_en: rootPath + "dateWhite/unit_1.png",
            show_level: hmUI.show_level.ONLY_NORMAL,
          });
          //weather
          let weatherIcon = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
            x: 224,
            y: 289,
            type: hmUI.data_type.WEATHER, // 获取心率数字，自动获取
            image_array: weatherArr,
            image_length: weatherArr.length,
            align_h: hmUI.align.LEFT, //数字的对齐方式
            show_level: hmUI.show_level.ONLY_NORMAL,
          });
          //温度
          let temperature = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
            x: 210,
            y: 323,
            // text:15,
            type: hmUI.data_type.WEATHER_CURRENT,
            font_array: dateWhiteArr,
            invalid_image: rootPath + "dateWhite/none.png",
            h_space: 0,
            align_h: hmUI.align.CENTER_H, //数字的对齐方式
            padding: false, //是否补零unit_1
            isCharacter: true,
            unit_sc: rootPath + "dateWhite/unit_0.png",
            unit_tc: rootPath + "dateWhite/unit_0.png",
            unit_en: rootPath + "dateWhite/unit_0.png",
            negative_image: rootPath + "dateWhite/fuhao.png",
            show_level: hmUI.show_level.ONLY_NORMAL,
          });
          //deplete
          depleteBg = hmUI.createWidget(hmUI.widget.IMG, {
            x: 71,
            y: 176,
            w: 152,
            h: 152,
            show_level: hmUI.show_level.ONLY_NORMAL,
          });

          depleteLevel = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
            x: 71,
            y: 176,
            w: 136,
            h: 136,
            // type: hmUI.data_type.CAL,
            // image_array: depleteArr,
            image_length: 5,
          });

          depleteIcon = hmUI.createWidget(hmUI.widget.IMG, {
            x: 120,
            y: 198,
            src: rootPath + "img/deplete.png",
            show_level: hmUI.show_level.ONLY_NORMAL,
          });

          depleteText = hmUI.createWidget(hmUI.widget.TEXT_IMG, {});

          function left_chart(bg_src, icon_src) {
            return [
              {
                src: bg_src,
                show_level: hmUI.show_level.ONLY_NORMAL,
              },
              {
                src: icon_src,
                show_level: hmUI.show_level.ONLY_NORMAL,
              },
            ];
          }

          //step
          stepBg = hmUI.createWidget(hmUI.widget.IMG, {
            x: 283,
            y: 176,
            w: 152,
            h: 152,
            src: rootPath + "img/2.png",
            show_level: hmUI.show_level.ONLY_NORMAL,
          });
          stepLevel = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
            x: 283,
            y: 176,
            w: 136,
            h: 136,
            // type: hmUI.data_type.STEP,
            // image_array: stepArr,
            image_length: 5,
          });

          stepIcon = hmUI.createWidget(hmUI.widget.IMG, {
            x: 333,
            y: 198,
            src: rootPath + "img/step.png",
            show_level: hmUI.show_level.ONLY_NORMAL,
          });
          stepText = hmUI.createWidget(hmUI.widget.TEXT_IMG, {});

          function right_chart(bg_src, icon_src) {
            return [
              {
                src: bg_src,
                show_level: hmUI.show_level.ONLY_NORMAL,
              },
              {
                src: icon_src,
                show_level: hmUI.show_level.ONLY_NORMAL,
              },
            ];
          }

          //timepointer

          hourPointer = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
            hour_centerX: 240,
            hour_centerY: 240,
            hour_posX: 9,
            hour_posY: 140,
            hour_path: rootPath + "img/hour.png",
            show_level: hmUI.show_level.ONLY_NORMAL,
          });
          minutePointer = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
            minute_centerX: 240,
            minute_centerY: 240,
            minute_posX: 9,
            minute_posY: 185,
            minute_path: rootPath + "img/min.png",
            show_level: hmUI.show_level.ONLY_NORMAL,
          });
          let img_cover = hmUI.createWidget(hmUI.widget.IMG, {
            x: 230,
            y: 230,
            w: 23,
            h: 23,
            src: rootPath + "img/img/center.png",
            show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONAL_AOD,
          });
          //clock
          let clock = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
            x: 225.22,
            y: 25.41,
            type: hmUI.system_status.CLOCK,
            src: rootPath + "img/clock.png",
          });
          //disconnect
          let disconnect = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
            x: 225,
            y: 426,
            type: hmUI.system_status.DISCONNECT,
            src: rootPath + "img/disconnect.png",
          });

          //可编辑组件
          let widgetOptionalArray = [
            {
              type: hmUI.edit_type.PAI_WEEKLY,
              preview: rootPath + "/previews/Slice57.png",
            },
            {
              type: hmUI.edit_type.STEP,
              preview: rootPath + "/previews/Slice58.png",
            },
            {
              type: hmUI.edit_type.HUMIDITY,
              preview: rootPath + "/previews/Slice59.png",
            },
            {
              type: hmUI.edit_type.CAL,
              preview: rootPath + "/previews/Slice63.png",
            },
            {
              type: hmUI.edit_type.TEMPERATURE,
              preview: rootPath + "/previews/Slice64.png",
            },
            {
              type: hmUI.edit_type.BATTERY,
              preview: rootPath + "/previews/Slice65.png",
            },
            // { type: hmUI.edit_type.AQI, preview: rootPath + '/previews/Slice52.png' },
            {
              type: hmUI.edit_type.UVI,
              preview: rootPath + "/previews/Slice61.png",
            },
          ];

          let edit_list_config = {
            title_font_size: 34,
            title_align_h: hmUI.align.CENTER_H,
            list_item_vspace: 8,
            list_bg_color: 0x0000,
            list_bg_radius: 30,
            list_group_text_font_size: 32,
            list_group_text_align_h: hmUI.align.CENTER_H,
            list_tips_text_font_size: 32,
            list_tips_text_align_h: hmUI.align.LEFT,
          };

          let left_groupX = 59;
          let left_groupY = 166;
          let left_Widget = hmUI.createWidget(
            hmUI.widget.WATCHFACE_EDIT_GROUP,
            {
              edit_id: 101,
              x: left_groupX,
              y: left_groupY,
              w: 152,
              h: 152,
              select_image: rootPath + "/img/select.png",
              un_select_image: rootPath + "/img/unselect.png",
              default_type: hmUI.edit_type.CAL,
              optional_types: widgetOptionalArray,
              count: widgetOptionalArray.length,
              tips_BG: rootPath + "/edit/widget_tips.png",
              tips_x: 23,
              tips_y: -46,
              tips_width: 104,
              tips_margin: 10,
              select_list: edit_list_config,
            }
          );
          let typeLeft = left_Widget.getProperty(hmUI.prop.CURRENT_TYPE);
          let toggle = null;
          switch (typeLeft) {
            case hmUI.edit_type.PAI_WEEKLY:
              jumpLeft = hmUI.data_type.PAI_WEEKLY;
              toggle = left_chart(
                rootPath + "img/2.png",
                rootPath + "edit_icon/pai.png"
              );
              depleteBg.setProperty(hmUI.prop.MORE, toggle[0]);
              // depleteLevel.setProperty(hmUI.prop.MORE, toggle[1]);
              depleteLevel.setProperty(hmUI.prop.MORE, {
                x: 71,
                y: 177,
                w: 136,
                h: 136,
                type: hmUI.data_type.PAI_WEEKLY,
                image_array: stepArr,
                image_length: stepArr.length,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              depleteIcon.setProperty(hmUI.prop.MORE, toggle[1]);
              depleteText.setProperty(hmUI.prop.MORE, {
                type: hmUI.data_type.PAI_WEEKLY,
                align_h: hmUI.align.CENTER_H,
                x: 111,
                y: 232,
                font_array: dateWhiteArr,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              break;
            case hmUI.edit_type.STEP:
              jumpLeft = hmUI.data_type.STEP;
              toggle = left_chart(
                rootPath + "img/2.png",
                rootPath + "edit_icon/step.png"
              );
              depleteBg.setProperty(hmUI.prop.MORE, toggle[0]);
              // depleteLevel.setProperty(hmUI.prop.MORE, toggle[1]);
              depleteLevel.setProperty(hmUI.prop.MORE, {
                x: 71,
                y: 177,
                w: 136,
                h: 136,
                image_array: stepArr,
                image_length: 5,
                type: hmUI.data_type.STEP,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              depleteIcon.setProperty(hmUI.prop.MORE, toggle[1]);
              depleteText.setProperty(hmUI.prop.MORE, {
                type: hmUI.data_type.STEP,
                align_h: hmUI.align.CENTER_H,
                x: 92,
                y: 232,
                font_array: dateWhiteArr,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              break;
            case hmUI.edit_type.CAL:
              jumpLeft = hmUI.data_type.CAL;
              toggle = left_chart(
                rootPath + "img/1.png",
                rootPath + "edit_icon/CAL.png"
              );
              depleteBg.setProperty(hmUI.prop.MORE, toggle[0]);
              // depleteLevel.setProperty(hmUI.prop.MORE, toggle[1]);
              depleteLevel.setProperty(hmUI.prop.MORE, {
                x: 71,
                y: 177,
                w: 136,
                h: 136,
                type: hmUI.data_type.CAL,
                image_array: depleteArr,
                image_length: depleteArr.length,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              depleteIcon.setProperty(hmUI.prop.MORE, toggle[1]);
              depleteText.setProperty(hmUI.prop.MORE, {
                type: hmUI.data_type.CAL,
                align_h: hmUI.align.CENTER_H,
                invalid_image: rootPath + "dateWhite/none.png",
                font_array: dateWhiteArr,
                x: 101,
                y: 232,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              break;
            case hmUI.edit_type.TEMPERATURE:
              jumpLeft = hmUI.data_type.WEATHER;
              toggle = left_chart(
                rootPath + "img/1.png",
                rootPath + "edit_icon/TEMPERATURE.png"
              );
              depleteBg.setProperty(hmUI.prop.MORE, toggle[0]);
              // depleteLevel.setProperty(hmUI.prop.MORE, toggle[1]);
              depleteLevel.setProperty(hmUI.prop.MORE, {
                x: 71,
                y: 177,
                w: 136,
                h: 136,
                // type: hmUI.data_type.TEMPERATURE,
                type: hmUI.data_type.WEATHER_CURRENT,
                image_array: depleteArr,
                image_length: depleteArr.length,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              depleteIcon.setProperty(hmUI.prop.MORE, toggle[1]);
              depleteText.setProperty(hmUI.prop.MORE, {
                type: hmUI.data_type.WEATHER_CURRENT,
                font_array: dateWhiteArr,
                invalid_image: rootPath + "dateWhite/none.png",
                unit_sc: rootPath + "dateWhite/unit_0.png",
                unit_tc: rootPath + "dateWhite/unit_0.png",
                unit_en: rootPath + "dateWhite/unit_0.png",
                negative_image: rootPath + "dateWhite/fuhao.png",
                align_h: hmUI.align.CENTER_H,
                x: 105,
                y: 232,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              break;
            case hmUI.edit_type.BATTERY:
              jumpLeft = hmUI.data_type.BATTERY;
              toggle = left_chart(
                rootPath + "img/1.png",
                rootPath + "edit_icon/battery.png"
              );
              depleteBg.setProperty(hmUI.prop.MORE, toggle[0]);
              // depleteLevel.setProperty(hmUI.prop.MORE, toggle[1]);
              depleteLevel.setProperty(hmUI.prop.MORE, {
                x: 71,
                y: 177,
                w: 136,
                h: 136,
                type: hmUI.data_type.BATTERY,
                image_array: depleteArr,
                image_length: depleteArr.length,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              depleteIcon.setProperty(hmUI.prop.MORE, toggle[1]);
              depleteText.setProperty(hmUI.prop.MORE, {
                type: hmUI.data_type.BATTERY,
                font_array: dateWhiteArr,
                unit_sc: rootPath + "dateWhite/unit_1.png",
                unit_tc: rootPath + "dateWhite/unit_1.png",
                unit_en: rootPath + "dateWhite/unit_1.png",
                align_h: hmUI.align.CENTER_H,
                x: 102,
                y: 231,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              break;
            case hmUI.edit_type.HUMIDITY:
              jumpLeft = hmUI.data_type.HUMIDITY;
              toggle = left_chart(
                rootPath + "img/3.png",
                rootPath + "edit_icon/HUMIDITY.png"
              );
              depleteBg.setProperty(hmUI.prop.MORE, toggle[0]);
              // depleteLevel.setProperty(hmUI.prop.MORE, toggle[1]);
              depleteLevel.setProperty(hmUI.prop.MORE, {
                x: 71,
                y: 177,
                w: 136,
                h: 136,
                type: hmUI.data_type.HUMIDITY,
      
                image_array: humidityArr,
                image_length: humidityArr.length,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              depleteIcon.setProperty(hmUI.prop.MORE, toggle[1]);
              depleteText.setProperty(hmUI.prop.MORE, {
                type: hmUI.data_type.HUMIDITY,
                font_array: dateWhiteArr,
                unit_sc: rootPath + "dateWhite/unit_1.png",
                unit_tc: rootPath + "dateWhite/unit_1.png",
                unit_en: rootPath + "dateWhite/unit_1.png",
                invalid_image: rootPath + "dateWhite/none.png",
                align_h: hmUI.align.CENTER_H,
                x: 99,
                y: 232,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              break;
            case hmUI.edit_type.UVI:
              jumpLeft = hmUI.data_type.UVI;
              toggle = left_chart(
                rootPath + "img/4.png",
                rootPath + "edit_icon/UVI.png"
              );
              depleteBg.setProperty(hmUI.prop.MORE, toggle[0]);
              depleteLevel.setProperty(hmUI.prop.MORE, {
                x: 71,
                y: 177,
                w: 136,
                h: 136,
                type: hmUI.data_type.UVI,
                image_array: uviArr,
                image_length: uviArr.length,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              depleteIcon.setProperty(hmUI.prop.MORE, toggle[1]);
              depleteText.setProperty(hmUI.prop.MORE, {
                type: hmUI.data_type.UVI,
                invalid_image: rootPath + "dateWhite/none.png",
                font_array: dateWhiteArr,
                align_h: hmUI.align.CENTER_H,
                x: 119,
                y: 232,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              break;
            // case hmUI.edit_type.AQI:
            //     toggle = left_chart(rootPath + "img/4.png", rootPath + "edit_icon/AQI.png")
            //     depleteBg.setProperty(hmUI.prop.MORE, toggle[0]);
            //     // depleteLevel.setProperty(hmUI.prop.MORE, toggle[1]);
            //     depleteLevel.setProperty(hmUI.prop.MORE, {
            //         x: 66,
            //         y: 172,
            //         w: 136,
            //         h: 136,
            //         type: hmUI.data_type.AQI,
            //         image_array: uviArr,
            //         image_length: uviArr.length,
            //         show_level: hmUI.show_level.ONLY_NORMAL
            //     });
            //     depleteIcon.setProperty(hmUI.prop.MORE, toggle[1]);
            //     depleteText.setProperty(hmUI.prop.MORE, {
            //         type: hmUI.data_type.AQI,
            //         invalid_image: rootPath + "dateWhite/none.png",
            //         align_h: hmUI.align.CENTER_H,
            //         font_array: dateWhiteArr,
            //         x: 102.93,
            //         y: 232,
            //         show_level: hmUI.show_level.ONLY_NORMAL
            //     });
            //     break;
          }

          let right_groupX = 275;
          let right_groupY = 166;
          let right_Widget = hmUI.createWidget(
            hmUI.widget.WATCHFACE_EDIT_GROUP,
            {
              edit_id: 102,
              x: right_groupX,
              y: right_groupY,
              w: 152,
              h: 152,
              select_image: rootPath + "/img/select.png",
              un_select_image: rootPath + "/img/unselect.png",
              default_type: hmUI.edit_type.STEP,
              optional_types: widgetOptionalArray,
              count: widgetOptionalArray.length,
              tips_BG: rootPath + "/edit/widget_tips.png",
              tips_x: 23,
              tips_y: -46,
              tips_width: 104,
              tips_margin: 10,
              select_list: edit_list_config,
            }
          );
          let typeRight = right_Widget.getProperty(hmUI.prop.CURRENT_TYPE);
          let toggle_right = null;
          switch (typeRight) {
            case hmUI.edit_type.PAI_WEEKLY:
              jumpRight = hmUI.data_type.PAI_WEEKLY;
              toggle_right = right_chart(
                rootPath + "img/2.png",
                rootPath + "edit_icon/pai.png"
              );
              stepBg.setProperty(hmUI.prop.MORE, toggle_right[0]);
              // stepLevel.setProperty(hmUI.prop.MORE, toggle_right[1]);
              stepLevel.setProperty(hmUI.prop.MORE, {
                x: 283,
                y: 177,
                w: 136,
                h: 136,
                type: hmUI.data_type.PAI_WEEKLY,
                image_array: stepArr,
                image_length: stepArr.length,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              stepIcon.setProperty(hmUI.prop.MORE, toggle_right[1]);
              stepText.setProperty(hmUI.prop.MORE, {
                type: hmUI.data_type.PAI_WEEKLY,
                align_h: hmUI.align.CENTER_H,
                font_array: dateWhiteArr,
                x: 323,
                y: 232.05,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              break;
            case hmUI.edit_type.STEP:
              jumpRight = hmUI.data_type.STEP;
              toggle_right = right_chart(
                rootPath + "img/2.png",
                rootPath + "edit_icon/step.png"
              );
              stepBg.setProperty(hmUI.prop.MORE, toggle_right[0]);
              // stepLevel.setProperty(hmUI.prop.MORE, toggle_right[1]);
              stepLevel.setProperty(hmUI.prop.MORE, {
                x: 283,
                y: 177,
                w: 136,
                h: 136,
                type: hmUI.data_type.STEP,
                image_array: stepArr,
                image_length: stepArr.length,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              stepIcon.setProperty(hmUI.prop.MORE, toggle_right[1]);
              stepText.setProperty(hmUI.prop.MORE, {
                type: hmUI.data_type.STEP,
                align_h: hmUI.align.CENTER_H,
                font_array: dateWhiteArr,
                x: 306,
                y: 232.05,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              break;
            case hmUI.edit_type.CAL:
              jumpRight = hmUI.data_type.CAL;
              toggle_right = right_chart(
                rootPath + "img/1.png",
                rootPath + "edit_icon/CAL.png"
              );
              stepBg.setProperty(hmUI.prop.MORE, toggle_right[0]);
              // stepLevel.setProperty(hmUI.prop.MORE, toggle_right[1]);
              stepLevel.setProperty(hmUI.prop.MORE, {
                x: 283,
                y: 177,
                w: 136,
                h: 136,
                type: hmUI.data_type.CAL,
                image_array: depleteArr,
                image_length: depleteArr.length,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              stepIcon.setProperty(hmUI.prop.MORE, toggle_right[1]);
              stepText.setProperty(hmUI.prop.MORE, {
                type: hmUI.data_type.CAL,
                invalid_image: rootPath + "dateWhite/none.png",
                align_h: hmUI.align.CENTER_H,
                font_array: dateWhiteArr,
                x: 314,
                y: 232.05,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              break;
            case hmUI.edit_type.TEMPERATURE:
              jumpRight = hmUI.data_type.WEATHER;
              toggle_right = right_chart(
                rootPath + "img/1.png",
                rootPath + "edit_icon/TEMPERATURE.png"
              );
              stepBg.setProperty(hmUI.prop.MORE, toggle_right[0]);
              // stepLevel.setProperty(hmUI.prop.MORE, toggle_right[1]);
              stepLevel.setProperty(hmUI.prop.MORE, {
                x: 283,
                y: 177,
                w: 136,
                h: 136,
                type: hmUI.data_type.WEATHER_CURRENT,
                image_array: depleteArr,
                image_length: depleteArr.length,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              stepIcon.setProperty(hmUI.prop.MORE, toggle_right[1]);
              stepText.setProperty(hmUI.prop.MORE, {
                type: hmUI.data_type.WEATHER_CURRENT,
                font_array: dateWhiteArr,
                unit_sc: rootPath + "dateWhite/unit_0.png",
                unit_tc: rootPath + "dateWhite/unit_0.png",
                unit_en: rootPath + "dateWhite/unit_0.png",
                invalid_image: rootPath + "dateWhite/none.png",
                negative_image: rootPath + "dateWhite/fuhao.png",
                align_h: hmUI.align.CENTER_H,
                x: 319,
                y: 232.05,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              break;
            case hmUI.edit_type.BATTERY:
              jumpRight = hmUI.data_type.BATTERY;
              toggle_right = right_chart(
                rootPath + "img/1.png",
                rootPath + "edit_icon/battery.png"
              );
              stepBg.setProperty(hmUI.prop.MORE, toggle_right[0]);
              // stepLevel.setProperty(hmUI.prop.MORE, toggle_right[1]);
              stepLevel.setProperty(hmUI.prop.MORE, {
                x: 283,
                y: 177,
                w: 136,
                h: 136,
                type: hmUI.data_type.BATTERY,
                image_array: depleteArr,
                image_length: depleteArr.length,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              stepIcon.setProperty(hmUI.prop.MORE, toggle_right[1]);
              stepText.setProperty(hmUI.prop.MORE, {
                type: hmUI.data_type.BATTERY,
                font_array: dateWhiteArr,
                unit_sc: rootPath + "dateWhite/unit_1.png",
                unit_tc: rootPath + "dateWhite/unit_1.png",
                unit_en: rootPath + "dateWhite/unit_1.png",
                align_h: hmUI.align.CENTER_H,
                x: 316,
                y: 232.05,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              break;
            case hmUI.edit_type.HUMIDITY:
              jumpRight = hmUI.data_type.HUMIDITY;
              toggle_right = right_chart(
                rootPath + "img/3.png",
                rootPath + "edit_icon/HUMIDITY.png"
              );
              stepBg.setProperty(hmUI.prop.MORE, toggle_right[0]);
              // stepLevel.setProperty(hmUI.prop.MORE, toggle_right[1]);
              stepLevel.setProperty(hmUI.prop.MORE, {
                x: 283,
                y: 177,
                w: 136,
                h: 136,
                type: hmUI.data_type.HUMIDITY,
                image_array: humidityArr,
                image_length: humidityArr.length,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              stepIcon.setProperty(hmUI.prop.MORE, toggle_right[1]);
              stepText.setProperty(hmUI.prop.MORE, {
                type: hmUI.data_type.HUMIDITY,
                font_array: dateWhiteArr,
                invalid_image: rootPath + "dateWhite/none.png",
                align_h: hmUI.align.CENTER_H,
                unit_sc: rootPath + "dateWhite/unit_1.png",
                unit_tc: rootPath + "dateWhite/unit_1.png",
                unit_en: rootPath + "dateWhite/unit_1.png",
                x: 313,
                y: 232.05,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              break;
            case hmUI.edit_type.UVI:
              jumpRight = hmUI.data_type.UVI;
              toggle_right = right_chart(
                rootPath + "img/4.png",
                rootPath + "edit_icon/UVI.png"
              );
              stepBg.setProperty(hmUI.prop.MORE, toggle_right[0]);
              // stepLevel.setProperty(hmUI.prop.MORE, toggle_right[1]);
              stepLevel.setProperty(hmUI.prop.MORE, {
                x: 283,
                y: 177,
                w: 136,
                h: 136,
                type: hmUI.data_type.UVI,
                image_array: uviArr,
                image_length: uviArr.length,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              stepIcon.setProperty(hmUI.prop.MORE, toggle_right[1]);
              stepText.setProperty(hmUI.prop.MORE, {
                type: hmUI.data_type.UVI,
                font_array: dateWhiteArr,
                invalid_image: rootPath + "dateWhite/none.png",
                align_h: hmUI.align.CENTER_H,
                x: 332,
                y: 232.05,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              break;
            // case hmUI.edit_type.AQI:
            //     toggle_right = right_chart(rootPath + "img/4.png", rootPath + "edit_icon/AQI.png")
            //     stepBg.setProperty(hmUI.prop.MORE, toggle_right[0]);
            //     // stepLevel.setProperty(hmUI.prop.MORE, toggle_right[1]);
            //     stepLevel.setProperty(hmUI.prop.MORE, {
            //         x: 279,
            //         y: 172,
            //         w: 136,
            //         h: 136,
            //         type: hmUI.data_type.AQI,
            //         image_array: uviArr,
            //         image_length: uviArr.length,
            //         show_level: hmUI.show_level.ONLY_NORMAL
            //     });
            //     stepIcon.setProperty(hmUI.prop.MORE, toggle_right[1]);
            //     stepText.setProperty(hmUI.prop.MORE, {
            //         type: hmUI.data_type.AQI,
            //         font_array: dateWhiteArr,
            //         invalid_image: rootPath + "dateWhite/none.png",
            //         align_h: hmUI.align.CENTER_H,
            //         x: 320,
            //         y: 232.05,
            //         show_level: hmUI.show_level.ONLY_NORMAL
            //     });
            //     break;
          }
          maskCover = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_MASK, {
            x: 0,
            y: 0,
            w: 480,
            h: 480,
            src: rootPath + "mask/mask100.png",
            show_level: hmUI.show_level.ONLY_EDIT,
          });

          mask = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_FG_MASK, {
            x: 0,
            y: 0,
            w: 480,
            h: 480,
            src: rootPath + "mask/mask70.png",
            show_level: hmUI.show_level.ONLY_EDIT,
          });

          hmUI.createWidget(hmUI.widget.IMG_CLICK, {
            x: 215,
            y: 16,
            w: 49,
            h: 44,
            type: hmUI.data_type.ALARM_CLOCK, //闹钟
          });

          hmUI.createWidget(hmUI.widget.IMG_CLICK, {
            x: 335,
            y: 66,
            w: 38,
            h: 65,
            type: hmUI.data_type.PAI_WEEKLY, //PAI480
          });
          hmUI.createWidget(hmUI.widget.IMG_CLICK, {
            x: 223,
            y: 107,
            w: 38,
            h: 85,
            type: hmUI.data_type.HEART, //心率
          });

          hmUI.createWidget(hmUI.widget.IMG_CLICK, {
            x: 218,
            y: 289,
            w: 46,
            h: 75,
            type: hmUI.data_type.WEATHER, //天气
          });

          hmUI.createWidget(hmUI.widget.IMG_CLICK, {
            x: 92,
            y: 350,
            w: 46,
            h: 75,
            type: hmUI.data_type.HUMIDITY, //湿度
          });

          hmUI.createWidget(hmUI.widget.IMG_CLICK, {
            x: 218,
            y: 423,
            w: 45,
            h: 37,
            type: hmUI.data_type.DISCONNECT, //蓝牙
          });

          hmUI.createWidget(hmUI.widget.IMG_CLICK, {
            x: 61,
            y: 171,
            w: 142,
            h: 137,
            type: jumpLeft, //可编辑左
          });

          hmUI.createWidget(hmUI.widget.IMG_CLICK, {
            x: 277,
            y: 171,
            w: 142,
            h: 137,
            type: jumpRight, //可编辑右
          });
          hmUI.createWidget(hmUI.widget.IMG_CLICK, {
            x: 109,
            y: 66,
            w: 38,
            h: 65,
            type: hmUI.data_type.UVI, //闹钟
          });
        }
      },

      onInit() {
        console.log("index page.js on init invoke");
        this.init_view();
      },

      onReady() {
        console.log("index page.js on ready invoke");
      },

      onShow() {
        console.log("index page.js on show invoke");
      },

      onHide() {
        console.log("index page.js on hide invoke");
      },

      onDestory() {
        console.log("index page.js on destory invoke");
      },
    });
    /*
     * end js
     */
  })();
} catch (e) {
  console.log(e);
}

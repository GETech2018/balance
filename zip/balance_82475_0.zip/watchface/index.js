﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_dnd_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_step_icon_img = ''
        let normal_step_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_high_text_img = ''
        let normal_temperature_low_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_battery_TextRotate = new Array(3);
        let normal_battery_TextRotate_ASCIIARRAY = new Array(10);
        let normal_battery_TextRotate_img_width = 21;
        let normal_battery_icon_img = ''
        let normal_day_TextRotate = new Array(2);
        let normal_day_TextRotate_ASCIIARRAY = new Array(10);
        let normal_day_TextRotate_img_width = 16;
        let normal_timerTextUpdate = undefined;
        let normal_date_img_date_week_img = ''
        let normal_analog_clock_pro_hour_pointer_img = ''
        let normal_analog_clock_pro_minute_pointer_img = ''
        let normal_timerUpdateSec = undefined;
        let normal_analog_clock_time_pointer_smooth_second = ''
        let idle_analog_clock_pro_hour_pointer_img = ''
        let idle_analog_clock_pro_minute_pointer_img = ''
        let timeSensor = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'back.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 255,
              y: 280,
              src: 'DND.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 225,
              y: 283,
              src: 'bt_off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 196,
              y: 283,
              src: 'alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 67,
              y: 242,
              src: 'i_bpm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 115,
              y: 245,
              font_array: ["nD.0000.png","nD.0001.png","nD.0002.png","nD.0003.png","nD.0004.png","nD.0005.png","nD.0006.png","nD.0007.png","nD.0008.png","nD.0009.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 66,
              y: 202,
              src: 'i_steps.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 112,
              y: 208,
              font_array: ["nD.0000.png","nD.0001.png","nD.0002.png","nD.0003.png","nD.0004.png","nD.0005.png","nD.0006.png","nD.0007.png","nD.0008.png","nD.0009.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 202,
              y: 74,
              image_array: ["0111.png","0112.png","0113.png","0114.png","0115.png","0116.png","0117.png","0118.png","0119.png","0120.png","0121.png","0122.png","0123.png","0124.png","0125.png","0126.png","0127.png","0128.png","0129.png","0130.png","0131.png","0132.png","0133.png","0134.png","0135.png","0136.png","0137.png","0138.png","0139.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 278,
              y: 99,
              font_array: ["nB.0000.png","nB.0001.png","nB.0002.png","nB.0003.png","nB.0004.png","nB.0005.png","nB.0006.png","nB.0007.png","nB.0008.png","nB.0009.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'sm_temp.png',
              unit_tc: 'sm_temp.png',
              unit_en: 'sm_temp.png',
              negative_image: 'sm_minus.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 129,
              y: 99,
              font_array: ["nB.0000.png","nB.0001.png","nB.0002.png","nB.0003.png","nB.0004.png","nB.0005.png","nB.0006.png","nB.0007.png","nB.0008.png","nB.0009.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'sm_temp.png',
              unit_tc: 'sm_temp.png',
              unit_en: 'sm_temp.png',
              negative_image: 'sm_minus.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 208,
              y: 150,
              font_array: ["nB.0000.png","nB.0001.png","nB.0002.png","nB.0003.png","nB.0004.png","nB.0005.png","nB.0006.png","nB.0007.png","nB.0008.png","nB.0009.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'sm_temp.png',
              unit_tc: 'sm_temp.png',
              unit_en: 'sm_temp.png',
              negative_image: 'sm_minus.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_battery_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 369,
              // y: 248,
              // font_array: ["nB.0000.png","nB.0001.png","nB.0002.png","nB.0003.png","nB.0004.png","nB.0005.png","nB.0006.png","nB.0007.png","nB.0008.png","nB.0009.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: 0,
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_battery_TextRotate_ASCIIARRAY[0] = 'nB.0000.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[1] = 'nB.0001.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[2] = 'nB.0002.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[3] = 'nB.0003.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[4] = 'nB.0004.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[5] = 'nB.0005.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[6] = 'nB.0006.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[7] = 'nB.0007.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[8] = 'nB.0008.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[9] = 'nB.0009.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 3; i++) {
              normal_battery_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 369,
                center_y: 248,
                pos_x: 369,
                pos_y: 248,
                angle: 0,
                src: 'nB.0000.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_battery_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 355,
              y: 207,
              src: 'i_batt.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_day_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 240,
              // y: 358,
              // font_array: ["nD.0000.png","nD.0001.png","nD.0002.png","nD.0003.png","nD.0004.png","nD.0005.png","nD.0006.png","nD.0007.png","nD.0008.png","nD.0009.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: 0,
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.DAY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_day_TextRotate_ASCIIARRAY[0] = 'nD.0000.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[1] = 'nD.0001.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[2] = 'nD.0002.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[3] = 'nD.0003.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[4] = 'nD.0004.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[5] = 'nD.0005.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[6] = 'nD.0006.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[7] = 'nD.0007.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[8] = 'nD.0008.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[9] = 'nD.0009.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              normal_day_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 240,
                center_y: 358,
                pos_x: 240,
                pos_y: 358,
                angle: 0,
                src: 'nD.0000.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_day_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            let screenType = hmSetting.getScreenType();
            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 204,
              y: 317,
              week_en: ["d.0001.png","d.0002.png","d.0003.png","d.0004.png","d.0005.png","d.0006.png","d.0007.png"],
              week_tc: ["d.0001.png","d.0002.png","d.0003.png","d.0004.png","d.0005.png","d.0006.png","d.0007.png"],
              week_sc: ["d.0001.png","d.0002.png","d.0003.png","d.0004.png","d.0005.png","d.0006.png","d.0007.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const deviceInfo = hmSetting.getDeviceInfo();
            timeSensor.addEventListener(timeSensor.event.MINUTEEND, function() {
              let updateHour = timeSensor.minute == 0;

              time_update(UpdateHour, true);
            });

            // normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'pt.hor.png',
              // center_x: 239,
              // center_y: 239,
              // x: 13,
              // y: 238,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.hour,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 239 - 13,
              pos_y: 239 - 238,
              center_x: 239,
              center_y: 239,
              src: 'pt.hor.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'pt.min.png',
              // center_x: 239,
              // center_y: 239,
              // x: 13,
              // y: 239,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.minute,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 239 - 13,
              pos_y: 239 - 239,
              center_x: 239,
              center_y: 239,
              src: 'pt.min.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'pt.sec.png',
              // center_x: 239,
              // center_y: 239,
              // x: 13,
              // y: 238,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_time_pointer_smooth_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'pt.sec.png',
              second_centerX: 239,
              second_centerY: 239,
              second_posX: 13,
              second_posY: 238,
              fresh_frequency: 15,
              fresh_freqency: 15,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_smooth_second = hmUI.createWidget(hmUI.widget.SMOOTH_SECOND, {
              // type: 3,
              // fps: 15,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });



            console.log('Watch_Face.ScreenAOD');

            // idle_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'pt.hor.png',
              // center_x: 239,
              // center_y: 239,
              // x: 13,
              // y: 238,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.hour,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });


            idle_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 239 - 13,
              pos_y: 239 - 238,
              center_x: 239,
              center_y: 239,
              src: 'pt.hor.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'pt.min.png',
              // center_x: 239,
              // center_y: 239,
              // x: 13,
              // y: 239,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.minute,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });


            idle_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 239 - 13,
              pos_y: 239 - 239,
              center_x: 239,
              center_y: 239,
              src: 'pt.min.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            //start of ignored block
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              if (updateHour) {
                let normal_hour = hour;
                let normal_fullAngle_hour = 360;
                if (normal_hour > 11) normal_hour -= 12;
                let normal_angle_hour = 0 + normal_fullAngle_hour*normal_hour/12 + (normal_fullAngle_hour/12)*minute/60;
                if (normal_analog_clock_pro_hour_pointer_img) normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_hour);
              };

              if (updateMinute) {
                let normal_fullAngle_minute = 360;
                let normal_angle_minute = 0 + normal_fullAngle_minute*(minute + second/60)/60;
                if (normal_analog_clock_pro_minute_pointer_img) normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_minute);
              };

              if (updateHour) {
                let idle_hour = hour;
                let idle_fullAngle_hour = 360;
                if (idle_hour > 11) idle_hour -= 12;
                let idle_angle_hour = 0 + idle_fullAngle_hour*idle_hour/12 + (idle_fullAngle_hour/12)*minute/60;
                if (idle_analog_clock_pro_hour_pointer_img) idle_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.ANGLE, idle_angle_hour);
              };

              if (updateMinute) {
                let idle_fullAngle_minute = 360;
                let idle_angle_minute = 0 + idle_fullAngle_minute*minute/60;
                if (idle_analog_clock_pro_minute_pointer_img) idle_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.ANGLE, idle_angle_minute);
              };

            };

            //end of ignored block
            //start of ignored block
            function text_update() {
              console.log('text_update()');

              console.log('update text rotate battery_BATTERY');
              let valueBattery = battery.current;
              let normal_battery_rotate_string = parseInt(valueBattery).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  normal_battery_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueBattery != null && valueBattery != undefined && isFinite(valueBattery) && normal_battery_rotate_string.length > 0 && normal_battery_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let normal_battery_TextRotate_posOffset = normal_battery_TextRotate_img_width * normal_battery_rotate_string.length;
                  img_offset -= normal_battery_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_battery_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_battery_TextRotate[index].setProperty(hmUI.prop.POS_X, 369 + img_offset);
                      normal_battery_TextRotate[index].setProperty(hmUI.prop.SRC, normal_battery_TextRotate_ASCIIARRAY[charCode]);
                      normal_battery_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_battery_TextRotate_img_width;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate day_TIME');
              let valueDay = timeSensor.day;
              let normal_day_rotate_string = parseInt(valueDay).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_day_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueDay != null && valueDay != undefined && isFinite(valueDay) && normal_day_rotate_string.length > 0 && normal_day_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let normal_day_TextRotate_posOffset = normal_day_TextRotate_img_width * normal_day_rotate_string.length;
                  img_offset -= normal_day_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_day_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_day_TextRotate[index].setProperty(hmUI.prop.POS_X, 240 + img_offset);
                      normal_day_TextRotate[index].setProperty(hmUI.prop.SRC, normal_day_TextRotate_ASCIIARRAY[charCode]);
                      normal_day_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_day_TextRotate_img_width;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

            };

            //end of ignored block
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                time_update(true, true);
                text_update();
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerTextUpdate) {
                    normal_timerTextUpdate = timer.createTimer(0, 1000, (function (option) {
                      text_update();
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSec) {
                    let animDelay = timeSensor.utc % 1000;
                    let animRepeat = 1000;
                    normal_timerUpdateSec = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, true);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerTextUpdate) {
                  timer.stopTimer(normal_timerTextUpdate);
                  normal_timerTextUpdate = undefined;
                }
                if (normal_timerUpdateSec) {
                  timer.stopTimer(normal_timerUpdateSec);
                  normal_timerUpdateSec = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

		let screenType = hmSetting.getScreenType();
		let colornumber_main = 1
		let secstring = 'hand_sec1.png'
		let button_color1 = ''
		let button_color2 = ''
		let button_color3 = ''
		let button_color4 = ''
		let button_color5 = ''
		let button_color6 = ''
		let button_color7 = ''
		let button_color8 = ''
		let button_color9 = ''
		let button_color10 = ''
		let button_color11 = ''
		let button_color12 = ''
		let button_color13 = ''
		let button_color14 = ''
		let button_color15 = ''
		let button_color16 = ''
		let savedScoreAOD = ''
		
		function click_COLOR() {
			
			normal_stress_icon_img.setProperty(hmUI.prop.VISIBLE, true);
			button_color1.setProperty(hmUI.prop.VISIBLE, true);
			button_color2.setProperty(hmUI.prop.VISIBLE, true);
			button_color3.setProperty(hmUI.prop.VISIBLE, true);
			button_color4.setProperty(hmUI.prop.VISIBLE, true);
			button_color5.setProperty(hmUI.prop.VISIBLE, true);
			button_color6.setProperty(hmUI.prop.VISIBLE, true);
			button_color7.setProperty(hmUI.prop.VISIBLE, true);
			button_color8.setProperty(hmUI.prop.VISIBLE, true);
			button_color9.setProperty(hmUI.prop.VISIBLE, true);
			button_color10.setProperty(hmUI.prop.VISIBLE, true);
			button_color11.setProperty(hmUI.prop.VISIBLE, true);
			button_color12.setProperty(hmUI.prop.VISIBLE, true);
			button_color13.setProperty(hmUI.prop.VISIBLE, true);
			button_color14.setProperty(hmUI.prop.VISIBLE, true);
			button_color15.setProperty(hmUI.prop.VISIBLE, true);
			button_color16.setProperty(hmUI.prop.VISIBLE, true);
			Button_1.setProperty(hmUI.prop.VISIBLE, false);
			Button_2.setProperty(hmUI.prop.VISIBLE, false);
			Button_3.setProperty(hmUI.prop.VISIBLE, false);
			Button_4.setProperty(hmUI.prop.VISIBLE, false);
			Button_5.setProperty(hmUI.prop.VISIBLE, false);
			Button_6.setProperty(hmUI.prop.VISIBLE, false);
			Button_7.setProperty(hmUI.prop.VISIBLE, false);
			Button_8.setProperty(hmUI.prop.VISIBLE, false);
			Button_9.setProperty(hmUI.prop.VISIBLE, false);
			Button_10.setProperty(hmUI.prop.VISIBLE, false);
			Button_11.setProperty(hmUI.prop.VISIBLE, false);
			Button_12.setProperty(hmUI.prop.VISIBLE, false);
			Button_13.setProperty(hmUI.prop.VISIBLE, false);
			Button_14.setProperty(hmUI.prop.VISIBLE, false);
			Button_15.setProperty(hmUI.prop.VISIBLE, false);
			Button_16.setProperty(hmUI.prop.VISIBLE, false);
			Button_17.setProperty(hmUI.prop.VISIBLE, false);
			Button_18.setProperty(hmUI.prop.VISIBLE, false);
            hmUI.showToast({text: 'CHOOSE YOUR COLOR'});
        }

        function CHOOSE_COLOR(){
			
			if ( colornumber_main == 1) { 
				secstring = 'hand_sec1.png'
			}
			if ( colornumber_main == 2) {
				secstring = 'hand_sec2.png'
			}
			if ( colornumber_main == 3) {
				secstring = 'hand_sec3.png'
			}
			if ( colornumber_main == 4) {
				secstring = 'hand_sec4.png'
			}
			if ( colornumber_main == 5) {
				secstring = 'hand_sec5.png'
			}
			if ( colornumber_main == 6) {
				secstring = 'hand_sec6.png'
			}
			if ( colornumber_main == 7) {
				secstring = 'hand_sec7.png'
			}
			if ( colornumber_main == 8) {
				secstring = 'hand_sec8.png'
			}
			if ( colornumber_main == 9) {
				secstring = 'hand_sec9.png'
			}
			if ( colornumber_main == 10) {
				secstring = 'hand_sec10.png'
			}
			if ( colornumber_main == 11) {
				secstring = 'hand_sec11.png'
			}
			if ( colornumber_main == 12) {
				secstring = 'hand_sec12.png'
			}
			if ( colornumber_main == 13) {
				secstring = 'hand_sec13.png'
			}
			if ( colornumber_main == 14) {
				secstring = 'hand_sec14.png'
			}
			if ( colornumber_main == 15) {
				secstring = 'hand_sec15.png'
			}
			if ( colornumber_main == 16) {
				secstring = 'hand_sec16.png'
			}
			if ( colornumber_main <= 16) { 
			
            normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.MORE, {
              second_path: secstring,
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 240,
              second_posY: 240,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			}
			
			hmFS.SysProSetInt('userScore', colornumber_main);
            console.log(savedScoreAOD);   
			
			normal_image_img.setProperty(hmUI.prop.SRC, "color" + parseInt(colornumber_main) + ".png");
			setTimeout(function(){
			normal_stress_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			button_color1.setProperty(hmUI.prop.VISIBLE, false);
			button_color2.setProperty(hmUI.prop.VISIBLE, false);
			button_color3.setProperty(hmUI.prop.VISIBLE, false);
			button_color4.setProperty(hmUI.prop.VISIBLE, false);
			button_color5.setProperty(hmUI.prop.VISIBLE, false);
			button_color6.setProperty(hmUI.prop.VISIBLE, false);
			button_color7.setProperty(hmUI.prop.VISIBLE, false);
			button_color8.setProperty(hmUI.prop.VISIBLE, false);
			button_color9.setProperty(hmUI.prop.VISIBLE, false);
			button_color10.setProperty(hmUI.prop.VISIBLE, false);
			button_color11.setProperty(hmUI.prop.VISIBLE, false);
			button_color12.setProperty(hmUI.prop.VISIBLE, false);
			button_color13.setProperty(hmUI.prop.VISIBLE, false);
			button_color14.setProperty(hmUI.prop.VISIBLE, false);
			button_color15.setProperty(hmUI.prop.VISIBLE, false);
			button_color16.setProperty(hmUI.prop.VISIBLE, false);
			Button_1.setProperty(hmUI.prop.VISIBLE, true);
			Button_2.setProperty(hmUI.prop.VISIBLE, true);
			Button_3.setProperty(hmUI.prop.VISIBLE, true);
			Button_4.setProperty(hmUI.prop.VISIBLE, true);
			Button_5.setProperty(hmUI.prop.VISIBLE, true);
			Button_6.setProperty(hmUI.prop.VISIBLE, true);
			Button_7.setProperty(hmUI.prop.VISIBLE, true);
			Button_8.setProperty(hmUI.prop.VISIBLE, true);
			Button_9.setProperty(hmUI.prop.VISIBLE, true);
			Button_10.setProperty(hmUI.prop.VISIBLE, true);
			Button_11.setProperty(hmUI.prop.VISIBLE, true);
			Button_12.setProperty(hmUI.prop.VISIBLE, true);
			Button_13.setProperty(hmUI.prop.VISIBLE, true);
			Button_14.setProperty(hmUI.prop.VISIBLE, true);
			Button_15.setProperty(hmUI.prop.VISIBLE, true);
			Button_16.setProperty(hmUI.prop.VISIBLE, true);
			Button_17.setProperty(hmUI.prop.VISIBLE, true);
			Button_18.setProperty(hmUI.prop.VISIBLE, true);
			}, 1200);
		}
		
		function click_COLOR1() {
            colornumber_main=1;
			hmUI.showToast({text: 'O R A N G E'});
			CHOOSE_COLOR();
        }
		
		function click_COLOR2() {
            colornumber_main=2;
			hmUI.showToast({text: 'T E A L'});
			CHOOSE_COLOR();
        }
		
		function click_COLOR3() {
            colornumber_main=3;
			hmUI.showToast({text: 'O L I V E'});
			CHOOSE_COLOR();
        }
		
		function click_COLOR4() {
            colornumber_main=4;
			hmUI.showToast({text: 'M A R O O N'});
			CHOOSE_COLOR();
        }
		
		function click_COLOR5() {
            colornumber_main=5;
			hmUI.showToast({text: 'A Q U A'});
			CHOOSE_COLOR();
        }
		
		function click_COLOR6() {
            colornumber_main=6;
			hmUI.showToast({text: 'G R E E N'});
			CHOOSE_COLOR();
        }
		
		function click_COLOR7() {
            colornumber_main=7;
			hmUI.showToast({text: 'R E D'});
			CHOOSE_COLOR();
        }
		
		function click_COLOR8() {
            colornumber_main=8;
			hmUI.showToast({text: 'Y E L L O W'});
			CHOOSE_COLOR();
        }
		
		function click_COLOR9() {
            colornumber_main=9;
			hmUI.showToast({text: 'L I M E'});
			CHOOSE_COLOR();
        }
		
		function click_COLOR10() {
            colornumber_main=10;
			hmUI.showToast({text: 'P U R P L E'});
			CHOOSE_COLOR();
        }
		
		function click_COLOR11() {
            colornumber_main=11;
			hmUI.showToast({text: 'B L U E'});
			CHOOSE_COLOR();
        }
		
		function click_COLOR12() {
            colornumber_main=12;
			hmUI.showToast({text: 'F U C H S I A'});
			CHOOSE_COLOR();
        }
		
		function click_COLOR13() {
            colornumber_main=13;
			hmUI.showToast({text: 'S E P I A'});
			CHOOSE_COLOR();
        }
		
		function click_COLOR14() {
            colornumber_main=14;
			hmUI.showToast({text: 'A M B E R'});
			CHOOSE_COLOR();
        }
		
		function click_COLOR15() {
            colornumber_main=15;
			hmUI.showToast({text: 'S I L V E R'});
			CHOOSE_COLOR();
        }
		
		function click_COLOR16() {
            colornumber_main=16;
			hmUI.showToast({text: 'B L A C K'});
			CHOOSE_COLOR();
        }
		
		let element_index = 0; 
        let element_count = 5;
		
		function click_CONTENT() {
			element_index = (element_index + 1) % element_count;
			apply_content_switch();
		}
		
		function click_CONTENTB() {
			if (element_index == 0) {
			element_index = element_count - 1;
				} else {
			element_index = (element_index - 1) % element_count;
				}	
			apply_content_switch();
		}

		function apply_content_switch() {

			  normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, element_index == 0);
			  normal_step_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, element_index == 0);
			  normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, element_index == 0);
			  Button_1.setProperty(hmUI.prop.VISIBLE, element_index == 0);
			  Button_6.setProperty(hmUI.prop.VISIBLE, element_index == 0);

              normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, element_index == 1);
			  normal_heart_rate_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, element_index == 1);
			  normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, element_index == 1);
			  Button_2.setProperty(hmUI.prop.VISIBLE, element_index == 1);
			  Button_7.setProperty(hmUI.prop.VISIBLE, element_index == 1);

              normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, element_index == 2);
			  normal_calorie_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, element_index == 2);
			  normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, element_index == 2);
			  Button_3.setProperty(hmUI.prop.VISIBLE, element_index == 2);
			  Button_8.setProperty(hmUI.prop.VISIBLE, element_index == 2);
			  
			  normal_humidity_icon_img.setProperty(hmUI.prop.VISIBLE, element_index == 3);
			  normal_humidity_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, element_index == 3);
			  normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, element_index == 3);
			  normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, element_index == 3);
			  Button_4.setProperty(hmUI.prop.VISIBLE, element_index == 3);
			  Button_9.setProperty(hmUI.prop.VISIBLE, element_index == 3);
			  
			  normal_uvi_icon_img.setProperty(hmUI.prop.VISIBLE, element_index == 4);
			  normal_uvi_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, element_index == 4);
			  normal_sun_current_text_img.setProperty(hmUI.prop.VISIBLE, element_index == 4);
			  Button_5.setProperty(hmUI.prop.VISIBLE, element_index == 4);
			  Button_10.setProperty(hmUI.prop.VISIBLE, element_index == 4);

               if (element_index == 0) {
                 hmUI.showToast({text: 'STEPS'});
               };
               if (element_index == 1) {
                 hmUI.showToast({text: 'PULSE'});
               };
               if (element_index == 2) {
                 hmUI.showToast({text: 'KCAL'});
               };
			   if (element_index == 3) {
                 hmUI.showToast({text: 'WEATHER'});
               };
			   if (element_index == 4) {
                 hmUI.showToast({text: 'SUN/UV'});
               };
        };
		
		let elementnumber_1 = 1
        let total_elemente = 2

        function click_HANDS() {
            if(elementnumber_1==total_elemente) {
            elementnumber_1=1;
                UpdateElementeOne();
                }
            else {
                elementnumber_1=elementnumber_1+1;
                if(elementnumber_1==2) {
                  UpdateElementeTwo();
                }
            }
            if(elementnumber_1==1) hmUI.showToast({text: 'SHOW SEC HAND'});
            if(elementnumber_1==2) hmUI.showToast({text: 'HIDE SEC HAND'});
        }

        function UpdateElementeOne(){
                normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, true);
        }

        function UpdateElementeTwo(){
				normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, false);
        }
        // end user_functions.js

        let normal_background_bg = ''
        let normal_analog_clock_pro_second_pointer_img = ''
        let normal_timerUpdateSecSmooth = undefined;
        let lastTime = 0;
        let normal_spo2_icon_img = ''
        let normal_image_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_uvi_icon_img = ''
        let normal_uvi_pointer_progress_img_pointer = ''
        let normal_sun_current_text_img = ''
        let normal_humidity_icon_img = ''
        let normal_humidity_pointer_progress_img_pointer = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_calorie_icon_img = ''
        let normal_calorie_pointer_progress_img_pointer = ''
        let normal_calorie_current_text_img = ''
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_pointer_progress_img_pointer = ''
        let normal_heart_rate_text_text_img = ''
        let normal_step_icon_img = ''
        let normal_step_pointer_progress_img_pointer = ''
        let normal_step_current_text_img = ''
        let normal_system_disconnect_img = ''
        let normal_battery_pointer_progress_img_pointer = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_month_pointer_progress_date_pointer = ''
        let normal_stand_icon_img = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_stress_icon_img = ''
        let idle_background_bg = ''
        let idle_spo2_icon_img = ''
        let idle_image_img = ''
        let idle_moon_image_progress_img_level = ''
        let idle_step_icon_img = ''
        let idle_step_pointer_progress_img_pointer = ''
        let idle_step_current_text_img = ''
        let idle_system_disconnect_img = ''
        let idle_battery_icon_img = ''
        let idle_battery_pointer_progress_img_pointer = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_day = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let Button_7 = ''
        let Button_8 = ''
        let Button_9 = ''
        let Button_10 = ''
        let Button_11 = ''
        let Button_12 = ''
        let Button_13 = ''
        let Button_14 = ''
        let Button_15 = ''
        let Button_16 = ''
        let Button_17 = ''
        let Button_18 = ''
        let timeSensor = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFFD0C8B8',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            const deviceInfo = hmSetting.getDeviceInfo();
            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'sec_circle.png',
              // center_x: 240,
              // center_y: 240,
              // x: 240,
              // y: 240,
              // start_angle: 225,
              // end_angle: -135,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 240,
              pos_y: 240 - 240,
              center_x: 240,
              center_y: 240,
              src: 'sec_circle.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            function startSecAnim(sec, animDuration) {
              const secAnim = {
                anim_steps: [{
                  anim_rate: 'linear',
                  anim_duration: animDuration,
                  anim_from: sec,
                  anim_to: sec + (-360*(animDuration*6/1000))/360,
                  anim_key: 'angle',
                }],
                anim_fps: 15,
                anim_auto_start: 1,
                anim_repeat: 1,
                anim_auto_destroy: 1,
              }
              normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANIM, secAnim);
            }
            // normal_analog_clock_pro_smooth_second = hmUI.createWidget(hmUI.widget.SMOOTH_SECOND, {
              // type: 4,
              // fps: 15,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_spo2_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'mask.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'color1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 324,
              y: 324,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_uvi_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'panel5.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_uvi_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'pointer.png',
              center_x: 346,
              center_y: 240,
              x: 68,
              y: 68,
              start_angle: 0,
              end_angle: 300,
              invalid_visible: false,
              type: hmUI.data_type.UVI,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 218,
              y: 136,
              font_array: ["sun_00.png","sun_01.png","sun_02.png","sun_03.png","sun_04.png","sun_05.png","sun_06.png","sun_07.png","sun_08.png","sun_09.png"],
              padding: false,
              h_space: -1,
              dot_image: 'sun_sep.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'panel4.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'pointer.png',
              center_x: 346,
              center_y: 240,
              x: 68,
              y: 68,
              start_angle: 0,
              end_angle: 300,
              invalid_visible: false,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 188,
              y: 130,
              image_array: ["weatherl_00.png","weatherl_01.png","weatherl_02.png","weatherl_03.png","weatherl_04.png","weatherl_05.png","weatherl_06.png","weatherl_07.png","weatherl_08.png","weatherl_09.png","weatherl_10.png","weatherl_11.png","weatherl_12.png","weatherl_13.png","weatherl_14.png","weatherl_15.png","weatherl_16.png","weatherl_17.png","weatherl_18.png","weatherl_19.png","weatherl_20.png","weatherl_21.png","weatherl_22.png","weatherl_23.png","weatherl_24.png","weatherl_25.png","weatherl_26.png","weatherl_27.png","weatherl_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 218,
              y: 135,
              font_array: ["sun_00.png","sun_01.png","sun_02.png","sun_03.png","sun_04.png","sun_05.png","sun_06.png","sun_07.png","sun_08.png","sun_09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'sun_11.png',
              unit_tc: 'sun_11.png',
              unit_en: 'sun_11.png',
              imperial_unit_sc: 'sun_13.png',
              imperial_unit_tc: 'sun_13.png',
              imperial_unit_en: 'sun_13.png',
              negative_image: 'sun_12.png',
              invalid_image: 'sun_10.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const temperatureUnit = hmSetting.getTemperatureUnit();
            //start of ignored block
            if (temperatureUnit == 1) {
              normal_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
                x: 218,
                y: 135,
                font_array: ["sun_00.png","sun_01.png","sun_02.png","sun_03.png","sun_04.png","sun_05.png","sun_06.png","sun_07.png","sun_08.png","sun_09.png"],
                padding: false,
                h_space: 0,
                unit_sc: 'sun_13.png',
                unit_tc: 'sun_13.png',
                unit_en: 'sun_13.png',
                imperial_unit_sc: 'sun_11.png',
                imperial_unit_tc: 'sun_11.png',
                imperial_unit_en: 'sun_11.png',
                negative_image: 'sun_12.png',
                invalid_image: 'sun_10.png',
                align_h: hmUI.align.CENTER_H,
                type: hmUI.data_type.WEATHER_CURRENT,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
            };
            //end of ignored block

            normal_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'panel3.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'pointer.png',
              center_x: 346,
              center_y: 240,
              x: 68,
              y: 68,
              start_angle: 0,
              end_angle: 300,
              invalid_visible: false,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 198,
              y: 135,
              font_array: ["sun_00.png","sun_01.png","sun_02.png","sun_03.png","sun_04.png","sun_05.png","sun_06.png","sun_07.png","sun_08.png","sun_09.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'panel2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'pointer.png',
              center_x: 346,
              center_y: 240,
              x: 68,
              y: 68,
              start_angle: 0,
              end_angle: 300,
              invalid_visible: false,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 208,
              y: 135,
              font_array: ["sun_00.png","sun_01.png","sun_02.png","sun_03.png","sun_04.png","sun_05.png","sun_06.png","sun_07.png","sun_08.png","sun_09.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'panel1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'pointer.png',
              center_x: 346,
              center_y: 240,
              x: 68,
              y: 68,
              start_angle: 0,
              end_angle: 300,
              invalid_visible: false,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 188,
              y: 135,
              font_array: ["sun_00.png","sun_01.png","sun_02.png","sun_03.png","sun_04.png","sun_05.png","sun_06.png","sun_07.png","sun_08.png","sun_09.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 150,
              y: 260,
              src: 'st_bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'pointer.png',
              center_x: 134,
              center_y: 240,
              x: 68,
              y: 68,
              start_angle: 0,
              end_angle: 360,
              invalid_visible: false,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 206,
              y: 320,
              week_en: ["wd1.png","wd2.png","wd3.png","wd4.png","wd5.png","wd6.png","wd7.png"],
              week_tc: ["wd1.png","wd2.png","wd3.png","wd4.png","wd5.png","wd6.png","wd7.png"],
              week_sc: ["wd1.png","wd2.png","wd3.png","wd4.png","wd5.png","wd6.png","wd7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 216,
              day_startY: 354,
              day_sc_array: ["day_00.png","day_01.png","day_02.png","day_03.png","day_04.png","day_05.png","day_06.png","day_07.png","day_08.png","day_09.png"],
              day_tc_array: ["day_00.png","day_01.png","day_02.png","day_03.png","day_04.png","day_05.png","day_06.png","day_07.png","day_08.png","day_09.png"],
              day_en_array: ["day_00.png","day_01.png","day_02.png","day_03.png","day_04.png","day_05.png","day_06.png","day_07.png","day_08.png","day_09.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_month_pointer_progress_date_pointer = hmUI.createWidget(hmUI.widget.DATE_POINTER, {
              src: 'month.png',
              center_x: 240,
              center_y: 346,
              posX: 75,
              posY: 74,
              start_angle: -30,
              end_angle: 330,
              type: hmUI.date.MONTH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'top.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hand_hour1.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 240,
              hour_posY: 240,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'hand_min1.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 240,
              minute_posY: 240,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'hand_sec1.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 240,
              second_posY: 240,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'Theme_Picker.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_spo2_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'aod_mask.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'color1.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 324,
              y: 324,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'panel1.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'pointer.png',
              center_x: 346,
              center_y: 240,
              x: 68,
              y: 68,
              start_angle: 0,
              end_angle: 300,
              invalid_visible: false,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 188,
              y: 135,
              font_array: ["sun_00.png","sun_01.png","sun_02.png","sun_03.png","sun_04.png","sun_05.png","sun_06.png","sun_07.png","sun_08.png","sun_09.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 120,
              y: 325,
              src: 'aod_st_bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'aod_top.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'pointer.png',
              center_x: 134,
              center_y: 240,
              x: 68,
              y: 68,
              start_angle: 0,
              end_angle: 360,
              invalid_visible: false,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 206,
              y: 320,
              week_en: ["wd1.png","wd2.png","wd3.png","wd4.png","wd5.png","wd6.png","wd7.png"],
              week_tc: ["wd1.png","wd2.png","wd3.png","wd4.png","wd5.png","wd6.png","wd7.png"],
              week_sc: ["wd1.png","wd2.png","wd3.png","wd4.png","wd5.png","wd6.png","wd7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 216,
              day_startY: 354,
              day_sc_array: ["day_00.png","day_01.png","day_02.png","day_03.png","day_04.png","day_05.png","day_06.png","day_07.png","day_08.png","day_09.png"],
              day_tc_array: ["day_00.png","day_01.png","day_02.png","day_03.png","day_04.png","day_05.png","day_06.png","day_07.png","day_08.png","day_09.png"],
              day_en_array: ["day_00.png","day_01.png","day_02.png","day_03.png","day_04.png","day_05.png","day_06.png","day_07.png","day_08.png","day_09.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hand_hour1.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 240,
              hour_posY: 240,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'hand_min1.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 240,
              minute_posY: 240,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 295,
              y: 190,
              w: 100,
              h: 100,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'SportListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 295,
              y: 190,
              w: 100,
              h: 100,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'spo_HomeScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 295,
              y: 190,
              w: 100,
              h: 100,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'SportStatusScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 295,
              y: 190,
              w: 100,
              h: 100,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({ appid: 1051195, url: 'page/index', params: { from_wf: true} });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 295,
              y: 190,
              w: 100,
              h: 100,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'BaroAltimeterScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 190,
              y: 120,
              w: 100,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'activityAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_7 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 190,
              y: 120,
              w: 100,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'heart_app_Screen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_8 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 190,
              y: 120,
              w: 100,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PAI_app_Screen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_9 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 190,
              y: 120,
              w: 100,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'WeatherScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_10 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 190,
              y: 120,
              w: 100,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'TideScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_11 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 320,
              y: 320,
              w: 50,
              h: 45,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'Sleep_HomeScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_12 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 80,
              y: 320,
              w: 80,
              h: 80,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'StopWatchScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_13 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 85,
              y: 190,
              w: 100,
              h: 100,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PowerSaveHintScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_14 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 190,
              y: 300,
              w: 100,
              h: 100,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_15 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 205,
              y: 205,
              w: 70,
              h: 70,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                				click_HANDS();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_16 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 365,
              y: 365,
              w: 50,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                				click_COLOR();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_17 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 125,
              y: 120,
              w: 50,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                				click_CONTENTB();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_18 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 305,
              y: 120,
              w: 50,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                				click_CONTENT();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            console.log('user_script_end.js');
            // start user_script_end.js

			button_color1 = hmUI.createWidget(hmUI.widget.BUTTON, {
			  x: 95,
              y: 95,
              w: 65,
              h: 65,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                click_COLOR1();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button
			
			button_color2 = hmUI.createWidget(hmUI.widget.BUTTON, {
			  x: 170,
              y: 95,
              w: 65,
              h: 65,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                click_COLOR2();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button
			
			button_color3 = hmUI.createWidget(hmUI.widget.BUTTON, {
			  x: 245,
              y: 95,
              w: 65,
              h: 65,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                click_COLOR3();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button
			
			button_color4 = hmUI.createWidget(hmUI.widget.BUTTON, {
			  x: 320,
              y: 95,
              w: 65,
              h: 65,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                click_COLOR4();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button
			
			button_color5 = hmUI.createWidget(hmUI.widget.BUTTON, {
			  x: 95,
              y: 170,
              w: 65,
              h: 65,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                click_COLOR5();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button
			
			button_color6 = hmUI.createWidget(hmUI.widget.BUTTON, {
			  x: 170,
              y: 170,
              w: 65,
              h: 65,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                click_COLOR6();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button
			
			button_color7 = hmUI.createWidget(hmUI.widget.BUTTON, {
			  x: 245,
              y: 170,
              w: 65,
              h: 65,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                click_COLOR7();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button
			
			button_color8 = hmUI.createWidget(hmUI.widget.BUTTON, {
			  x: 320,
              y: 170,
              w: 65,
              h: 65,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                click_COLOR8();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button
			
			button_color9 = hmUI.createWidget(hmUI.widget.BUTTON, {
			  x: 95,
              y: 245,
              w: 65,
              h: 65,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                click_COLOR9();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button
			
			button_color10 = hmUI.createWidget(hmUI.widget.BUTTON, {
			  x: 170,
              y: 245,
              w: 65,
              h: 65,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                click_COLOR10();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button
			
			button_color11 = hmUI.createWidget(hmUI.widget.BUTTON, {
			  x: 245,
              y: 245,
              w: 65,
              h: 65,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                click_COLOR11();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button
			
			button_color12 = hmUI.createWidget(hmUI.widget.BUTTON, {
			  x: 320,
              y: 245,
              w: 65,
              h: 65,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                click_COLOR12();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button
			
			button_color13 = hmUI.createWidget(hmUI.widget.BUTTON, {
			  x: 95,
              y: 320,
              w: 65,
              h: 65,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                click_COLOR13();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button
			
			button_color14 = hmUI.createWidget(hmUI.widget.BUTTON, {
			  x: 170,
              y: 320,
              w: 65,
              h: 65,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                click_COLOR14();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button
			
			button_color15 = hmUI.createWidget(hmUI.widget.BUTTON, {
			  x: 245,
              y: 320,
              w: 65,
              h: 65,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                click_COLOR15();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button
			
			button_color16 = hmUI.createWidget(hmUI.widget.BUTTON, {
			  x: 320,
              y: 320,
              w: 65,
              h: 65,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                click_COLOR16();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button
			
			let cc = 0
			if (cc ==0 ){
			normal_stress_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			button_color1.setProperty(hmUI.prop.VISIBLE, false);
			button_color2.setProperty(hmUI.prop.VISIBLE, false);
			button_color3.setProperty(hmUI.prop.VISIBLE, false);
			button_color4.setProperty(hmUI.prop.VISIBLE, false);
			button_color5.setProperty(hmUI.prop.VISIBLE, false);
			button_color6.setProperty(hmUI.prop.VISIBLE, false);
			button_color7.setProperty(hmUI.prop.VISIBLE, false);
			button_color8.setProperty(hmUI.prop.VISIBLE, false);
			button_color9.setProperty(hmUI.prop.VISIBLE, false);
			button_color10.setProperty(hmUI.prop.VISIBLE, false);
			button_color11.setProperty(hmUI.prop.VISIBLE, false);
			button_color12.setProperty(hmUI.prop.VISIBLE, false);
			button_color13.setProperty(hmUI.prop.VISIBLE, false);
			button_color14.setProperty(hmUI.prop.VISIBLE, false);
			button_color15.setProperty(hmUI.prop.VISIBLE, false);
			button_color16.setProperty(hmUI.prop.VISIBLE, false);

              normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			  normal_heart_rate_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			  normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			  Button_2.setProperty(hmUI.prop.VISIBLE, false);
			  Button_7.setProperty(hmUI.prop.VISIBLE, false);

              normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			  normal_calorie_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			  normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			  Button_3.setProperty(hmUI.prop.VISIBLE, false);
			  Button_8.setProperty(hmUI.prop.VISIBLE, false);
			  
			  normal_humidity_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			  normal_humidity_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			  normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
			  normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			  Button_4.setProperty(hmUI.prop.VISIBLE, false);
			  Button_9.setProperty(hmUI.prop.VISIBLE, false);
			  
			  normal_uvi_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			  normal_uvi_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			  normal_sun_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			  Button_5.setProperty(hmUI.prop.VISIBLE, false);
			  Button_10.setProperty(hmUI.prop.VISIBLE, false);
			cc = 1;
			}
            // end user_script_end.js

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                let secAngle = 225 + (-360*6)*(timeSensor.second + ((timeSensor.utc % 1000) / 1000))/360;
                normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, secAngle);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSecSmooth) {
                    let duration = 0;
                    let animDuration = 5000;
                    if (timeSensor.second > 55) animDuration = 1000*(60.1 - (timeSensor.second - (timeSensor.utc % 1000) / 1000));
                    let diffTime = timeSensor.utc - lastTime;
                    if (diffTime < animDuration) duration = animDuration - diffTime;
                    normal_timerUpdateSecSmooth = timer.createTimer(duration, animDuration, (function (option) {
                      lastTime = timeSensor.utc;
                      secAngle = 225 + (-360*6)*(timeSensor.second + ((timeSensor.utc % 1000) / 1000))/360;
                      startSecAnim(secAngle, animDuration);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


                console.log('resume_call.js');
                // start resume_call.js

			idle_image_img.setProperty(hmUI.prop.SRC, "color" + hmFS.SysProGetInt('userScore') + ".png");
                // end resume_call.js

              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerUpdateSecSmooth) {
                  timer.stopTimer(normal_timerUpdateSecSmooth);
                  normal_timerUpdateSecSmooth = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
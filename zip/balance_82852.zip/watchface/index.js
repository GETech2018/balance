﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

//#region functions

function read_pressure() {
    console.log("read_pressure()");
    const file_name_alt = "../../../baro_altim/pressure.dat";
    const [fs_stat, err] = hmFS.stat(file_name_alt);
    if (err == 0) {
      let file_size = fs_stat.size;
      const len = file_size / 4;
      console.log(`size_alt: ${file_size}, lenght: ${len}`)
      const fh = hmFS.open(file_name_alt, hmFS.O_RDONLY)
  
      let array_buffer = new Float32Array(len);
      hmFS.read(fh, array_buffer.buffer, 0, file_size);
      hmFS.close(fh);
      console.log(`value ${array_buffer[array_buffer.length -1]}`);
      return array_buffer;
    } else {
      console.log('err:', err)
    }
    return null;
  }
  
  function getPressureValue(pressure_array) {
    console.log("getPressureValue()");
    if(pressure_array == null || pressure_array == undefined || pressure_array.length == 0) return 0;
    let start_index = pressure_array.length - 1;
    let end_index = start_index - 30*3; // 3 часа
    if(end_index < 0) end_index = 0;
    for (let index = start_index; index >= end_index; index--) {
      if(pressure_array[index] != 0) return parseInt(pressure_array[index] / 100);
    }
    return 0;
  }
  
  function changesPressure(pressure_array) {
    console.log("changesPressure()");
    if(pressure_array == null || pressure_array == undefined || pressure_array.length == 0) return 0;
    let start_index = pressure_array.length - 1;
    let end_index = start_index - 30*3; // 3 часа
    let value = pressure_array[start_index];
    let result = 0;
    if(end_index < 0) end_index = 0;
    for (let index = start_index; index >= end_index; index--) {
      let element = pressure_array[index];
      if(element != 0) {
        if(Math.abs(value - element) > 10) { // учитываем только если разниза больше 0,1 hPa
          value = value - element;
          console.log(`element = ${element}`);
          console.log(`pressere_changes = ${value}`);
          return value;
        }
      }
    }
    return result;
  }
  
  function hPa_To_mmHg(hPa_value = 0) {
    let mmHg = Math.round(hPa_value * 0.750064);
    return mmHg;
  }
  //#endregion
  
  let text_pressere;

  
        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_image_img = ''
        let normal_pai_day_text_img = ''
        let normal_altimeter_pointer_progress_img_pointer = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_heart_rate_text_text_img = ''
        let normal_wind_direction_image_progress_img_level = ''
        let normal_wind_image_progress_img_level = ''
        let normal_moon_image_progress_img_level = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_city_name_text = ''
        let normal_temperature_high_text_img = ''
        let normal_temperature_high_separator_img = ''
        let normal_temperature_low_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_sun_high_text_img = ''
        let normal_sun_low_text_img = ''
        let normal_humidity_text_text_img = ''
        let normal_stand_current_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_battery_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let idle_background_bg = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''
        let normal_step_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_battery_jumpable_img_click = ''
        let normal_altimeter_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_sleep_jumpable_img_click = ''
        let normal_stopwatch_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            // FontName: GoogleSans-Regular.ttf; FontSize: 26; Cache: full
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 31,
              h: 31,
              text_size: 26,
              char_space: 0,
              line_space: 0,
              font: 'fonts/GoogleSans-Regular.ttf',
              color: 0xFF000000,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.NONE,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('user_script_start.js');
            // start user_script_start.js

            let sleep_time_txt = ''
            let sleep_start_time_txt = ''
            let sleep_end_time_txt = ''
            let sleep_score_txt = ''
            let wake_time_txt = ''

            const sleep = hmSensor.createSensor(hmSensor.id.SLEEP);
            let sleepInfo = sleep.getBasicInfo();
            
            let sleepTotalTime = sleep.getTotalTime();		
            let sleepStartTime = sleepInfo.startTime;
            let sleepEndTime = sleepInfo.endTime + 1;
            let sleepScore = sleepInfo.score;

        //время пробуждений	
            let sleepStageArray = sleep.getSleepStageData();
            const modelData = sleep.getSleepStageModel();
        //		

            function updateSleepInfo() {
                sleepTotalTime = sleep.getTotalTime();
                sleepInfo = sleep.getBasicInfo();
                sleepStartTime = sleepInfo.startTime;
                if (sleepStartTime >= 24*60) {
                    sleepStartTime -= 24*60
                }
                
                sleepEndTime = sleepInfo.endTime + 1;
                if (sleepEndTime >= 24*60) {
                    sleepEndTime -= 24*60
                }

            // время пробуждений
                let wakeTime = 0;
                sleepStageArray = sleep.getSleepStageData();
                
                for (let i = 0; i < sleepStageArray.length; i++) {
                let data = sleepStageArray[i];
                if (data.model == modelData.WAKE_STAGE){
                        wakeTime += data.stop + 1 - data.start;
                }

                }
                
                sleepTotalTime -= wakeTime;
           //
                
                sleep_time_txt.setProperty(hmUI.prop.TEXT, ' ' + Math.floor(sleepTotalTime / 60).toString().padStart(2, "0") + ':' + (sleepTotalTime % 60).toString().padStart(2, "0"));
                sleep_start_time_txt.setProperty(hmUI.prop.TEXT, Math.floor(sleepStartTime / 60).toString().padStart(2, "0") + ':' + (sleepStartTime % 60).toString().padStart(2, "0"));
                sleep_end_time_txt.setProperty(hmUI.prop.TEXT, Math.floor(sleepEndTime / 60).toString().padStart(2, "0") + ':' + (sleepEndTime % 60).toString().padStart(2, "0"));
                wake_time_txt.setProperty(hmUI.prop.TEXT, 'Не спали: ' + String(wakeTime) + ' мин.');
                sleep_score_txt.setProperty(hmUI.prop.TEXT, ' ' + String(sleepScore));
            }
            // end user_script_start.js

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'osn.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: '1001.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('user_script.js');
            // start user_script.js
            sleep_time_txt = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 185,
              y: 320,
              w: 190,
              h: 45,
              text_size: 30,
              char_space: 0,
              line_space: 0,
              font: "fonts/GoogleSans-Regular.ttf",
              color: 0x89a3ab,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "--",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            //
            text_pressere = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 182,
              y: 21,
              w: 170,
              h: 45,
              text_size: 30,
              char_space: 0,
              line_space: 0,
              font: "fonts/GoogleSans-Regular.ttf",
              color: 0x89a3ab,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "--",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            //
  

            // end user_script.js

            normal_pai_day_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 54,
              y: 251,
              font_array: ["mG_0.png","mG_1.png","mG_2.png","mG_3.png","mG_4.png","mG_5.png","mG_6.png","mG_7.png","mG_8.png","mG_9.png"],
              padding: false,
              h_space: -1,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.PAI_DAILY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: '0002.png',
              center_x: 178,
              center_y: 41,
              x: 3,
              y: 11,
              start_angle: -140,
              end_angle: 140,
              invalid_visible: false,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 122,
              y: 69,
              week_en: ["DG_0.png","DG_1.png","DG_2.png","DG_3.png","DG_4.png","DG_5.png","DG_6.png"],
              week_tc: ["DG_0.png","DG_1.png","DG_2.png","DG_3.png","DG_4.png","DG_5.png","DG_6.png"],
              week_sc: ["DG_0.png","DG_1.png","DG_2.png","DG_3.png","DG_4.png","DG_5.png","DG_6.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 276,
              month_startY: 69,
              month_sc_array: ["MonG_0.png","MonG_1.png","MonG_2.png","MonG_3.png","MonG_4.png","MonG_5.png","MonG_6.png","MonG_7.png","MonG_8.png","MonG_9.png","MonG_10.png","MonG_11.png"],
              month_tc_array: ["MonG_0.png","MonG_1.png","MonG_2.png","MonG_3.png","MonG_4.png","MonG_5.png","MonG_6.png","MonG_7.png","MonG_8.png","MonG_9.png","MonG_10.png","MonG_11.png"],
              month_en_array: ["MonG_0.png","MonG_1.png","MonG_2.png","MonG_3.png","MonG_4.png","MonG_5.png","MonG_6.png","MonG_7.png","MonG_8.png","MonG_9.png","MonG_10.png","MonG_11.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 212,
              day_startY: 73,
              day_sc_array: ["sekG_0.png","sekG_1.png","sekG_2.png","sekG_3.png","sekG_4.png","sekG_5.png","sekG_6.png","sekG_7.png","sekG_8.png","sekG_9.png"],
              day_tc_array: ["sekG_0.png","sekG_1.png","sekG_2.png","sekG_3.png","sekG_4.png","sekG_5.png","sekG_6.png","sekG_7.png","sekG_8.png","sekG_9.png"],
              day_en_array: ["sekG_0.png","sekG_1.png","sekG_2.png","sekG_3.png","sekG_4.png","sekG_5.png","sekG_6.png","sekG_7.png","sekG_8.png","sekG_9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 62,
              y: 326,
              font_array: ["BLG_0.png","BLG_1.png","BLG_2.png","BLG_3.png","BLG_4.png","BLG_5.png","BLG_6.png","BLG_7.png","BLG_8.png","BLG_9.png"],
              padding: false,
              h_space: -2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_direction_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 363,
              y: 127,
              image_array: ["wind_1.png","wind_2.png","wind_3.png","wind_4.png","wind_5.png","wind_6.png","wind_7.png","wind_8.png"],
              image_length: 8,
              type: hmUI.data_type.WIND_DIRECTION,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 419,
              y: 128,
              image_array: ["BLG_0.png","BLG_1.png","BLG_2.png","BLG_3.png","BLG_4.png","BLG_5.png","BLG_6.png","BLG_7.png","BLG_8.png","BLG_9.png"],
              image_length: 10,
              type: hmUI.data_type.WIND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 45,
              y: 102,
              image_array: ["moon_1.png","moon_2.png","moon_3.png","moon_4.png","moon_5.png","moon_6.png","moon_7.png","moon_8.png","moon_9.png","moon_10.png","moon_11.png","moon_12.png","moon_13.png","moon_14.png","moon_15.png","moon_16.png","moon_17.png","moon_18.png","moon_19.png","moon_20.png","moon_21.png","moon_22.png","moon_23.png","moon_24.png","moon_25.png","moon_26.png","moon_27.png","moon_28.png","moon_29.png","moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 425,
              y: 234,
              src: 'NoBT.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 426,
              y: 205,
              src: 'alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 165,
              y: 170,
              w: 150,
              h: 45,
              text_size: 26,
              char_space: 0,
              line_space: 0,
              font: 'fonts/GoogleSans-Regular.ttf',
              color: 0xFF000000,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 221,
              y: 128,
              font_array: ["BLG_0.png","BLG_1.png","BLG_2.png","BLG_3.png","BLG_4.png","BLG_5.png","BLG_6.png","BLG_7.png","BLG_8.png","BLG_9.png"],
              padding: false,
              h_space: -2,
              unit_sc: 'BLG_gr.png',
              unit_tc: 'BLG_gr.png',
              unit_en: 'BLG_gr.png',
              negative_image: 'BLG_mn.png',
              invalid_image: 'BLG_vp.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 279,
              y: 130,
              src: 'BLG_kos.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 291,
              y: 128,
              font_array: ["BLG_0.png","BLG_1.png","BLG_2.png","BLG_3.png","BLG_4.png","BLG_5.png","BLG_6.png","BLG_7.png","BLG_8.png","BLG_9.png"],
              padding: false,
              h_space: -2,
              unit_sc: 'BLG_gr.png',
              unit_tc: 'BLG_gr.png',
              unit_en: 'BLG_gr.png',
              negative_image: 'BLG_mn.png',
              invalid_image: 'BLG_vp.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 106,
              y: 128,
              font_array: ["BLG_0.png","BLG_1.png","BLG_2.png","BLG_3.png","BLG_4.png","BLG_5.png","BLG_6.png","BLG_7.png","BLG_8.png","BLG_9.png"],
              padding: false,
              h_space: -2,
              unit_sc: 'BLG_gr.png',
              unit_tc: 'BLG_gr.png',
              unit_en: 'BLG_gr.png',
              negative_image: 'BLG_mn.png',
              invalid_image: 'BLG_vp.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 169,
              y: 114,
              image_array: ["weather_0.png","weather_1.png","weather_2.png","weather_3.png","weather_4.png","weather_5.png","weather_6.png","weather_7.png","weather_8.png","weather_9.png","weather_10.png","weather_11.png","weather_12.png","weather_13.png","weather_14.png","weather_15.png","weather_16.png","weather_17.png","weather_18.png","weather_19.png","weather_20.png","weather_21.png","weather_22.png","weather_23.png","weather_24.png","weather_25.png","weather_26.png","weather_27.png","weather_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 58,
              y: 178,
              font_array: ["poG_0.png","poG_1.png","poG_2.png","poG_3.png","poG_4.png","poG_5.png","poG_6.png","poG_7.png","poG_8.png","poG_9.png"],
              padding: false,
              h_space: 0,
              dot_image: 'poG_tch.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 355,
              y: 178,
              font_array: ["poG_0.png","poG_1.png","poG_2.png","poG_3.png","poG_4.png","poG_5.png","poG_6.png","poG_7.png","poG_8.png","poG_9.png"],
              padding: false,
              h_space: 0,
              dot_image: 'poG_tch.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 54,
              y: 283,
              font_array: ["mG_0.png","mG_1.png","mG_2.png","mG_3.png","mG_4.png","mG_5.png","mG_6.png","mG_7.png","mG_8.png","mG_9.png"],
              padding: false,
              h_space: -1,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 54,
              y: 218,
              font_array: ["mG_0.png","mG_1.png","mG_2.png","mG_3.png","mG_4.png","mG_5.png","mG_6.png","mG_7.png","mG_8.png","mG_9.png"],
              padding: false,
              h_space: -1,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STAND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 180,
              y: 433,
              font_array: ["BLG_0.png","BLG_1.png","BLG_2.png","BLG_3.png","BLG_4.png","BLG_5.png","BLG_6.png","BLG_7.png","BLG_8.png","BLG_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'BLG_km.png',
              unit_tc: 'BLG_km.png',
              unit_en: 'BLG_km.png',
              dot_image: 'BLG_zp.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 324,
              y: 326,
              font_array: ["BLG_0.png","BLG_1.png","BLG_2.png","BLG_3.png","BLG_4.png","BLG_5.png","BLG_6.png","BLG_7.png","BLG_8.png","BLG_9.png"],
              padding: false,
              h_space: -2,
              unit_sc: 'BLG_k.png',
              unit_tc: 'BLG_k.png',
              unit_en: 'BLG_k.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 297,
              y: 381,
              font_array: ["poG_0.png","poG_1.png","poG_2.png","poG_3.png","poG_4.png","poG_5.png","poG_6.png","poG_7.png","poG_8.png","poG_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'poG_pr.png',
              unit_tc: 'poG_pr.png',
              unit_en: 'poG_pr.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 156,
              y: 376,
              font_array: ["sekG_0.png","sekG_1.png","sekG_2.png","sekG_3.png","sekG_4.png","sekG_5.png","sekG_6.png","sekG_7.png","sekG_8.png","sekG_9.png"],
              padding: true,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 81,
              hour_startY: 202,
              hour_array: ["hourG_0.png","hourG_1.png","hourG_2.png","hourG_3.png","hourG_4.png","hourG_5.png","hourG_6.png","hourG_7.png","hourG_8.png","hourG_9.png"],
              hour_zero: 1,
              hour_space: -7,
              hour_angle: 0,
              hour_unit_sc: '0005.png',
              hour_unit_tc: '0005.png',
              hour_unit_en: '0005.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 248,
              minute_startY: 202,
              minute_array: ["hourG_0.png","hourG_1.png","hourG_2.png","hourG_3.png","hourG_4.png","hourG_5.png","hourG_6.png","hourG_7.png","hourG_8.png","hourG_9.png"],
              minute_zero: 1,
              minute_space: -7,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 400,
              second_startY: 273,
              second_array: ["sekG_0.png","sekG_1.png","sekG_2.png","sekG_3.png","sekG_4.png","sekG_5.png","sekG_6.png","sekG_7.png","sekG_8.png","sekG_9.png"],
              second_zero: 1,
              second_space: 4,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 230,
              y: 206,
              src: 'hourGzn.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 81,
              hour_startY: 202,
              hour_array: ["hourBLG_0.png","hourBLG_1.png","hourBLG_2.png","hourBLG_3.png","hourBLG_4.png","hourBLG_5.png","hourBLG_6.png","hourBLG_7.png","hourBLG_8.png","hourBLG_9.png"],
              hour_zero: 1,
              hour_space: -7,
              hour_angle: 0,
              hour_unit_sc: '0005.png',
              hour_unit_tc: '0005.png',
              hour_unit_en: '0005.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 248,
              minute_startY: 202,
              minute_array: ["hourBLG_0.png","hourBLG_1.png","hourBLG_2.png","hourBLG_3.png","hourBLG_4.png","hourBLG_5.png","hourBLG_6.png","hourBLG_7.png","hourBLG_8.png","hourBLG_9.png"],
              minute_zero: 1,
              minute_space: -7,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 400,
              second_startY: 273,
              second_array: ["sekG_0.png","sekG_1.png","sekG_2.png","sekG_3.png","sekG_4.png","sekG_5.png","sekG_6.png","sekG_7.png","sekG_8.png","sekG_9.png"],
              second_zero: 1,
              second_space: 4,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 230,
              y: 206,
              src: 'hourBLG_zn.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 110,
              y: 366,
              w: 165,
              h: 50,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 34,
              y: 320,
              w: 84,
              h: 36,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 297,
              y: 368,
              w: 100,
              h: 47,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 164,
              y: 19,
              w: 138,
              h: 36,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 273,
              y: 204,
              w: 100,
              h: 100,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sleep_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 183,
              y: 320,
              w: 99,
              h: 37,
              type: hmUI.data_type.SLEEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 399,
              y: 265,
              w: 55,
              h: 45,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 40,
              y: 106,
              w: 67,
              h: 57,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0005.png',
              normal_src: '0005.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'FlashLightScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 123,
              y: 66,
              w: 225,
              h: 43,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0005.png',
              normal_src: '0005.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 128,
              y: 118,
              w: 225,
              h: 43,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0005.png',
              normal_src: '0005.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'WeatherScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 118,
              y: 204,
              w: 99,
              h: 100,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0005.png',
              normal_src: '0005.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'WorldClockScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            function scale_call() {
              console.log('scale_call()');

              console.log('Weather city name');
              let weatherData = weatherSensor.getForecastWeather();
              normal_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();

                console.log('resume_call.js');
                // start resume_call.js

let pressure_array = read_pressure();
let value = getPressureValue(pressure_array);
value = hPa_To_mmHg(value);
let value_str = value == 0 ? "--" : value + " мм";
text_pressere.setProperty(hmUI.prop.TEXT, value_str);
//
              updateSleepInfo();
            //
                // end resume_call.js

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

//#region functions

function read_pressure() {
    console.log("read_pressure()");
    const file_name_alt = "../../../baro_altim/pressure.dat";
    const [fs_stat, err] = hmFS.stat(file_name_alt);
    if (err == 0) {
      let file_size = fs_stat.size;
      const len = file_size / 4;
      console.log(`size_alt: ${file_size}, lenght: ${len}`)
      const fh = hmFS.open(file_name_alt, hmFS.O_RDONLY)
  
      let array_buffer = new Float32Array(len);
      hmFS.read(fh, array_buffer.buffer, 0, file_size);
      hmFS.close(fh);
      console.log(`value ${array_buffer[array_buffer.length -1]}`);
      return array_buffer;
    } else {
      console.log('err:', err)
    }
    return null;
  }
  
  function getPressureValue(pressure_array) {
    console.log("getPressureValue()");
    if(pressure_array == null || pressure_array == undefined || pressure_array.length == 0) return 0;
    let start_index = pressure_array.length - 1;
    let end_index = start_index - 30*3; // 3 часа
    if(end_index < 0) end_index = 0;
    for (let index = start_index; index >= end_index; index--) {
      if(pressure_array[index] != 0) return parseInt(pressure_array[index] / 100);
    }
    return 0;
  }
  
  function changesPressure(pressure_array) {
    console.log("changesPressure()");
    if(pressure_array == null || pressure_array == undefined || pressure_array.length == 0) return 0;
    let start_index = pressure_array.length - 1;
    let end_index = start_index - 30*3; // 3 часа
    let value = pressure_array[start_index];
    let result = 0;
    if(end_index < 0) end_index = 0;
    for (let index = start_index; index >= end_index; index--) {
      let element = pressure_array[index];
      if(element != 0) {
        if(Math.abs(value - element) > 10) { // учитываем только если разниза больше 0,1 hPa
          value = value - element;
          console.log(`element = ${element}`);
          console.log(`pressere_changes = ${value}`);
          return value;
        }
      }
    }
    return result;
  }
  
  function hPa_To_mmHg(hPa_value = 0) {
    let mmHg = Math.round(hPa_value * 0.750064);
    return mmHg;
  }
  //#endregion
  
        let text_pressere;
        //
        let btn_bezel = ''
        let bezel_num = 1
        let bezel_all = 7
        let n_bezel = ''
        let l_num = 1
        let l_all = 4
        let element_index = 1;  // Selected element index
        let element_count = 2;  // Number of elements        
        //

  
        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_wind_direction_image_progress_img_level = ''
        let normal_wind_current_text_font = ''
        let normal_humidity_current_text_font = ''
        let normal_step_current_text_font = ''
        let normal_heart_rate_text_font = ''
        let normal_calorie_current_text_font = ''
        let normal_pai_weekly_text_font = ''
        let normal_moon_image_progress_img_level = ''
        let normal_city_name_text = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_font = ''
        let normal_battery_text_text_img = ''
        let normal_battery_text_separator_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_digital_clock_img_time = ''
        let normal_image_img = ''
        let normal_uvi_icon_img = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg = ''
        let idle_battery_text_text_img = ''
        let idle_battery_text_separator_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_day = ''
        let idle_digital_clock_img_time = ''
        let idle_image_img = ''
        let normal_battery_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
            //

            function click_Bezel() {
              if(bezel_num>=bezel_all) {bezel_num=1;}
              else { bezel_num=bezel_num+1;}
              hmUI.showToast({text: "Цвет " + parseInt(bezel_num) });
                normal_background_bg_img.setProperty(hmUI.prop.SRC, "osn_" + parseInt(bezel_num) + ".png");
            } 

            //                     
            //

            function click_l() {
              if(l_num>=l_all) {l_num=1;}
              else { l_num=l_num+1;}
              hmUI.showToast({text: "Безель " + parseInt(l_num) });
                normal_image_img.setProperty(hmUI.prop.SRC, "nakl_" + parseInt(l_num) + ".png");
            } 

            //                 
            // FontName: Impact.ttf; FontSize: 28
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 349,
              h: 42,
              text_size: 28,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Impact.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.RIGHT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: Impact.ttf; FontSize: 28; Cache: full
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 33,
              h: 33,
              text_size: 28,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Impact.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.NONE,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('user_script_start.js');
            // start user_script_start.js

            let sleep_time_txt = ''
            let sleep_start_time_txt = ''
            let sleep_end_time_txt = ''
            let sleep_score_txt = ''
            let wake_time_txt = ''

            const sleep = hmSensor.createSensor(hmSensor.id.SLEEP);
            let sleepInfo = sleep.getBasicInfo();
            
            let sleepTotalTime = sleep.getTotalTime();		
            let sleepStartTime = sleepInfo.startTime;
            let sleepEndTime = sleepInfo.endTime + 1;
            let sleepScore = sleepInfo.score;

        //время пробуждений	
            let sleepStageArray = sleep.getSleepStageData();
            const modelData = sleep.getSleepStageModel();
        //		

            function updateSleepInfo() {
                sleepTotalTime = sleep.getTotalTime();
                sleepInfo = sleep.getBasicInfo();
                sleepStartTime = sleepInfo.startTime;
                if (sleepStartTime >= 24*60) {
                    sleepStartTime -= 24*60
                }
                
                sleepEndTime = sleepInfo.endTime + 1;
                if (sleepEndTime >= 24*60) {
                    sleepEndTime -= 24*60
                }

            // время пробуждений
                let wakeTime = 0;
                sleepStageArray = sleep.getSleepStageData();
                
                for (let i = 0; i < sleepStageArray.length; i++) {
                let data = sleepStageArray[i];
                if (data.model == modelData.WAKE_STAGE){
                        wakeTime += data.stop + 1 - data.start;
                }

                }
                
                sleepTotalTime -= wakeTime;
           //
                
                sleep_time_txt.setProperty(hmUI.prop.TEXT, ' ' + Math.floor(sleepTotalTime / 60).toString().padStart(2, "0") + ':' + (sleepTotalTime % 60).toString().padStart(2, "0"));
                sleep_start_time_txt.setProperty(hmUI.prop.TEXT, Math.floor(sleepStartTime / 60).toString().padStart(2, "0") + ':' + (sleepStartTime % 60).toString().padStart(2, "0"));
                sleep_end_time_txt.setProperty(hmUI.prop.TEXT, Math.floor(sleepEndTime / 60).toString().padStart(2, "0") + ':' + (sleepEndTime % 60).toString().padStart(2, "0"));
                wake_time_txt.setProperty(hmUI.prop.TEXT, 'Не спали: ' + String(wakeTime) + ' мин.');
                sleep_score_txt.setProperty(hmUI.prop.TEXT, ' ' + String(sleepScore));
            }
            // end user_script_start.js

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'osn_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('user_script.js');
            // start user_script.js
            sleep_time_txt = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 43,
              y: 285,
              w: 150,
              h: 35,
              text_size: 28,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Impact.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.RIGHT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "--",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            //
            text_pressere = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 43,
              y: 113,
              w: 150,
              h: 35,
              text_size: 28,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Impact.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.RIGHT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "--",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            //
  

            // end user_script.js

            normal_wind_direction_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 147,
              y: 90,
              image_array: ["wind_0.png","wind_1.png","wind_2.png","wind_3.png","wind_4.png","wind_5.png","wind_6.png","wind_7.png"],
              image_length: 8,
              type: hmUI.data_type.WIND_DIRECTION,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 41,
              y: 55,
              w: 150,
              h: 35,
              text_size: 28,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Impact.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.RIGHT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.WIND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 42,
              y: 143,
              w: 150,
              h: 35,
              text_size: 28,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Impact.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.RIGHT,
              align_v: hmUI.align.TOP,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 42,
              y: 313,
              w: 150,
              h: 35,
              text_size: 28,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Impact.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.RIGHT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 41,
              y: 342,
              w: 150,
              h: 35,
              text_size: 28,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Impact.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.RIGHT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 42,
              y: 371,
              w: 150,
              h: 35,
              text_size: 28,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Impact.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.RIGHT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_weekly_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 41,
              y: 400,
              w: 150,
              h: 35,
              text_size: 28,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Impact.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.RIGHT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 217,
              y: 214,
              image_array: ["moon_01.png","moon_02.png","moon_03.png","moon_04.png","moon_05.png","moon_06.png","moon_07.png","moon_08.png","moon_09.png","moon_10.png","moon_11.png","moon_12.png","moon_13.png","moon_14.png","moon_15.png","moon_16.png","moon_17.png","moon_18.png","moon_19.png","moon_20.png","moon_21.png","moon_22.png","moon_23.png","moon_24.png","moon_25.png","moon_26.png","moon_27.png","moon_28.png","moon_29.png","moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);
            normal_moon_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);  // Disable element display  

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT);
            normal_city_name_text.setProperty(hmUI.prop.MORE, {
              x: 44,
              y: 44,
              w: 392,
              h: 392,
              text_size: 28,
              char_space: 0,
              //line_space: 0,
              font: 'fonts/Impact.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "--",              
              start_angle: -200,
              end_angle: 20,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            
            
            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 127,
              y: 214,
              image_array: ["weather_0.png","weather_1.png","weather_2.png","weather_3.png","weather_4.png","weather_5.png","weather_6.png","weather_7.png","weather_8.png","weather_9.png","weather_10.png","weather_11.png","weather_12.png","weather_13.png","weather_14.png","weather_15.png","weather_16.png","weather_17.png","weather_18.png","weather_19.png","weather_20.png","weather_21.png","weather_22.png","weather_23.png","weather_24.png","weather_25.png","weather_26.png","weather_27.png","weather_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 42,
              y: 172,
              w: 150,
              h: 35,
              text_size: 28,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Impact.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.RIGHT,
              align_v: hmUI.align.TOP,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 317,
              y: 378,
              font_array: ["data_0.png","data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png"],
              padding: false,
              h_space: -2,
              unit_sc: 'data.png',
              unit_tc: 'data.png',
              unit_en: 'data.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 311,
              y: 339,
              src: 'dataBT.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 311,
              y: 101,
              week_en: ["day_0.png","day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png"],
              week_tc: ["day_0.png","day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png"],
              week_sc: ["day_0.png","day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 318,
              day_startY: 69,
              day_sc_array: ["data_0.png","data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png"],
              day_tc_array: ["data_0.png","data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png"],
              day_en_array: ["data_0.png","data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 318,
              hour_startY: 139,
              hour_array: ["H_0.png","H_1.png","H_2.png","H_3.png","H_4.png","H_5.png","H_6.png","H_7.png","H_8.png","H_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 318,
              minute_startY: 260,
              minute_array: ["H_0.png","H_1.png","H_2.png","H_3.png","H_4.png","H_5.png","H_6.png","H_7.png","H_8.png","H_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 363,
              second_startY: 224,
              second_array: ["sekk_0.png","sekk_1.png","sekk_2.png","sekk_3.png","sekk_4.png","sekk_5.png","sekk_6.png","sekk_7.png","sekk_8.png","sekk_9.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'nakl_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_uvi_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'sekosn_1-2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_uvi_icon_img.setProperty(hmUI.prop.VISIBLE, false);  // Disable element display

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hour.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 32,
              hour_posY: 238,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.VISIBLE, false);  // Disable element display

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'min.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 32,
              minute_posY: 238,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.VISIBLE, false);  // Disable element display

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'sek.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 32,
              second_posY: 238,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, false);  // Disable element display


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 317,
              y: 378,
              font_array: ["dataAOD_0.png","dataAOD_1.png","dataAOD_2.png","dataAOD_3.png","dataAOD_4.png","dataAOD_5.png","dataAOD_6.png","dataAOD_7.png","dataAOD_8.png","dataAOD_9.png"],
              padding: false,
              h_space: -2,
              unit_sc: 'dataAOD.png',
              unit_tc: 'dataAOD.png',
              unit_en: 'dataAOD.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 311,
              y: 339,
              src: 'dataBTaod.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 311,
              y: 101,
              week_en: ["dayAOD_0.png","dayAOD_1.png","dayAOD_2.png","dayAOD_3.png","dayAOD_4.png","dayAOD_5.png","dayAOD_6.png"],
              week_tc: ["dayAOD_0.png","dayAOD_1.png","dayAOD_2.png","dayAOD_3.png","dayAOD_4.png","dayAOD_5.png","dayAOD_6.png"],
              week_sc: ["dayAOD_0.png","dayAOD_1.png","dayAOD_2.png","dayAOD_3.png","dayAOD_4.png","dayAOD_5.png","dayAOD_6.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 318,
              day_startY: 69,
              day_sc_array: ["dataAOD_0.png","dataAOD_1.png","dataAOD_2.png","dataAOD_3.png","dataAOD_4.png","dataAOD_5.png","dataAOD_6.png","dataAOD_7.png","dataAOD_8.png","dataAOD_9.png"],
              day_tc_array: ["dataAOD_0.png","dataAOD_1.png","dataAOD_2.png","dataAOD_3.png","dataAOD_4.png","dataAOD_5.png","dataAOD_6.png","dataAOD_7.png","dataAOD_8.png","dataAOD_9.png"],
              day_en_array: ["dataAOD_0.png","dataAOD_1.png","dataAOD_2.png","dataAOD_3.png","dataAOD_4.png","dataAOD_5.png","dataAOD_6.png","dataAOD_7.png","dataAOD_8.png","dataAOD_9.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 318,
              hour_startY: 139,
              hour_array: ["HAOD_0.png","HAOD_1.png","HAOD_2.png","HAOD_3.png","HAOD_4.png","HAOD_5.png","HAOD_6.png","HAOD_7.png","HAOD_8.png","HAOD_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 318,
              minute_startY: 260,
              minute_array: ["HAOD_0.png","HAOD_1.png","HAOD_2.png","HAOD_3.png","HAOD_4.png","HAOD_5.png","HAOD_6.png","HAOD_7.png","HAOD_8.png","HAOD_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 363,
              second_startY: 224,
              second_array: ["sekk_0.png","sekk_1.png","sekk_2.png","sekk_3.png","sekk_4.png","sekk_5.png","sekk_6.png","sekk_7.png","sekk_8.png","sekk_9.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 321,
              y: 227,
              src: 'tchkAOD.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 322,
              y: 350,
              w: 53,
              h: 57,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 123,
              y: 208,
              w: 59,
              h: 63,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 340,
              y: 272,
              w: 62,
              h: 58,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 337,
              y: 152,
              w: 65,
              h: 56,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'clean.png',
              normal_src: 'clean.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'FlashLightScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 325,
              y: 76,
              w: 51,
              h: 56,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'clean.png',
              normal_src: 'clean.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 218,
              y: 424,
              w: 51,
              h: 56,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'clean.png',
              normal_src: 'clean.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'SportListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 217,
              y: 1,
              w: 51,
              h: 53,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'clean.png',
              normal_src: 'clean.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'AlarmInfoScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button
            //click zona     

            function click_btn() {  // Function to enable and disable the visibility of elements
              element_index++;
              if(element_index > element_count) element_index = 1;
              normal_uvi_icon_img.setProperty(hmUI.prop.VISIBLE, element_index == 1);
              normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.VISIBLE, element_index == 1);
              normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.VISIBLE, element_index == 1);
              normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, element_index == 1);                                            
              normal_moon_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, element_index == 2);
                                                                 
                                                
              if (element_index == 1) {
                hmUI.showToast({text: 'Вид 1'});
              };
              if (element_index == 2) {
                hmUI.showToast({text: 'Вид 2'});
              };
            };


            //end click zona
            function scale_call() {
              console.log('scale_call()');

              console.log('Weather city name');
              let weatherData = weatherSensor.getForecastWeather();
              normal_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

            };

            // Button to switch elements. This block should be after all blocks with display elements.
            hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 225,  // x coordinate of the button
              y: 225,  // y coordinate of the button
              text: '',
              w: 50,  // button width
              h: 50,  // button height
              normal_src: 'clean.png',  // transparent image
              press_src: 'clean.png',  // transparent image
              show_level: hmUI.show_level.ONLY_NORMAL,
              click_func: () => {
                click_btn();
              }
            });
            // end button 
            //
            btn_bezel = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 430,
              y: 210,
              text: '',
              w: 50,
              h: 50,
              normal_src: 'clean.png',
              press_src: 'clean.png',
              click_func: () => {
               click_Bezel();
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btn_bezel.setProperty(hmUI.prop.VISIBLE, true);

            //
            n_bezel = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 4,
              y: 212,
              text: '',
              w: 50,
              h: 50,
              normal_src: 'clean.png',
              press_src: 'clean.png',
              click_func: () => {
               click_l();
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            n_bezel.setProperty(hmUI.prop.VISIBLE, true);
            //            
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();

                console.log('resume_call.js');
                // start resume_call.js

let pressure_array = read_pressure();
let value = getPressureValue(pressure_array);
value = hPa_To_mmHg(value);
let value_str = value == 0 ? "--" : value + " ";
text_pressere.setProperty(hmUI.prop.TEXT, value_str);
//
              updateSleepInfo();
            //
                // end resume_call.js

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
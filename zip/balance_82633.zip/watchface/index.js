﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_rotate_animation_img_1 = '';
        let normal_rotate_animation_param_1 = null;
        let normal_rotate_animation_lastTime_1 = 0;
        let timer_anim_rotate_1;
        let normal_rotate_animation_count_1 = 0;
        let normal_rotate_animation_img_2 = '';
        let normal_rotate_animation_param_2 = null;
        let normal_rotate_animation_lastTime_2 = 0;
        let timer_anim_rotate_2;
        let normal_rotate_animation_count_2 = 0;
        let normal_rotate_animation_img_3 = '';
        let normal_rotate_animation_param_3 = null;
        let normal_rotate_animation_lastTime_3 = 0;
        let timer_anim_rotate_3;
        let timer_anim_rotate_3_mirror = false;
        let normal_rotate_animation_param_3_mirror = null;
        let normal_rotate_animation_count_3 = 0;
        let normal_rotate_animation_img_4 = '';
        let normal_rotate_animation_param_4 = null;
        let normal_rotate_animation_lastTime_4 = 0;
        let timer_anim_rotate_4;
        let timer_anim_rotate_4_mirror = false;
        let normal_rotate_animation_param_4_mirror = null;
        let normal_rotate_animation_count_4 = 0;
        let normal_rotate_animation_img_5 = '';
        let normal_rotate_animation_param_5 = null;
        let normal_rotate_animation_lastTime_5 = 0;
        let timer_anim_rotate_5;
        let normal_rotate_animation_count_5 = 0;
        let normal_motion_animation_img_1 = '';
        let normal_motion_animation_paramX_1 = null;
        let normal_motion_animation_paramY_1 = null;
        let normal_motion_animation_lastTime_1 = 0;
        let timer_anim_motion_1;
        let normal_motion_animation_count_1 = 0;
        let normal_motion_animation_img_2 = '';
        let normal_motion_animation_paramX_2 = null;
        let normal_motion_animation_paramY_2 = null;
        let normal_motion_animation_lastTime_2 = 0;
        let timer_anim_motion_2;
        let normal_motion_animation_count_2 = 0;
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_city_name_text = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_text_separator_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_text_separator_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_year = ''
        let normal_date_year_separator_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month = ''
        let normal_date_month_separator_img = ''
        let normal_step_current_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_minute_separator_img = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_step_current_text_img = ''
        let idle_distance_text_text_img = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_minute_separator_img = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: '1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_rotate_animation_img_1 = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 481,
              h: 481,
              pos_x: 250,
              pos_y: 318,
              center_x: 286,
              center_y: 355,
              angle: 0,
              src: 'animation/anim_95.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_rotate_animation_param_1 = {
              anim_steps: [{
                anim_rate: 'linear',
                anim_duration: 10000,
                anim_from: 0,
                anim_to: 360,
                anim_key: "angle",
              }],
              anim_fps: 15,
              anim_auto_start: 1,
              anim_repeat: 1,
              anim_auto_destroy: 1,
            };

            let now = hmSensor.createSensor(hmSensor.id.TIME);

            function anim_rotate_1_complete_call() {
              normal_rotate_animation_img_1.setProperty(hmUI.prop.ANIM, normal_rotate_animation_param_1);
              normal_rotate_animation_lastTime_1 = now.utc;
              normal_rotate_animation_count_1 = normal_rotate_animation_count_1 - 1;
              if(normal_rotate_animation_count_1 < -1) normal_rotate_animation_count_1 = - 1;
              if(normal_rotate_animation_count_1 == 0) stop_anim_rotate_1();
            }; // end animation callback function
            
            function stop_anim_rotate_1() {
              if (timer_anim_rotate_1) {
                timer.stopTimer(timer_anim_rotate_1);
                timer_anim_rotate_1 = undefined;
              };
            }; // end stop_anim_rotate function

            // normal_rotate_anime_1 = hmUI.createWidget(hmUI.widget.Rotate_Animation, {
              // start_angle: 0,
              // end_angle: 360,
              // pos_x: 36,
              // pos_y: 37,
              // center_x: 286,
              // center_y: 355,
              // src: 'anim_95.png',
              // anim_fps: 15,
              // anim_duration: 10000,
              // repeat_count: 0,
              // anim_two_sides: False,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_rotate_animation_img_2 = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 481,
              h: 481,
              pos_x: 118,
              pos_y: 309,
              center_x: 173,
              center_y: 363,
              angle: 0,
              src: 'animation/anim_97.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_rotate_animation_param_2 = {
              anim_steps: [{
                anim_rate: 'linear',
                anim_duration: 45000,
                anim_from: 0,
                anim_to: 360,
                anim_key: "angle",
              }],
              anim_fps: 25,
              anim_auto_start: 1,
              anim_repeat: 1,
              anim_auto_destroy: 1,
            };

            function anim_rotate_2_complete_call() {
              normal_rotate_animation_img_2.setProperty(hmUI.prop.ANIM, normal_rotate_animation_param_2);
              normal_rotate_animation_lastTime_2 = now.utc;
              normal_rotate_animation_count_2 = normal_rotate_animation_count_2 - 1;
              if(normal_rotate_animation_count_2 < -1) normal_rotate_animation_count_2 = - 1;
              if(normal_rotate_animation_count_2 == 0) stop_anim_rotate_2();
            }; // end animation callback function
            
            function stop_anim_rotate_2() {
              if (timer_anim_rotate_2) {
                timer.stopTimer(timer_anim_rotate_2);
                timer_anim_rotate_2 = undefined;
              };
            }; // end stop_anim_rotate function

            // normal_rotate_anime_2 = hmUI.createWidget(hmUI.widget.Rotate_Animation, {
              // start_angle: 0,
              // end_angle: 360,
              // pos_x: 55,
              // pos_y: 54,
              // center_x: 173,
              // center_y: 363,
              // src: 'anim_97.png',
              // anim_fps: 25,
              // anim_duration: 45000,
              // repeat_count: 0,
              // anim_two_sides: False,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_rotate_animation_img_3 = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 481,
              h: 481,
              pos_x: 162,
              pos_y: 286,
              center_x: 239,
              center_y: 363,
              angle: 0,
              src: 'animation/anim_93.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_rotate_animation_param_3 = {
              anim_steps: [{
                anim_rate: 'linear',
                anim_duration: 10000,
                anim_from: 0,
                anim_to: 0,
                anim_key: "angle",
              }],
              anim_fps: 15,
              anim_auto_start: 1,
              anim_repeat: 1,
              anim_auto_destroy: 1,
            };

            normal_rotate_animation_param_3_mirror = {
              anim_steps: [{
                anim_rate: 'linear',
                anim_duration: 10000,
                anim_from: 0,
                anim_to: 0,
                anim_key: "angle",
              }],
              anim_fps: 15,
              anim_auto_start: 1,
              anim_repeat: 1,
              anim_auto_destroy: 1,
            };

            function anim_rotate_3_mirror() {
              normal_rotate_animation_img_3.setProperty(hmUI.prop.ANIM, normal_rotate_animation_param_3_mirror);
              normal_rotate_animation_lastTime_3 = now.utc;
              normal_rotate_animation_count_3 = normal_rotate_animation_count_3 - 1;
              if(normal_rotate_animation_count_3 < -1) normal_rotate_animation_count_3 = - 1;
              if(normal_rotate_animation_count_3 == 0) stop_anim_rotate_3();

            }; // end animation_mirror callback function

            function anim_rotate_3_complete_call() {
              normal_rotate_animation_img_3.setProperty(hmUI.prop.ANIM, normal_rotate_animation_param_3);
              normal_rotate_animation_lastTime_3 = now.utc;
            }; // end animation callback function
            
            function stop_anim_rotate_3() {
              if (timer_anim_rotate_3) {
                timer.stopTimer(timer_anim_rotate_3);
                timer_anim_rotate_3 = undefined;
              };
            }; // end stop_anim_rotate function

            // normal_rotate_anime_3 = hmUI.createWidget(hmUI.widget.Rotate_Animation, {
              // start_angle: 0,
              // end_angle: 0,
              // pos_x: 77,
              // pos_y: 77,
              // center_x: 239,
              // center_y: 363,
              // src: 'anim_93.png',
              // anim_fps: 15,
              // anim_duration: 10000,
              // repeat_count: 0,
              // anim_two_sides: True,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_rotate_animation_img_4 = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 481,
              h: 481,
              pos_x: 173,
              pos_y: 298,
              center_x: 239,
              center_y: 364,
              angle: 0,
              src: 'animation/anim_94.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_rotate_animation_param_4 = {
              anim_steps: [{
                anim_rate: 'linear',
                anim_duration: 500,
                anim_from: 0,
                anim_to: 400,
                anim_key: "angle",
              }],
              anim_fps: 25,
              anim_auto_start: 1,
              anim_repeat: 1,
              anim_auto_destroy: 1,
            };

            normal_rotate_animation_param_4_mirror = {
              anim_steps: [{
                anim_rate: 'linear',
                anim_duration: 500,
                anim_from: 400,
                anim_to: 0,
                anim_key: "angle",
              }],
              anim_fps: 25,
              anim_auto_start: 1,
              anim_repeat: 1,
              anim_auto_destroy: 1,
            };

            function anim_rotate_4_mirror() {
              normal_rotate_animation_img_4.setProperty(hmUI.prop.ANIM, normal_rotate_animation_param_4_mirror);
              normal_rotate_animation_lastTime_4 = now.utc;
              normal_rotate_animation_count_4 = normal_rotate_animation_count_4 - 1;
              if(normal_rotate_animation_count_4 < -1) normal_rotate_animation_count_4 = - 1;
              if(normal_rotate_animation_count_4 == 0) stop_anim_rotate_4();

            }; // end animation_mirror callback function

            function anim_rotate_4_complete_call() {
              normal_rotate_animation_img_4.setProperty(hmUI.prop.ANIM, normal_rotate_animation_param_4);
              normal_rotate_animation_lastTime_4 = now.utc;
            }; // end animation callback function
            
            function stop_anim_rotate_4() {
              if (timer_anim_rotate_4) {
                timer.stopTimer(timer_anim_rotate_4);
                timer_anim_rotate_4 = undefined;
              };
            }; // end stop_anim_rotate function

            // normal_rotate_anime_4 = hmUI.createWidget(hmUI.widget.Rotate_Animation, {
              // start_angle: 0,
              // end_angle: 400,
              // pos_x: 66,
              // pos_y: 66,
              // center_x: 239,
              // center_y: 364,
              // src: 'anim_94.png',
              // anim_fps: 25,
              // anim_duration: 500,
              // repeat_count: 0,
              // anim_two_sides: True,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_rotate_animation_img_5 = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 481,
              h: 481,
              pos_x: 192,
              pos_y: 294,
              center_x: 239,
              center_y: 365,
              angle: 0,
              src: 'animation/anim_96.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_rotate_animation_param_5 = {
              anim_steps: [{
                anim_rate: 'linear',
                anim_duration: 60000,
                anim_from: 0,
                anim_to: 360,
                anim_key: "angle",
              }],
              anim_fps: 15,
              anim_auto_start: 1,
              anim_repeat: 1,
              anim_auto_destroy: 1,
            };

            function anim_rotate_5_complete_call() {
              normal_rotate_animation_img_5.setProperty(hmUI.prop.ANIM, normal_rotate_animation_param_5);
              normal_rotate_animation_lastTime_5 = now.utc;
              normal_rotate_animation_count_5 = normal_rotate_animation_count_5 - 1;
              if(normal_rotate_animation_count_5 < -1) normal_rotate_animation_count_5 = - 1;
              if(normal_rotate_animation_count_5 == 0) stop_anim_rotate_5();
            }; // end animation callback function
            
            function stop_anim_rotate_5() {
              if (timer_anim_rotate_5) {
                timer.stopTimer(timer_anim_rotate_5);
                timer_anim_rotate_5 = undefined;
              };
            }; // end stop_anim_rotate function

            // normal_rotate_anime_5 = hmUI.createWidget(hmUI.widget.Rotate_Animation, {
              // start_angle: 0,
              // end_angle: 360,
              // pos_x: 47,
              // pos_y: 71,
              // center_x: 239,
              // center_y: 365,
              // src: 'anim_96.png',
              // anim_fps: 15,
              // anim_duration: 60000,
              // repeat_count: 0,
              // anim_two_sides: False,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_motion_animation_img_1 = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 479,
              h: 479,
              pos_x: 146,
              pos_y: 272,
              src: 'animation/anim_98.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_motion_animation_paramX_1 = {
              anim_steps: [{
                anim_rate: 'linear',
                anim_duration: 1000,
                anim_from: 146,
                anim_to: 146,
                anim_key: "pos_x",
              }],
              anim_fps: 15,
              anim_auto_start: 1,
              anim_repeat: 1,
              anim_auto_destroy: 1,
            };

            normal_motion_animation_paramY_1 = {
              anim_steps: [{
                anim_rate: 'linear',
                anim_duration: 1000,
                anim_from: 272,
                anim_to: 272,
                anim_key: "pos_y",
              }],
              anim_fps: 15,
              anim_auto_start: 1,
              anim_repeat: 1,
              anim_auto_destroy: 1,
            };

            function anim_motion_1_complete_call() {
              normal_motion_animation_img_1.setProperty(hmUI.prop.ANIM, normal_motion_animation_paramX_1);
              normal_motion_animation_img_1.setProperty(hmUI.prop.ANIM, normal_motion_animation_paramY_1);
                normal_motion_animation_lastTime_1 = now.utc;
              normal_motion_animation_count_1 = normal_motion_animation_count_1 - 1;
              if(normal_motion_animation_count_1 < -1) normal_motion_animation_count_1 = - 1;
              if(normal_motion_animation_count_1 == 0) stop_anim_motion_1();
            }; // end animation callback function
            
            function stop_anim_motion_1() {
              if (timer_anim_motion_1) {
                timer.stopTimer(timer_anim_motion_1);
                timer_anim_motion_1 = undefined;
              };
            }; // end stop_anim_motion function

            // normal_motion_anime_1 = hmUI.createWidget(hmUI.widget.Motion_Animation, {
              // x_start: 146,
              // y_start: 272,
              // x_end: 146,
              // y_end: 272,
              // src: 'anim_98.png',
              // anim_fps: 15,
              // anim_duration: 1000,
              // repeat_count: 0,
              // anim_two_sides: False,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_motion_animation_img_2 = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 479,
              h: 479,
              pos_x: 110,
              pos_y: 261,
              src: 'animation/anim_zd2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_motion_animation_paramX_2 = {
              anim_steps: [{
                anim_rate: 'linear',
                anim_duration: 1000,
                anim_from: 110,
                anim_to: 110,
                anim_key: "pos_x",
              }],
              anim_fps: 5,
              anim_auto_start: 1,
              anim_repeat: 1,
              anim_auto_destroy: 1,
            };

            normal_motion_animation_paramY_2 = {
              anim_steps: [{
                anim_rate: 'linear',
                anim_duration: 1000,
                anim_from: 261,
                anim_to: 261,
                anim_key: "pos_y",
              }],
              anim_fps: 5,
              anim_auto_start: 1,
              anim_repeat: 1,
              anim_auto_destroy: 1,
            };

            function anim_motion_2_complete_call() {
              normal_motion_animation_img_2.setProperty(hmUI.prop.ANIM, normal_motion_animation_paramX_2);
              normal_motion_animation_img_2.setProperty(hmUI.prop.ANIM, normal_motion_animation_paramY_2);
                normal_motion_animation_lastTime_2 = now.utc;
              normal_motion_animation_count_2 = normal_motion_animation_count_2 - 1;
              if(normal_motion_animation_count_2 < -1) normal_motion_animation_count_2 = - 1;
              if(normal_motion_animation_count_2 == 0) stop_anim_motion_2();
            }; // end animation callback function
            
            function stop_anim_motion_2() {
              if (timer_anim_motion_2) {
                timer.stopTimer(timer_anim_motion_2);
                timer_anim_motion_2 = undefined;
              };
            }; // end stop_anim_motion function

            // normal_motion_anime_2 = hmUI.createWidget(hmUI.widget.Motion_Animation, {
              // x_start: 110,
              // y_start: 261,
              // x_end: 110,
              // y_end: 261,
              // src: 'anim_zd2.png',
              // anim_fps: 5,
              // anim_duration: 1000,
              // repeat_count: 0,
              // anim_two_sides: False,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 62,
              y: 288,
              src: '130.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 339,
              y: 345,
              src: '122.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 98,
              y: 85,
              image_array: ["37.png","38.png","39.png","40.png","41.png","42.png","43.png","44.png","45.png","46.png","47.png","48.png","49.png","50.png","51.png","52.png","53.png","54.png","55.png","56.png","57.png","58.png","59.png","60.png","61.png","62.png","63.png","64.png","65.png","66.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 291,
              y: 79,
              image_array: ["67.png","68.png","69.png","70.png","71.png","72.png","73.png","74.png","75.png","76.png","77.png","78.png","79.png","80.png","81.png","82.png","83.png","84.png","85.png","86.png","87.png","88.png","89.png","90.png","91.png","92.png","93.png","94.png","95.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 354,
              y: 128,
              font_array: ["17.png","18.png","19.png","20.png","21.png","22.png","23.png","24.png","25.png","26.png"],
              padding: false,
              h_space: 1,
              unit_sc: '97.png',
              unit_tc: '97.png',
              unit_en: '97.png',
              negative_image: '96.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 293,
              y: 145,
              w: 89,
              h: 33,
              text_size: 24,
              char_space: 0,
              line_space: 0,
              color: 0xFFFF8000,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: '4.png',
              hour_centerX: 238,
              hour_centerY: 238,
              hour_posX: 25,
              hour_posY: 147,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: '5.png',
              minute_centerX: 238,
              minute_centerY: 238,
              minute_posX: 26,
              minute_posY: 214,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: '6.png',
              second_centerX: 238,
              second_centerY: 239,
              second_posX: 24,
              second_posY: 213,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 364,
              y: 240,
              font_array: ["17.png","18.png","19.png","20.png","21.png","22.png","23.png","24.png","25.png","26.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 313,
              y: 239,
              src: '118.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 367,
              y: 205,
              font_array: ["17.png","18.png","19.png","20.png","21.png","22.png","23.png","24.png","25.png","26.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 403,
              y: 207,
              src: '120.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 303,
              y: 205,
              image_array: ["98.png","99.png","100.png","101.png","102.png","103.png","104.png","105.png","106.png","107.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 263,
              day_startY: 99,
              day_sc_array: ["17.png","18.png","19.png","20.png","21.png","22.png","23.png","24.png","25.png","26.png"],
              day_tc_array: ["17.png","18.png","19.png","20.png","21.png","22.png","23.png","24.png","25.png","26.png"],
              day_en_array: ["17.png","18.png","19.png","20.png","21.png","22.png","23.png","24.png","25.png","26.png"],
              day_zero: 1,
              day_space: 1,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 188,
              year_startY: 100,
              year_sc_array: ["17.png","18.png","19.png","20.png","21.png","22.png","23.png","24.png","25.png","26.png"],
              year_tc_array: ["17.png","18.png","19.png","20.png","21.png","22.png","23.png","24.png","25.png","26.png"],
              year_en_array: ["17.png","18.png","19.png","20.png","21.png","22.png","23.png","24.png","25.png","26.png"],
              year_zero: 0,
              year_space: 0,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_year_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 215,
              y: 112,
              src: '29.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 197,
              y: 136,
              week_en: ["30.png","31.png","32.png","33.png","34.png","35.png","36.png"],
              week_tc: ["30.png","31.png","32.png","33.png","34.png","35.png","36.png"],
              week_sc: ["30.png","31.png","32.png","33.png","34.png","35.png","36.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 225,
              month_startY: 100,
              month_sc_array: ["17.png","18.png","19.png","20.png","21.png","22.png","23.png","24.png","25.png","26.png"],
              month_tc_array: ["17.png","18.png","19.png","20.png","21.png","22.png","23.png","24.png","25.png","26.png"],
              month_en_array: ["17.png","18.png","19.png","20.png","21.png","22.png","23.png","24.png","25.png","26.png"],
              month_zero: 1,
              month_space: 1,
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_month_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 253,
              y: 111,
              src: '29.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 107,
              y: 242,
              font_array: ["17.png","18.png","19.png","20.png","21.png","22.png","23.png","24.png","25.png","26.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 110,
              y: 212,
              font_array: ["17.png","18.png","19.png","20.png","21.png","22.png","23.png","24.png","25.png","26.png"],
              padding: false,
              h_space: 1,
              unit_sc: '121.png',
              unit_tc: '121.png',
              unit_en: '121.png',
              dot_image: '27.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 331,
              hour_startY: 300,
              hour_array: ["7.png","8.png","9.png","10.png","11.png","12.png","13.png","14.png","15.png","16.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 372,
              minute_startY: 300,
              minute_array: ["7.png","8.png","9.png","10.png","11.png","12.png","13.png","14.png","15.png","16.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_minute_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: '20.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: '4.png',
              hour_centerX: 238,
              hour_centerY: 238,
              hour_posX: 25,
              hour_posY: 147,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: '5.png',
              minute_centerX: 238,
              minute_centerY: 238,
              minute_posX: 26,
              minute_posY: 214,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 90,
              y: 246,
              font_array: ["17.png","18.png","19.png","20.png","21.png","22.png","23.png","24.png","25.png","26.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 78,
              y: 215,
              font_array: ["17.png","18.png","19.png","20.png","21.png","22.png","23.png","24.png","25.png","26.png"],
              padding: false,
              h_space: 1,
              unit_sc: '28.png',
              unit_tc: '28.png',
              unit_en: '28.png',
              dot_image: '27.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 340,
              hour_startY: 317,
              hour_array: ["7.png","8.png","9.png","10.png","11.png","12.png","13.png","14.png","15.png","16.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 383,
              minute_startY: 317,
              minute_array: ["7.png","8.png","9.png","10.png","11.png","12.png","13.png","14.png","15.png","16.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_minute_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: '20.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 332,
              y: 337,
              w: 60,
              h: 60,
              src: '123.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 370,
              y: 108,
              w: 71,
              h: 63,
              src: '123.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 301,
              y: 232,
              w: 95,
              h: 57,
              src: '123.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 83,
              y: 229,
              w: 90,
              h: 65,
              src: '123.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            function scale_call() {
              console.log('scale_call()');

              console.log('Weather city name');
              let weatherData = weatherSensor.getForecastWeather();
              normal_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();

                let nawAnimationTime = now.utc;;
                
                let delay_anim_rotate_1 = 0;
                let repeat_anim_rotate_1 = 10000;
                delay_anim_rotate_1 = repeat_anim_rotate_1 - (nawAnimationTime - normal_rotate_animation_lastTime_1);
                if(delay_anim_rotate_1 < 0) delay_anim_rotate_1 = 0; 
                if((nawAnimationTime - normal_rotate_animation_lastTime_1) > repeat_anim_rotate_1) {
                  normal_rotate_animation_count_1 = 0;
                  timer_anim_rotate_1_mirror = false;
                };

                if (!timer_anim_rotate_1) {
                  timer_anim_rotate_1 = timer.createTimer(delay_anim_rotate_1, repeat_anim_rotate_1, (function (option) {
                    anim_rotate_1_complete_call()
                  })); // end timer create
                };
                
                let delay_anim_rotate_2 = 0;
                let repeat_anim_rotate_2 = 45000;
                delay_anim_rotate_2 = repeat_anim_rotate_2 - (nawAnimationTime - normal_rotate_animation_lastTime_2);
                if(delay_anim_rotate_2 < 0) delay_anim_rotate_2 = 0; 
                if((nawAnimationTime - normal_rotate_animation_lastTime_2) > repeat_anim_rotate_2) {
                  normal_rotate_animation_count_2 = 0;
                  timer_anim_rotate_2_mirror = false;
                };

                if (!timer_anim_rotate_2) {
                  timer_anim_rotate_2 = timer.createTimer(delay_anim_rotate_2, repeat_anim_rotate_2, (function (option) {
                    anim_rotate_2_complete_call()
                  })); // end timer create
                };
                
                let delay_anim_rotate_3 = 0;
                let repeat_anim_rotate_3 = 10000;
                delay_anim_rotate_3 = repeat_anim_rotate_3 - (nawAnimationTime - normal_rotate_animation_lastTime_3);
                if(delay_anim_rotate_3 < 0) delay_anim_rotate_3 = 0; 
                if((nawAnimationTime - normal_rotate_animation_lastTime_3) > repeat_anim_rotate_3*2) {
                  normal_rotate_animation_count_3 = 0;
                  timer_anim_rotate_3_mirror = false;
                };

                if (!timer_anim_rotate_3) {
                  timer_anim_rotate_3 = timer.createTimer(delay_anim_rotate_3, repeat_anim_rotate_3, (function (option) {
                    if(timer_anim_rotate_3_mirror) {
                      anim_rotate_3_mirror()
                    } else {
                      anim_rotate_3_complete_call()
                    };
                    timer_anim_rotate_3_mirror = !timer_anim_rotate_3_mirror;
                  })); // end timer create
                };
                
                let delay_anim_rotate_4 = 0;
                let repeat_anim_rotate_4 = 500;
                delay_anim_rotate_4 = repeat_anim_rotate_4 - (nawAnimationTime - normal_rotate_animation_lastTime_4);
                if(delay_anim_rotate_4 < 0) delay_anim_rotate_4 = 0; 
                if((nawAnimationTime - normal_rotate_animation_lastTime_4) > repeat_anim_rotate_4*2) {
                  normal_rotate_animation_count_4 = 0;
                  timer_anim_rotate_4_mirror = false;
                };

                if (!timer_anim_rotate_4) {
                  timer_anim_rotate_4 = timer.createTimer(delay_anim_rotate_4, repeat_anim_rotate_4, (function (option) {
                    if(timer_anim_rotate_4_mirror) {
                      anim_rotate_4_mirror()
                    } else {
                      anim_rotate_4_complete_call()
                    };
                    timer_anim_rotate_4_mirror = !timer_anim_rotate_4_mirror;
                  })); // end timer create
                };
                
                let delay_anim_rotate_5 = 0;
                let repeat_anim_rotate_5 = 60000;
                delay_anim_rotate_5 = repeat_anim_rotate_5 - (nawAnimationTime - normal_rotate_animation_lastTime_5);
                if(delay_anim_rotate_5 < 0) delay_anim_rotate_5 = 0; 
                if((nawAnimationTime - normal_rotate_animation_lastTime_5) > repeat_anim_rotate_5) {
                  normal_rotate_animation_count_5 = 0;
                  timer_anim_rotate_5_mirror = false;
                };

                if (!timer_anim_rotate_5) {
                  timer_anim_rotate_5 = timer.createTimer(delay_anim_rotate_5, repeat_anim_rotate_5, (function (option) {
                    anim_rotate_5_complete_call()
                  })); // end timer create
                };
                
                let delay_anim_motion_1 = 0;
                let repeat_anim_motion_1 = 1000;
                delay_anim_motion_1 = repeat_anim_motion_1 - (nawAnimationTime - normal_motion_animation_lastTime_1);
                if(delay_anim_motion_1 < 0) delay_anim_motion_1 = 0; 
                if((nawAnimationTime - normal_motion_animation_lastTime_1) > repeat_anim_motion_1) {
                  normal_motion_animation_count_1 = 0;
                  timer_anim_motion_1_mirror = false;
                };

                if (!timer_anim_motion_1) {
                  timer_anim_motion_1 = timer.createTimer(delay_anim_motion_1, repeat_anim_motion_1, (function (option) {
                    anim_motion_1_complete_call()
                  })); // end timer create
                };
                
                let delay_anim_motion_2 = 0;
                let repeat_anim_motion_2 = 1000;
                delay_anim_motion_2 = repeat_anim_motion_2 - (nawAnimationTime - normal_motion_animation_lastTime_2);
                if(delay_anim_motion_2 < 0) delay_anim_motion_2 = 0; 
                if((nawAnimationTime - normal_motion_animation_lastTime_2) > repeat_anim_motion_2) {
                  normal_motion_animation_count_2 = 0;
                  timer_anim_motion_2_mirror = false;
                };

                if (!timer_anim_motion_2) {
                  timer_anim_motion_2 = timer.createTimer(delay_anim_motion_2, repeat_anim_motion_2, (function (option) {
                    anim_motion_2_complete_call()
                  })); // end timer create
                };

              }),
              pause_call: (function () {
                console.log('pause_call()');
                stop_anim_rotate_1();
                stop_anim_rotate_2();
                stop_anim_rotate_3();
                stop_anim_rotate_4();
                stop_anim_rotate_5();
                stop_anim_motion_1();
                stop_anim_motion_2();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
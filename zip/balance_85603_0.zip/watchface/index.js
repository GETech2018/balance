﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_heart_rate_image_progress_img_progress = ''
        let normal_heart_rate_text_text_img = ''
        let normal_wind_current_text_font = ''
        let normal_image_img = ''
        let normal_fat_burning_TextRotate = new Array(3);
        let normal_fat_burning_TextRotate_ASCIIARRAY = new Array(10);
        let normal_fat_burning_TextRotate_img_width = 22;
        let normal_uvi_current_text_font = ''
        let normal_calorie_current_text_img = ''
        let normal_altimeter_text_text_img = ''
        let normal_stress_text_text_img = ''
        let normal_pai_weekly_text_img = ''
        let normal_battery_text_text_img = ''
        let normal_humidity_text_text_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_month = ''
        let normal_temperature_high_text_img = ''
        let normal_temperature_low_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_step_current_text_img = ''
        let normal_time_hour_text_font = ''
        let normal_timerTimeUpdate = undefined;
        let normal_time_minute_text_font = ''
        let normal_time_second_text_font = ''
        let normal_sun_high_text_img = ''
        let normal_sun_low_text_img = ''
        let image_top_img = ''
        let normal_step_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_bodyTemp_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_altimeter_jumpable_img_click = ''
        let normal_stress_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_fatBurning_jumpable_img_click = ''
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            // FontName: monofonto rg.ttf; FontSize: 34
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 482,
              h: 49,
              text_size: 34,
              char_space: -1,
              line_space: 0,
              font: 'fonts/monofonto rg.ttf',
              color: 0xFF000000,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: monofonto rg.ttf; FontSize: 96
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 1239,
              h: 138,
              text_size: 96,
              char_space: -7,
              line_space: 0,
              font: 'fonts/monofonto rg.ttf',
              color: 0xFF000000,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.ScreenNormal');

            normal_heart_rate_image_progress_img_progress = hmUI.createWidget(hmUI.widget.IMG_PROGRESS, {
              x: [0,0,0,0,0,0],
              y: [0,0,0,0,0,0],
              image_array: ["bcg1.png","bcg2.png","bcg3.png","bcg4.png","bcg5.png","bcg6.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 91,
              y: 327,
              font_array: ["34_0_00.png","34_1_00.png","34_2_00.png","34_3_00.png","34_4_00.png","34_5_00.png","34_6_00.png","34_7_00.png","34_8_00.png","34_9_00.png"],
              padding: true,
              h_space: 18,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 165,
              y: 359,
              w: 150,
              h: 40,
              text_size: 34,
              char_space: -1,
              line_space: 0,
              font: 'fonts/monofonto rg.ttf',
              color: 0xFF000000,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.WIND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 289,
              y: 53,
              src: '34_0_00.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_fat_burning_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 71,
              // y: 88,
              // font_array: ["34_0_00.png","34_1_00.png","34_2_00.png","34_3_00.png","34_4_00.png","34_5_00.png","34_6_00.png","34_7_00.png","34_8_00.png","34_9_00.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: 18,
              // angle: 0,
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.FAT_BURNING,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_fat_burning_TextRotate_ASCIIARRAY[0] = '34_0_00.png';  // set of images with numbers
            normal_fat_burning_TextRotate_ASCIIARRAY[1] = '34_1_00.png';  // set of images with numbers
            normal_fat_burning_TextRotate_ASCIIARRAY[2] = '34_2_00.png';  // set of images with numbers
            normal_fat_burning_TextRotate_ASCIIARRAY[3] = '34_3_00.png';  // set of images with numbers
            normal_fat_burning_TextRotate_ASCIIARRAY[4] = '34_4_00.png';  // set of images with numbers
            normal_fat_burning_TextRotate_ASCIIARRAY[5] = '34_5_00.png';  // set of images with numbers
            normal_fat_burning_TextRotate_ASCIIARRAY[6] = '34_6_00.png';  // set of images with numbers
            normal_fat_burning_TextRotate_ASCIIARRAY[7] = '34_7_00.png';  // set of images with numbers
            normal_fat_burning_TextRotate_ASCIIARRAY[8] = '34_8_00.png';  // set of images with numbers
            normal_fat_burning_TextRotate_ASCIIARRAY[9] = '34_9_00.png';  // set of images with numbers

            //#region TextRotate
            for (let i = 0; i < 3; i++) {
              normal_fat_burning_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 71,
                center_y: 88,
                pos_x: 71,
                pos_y: 88,
                angle: 0,
                src: '34_0_00.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_fat_burning_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //#endregion
            
            const fat_burning = hmSensor.createSensor(hmSensor.id.FAT_BURRING);
            fat_burning.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            normal_uvi_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 165,
              y: 85,
              w: 150,
              h: 40,
              text_size: 34,
              char_space: -1,
              line_space: 0,
              font: 'fonts/monofonto rg.ttf',
              color: 0xFF000000,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.UVI,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 52,
              y: 122,
              font_array: ["34_0_00.png","34_1_00.png","34_2_00.png","34_3_00.png","34_4_00.png","34_5_00.png","34_6_00.png","34_7_00.png","34_8_00.png","34_9_00.png"],
              padding: true,
              h_space: 18,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 289,
              y: 122,
              font_array: ["34_0_00.png","34_1_00.png","34_2_00.png","34_3_00.png","34_4_00.png","34_5_00.png","34_6_00.png","34_7_00.png","34_8_00.png","34_9_00.png"],
              padding: true,
              h_space: 18,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 71,
              y: 362,
              font_array: ["34_0_00.png","34_1_00.png","34_2_00.png","34_3_00.png","34_4_00.png","34_5_00.png","34_6_00.png","34_7_00.png","34_8_00.png","34_9_00.png"],
              padding: true,
              h_space: 18,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STRESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_weekly_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 91,
              y: 396,
              font_array: ["34_0_00.png","34_1_00.png","34_2_00.png","34_3_00.png","34_4_00.png","34_5_00.png","34_6_00.png","34_7_00.png","34_8_00.png","34_9_00.png"],
              padding: true,
              h_space: 18,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 91,
              y: 53,
              font_array: ["34_0_00.png","34_1_00.png","34_2_00.png","34_3_00.png","34_4_00.png","34_5_00.png","34_6_00.png","34_7_00.png","34_8_00.png","34_9_00.png"],
              padding: true,
              h_space: 18,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 289,
              y: 53,
              font_array: ["34_0_00.png","34_1_00.png","34_2_00.png","34_3_00.png","34_4_00.png","34_5_00.png","34_6_00.png","34_7_00.png","34_8_00.png","34_9_00.png"],
              padding: true,
              h_space: 18,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 269,
              day_startY: 19,
              day_sc_array: ["34_0_00.png","34_1_00.png","34_2_00.png","34_3_00.png","34_4_00.png","34_5_00.png","34_6_00.png","34_7_00.png","34_8_00.png","34_9_00.png"],
              day_tc_array: ["34_0_00.png","34_1_00.png","34_2_00.png","34_3_00.png","34_4_00.png","34_5_00.png","34_6_00.png","34_7_00.png","34_8_00.png","34_9_00.png"],
              day_en_array: ["34_0_00.png","34_1_00.png","34_2_00.png","34_3_00.png","34_4_00.png","34_5_00.png","34_6_00.png","34_7_00.png","34_8_00.png","34_9_00.png"],
              day_zero: 1,
              day_space: 18,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 151,
              month_startY: 19,
              month_sc_array: ["34_0_00.png","34_1_00.png","34_2_00.png","34_3_00.png","34_4_00.png","34_5_00.png","34_6_00.png","34_7_00.png","34_8_00.png","34_9_00.png"],
              month_tc_array: ["34_0_00.png","34_1_00.png","34_2_00.png","34_3_00.png","34_4_00.png","34_5_00.png","34_6_00.png","34_7_00.png","34_8_00.png","34_9_00.png"],
              month_en_array: ["34_0_00.png","34_1_00.png","34_2_00.png","34_3_00.png","34_4_00.png","34_5_00.png","34_6_00.png","34_7_00.png","34_8_00.png","34_9_00.png"],
              month_zero: 1,
              month_space: 17,
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 289,
              y: 396,
              font_array: ["34_0_00.png","34_1_00.png","34_2_00.png","34_3_00.png","34_4_00.png","34_5_00.png","34_6_00.png","34_7_00.png","34_8_00.png","34_9_00.png"],
              padding: true,
              h_space: 18,
              negative_image: '34_-_00.png',
              invalid_image: '34_-_00.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 309,
              y: 88,
              font_array: ["34_0_00.png","34_1_00.png","34_2_00.png","34_3_00.png","34_4_00.png","34_5_00.png","34_6_00.png","34_7_00.png","34_8_00.png","34_9_00.png"],
              padding: true,
              h_space: 18,
              negative_image: '34_-_00.png',
              invalid_image: '34_-_00.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 309,
              y: 362,
              font_array: ["34_0_00.png","34_1_00.png","34_2_00.png","34_3_00.png","34_4_00.png","34_5_00.png","34_6_00.png","34_7_00.png","34_8_00.png","34_9_00.png"],
              padding: true,
              h_space: 18,
              negative_image: '34_-_00.png',
              invalid_image: '34_-_00.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 150,
              y: 430,
              font_array: ["34_0_00.png","34_1_00.png","34_2_00.png","34_3_00.png","34_4_00.png","34_5_00.png","34_6_00.png","34_7_00.png","34_8_00.png","34_9_00.png"],
              padding: true,
              h_space: 18,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            let screenType = hmSetting.getScreenType();
            normal_time_hour_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 6,
              y: 192,
              w: 150,
              h: 96,
              text_size: 96,
              char_space: -7,
              line_space: 0,
              font: 'fonts/monofonto rg.ttf',
              color: 0xFF000000,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_time_minute_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 165,
              y: 192,
              w: 150,
              h: 96,
              text_size: 96,
              char_space: -7,
              line_space: 0,
              font: 'fonts/monofonto rg.ttf',
              color: 0xFF000000,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_time_second_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 324,
              y: 192,
              w: 150,
              h: 96,
              text_size: 96,
              char_space: -7,
              line_space: 0,
              font: 'fonts/monofonto rg.ttf',
              color: 0xFF000000,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 150,
              y: 156,
              font_array: ["34_0_00.png","34_1_00.png","34_2_00.png","34_3_00.png","34_4_00.png","34_5_00.png","34_6_00.png","34_7_00.png","34_8_00.png","34_9_00.png"],
              padding: false,
              h_space: 18,
              dot_image: '34_-_00.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 150,
              y: 293,
              font_array: ["34_0_00.png","34_1_00.png","34_2_00.png","34_3_00.png","34_4_00.png","34_5_00.png","34_6_00.png","34_7_00.png","34_8_00.png","34_9_00.png"],
              padding: true,
              h_space: 18,
              dot_image: '32_-_00.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            image_top_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 230,
              y: 20,
              src: '34_-_00.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 151,
              y: 438,
              w: 175,
              h: 103,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 49,
              y: 328,
              w: 150,
              h: 30,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 83,
              y: 399,
              w: 100,
              h: 30,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 202,
              y: 136,
              w: 76,
              h: 50,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_bodyTemp_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 280,
              y: 398,
              w: 110,
              h: 30,
              type: hmUI.data_type.BODY_TEMP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 300,
              y: 332,
              w: 118,
              h: 60,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 289,
              y: 125,
              w: 170,
              h: 30,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 63,
              y: 363,
              w: 113,
              h: 30,
              type: hmUI.data_type.STRESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 181,
              y: 193,
              w: 120,
              h: 100,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 338,
              y: 191,
              w: 120,
              h: 100,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 24,
              y: 194,
              w: 120,
              h: 100,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_fatBurning_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 63,
              y: 91,
              w: 115,
              h: 30,
              type: hmUI.data_type.FAT_BURNING,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            //#region time_update
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              console.log('hour font');
              if (updateHour) {
                let normal_hourStr = format_hour.toString();
                normal_hourStr = normal_hourStr.padStart(2, '0');
                normal_time_hour_text_font.setProperty(hmUI.prop.TEXT, normal_hourStr );
              };

              console.log('minute font');
              if (updateMinute) {
                let normal_minuteStr = minute.toString();
                normal_minuteStr = normal_minuteStr.padStart(2, '0');
                normal_time_minute_text_font.setProperty(hmUI.prop.TEXT, normal_minuteStr );
              };

              console.log('second font');
                let normal_secondStr = second.toString();
                normal_secondStr = normal_secondStr.padStart(2, '0');
                normal_time_second_text_font.setProperty(hmUI.prop.TEXT, normal_secondStr );
            };

            //#endregion
            //#region text_update
            function text_update() {
              console.log('text_update()');

              console.log('update text rotate fat_burning_FAT_BURRING');
              let valueFatBurning = fat_burning.current;
              let normal_fat_burning_rotate_string = parseInt(valueFatBurning).toString();
              normal_fat_burning_rotate_string = normal_fat_burning_rotate_string.padStart(3, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  normal_fat_burning_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueFatBurning != null && valueFatBurning != undefined && isFinite(valueFatBurning) && normal_fat_burning_rotate_string.length > 0 && normal_fat_burning_rotate_string.length <= 3) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of normal_fat_burning_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_fat_burning_TextRotate[index].setProperty(hmUI.prop.POS_X, 71 + img_offset);
                      normal_fat_burning_TextRotate[index].setProperty(hmUI.prop.SRC, normal_fat_burning_TextRotate_ASCIIARRAY[charCode]);
                      normal_fat_burning_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_fat_burning_TextRotate_img_width + 18;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

            };

            //#endregion
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                time_update(true, true);
                text_update();
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerTimeUpdate) {
                    normal_timerTimeUpdate = timer.createTimer(0, 1000, (function (option) {
                      let updateHour = timeSensor.minute == 0 && timeSensor.second < 2;
                      let updateMinute = timeSensor.second < 2;
                      time_update(updateHour, updateMinute);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerTimeUpdate) {
                  timer.stopTimer(normal_timerTimeUpdate);
                  normal_timerTimeUpdate = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start
        let btn_bezel = ''
        let bezel_num = 1
        let bezel_all = 6

        let btn_bezel1 = ''
        let bezel_num1 = 1
        let bezel_all1 = 6      
        
        let btn_bezel2 = ''
        let bezel_num2 = 1
        let bezel_all2 = 5         
        
        let normal_background_bg_img = ''
        let normal_battery_circle_scale = ''
        let normal_date_img_date_week_img = ''
        let normal_image_img = ''
        let normal_system_disconnect_img = ''
        let normal_day_text_font = ''
        let normal_analog_clock_pro_hour_pointer_img = ''
        let normal_analog_clock_pro_minute_pointer_img = ''
        let normal_analog_clock_pro_second_pointer_img = ''
        let normal_timerUpdateSec = undefined;
        let idle_background_bg_img = ''
        let idle_battery_circle_scale = ''
        let idle_date_img_date_week_img = ''
        let idle_image_img = ''
        let idle_system_disconnect_img = ''
        let idle_day_text_font = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let normal_battery_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_sleep_jumpable_img_click = ''

        let normal_hour_TextRotate = new Array(2);
        let normal_hour_TextRotate_ASCIIARRAY = new Array(10);
        let normal_hour_TextRotate_img_width = 26;
        let normal_img_height = 30;
        let normal_timerTextUpdate = undefined;
        let normal_minute_TextRotate = new Array(2);
        let normal_minute_TextRotate_ASCIIARRAY = new Array(10);
        let normal_minute_TextRotate_img_width = 26;  

        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
            function click_Bezel() {
              if(bezel_num>=bezel_all) {bezel_num=1;}
              else { bezel_num=bezel_num+1;}
              hmUI.showToast({text: "Цвет " + parseInt(bezel_num) });
                normal_background_bg_img.setProperty(hmUI.prop.SRC, "osn_" + parseInt(bezel_num) + ".png");
            }   
            function click_Bezel1() {
              if(bezel_num1>=bezel_all1) {bezel_num1=1;}
              else { bezel_num1=bezel_num1+1;}
              hmUI.showToast({text: "Вид " + parseInt(bezel_num1) });
                normal_image_img.setProperty(hmUI.prop.SRC, "zapl_" + parseInt(bezel_num1) + ".png");
            }       
            function click_Bezel2() {
              if(bezel_num2>=bezel_all2) {bezel_num2=1;}
              else { bezel_num2=bezel_num2+1;}
              hmUI.showToast({text: "Цвет " + parseInt(bezel_num2) });
                normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.SRC, "hour_" + parseInt(bezel_num2) + ".png");
                normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.SRC, "sekk_" + parseInt(bezel_num2) + ".png");
            }                          
                
            // FontName: GoogleSans-Regular.ttf; FontSize: 40
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 536,
              h: 60,
              text_size: 40,
              char_space: 0,
              line_space: 0,
              font: 'fonts/GoogleSans-Regular.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'osn_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 239,
              // center_y: 400,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 36,
              // line_width: 11,
              // line_cap: Flat,
              // color: 0xFF282828,
              // mirror: False,
              // inversion: True,
              // alpha: 255,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            let screenType = hmSetting.getScreenType();
            normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 239,
              center_y: 400,
              start_angle: 360,
              end_angle: 0,
              radius: 31,
              line_width: 11,
              corner_flag: 3,
              color: 0xFF282828,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 197,
              y: 66,
              week_en: ["day_0.png","day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png"],
              week_tc: ["day_0.png","day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png"],
              week_sc: ["day_0.png","day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'zapl_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 219,
              y: 381,
              src: 'alarm.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function() {
              time_update(true);
            });

            normal_day_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 166,
              y: 35,
              w: 150,
              h: 50,
              text_size: 40,
              char_space: 0,
              font: 'fonts/GoogleSans-Regular.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const deviceInfo = hmSetting.getDeviceInfo();
            //if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.MINUTEEND, function() {
              let updateHour = timeSensor.minute == 0;

              time_update(updateHour, true);
              text_update();
            });

            // normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'hour_1.png',
              // center_x: 240,
              // center_y: 240,
              // x: 44,
              // y: 243,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.hour,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 44,
              pos_y: 240 - 243,
              center_x: 240,
              center_y: 240,
              src: 'hour_1.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'min_1.png',
              // center_x: 240,
              // center_y: 240,
              // x: 44,
              // y: 243,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.minute,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 44,
              pos_y: 240 - 243,
              center_x: 240,
              center_y: 240,
              src: 'min_1.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'sekk_1.png',
              // center_x: 240,
              // center_y: 240,
              // x: 44,
              // y: 243,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 44,
              pos_y: 240 - 243,
              center_x: 240,
              center_y: 240,
              src: 'sekk_1.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // массивы картинок для цифр
            for (let i = 0; i < 10; i++) {
              normal_hour_TextRotate_ASCIIARRAY[i] = `H_${i}.png`;
              normal_minute_TextRotate_ASCIIARRAY[i] = `H_${i}.png`;
            }

            // IMG для часов
            for (let i = 0; i < 2; i++) {
              normal_hour_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0, y: 0, w: 480, h: 480,
                center_x: 240, center_y: 240,
                src: 'H_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_hour_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            }

            // IMG для минут
            for (let i = 0; i < 2; i++) {
              normal_minute_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0, y: 0, w: 480, h: 480,
                center_x: 240, center_y: 240,
                src: 'H_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_minute_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            } 
            //let screenType = hmSetting.getScreenType();             


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'osn_1.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 239,
              // center_y: 400,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 36,
              // line_width: 11,
              // line_cap: Flat,
              // color: 0xFF282828,
              // mirror: False,
              // inversion: True,
              // alpha: 255,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 239,
              center_y: 400,
              start_angle: 360,
              end_angle: 0,
              radius: 31,
              line_width: 11,
              corner_flag: 3,
              color: 0xFF282828,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 197,
              y: 66,
              week_en: ["day_0.png","day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png"],
              week_tc: ["day_0.png","day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png"],
              week_sc: ["day_0.png","day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'zapl_5.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 219,
              y: 381,
              src: 'alarm.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_day_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 166,
              y: 35,
              w: 150,
              h: 50,
              text_size: 40,
              char_space: 0,
              font: 'fonts/GoogleSans-Regular.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hour_AOD.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 44,
              hour_posY: 243,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'min_AOD.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 44,
              minute_posY: 243,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 215,
              y: 371,
              w: 49,
              h: 57,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 389,
              y: 316,
              w: 61,
              h: 61,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 317,
              y: 397,
              w: 61,
              h: 61,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 102,
              y: 393,
              w: 61,
              h: 61,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 211,
              y: 45,
              w: 59,
              h: 57,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sleep_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 25,
              y: 318,
              w: 61,
              h: 61,
              type: hmUI.data_type.SLEEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            btn_bezel = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 0,
              y: 210,
              text: '',
              w: 50,
              h: 50,
              normal_src: 'clean.png',
              press_src: 'clean.png',
              click_func: () => {
               click_Bezel();
               
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btn_bezel.setProperty(hmUI.prop.VISIBLE, true); 
            
            btn_bezel1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 430,
              y: 210,
              text: '',
              w: 50,
              h: 50,
              normal_src: 'clean.png',
              press_src: 'clean.png',
              click_func: () => {
               click_Bezel1();
               
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btn_bezel1.setProperty(hmUI.prop.VISIBLE, true);    
            
            btn_bezel2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 218,
              y: 215,
              text: '',
              w: 50,
              h: 50,
              normal_src: 'clean.png',
              press_src: 'clean.png',
              click_func: () => {
               click_Bezel2();
               
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btn_bezel2.setProperty(hmUI.prop.VISIBLE, true);             

            //#region time_update
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              console.log('day font');
              if (updateHour) {
                let normal_dayStr = timeSensor.day.toString();
                normal_day_text_font.setProperty(hmUI.prop.TEXT, normal_dayStr );
              };

              if (updateMinute) { // Hour Pointer
                let normal_hour = hour;
                let normal_fullAngle_hour = 360;
                if (normal_hour > 11) normal_hour -= 12;
                let normal_angle_hour = 0 + normal_fullAngle_hour*normal_hour/12 + (normal_fullAngle_hour/12)*minute/60;
                if (normal_analog_clock_pro_hour_pointer_img) normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_hour);
              };

              if (updateMinute) { // Minute Pointer
                let normal_fullAngle_minute = 360;
                let normal_angle_minute = 0 + normal_fullAngle_minute*minute/60;
                if (normal_analog_clock_pro_minute_pointer_img) normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_minute);
              };

              // Second Pointer
              let normal_fullAngle_second = 360;
              let normal_angle_second = 0 + normal_fullAngle_second*second/60;
              if (normal_analog_clock_pro_second_pointer_img) normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_second);

              console.log('day font');
              if (updateHour) {
                let idle_dayStr = timeSensor.day.toString();
                idle_day_text_font.setProperty(hmUI.prop.TEXT, idle_dayStr );
              };

            };

            function text_update() {
              if (screenType == hmSetting.screen_type.AOD) return;
              let valueHour = timeSensor.format_hour;
              let valueMinute = timeSensor.minute;
              let valueSecond = timeSensor.second;

              // угол минутной стрелки
              let angle = valueMinute * 6;
              let rad = angle * Math.PI / 180;

              // направление стрелки
              let dx = Math.sin(rad);
              let dy = -Math.cos(rad);

              // радиус до центра блока (подгони под длину стрелки)
              let R = 74;

              // точка привязки блока (центр строки)
              let baseX = 240 + R * dx;
              let baseY = 240 + R * dy;

              // строка HHMM
              let hourStr = String(valueHour).padStart(2, '0');
              let minStr = String(valueMinute).padStart(2, '0');
              let fullStr = hourStr + minStr;

              // угол для блока
              let displayAngle = (valueMinute < 30 ? angle - 90 : angle + 90);

              // ширина строки
              let extra_space = 12; // Задайте здесь желаемый отступ в пикселях между часами и минутами
              let totalWidth = (fullStr.length * normal_hour_TextRotate_img_width) + extra_space; // Учитываем отступ в общей ширине
              let initialOffset = -totalWidth / 2;
              let offset = initialOffset;

              let displayRad = displayAngle * Math.PI / 180;
              let cos = Math.cos(displayRad);
              let sin = Math.sin(displayRad);
              let centerX = 240;
              let centerY = 240;
              let width = normal_hour_TextRotate_img_width;
              let height = normal_img_height;

              // Вычисляем перпендикулярное направление для сдвига
              let perpX = -sin; // Перпендикуляр к направлению строки
              let perpY = cos;

              // Фиксированный сдвиг для центрирования цифры по высоте (верхний левый -> центр)
              let fixedShift = -height / 2;

              // Переменный сдвиг для корректировки расстояния (max при 0/30, min при 15/45)
              let cosAbs = Math.abs(Math.cos(rad));
              let maxShift = 0; // Подгони значение max расстояния
              let minShift = 0;
              let variableShift = minShift + (maxShift - minShift) * cosAbs;

              // Общий сдвиг (можно изменить знак для направления)
              let shiftAmount = fixedShift + variableShift;

              // Применяем сдвиг к base
              baseX += shiftAmount * perpX;
              baseY += shiftAmount * perpY;

              // отрисовка
              for (let i = 0; i < fullStr.length; i++) {
                let charCode = fullStr.charCodeAt(i) - 48;
                if (charCode >= 0 && charCode <= 9) {
                  // desired top-left D
                  let desired_D_x = baseX + offset * cos;
                  let desired_D_y = baseY + offset * sin;

                  // vector from rotation center
                  let vx = desired_D_x - centerX;
                  let vy = desired_D_y - centerY;

                  // apply inverse rotation: R(-displayAngle)
                  let pre_vx = cos * vx + sin * vy;
                  let pre_vy = -sin * vx + cos * vy;

                  let pre_pos_x = centerX + pre_vx;
                  let pre_pos_y = centerY + pre_vy;

                  let pos_x = Math.round(pre_pos_x);
                  let pos_y = Math.round(pre_pos_y);

                  let widget = (i < 2 ? normal_hour_TextRotate[i] : normal_minute_TextRotate[i - 2]);

                  widget.setProperty(hmUI.prop.POS_X, pos_x);
                  widget.setProperty(hmUI.prop.POS_Y, pos_y);
                  widget.setProperty(hmUI.prop.SRC, normal_hour_TextRotate_ASCIIARRAY[charCode]);
                  widget.setProperty(hmUI.prop.ANGLE, displayAngle);
                  widget.setProperty(hmUI.prop.VISIBLE, true);

                  offset += width;
                  if (i === 1) { // Добавляем отступ после второй цифры часов (перед минутами)
                    offset += extra_space;
                  }
                }
              }
            }              

            //#endregion
            function scale_call() {
              console.log('scale_call()');

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_cs_normal_battery = 1 - progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_battery * 100);
                  if (normal_battery_circle_scale) {
                    normal_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 239,
                      center_y: 400,
                      start_angle: 360,
                      end_angle: 0,
                      radius: 31,
                      line_width: 11,
                      corner_flag: 3,
                      color: 0xFF282828,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales BATTERY');
                let progress_cs_idle_battery = 1 - progressBattery;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_battery_circle_scale_circle_scale
                  let level = Math.round(progress_cs_idle_battery * 100);
                  if (idle_battery_circle_scale) {
                    idle_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 239,
                      center_y: 400,
                      start_angle: 360,
                      end_angle: 0,
                      radius: 31,
                      line_width: 11,
                      corner_flag: 3,
                      color: 0xFF282828,
                      show_level: hmUI.show_level.ONLY_AOD,
                      level: level,
                    });
                  };
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                time_update(true, true);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSec) {
                    let animDelay = timeSensor.utc % 1000;
                    let animRepeat = 1000;
                    normal_timerUpdateSec = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, false);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                text_update();


              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerUpdateSec) {
                  timer.stopTimer(normal_timerUpdateSec);
                  normal_timerUpdateSec = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
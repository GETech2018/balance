﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);
        let normal_altimeter_current_text_font = ''
        let normal_wind_current_text_font_pr = ''
        let normal_Rain_current_text_font = ''
		
        let normal_temperature_max_min_text_font_pr = ''
        let normal_temperature_current_text_font_pr = ''
        let normal_block_bg = ''
        let btn_block_off = ''
        let normal_temperature_Feels_text_font = ''
        let normal_humidity_current_text_font_pr = ''
        let normal_analog_clock_time_pointer_second = ''
		
		
		
		
function loadSettings() {
    stepN = hmFS.SysProGetInt('TACT5_480_stepN') === undefined ? (hmFS.SysProSetInt('TACT5_480_stepN', 0), 0) : hmFS.SysProGetInt('TACT5_480_stepN');
    block = hmFS.SysProGetInt('TACT5_480_block') === undefined ? (hmFS.SysProSetInt('TACT5_480_block', 0), 0) : hmFS.SysProGetInt('TACT5_480_block');
    dig_time = hmFS.SysProGetInt('TACT5_480_dig_time') === undefined ? (hmFS.SysProSetInt('TACT5_480_dig_time', 0), 0) : hmFS.SysProGetInt('TACT5_480_dig_time');
    sec = hmFS.SysProGetInt('TACT5_480_sec') === undefined ? (hmFS.SysProSetInt('TACT5_480_sec', 0), 0) : hmFS.SysProGetInt('TACT5_480_sec');
}

let sec = 0
function click_sec() {
sec = (sec + 1)%7 	
hmFS.SysProSetInt('TACT5_480_sec', sec);
	
            normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.MORE, {
              second_path: 'str_s_'+sec+'.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 240,
              second_posY: 240,
              fresh_frequency: 25,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });  	
	
}	


let dig_time = 0
function click_time() {
dig_time = (dig_time + 1)%2 	
hmFS.SysProSetInt('TACT5_480_dig_time', dig_time);
	
normal_widget_text_13.setProperty(hmUI.prop.VISIBLE, dig_time == 0);	
normal_widget_text_14.setProperty(hmUI.prop.VISIBLE, dig_time == 0);
	
            normal_time_hour_min_text_font.setProperty(hmUI.prop.MORE, {
              x: 0,
              y: dig_time == 0 ? 140:122,
              w: 480,
              h: 170,
              text_size: dig_time == 0 ? 163:143,
              char_space: 0,
              font: dig_time == 0 ? 'fonts/digital_12.ttf':'fonts/din_cond_bold_3.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_time_second_text_font.setProperty(hmUI.prop.MORE, {
              x: 335,
              y: dig_time == 0 ? 147:139,
              w: 150,
              h: 100,
              text_size: dig_time == 0 ? 76:68,
              char_space: 0,
              font: dig_time == 0 ? 'fonts/digital_12.ttf':'fonts/din_cond_bold_3.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });	
	
	
}	
	
	
function progress_temp(valTemp,valMax,valMin) {
          //      let temperatureH = forecastData.data[0].high;
//                let temperatureN = forecastData.data[0].low;
	
                let valueStand = valTemp-valMin;
                let targetStand = valMax-valMin;
                let progressStand = valueStand/targetStand;
                if (progressStand > 1) progressStand = 1;
                let progress_ls_normal_stand = 1 - progressStand;

               // if (screenType != hmSetting.screen_type.AOD) {

                  // normal_stand_linear_scale
                  // initial parameters
                  let start_x_normal_stand = 210;
                  let start_y_normal_stand = 17;
                  let lenght_ls_normal_stand = 73;
                  let line_width_ls_normal_stand = 21;
                  let color_ls_normal_stand = 0xFF000000;
                  
                  // calculated parameters
                  let start_x_normal_stand_draw = start_x_normal_stand;
                  let start_y_normal_stand_draw = start_y_normal_stand;
                  lenght_ls_normal_stand = lenght_ls_normal_stand * progress_ls_normal_stand;
                  let lenght_ls_normal_stand_draw = line_width_ls_normal_stand;
                  let line_width_ls_normal_stand_draw = lenght_ls_normal_stand;
                  if (lenght_ls_normal_stand < 0){
                    line_width_ls_normal_stand_draw = -lenght_ls_normal_stand;
                    start_y_normal_stand_draw = start_y_normal_stand_draw - line_width_ls_normal_stand_draw;
                  };
                  
                  normal_stand_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_stand_draw,
                    y: start_y_normal_stand_draw,
                    w: lenght_ls_normal_stand_draw,
                    h: line_width_ls_normal_stand_draw,
                    color: color_ls_normal_stand,
                  });
}	


let block = 0	
function click_block() {
block = 1
hmFS.SysProSetInt('TACT5_480_block', block);
normal_block_bg.setProperty(hmUI.prop.VISIBLE, true);
btn_block_off.setProperty(hmUI.prop.VISIBLE, true);
normal_widget_text_12.setProperty(hmUI.prop.TEXT, '}');	
}		

function click_block_off() {
block = 0
hmFS.SysProSetInt('TACT5_480_block', block);
normal_block_bg.setProperty(hmUI.prop.VISIBLE, false);
btn_block_off.setProperty(hmUI.prop.VISIBLE, false);
normal_widget_text_12.setProperty(hmUI.prop.TEXT, '{');	
}
		
 let stepN = 0
function click_step() {
stepN = (stepN + 1) % 2
    hmFS.SysProSetInt('TACT5_480_stepN', stepN);
normal_step_current_text_font.setProperty(hmUI.prop.VISIBLE, stepN == 0);	
normal_distance_current_text_font.setProperty(hmUI.prop.VISIBLE, stepN == 1);	
normal_widget_text_2.setProperty(hmUI.prop.TEXT, stepN == 0 ? 'S':'D');

}	

function start_wg() {
normal_step_current_text_font.setProperty(hmUI.prop.VISIBLE, stepN == 0);	
normal_distance_current_text_font.setProperty(hmUI.prop.VISIBLE, stepN == 1);	
normal_widget_text_2.setProperty(hmUI.prop.TEXT, stepN == 0 ? 'S':'D');
	
normal_block_bg.setProperty(hmUI.prop.VISIBLE, block == 1);	
btn_block_off.setProperty(hmUI.prop.VISIBLE, block == 1);
normal_widget_text_12.setProperty(hmUI.prop.TEXT, block == 0 ? '{':'}');
	
normal_widget_text_13.setProperty(hmUI.prop.VISIBLE, dig_time == 0);	
normal_widget_text_14.setProperty(hmUI.prop.VISIBLE, dig_time == 0);

            normal_time_hour_min_text_font.setProperty(hmUI.prop.MORE, {
              x: 0,
              y: dig_time == 0 ? 140:122,
              w: 480,
              h: 170,
              text_size: dig_time == 0 ? 163:143,
              char_space: 0,
              font: dig_time == 0 ? 'fonts/digital_12.ttf':'fonts/din_cond_bold_3.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_time_second_text_font.setProperty(hmUI.prop.MORE, {
              x: 335,
              y: dig_time == 0 ? 147:139,
              w: 150,
              h: 100,
              text_size: dig_time == 0 ? 76:68,
              char_space: 0,
              font: dig_time == 0 ? 'fonts/digital_12.ttf':'fonts/din_cond_bold_3.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });	
	
            idle_time_hour_min_text_font.setProperty(hmUI.prop.MORE, {
              x: 0,
              y: dig_time == 0 ? 140:122,
              w: 480,
              h: 170,
              text_size: dig_time == 0 ? 163:143,
              char_space: 0,
              font: dig_time == 0 ? 'fonts/digital_12.ttf':'fonts/din_cond_bold_3.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // padding: true,
              show_level: hmUI.show_level.ONLY_AOD,
            });
	
            normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.MORE, {
              second_path: 'str_s_'+sec+'.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 240,
              second_posY: 240,
              fresh_frequency: 25,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });  	
	

}	


		// запуск приложения с заданным appId (если оно установлено) или системного приложения
function launchAppOrAppId(url, appId, page = 'page/index') {
 let appInstalled = false;
 try {
  const id16 = appId.toString(16).padStart(8, "0"); // переводим appId в 16-ричный формат
  const [fs_stat, err] = hmFS.stat_asset(`../../../js_apps/${id16}/app.json`); // проверяем наличие файла 'app.json' в папке приложения
  if (err == 0) { //  если файл есть,  то приложение установлено
   appInstalled = true;
  } else {
   console.log("err:", err);
  }
 } catch (error) {
  console.log("error:", error);
  console.log("FAIL: No access to hmFS.");
 }
 if (appInstalled) hmApp.startApp({
  appid: appId,
  url: page
 })
 else hmApp.startApp({
  url: url,
  native: true
 });
}

		


//переменные для ргафика

let isDayIcons = false

function getSunTimes(weatherData) {
  let tideData = weatherData.tideData;

  // Получение времени заката
  let sunset_hour = -1;
  let sunset_minute = -1;
  if (tideData.count > 0) {
   sunset_hour = tideData.data[0].sunset.hour;
   sunset_minute = tideData.data[0].sunset.minute;
  }

  let normal_sunset = undefined;
  if (sunset_hour >= 0 && sunset_minute >= 0) {
   normal_sunset = String(sunset_hour).padStart(2, '0') + ':' + String(sunset_minute).padStart(2, '0');
  }

  // Получение времени восхода
  let sunrise_hour = -1;
  let sunrise_minute = -1;
  if (tideData.count > 0) {
   sunrise_hour = tideData.data[0].sunrise.hour;
   sunrise_minute = tideData.data[0].sunrise.minute;
  }

  let normal_sunrise = undefined;
  if (sunrise_hour >= 0 && sunrise_minute >= 0) {
   normal_sunrise = String(sunrise_hour).padStart(2, '0') + ':' + String(sunrise_minute).padStart(2, '0');
  }

  return {
   normal_sunset_circle_string: normal_sunset,
   normal_sunrise_circle_string: normal_sunrise
  };
 }

        let normal_stand_linear_scale = ''

function autoToggleWeatherIcons() {

  let weatherData = weatherSensor.getForecastWeather();
  let tideData = weatherData.tideData;
  let forecastData = weatherData.forecastData;
	
  sunData = weatherData.tideData;
  if (sunData.count > 0) {
   today = sunData.data[0];
   sunriseMins = (today.sunrise.hour) * 60 + today.sunrise.minute;
   sunsetMins = (today.sunset.hour) * 60 + today.sunset.minute;
  } else {
   sunriseMins = sunriseMins_def;
   sunsetMins = sunsetMins_def;
  }
  curMins = timeSensor.hour * 60 + timeSensor.minute;
  let isDayNow = (curMins >= sunriseMins) && (curMins < sunsetMins);

  if (isDayNow) {
   if (!isDayIcons) {
    isDayIcons = true;
   }
  } else {
   if (isDayIcons) {
    isDayIcons = false;
   }
  }


  const {
   normal_sunset_circle_string,
   normal_sunrise_circle_string
  } = getSunTimes(weatherData);

  // СОХРАНЯЕМ ДАННЫЕ ДЛЯ AOD
  let displaySunrise = normal_sunrise_circle_string || "06:00";
  let displaySunset = normal_sunset_circle_string || "18:00";
  let displayWeatherIcon = "--";
	
 normal_widget_text_5.setProperty(hmUI.prop.TEXT, isDayIcons == false ? 'K' : 'J');
	
normal_sun_high_text_font.setProperty(hmUI.prop.VISIBLE, !isDayIcons);
normal_sun_low_text_font.setProperty(hmUI.prop.VISIBLE, isDayIcons);
	

 }



/********  класс Провайдер погоды  ********/
/******				v2.0			*******/
/******		2025 © leXxiR [4pda]	*******/

class WeatherProvider {
  constructor(props = {}) {
	this.props = {
		night_icons: [],											// индексы иконок для замены день-ночь
		index: hmFS.SysProGetInt('WeatherProviderIndex') ?? 0,		// текущий индекс провайдера (сохраняется и считывается из памяти)
		show_toast: true,											// показывать всплывающее сообщение при переключении провайдера
		use_plus_sign: true,										// отображать положительную температуру со знаком "+"
		full_wind_title: false,										// использовать полные наименования направлений ветра
		baro_unit_index: 0,											// индекс единицы измерения давления: 0 - мм рт.ст., 1 - гПа
		temp_widget: null,											// виджет TEXT для отображения температуры
		temp_max_widget: null,										// виджет TEXT для отображения максимальной температуры
		temp_min_widget: null,										// виджет TEXT для отображения минимальной температуры
		temp_feels_widget: null,									// виджет TEXT для отображения ощущаемой температуры
		description_widget: null,									// виджет TEXT для отображения текстового описания текущей погоды
		cityName_widget: null,										// виджет TEXT для отображения названия города
		wind_speed_widget: null,									// виджет TEXT для отображения скорости ветра
		wind_dir_widget: null,										// виджет TEXT для отображения названия направления ветра
		humidity_widget: null,										// виджет TEXT для отображения влажности
		pressure_widget: null,										// виджет TEXT для отображения давления
		uvi_widget: null,											// виджет TEXT для отображения УФ индекса
		chance_of_rain_widget: null,								// виджет TEXT для отображения вероятности осадков
		icon_widget: null,											// виджет IMG для отображения значка погоды
		time_sensor: null,											// сенсор времени, если не задан, то создается новый
		weather_sensor: null,										// сенсор погоды, если не задан, то создается новый
		baro_sensor: null,											// сенсор барометра, если не задан, то создается новый
		file_name: 'weather.json',									// имя файла с погодными данными
		auto_update: true,											// автоматическое обновление погоды (нет необходимости добавлять weatherProvider.update() в event.MINUTEEND и WIDGET_DELEGATE)
		lang: hmSetting.getLanguage() == 4 ? 0 : 1,					// языка устройства	(Русский = 0 / Английский = 1)
		...props,
	};

	this.providers = [
					{name: ['Zepp', 'Zepp'], appId: null},							// 0
					{name: ['Погодный сервис', 'Weather service'], appId: 1065824},	// 1
					{name: ['RWeather', 'RWeather'], appId: 1066654},				// 2
				]

	this.description = [
			['Облачно', 'Временами дождь', 'Временами снег', 'Ясно', 'Пасмурно', 'Слабый дождь', 'Слабый снег', 'Умеренный дождь', 'Умеренный снег', 'Сильный снегопад', 'Сильный дождь', 'Песчаная буря', 'Мокрый снег', 'Туман', 'Дымка', 'Дождь с грозой', 'Метель', 'Пыльно', 'Ливень', 'Дождь с градом', 'Сильный дождь с градом', 'Сильный дождь', 'Пыльная буря', 'Сильная песчаная буря', 'Сильный дождь', 'Обновите погоду', 'Облачно ночью', 'Дождливо ночью', 'Ясно ночью'],
			['Cloudy', 'Showers', 'Snow Showers', 'Sunny', 'Overcast', 'Light Rain', 'Light Snow', 'Moderate Rain', 'Moderate Snow', 'Heavy Snow', 'Heavy Rain', 'Sandstorm', 'Rain and Snow', 'Fog', 'Hazy', 'T-Storms', 'Snowstorm', 'Floating dust', 'Very Heavy Rainstorm', 'Rain and Hail', 'T-Storms and Hail', 'Heavy Rainstorm', 'Dust', 'Heavy sand storm', 'Rainstorm', 'Unknown', 'Cloudy Nighttime', 'Showers Nighttime', 'Sunny Nighttime'],
		]

	this.windTitles = [
	  [
	   ['С', 'N'],
	   ['СВ', 'NE'],
	   ['В', 'E'],
	   ['ЮВ', 'SE'],
	   ['Ю', 'S'],
	   ['ЮЗ', 'SW'],
	   ['З', 'W'],
	   ['СЗ', 'NW'],
	  ],
	  [
	   ['Северный', 'North'],
	   ['Северо-Восточный', 'Northeast'],
	   ['Восточный', 'East'],
	   ['Юго-Восточный', 'Southeast'],
	   ['Южный', 'South'],
	   ['Юго-Западный', 'Southwest'],
	   ['Западный', 'West'],
	   ['Северо-Западный', 'Northwest'],
	  ]
	]


	this.last = {
		weatherIcon: 25,
		weatherDescription:  'Нет данных',
		temperature: '--',
		temperatureFeels: '--',
		temperatureMax: '--',
		temperatureMin: '--',
		cityName: '--',
		windSpeed: '',
		windDirection: '--',		// направление ветра (в градусах)
		windTitle: '--',			// название направления ветра
		humidity: '--',
		pressure: '--',
		uvi: '--',
		chanceOfRain: '--',
		modTime: null,
	}

	if (!this.props.time_sensor) this.props.time_sensor = hmSensor.createSensor(hmSensor.id.TIME);
	if (!this.props.weather_sensor) this.props.weather_sensor = hmSensor.createSensor(hmSensor.id.WEATHER);
	if (!this.props.baro_sensor) this.props.baro_sensor = hmSensor.createSensor(hmSensor.id.BARO);
	if (isFinite(props.index)) hmFS.SysProSetInt('WeatherProviderIndex', props.index);
	if (this.props.auto_update) this.createHandlers();
  }

// создание обработчиков автоматического обновления погоды
	createHandlers() {
		this.props.time_sensor.addEventListener(this.props.time_sensor.event.MINUTEEND, () => this.update());

		this.widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
		  resume_call: ( () => this.update() )
		})
	}

// служебные функции
	arrayBufferToCyrillic(buffer) {
	  let result = '';
	  const bytes = new Uint8Array(buffer);

	  let i = 0;
	  while (i < bytes.length) {
		let byte1 = bytes[i++];
		
		if (byte1 < 0x80) {								// Обработка 1-байтовых символов (ASCII)
		  result += String.fromCharCode(byte1);
		} else if (byte1 >= 0xC0 && byte1 < 0xE0) {		// Обработка 2-байтовых символов (UTF-8 кодировка для кириллицы)
		  let byte2 = bytes[i++];
		  let charCode = ((byte1 & 0x1F) << 6) | (byte2 & 0x3F);
		  result += String.fromCharCode(charCode);
		} else if (byte1 >= 0xE0 && byte1 < 0xF0) {		// Обработка 3-байтовых символов (например, для UTF-8)
		  let byte2 = bytes[i++];
		  let byte3 = bytes[i++];
		  let charCode = ((byte1 & 0x0F) << 12) | ((byte2 & 0x3F) << 6) | (byte3 & 0x3F);
		  result += String.fromCharCode(charCode);
		}
	  }

	  return result
	}

// чтение погодных данных из файла
	readFile(app_id) {
	  if (!app_id) return null				
	  let str_result = "";
	  try {
		const [fs_stat, err] = hmFS.stat(this.props.file_name, {
		  appid: app_id,
		});
		if (err == 0) {
		  const fh = hmFS.open(this.props.file_name, hmFS.O_RDONLY, {
			appid: app_id,
		  });

		  const len = fs_stat.size;
		  let array_buffer = new ArrayBuffer(len);
		  hmFS.read(fh, array_buffer, 0, len);
		  hmFS.close(fh);
		  str_result = this.arrayBufferToCyrillic(array_buffer);

		  return str_result;
		} else {
		  console.log("err:", err);
		}
	  } catch (error) {
		console.log("error:", error);
		console.log("FAIL: No access to hmFS.");
	  }
	  return null;
	}

// получить время последнего изменеия файла
	getFileModTime(app_id) {
	  if (!app_id) return null
	  try {
		const [fs_stat, err] = hmFS.stat(this.props.file_name, {
		  appid: app_id,
		});
		
		if (err == 0) {
		  return fs_stat.mtime
		} else {
		  console.log("ModTime err:", err);
		}
	  } catch (error) {
		console.log("ModTime error:", error);
		console.log("FAIL: No access to hmFS.");
	  }
		return null
	}

// проверка времени суток: возвращает true, если сейчас день
	isDayNow() {
		const sunData = this.props.weather_sensor.getForecastWeather().tideData;
		let sunriseMins = 8 * 60;			// время восхода
		let sunsetMins = 20 * 60;			// и заката по умолчанию

		if (sunData.length > 0){
			const today = sunData.data[0];
			sunriseMins = today.sunrise.hour * 60 + today.sunrise.minute;
			sunsetMins = today.sunset.hour * 60 + today.sunset.minute;
		}

		const curMins = curTime.hour * 60 + curTime.minute;
		const nowIsDay = (curMins >= sunriseMins) && (curMins < sunsetMins);

		return nowIsDay
	}


// сопоставление индекса иконки погоды из приложений WeatherService и RuWeather с иконками погоды от Zepp 
	getZeppIconIndex(index, app_id = null) {
		
		if (!app_id)  return index;			//	если нет app_id, то не меняем индекс иконки

		let newIndex = 25;
		
		if (app_id == 1065824) {					// WeatherService
			switch(index) {
			   case 1:
					newIndex = 3;
				break;
			   case 2:
					newIndex = 0;
				break;
			   case 3:
			   case 4:
					newIndex = 4;
				break;
			   case 5:
					newIndex = 1;
				break;
			   case 6:
					newIndex = 5;
				break;
			   case 7:
					newIndex = 10;
				break;
			   case 8:
					newIndex = 15;
				break;
			   case 9:
					newIndex = 6;
				break;
			   case 10:
					newIndex = 8;
				break;
			   case 11:
					newIndex = 9;
				break;
			   case 12:
					newIndex = 12;
				break;
			   case 13:
					newIndex = 13;
				break;
			   case 14:
					newIndex = 17;
				break;
			   default:
					newIndex = 25;
				break;
			}
		} else if (app_id == 1066654) {					// RuWeather
			newIndex = index - 1;
		}

		return newIndex
	}

// температура со знаком
	tempWithSign(val){
		val = parseFloat(val);
		if (!isFinite(val)) return '--'		// если на входе не число - возвращаем прочерки
		val = Math.round(val);
		if (val > 0 && this.props.use_plus_sign) val = '+' + val;
		val += '°';
		
		return val
	}

// получить значение давления с сенсора часов (в заданных единицах измерения)
	getPressureFromSensor(){
		let v = this.props.baro_sensor.pressure;
		if (!isFinite(v)) return '--'							// если на входе не число - возвращаем прочерки
		if (this.props.baro_unit_index == 0) v *= 0.750064;		// если нужно, переводим в мм рт.ст.
		return Math.round(v).toString();
	}

//получение погодных данных из Zepp
	getZeppWeatherData() {
		const iconIndex = this.props.weather_sensor.curAirIconIndex ?? 25;
		const data = {
			weatherIcon: iconIndex,
			weatherDescription:  this.description[this.props.lang][iconIndex],
			temperature: this.props.weather_sensor.current ?? '--',
			temperatureFeels: '--',
			temperatureMax: this.props.weather_sensor.high ?? '--',
			temperatureMin: this.props.weather_sensor.low ?? '--',
			cityName: this.props.weather_sensor.getForecastWeather().cityName ?? '--',
			windSpeed: '',
			windDirection: '--',
			windTitle: '--',
			humidity: '--',
			pressure: this.getPressureFromSensor(),
			uvi: '--',
			chanceOfRain: '--',
		}

		return data
	}

//получение погодных данных из файла приложения
	getAppWeatherData(app_id) {
		const data = {
			weatherIcon: 25,
			weatherDescription:  'Нет данных',
			temperature: '--',
			temperatureFeels: '--',
			temperatureMax: '--',
			temperatureMin: '--',
			cityName: '--',
			windSpeed: '',
			windDirection: '--',
			windTitle: '--',
			humidity: '--',
			pressure: '--',
			uvi: '--',
			chanceOfRain: '--',
		}

		// читаем данные из файла данных приложения
		let weather_str = this.readFile(app_id);
		let weatherJson = JSON.parse(weather_str);
  
		if (weatherJson) {
			if (isFinite(weatherJson.weatherIcon)) {		// считываем индекс иконки погоды и сразу переводим в нумерацию Zepp
			  data.weatherIcon = this.getZeppIconIndex(parseInt(weatherJson.weatherIcon), app_id);
			}

			if (weatherJson?.weatherDescriptionExtended?.length) {
			  data.weatherDescription = weatherJson.weatherDescriptionExtended;
			  data.weatherDescription = data.weatherDescription.replace(data.weatherDescription[0], data.weatherDescription[0].toUpperCase());
			} else data.weatherDescription = this.description[data.weatherIcon];

			if (isFinite(weatherJson.temperature)) {
			  data.temperature = Math.round(parseFloat(weatherJson.temperature));
			}
			
			if (isFinite(weatherJson.temperatureFeels)){
				data.temperatureFeels = Math.round(parseFloat(weatherJson.temperatureFeels));
			}
			  
			if (isFinite(weatherJson.temperatureMax)){
				data.temperatureMax = Math.round(parseFloat(weatherJson.temperatureMax));
			}
			  
			if (isFinite(weatherJson.temperatureMin)){
				data.temperatureMin = Math.round(parseFloat(weatherJson.temperatureMin));
			}
			
			if (weatherJson.city) {
			  data.cityName = weatherJson.city;
			}

			if (isFinite(weatherJson.windSpeed)){
				data.windSpeed = parseFloat(weatherJson.windSpeed).toFixed(1);			// округляем до 1 знака после заятой
				if (data.windSpeed > 10) data.windSpeed = Math.round(data.windSpeed);	// если скорость больше 10, то округляем до целого
			}

			if (isFinite(weatherJson.windDirection)){
				data.windDirection = parseInt(weatherJson.windDirection);
			}

			if (isFinite(weatherJson.humidity)){
				data.humidity = parseInt(weatherJson.humidity);
			}

			if (isFinite(weatherJson.pressure)){
				data.pressure = parseInt(weatherJson.pressure);
			}

			if (isFinite(weatherJson.uvi)){
				data.uvi = parseInt(weatherJson.uvi);
			}
			
			if (isFinite(weatherJson.chanceOfRain)){
				data.chanceOfRain = parseInt(weatherJson.chanceOfRain);
			}					
		}
		
		return data
	}

//получение погодных данных из файла приложения или Zepp
	getWeatherData(app_id = null) {
		if (!app_id) return this.getZeppWeatherData()		// если нет app_id, то получаем данные от Zepp
		else return this.getAppWeatherData(app_id);			// иначе читаем данные из файла данных приложения
	}

// обновить данные и виджеты, используя текущего провайдера
	update() {
	 let curIcon = parseInt(this.last.weatherIcon); // текущий индекс значка погоды без учета времени суток (т.е. число без "n")

	 const modTime = this.getFileModTime(this.providers[this.props.index].appId); // время изменеия файла с данными

	 if (!modTime || this.last.modTime != modTime) { // если не получено время изменеия или оно отличается от последнего времени изменеия
	  const newData = this.getWeatherData(this.providers[this.props.index].appId); // тогда читаем новые данные из файла
	  this.last.modTime = modTime;

	  let val = this.tempWithSign(newData.temperature);
	  if (val != this.last.temperature) {
	   this.last.temperature = val;
	   if (this.props.temp_widget) this.props.temp_widget.setProperty(hmUI.prop.TEXT, val);
	  }

	  val = this.tempWithSign(newData.temperatureMax);
	  if (val != this.last.temperatureMax) {
	   this.last.temperatureMax = val;
	   if (this.props.temp_max_widget) this.props.temp_max_widget.setProperty(hmUI.prop.TEXT, val);
	  }

	  val = this.tempWithSign(newData.temperatureMin);
	  if (val != this.last.temperatureMin) {
	   this.last.temperatureMin = val;
	   if (this.props.temp_min_widget) this.props.temp_min_widget.setProperty(hmUI.prop.TEXT, val);
	  }

	  val = this.tempWithSign(newData.temperatureFeels);
	  if (val != this.last.temperatureFeels) {
	   this.last.temperatureFeels = val;
	   if (this.props.temp_feels_widget) this.props.temp_feels_widget.setProperty(hmUI.prop.TEXT, val);
	  }

	  val = newData.cityName;
	  if (val != this.last.cityName) {
	   this.last.cityName = val;
	   if (this.props.cityName_widget) this.props.cityName_widget.setProperty(hmUI.prop.TEXT, val);
	  }

	  val = newData.weatherDescription;
	  if (val != this.last.weatherDescription) {
	   this.last.weatherDescription = val;
	   if (this.props.description_widget) this.props.description_widget.setProperty(hmUI.prop.TEXT, val);
	  }

	  val = newData.windSpeed;
	  if (val != this.last.windSpeed) {
	   this.last.windSpeed = val;
	   if (this.props.wind_speed_widget) this.props.wind_speed_widget.setProperty(hmUI.prop.TEXT, val.toString());
	  }

	  val = newData.windDirection;
	  if (val != this.last.windDirection) {
	   this.last.windDirection = val;
	   this.last.windTitle = this.getWindTitle(val);
	   if (this.props.wind_dir_widget) this.props.wind_dir_widget.setProperty(hmUI.prop.TEXT, this.last.windTitle);
	  }

	  val = newData.humidity;
	  if (val != this.last.humidity) {
	   this.last.humidity = val;
	   if (this.props.humidity_widget) this.props.humidity_widget.setProperty(hmUI.prop.TEXT, val + '%');
	  }

	  val = newData.uvi;
	  if (val != this.last.uvi) {
	   this.last.uvi = val;
	   if (this.props.uvi_widget) this.props.uvi_widget.setProperty(hmUI.prop.TEXT, val.toString());
	  }

	  val = newData.chanceOfRain;
	  if (val != this.last.chanceOfRain) {
	   this.last.chanceOfRain = val;
	   if (this.props.chance_of_rain_widget) this.props.chance_of_rain_widget.setProperty(hmUI.prop.TEXT, val + '%');
	  }

	  val = newData.pressure;
	  if (this.providers[this.props.index].appId == 1065824 && this.props.baro_unit_index == 0) val = Math.round(val * 0.750064) // в WeatherService давление хранится в гПа, если нунжно переводим в мм рт.ст.
	  else if (this.providers[this.props.index].appId == 1066654 && this.props.baro_unit_index == 1) val = Math.round(val * 1.33322); // в RWeather давление хранится в мм рт.ст. если нунжно переводим в гПа
	  if (!val) val = this.getPressureFromSensor(); // если значения нет - пробуме получить с барометра
	  if (val != this.last.pressure) {
	   this.last.pressure = val;
	   if (this.props.pressure_widget) this.props.pressure_widget.setProperty(hmUI.prop.TEXT, val.toString());
	  }

	  curIcon = newData.weatherIcon; // получаем текущий индекс значка погоды
	 }

	 if (this.props.night_icons.includes(curIcon) && !this.isDayNow()) { // если он в списке ночных иконок и сейчас "ночь", то добавляем суффикс 'n'
	  curIcon += 'n';
	 }

	 if (curIcon != this.last.weatherIcon) {
	  this.last.weatherIcon = curIcon;
	  if (this.props.icon_widget) this.props.icon_widget.setProperty(hmUI.prop.SRC, "w_" + curIcon + ".png");
	 }
	}

// переключить на следующего провайдера
	next(show_toast = this.props.show_toast) {
		const v = (this.props.index + 1) % this.providers.length;
		this.provider = v;
		if (show_toast) hmUI.showToast({text: this.name});
	}

// переключить на предыдующего провайдера
	prev(show_toast = this.props.show_toast) {
		const v = (this.props.index - 1 + this.providers.length) % this.providers.length;
		this.provider = v;
		if (show_toast) hmUI.showToast({text: this.name});
	}

// переключить назад или вперед
	toggle(dir, show_toast = this.props.show_toast) {
		if (dir > 0) this.next(show_toast)
		else this.prev(show_toast);
	}
	
// установить провайдера по индексу
	set provider(v) {
		this.props.index = v;
		hmFS.SysProSetInt('WeatherProviderIndex', v);
		this.update();
	}

// получить индекс текущего провайдера
	get index() {
		return this.props.index
	}

// получить название текущего провайдера
	get name() {
		return this.providers[this.props.index].name[this.props.lang]
	}

// получить название города
	get cityName() {
		return this.last.cityName
	}

// получить текущую температуру
	get temperature() {
		return this.last.temperature
	}

// получить максимальную температуру
	get temperatureMax() {
		return this.last.temperatureMax
	}

// получить минимальную температуру
	get temperatureMin() {
		return this.last.temperatureMin
	}

// получить ощущаемую температуру
	get temperatureFeels() {
		return this.last.temperatureFeels
	}

// получить описание погоды
	get weatherDescription() {
		return this.last.weatherDescription
	}

// получить скорость ветра
	get windSpeed() {
		return this.last.windSpeed
	}

// получить направление ветра
	get windDirection() {
		return this.last.windDirection
	}

// получить название направления ветра
	get windTitle() {
		return this.last.windTitle
	}

// получить название направления ветра от значения в градусах
	getWindTitle(v) {
		if(!isFinite(v)) return '--'
		v = parseInt(360 + v) % 360;		// переводим угол в диапазон 0-360
		const i = Math.round(v / 45) % 8;	// определяем индекс направления
		return this.windTitles[Number(this.props.full_wind_title)][i][this.props.lang]
	}

// получить значение УФ индекса
	get uvi() {
		return this.last.uvi
	}

// получить влажность
	get humidity() {
		return this.last.humidity
	}

// получить давление
	get pressure() {
		return this.last.pressure
	}

// получить давление с датчика часов
	get barometer() {
		return this.getPressureFromSensor()
	}

// получить вероятность осадков
	get chanceOfRain() {
		return this.last.chanceOfRain
	}


// удалить
  delete() {
	this.providers = null;
	this.props = null;
	this.last = null;
	this.description = null;
	this.windTitles = null;
	if (this.widgetDelegate) {
		hmUI.deleteWidget(this.widgetDelegate);
		this.widgetDelegate = null;
	}
  }

}




        // end user_functions.js

        let normal_background_bg = ''
        let normal_image_img = ''
        let normal_date_img_date_week_img = ''
        let normal_battery_linear_scale = ''
        let normal_battery_icon_img = ''
        let normal_battery_current_text_font = ''
        let normal_alarm_clock_current_text_font = ''
        let normal_distance_current_text_font = ''
        let normal_heart_rate_text_font = ''
        let normal_humidity_current_text_font = ''
        let normal_sun_high_text_font = ''
        let normal_sun_low_text_font = ''
        let normal_calorie_linear_scale = ''
        let normal_calorie_icon_img = ''
        let normal_calorie_current_text_font = ''
        let normal_step_linear_scale = ''
        let normal_step_icon_img = ''
        let normal_step_current_text_font = ''
        let normal_wind_current_text_font = ''
        let normal_weather_image_progress_img_level = ''
        let normal_month_name_font = ''
        let normal_Month_Array = ['ЯНВ', 'ФЕВ', 'МАР', 'АПР', 'МАЙ', 'ИЮН', 'ИЮЛ', 'АВГ', 'СЕН', 'ОКТ', 'НОЯ', 'ДЕК', ];
        let normal_day_text_font = ''
        let normal_system_disconnect_img = ''
        let normal_widget_text_1 = ''
        let normal_widget_text_2 = ''
        let normal_widget_text_3 = ''
        let normal_widget_text_4 = ''
        let normal_widget_text_5 = ''
        let normal_widget_text_6 = ''
        let normal_widget_text_7 = ''
        let normal_widget_text_8 = ''
        let normal_widget_text_9 = ''
        let normal_widget_text_10 = ''
        let normal_widget_text_11 = ''
        let normal_widget_text_12 = ''
        let normal_widget_text_13 = ''
        let normal_widget_text_14 = ''
        let normal_time_hour_min_text_font = ''
        let normal_timerTimeUpdate = undefined;
        let normal_time_second_text_font = ''
        let idle_background_bg = ''
        let idle_time_hour_min_text_font = ''
        let idle_timerTimeUpdate = undefined;
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let Button_7 = ''
        let Button_8 = ''
        let Button_9 = ''
        let Button_Switch_BG_Color = ''

        let bgColorIndex = 0;
        let bgColorList = [0xFF80FF00, 0xFF00FFFF, 0xFFFF0000, 0xFFFF8000, 0xFFFFFF00, 0xFFFFFFFF];
        let bgColorToastList = ['Фон %s', 'Фон %s', 'Фон %s', 'Фон %s', 'Фон %s', 'Фон %s'];
        const watchfaceId = hmApp.packageInfo().watchfaceId;
        
        let degreeSum = 0;
        let crownSensitivity = 70;  // crown sensitivity level
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            // FontName: inter_tight_semibold.ttf; FontSize: 34
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 474,
              h: 58,
              text_size: 34,
              char_space: 0,
              line_space: 0,
              font: 'fonts/inter_tight_semibold.ttf',
              color: 0xFFD7D7D7,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: inter_tight_semibold.ttf; FontSize: 24
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 345,
              h: 43,
              text_size: 24,
              char_space: 0,
              line_space: 0,
              font: 'fonts/inter_tight_semibold.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: inter_tight_semibold.ttf; FontSize: 30
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 415,
              h: 51,
              text_size: 30,
              char_space: 0,
              line_space: 0,
              font: 'fonts/inter_tight_semibold.ttf',
              color: 0xFFD7D7D7,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: inter_tight_semibold.ttf; FontSize: 26; Cache: full
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 31,
              h: 31,
              text_size: 26,
              char_space: 0,
              line_space: 0,
              font: 'fonts/inter_tight_semibold.ttf',
              color: 0xFFD7D7D7,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: inter_tight_semibold.ttf; FontSize: 52
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 732,
              h: 91,
              text_size: 52,
              char_space: 0,
              line_space: 0,
              font: 'fonts/inter_tight_semibold.ttf',
              color: 0xFFD7D7D7,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: ic_Sever1.ttf; FontSize: 36
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 495,
              h: 51,
              text_size: 36,
              char_space: 0,
              line_space: 0,
              font: 'fonts/ic_Sever1.ttf',
              color: 0xFFD7D7D7,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: digital_12.ttf; FontSize: 163
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 1638,
              h: 196,
              text_size: 163,
              char_space: 0,
              line_space: 0,
              font: 'fonts/digital_12.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: digital_12.ttf; FontSize: 76
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 781,
              h: 92,
              text_size: 76,
              char_space: 0,
              line_space: 0,
              font: 'fonts/digital_12.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('user_script_start.js');
            // start user_script_start.js

loadSettings();

hmUI.createWidget(hmUI.widget.TEXT, {
 x: 478,
 y: 478,
 w: 470,
 h: 51,
 text_size: 36,
 char_space: 0,
 line_space: 0,
 font: 'fonts/ic_Sever1.ttf',
 color: 0xFFD7D7D7,
 align_h: hmUI.align.CENTER_H,
 align_v: hmUI.align.CENTER_V,
 text_style: hmUI.text_style.ELLIPSIS,
 text: "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz[]{}!()=?<>@",
 show_level: hmUI.show_level.ONLY_NORMAL,
});

hmUI.createWidget(hmUI.widget.TEXT, {
 x: 478,
 y: 478,
 w: 470,
 h: 58,
 text_size: 34,
 char_space: 0,
 line_space: 0,
 font: 'fonts/inter_tight_semibold.ttf',
 color: 0xFFD7D7D7,
 align_h: hmUI.align.CENTER_H,
 align_v: hmUI.align.CENTER_V,
 text_style: hmUI.text_style.ELLIPSIS,
 text: "0123456789°-ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz[]{}!()=?<>@",
 show_level: hmUI.show_level.ONLY_NORMAL,
});

// FontName: din_cond_bold_3.ttf; FontSize: 139
hmUI.createWidget(hmUI.widget.TEXT, {
 x: 478,
 y: 478,
 w: 1557,
 h: 182,
 text_size: 143,
 char_space: 0,
 line_space: 0,
 font: 'fonts/din_cond_bold_3.ttf',
 color: 0xFFFFFFFF,
 align_h: hmUI.align.LEFT,
 align_v: hmUI.align.CENTER_V,
 text_style: hmUI.text_style.ELLIPSIS,
 text: "0123456789 _-.,:;`'%°\\/",
 show_level: hmUI.show_level.ONLY_NORMAL,
});

// FontName: din_cond_bold_3.ttf; FontSize: 66
hmUI.createWidget(hmUI.widget.TEXT, {
 x: 478,
 y: 478,
 w: 747,
 h: 86,
 text_size: 68,
 char_space: 0,
 line_space: 0,
 font: 'fonts/din_cond_bold_3.ttf',
 color: 0xFFFFFFFF,
 align_h: hmUI.align.CENTER_H,
 align_v: hmUI.align.CENTER_V,
 text_style: hmUI.text_style.ELLIPSIS,
 text: "0123456789 _-.,:;`'%°\\/",
 show_level: hmUI.show_level.ONLY_NORMAL,
});

            // end user_script_start.js

            //#region onDigitalCrown
            console.log('onDigitalCrown()');
            function onDigitalCrown() {
              setTimeout(() => {
                hmApp.registerSpinEvent(function (key, degree) {
                  if (key === hmApp.key.HOME) {
                    degreeSum += degree;
                    if (Math.abs(degreeSum) > crownSensitivity){
                      let step = degreeSum < 0 ? -1 : 1;
                      degreeSum = 0;
                      
                      console.log('SwitchBgColor use crown');
                      bgColorIndex += step;
                      bgColorIndex = bgColorIndex < 0 ? bgColorList.length + bgColorIndex : bgColorIndex % bgColorList.length;
                      hmFS.SysProSetInt(`bgColorIndex_${watchfaceId}`, bgColorIndex);
                      degreeSum = 0;
                      let toastText = bgColorToastList[bgColorIndex].replace('%s', `${bgColorIndex + 1}`);
                      if (toastText.length > 0) hmUI.showToast({text: toastText});
                      normal_background_bg.setProperty(hmUI.prop.COLOR, bgColorList[bgColorIndex]);
                      vibro(28);
                    }
                  } // key
                }) // crown
              }, 250);
            }
            //#endregion

            //#region SwitchBG_Color
            console.log('SwitchBG_Color');
            function switchBG_Color() {
              bgColorIndex++;
              if (bgColorIndex >= bgColorList.length) bgColorIndex = 0;
              hmFS.SysProSetInt(`bgColorIndex_${watchfaceId}`, bgColorIndex);
              let toastText = bgColorToastList[bgColorIndex].replace('%s', `${bgColorIndex + 1}`);
              if (toastText.length > 0) hmUI.showToast({text: toastText});
              normal_background_bg.setProperty(hmUI.prop.COLOR, bgColorList[bgColorIndex]);
              vibro(28);
            };
            //#endregion

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFF80FF00',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 34,
              y: 279,
              week_en: ["week_0.png","week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png"],
              week_tc: ["week_0.png","week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png"],
              week_sc: ["week_0.png","week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            if (screenType != hmSetting.screen_type.AOD) {
              normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);

            normal_battery_linear_scale.setAlpha(180);
            };

            // normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 248,
              // start_y: 90,
              // color: 0xFF000000,
              // lenght: -73,
              // line_width: 21,
              // line_cap: Flat,
              // vertical: True,
              // mirror: False,
              // inversion: True,
              // alpha: 180,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 247,
              y: 15,
              src: 'cap_pr.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 286,
              y: 58,
              w: 155,
              h: 41,
              text_size: 34,
              char_space: 0,
              font: 'fonts/inter_tight_semibold.ttf',
              color: 0xFFD7D7D7,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_clock_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 344,
              y: 235,
              w: 155,
              h: 41,
              text_size: 24,
              char_space: 0,
              font: 'fonts/inter_tight_semibold.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              padding: true,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 286,
              y: 374,
              w: 155,
              h: 41,
              text_size: 34,
              char_space: 0,
              font: 'fonts/inter_tight_semibold.ttf',
              color: 0xFFD7D7D7,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 103,
              y: 317,
              w: 155,
              h: 41,
              text_size: 30,
              char_space: 0,
              font: 'fonts/inter_tight_semibold.ttf',
              color: 0xFFD7D7D7,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 341,
              y: 317,
              w: 155,
              h: 41,
              text_size: 30,
              char_space: 0,
              font: 'fonts/inter_tight_semibold.ttf',
              color: 0xFFD7D7D7,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              unit_type: 1,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 209,
              y: 317,
              w: 155,
              h: 41,
              text_size: 30,
              char_space: 0,
              font: 'fonts/inter_tight_semibold.ttf',
              color: 0xFFD7D7D7,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 209,
              y: 317,
              w: 155,
              h: 41,
              text_size: 30,
              char_space: 0,
              font: 'fonts/inter_tight_semibold.ttf',
              color: 0xFFD7D7D7,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('user_script.js');
            // start user_script.js
           // if (screenType != hmSetting.screen_type.AOD) {
              normal_stand_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);

            normal_stand_linear_scale.setAlpha(180);
          //  };

/*            const stand = hmSensor.createSensor(hmSensor.id.STAND);
            stand.addEventListener(hmSensor.event.CHANGE, function() {
              autoToggleWeatherIcons();
            });*/

            normal_altimeter_current_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 255,
              y: 99,
              w: 155,
              h: 52,
              text_size: 30,
              char_space: 0,
              font: 'fonts/inter_tight_semibold.ttf',
              color: 0xFFD7D7D7,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

// экземпляр класса
//const barometer = new AdvancedBarometer({
//	widget: normal_altimeter_current_text_font,
//	//show_trend: true,
//});

//barometer.update() 			// обновить показания давления и виджет
//barometer.mmHg				// текущее значение давление в мм рт. ст.
//barometer.hPa				// текущее значение давление в гПа
//barometer.pressure			// давление в текущих единицах измерения
//barometer.unit				// название текущей единицы измерения
//barometer.unit_index			// индекс текущей единицы измерения
//barometer.trend				// тренд давления
//barometer.delete() 			// удалить

//unit_index:  0,				// текущий индекс единицы измерения (сохраняется и считывается из памяти): 0 - мм рт.ст., 1 - гПа
//show_toast: true,			// показывать всплывающее сообщение при переключении единицы измерения
//widget: null,				// виджет TEXT для отображения давления
//show_trend: true,			// показывать тренд (растет, падает) после значения давления при обновлении виджета
//time_sensor: null,			// сенсор времени (для обновления давления), если не задан, то создается новый
//auto_update: true,			// автоматическое обновление давления (нет необходимости добавлять метод .update() в event.MINUTEEND и WIDGET_DELEGATE)
//lang:  0 или 1,				// языка устройства	(Русский = 0 / Английский = 1)
//d_time: 30,				// период времени (в мин), после которого происходит переинициализация опорного давления



            normal_wind_current_text_font_pr = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 356,
              y: 99,
              w: 155,
              h: 52,
              text_size: 30,
              char_space: 0,
              font: 'fonts/inter_tight_semibold.ttf',
              color: 0xFFD7D7D7,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WIND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_Rain_current_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 341,
              y: 317,
              w: 155,
              h: 41,
              text: '--',
              text_size: 30,
              char_space: 0,
              font: 'fonts/inter_tight_semibold.ttf',
              color: 0xFFD7D7D7,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
             // type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_font_pr = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 41,
              y: 58,
              w: 155,
              h: 41,
              text_size: 34,
              text: '--',
              char_space: 0,
              font: 'fonts/inter_tight_semibold.ttf',
              color: 0xFFD7D7D7,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.RIGHT,
              unit_type: 1,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            normal_temperature_Feels_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: -4,
              y: -4,
              w: 488,
              h: 488,
              text_size: 24,
              char_space: 0,
              font: 'fonts/inter_tight_semibold.ttf',
              alpha: 180,
              color: 0xFFFFFFFF,
              // use_text_circle: true,
              start_angle: 0,
              end_angle: 90,
              mode: 0,
              // radius: 238,
              align_h: hmUI.align.CENTER_H,
              padding: true,
              unit_type: 1,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_current_text_font_pr = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 341,
              y: 317,
              w: 155,
              h: 41,
              text: '--',
              text_size: 30,
              char_space: 0,
              font: 'fonts/inter_tight_semibold.ttf',
              color: 0xFFD7D7D7,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
             // type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });



		// экземпляр класса
			const weatherProvider = new WeatherProvider({
//				night_icons: [0, 1, 2, 3, 14],
//				show_toast: false,
				temp_widget: normal_temperature_current_text_font_pr,
//				temp_max_widget: tempMaxText,
//				temp_min_widget: tempMinText,
				temp_feels_widget: normal_temperature_Feels_text_font,
				humidity_widget: normal_humidity_current_text_font_pr,
//				description_widget: descriptionText,
//				cityName_widget: cityNameText,
				//index: 1,
				wind_speed_widget: normal_wind_current_text_font_pr,
				chance_of_rain_widget: normal_Rain_current_text_font,
//				wind_dir_widget: windDirText,
				pressure_widget: normal_altimeter_current_text_font,
//				icon_widget: weatherImg,
//				time_sensor: curTime,
//				weather_sensor: weather,
			});

            normal_temperature_max_min_text_font_pr = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 98,
              y: 99,
              w: 155,
              h: 52,
              text_size: 30,
              text: String(weatherProvider.temperatureMin.replace('°', '') + "/" + weatherProvider.temperatureMax.replace('°', '')),
              char_space: 0,
              font: 'fonts/inter_tight_semibold.ttf',
              color: 0xFFD7D7D7,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_HIGH_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


			const weatherProviderName = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 327,
              y: 52,
              w: 52,
              h: 52,
              text_size: 36,
              char_space: 0,
              alpha: 128,
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              align_h: hmUI.align.CENTER_H,
              text: weatherProvider.index == 0 ? 'Zp' : weatherProvider.index == 1 ? 'En' : 'Ru',
              show_level: hmUI.show_level.ONLY_NORMAL,
			});



            // end user_script.js

            if (screenType != hmSetting.screen_type.AOD) {
              normal_calorie_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);

            normal_calorie_linear_scale.setAlpha(180);
            };

            // normal_calorie_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 210,
              // start_y: 452,
              // color: 0xFF000000,
              // lenght: -73,
              // line_width: 21,
              // line_cap: Flat,
              // vertical: True,
              // mirror: False,
              // inversion: True,
              // alpha: 180,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const calorie = hmSensor.createSensor(hmSensor.id.CALORIE);
            calorie.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 209,
              y: 378,
              src: 'cap_pr.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 42,
              y: 374,
              w: 155,
              h: 41,
              text_size: 34,
              char_space: 0,
              font: 'fonts/inter_tight_semibold.ttf',
              color: 0xFFD7D7D7,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (screenType != hmSetting.screen_type.AOD) {
              normal_step_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);

            normal_step_linear_scale.setAlpha(180);
            };

            // normal_step_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 248,
              // start_y: 452,
              // color: 0xFF000000,
              // lenght: -73,
              // line_width: 21,
              // line_cap: Flat,
              // vertical: True,
              // mirror: False,
              // inversion: True,
              // alpha: 180,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 247,
              y: 378,
              src: 'cap_pr.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 286,
              y: 374,
              w: 155,
              h: 41,
              text_size: 34,
              char_space: 0,
              font: 'fonts/inter_tight_semibold.ttf',
              color: 0xFFD7D7D7,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 356,
              y: 99,
              w: 155,
              h: 52,
              text_size: 30,
              char_space: 0,
              font: 'fonts/inter_tight_semibold.ttf',
              color: 0xFFD7D7D7,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WIND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 156,
              y: 12,
              image_array: ["w_0.png","w_1.png","w_2.png","w_3.png","w_4.png","w_5.png","w_6.png","w_7.png","w_8.png","w_9.png","w_10.png","w_11.png","w_12.png","w_13.png","w_14.png","w_15.png","w_16.png","w_17.png","w_18.png","w_19.png","w_20.png","w_21.png","w_22.png","w_23.png","w_24.png","w_25.png","w_26.png","w_27.png","w_28.png"],
              image_length: 29,
              // alpha: 215,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level.setAlpha(215);

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function() {
              time_update(true);
            });

            normal_month_name_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: -14,
              y: 210,
              w: 155,
              h: 72,
              text_size: 26,
              char_space: 0,
              font: 'fonts/inter_tight_semibold.ttf',
              color: 0xFFD7D7D7,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // padding: true,
              // unit_string: ЯНВ, ФЕВ, МАР, АПР, МАЙ, ИЮН, ИЮЛ, АВГ, СЕН, ОКТ, НОЯ, ДЕК,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_day_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: -14,
              y: 156,
              w: 155,
              h: 72,
              text_size: 52,
              char_space: 0,
              font: 'fonts/inter_tight_semibold.ttf',
              color: 0xFFD7D7D7,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 398,
              y: 221,
              src: 'stat_BT.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_1 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 275,
              y: 14,
              w: 52,
              h: 52,
              text_size: 36,
              char_space: 0,
              font: 'fonts/ic_Sever1.ttf',
              color: 0xFFD7D7D7,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              align_h: hmUI.align.CENTER_H,
              text: 'Z',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_2 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 275,
              y: 418,
              w: 52,
              h: 52,
              text_size: 36,
              char_space: 0,
              font: 'fonts/ic_Sever1.ttf',
              color: 0xFFD7D7D7,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              align_h: hmUI.align.CENTER_H,
              text: 'S',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_3 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 156,
              y: 418,
              w: 52,
              h: 52,
              text_size: 36,
              char_space: 0,
              font: 'fonts/ic_Sever1.ttf',
              color: 0xFFD7D7D7,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              align_h: hmUI.align.CENTER_H,
              text: 'C',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_4 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 297,
              y: 316,
              w: 52,
              h: 52,
              text_size: 36,
              char_space: 0,
              font: 'fonts/ic_Sever1.ttf',
              color: 0xFFD7D7D7,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              align_h: hmUI.align.CENTER_H,
              text: ']',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_5 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 165,
              y: 318,
              w: 52,
              h: 52,
              text_size: 36,
              char_space: 0,
              font: 'fonts/ic_Sever1.ttf',
              color: 0xFFD7D7D7,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              align_h: hmUI.align.CENTER_H,
              text: 'J',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_6 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 58,
              y: 318,
              w: 52,
              h: 52,
              text_size: 36,
              char_space: 0,
              font: 'fonts/ic_Sever1.ttf',
              color: 0xFFD7D7D7,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              align_h: hmUI.align.CENTER_H,
              text: 'P',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_7 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 52,
              y: 103,
              w: 52,
              h: 52,
              text_size: 36,
              char_space: 0,
              font: 'fonts/ic_Sever1.ttf',
              color: 0xFFD7D7D7,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              align_h: hmUI.align.CENTER_H,
              text: 'N',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_8 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 205,
              y: 103,
              w: 52,
              h: 52,
              text_size: 36,
              char_space: 0,
              font: 'fonts/ic_Sever1.ttf',
              color: 0xFFD7D7D7,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              align_h: hmUI.align.CENTER_H,
              text: '^',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_9 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 310,
              y: 101,
              w: 52,
              h: 52,
              text_size: 36,
              char_space: 0,
              font: 'fonts/ic_Sever1.ttf',
              color: 0xFFD7D7D7,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              align_h: hmUI.align.CENTER_H,
              text: 'W',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_10 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 72,
              y: 374,
              w: 52,
              h: 52,
              text_size: 36,
              char_space: 0,
              font: 'fonts/ic_Sever1.ttf',
              alpha: 128,
              color: 0xFFD7D7D7,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              align_h: hmUI.align.CENTER_H,
              text: 'i',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_11 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 72,
              y: 50,
              w: 52,
              h: 52,
              text_size: 36,
              char_space: 0,
              font: 'fonts/ic_Sever1.ttf',
              alpha: 128,
              color: 0xFFD7D7D7,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              align_h: hmUI.align.CENTER_H,
              text: 'y',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_12 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 374,
              y: 372,
              w: 52,
              h: 52,
              text_size: 36,
              char_space: 0,
              font: 'fonts/ic_Sever1.ttf',
              alpha: 128,
              color: 0xFFD7D7D7,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              align_h: hmUI.align.CENTER_H,
              text: '{',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_13 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 0,
              y: 140,
              w: 480,
              h: 175,
              text_size: 163,
              char_space: 0,
              font: 'fonts/digital_12.ttf',
              alpha: 40,
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.WRAP,
              align_h: hmUI.align.CENTER_H,
              text: '88:88',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_14 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 345,
              y: 147,
              w: 155,
              h: 103,
              text_size: 76,
              char_space: 0,
              font: 'fonts/digital_12.ttf',
              alpha: 40,
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.WRAP,
              align_h: hmUI.align.CENTER_H,
              text: '88',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_time_hour_min_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 0,
              y: 140,
              w: 480,
              h: 175,
              text_size: 163,
              char_space: 0,
              font: 'fonts/digital_12.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_time_second_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 345,
              y: 147,
              w: 155,
              h: 103,
              text_size: 76,
              char_space: 0,
              font: 'fonts/digital_12.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_time_hour_min_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 0,
              y: 140,
              w: 480,
              h: 175,
              text_size: 163,
              char_space: 0,
              font: 'fonts/digital_12.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // padding: true,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            console.log('user_script_beforeShortcuts.js');
            // start user_script_beforeShortcuts.js

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'str_s_'+sec+'.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 240,
              second_posY: 240,
              fresh_frequency: 25,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            // end user_script_beforeShortcuts.js

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 261,
              y: 375,
              w: 82,
              h: 82,
              text: '',
              color: 0xFFFF8C00,
              text_size: 26,
              press_src: 'AL_0.png',
              normal_src: 'AL_0.png',
              click_func: (button_widget) => {
                click_step();
vibro(28);
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 343,
              y: 52,
              w: 82,
              h: 82,
              text: '',
              color: 0xFFFF8C00,
              text_size: 26,
              press_src: 'AL_0.png',
              normal_src: 'AL_0.png',
              click_func: (button_widget) => {
                vibro(28);
weatherProvider.prev(false);
weatherProviderName.setProperty(hmUI.prop.TEXT, weatherProvider.index == 0 ? 'Zp' : weatherProvider.index == 1 ? 'En' : 'Ru');
normal_widget_text_4.setProperty(hmUI.prop.COLOR, String(weatherProvider.chanceOfRain) >= 50 ? 0xFFFF0000 : 0xFFD7D7D7);
normal_temperature_max_min_text_font_pr.setProperty(hmUI.prop.TEXT, String(weatherProvider.temperatureMin.replace('°', '') + "/" + weatherProvider.temperatureMax.replace('°', '')));
normal_wind_current_text_font.setProperty(hmUI.prop.VISIBLE, weatherProvider.index == 0 ? true:false);
progress_temp(weatherProvider.temperature.replace('°', ''),weatherProvider.temperatureMax.replace('°', ''),weatherProvider.temperatureMin.replace('°', ''))

normal_temperature_Feels_text_font.setProperty(hmUI.prop.VISIBLE, weatherProvider.index != 0 ? true:false);

normal_widget_text_4.setProperty(hmUI.prop.TEXT, weatherProvider.index == 1 ? "]":"V");
normal_Rain_current_text_font.setProperty(hmUI.prop.VISIBLE, weatherProvider.index == 1);
normal_humidity_current_text_font_pr.setProperty(hmUI.prop.VISIBLE, weatherProvider.index == 2);
normal_humidity_current_text_font.setProperty(hmUI.prop.VISIBLE, weatherProvider.index == 0);
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 131,
              y: 13,
              w: 82,
              h: 82,
              text: '',
              color: 0xFFFF8C00,
              text_size: 26,
              press_src: 'AL_0.png',
              normal_src: 'AL_0.png',
              click_func: (button_widget) => {
                launchAppOrAppId('WeatherScreen', 1051195);
vibro(28);
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 11,
              y: 171,
              w: 82,
              h: 82,
              text: '',
              color: 0xFFFF8C00,
              text_size: 26,
              press_src: 'AL_0.png',
              normal_src: 'AL_0.png',
              click_func: (button_widget) => {
                launchAppOrAppId('ScheduleCalScreen', 1057409);
vibro(28);
              }, // end func
              longpress_func: (button_widget) => {
                vibro(28);
click_time();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 125,
              y: 172,
              w: 82,
              h: 82,
              text: '',
              color: 0xFFFF8C00,
              text_size: 26,
              press_src: 'AL_0.png',
              normal_src: 'AL_0.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'CountdownAppScreen', native: true });
vibro(28);
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 272,
              y: 172,
              w: 82,
              h: 82,
              text: '',
              color: 0xFFFF8C00,
              text_size: 26,
              press_src: 'AL_0.png',
              normal_src: 'AL_0.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'AlarmInfoScreen', native: true });
vibro(28);
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_7 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 386,
              y: 172,
              w: 82,
              h: 82,
              text: '',
              color: 0xFFFF8C00,
              text_size: 26,
              press_src: 'AL_0.png',
              normal_src: 'AL_0.png',
              click_func: (button_widget) => {
                vibro(28);
click_sec();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_8 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 47,
              y: 44,
              w: 82,
              h: 82,
              text: '',
              color: 0xFFFF8C00,
              text_size: 26,
              press_src: 'AL_0.png',
              normal_src: 'AL_0.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'FindPhoneScreen', native: true });
vibro(28);
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_9 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 345,
              y: 348,
              w: 82,
              h: 82,
              text: '',
              color: 0xFFFF8C00,
              text_size: 26,
              press_src: 'AL_0.png',
              normal_src: 'AL_0.png',
              click_func: (button_widget) => {
                vibro(28);
click_block();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            console.log('Watch_Face.SwitchBG_Color');
            // Button_Switch_BG_Color = hmUI.createWidget(hmUI.widget.SwitchBG_Color, {
              // x: 50,
              // y: 341,
              // w: 80,
              // h: 80,
              // text: '',
              // color: 0xFF808080,
              // text_size: 25,
              // press_src: 'AL_0.png',
              // normal_src: 'AL_0.png',
              // color_list: 0xFF80FF00|0xFF00FFFF|0xFFFF0000|0xFFFF8000|0xFFFFFF00|0xFFFFFFFF,
              // toast_list: Фон %s|Фон %s|Фон %s|Фон %s|Фон %s|Фон %s,
              // use_crown: True,
              // use_in_AOD: False,
              // vibro: True,
            // });

            Button_Switch_BG_Color = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 50,
              y: 341,
              w: 80,
              h: 80,
              text: '',
              color: 0xFF808080,
              text_size: 25,
              press_src: 'AL_0.png',
              normal_src: 'AL_0.png',
              click_func: (button_widget) => {
                switchBG_Color();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            //#region vibrate function
            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;

            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            //#endregion

            console.log('user_script_end.js');
            // start user_script_end.js

   normal_block_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
    x: 0,
    y: 0,
    w: 480,
    h: 480,
    color: '0xFF80FF00',
    alpha: 0,
    show_level: hmUI.show_level.ONLY_NORMAL,
   });

   normal_block_bg.setProperty(hmUI.prop.VISIBLE, block == 1);

   btn_block_off = hmUI.createWidget(hmUI.widget.BUTTON, {
    x: 335,
    y: 338,
    w: 80,
    h: 80,
    text: '',
    color: 0xFFFF8C00,
    text_size: 25,
    press_src: 'AL_0.png',
    normal_src: 'AL_0.png',
    click_func: () => {
     // end func
    }, // end func
    longpress_func: () => {
     vibro(28);
     click_block_off();
    },
    show_level: hmUI.show_level.ONLY_NORMAL,
   }); // end button


   start_wg();

            // end user_script_end.js

            //#region time_update
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              console.log('month font');
              if (updateHour) {
                let normal_Month_Str = normal_Month_Array[timeSensor.month-1];
                normal_month_name_font.setProperty(hmUI.prop.TEXT, normal_Month_Str );
              };

              console.log('day font');
              if (updateHour) {
                let normal_dayStr = timeSensor.day.toString();
                normal_dayStr = normal_dayStr.padStart(2, '0');
                normal_day_text_font.setProperty(hmUI.prop.TEXT, normal_dayStr );
              };

              console.log('hour:min font');
              if (updateMinute) {
                let normal_HourMinStr = format_hour.toString();
                normal_HourMinStr = normal_HourMinStr.padStart(2, '0');
                normal_HourMinStr = normal_HourMinStr + ':' + minute.toString().padStart(2, '0');
                if (!timeSensor.is24Hour) {
                  if (hour > 11) normal_HourMinStr = 'pm ' + normal_HourMinStr
                  else normal_HourMinStr = 'am ' + normal_HourMinStr
                };
                normal_time_hour_min_text_font.setProperty(hmUI.prop.TEXT, normal_HourMinStr );
              };

              console.log('second font');
                let normal_secondStr = second.toString();
                normal_secondStr = normal_secondStr.padStart(2, '0');
                normal_time_second_text_font.setProperty(hmUI.prop.TEXT, normal_secondStr );
              console.log('hour:min font');
              if (updateMinute) {
                let idle_HourMinStr = format_hour.toString();
                idle_HourMinStr = idle_HourMinStr.padStart(2, '0');
                idle_HourMinStr = idle_HourMinStr + ':' + minute.toString().padStart(2, '0');
                if (!timeSensor.is24Hour) {
                  if (hour > 11) idle_HourMinStr = 'pm ' + idle_HourMinStr
                  else idle_HourMinStr = 'am ' + idle_HourMinStr
                };
                idle_time_hour_min_text_font.setProperty(hmUI.prop.TEXT, idle_HourMinStr );
              };

            };

            //#endregion
            function scale_call() {
              console.log('scale_call()');

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_ls_normal_battery = 1 - progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_linear_scale
                  // initial parameters
                  let start_x_normal_battery = 248;
                  let start_y_normal_battery = 17;
                  let lenght_ls_normal_battery = 73;
                  let line_width_ls_normal_battery = 21;
                  let color_ls_normal_battery = 0xFF000000;
                  
                  // calculated parameters
                  let start_x_normal_battery_draw = start_x_normal_battery;
                  let start_y_normal_battery_draw = start_y_normal_battery;
                  lenght_ls_normal_battery = lenght_ls_normal_battery * progress_ls_normal_battery;
                  let lenght_ls_normal_battery_draw = line_width_ls_normal_battery;
                  let line_width_ls_normal_battery_draw = lenght_ls_normal_battery;
                  if (lenght_ls_normal_battery < 0){
                    line_width_ls_normal_battery_draw = -lenght_ls_normal_battery;
                    start_y_normal_battery_draw = start_y_normal_battery_draw - line_width_ls_normal_battery_draw;
                  };
                  
                  normal_battery_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_battery_draw,
                    y: start_y_normal_battery_draw,
                    w: lenght_ls_normal_battery_draw,
                    h: line_width_ls_normal_battery_draw,
                    color: color_ls_normal_battery,
                  });
                };

                console.log('update scales CALORIE');
                
                let valueCalories = calorie.current;
                let targetCalories = calorie.target;
                let progressCalories = valueCalories/targetCalories;
                if (progressCalories > 1) progressCalories = 1;
                let progress_ls_normal_calorie = 1 - progressCalories;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_calorie_linear_scale
                  // initial parameters
                  let start_x_normal_calorie = 210;
                  let start_y_normal_calorie = 379;
                  let lenght_ls_normal_calorie = 73;
                  let line_width_ls_normal_calorie = 21;
                  let color_ls_normal_calorie = 0xFF000000;
                  
                  // calculated parameters
                  let start_x_normal_calorie_draw = start_x_normal_calorie;
                  let start_y_normal_calorie_draw = start_y_normal_calorie;
                  lenght_ls_normal_calorie = lenght_ls_normal_calorie * progress_ls_normal_calorie;
                  let lenght_ls_normal_calorie_draw = line_width_ls_normal_calorie;
                  let line_width_ls_normal_calorie_draw = lenght_ls_normal_calorie;
                  if (lenght_ls_normal_calorie < 0){
                    line_width_ls_normal_calorie_draw = -lenght_ls_normal_calorie;
                    start_y_normal_calorie_draw = start_y_normal_calorie_draw - line_width_ls_normal_calorie_draw;
                  };
                  
                  normal_calorie_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_calorie_draw,
                    y: start_y_normal_calorie_draw,
                    w: lenght_ls_normal_calorie_draw,
                    h: line_width_ls_normal_calorie_draw,
                    color: color_ls_normal_calorie,
                  });
                };

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_ls_normal_step = 1 - progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_linear_scale
                  // initial parameters
                  let start_x_normal_step = 248;
                  let start_y_normal_step = 379;
                  let lenght_ls_normal_step = 73;
                  let line_width_ls_normal_step = 21;
                  let color_ls_normal_step = 0xFF000000;
                  
                  // calculated parameters
                  let start_x_normal_step_draw = start_x_normal_step;
                  let start_y_normal_step_draw = start_y_normal_step;
                  lenght_ls_normal_step = lenght_ls_normal_step * progress_ls_normal_step;
                  let lenght_ls_normal_step_draw = line_width_ls_normal_step;
                  let line_width_ls_normal_step_draw = lenght_ls_normal_step;
                  if (lenght_ls_normal_step < 0){
                    line_width_ls_normal_step_draw = -lenght_ls_normal_step;
                    start_y_normal_step_draw = start_y_normal_step_draw - line_width_ls_normal_step_draw;
                  };
                  
                  normal_step_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_step_draw,
                    y: start_y_normal_step_draw,
                    w: lenght_ls_normal_step_draw,
                    h: line_width_ls_normal_step_draw,
                    color: color_ls_normal_step,
                  });
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                time_update(true, true);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerTimeUpdate) {
                    normal_timerTimeUpdate = timer.createTimer(0, 1000, (function (option) {
                      let updateHour = timeSensor.minute == 0 && timeSensor.second < 2;
                      let updateMinute = timeSensor.second < 2;
                      time_update(updateHour, updateMinute);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.AOD) {
                  if (!idle_timerTimeUpdate) {
                    idle_timerTimeUpdate = timer.createTimer(0, 1000, (function (option) {
                      let updateHour = timeSensor.minute == 0 && timeSensor.second < 2;
                      let updateMinute = timeSensor.second < 2;
                      time_update(updateHour, updateMinute);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


                //SwitchBgColor
                if (hmFS.SysProGetInt(`bgColorIndex_${watchfaceId}`) === undefined) {
                  bgColorIndex = 0;
                  hmFS.SysProSetInt(`bgColorIndex_${watchfaceId}`, bgColorIndex);
                } else {
                  bgColorIndex = hmFS.SysProGetInt(`bgColorIndex_${watchfaceId}`);
                };
                if (screenType == hmSetting.screen_type.WATCHFACE && normal_background_bg) normal_background_bg.setProperty(hmUI.prop.COLOR, bgColorList[bgColorIndex]);
                onDigitalCrown();
                console.log('resume_call.js');
                // start resume_call.js

loadSettings(); 
autoToggleWeatherIcons();

normal_widget_text_4.setProperty(hmUI.prop.COLOR, String(weatherProvider.chanceOfRain) >= 50 ? 0xFFFF0000 : 0xFFD7D7D7);

normal_temperature_max_min_text_font_pr.setProperty(hmUI.prop.TEXT, String(weatherProvider.temperatureMin.replace('°', '') + "/" + weatherProvider.temperatureMax.replace('°', '')));

normal_wind_current_text_font.setProperty(hmUI.prop.VISIBLE, weatherProvider.index == 0 ? true:false);

progress_temp(weatherProvider.temperature.replace('°', ''),weatherProvider.temperatureMax.replace('°', ''),weatherProvider.temperatureMin.replace('°', ''));

normal_temperature_Feels_text_font.setProperty(hmUI.prop.VISIBLE, weatherProvider.index != 0 ? true:false);

normal_widget_text_4.setProperty(hmUI.prop.TEXT, weatherProvider.index == 1 ? "]":"V");
normal_Rain_current_text_font.setProperty(hmUI.prop.VISIBLE, weatherProvider.index == 1);
normal_humidity_current_text_font_pr.setProperty(hmUI.prop.VISIBLE, weatherProvider.index == 2);
normal_humidity_current_text_font.setProperty(hmUI.prop.VISIBLE, weatherProvider.index == 0);



                // end resume_call.js

              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerTimeUpdate) {
                  timer.stopTimer(normal_timerTimeUpdate);
                  normal_timerTimeUpdate = undefined;
                }
                if (idle_timerTimeUpdate) {
                  timer.stopTimer(idle_timerTimeUpdate);
                  idle_timerTimeUpdate = undefined;
                }

                hmApp.unregisterSpinEvent();
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
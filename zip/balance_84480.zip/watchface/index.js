﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_calorie_icon_img = ''
        let normal_calorie_current_text_img = ''
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_battery_current_text_font = ''
        let normal_battery_image_progress_img_level = ''
        let normal_date_img_date_day = ''
        let normal_image_img = ''
        let normal_month_name_font = ''
        let normal_Month_Array = ['JANVIER', 'FEVRIER', 'MARS', 'AVRIL', 'MAI', 'JUIN', 'JUILLET', 'AOUT', 'SEPTEMBRE', 'OCTOBRE', 'NOVEMBRE', 'DECEMBRE', ];
        let normal_dow_text_font = ''
        let normal_DOW_Array = ['LUNDI', 'MARDI', 'MERCREDI', 'JEUDI', 'VENDREDI', 'SAMEDI', 'DIMANCHE'];
        let normal_digital_clock_img_time = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_date_img_date_day = ''
        let idle_image_img = ''
        let idle_month_name_font = ''
        let idle_Month_Array = ['JANVIER', 'FEVRIER', 'MARS', 'AVRIL', 'MAI', 'JUIN', 'JUILLET', 'AOUT', 'SEPTEMBRE', 'OCTOBRE', 'NOVEMBRE', 'DECEMBRE', ];
        let idle_dow_text_font = ''
        let idle_DOW_Array = ['LUNDI', 'MARDI', 'MERCREDI', 'JEUDI', 'VENDREDI', 'SAMEDI', 'DIMANCHE'];
        let idle_digital_clock_img_time = ''
        let normal_step_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: '0000.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 325,
              y: 221,
              image_array: ["w00.png","w01.png","w02.png","w03.png","w04.png","w05.png","w06.png","w07.png","w08.png","w09.png","w10.png","w11.png","w12.png","w13.png","w14.png","w15.png","w16.png","w17.png","w18.png","w19.png","w20.png","w21.png","w22.png","w23.png","w24.png","w25.png","w26.png","w27.png","w28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 322,
              y: 285,
              font_array: ["Z00.png","Z01.png","Z02.png","Z03.png","Z04.png","Z05.png","Z06.png","Z07.png","Z08.png","Z09.png"],
              padding: false,
              h_space: 5,
              unit_sc: 'Z10.png',
              unit_tc: 'Z10.png',
              unit_en: 'Z10.png',
              negative_image: 'Z11.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 241,
              y: 283,
              src: 'sem6.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 279,
              y: 282,
              src: 'sem4.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 409,
              y: 220,
              src: 'sem2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 397,
              y: 265,
              font_array: ["Z00.png","Z01.png","Z02.png","Z03.png","Z04.png","Z05.png","Z06.png","Z07.png","Z08.png","Z09.png"],
              padding: false,
              h_space: 5,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 38,
              y: 230,
              src: 'sem1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 32,
              y: 265,
              font_array: ["Z00.png","Z01.png","Z02.png","Z03.png","Z04.png","Z05.png","Z06.png","Z07.png","Z08.png","Z09.png"],
              padding: false,
              h_space: 5,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 256,
              y: 344,
              font_array: ["Z00.png","Z01.png","Z02.png","Z03.png","Z04.png","Z05.png","Z06.png","Z07.png","Z08.png","Z09.png"],
              padding: false,
              h_space: 3,
              unit_sc: 'Z15.png',
              unit_tc: 'Z15.png',
              unit_en: 'Z15.png',
              dot_image: 'Z16.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 147,
              y: 345,
              font_array: ["Z00.png","Z01.png","Z02.png","Z03.png","Z04.png","Z05.png","Z06.png","Z07.png","Z08.png","Z09.png"],
              padding: false,
              h_space: 5,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 166,
              y: 423,
              w: 150,
              h: 30,
              text_size: 25,
              char_space: 0,
              line_space: 0,
              color: 0xFFFCAB25,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 177,
              y: 388,
              image_array: ["ENE_01.png","ENE_02.png","ENE_03.png","ENE_04.png","ENE_05.png","ENE_06.png","ENE_07.png","ENE_08.png","ENE_09.png","ENE_10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 221,
              day_startY: 21,
              day_sc_array: ["D00.png","D01.png","D02.png","D03.png","D04.png","D05.png","D06.png","D07.png","D08.png","D09.png"],
              day_tc_array: ["D00.png","D01.png","D02.png","D03.png","D04.png","D05.png","D06.png","D07.png","D08.png","D09.png"],
              day_en_array: ["D00.png","D01.png","D02.png","D03.png","D04.png","D05.png","D06.png","D07.png","D08.png","D09.png"],
              day_zero: 1,
              day_space: 6,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 145,
              y: 62,
              src: '0115.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function() {
              time_update(true);
            });

            normal_month_name_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 162,
              y: 103,
              w: 150,
              h: 30,
              text_size: 26,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              // unit_string: JANVIER, FEVRIER, MARS, AVRIL, MAI, JUIN, JUILLET, AOUT, SEPTEMBRE, OCTOBRE, NOVEMBRE, DECEMBRE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_dow_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 161,
              y: 68,
              w: 150,
              h: 30,
              text_size: 28,
              char_space: 0,
              line_space: 0,
              color: 0xFF000000,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              // unit_string: LUNDI, MARDI, MERCREDI, JEUDI, VENDREDI, SAMEDI, DIMANCHE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 109,
              hour_startY: 160,
              hour_array: ["M00.png","M01.png","M02.png","M03.png","M04.png","M05.png","M06.png","M07.png","M08.png","M09.png"],
              hour_zero: 1,
              hour_space: 10,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 234,
              minute_startY: 160,
              minute_array: ["H00.png","H01.png","H02.png","H03.png","H04.png","H05.png","H06.png","H07.png","H08.png","H09.png"],
              minute_zero: 1,
              minute_space: 10,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 333,
              second_startY: 160,
              second_array: ["D00.png","D01.png","D02.png","D03.png","D04.png","D05.png","D06.png","D07.png","D08.png","D09.png"],
              second_zero: 1,
              second_space: 6,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 241,
              y: 283,
              src: 'sem6.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 279,
              y: 282,
              src: 'sem4.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 221,
              day_startY: 21,
              day_sc_array: ["D00.png","D01.png","D02.png","D03.png","D04.png","D05.png","D06.png","D07.png","D08.png","D09.png"],
              day_tc_array: ["D00.png","D01.png","D02.png","D03.png","D04.png","D05.png","D06.png","D07.png","D08.png","D09.png"],
              day_en_array: ["D00.png","D01.png","D02.png","D03.png","D04.png","D05.png","D06.png","D07.png","D08.png","D09.png"],
              day_zero: 1,
              day_space: 6,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 145,
              y: 62,
              src: '0115.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_month_name_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 162,
              y: 103,
              w: 150,
              h: 30,
              text_size: 26,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              // unit_string: JANVIER, FEVRIER, MARS, AVRIL, MAI, JUIN, JUILLET, AOUT, SEPTEMBRE, OCTOBRE, NOVEMBRE, DECEMBRE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_dow_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 161,
              y: 68,
              w: 150,
              h: 30,
              text_size: 28,
              char_space: 0,
              line_space: 0,
              color: 0xFF000000,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              // unit_string: LUNDI, MARDI, MERCREDI, JEUDI, VENDREDI, SAMEDI, DIMANCHE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 109,
              hour_startY: 160,
              hour_array: ["M00.png","M01.png","M02.png","M03.png","M04.png","M05.png","M06.png","M07.png","M08.png","M09.png"],
              hour_zero: 1,
              hour_space: 10,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 234,
              minute_startY: 160,
              minute_array: ["H00.png","H01.png","H02.png","H03.png","H04.png","H05.png","H06.png","H07.png","H08.png","H09.png"],
              minute_zero: 1,
              minute_space: 10,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 333,
              second_startY: 160,
              second_array: ["D00.png","D01.png","D02.png","D03.png","D04.png","D05.png","D06.png","D07.png","D08.png","D09.png"],
              second_zero: 1,
              second_space: 6,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 9,
              // disconneсnt_toast_text: BT OFF,
              // conneсnt_vibrate_type: 9,
              // conneсnt_toast_text: BT ON,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              console.log('checkConnection()');
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  hmUI.showToast({text: "BT OFF"});
                  vibro(9);
                }
                if(status) {
                  hmUI.showToast({text: "BT ON"});
                  vibro(9);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              if (scene != 1) timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 142,
              y: 333,
              w: 191,
              h: 59,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 273,
              y: 278,
              w: 50,
              h: 48,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            //start of ignored block
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              console.log('month font');
              if (updateHour) {
                let normal_Month_Str = normal_Month_Array[timeSensor.month-1];
                normal_month_name_font.setProperty(hmUI.prop.TEXT, normal_Month_Str );
              };

              console.log('day of week font');
              if (updateHour) {
                let normal_DOW_Str = normal_DOW_Array[timeSensor.week-1];
                normal_dow_text_font.setProperty(hmUI.prop.TEXT, normal_DOW_Str );
              };

              console.log('month font');
              if (updateHour) {
                let idle_Month_Str = idle_Month_Array[timeSensor.month-1];
                idle_month_name_font.setProperty(hmUI.prop.TEXT, idle_Month_Str );
              };

              console.log('day of week font');
              if (updateHour) {
                let idle_DOW_Str = idle_DOW_Array[timeSensor.week-1];
                idle_dow_text_font.setProperty(hmUI.prop.TEXT, idle_DOW_Str );
              };

            };

            //end of ignored block
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                time_update(true, true);
                checkConnection();
                stopVibro();

              }),
              pause_call: (function () {
                console.log('pause_call()');
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
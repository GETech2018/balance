try {
    ((() => {
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        let normal$_$text_97630742180c4faea5a7f9658fb7d8f4 = '';
        let normal$_$text_11f1dd71274c4dcaa0deecf75df5f86f = '';
        let normal$_$text_3f2b335acfa24c339279257ba3161a18 = '';
        let normal$_$text_1da061559b2d4292afc6a3b8b14f51d2 = '';
        let dateFormat = '';
        let dateFormatMap = '';
        let idle$_$text_89d5ca6ce2cb45eba4db920c8f8a30bc = '';
        let batterySensor = '';
        let stepSensor = '';
        let heartSensor = '';
        let timeSensor = '';
        const logger = Logger.getLogger('watchface');
        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 480,
                    h: 480,
                    src: '2.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                    hour_centerX: 240,
                    hour_centerY: 240,
                    hour_posX: 240,
                    hour_posY: 240,
                    hour_path: '3.png',
                    hour_cover_x: 0,
                    hour_cover_y: 0,
                    minute_centerX: 240,
                    minute_centerY: 240,
                    minute_posX: 240,
                    minute_posY: 240,
                    minute_path: '4.png',
                    minute_cover_x: 0,
                    minute_cover_y: 0,
                    second_centerX: 240,
                    second_centerY: 240,
                    second_posX: 240,
                    second_posY: 240,
                    second_path: '6.png',
                    second_cover_path: '5.png',
                    second_cover_x: 0,
                    second_cover_y: 0,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_97630742180c4faea5a7f9658fb7d8f4 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 106,
                    y: 220,
                    w: 100,
                    h: 40,
                    text: '[BATT_PER]%',
                    color: '0xFFfa0002',
                    text_size: 25,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_11f1dd71274c4dcaa0deecf75df5f86f = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 170,
                    y: 330,
                    w: 140,
                    h: 40,
                    text: '[SC]',
                    color: '0xFFFA0002',
                    text_size: 40,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_3f2b335acfa24c339279257ba3161a18 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 190,
                    y: 285,
                    w: 100,
                    h: 40,
                    text: '[HR]',
                    color: '0xFFFA0002',
                    text_size: 25,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_1da061559b2d4292afc6a3b8b14f51d2 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 286,
                    y: 210,
                    w: 100,
                    h: 60,
                    text: '[DAY]',
                    color: '0xFFfa0002',
                    text_size: 50,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                    hour_centerX: 240,
                    hour_centerY: 240,
                    hour_posX: 240,
                    hour_posY: 240,
                    hour_path: '3.png',
                    hour_cover_x: 0,
                    hour_cover_y: 0,
                    minute_centerX: 240,
                    minute_centerY: 240,
                    minute_posX: 240,
                    minute_posY: 240,
                    minute_path: '4.png',
                    minute_cover_path: '7.png',
                    minute_cover_x: 0,
                    minute_cover_y: 0,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_AOD
                });
                idle$_$text_89d5ca6ce2cb45eba4db920c8f8a30bc = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 286,
                    y: 210,
                    w: 100,
                    h: 60,
                    text: '[DAY]',
                    color: '0xFFfa0002',
                    text_size: 50,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_AOD
                });
                if (!batterySensor) {
                    batterySensor = hmSensor.createSensor(hmSensor.id.BATTERY);
                }
                if (!stepSensor) {
                    stepSensor = hmSensor.createSensor(hmSensor.id.STEP);
                }
                if (!heartSensor) {
                    heartSensor = hmSensor.createSensor(hmSensor.id.HEART);
                }
                if (!timeSensor) {
                    timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
                }
                batterySensor.addEventListener(hmSensor.event.CHANGE, function () {
                    normal$_$text_97630742180c4faea5a7f9658fb7d8f4.setProperty(hmUI.prop.MORE, { text: `${ batterySensor.current }%` });
                }), stepSensor.addEventListener(hmSensor.event.CHANGE, function () {
                    normal$_$text_11f1dd71274c4dcaa0deecf75df5f86f.setProperty(hmUI.prop.MORE, { text: `${ stepSensor.current }` });
                }), heartSensor.addEventListener(heartSensor.event.LAST, function () {
                    normal$_$text_3f2b335acfa24c339279257ba3161a18.setProperty(hmUI.prop.MORE, { text: `${ heartSensor.last }` });
                }), timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function () {
                    dateFormat = hmSetting.getDateFormat();
                    dateFormatMap = [
                        () => {
                            normal$_$text_1da061559b2d4292afc6a3b8b14f51d2.setProperty(hmUI.prop.MORE, { text: `${ timeSensor.day }` });
                        },
                        () => {
                            normal$_$text_1da061559b2d4292afc6a3b8b14f51d2.setProperty(hmUI.prop.MORE, { text: `${ timeSensor.day }` });
                        },
                        () => {
                            normal$_$text_1da061559b2d4292afc6a3b8b14f51d2.setProperty(hmUI.prop.MORE, { text: `${ timeSensor.day }` });
                        }
                    ];
                    dateFormatMap[dateFormat]();
                    dateFormat = hmSetting.getDateFormat();
                    dateFormatMap = [
                        () => {
                            idle$_$text_89d5ca6ce2cb45eba4db920c8f8a30bc.setProperty(hmUI.prop.MORE, { text: `${ timeSensor.day }` });
                        },
                        () => {
                            idle$_$text_89d5ca6ce2cb45eba4db920c8f8a30bc.setProperty(hmUI.prop.MORE, { text: `${ timeSensor.day }` });
                        },
                        () => {
                            idle$_$text_89d5ca6ce2cb45eba4db920c8f8a30bc.setProperty(hmUI.prop.MORE, { text: `${ timeSensor.day }` });
                        }
                    ];
                    dateFormatMap[dateFormat]();
                });
                hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
                    resume_call: function () {
                        normal$_$text_97630742180c4faea5a7f9658fb7d8f4.setProperty(hmUI.prop.MORE, { text: `${ batterySensor.current }%` });
                        normal$_$text_11f1dd71274c4dcaa0deecf75df5f86f.setProperty(hmUI.prop.MORE, { text: `${ stepSensor.current }` });
                        normal$_$text_3f2b335acfa24c339279257ba3161a18.setProperty(hmUI.prop.MORE, { text: `${ heartSensor.last }` });
                        dateFormat = hmSetting.getDateFormat();
                        dateFormatMap = [
                            () => {
                                normal$_$text_1da061559b2d4292afc6a3b8b14f51d2.setProperty(hmUI.prop.MORE, { text: `${ timeSensor.day }` });
                            },
                            () => {
                                normal$_$text_1da061559b2d4292afc6a3b8b14f51d2.setProperty(hmUI.prop.MORE, { text: `${ timeSensor.day }` });
                            },
                            () => {
                                normal$_$text_1da061559b2d4292afc6a3b8b14f51d2.setProperty(hmUI.prop.MORE, { text: `${ timeSensor.day }` });
                            }
                        ];
                        dateFormatMap[dateFormat]();
                        dateFormat = hmSetting.getDateFormat();
                        dateFormatMap = [
                            () => {
                                idle$_$text_89d5ca6ce2cb45eba4db920c8f8a30bc.setProperty(hmUI.prop.MORE, { text: `${ timeSensor.day }` });
                            },
                            () => {
                                idle$_$text_89d5ca6ce2cb45eba4db920c8f8a30bc.setProperty(hmUI.prop.MORE, { text: `${ timeSensor.day }` });
                            },
                            () => {
                                idle$_$text_89d5ca6ce2cb45eba4db920c8f8a30bc.setProperty(hmUI.prop.MORE, { text: `${ timeSensor.day }` });
                            }
                        ];
                        dateFormatMap[dateFormat]();
                    }
                });
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })());
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
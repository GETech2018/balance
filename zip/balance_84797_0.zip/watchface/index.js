﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg = ''
        let normal_calorie_icon_img = ''
        let normal_calorie_current_text_font = ''
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_text_font = ''
        let normal_distance_icon_img = ''
        let normal_distance_current_text_font = ''
        let normal_step_icon_img = ''
        let normal_step_current_text_font = ''
        let normal_battery_current_text_font = ''
        let normal_battery_image_progress_img_level = ''
        let normal_year_text_font = ''
        let normal_month_name_font = ''
        let normal_Month_Array = ['GEN', 'FEB', 'MAR', 'APR', 'MAG', 'GIU', 'LUG', 'AGO', 'SET', 'OTT', 'NOV', 'DIC', ];
        let normal_day_text_font = ''
        let normal_dow_text_font = ''
        let normal_DOW_Array = ['LUNEDI', 'MARTEDI', 'MERCOLEDI', 'GIOVEDI', 'VENERDI', 'SABATO', 'DOMENICA'];
        let normal_humidity_icon_img = ''
        let normal_humidity_current_text_font = ''
        let normal_wind_icon_img = ''
        let normal_wind_current_text_font = ''
        let normal_city_name_text = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_high_text_font = ''
        let normal_temperature_low_text_font = ''
        let normal_temperature_current_text_font = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_analog_clock_pro_hour_pointer_img = ''
        let normal_analog_clock_pro_minute_pointer_img = ''
        let normal_timerUpdateSec = undefined;
        let normal_analog_clock_time_pointer_smooth_second = ''
        let idle_background_bg = ''
        let idle_calorie_icon_img = ''
        let idle_calorie_current_text_font = ''
        let idle_heart_rate_icon_img = ''
        let idle_heart_rate_text_font = ''
        let idle_distance_icon_img = ''
        let idle_distance_current_text_font = ''
        let idle_step_icon_img = ''
        let idle_step_current_text_font = ''
        let idle_battery_current_text_font = ''
        let idle_battery_image_progress_img_level = ''
        let idle_year_text_font = ''
        let idle_month_name_font = ''
        let idle_Month_Array = ['GEN', 'FEB', 'MAR', 'APR', 'MAG', 'GIU', 'LUG', 'AGO', 'SET', 'OTT', 'NOV', 'DIC', ];
        let idle_day_text_font = ''
        let idle_dow_text_font = ''
        let idle_DOW_Array = ['LUNEDI', 'MARTEDI', 'MERCOLEDI', 'GIOVEDI', 'VENERDI', 'SABATO', 'DOMENICA'];
        let idle_humidity_icon_img = ''
        let idle_humidity_current_text_font = ''
        let idle_wind_icon_img = ''
        let idle_wind_current_text_font = ''
        let idle_city_name_text = ''
        let idle_weather_image_progress_img_level = ''
        let idle_temperature_high_text_font = ''
        let idle_temperature_low_text_font = ''
        let idle_temperature_current_text_font = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''
        let idle_analog_clock_pro_hour_pointer_img = ''
        let idle_analog_clock_pro_minute_pointer_img = ''
        let normal_step_jumpable_img_click = ''
        let normal_cal_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_battery_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_fatBurning_jumpable_img_click = ''
        let Button_1 = ''
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 411,
              y: 325,
              src: '0057.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 300,
              y: 316,
              w: 150,
              h: 35,
              text_size: 27,
              char_space: 0,
              line_space: 0,
              color: 0xFFFF8C00,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 50,
              y: 326,
              src: '0054.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 87,
              y: 316,
              w: 150,
              h: 35,
              text_size: 27,
              char_space: 0,
              line_space: 0,
              color: 0xFFFF0000,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 94,
              y: 371,
              src: 'distanza.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 86,
              y: 374,
              w: 150,
              h: 35,
              text_size: 27,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 354,
              y: 376,
              src: '0088.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 236,
              y: 374,
              w: 150,
              h: 35,
              text_size: 27,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 228,
              y: 436,
              w: 150,
              h: 36,
              text_size: 27,
              char_space: 0,
              line_space: 0,
              color: 0xFFFF0000,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 200,
              y: 424,
              image_array: ["0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png","0050.png","0051.png","0052.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function() {
              time_update(true);
            });

            normal_year_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 285,
              y: 328,
              w: 150,
              h: 35,
              text_size: 27,
              char_space: 0,
              line_space: 0,
              color: 0xFF00FFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_month_name_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 167,
              y: 328,
              w: 150,
              h: 35,
              text_size: 27,
              char_space: 0,
              line_space: 0,
              color: 0xFF0080FF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              // unit_string: GEN,FEB,MAR,APR,MAG,GIU,LUG,AGO,SET,OTT,NOV,DIC,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_day_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 108,
              y: 328,
              w: 150,
              h: 34,
              text_size: 27,
              char_space: 0,
              line_space: 0,
              color: 0xFF80FFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_dow_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 165,
              y: 296,
              w: 150,
              h: 37,
              text_size: 28,
              char_space: 0,
              line_space: 0,
              color: 0xFF00FF00,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              // unit_string: LUNEDI,MARTEDI,MERCOLEDI,GIOVEDI,VENERDI,SABATO, DOMENICA,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 399,
              y: 134,
              src: 'UMIDITA.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 350,
              y: 125,
              w: 150,
              h: 36,
              text_size: 27,
              char_space: 0,
              line_space: 0,
              color: 0xFF00FFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 53,
              y: 130,
              src: 'VENTO.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 100,
              y: 124,
              w: 150,
              h: 35,
              text_size: 27,
              char_space: 0,
              line_space: 0,
              color: 0xFF00FF00,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.WIND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 115,
              y: 152,
              w: 250,
              h: 40,
              text_size: 27,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFF00,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 149,
              y: 18,
              image_array: ["0059.png","0060.png","0061.png","0062.png","0063.png","0064.png","0065.png","0066.png","0067.png","0068.png","0069.png","0070.png","0071.png","0072.png","0073.png","0074.png","0075.png","0076.png","0077.png","0078.png","0079.png","0080.png","0081.png","0082.png","0083.png","0084.png","0085.png","0086.png","0087.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 282,
              y: 60,
              w: 150,
              h: 30,
              text_size: 25,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFF00,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 52,
              y: 60,
              w: 150,
              h: 30,
              text_size: 25,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFF00,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 165,
              y: -7,
              w: 150,
              h: 50,
              text_size: 35,
              char_space: 0,
              line_space: 0,
              color: 0xFFFF8C00,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 45,
              hour_startY: 194,
              hour_array: ["0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png"],
              hour_zero: 1,
              hour_space: 3,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 279,
              minute_startY: 194,
              minute_array: ["0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png"],
              minute_zero: 1,
              minute_space: 3,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 224,
              second_startY: 266,
              second_array: ["0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png","0023.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 207,
              y: 202,
              src: 'Compass2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const deviceInfo = hmSetting.getDeviceInfo();
            timeSensor.addEventListener(timeSensor.event.MINUTEEND, function() {
              let updateHour = timeSensor.minute == 0;

              time_update(updateHour, true);
            });

            // normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'hour.png',
              // center_x: 240,
              // center_y: 240,
              // x: 14,
              // y: 133,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.hour,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 14,
              pos_y: 240 - 133,
              center_x: 240,
              center_y: 240,
              src: 'hour.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            // normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'min.png',
              // center_x: 240,
              // center_y: 240,
              // x: 34,
              // y: 208,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.minute,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 34,
              pos_y: 240 - 208,
              center_x: 240,
              center_y: 240,
              src: 'min.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'sec_00.png',
              // center_x: 240,
              // center_y: 240,
              // x: 11,
              // y: 216,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_time_pointer_smooth_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'sec_00.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 11,
              second_posY: 216,
              fresh_frequency: 15,
              fresh_freqency: 15,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_smooth_second = hmUI.createWidget(hmUI.widget.SMOOTH_SECOND, {
              // type: 3,
              // fps: 15,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });



            console.log('Watch_Face.ScreenAOD');
            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 411,
              y: 325,
              src: '0057.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 300,
              y: 316,
              w: 150,
              h: 35,
              text_size: 27,
              char_space: 0,
              line_space: 0,
              color: 0xFFFF8C00,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 50,
              y: 326,
              src: '0054.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 87,
              y: 316,
              w: 150,
              h: 35,
              text_size: 27,
              char_space: 0,
              line_space: 0,
              color: 0xFFFF0000,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_distance_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 94,
              y: 371,
              src: 'distanza.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_distance_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 86,
              y: 374,
              w: 150,
              h: 35,
              text_size: 27,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 354,
              y: 376,
              src: '0088.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 236,
              y: 374,
              w: 150,
              h: 35,
              text_size: 27,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 228,
              y: 436,
              w: 150,
              h: 36,
              text_size: 27,
              char_space: 0,
              line_space: 0,
              color: 0xFFFF0000,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 200,
              y: 424,
              image_array: ["0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png","0050.png","0051.png","0052.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_year_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 285,
              y: 328,
              w: 150,
              h: 35,
              text_size: 27,
              char_space: 0,
              line_space: 0,
              color: 0xFF00FFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_month_name_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 167,
              y: 328,
              w: 150,
              h: 35,
              text_size: 27,
              char_space: 0,
              line_space: 0,
              color: 0xFF0080FF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              // unit_string: GEN,FEB,MAR,APR,MAG,GIU,LUG,AGO,SET,OTT,NOV,DIC,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_day_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 108,
              y: 328,
              w: 150,
              h: 34,
              text_size: 27,
              char_space: 0,
              line_space: 0,
              color: 0xFF80FFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              // padding: true,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_dow_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 165,
              y: 296,
              w: 150,
              h: 37,
              text_size: 28,
              char_space: 0,
              line_space: 0,
              color: 0xFF00FF00,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              // unit_string: LUNEDI,MARTEDI,MERCOLEDI,GIOVEDI,VENERDI,SABATO, DOMENICA,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_humidity_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 399,
              y: 134,
              src: 'UMIDITA.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_humidity_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 350,
              y: 125,
              w: 150,
              h: 36,
              text_size: 27,
              char_space: 0,
              line_space: 0,
              color: 0xFF00FFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_wind_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 53,
              y: 130,
              src: 'VENTO.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_wind_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 100,
              y: 124,
              w: 150,
              h: 35,
              text_size: 27,
              char_space: 0,
              line_space: 0,
              color: 0xFF00FF00,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.WIND,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 115,
              y: 152,
              w: 250,
              h: 40,
              text_size: 27,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFF00,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 149,
              y: 18,
              image_array: ["0059.png","0060.png","0061.png","0062.png","0063.png","0064.png","0065.png","0066.png","0067.png","0068.png","0069.png","0070.png","0071.png","0072.png","0073.png","0074.png","0075.png","0076.png","0077.png","0078.png","0079.png","0080.png","0081.png","0082.png","0083.png","0084.png","0085.png","0086.png","0087.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_high_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 282,
              y: 60,
              w: 150,
              h: 30,
              text_size: 25,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFF00,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_low_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 52,
              y: 60,
              w: 150,
              h: 30,
              text_size: 25,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFF00,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 165,
              y: -7,
              w: 150,
              h: 50,
              text_size: 35,
              char_space: 0,
              line_space: 0,
              color: 0xFFFF8C00,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 45,
              hour_startY: 194,
              hour_array: ["0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png"],
              hour_zero: 1,
              hour_space: 3,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 279,
              minute_startY: 194,
              minute_array: ["0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png"],
              minute_zero: 1,
              minute_space: 3,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 207,
              y: 202,
              src: 'Compass2.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'hour.png',
              // center_x: 240,
              // center_y: 240,
              // x: 14,
              // y: 133,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.hour,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });


            idle_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 14,
              pos_y: 240 - 133,
              center_x: 240,
              center_y: 240,
              src: 'hour.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'min.png',
              // center_x: 240,
              // center_y: 240,
              // x: 34,
              // y: 208,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.minute,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });


            idle_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 34,
              pos_y: 240 - 208,
              center_x: 240,
              center_y: 240,
              src: 'min.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 281,
              y: 370,
              w: 106,
              h: 50,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_cal_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 84,
              y: 370,
              w: 100,
              h: 50,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 44,
              y: 314,
              w: 100,
              h: 50,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 193,
              y: 423,
              w: 100,
              h: 100,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 184,
              y: 37,
              w: 130,
              h: 100,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 48,
              y: 190,
              w: 100,
              h: 100,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 335,
              y: 190,
              w: 100,
              h: 100,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 204,
              y: 190,
              w: 80,
              h: 100,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_fatBurning_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 346,
              y: 308,
              w: 100,
              h: 50,
              type: hmUI.data_type.FAT_BURNING,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 164,
              y: 299,
              w: 161,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_empty.png',
              normal_src: '0_empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            //start of ignored block
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              console.log('year font');
              if (updateHour) {
                let normal_yearStr = (timeSensor.year % 100).toString();
                normal_year_text_font.setProperty(hmUI.prop.TEXT, normal_yearStr );
              };

              console.log('month font');
              if (updateHour) {
                let normal_Month_Str = normal_Month_Array[timeSensor.month-1];
                normal_month_name_font.setProperty(hmUI.prop.TEXT, normal_Month_Str );
              };

              console.log('day font');
              if (updateHour) {
                let normal_dayStr = timeSensor.day.toString();
                normal_dayStr = normal_dayStr.padStart(2, '0');
                normal_day_text_font.setProperty(hmUI.prop.TEXT, normal_dayStr );
              };

              console.log('day of week font');
              if (updateHour) {
                let normal_DOW_Str = normal_DOW_Array[timeSensor.week-1];
                normal_dow_text_font.setProperty(hmUI.prop.TEXT, normal_DOW_Str );
              };

              if (updateMinute) {
                let normal_hour = hour;
                let normal_fullAngle_hour = 360;
                if (normal_hour > 11) normal_hour -= 12;
                let normal_angle_hour = 0 + normal_fullAngle_hour*normal_hour/12 + (normal_fullAngle_hour/12)*minute/60;
                if (normal_analog_clock_pro_hour_pointer_img) normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_hour);
              };

                let normal_fullAngle_minute = 360;
                let normal_angle_minute = 0 + normal_fullAngle_minute*(minute + second/60)/60;
                if (normal_analog_clock_pro_minute_pointer_img) normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_minute);
              console.log('year font');
              if (updateHour) {
                let idle_yearStr = (timeSensor.year % 100).toString();
                idle_year_text_font.setProperty(hmUI.prop.TEXT, idle_yearStr );
              };

              console.log('month font');
              if (updateHour) {
                let idle_Month_Str = idle_Month_Array[timeSensor.month-1];
                idle_month_name_font.setProperty(hmUI.prop.TEXT, idle_Month_Str );
              };

              console.log('day font');
              if (updateHour) {
                let idle_dayStr = timeSensor.day.toString();
                idle_dayStr = idle_dayStr.padStart(2, '0');
                idle_day_text_font.setProperty(hmUI.prop.TEXT, idle_dayStr );
              };

              console.log('day of week font');
              if (updateHour) {
                let idle_DOW_Str = idle_DOW_Array[timeSensor.week-1];
                idle_dow_text_font.setProperty(hmUI.prop.TEXT, idle_DOW_Str );
              };

              if (updateMinute) {
                let idle_hour = hour;
                let idle_fullAngle_hour = 360;
                if (idle_hour > 11) idle_hour -= 12;
                let idle_angle_hour = 0 + idle_fullAngle_hour*idle_hour/12 + (idle_fullAngle_hour/12)*minute/60;
                if (idle_analog_clock_pro_hour_pointer_img) idle_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.ANGLE, idle_angle_hour);
              };

              if (updateMinute) {
                let idle_fullAngle_minute = 360;
                let idle_angle_minute = 0 + idle_fullAngle_minute*minute/60;
                if (idle_analog_clock_pro_minute_pointer_img) idle_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.ANGLE, idle_angle_minute);
              };

            };

            //end of ignored block
            function scale_call() {
              console.log('scale_call()');

              console.log('Weather city name');
              let weatherData = weatherSensor.getForecastWeather();
              normal_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

              console.log('Weather city name');
              idle_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                time_update(true, true);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSec) {
                    let animDelay = timeSensor.utc % 1000;
                    let animRepeat = 1000;
                    normal_timerUpdateSec = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, true);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerUpdateSec) {
                  timer.stopTimer(normal_timerUpdateSec);
                  normal_timerUpdateSec = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
﻿try {

    (() => {
          var __$$app$$__ = __$$hmAppManager$$__.currentApp;
          var __$$module$$__ = __$$app$$__.current;
          var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'napitek');
          const logger = DeviceRuntimeCore.HmLogger.getLogger("doZen");

          let standard_godz;
          let standard_min;
          let bateria_poziom;
          let godzSzyk;
          let minSzyk;
          let bateriaSzyk;
          let uaktualniacz = undefined;
          let czas_teraz;
  
          __$$module$$__.module = DeviceRuntimeCore.WatchFace({
  
            initView() {

              godzSzyk = new Array(13).fill(null).map((_, i) => `h${i}.png`);
              minSzyk = new Array(60).fill(null).map((_, j) => `m${j}.png`);
  
              const tlo = hmUI.createWidget(hmUI.widget.FILL_RECT, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                color: 0x000000,
              });
  
              standard_godz = hmUI.createWidget(hmUI.widget.IMG, {
                x: 100,
                y: 140,
                w: 128,
                h: 200,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              
              standard_min = hmUI.createWidget(hmUI.widget.IMG, {
                x: 50,
                y: 50,
                w: 384,
                h: 380,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });

              bateria_poziom = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                x: 190,
                y: 95,
                w: 112,
                h: 290,
                bateriaSzyk: new Array(10).fill(null).map((_, k) => `b${k}.png`),
                image_length: 10,
                type: hmUI.data_type.BATTERY,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
                             
              if (!czas_teraz) czas_teraz = hmSensor.createSensor(hmSensor.id.TIME);
                  
              uaktualniacz = timer.createTimer(0, 1000, (function (option) {
                  let godzina = czas_teraz.hour;
                  let minuta = czas_teraz.minute;
                  godzina = (godzina % 12) || 12;
                  let godzina_d = String(godzina).padStart(2, '0');
                  let minuta_d = String(minuta).padStart(2, '0');
                  standard_godz.setProperty(hmUI.prop.SRC, "h" + godzina_d + ".png");
                  standard_min.setProperty(hmUI.prop.SRC, "m" + minuta_d + ".png");
              }));

              const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
                resume_call: (function () {
                    if (screenType != hmSetting.screen_type.AOD) {
                      let godzina = czas_teraz.hour;
                      let minuta = czas_teraz.minute;
                      godzina = (godzina % 12) || 12;
                      let godzina_d = String(godzina).padStart(2, '0');
                      let minuta_d = String(minuta).padStart(2, '0');
                      standard_godz.setProperty(hmUI.prop.SRC, "h" + godzina_d + ".png");
                      standard_min.setProperty(hmUI.prop.SRC, "m" + minuta_d + ".png");
                    }
                  }),
              });
            },
          onInit() {
            logger.log('index page.js on init invoke')
            this.initView()
          },
          
          onBuild() {
            logger.log('index page.js on build invoke')
            
          },
          
          onDestroy() {
            logger.log('index page.js on destroy invoke')
          },
        })
    })()
  } 
catch (e) {
  console.log(e)
}
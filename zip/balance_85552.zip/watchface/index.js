﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_sun_icon_img = ''
        let normal_sun_high_text_font = ''
        let normal_sun_low_text_font = ''
        let normal_day_text_font = ''
        let normal_dow_text_font = ''
        let normal_DOW_Array = ['MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT', 'SUN'];
        let normal_heart_rate_text_font = ''
        let normal_stress_icon_img = ''
        let normal_stress_current_text_font = ''
        let normal_stand_current_text_font = ''
        let normal_calorie_icon_img = ''
        let normal_calorie_current_text_font = ''
        let normal_distance_current_text_font = ''
        let normal_step_icon_img = ''
        let normal_step_current_text_font = ''
        let normal_step_image_progress_img_level = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_high_text_font = ''
        let normal_temperature_low_text_font = ''
        let normal_temperature_current_text_font = ''
        let normal_battery_current_text_font = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_time_hour_text_font = ''
        let normal_timerTimeUpdate = undefined;
        let normal_time_minute_text_font = ''
        let normal_time_second_text_font = ''
        let idle_system_clock_img = ''
        let idle_day_text_font = ''
        let idle_dow_text_font = ''
        let idle_DOW_Array = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
        let idle_time_hour_min_text_font = ''
        let idle_timerTimeUpdate = undefined;
        let normal_heart_jumpable_img_click = ''
        let normal_stress_jumpable_img_click = ''
        let normal_walking_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let Button_7 = ''
        let Button_8 = ''
        let Button_9 = ''
        let Button_10 = ''
        let Button_11 = ''
        let Button_12 = ''
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            // FontName: Antonio-Bold.ttf; FontSize: 17
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 270,
              h: 28,
              text_size: 17,
              char_space: 2,
              line_space: 0,
              font: 'fonts/Antonio-Bold.ttf',
              color: 0xFFFFFF00,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: Antonio-Bold.ttf; FontSize: 29
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 416,
              h: 50,
              text_size: 29,
              char_space: 2,
              line_space: 0,
              font: 'fonts/Antonio-Bold.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: Antonio-Bold.ttf; FontSize: 29; Cache: full
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 34,
              h: 34,
              text_size: 29,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Antonio-Bold.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.NONE,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: Antonio-Bold.ttf; FontSize: 20
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 332,
              h: 34,
              text_size: 20,
              char_space: 3,
              line_space: 0,
              font: 'fonts/Antonio-Bold.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: Antonio-Bold.ttf; FontSize: 23; Cache: full
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 27,
              h: 27,
              text_size: 23,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Antonio-Bold.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.RIGHT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.NONE,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: Antonio-Bold.ttf; FontSize: 27
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 570,
              h: 46,
              text_size: 27,
              char_space: 8,
              line_space: 0,
              font: 'fonts/Antonio-Bold.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.RIGHT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: Antonio-Bold.ttf; FontSize: 37
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 549,
              h: 63,
              text_size: 37,
              char_space: 3,
              line_space: 0,
              font: 'fonts/Antonio-Bold.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: Antonio-Bold.ttf; FontSize: 68
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 937,
              h: 117,
              text_size: 68,
              char_space: 3,
              line_space: 0,
              font: 'fonts/Antonio-Bold.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: Antonio-Bold.ttf; FontSize: 44
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 661,
              h: 75,
              text_size: 44,
              char_space: 4,
              line_space: 0,
              font: 'fonts/Antonio-Bold.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: Antonio-Bold.ttf; FontSize: 31
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 469,
              h: 52,
              text_size: 31,
              char_space: 3,
              line_space: 0,
              font: 'fonts/Antonio-Bold.ttf',
              color: 0xFFC0C0C0,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: '1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 36,
              y: 103,
              src: '0196.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 22,
              y: 85,
              w: 150,
              h: 30,
              text_size: 17,
              char_space: 2,
              line_space: 0,
              font: 'fonts/Antonio-Bold.ttf',
              color: 0xFFFFFF00,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 22,
              y: 131,
              w: 150,
              h: 30,
              text_size: 17,
              char_space: 3,
              line_space: 0,
              font: 'fonts/Antonio-Bold.ttf',
              color: 0xFF00FFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function() {
              time_update(true);
            });

            normal_day_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 164,
              y: 43,
              w: 150,
              h: 41,
              text_size: 29,
              char_space: 2,
              line_space: 0,
              font: 'fonts/Antonio-Bold.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_dow_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 111,
              y: 43,
              w: 150,
              h: 41,
              text_size: 29,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Antonio-Bold.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              // unit_string: MON,TUE, WED, THU, FRI, SAT, SUN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 322,
              y: 308,
              w: 150,
              h: 30,
              text_size: 20,
              char_space: 3,
              line_space: 0,
              font: 'fonts/Antonio-Bold.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              padding: true,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 394,
              y: 99,
              src: '0193.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 231,
              y: 308,
              w: 150,
              h: 30,
              text_size: 20,
              char_space: 3,
              line_space: 0,
              font: 'fonts/Antonio-Bold.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              padding: true,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.STRESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 324,
              y: 215,
              w: 150,
              h: 30,
              text_size: 20,
              char_space: 3,
              line_space: 0,
              font: 'fonts/Antonio-Bold.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              padding: true,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.STAND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 74,
              y: 382,
              src: '0195.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 227,
              y: 215,
              w: 150,
              h: 30,
              text_size: 20,
              char_space: 3,
              line_space: 0,
              font: 'fonts/Antonio-Bold.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              padding: true,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 10,
              y: 320,
              w: 150,
              h: 37,
              text_size: 23,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Antonio-Bold.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.RIGHT,
              align_v: hmUI.align.TOP,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 34,
              y: 148,
              src: '0197.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 11,
              y: 272,
              w: 150,
              h: 37,
              text_size: 27,
              char_space: 8,
              line_space: 0,
              font: 'fonts/Antonio-Bold.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.RIGHT,
              align_v: hmUI.align.TOP,
              padding: true,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 86,
              y: 364,
              image_array: ["46.png","47.png","48.png","49.png","50.png"],
              image_length: 5,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 70,
              y: 182,
              image_array: ["meteo-01.png","meteo-02.png","meteo-03.png","meteo-04.png","meteo-05.png","meteo-06.png","meteo-07.png","meteo-08.png","meteo-09.png","meteo-10.png","meteo-11.png","meteo-12.png","meteo-13.png","meteo-14.png","meteo-15.png","meteo-16.png","meteo-17.png","meteo-18.png","meteo-19.png","meteo-20.png","meteo-21.png","meteo-22.png","meteo-23.png","meteo-24.png","meteo-25.png","meteo-26.png","meteo-27.png","meteo-28.png","meteo-29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 134,
              y: 176,
              w: 150,
              h: 30,
              text_size: 17,
              char_space: 2,
              line_space: 0,
              font: 'fonts/Antonio-Bold.ttf',
              color: 0xFF00FFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 88,
              y: 176,
              w: 150,
              h: 30,
              text_size: 17,
              char_space: 2,
              line_space: 0,
              font: 'fonts/Antonio-Bold.ttf',
              color: 0xFFFF8080,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 114,
              y: 202,
              w: 150,
              h: 54,
              text_size: 37,
              char_space: 3,
              line_space: 0,
              font: 'fonts/Antonio-Bold.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 197,
              y: 15,
              w: 150,
              h: 48,
              text_size: 20,
              char_space: 2,
              line_space: 0,
              font: 'fonts/Antonio-Bold.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              padding: true,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 327,
              am_y: 68,
              am_sc_path: '33.png',
              am_en_path: '33.png',
              pm_x: 327,
              pm_y: 68,
              pm_sc_path: '34.png',
              pm_en_path: '34.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            normal_time_hour_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 87,
              y: 70,
              w: 150,
              h: 79,
              text_size: 68,
              char_space: 3,
              line_space: 0,
              font: 'fonts/Antonio-Bold.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_time_minute_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 183,
              y: 70,
              w: 150,
              h: 79,
              text_size: 68,
              char_space: 3,
              line_space: 0,
              font: 'fonts/Antonio-Bold.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_time_second_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 269,
              y: 107,
              w: 150,
              h: 58,
              text_size: 44,
              char_space: 4,
              line_space: 0,
              font: 'fonts/Antonio-Bold.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 127,
              y: 83,
              src: 'alar.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_day_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 169,
              y: 73,
              w: 150,
              h: 52,
              text_size: 31,
              char_space: 3,
              line_space: 0,
              font: 'fonts/Antonio-Bold.ttf',
              color: 0xFFC0C0C0,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              // padding: true,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_dow_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 150,
              y: 125,
              w: 187,
              h: 66,
              text_size: 35,
              char_space: 0,
              line_space: 0,
              color: 0xFFC0C0C0,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              // unit_string: Monday, Tuesday, Wednesday, Thursday, Friday, Saturday, Sunday,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_time_hour_min_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 114,
              y: 134,
              w: 268,
              h: 194,
              text_size: 58,
              char_space: 1,
              line_space: 0,
              color: 0xFFC0C0C0,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              // padding: true,
              // unit_type: 2,
              // unit_end: true,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 0,
              // disconneсnt_toast_text: RUSH OFF,
              // conneсnt_vibrate_type: 0,
              // conneсnt_toast_text: RUSH ON,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              console.log('checkConnection()');
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  hmUI.showToast({text: "RUSH OFF"});
                  vibro(0);
                }
                if(status) {
                  hmUI.showToast({text: "RUSH ON"});
                  vibro(0);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              if (scene != 1) timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function
            console.log('Watch_Face.Shortcuts');

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 373,
              y: 291,
              w: 50,
              h: 50,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 280,
              y: 291,
              w: 50,
              h: 50,
              type: hmUI.data_type.STRESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_walking_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 377,
              y: 200,
              w: 50,
              h: 50,
              type: hmUI.data_type.WALKING,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 187,
              y: 0,
              w: 100,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'Settings_batteryManagerScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 154,
              y: 49,
              w: 100,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 50,
              y: 89,
              w: 100,
              h: 68,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'TideScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 40,
              y: 186,
              w: 199,
              h: 74,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'WeatherScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 40,
              y: 278,
              w: 199,
              h: 74,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'activityAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 385,
              y: 85,
              w: 50,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'Settings_homeScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_7 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 279,
              y: 200,
              w: 50,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'SportListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_8 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 50,
              y: 360,
              w: 50,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'Settings_lightAdjustScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_9 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 110,
              y: 388,
              w: 50,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PhoneHomeScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_10 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 180,
              y: 388,
              w: 50,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'LocalMusicScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_11 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 248,
              y: 388,
              w: 50,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'AlarmInfoScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_12 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 320,
              y: 388,
              w: 50,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'AppListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            //start of ignored block
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              console.log('day font');
              if (updateHour) {
                let normal_dayStr = timeSensor.day.toString();
                normal_dayStr = normal_dayStr.padStart(2, '0');
                normal_day_text_font.setProperty(hmUI.prop.TEXT, normal_dayStr );
              };

              console.log('day of week font');
              if (updateHour) {
                let normal_DOW_Str = normal_DOW_Array[timeSensor.week-1];
                normal_dow_text_font.setProperty(hmUI.prop.TEXT, normal_DOW_Str );
              };

              console.log('hour font');
              if (updateHour) {
                let normal_hourStr = format_hour.toString();
                normal_hourStr = normal_hourStr.padStart(2, '0');
                normal_time_hour_text_font.setProperty(hmUI.prop.TEXT, normal_hourStr );
              };

              console.log('minute font');
              if (updateMinute) {
                let normal_minuteStr = minute.toString();
                normal_minuteStr = normal_minuteStr.padStart(2, '0');
                normal_time_minute_text_font.setProperty(hmUI.prop.TEXT, normal_minuteStr );
              };

              console.log('second font');
                let normal_secondStr = second.toString();
                normal_secondStr = normal_secondStr.padStart(2, '0');
                normal_time_second_text_font.setProperty(hmUI.prop.TEXT, normal_secondStr );
              console.log('day font');
              if (updateHour) {
                let idle_dayStr = timeSensor.day.toString();
                idle_dayStr = idle_dayStr.padStart(2, '0');
                idle_day_text_font.setProperty(hmUI.prop.TEXT, idle_dayStr );
              };

              console.log('day of week font');
              if (updateHour) {
                let idle_DOW_Str = idle_DOW_Array[timeSensor.week-1];
                idle_dow_text_font.setProperty(hmUI.prop.TEXT, idle_DOW_Str );
              };

              console.log('hour:min font');
              if (updateMinute) {
                let idle_HourMinStr = format_hour.toString();
                idle_HourMinStr = idle_HourMinStr.padStart(2, '0');
                idle_HourMinStr = idle_HourMinStr + ':' + minute.toString().padStart(2, '0')
                if (!timeSensor.is24Hour) {
                  if (hour > 11) idle_HourMinStr = idle_HourMinStr + ' PM';
                  else idle_HourMinStr = idle_HourMinStr + ' AM';
                };
                idle_time_hour_min_text_font.setProperty(hmUI.prop.TEXT, idle_HourMinStr );
              };

            };

            //end of ignored block
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                time_update(true, true);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerTimeUpdate) {
                    normal_timerTimeUpdate = timer.createTimer(0, 1000, (function (option) {
                      let updateHour = timeSensor.minute == 0 && timeSensor.second < 2;
                      let updateMinute = timeSensor.second < 2;
                      time_update(updateHour, updateMinute);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.AOD) {
                  if (!idle_timerTimeUpdate) {
                    idle_timerTimeUpdate = timer.createTimer(0, 1000, (function (option) {
                      let updateHour = timeSensor.minute == 0 && timeSensor.second < 2;
                      let updateMinute = timeSensor.second < 2;
                      time_update(updateHour, updateMinute);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                checkConnection();
                stopVibro();

              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerTimeUpdate) {
                  timer.stopTimer(normal_timerTimeUpdate);
                  normal_timerTimeUpdate = undefined;
                }
                if (idle_timerTimeUpdate) {
                  timer.stopTimer(idle_timerTimeUpdate);
                  idle_timerTimeUpdate = undefined;
                }
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
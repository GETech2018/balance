﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_date_img_date_week_img = ''
        let normal_system_lock_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_date_img_date_year = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_altimeter_icon_img = ''
		let normal_temp_text_text_img = ''
        let normal_humidity_icon_img = ''
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_wind_icon_img = ''
        let normal_wind_direction_image_progress_img_level = ''
        let normal_wind_text_text_img = ''
        let normal_moon_icon_img = ''
        let normal_uvi_icon_img = ''
        let normal_floor_text_text_img = ''
        let normal_fat_burning_icon_img = ''
        let normal_fat_burning_target_text_img = ''
        let normal_fat_burning_current_text_img = ''
        let normal_stand_icon_img = ''
        let normal_stand_target_text_img = ''
        let normal_stand_current_text_img = ''
        let normal_stand_image_progress_img_level = ''
        let normal_distance_icon_img = ''
        let normal_distance_text_text_img = ''
        let normal_calorie_icon_img = ''
        let normal_calorie_current_text_img = ''
        let normal_calorie_image_progress_img_level = ''
        let normal_step_icon_img = ''
        let normal_step_current_text_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_temperature_icon_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_max_min_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_sun_icon_img = ''
        let normal_sun_high_text_img = ''
        let normal_sun_low_text_img = ''
        let normal_sun_pointer_progress_img_pointer = ''
        let normal_spo2_icon_img = ''
        let normal_compass_icon_img = ''
        let normal_compass_direction_pointer_img = ''
        let normal_compass_text_img = ''
        let normal_compass_direction_img_level = ''
        let normal_compass_direction_arr = ["d_1.png", "d_2.png", "d_3.png", "d_4.png", "d_5.png", "d_6.png", "d_7.png", "d_8.png"];
        let normal_pai_icon_img = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_digital_clock_img_time = ''
        let normal_step_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_stand_jumpable_img_click = ''
        let normal_fatBurning_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
		
		let btn_bezel = ''
        let bezel_num = 1
        let bezel_all = 7
     
        function click_Bezel() {
            if(bezel_num>=bezel_all) {bezel_num=1;}
            else { bezel_num=bezel_num+1;}
            hmUI.showToast({text: "<BackGround> " + parseInt(bezel_num) });
            normal_background_bg_img.setProperty(hmUI.prop.SRC, "bg_" + parseInt(bezel_num) + ".png");
        }
		
		const thermometer = hmSensor.createSensor(hmSensor.id.BODY_TEMP)
		
		const sleep = hmSensor.createSensor(hmSensor.id.SLEEP);
		//let sleepInfo = sleep.getBasicInfo();
		
		let sleepTotalTime = sleep.getTotalTime();

		let sleepStageArray = sleep.getSleepStageData();
		const modelData = sleep.getSleepStageModel();
		
		function updateSleepInfo() {
			sleepTotalTime = sleep.getTotalTime();
			sleepStageArray = sleep.getSleepStageData();
			//sleepInfo = sleep.getBasicInfo();
			
			let wakeTime = 0;
			sleepStageArray = sleep.getSleepStageData();
			
			for (let i = 0; i < sleepStageArray.length; i++) {
			  let data = sleepStageArray[i];
			  if (data.model == modelData.WAKE_STAGE){
					wakeTime += data.stop + 1 - data.start;
			  }

			}
			
			sleepTotalTime -= wakeTime;
			if (sleepTotalTime < 0) sleepTotalTime = 0;

			sleep_time_txt.setProperty(hmUI.prop.TEXT, '' + Math.floor(sleepTotalTime / 60).toString().padStart(2, "0") + ':' + (sleepTotalTime % 60).toString().padStart(2, "0"));
       
        }
		
		let btn_zona1 = ''
        let zona1_num = 0
        let zona1_all = 5
		
		function click_zona1() {
		  zona1_num = (zona1_num + 1) % (zona1_all + 1);
          if (zona1_num == 0) {		
		    normal_pai_icon_img.setProperty(hmUI.prop.VISIBLE, true);
            normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.VISIBLE, true);
			normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.VISIBLE, true);
			normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, true);
			normal_compass_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_compass_direction_pointer_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_compass_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_compass_direction_img_level.setProperty(hmUI.prop.VISIBLE, false);
			normal_spo2_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_sun_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_sun_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
			normal_temperature_max_min_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_sun_high_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_sun_low_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_moon_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_step_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
			normal_stand_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
			normal_wind_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_wind_direction_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
			normal_wind_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
		    hmUI.showToast({
            });
          };
		  
		 if (zona1_num == 1) {
			normal_pai_icon_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.VISIBLE, false);
			normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.VISIBLE, false);
			normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, false);
			normal_compass_icon_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_compass_direction_pointer_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_compass_text_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_compass_direction_img_level.setProperty(hmUI.prop.VISIBLE, true);
			normal_spo2_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_sun_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_sun_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
			normal_temperature_max_min_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_sun_high_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_sun_low_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_moon_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_step_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
			normal_stand_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
			normal_wind_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_wind_direction_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
			normal_wind_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
		    hmUI.showToast({
            });
          };
		  
		  if (zona1_num == 2) {
			normal_pai_icon_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.VISIBLE, false);
			normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.VISIBLE, false);
			normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, false);
			normal_compass_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_compass_direction_pointer_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_compass_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_compass_direction_img_level.setProperty(hmUI.prop.VISIBLE, false);
			normal_spo2_icon_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_sun_icon_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_sun_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, true);
			normal_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
			normal_temperature_max_min_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_sun_high_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_sun_low_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_moon_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_step_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
			normal_stand_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
			normal_wind_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_wind_direction_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
			normal_wind_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
		    hmUI.showToast({
            });
          };
		  
		  if (zona1_num == 3) {
			normal_pai_icon_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.VISIBLE, false);
			normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.VISIBLE, false);
			normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, false);
			normal_compass_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_compass_direction_pointer_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_compass_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_compass_direction_img_level.setProperty(hmUI.prop.VISIBLE, false);
			normal_spo2_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_sun_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_sun_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);
			normal_temperature_max_min_text_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_sun_high_text_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_sun_low_text_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_moon_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_step_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
			normal_stand_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
			normal_wind_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_wind_direction_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
			normal_wind_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
		    hmUI.showToast({
            });
          };
		  
		  if (zona1_num == 4) {
			normal_pai_icon_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.VISIBLE, false);
			normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.VISIBLE, false);
			normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, false);
			normal_compass_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_compass_direction_pointer_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_compass_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_compass_direction_img_level.setProperty(hmUI.prop.VISIBLE, false);
			normal_spo2_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_sun_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_sun_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
			normal_temperature_max_min_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_sun_high_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_sun_low_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_moon_icon_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_step_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);
			normal_calorie_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);
			normal_stand_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);
			normal_wind_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_wind_direction_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
			normal_wind_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
		    hmUI.showToast({
            });
          };
		  
		  if (zona1_num == 5) {
			normal_pai_icon_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.VISIBLE, false);
			normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.VISIBLE, false);
			normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, false);
			normal_compass_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_compass_direction_pointer_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_compass_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_compass_direction_img_level.setProperty(hmUI.prop.VISIBLE, false);
			normal_spo2_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_sun_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_sun_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
			normal_temperature_max_min_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_sun_high_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_sun_low_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_moon_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_step_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
			normal_stand_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
			normal_wind_icon_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_wind_direction_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);
			normal_wind_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
		    hmUI.showToast({
            });
          };
        }
		
		let btn_zona2 = ''
        let zona2_num = 0
        let zona2_all = 2
		
		function click_zona2() {
		  zona2_num = (zona2_num + 1) % (zona2_all + 1);
          if (zona2_num == 0) {		
		    normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, true);
            normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_distance_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
		    hmUI.showToast({
            });
          };
		  
		 if (zona2_num == 1) {
			normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_distance_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
		    hmUI.showToast({
            });
          };
		  
		  if (zona2_num == 2) {
			normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_distance_icon_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
		    hmUI.showToast({
            });
          };
        }
		
		let btn_zona3 = ''
        let zona3_num = 0
        let zona3_all = 2
		
		function click_zona3() {
		  zona3_num = (zona3_num + 1) % (zona3_all + 1);
          if (zona3_num == 0) {		
		    normal_stand_icon_img.setProperty(hmUI.prop.VISIBLE, true);
            normal_stand_target_text_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_stand_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_fat_burning_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_fat_burning_target_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_fat_burning_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_uvi_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_floor_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
		    hmUI.showToast({
            });
          };
		  
		 if (zona3_num == 1) {
			normal_stand_icon_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_stand_target_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_stand_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_fat_burning_icon_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_fat_burning_target_text_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_fat_burning_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_uvi_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_floor_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
		    hmUI.showToast({
            });
          };
		  
		  if (zona3_num == 2) {
			normal_stand_icon_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_stand_target_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_stand_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_fat_burning_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_fat_burning_target_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_fat_burning_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_uvi_icon_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_floor_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
		    hmUI.showToast({
            });
          };
        }
		
		let btn_zona4 = ''
        let zona4_num = 0
        let zona4_all = 2
		
		function click_zona4() {
		  zona4_num = (zona4_num + 1) % (zona4_all + 1);
          if (zona4_num == 0) {		
		    normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, true);
            normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_humidity_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			sleep_time_txt.setProperty(hmUI.prop.VISIBLE, false);
			normal_altimeter_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_temp_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
		    hmUI.showToast({
            });
          };
		  
		 if (zona4_num == 1) {
			normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_humidity_icon_img.setProperty(hmUI.prop.VISIBLE, true);
			sleep_time_txt.setProperty(hmUI.prop.VISIBLE, true);
			normal_altimeter_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_temp_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
		    hmUI.showToast({
            });
          };
		  
		  if (zona4_num == 2) {
			normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_humidity_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			sleep_time_txt.setProperty(hmUI.prop.VISIBLE, false);
			normal_altimeter_icon_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_temp_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
		    hmUI.showToast({
            });
          };
        }
		
		let longPress_Timer = null;
	    let longPressDelay = 900;   // задержка на долгое нажатие в мс
		
		function getLongPress1() {
		    if(longPress_Timer) timer.stopTimer(longPress_Timer);
			
			let url;

			switch(zona1_num) {
			   case 0:
					url = 'CountdownAppScreen';
				break;
			   case 1:
					url = 'CompassScreen';
				break;
			   case 2:
					url = 'TideScreen';
				break;
			   case 3:
					url = 'WeatherScreen';
				break;
			   case 4:
					url = 'activityAppScreen';
				break;	
			   default:
				break;
			}
			hmApp.startApp({ url: url, native: true });
			
	    }
		
		function getLongPress4() {
		    if(longPress_Timer) timer.stopTimer(longPress_Timer);
			
			let url;

			switch(zona4_num) {
			   case 0:
					url = 'heart_app_Screen';
				break;
			   case 1:
					url = 'Sleep_HomeScreen';
				break;
			   case 2:
					url = 'tempHomeScreen';
				break;
			   default:
				break;
			}
			hmApp.startApp({ url: url, native: true });
			
	    }


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg_7.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 168,
              y: 146,
              week_en: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              week_tc: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              week_sc: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 170,
              y: 24,
              src: 'lock.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 228,
              y: 24,
              src: 'bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 287,
              y: 24,
              src: 'alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 228,
              y: 425,
              font_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: '%.png',
              unit_tc: '%.png',
              unit_en: '%.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 190,
              y: 431,
              image_array: ["A100_151.png","A100_152.png","A100_153.png","A100_154.png","A100_155.png","A100_156.png","A100_157.png","A100_158.png","A100_159.png","A100_160.png","A100_161.png"],
              image_length: 11,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 269,
              year_startY: 60,
              year_sc_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
              year_tc_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
              year_en_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
              year_zero: 0,
              year_space: 0,
              year_align: hmUI.align.CENTER_H,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 224,
              month_startY: 60,
              month_sc_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
              month_tc_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
              month_en_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
              month_zero: 1,
              month_space: 0,
              month_unit_sc: 'dot_1.png',
              month_unit_tc: 'dot_1.png',
              month_unit_en: 'dot_1.png',
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 179,
              day_startY: 60,
              day_sc_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
              day_tc_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
              day_en_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
              day_zero: 1,
              day_space: 0,
              day_unit_sc: 'dot_1.png',
              day_unit_tc: 'dot_1.png',
              day_unit_en: 'dot_1.png',
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 30,
              y: 263,
              src: 'temp.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			normal_temp_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 42,
              y: 300,
              font_array: ["f_0.png","f_1.png","f_2.png","f_3.png","f_4.png","f_5.png","f_6.png","f_7.png","f_8.png","f_9.png"],
              padding: false,
              h_space: 0,
              dot_image: 'dot.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BODY_TEMP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 30,
              y: 263,
              src: 'sleep.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			sleep_time_txt = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 40,			
              y: 288,			
			  w: 100,			
			  h: 50,			
			  text_size: 30,	
			  text: '',
			  color: 0x000000,	
              align_h: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 30,
              y: 263,
              src: 'bpm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 46,
              y: 300,
              font_array: ["f_0.png","f_1.png","f_2.png","f_3.png","f_4.png","f_5.png","f_6.png","f_7.png","f_8.png","f_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 199,
              y: 177,
              src: 'wind.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_direction_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 206,
              y: 183,
              image_array: ["wind_1.png","wind_2.png","wind_3.png","wind_4.png","wind_5.png","wind_6.png","wind_7.png","wind_8.png"],
              image_length: 8,
              type: hmUI.data_type.WIND_DIRECTION,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 264,
              y: 244,
              font_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WIND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 199,
              y: 177,
              src: 'A100_118.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_uvi_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 368,
              y: 177,
              src: 'floor.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_floor_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 380,
              y: 258,
              font_array: ["fts_0.png","fts_1.png","fts_2.png","fts_3.png","fts_4.png","fts_5.png","fts_6.png","fts_7.png","fts_8.png","fts_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.FLOOR,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_fat_burning_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 368,
              y: 177,
              src: 'fat.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_fat_burning_target_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 387,
              y: 280,
              font_array: ["f_0.png","f_1.png","f_2.png","f_3.png","f_4.png","f_5.png","f_6.png","f_7.png","f_8.png","f_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.FAT_BURNING_TARGET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_fat_burning_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 387,
              y: 241,
              font_array: ["f_0.png","f_1.png","f_2.png","f_3.png","f_4.png","f_5.png","f_6.png","f_7.png","f_8.png","f_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.FAT_BURNING,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 368,
              y: 177,
              src: 'stand.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_target_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 393,
              y: 280,
              font_array: ["f_0.png","f_1.png","f_2.png","f_3.png","f_4.png","f_5.png","f_6.png","f_7.png","f_8.png","f_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STAND_TARGET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 379,
              y: 243,
              font_array: ["f_0.png","f_1.png","f_2.png","f_3.png","f_4.png","f_5.png","f_6.png","f_7.png","f_8.png","f_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STAND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 199,
              y: 177,
              image_array: ["cal_1.png","cal_2.png","cal_3.png","cal_4.png","cal_5.png","cal_6.png","cal_7.png","cal_8.png","cal_9.png","cal_10.png","cal_11.png"],
              image_length: 11,
              type: hmUI.data_type.STAND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 30,
              y: 178,
              src: 'alt.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 48,
              y: 214,
              font_array: ["f_0.png","f_1.png","f_2.png","f_3.png","f_4.png","f_5.png","f_6.png","f_7.png","f_8.png","f_9.png"],
              padding: false,
              h_space: 0,
              dot_image: 'dot.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 30,
              y: 178,
              src: 'kcal.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 33,
              y: 214,
              font_array: ["f_0.png","f_1.png","f_2.png","f_3.png","f_4.png","f_5.png","f_6.png","f_7.png","f_8.png","f_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 199,
              y: 177,
              image_array: ["fat_1.png","fat_2.png","fat_3.png","fat_4.png","fat_5.png","fat_6.png","fat_7.png","fat_8.png","fat_9.png","fat_10.png"],
              image_length: 10,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 30,
              y: 178,
              src: 'A100_128.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 45,
              y: 215,
              font_array: ["f_0.png","f_1.png","f_2.png","f_3.png","f_4.png","f_5.png","f_6.png","f_7.png","f_8.png","f_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 199,
              y: 177,
              image_array: ["step_1.png","step_2.png","step_3.png","step_4.png","step_5.png","step_6.png","step_7.png","step_8.png","step_9.png","step_10.png"],
              image_length: 10,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 199,
              y: 177,
              src: 'weather.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 205,
              y: 189,
              image_array: ["w_1.png","w_2.png","w_3.png","w_4.png","w_5.png","w_6.png","w_7.png","w_8.png","w_9.png","w_10.png","w_11.png","w_12.png","w_13.png","w_14.png","w_15.png","w_16.png","w_17.png","w_18.png","w_19.png","w_20.png","w_21.png","w_22.png","w_23.png","w_24.png","w_25.png","w_26.png","w_27.png","w_28.png","w_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_max_min_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 231,
              y: 272,
              font_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
              padding: false,
              h_space: 0,
              negative_image: 'dot11.png',
              dot_image: 'dot_1.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_HIGH_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 295,
              y: 220,
              font_array: ["fs_0.png","fs_1.png","fs_2.png","fs_3.png","fs_4.png","fs_5.png","fs_6.png","fs_7.png","fs_8.png","fs_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'gradus.png',
              unit_tc: 'gradus.png',
              unit_en: 'gradus.png',
              negative_image: 'dot211.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 199,
              y: 177,
              src: 'sun_icon.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 221,
              y: 308,
              font_array: ["fonts_0.png","fonts_1.png","fonts_2.png","fonts_3.png","fonts_4.png","fonts_5.png","fonts_6.png","fonts_7.png","fonts_8.png","fonts_9.png"],
              padding: false,
              h_space: -1,
              dot_image: 'dots.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 283,
              y: 308,
              font_array: ["fonts_0.png","fonts_1.png","fonts_2.png","fonts_3.png","fonts_4.png","fonts_5.png","fonts_6.png","fonts_7.png","fonts_8.png","fonts_9.png"],
              padding: false,
              h_space: -1,
              dot_image: 'dots.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'sun.png',
              center_x: 281,
              center_y: 256,
              x: 82,
              y: 75,
              start_angle: -104,
              end_angle: 104,
              invalid_visible: false,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 203,
              y: 181,
              src: 'mask.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_compass_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 199,
              y: 177,
              src: 'compass.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const deviceInfo = hmSetting.getDeviceInfo();
            
            // normal_compass_custom_pointer_img = hmUI.createWidget(hmUI.widget.CUSTOM_POINTER, {
              // src: 'comp_point.png',
              // center_x: 280,
              // center_y: 259,
              // x: 16,
              // y: 77,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.COMPASS,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            //start of ignored block
            normal_compass_direction_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 280 - 16,
              pos_y: 259 - 77,
              center_x: 280,
              center_y: 259,
              src: 'comp_point.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            //end of ignored block

            normal_compass_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 243,
              y: 240,
              font_array: ["f_0.png","f_1.png","f_2.png","f_3.png","f_4.png","f_5.png","f_6.png","f_7.png","f_8.png","f_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.COMPASS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_compass_direction_img_level = hmUI.createWidget(hmUI.widget.IMG, {
              x: 257,
              y: 265,
              src: 'd_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
              // type: hmUI.data_type.COMPASS,
            });

            normal_pai_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 199,
              y: 177,
              src: 'A100_123.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'A100_126.png',
              hour_centerX: 280,
              hour_centerY: 257,
              hour_posX: 8,
              hour_posY: 52,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'A100_127.png',
              minute_centerX: 280,
              minute_centerY: 257,
              minute_posX: 8,
              minute_posY: 68,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'wfs_property1prism2_0cf0b85a_548b_4351_8169_f7827c39e452.png',
              second_centerX: 280,
              second_centerY: 257,
              second_posX: 62,
              second_posY: 75,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 117,
              hour_startY: 95,
              hour_array: ["A100_003.png","A100_004.png","A100_005.png","A100_006.png","A100_007.png","A100_008.png","A100_009.png","A100_010.png","A100_011.png","A100_012.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_unit_sc: 'A100_013.png',
              hour_unit_tc: 'A100_013.png',
              hour_unit_en: 'A100_013.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 250,
              minute_startY: 95,
              minute_array: ["A100_003.png","A100_004.png","A100_005.png","A100_006.png","A100_007.png","A100_008.png","A100_009.png","A100_010.png","A100_011.png","A100_012.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 373,
              second_startY: 124,
              second_array: ["sec_0.png","sec_1.png","sec_2.png","sec_3.png","sec_4.png","sec_5.png","sec_6.png","sec_7.png","sec_8.png","sec_9.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Shortcuts');

            btn_zona2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 50,
              y: 177,
              text: '',
              w: 130,
              h: 80,
              normal_src: 'Empty.png',
              press_src: 'Empty.png',
              click_func: () => {
				click_zona2();
             },
			 longpress_func: () => {
             hmApp.startApp({url: 'activityWeekShowScreen', native: true });
             },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btn_zona2.setProperty(hmUI.prop.VISIBLE, true);
			normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_distance_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);

            btn_zona4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 50,
              y: 263,
              text: '',
              w: 130,
              h: 80,
              normal_src: 'Empty.png',
              press_src: 'Empty.png',
              click_func: () => {
				click_zona4();
				},
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btn_zona4.setProperty(hmUI.prop.VISIBLE, true);
			normal_humidity_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			sleep_time_txt.setProperty(hmUI.prop.VISIBLE, false);
			normal_altimeter_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_temp_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			
			btn_zona4.addEventListener(hmUI.event.CLICK_DOWN, function () {
					if(longPress_Timer) timer.stopTimer(longPress_Timer);
					longPress_Timer = timer.createTimer(longPressDelay, 0, getLongPress4, {});
			});
			btn_zona4.addEventListener(hmUI.event.CLICK_UP, function () {
					if(longPress_Timer) timer.stopTimer(longPress_Timer);
			});

            btn_zona1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 230,
              y: 208,
              text: '',
              w: 100,
              h: 100,
              normal_src: 'Empty.png',
              press_src: 'Empty.png',
              click_func: () => {
				click_zona1();
             },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btn_zona1.setProperty(hmUI.prop.VISIBLE, true);
			normal_compass_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_compass_direction_pointer_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_compass_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_compass_direction_img_level.setProperty(hmUI.prop.VISIBLE, false);
			normal_spo2_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_sun_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_sun_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
			normal_temperature_max_min_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_sun_high_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_sun_low_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_moon_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_step_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
			normal_stand_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
			normal_wind_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_wind_direction_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
			normal_wind_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			
			btn_zona1.addEventListener(hmUI.event.CLICK_DOWN, function () {
					if(longPress_Timer) timer.stopTimer(longPress_Timer);
					longPress_Timer = timer.createTimer(longPressDelay, 0, getLongPress1, {});
			});
			btn_zona1.addEventListener(hmUI.event.CLICK_UP, function () {
					if(longPress_Timer) timer.stopTimer(longPress_Timer);
			});

            btn_zona3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 368,
              y: 215,
              text: '',
              w: 83,
              h: 100,
              normal_src: 'Empty.png',
              press_src: 'Empty.png',
              click_func: () => {
				click_zona3();
             },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btn_zona3.setProperty(hmUI.prop.VISIBLE, true);
			normal_fat_burning_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_fat_burning_target_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_fat_burning_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_uvi_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_floor_text_text_img.setProperty(hmUI.prop.VISIBLE, false);

            btn_bezel = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 186,
              y: 425,
              text: '',
              w: 100,
              h: 50,
              normal_src: 'Empty.png',
              press_src: 'Empty.png',
              click_func: () => {
                  click_Bezel();
              },
			  longpress_func: () => {
             hmApp.startApp({url: 'Settings_batteryManagerScreen', native: true });
             },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btn_bezel.setProperty(hmUI.prop.VISIBLE, true);

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 86,
              y: 350,
              w: 60,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PhoneRecentCallScreen', native: true });
              }, // end func
              longpress_func: (button_widget) => {
                hmApp.startApp({url: 'PhoneContactsScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 166,
              y: 350,
              w: 60,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'Settings_homeScreen', native: true });
              }, // end func
              longpress_func: (button_widget) => {
                hmApp.startApp({url: 'HmReStartScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 248,
              y: 350,
              w: 60,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'VoiceMemoScreen', native: true });
              }, // end func
              longpress_func: (button_widget) => {
                hmApp.startApp({url: 'ClubCardsScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 332,
              y: 350,
              w: 60,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'LocalMusicScreen', native: true });
              }, // end func
              longpress_func: (button_widget) => {
                hmApp.startApp({url: 'PhoneMusicCtrlScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            let screenType = hmSetting.getScreenType();
            //start of ignored block
            console.log('compass_update()');
            if (screenType == hmSetting.screen_type.WATCHFACE){
              compass = hmSensor.createSensor(hmSensor.id.COMPASS);
              compass.start();

              if (compass.direction_angle && compass.direction  && compass.direction_angle != 'INVALID') { // initial data
                // Compass Pointer
                let compass_direction_angle = parseInt(compass.direction_angle);
                normal_compass_direction_pointer_img.setProperty(hmUI.prop.ANGLE, -compass_direction_angle);
                // Compass Number
                let normal_compass_direction_angle_text = compass_direction_angle.toString();
                normal_compass_text_img.setProperty(hmUI.prop.TEXT, normal_compass_direction_angle_text);
                // Compass Images
                let compass_direction_angle_img = compass_direction_angle + 45 / 2;
                let compass_direction_index = parseInt(compass_direction_angle_img/45);
                if (compass_direction_index > 7) compass_direction_index = 0;
                normal_compass_direction_img_level.setProperty(hmUI.prop.SRC, normal_compass_direction_arr[compass_direction_index]);

              } else { // error data
                normal_compass_direction_pointer_img.setProperty(hmUI.prop.ANGLE, 0);
                normal_compass_text_img.setProperty(hmUI.prop.TEXT, '-');
                normal_compass_direction_img_level.setProperty(hmUI.prop.SRC, normal_compass_direction_arr[0]);

              }

              compass.addEventListener(hmSensor.event.CHANGE, function (compass_res) { // change values when changing direction

                if (compass_res.calibration_status) {
                  // Compass Pointer
                  let compass_direction_angle = parseInt(compass_res.direction_angle);
                  normal_compass_direction_pointer_img.setProperty(hmUI.prop.ANGLE, -compass_direction_angle);
                  // Compass Number
                  let normal_compass_direction_angle_text = compass_direction_angle.toString();
                  normal_compass_text_img.setProperty(hmUI.prop.TEXT, normal_compass_direction_angle_text);
                  // Compass Images
                  let compass_direction_angle_img = compass_direction_angle + 45 / 2;
                  let compass_direction_index = parseInt(compass_direction_angle_img/45);
                  if (compass_direction_index > 7) compass_direction_index = 0;
                  normal_compass_direction_img_level.setProperty(hmUI.prop.SRC, normal_compass_direction_arr[compass_direction_index]);

                } else { // error data
                  normal_compass_direction_pointer_img.setProperty(hmUI.prop.ANGLE, 0);
                  normal_compass_text_img.setProperty(hmUI.prop.TEXT, '-');
                  normal_compass_direction_img_level.setProperty(hmUI.prop.SRC, normal_compass_direction_arr[0]);

                }

              }); // Listener end

            };
            //end of ignored block

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
				updateSleepInfo();
                if (compass && screenType == hmSetting.screen_type.WATCHFACE) compass.start();

              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (compass) compass.stop();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
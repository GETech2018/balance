﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

const {
 width: D_W,
 height: D_H
} = hmSetting.getDeviceInfo();

let kof = D_W / 466

let Button_Cal = '';
let baroText = '';
let normal_timerTimeUpdate_2 = undefined;
let idle_analog_clock_time_pointer_hour = '';
let idle_analog_clock_time_pointer_minute = '';

function loadSettings() {
 select = hmFS.SysProGetInt('Iv_Carbon_IV_select') === undefined ? (hmFS.SysProSetInt('Iv_Carbon_IV_select', 0), 0) : hmFS.SysProGetInt('Iv_Carbon_IV_select');
}

// запуск приложения с заданным appId (если оно установлено) или системного приложения
function launchAppOrAppId(url, appId, page = 'page/index') {
 let appInstalled = false;
 try {
  const id16 = appId.toString(16).padStart(8, "0"); // переводим appId в 16-ричный формат
  const [fs_stat, err] = hmFS.stat_asset(`../../../js_apps/${id16}/app.json`); // проверяем наличие файла 'app.json' в папке приложения
  if (err == 0) { //  если файл есть,  то приложение установлено
   appInstalled = true;
  } else {
   console.log("err:", err);
  }
 } catch (error) {
  console.log("error:", error);
  console.log("FAIL: No access to hmFS.");
 }
 if (appInstalled) hmApp.startApp({
  appid: appId,
  url: page
 })
 else hmApp.startApp({
  url: url,
  native: true
 });
}

   let str_VIS = true;

   function str_off() {
    str_VIS = !str_VIS
    normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.VISIBLE, str_VIS);
    normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.VISIBLE, str_VIS);
    normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, str_VIS);

   }

   let str_x = [
    [30, 122, 26, 181, 20, 212],
    [51, 150, 40, 225, 24, 222],
    [25, 132, 26, 191, 20, 208],
    [7, 129, 11, 204, 11, 215],
    [20, 134, 19, 205, 19, 214],
   ];

   let select = 0;

   function str_select() {
    select = (select + 1) % 5
    hmFS.SysProSetInt('Iv_Carbon_IV_select', select);

    normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.MORE, {
     hour_path: 'str_H_' + select + '.png',
     hour_centerX: 233 * kof,
     hour_centerY: 233 * kof,
     hour_posX: str_x[select][0] * kof,
     hour_posY: str_x[select][1] * kof,
     show_level: hmUI.show_level.ONLY_NORMAL,
    });
    normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.MORE, {
     minute_path: 'str_M_' + select + '.png',
     minute_centerX: 233 * kof,
     minute_centerY: 233 * kof,
     minute_posX: str_x[select][2] * kof,
     minute_posY: str_x[select][3] * kof,
     show_level: hmUI.show_level.ONLY_NORMAL,
    });
    normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.MORE, {
     second_path: 'str_S_' + select + '.png',
     second_centerX: 233 * kof,
     second_centerY: 233 * kof,
     second_posX: str_x[select][4] * kof,
     second_posY: str_x[select][5] * kof,
     second_cover_path: 'str.png',
     second_cover_x: 220 * kof,
     second_cover_y: 219 * kof,
     show_level: hmUI.show_level.ONLY_NORMAL,
    });
   }

   function block_on() {
    normal_vo2max_icon_img.setProperty(hmUI.prop.SRC, 'ic_block_on.png');
    normal_vo2max_icon_img.setAlpha(255);
    Button_1.setProperty(hmUI.prop.VISIBLE, false);
    Button_2.setProperty(hmUI.prop.VISIBLE, false);
    Button_3.setProperty(hmUI.prop.VISIBLE, false);
    Button_4.setProperty(hmUI.prop.VISIBLE, false);
    Button_5.setProperty(hmUI.prop.VISIBLE, false);
    Button_6.setProperty(hmUI.prop.VISIBLE, false);
    Button_7.setProperty(hmUI.prop.VISIBLE, false);
    Button_8.setProperty(hmUI.prop.VISIBLE, true);
    Button_9.setProperty(hmUI.prop.VISIBLE, false);
   }

   function block_off() {
    normal_vo2max_icon_img.setProperty(hmUI.prop.SRC, 'ic_block_off.png');
    normal_vo2max_icon_img.setAlpha(128);
    Button_1.setProperty(hmUI.prop.VISIBLE, false);
    Button_1.setProperty(hmUI.prop.VISIBLE, true);
    Button_2.setProperty(hmUI.prop.VISIBLE, true);
    Button_3.setProperty(hmUI.prop.VISIBLE, true);
    Button_4.setProperty(hmUI.prop.VISIBLE, true);
    Button_5.setProperty(hmUI.prop.VISIBLE, true);
    Button_6.setProperty(hmUI.prop.VISIBLE, true);
    Button_7.setProperty(hmUI.prop.VISIBLE, true);
    Button_8.setProperty(hmUI.prop.VISIBLE, false);
    Button_9.setProperty(hmUI.prop.VISIBLE, true);
   }


   function widget_start() {
    normal_vo2max_icon_img.setProperty(hmUI.prop.SRC, 'ic_block_off.png');
    normal_vo2max_icon_img.setAlpha(128);
    Button_1.setProperty(hmUI.prop.VISIBLE, false);
    Button_1.setProperty(hmUI.prop.VISIBLE, true);
    Button_2.setProperty(hmUI.prop.VISIBLE, true);
    Button_3.setProperty(hmUI.prop.VISIBLE, true);
    Button_4.setProperty(hmUI.prop.VISIBLE, true);
    Button_5.setProperty(hmUI.prop.VISIBLE, true);
    Button_6.setProperty(hmUI.prop.VISIBLE, true);
    Button_7.setProperty(hmUI.prop.VISIBLE, true);
    Button_8.setProperty(hmUI.prop.VISIBLE, false);
    Button_9.setProperty(hmUI.prop.VISIBLE, true);
   }


   const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE)
   let stopVibro_Timer = null;

   function vibro(scene = 25) {
    let stopDelay = 50;
    vibrate.stop();
    vibrate.scene = scene;
    if (scene < 23 || scene > 25) stopDelay = 1220;
    vibrate.start();
    stopVibro_Timer = timer.createTimer(stopDelay, 0, stopVibro, {});
   }

   function stopVibro() {
    vibrate.stop();
    timer.stopTimer(stopVibro_Timer);
   }

/********************************
*	класс AdvancedBarometer		*
*		v1.2 (через сенсор)		*
*		2025 © leXxiR [4pda]	*
********************************/
	class AdvancedBarometer {
	  constructor(props = {}) {
		this.props = {
			unit_index: hmFS.SysProGetInt('BaroUnitIndex') ?? 0,		// текущий индекс единицы измерения (сохраняется и считывается из памяти): 0 - мм рт.ст., 1 - гПа
			show_toast: true,											// показывать всплывающее сообщение при переключении единицы измерения
			widget: null,												// виджет TEXT для отображения давления
			show_trend: true,											// показывать тренд (растет, падает) после значения давления при обновлении виджета
			time_sensor: null,											// сенсор времени (для обновления давления), если не задан, то создается новый
			baro_sensor: null,											// сенсор давления, если не задан, то создается новый
			auto_update: true,											// автоматическое обновление давления (нет необходимости добавлять метод .update() в event.MINUTEEND и WIDGET_DELEGATE)
			d_time: 30,													// период времени (в мин), после которого происходит переинициализация опорного давления
			lang: hmSetting.getLanguage() == 4 ? 0 : 1,					// языка устройства	(Русский = 0 / Английский = 1)
			...props,
		};

		this.unitStr = [	['мм рт.ст.',  'mmHg'],		// 0
							['гПа',  'hPa'],			// 1	
						]

		this.last = {
			value: null,
			trend: '',
		}

		this.prev = {
			value: null,
			time: 0,
		}

		if (!this.props.time_sensor) this.props.time_sensor = hmSensor.createSensor(hmSensor.id.TIME);
		if (!this.props.baro_sensor) this.props.baro_sensor = hmSensor.createSensor(hmSensor.id.BARO);
		if (isFinite(props.unit_index)) hmFS.SysProSetInt('BaroUnitIndex', props.unit_index);
		if (this.props.auto_update) this.createHandlers();
	  }

	// создание обработчиков автоматического обновления давления
		createHandlers() {
			this.props.time_sensor.addEventListener(this.props.time_sensor.event.MINUTEEND, () => this.update());

			this.widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
			  resume_call: ( () => this.update() )
			})
		}

	// получить текущее значения  давления и тренда
		getPressureAndTrend(){
			const value = this.props.baro_sensor.pressure;
			//const value = randomInt(980, 1020)

			let trend = '';
			let pressureChange = 0;
			
			if (value && this.prev.value) pressureChange = value - this.prev.value;

			if (pressureChange < 0) trend = "↓";
			else if (pressureChange > 0) trend = "↑";

			return {value, trend}
		}

	// задать опорное показание давления и время его измерения
		set referenceValue(v) {
			this.prev.value = v;
			this.prev.time = Date.now();
		}

	// пришло время обновить опорное значение (если прошло времени больше, чем d_time)
		get needToUpdateReference() {
			return (Date.now() - this.prev.time > this.props.d_time * 1000 * 60)
		}

	// установить единицы измерения по индексу: 0 - мм рт.ст., 1 - гПа
		setUnits(unit_index) {
			if(!isFinite(unit_index)) return
			this.props.unit_index = unit_index == 1 ? 1 : 0;
			hmFS.SysProSetInt('BaroUnitIndex', this.props.unit_index);
			if (this.props.widget) this.updateWidget();
		}

	// переключить единицы измерения на следующие по кругу
		toggleUnits(show_toast = this.props.show_toast) {
			const newIndex = (this.props.unit_index + 1) % this.unitStr.length;
			this.setUnits(newIndex);
			if (show_toast) hmUI.showToast({text: this.unit});
		}

	// обновить показания давления и виджет
		update() {
			const {value, trend}  = this.getPressureAndTrend();
			if (value != this.last.value || trend != this.last.trend){
				this.last.value = value;
				this.last.trend = trend;
				if (this.props.widget) this.updateWidget();
			}
			
			// обновляем опорное значение, если вышло время
			if (this.needToUpdateReference) this.referenceValue = value;
		}

	// обновить виджет
		updateWidget() {
			let str = this.pressure;
			if (this.props.show_trend) str += ` ${this.last.trend}`;
			this.props.widget.setProperty(hmUI.prop.TEXT, str);
		}

	// получить текущее значение давление в мм рт. ст.
		get mmHg() {
			let v = this.last.value;
			if (!(v)) return '--'
			else v *= 0.750064;
			return Math.round(v).toString();
		}

	// получить текущее значение давление в гПа
		get hPa() {
			let v = this.last.value;
			if (!(v)) return '--'
			return this.last.value
		}

	// получить давление в текущих единицах измерения
		get pressure() {
			if (this.props.unit_index == 0) return this.mmHg
			else return this.hPa
		}

	// получить название текущей единицы измерения
		get unit() {
			return this.unitStr[this.props.unit_index][this.props.lang]
		}

	// получить индекс текущей единицы измерения
		get unit_index() {
			return this.props.unit_index
		}

	// получить тренд
		get trend() {
			return this.last.trend
		}

	// удалить
	  delete() {
		this.props = null;
		this.last = null;
		this.unitStr = null;
		if (this.widgetDelegate) {
			hmUI.deleteWidget(this.widgetDelegate);
			this.widgetDelegate = null;
		}
	  }

	}


 
 
        // end user_functions.js

        let editBg = ''
        let editGroup_1  = ''
        let editGroup_2  = ''
        let editGroup_3  = ''
        let mask = ''
        let fg_mask = ''
        let normal_dow_text_font = ''
        let normal_DOW_Array = ['ПОНЕДЕЛЬНИК', 'ВТОРНИК', 'СРЕДА', 'ЧЕТВЕРГ', 'ПЯТНИЦА', 'СУББОТА', 'ВОСКРЕСЕНЬЕ'];
        let normal_month_name_font = ''
        let normal_Month_Array = ['ЯНВАРЯ', 'ФЕВРАЛЯ', 'МАРТА', 'АПРЕЛЯ', 'МАЯ', 'ИЮНЯ', 'ИЮЛЯ', 'АВГУСТА', 'СЕНТЯБРЯ', 'ОКТЯБРЯ', 'НОЯБРЯ', 'ДЕКАБРЯ', ];
        let normal_day_text_font = ''
        let normal_battery_current_text_font = ''
        let normal_time_hour_min_text_font = ''
        let normal_timerTimeUpdate = undefined;
        let normal_alarm_clock_icon_img = ''
        let normal_alarm_clock_current_text_font = ''
        let normal_altimeter_icon_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_font = ''
        let normal_pai_icon_img = ''
        let normal_stress_icon_img = ''
        let normal_stand_icon_img = ''
        let normal_vo2max_icon_img = ''
        let normal_floor_icon_img = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_battery_current_text_font = ''
        let idle_time_hour_min_text_font = ''
        let idle_timerTimeUpdate = undefined;
        let idle_vo2max_icon_img = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let Button_7 = ''
        let Button_8 = ''
        let Button_9 = ''
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            // FontName: arbrnplt.ttf; FontSize: 27; Cache: full
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 32,
              h: 32,
              text_size: 27,
              char_space: 0,
              line_space: 0,
              font: 'fonts/arbrnplt.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: arbrnplt.ttf; FontSize: 47
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 682,
              h: 63,
              text_size: 47,
              char_space: 0,
              line_space: 0,
              font: 'fonts/arbrnplt.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: arbrnplt.ttf; FontSize: 37
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 542,
              h: 50,
              text_size: 37,
              char_space: 0,
              line_space: 0,
              font: 'fonts/arbrnplt.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('user_script_start.js');
            // start user_script_start.js

loadSettings();

hmUI.createWidget(hmUI.widget.TEXT, {
 x: 464,
 y: 464,
 w: 31,
 h: 31,
 text_size: 26,
 char_space: 0,
 line_space: 0,
 font: 'fonts/arbrnplt.ttf',
 color: 0xFFFFFFFF,
 align_h: hmUI.align.LEFT,
 align_v: hmUI.align.CENTER_V,
 text_style: hmUI.text_style.NONE,
 text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/↑↓",
 show_level: hmUI.show_level.ONLY_NORMAL,
});
            // end user_script_start.js

            console.log('Watch_Face.ScreenNormal');
            editBg = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_BG, {
              edit_id: 1002,
              x: 0,
              y: 0,
              // w: 480,
              // h: 480,
              // AOD_show: True,
              bg_config: [
                { id: 1, preview: 'bg_edit_1_preview.png', path: 'bg_0.png' },
                { id: 2, preview: 'bg_edit_2_preview.png', path: 'bg_1.png' },
                { id: 3, preview: 'bg_edit_3_preview.png', path: 'bg_2.png' },
                { id: 4, preview: 'bg_edit_4_preview.png', path: 'bg_3.png' },
              ],
              count: 4,
              default_id: 1,
              fg: '.png',
              tips_bg: 'tips_bg.png',
              tips_x: 140,
              tips_y: 364,
            });
            console.log('Watch_Face.Editable_Elements before AOD');

            editGroup_1 = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
              edit_id: 10021,
              x: 35,
              y: 174,
              w: 165,
              h: 52,
              select_image: 'select_on.png',
              un_select_image: 'select_off.png',
              default_type: hmUI.edit_type.WEATHER,
              optional_types: [
                { type: hmUI.edit_type.WEATHER, preview: 'ez(1)_WEATHER.png' },
                { type: hmUI.edit_type.CAL, preview: 'ez(1)_CAL.png' },
                { type: hmUI.edit_type.HEART, preview: 'ez(1)_HEART.png' },
                { type: hmUI.edit_type.STEP, preview: 'ez(1)_STEP.png' },
                { type: hmUI.edit_type.DISTANCE, preview: 'ez(1)_DISTANCE.png' },
                { type: hmUI.edit_type.HUMIDITY, preview: 'ez(1)_HUMIDITY.png' },
                { type: hmUI.edit_type.WIND, preview: 'ez(1)_WIND.png' },
                { type: hmUI.edit_type.PAI, preview: 'ez(1)_PAI.png' },
                { type: hmUI.edit_type.STAND, preview: 'ez(1)_STAND.png' },
                { type: hmUI.edit_type.STRESS, preview: 'ez(1)_STRESS.png' },
                { type: hmUI.edit_type.UVI, preview: 'ez(1)_UVI.png' },
                { type: hmUI.edit_type.FAT_BURN, preview: 'ez(2)_FAT_BURNING.png'},
                { type: hmUI.edit_type.MOON, preview: 'ez(1)_MOON.png' },
                { type: hmUI.edit_type.BATTERY, preview: 'ez(1)_BATTERY.png' },
              ],
              count: 14,
              select_list: {
                title_font_size: 34,
                title_align_h: hmUI.align.CENTER_H,
                list_item_vspace: 8,
                list_tips_text_font_size: 32,
                list_tips_text_align_h: hmUI.align.LEFT
              },
              tips_BG: 'tips_bg.png',
              tips_x: 33,
              tips_y: -72,
              tips_width: 201,
              tips_margin: 4,
            });

            const editType_1 = editGroup_1.getProperty(hmUI.prop.CURRENT_TYPE);

            switch (editType_1) {
              case hmUI.edit_type.BATTERY:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 46,
                  y: 188,
                  src: 'AL_0.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.STEP:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 46,
                  y: 187,
                  src: 'ic_14.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 87,
                  y: 188,
                  font_array: ["dig_a_0.png","dig_a_1.png","dig_a_2.png","dig_a_3.png","dig_a_4.png","dig_a_5.png","dig_a_6.png","dig_a_7.png","dig_a_8.png","dig_a_9.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.LEFT,
                  type: hmUI.data_type.STEP,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.CAL:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 46,
                  y: 187,
                  src: 'ic_13.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 87,
                  y: 188,
                  font_array: ["dig_a_0.png","dig_a_1.png","dig_a_2.png","dig_a_3.png","dig_a_4.png","dig_a_5.png","dig_a_6.png","dig_a_7.png","dig_a_8.png","dig_a_9.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.LEFT,
                  type: hmUI.data_type.CAL,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.HEART:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 46,
                  y: 187,
                  src: 'ic_12.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 87,
                  y: 188,
                  font_array: ["dig_a_0.png","dig_a_1.png","dig_a_2.png","dig_a_3.png","dig_a_4.png","dig_a_5.png","dig_a_6.png","dig_a_7.png","dig_a_8.png","dig_a_9.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.LEFT,
                  type: hmUI.data_type.HEART,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.PAI:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 87,
                  y: 188,
                  font_array: ["dig_a_0.png","dig_a_1.png","dig_a_2.png","dig_a_3.png","dig_a_4.png","dig_a_5.png","dig_a_6.png","dig_a_7.png","dig_a_8.png","dig_a_9.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.LEFT,
                  type: hmUI.data_type.PAI_WEEKLY,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 46,
                  y: 186,
                  src: 'ic_5.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.DISTANCE:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 87,
                  y: 188,
                  font_array: ["dig_a_0.png","dig_a_1.png","dig_a_2.png","dig_a_3.png","dig_a_4.png","dig_a_5.png","dig_a_6.png","dig_a_7.png","dig_a_8.png","dig_a_9.png"],
                  padding: false,
                  h_space: 0,
                  dot_image: 'dig_a_dot.png',
                  align_h: hmUI.align.LEFT,
                  type: hmUI.data_type.DISTANCE,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 46,
                  y: 187,
                  src: 'ic_7.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.STAND:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 87,
                  y: 188,
                  font_array: ["dig_a_0.png","dig_a_1.png","dig_a_2.png","dig_a_3.png","dig_a_4.png","dig_a_5.png","dig_a_6.png","dig_a_7.png","dig_a_8.png","dig_a_9.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.LEFT,
                  type: hmUI.data_type.STAND,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                editableZone_1_stand_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
                  x: 46,
                  y: 186,
                  src: 'ic_23.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.STRESS:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 87,
                  y: 188,
                  font_array: ["dig_a_0.png","dig_a_1.png","dig_a_2.png","dig_a_3.png","dig_a_4.png","dig_a_5.png","dig_a_6.png","dig_a_7.png","dig_a_8.png","dig_a_9.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.LEFT,
                  type: hmUI.data_type.STRESS,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 46,
                  y: 186,
                  src: 'ic_24.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.FAT_BURN:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 87,
                  y: 188,
                  font_array: ["dig_a_0.png","dig_a_1.png","dig_a_2.png","dig_a_3.png","dig_a_4.png","dig_a_5.png","dig_a_6.png","dig_a_7.png","dig_a_8.png","dig_a_9.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.LEFT,
                  type: hmUI.data_type.FAT_BURNING,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 46,
                  y: 187,
                  src: 'ic_21.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.WEATHER:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 46,
                  y: 186,
                  src: 'ic_18.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 127,
                  y: 188,
                  font_array: ["dig_a_0.png","dig_a_1.png","dig_a_2.png","dig_a_3.png","dig_a_4.png","dig_a_5.png","dig_a_6.png","dig_a_7.png","dig_a_8.png","dig_a_9.png"],
                  padding: false,
                  h_space: 0,
                  unit_sc: 'AL_0.png',
                  unit_tc: 'AL_0.png',
                  unit_en: 'AL_0.png',
                  negative_image: 'dig_a_m.png',
                  invalid_image: 'dig_a_m.png',
                  align_h: hmUI.align.LEFT,
                  type: hmUI.data_type.WEATHER_HIGH,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 65,
                  y: 188,
                  font_array: ["dig_a_0.png","dig_a_1.png","dig_a_2.png","dig_a_3.png","dig_a_4.png","dig_a_5.png","dig_a_6.png","dig_a_7.png","dig_a_8.png","dig_a_9.png"],
                  padding: false,
                  h_space: 0,
                  unit_sc: 'AL_0.png',
                  unit_tc: 'AL_0.png',
                  unit_en: 'AL_0.png',
                  negative_image: 'dig_a_m.png',
                  invalid_image: 'dig_a_m.png',
                  align_h: hmUI.align.RIGHT,
                  type: hmUI.data_type.WEATHER_LOW,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 107,
                  y: 186,
                  src: 'ic_19.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.UVI:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 87,
                  y: 188,
                  font_array: ["dig_a_0.png","dig_a_1.png","dig_a_2.png","dig_a_3.png","dig_a_4.png","dig_a_5.png","dig_a_6.png","dig_a_7.png","dig_a_8.png","dig_a_9.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.LEFT,
                  type: hmUI.data_type.UVI,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 46,
                  y: 187,
                  src: 'ic_25.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.HUMIDITY:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 87,
                  y: 188,
                  font_array: ["dig_a_0.png","dig_a_1.png","dig_a_2.png","dig_a_3.png","dig_a_4.png","dig_a_5.png","dig_a_6.png","dig_a_7.png","dig_a_8.png","dig_a_9.png"],
                  padding: false,
                  h_space: 0,
                  unit_sc: 'ic_20.png',
                  unit_tc: 'ic_20.png',
                  unit_en: 'ic_20.png',
                  align_h: hmUI.align.LEFT,
                  type: hmUI.data_type.HUMIDITY,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 46,
                  y: 187,
                  src: 'ic_4.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.WIND:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 87,
                  y: 188,
                  font_array: ["dig_a_0.png","dig_a_1.png","dig_a_2.png","dig_a_3.png","dig_a_4.png","dig_a_5.png","dig_a_6.png","dig_a_7.png","dig_a_8.png","dig_a_9.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.LEFT,
                  type: hmUI.data_type.WIND,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                  x: 46,
                  y: 185,
                  image_array: ["wind_s_0.png","wind_s_1.png","wind_s_2.png","wind_s_3.png","wind_s_4.png","wind_s_5.png","wind_s_6.png","wind_s_7.png"],
                  image_length: 8,
                  type: hmUI.data_type.WIND_DIRECTION,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.MOON:
                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                  x: 46,
                  y: 185,
                  image_array: ["moon_0.png","moon_1.png","moon_2.png","moon_3.png","moon_4.png","moon_5.png","moon_6.png","moon_7.png","moon_8.png","moon_9.png","moon_10.png","moon_11.png","moon_12.png","moon_13.png","moon_14.png","moon_15.png","moon_16.png","moon_17.png","moon_18.png","moon_19.png","moon_20.png","moon_21.png","moon_22.png","moon_23.png","moon_24.png","moon_25.png","moon_26.png","moon_27.png","moon_28.png","moon_29.png"],
                  image_length: 30,
                  type: hmUI.data_type.MOON,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;
            }; // end switch

            editGroup_2 = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
              edit_id: 10022,
              x: 35,
              y: 254,
              w: 165,
              h: 52,
              select_image: 'select_on.png',
              un_select_image: 'select_off.png',
              default_type: hmUI.edit_type.STEP,
              optional_types: [
                { type: hmUI.edit_type.STEP, preview: 'ez(1)_STEP.png' },
                { type: hmUI.edit_type.CAL, preview: 'ez(1)_CAL.png' },
                { type: hmUI.edit_type.HEART, preview: 'ez(1)_HEART.png' },
                { type: hmUI.edit_type.DISTANCE, preview: 'ez(1)_DISTANCE.png' },
                { type: hmUI.edit_type.WEATHER, preview: 'ez(1)_WEATHER.png' },
                { type: hmUI.edit_type.SUN, preview: 'ez(1)_SUN.png' },
                { type: hmUI.edit_type.PAI, preview: 'ez(1)_PAI.png' },
                { type: hmUI.edit_type.STAND, preview: 'ez(1)_STAND.png' },
                { type: hmUI.edit_type.STRESS, preview: 'ez(1)_STRESS.png' },
                { type: hmUI.edit_type.FAT_BURN, preview: 'ez(2)_FAT_BURNING.png'},
                { type: hmUI.edit_type.UVI, preview: 'ez(1)_UVI.png' },
                { type: hmUI.edit_type.HUMIDITY, preview: 'ez(1)_HUMIDITY.png' },
                { type: hmUI.edit_type.WIND, preview: 'ez(1)_WIND.png' },
                { type: hmUI.edit_type.MOON, preview: 'ez(1)_MOON.png' },
                { type: hmUI.edit_type.BATTERY, preview: 'ez(1)_BATTERY.png' },
              ],
              count: 15,
              select_list: {
                title_font_size: 34,
                title_align_h: hmUI.align.CENTER_H,
                list_item_vspace: 8,
                list_tips_text_font_size: 32,
                list_tips_text_align_h: hmUI.align.LEFT
              },
              tips_BG: 'tips_bg.png',
              tips_x: 33,
              tips_y: 67,
              tips_width: 201,
              tips_margin: 4,
            });

            const editType_2 = editGroup_2.getProperty(hmUI.prop.CURRENT_TYPE);

            switch (editType_2) {
              case hmUI.edit_type.BATTERY:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 44,
                  y: 274,
                  src: 'AL_0.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.STEP:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 46,
                  y: 268,
                  src: 'ic_14.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 85,
                  y: 269,
                  font_array: ["dig_a_0.png","dig_a_1.png","dig_a_2.png","dig_a_3.png","dig_a_4.png","dig_a_5.png","dig_a_6.png","dig_a_7.png","dig_a_8.png","dig_a_9.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.LEFT,
                  type: hmUI.data_type.STEP,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.CAL:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 85,
                  y: 269,
                  font_array: ["dig_a_0.png","dig_a_1.png","dig_a_2.png","dig_a_3.png","dig_a_4.png","dig_a_5.png","dig_a_6.png","dig_a_7.png","dig_a_8.png","dig_a_9.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.LEFT,
                  type: hmUI.data_type.CAL,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 46,
                  y: 268,
                  src: 'ic_13.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.HEART:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 85,
                  y: 269,
                  font_array: ["dig_a_0.png","dig_a_1.png","dig_a_2.png","dig_a_3.png","dig_a_4.png","dig_a_5.png","dig_a_6.png","dig_a_7.png","dig_a_8.png","dig_a_9.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.LEFT,
                  type: hmUI.data_type.HEART,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 46,
                  y: 268,
                  src: 'ic_13.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.PAI:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 85,
                  y: 269,
                  font_array: ["dig_a_0.png","dig_a_1.png","dig_a_2.png","dig_a_3.png","dig_a_4.png","dig_a_5.png","dig_a_6.png","dig_a_7.png","dig_a_8.png","dig_a_9.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.LEFT,
                  type: hmUI.data_type.PAI_WEEKLY,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 46,
                  y: 268,
                  src: 'ic_5.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.DISTANCE:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 85,
                  y: 269,
                  font_array: ["dig_a_0.png","dig_a_1.png","dig_a_2.png","dig_a_3.png","dig_a_4.png","dig_a_5.png","dig_a_6.png","dig_a_7.png","dig_a_8.png","dig_a_9.png"],
                  padding: false,
                  h_space: 0,
                  dot_image: 'dig_a_dot.png',
                  align_h: hmUI.align.LEFT,
                  type: hmUI.data_type.DISTANCE,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 46,
                  y: 268,
                  src: 'ic_7.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.STAND:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 85,
                  y: 269,
                  font_array: ["dig_a_0.png","dig_a_1.png","dig_a_2.png","dig_a_3.png","dig_a_4.png","dig_a_5.png","dig_a_6.png","dig_a_7.png","dig_a_8.png","dig_a_9.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.LEFT,
                  type: hmUI.data_type.STAND,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                editableZone_2_stand_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
                  x: 46,
                  y: 268,
                  src: 'ic_23.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.STRESS:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 85,
                  y: 269,
                  font_array: ["dig_a_0.png","dig_a_1.png","dig_a_2.png","dig_a_3.png","dig_a_4.png","dig_a_5.png","dig_a_6.png","dig_a_7.png","dig_a_8.png","dig_a_9.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.LEFT,
                  type: hmUI.data_type.STRESS,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 46,
                  y: 268,
                  src: 'ic_24.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.FAT_BURN:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 85,
                  y: 269,
                  font_array: ["dig_a_0.png","dig_a_1.png","dig_a_2.png","dig_a_3.png","dig_a_4.png","dig_a_5.png","dig_a_6.png","dig_a_7.png","dig_a_8.png","dig_a_9.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.LEFT,
                  type: hmUI.data_type.FAT_BURNING,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 46,
                  y: 268,
                  src: 'ic_21.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.WEATHER:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 46,
                  y: 268,
                  src: 'ic_18.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 126,
                  y: 269,
                  font_array: ["dig_a_0.png","dig_a_1.png","dig_a_2.png","dig_a_3.png","dig_a_4.png","dig_a_5.png","dig_a_6.png","dig_a_7.png","dig_a_8.png","dig_a_9.png"],
                  padding: false,
                  h_space: 0,
                  unit_sc: 'AL_0.png',
                  unit_tc: 'AL_0.png',
                  unit_en: 'AL_0.png',
                  negative_image: 'dig_a_m.png',
                  invalid_image: 'dig_a_m.png',
                  align_h: hmUI.align.LEFT,
                  type: hmUI.data_type.WEATHER_HIGH,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 65,
                  y: 269,
                  font_array: ["dig_a_0.png","dig_a_1.png","dig_a_2.png","dig_a_3.png","dig_a_4.png","dig_a_5.png","dig_a_6.png","dig_a_7.png","dig_a_8.png","dig_a_9.png"],
                  padding: false,
                  h_space: 0,
                  unit_sc: 'AL_0.png',
                  unit_tc: 'AL_0.png',
                  unit_en: 'AL_0.png',
                  negative_image: 'dig_a_m.png',
                  invalid_image: 'dig_a_m.png',
                  align_h: hmUI.align.RIGHT,
                  type: hmUI.data_type.WEATHER_LOW,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 107,
                  y: 267,
                  src: 'ic_19.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.UVI:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 85,
                  y: 269,
                  font_array: ["dig_a_0.png","dig_a_1.png","dig_a_2.png","dig_a_3.png","dig_a_4.png","dig_a_5.png","dig_a_6.png","dig_a_7.png","dig_a_8.png","dig_a_9.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.LEFT,
                  type: hmUI.data_type.UVI,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 46,
                  y: 268,
                  src: 'ic_25.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.HUMIDITY:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 85,
                  y: 269,
                  font_array: ["dig_a_0.png","dig_a_1.png","dig_a_2.png","dig_a_3.png","dig_a_4.png","dig_a_5.png","dig_a_6.png","dig_a_7.png","dig_a_8.png","dig_a_9.png"],
                  padding: false,
                  h_space: 0,
                  unit_sc: 'ic_20.png',
                  unit_tc: 'ic_20.png',
                  unit_en: 'ic_20.png',
                  align_h: hmUI.align.LEFT,
                  type: hmUI.data_type.HUMIDITY,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 46,
                  y: 268,
                  src: 'ic_4.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.SUN:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 87,
                  y: 269,
                  font_array: ["dig_a_0.png","dig_a_1.png","dig_a_2.png","dig_a_3.png","dig_a_4.png","dig_a_5.png","dig_a_6.png","dig_a_7.png","dig_a_8.png","dig_a_9.png"],
                  padding: false,
                  h_space: 0,
                  invalid_image: 'dig_a_m.png',
                  dot_image: 'dig_a_dot2.png',
                  align_h: hmUI.align.LEFT,
                  type: hmUI.data_type.SUN_RISE,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 46,
                  y: 268,
                  src: 'ic_11.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.WIND:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 85,
                  y: 269,
                  font_array: ["dig_a_0.png","dig_a_1.png","dig_a_2.png","dig_a_3.png","dig_a_4.png","dig_a_5.png","dig_a_6.png","dig_a_7.png","dig_a_8.png","dig_a_9.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.LEFT,
                  type: hmUI.data_type.WIND,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                  x: 46,
                  y: 268,
                  image_array: ["wind_s_0.png","wind_s_1.png","wind_s_2.png","wind_s_3.png","wind_s_4.png","wind_s_5.png","wind_s_6.png","wind_s_7.png"],
                  image_length: 8,
                  type: hmUI.data_type.WIND_DIRECTION,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.MOON:
                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                  x: 46,
                  y: 268,
                  image_array: ["moon_0.png","moon_1.png","moon_2.png","moon_3.png","moon_4.png","moon_5.png","moon_6.png","moon_7.png","moon_8.png","moon_9.png","moon_10.png","moon_11.png","moon_12.png","moon_13.png","moon_14.png","moon_15.png","moon_16.png","moon_17.png","moon_18.png","moon_19.png","moon_20.png","moon_21.png","moon_22.png","moon_23.png","moon_24.png","moon_25.png","moon_26.png","moon_27.png","moon_28.png","moon_29.png"],
                  image_length: 30,
                  type: hmUI.data_type.MOON,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;
            }; // end switch

            editGroup_3 = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
              edit_id: 10023,
              x: 281,
              y: 254,
              w: 165,
              h: 52,
              select_image: 'select_on.png',
              un_select_image: 'select_off.png',
              default_type: hmUI.edit_type.DISTANCE,
              optional_types: [
                { type: hmUI.edit_type.DISTANCE, preview: 'ez(3)_DISTANCE.png' },
                { type: hmUI.edit_type.STEP, preview: 'ez(3)_STEP.png' },
                { type: hmUI.edit_type.PAI, preview: 'ez(3)_PAI.png' },
                { type: hmUI.edit_type.STAND, preview: 'ez(3)_STAND.png' },
                { type: hmUI.edit_type.STRESS, preview: 'ez(3)_STRESS.png' },
                { type: hmUI.edit_type.FAT_BURN, preview: 'ez(3)_FAT_BURNING.png'},
                { type: hmUI.edit_type.UVI, preview: 'ez(3)_UVI.png' },
                { type: hmUI.edit_type.HUMIDITY, preview: 'ez(3)_HUMIDITY.png' },
                { type: hmUI.edit_type.SUN, preview: 'ez(3)_SUN.png' },
                { type: hmUI.edit_type.WIND, preview: 'ez(3)_WIND.png' },
                { type: hmUI.edit_type.HEART, preview: 'ez(3)_HEART.png' },
                { type: hmUI.edit_type.CAL, preview: 'ez(3)_CAL.png' },
                { type: hmUI.edit_type.WEATHER, preview: 'ez(3)_WEATHER.png' },
                { type: hmUI.edit_type.MOON, preview: 'ez(3)_MOON.png' },
                { type: hmUI.edit_type.BATTERY, preview: 'ez(1)_BATTERY.png' },
              ],
              count: 15,
              select_list: {
                title_font_size: 34,
                title_align_h: hmUI.align.CENTER_H,
                list_item_vspace: 8,
                list_tips_text_font_size: 32,
                list_tips_text_align_h: hmUI.align.LEFT
              },
              tips_BG: 'tips_bg.png',
              tips_x: -64,
              tips_y: 67,
              tips_width: 201,
              tips_margin: 4,
            });

            const editType_3 = editGroup_3.getProperty(hmUI.prop.CURRENT_TYPE);

            switch (editType_3) {
              case hmUI.edit_type.BATTERY:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 413,
                  y: 272,
                  src: 'AL_0.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.STEP:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 316,
                  y: 269,
                  font_array: ["dig_a_0.png","dig_a_1.png","dig_a_2.png","dig_a_3.png","dig_a_4.png","dig_a_5.png","dig_a_6.png","dig_a_7.png","dig_a_8.png","dig_a_9.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.RIGHT,
                  type: hmUI.data_type.STEP,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 408,
                  y: 268,
                  src: 'ic_14.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.CAL:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 333,
                  y: 269,
                  font_array: ["dig_a_0.png","dig_a_1.png","dig_a_2.png","dig_a_3.png","dig_a_4.png","dig_a_5.png","dig_a_6.png","dig_a_7.png","dig_a_8.png","dig_a_9.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.RIGHT,
                  type: hmUI.data_type.CAL,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 408,
                  y: 268,
                  src: 'ic_13.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.HEART:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 348,
                  y: 269,
                  font_array: ["dig_a_0.png","dig_a_1.png","dig_a_2.png","dig_a_3.png","dig_a_4.png","dig_a_5.png","dig_a_6.png","dig_a_7.png","dig_a_8.png","dig_a_9.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.RIGHT,
                  type: hmUI.data_type.HEART,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 408,
                  y: 268,
                  src: 'ic_12.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.PAI:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 344,
                  y: 269,
                  font_array: ["dig_a_0.png","dig_a_1.png","dig_a_2.png","dig_a_3.png","dig_a_4.png","dig_a_5.png","dig_a_6.png","dig_a_7.png","dig_a_8.png","dig_a_9.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.RIGHT,
                  type: hmUI.data_type.PAI_WEEKLY,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 408,
                  y: 268,
                  src: 'ic_5.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.DISTANCE:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 316,
                  y: 269,
                  font_array: ["dig_a_0.png","dig_a_1.png","dig_a_2.png","dig_a_3.png","dig_a_4.png","dig_a_5.png","dig_a_6.png","dig_a_7.png","dig_a_8.png","dig_a_9.png"],
                  padding: false,
                  h_space: 0,
                  dot_image: 'dig_a_dot.png',
                  align_h: hmUI.align.RIGHT,
                  type: hmUI.data_type.DISTANCE,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 408,
                  y: 268,
                  src: 'ic_7.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.STAND:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 359,
                  y: 269,
                  font_array: ["dig_a_0.png","dig_a_1.png","dig_a_2.png","dig_a_3.png","dig_a_4.png","dig_a_5.png","dig_a_6.png","dig_a_7.png","dig_a_8.png","dig_a_9.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.RIGHT,
                  type: hmUI.data_type.STAND_TARGET,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                editableZone_3_stand_target_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
                  x: 408,
                  y: 268,
                  src: 'ic_23.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.STRESS:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 344,
                  y: 269,
                  font_array: ["dig_a_0.png","dig_a_1.png","dig_a_2.png","dig_a_3.png","dig_a_4.png","dig_a_5.png","dig_a_6.png","dig_a_7.png","dig_a_8.png","dig_a_9.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.RIGHT,
                  type: hmUI.data_type.STRESS,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 408,
                  y: 268,
                  src: 'ic_24.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.FAT_BURN:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 344,
                  y: 269,
                  font_array: ["dig_a_0.png","dig_a_1.png","dig_a_2.png","dig_a_3.png","dig_a_4.png","dig_a_5.png","dig_a_6.png","dig_a_7.png","dig_a_8.png","dig_a_9.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.RIGHT,
                  type: hmUI.data_type.FAT_BURNING,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 408,
                  y: 268,
                  src: 'ic_21.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.WEATHER:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 408,
                  y: 268,
                  src: 'ic_18.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 364,
                  y: 269,
                  font_array: ["dig_a_0.png","dig_a_1.png","dig_a_2.png","dig_a_3.png","dig_a_4.png","dig_a_5.png","dig_a_6.png","dig_a_7.png","dig_a_8.png","dig_a_9.png"],
                  padding: false,
                  h_space: 0,
                  negative_image: 'dig_a_m.png',
                  invalid_image: 'dig_a_m.png',
                  align_h: hmUI.align.LEFT,
                  type: hmUI.data_type.WEATHER_HIGH,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 343,
                  y: 268,
                  src: 'ic_19.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 301,
                  y: 269,
                  font_array: ["dig_a_0.png","dig_a_1.png","dig_a_2.png","dig_a_3.png","dig_a_4.png","dig_a_5.png","dig_a_6.png","dig_a_7.png","dig_a_8.png","dig_a_9.png"],
                  padding: false,
                  h_space: 0,
                  negative_image: 'dig_a_m.png',
                  invalid_image: 'dig_a_m.png',
                  align_h: hmUI.align.RIGHT,
                  type: hmUI.data_type.WEATHER_LOW,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 343,
                  y: 268,
                  src: 'ic_19.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.UVI:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 364,
                  y: 269,
                  font_array: ["dig_a_0.png","dig_a_1.png","dig_a_2.png","dig_a_3.png","dig_a_4.png","dig_a_5.png","dig_a_6.png","dig_a_7.png","dig_a_8.png","dig_a_9.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.RIGHT,
                  type: hmUI.data_type.UVI,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 408,
                  y: 268,
                  src: 'ic_25.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.HUMIDITY:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 320,
                  y: 269,
                  font_array: ["dig_a_0.png","dig_a_1.png","dig_a_2.png","dig_a_3.png","dig_a_4.png","dig_a_5.png","dig_a_6.png","dig_a_7.png","dig_a_8.png","dig_a_9.png"],
                  padding: false,
                  h_space: 0,
                  unit_sc: 'ic_20.png',
                  unit_tc: 'ic_20.png',
                  unit_en: 'ic_20.png',
                  align_h: hmUI.align.RIGHT,
                  type: hmUI.data_type.HUMIDITY,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 408,
                  y: 268,
                  src: 'ic_4.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.SUN:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 314,
                  y: 269,
                  font_array: ["dig_a_0.png","dig_a_1.png","dig_a_2.png","dig_a_3.png","dig_a_4.png","dig_a_5.png","dig_a_6.png","dig_a_7.png","dig_a_8.png","dig_a_9.png"],
                  padding: false,
                  h_space: 0,
                  dot_image: 'dig_a_dot2.png',
                  align_h: hmUI.align.RIGHT,
                  type: hmUI.data_type.SUN_SET,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 408,
                  y: 268,
                  src: 'ic_10.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.WIND:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 359,
                  y: 269,
                  font_array: ["dig_a_0.png","dig_a_1.png","dig_a_2.png","dig_a_3.png","dig_a_4.png","dig_a_5.png","dig_a_6.png","dig_a_7.png","dig_a_8.png","dig_a_9.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.RIGHT,
                  type: hmUI.data_type.WIND,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                  x: 408,
                  y: 268,
                  image_array: ["wind_s_0.png","wind_s_1.png","wind_s_2.png","wind_s_3.png","wind_s_4.png","wind_s_5.png","wind_s_6.png","wind_s_7.png"],
                  image_length: 8,
                  type: hmUI.data_type.WIND_DIRECTION,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.MOON:
                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                  x: 406,
                  y: 268,
                  image_array: ["moon_0.png","moon_1.png","moon_2.png","moon_3.png","moon_4.png","moon_5.png","moon_6.png","moon_7.png","moon_8.png","moon_9.png","moon_10.png","moon_11.png","moon_12.png","moon_13.png","moon_14.png","moon_15.png","moon_16.png","moon_17.png","moon_18.png","moon_19.png","moon_20.png","moon_21.png","moon_22.png","moon_23.png","moon_24.png","moon_25.png","moon_26.png","moon_27.png","moon_28.png","moon_29.png"],
                  image_length: 30,
                  type: hmUI.data_type.MOON,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;
            }; // end switch

            mask = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_MASK, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'AL_0.png',
              show_level: hmUI.show_level.ONLY_EDIT,
            });

            fg_mask = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_FG_MASK, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'AL_0.png',
              show_level: hmUI.show_level.ONLY_EDIT,
            });

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function() {
              time_update(true);
            });

            normal_dow_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 111,
              y: 129,
              w: 258,
              h: 41,
              text_size: 27,
              char_space: 0,
              font: 'fonts/arbrnplt.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // padding: true,
              // unit_string: ПОНЕДЕЛЬНИК, ВТОРНИК, СРЕДА, ЧЕТВЕРГ, ПЯТНИЦА, СУББОТА, ВОСКРЕСЕНЬЕ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_month_name_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 111,
              y: 95,
              w: 258,
              h: 41,
              text_size: 27,
              char_space: 0,
              font: 'fonts/arbrnplt.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // unit_string: ЯНВАРЯ, ФЕВРАЛЯ, МАРТА, АПРЕЛЯ, МАЯ, ИЮНЯ, ИЮЛЯ, АВГУСТА, СЕНТЯБРЯ, ОКТЯБРЯ, НОЯБРЯ, ДЕКАБРЯ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_day_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 162,
              y: 37,
              w: 155,
              h: 72,
              text_size: 47,
              char_space: 0,
              font: 'fonts/arbrnplt.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 162,
              y: 368,
              w: 155,
              h: 31,
              text_size: 27,
              char_space: 0,
              font: 'fonts/arbrnplt.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              unit_type: 1,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            normal_time_hour_min_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 162,
              y: 328,
              w: 155,
              h: 31,
              text_size: 37,
              char_space: 0,
              font: 'fonts/arbrnplt.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // padding: true,
              // unit_type: 1,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_clock_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 408,
              y: 228,
              src: 'ic_15.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_clock_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 241,
              y: 225,
              w: 155,
              h: 31,
              text_size: 27,
              char_space: 0,
              font: 'fonts/arbrnplt.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.RIGHT,
              padding: true,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 46,
              y: 229,
              src: 'ic_8.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 405,
              y: 180,
              image_array: ["w_0.png","w_1.png","w_2.png","w_3.png","w_4.png","w_5.png","w_6.png","w_7.png","w_8.png","w_9.png","w_10.png","w_11.png","w_12.png","w_13.png","w_14.png","w_15.png","w_16.png","w_17.png","w_18.png","w_19.png","w_20.png","w_21.png","w_22.png","w_23.png","w_24.png","w_25.png","w_26.png","w_27.png","w_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 241,
              y: 183,
              w: 155,
              h: 31,
              text_size: 27,
              char_space: 0,
              font: 'fonts/arbrnplt.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.RIGHT,
              unit_type: 1,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 138,
              y: 333,
              src: 'ic_0.png',
              // alpha: 128,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_icon_img.setAlpha(128);

            normal_stress_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 348,
              y: 110,
              src: 'ic_17.png',
              // alpha: 128,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_icon_img.setAlpha(128);

            normal_stand_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'bezel.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_vo2max_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 327,
              y: 332,
              src: 'ic_block_off.png',
              // alpha: 128,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_vo2max_icon_img.setAlpha(128);

            normal_floor_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 117,
              y: 110,
              src: 'ic_9.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'str_H_0.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 31,
              hour_posY: 126,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'str_M_0.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 27,
              minute_posY: 186,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'str_S_0.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 21,
              second_posY: 218,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');

            idle_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 162,
              y: 368,
              w: 155,
              h: 31,
              text_size: 27,
              char_space: 0,
              font: 'fonts/arbrnplt.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              unit_type: 1,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_time_hour_min_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 162,
              y: 93,
              w: 155,
              h: 31,
              text_size: 37,
              char_space: 0,
              font: 'fonts/arbrnplt.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // padding: true,
              // unit_type: 1,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_vo2max_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'bezel.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            console.log('AOD_user_script.js');
            // start AOD_user_script.js
            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'str_H_'+select+'.png',
              hour_centerX: 233*kof,
              hour_centerY: 233*kof,
              hour_posX: str_x[select][0]*kof,
              hour_posY: str_x[select][1]*kof,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'str_M_'+select+'.png',
              minute_centerX: 233*kof,
              minute_centerY: 233*kof,
              minute_posX: str_x[select][2]*kof,
              minute_posY: str_x[select][3]*kof,
              minute_cover_x: 220,
              minute_cover_y: 219,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            // end AOD_user_script.js

            console.log('user_script_beforeShortcuts.js');
            // start user_script_beforeShortcuts.js

baroText = hmUI.createWidget(hmUI.widget.TEXT, {
 x: 82 * kof,
 y: 218 * kof,
 w: 150 * kof,
 h: 30,
 // text:  Math.round(pressureValue * 0.750064).toString(),
 text: '--',
 text_size: 26 * kof,
 char_space: 0,
 font: 'fonts/arbrnplt.ttf',
 color: 0xFFFFFFFF,
 line_space: 0,
 align_v: hmUI.align.CENTER_V,
 text_style: hmUI.text_style.ELLIPSIS,
 align_h: hmUI.align.LEFT,
 // type: hmUI.data_type.ALTIMETER,
 show_level: hmUI.show_level.ONLY_NORMAL,
})

// экземпляр класса
const barometer = new AdvancedBarometer({
 widget: baroText,
 show_trend: true,
});

select = (select + 4) % 5
str_select(select)

            // end user_script_beforeShortcuts.js

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 320,
              y: 81,
              w: 82,
              h: 82,
              text: '',
              color: 0xFFFF8C00,
              text_size: 26,
              press_src: 'AL_0.png',
              normal_src: 'AL_0.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'FindPhoneScreen', native: true });
vibro();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 199,
              y: 67,
              w: 82,
              h: 82,
              text: '',
              color: 0xFFFF8C00,
              text_size: 26,
              press_src: 'AL_0.png',
              normal_src: 'AL_0.png',
              click_func: (button_widget) => {
                launchAppOrAppId('ScheduleCalScreen', 1057409);
vibro();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 109,
              y: 306,
              w: 82,
              h: 82,
              text: '',
              color: 0xFFFF8C00,
              text_size: 26,
              press_src: 'AL_0.png',
              normal_src: 'AL_0.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'CountdownAppScreen', native: true });
vibro();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 0,
              y: 199,
              w: 82,
              h: 82,
              text: '',
              color: 0xFFFF8C00,
              text_size: 26,
              press_src: 'AL_0.png',
              normal_src: 'AL_0.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'DragListScreen', native: true });
vibro();
              }, // end func
              longpress_func: (button_widget) => {
                str_select();
vibro();

              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 398,
              y: 166,
              w: 82,
              h: 82,
              text: '',
              color: 0xFFFF8C00,
              text_size: 26,
              press_src: 'AL_0.png',
              normal_src: 'AL_0.png',
              click_func: (button_widget) => {
                launchAppOrAppId('WeatherScreen', 1051195);
vibro();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 398,
              y: 249,
              w: 82,
              h: 82,
              text: '',
              color: 0xFFFF8C00,
              text_size: 26,
              press_src: 'AL_0.png',
              normal_src: 'AL_0.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'AlarmInfoScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_7 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 292,
              y: 306,
              w: 82,
              h: 82,
              text: '',
              color: 0xFFFF8C00,
              text_size: 26,
              press_src: 'AL_0.png',
              normal_src: 'AL_0.png',
              click_func: (button_widget) => {
                block_on();
vibro();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_8 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 292,
              y: 306,
              w: 82,
              h: 82,
              text: '',
              color: 0xFFFF8C00,
              text_size: 26,
              press_src: 'AL_0.png',
              normal_src: 'AL_0.png',
              longpress_func: (button_widget) => {
                block_off();
vibro();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_9 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 200,
              y: 200,
              w: 82,
              h: 82,
              text: '',
              color: 0xFFFF8C00,
              text_size: 26,
              press_src: 'AL_0.png',
              normal_src: 'AL_0.png',
              click_func: (button_widget) => {
                str_off();
vibro();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            console.log('user_script_end.js');
            // start user_script_end.js

widget_start();
            // end user_script_end.js

            //#region time_update
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              console.log('day of week font');
              if (updateHour) {
                let normal_DOW_Str = normal_DOW_Array[timeSensor.week-1];
                normal_dow_text_font.setProperty(hmUI.prop.TEXT, normal_DOW_Str );
              };

              console.log('month font');
              if (updateHour) {
                let normal_Month_Str = normal_Month_Array[timeSensor.month-1];
                normal_month_name_font.setProperty(hmUI.prop.TEXT, normal_Month_Str );
              };

              console.log('day font');
              if (updateHour) {
                let normal_dayStr = timeSensor.day.toString();
                normal_dayStr = normal_dayStr.padStart(2, '0');
                normal_day_text_font.setProperty(hmUI.prop.TEXT, normal_dayStr );
              };

              console.log('hour:min font');
              if (updateMinute) {
                let normal_HourMinStr = format_hour.toString();
                normal_HourMinStr = normal_HourMinStr.padStart(2, '0');
                normal_HourMinStr = normal_HourMinStr + ':' + minute.toString().padStart(2, '0')
                if (!timeSensor.is24Hour) {
                  if (hour > 11) normal_HourMinStr = 'Pm ' + normal_HourMinStr
                  else normal_HourMinStr = 'Am ' + normal_HourMinStr
                };
                normal_time_hour_min_text_font.setProperty(hmUI.prop.TEXT, normal_HourMinStr );
              };

              console.log('hour:min font');
              if (updateMinute) {
                let idle_HourMinStr = format_hour.toString();
                idle_HourMinStr = idle_HourMinStr.padStart(2, '0');
                idle_HourMinStr = idle_HourMinStr + ':' + minute.toString().padStart(2, '0')
                if (!timeSensor.is24Hour) {
                  if (hour > 11) idle_HourMinStr = 'Pm ' + idle_HourMinStr
                  else idle_HourMinStr = 'Am ' + idle_HourMinStr
                };
                idle_time_hour_min_text_font.setProperty(hmUI.prop.TEXT, idle_HourMinStr );
              };

            };

            //#endregion
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                time_update(true, true);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerTimeUpdate) {
                    normal_timerTimeUpdate = timer.createTimer(0, 1000, (function (option) {
                      let updateHour = timeSensor.minute == 0 && timeSensor.second < 2;
                      let updateMinute = timeSensor.second < 2;
                      time_update(updateHour, updateMinute);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.AOD) {
                  if (!idle_timerTimeUpdate) {
                    idle_timerTimeUpdate = timer.createTimer(0, 1000, (function (option) {
                      let updateHour = timeSensor.minute == 0 && timeSensor.second < 2;
                      let updateMinute = timeSensor.second < 2;
                      time_update(updateHour, updateMinute);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


                console.log('resume_call.js');
                // start resume_call.js

loadSettings()
if (screenType == hmSetting.screen_type.WATCHFACE) {
 if (!normal_timerTimeUpdate_2) {
  normal_timerTimeUpdate_2 = timer.createTimer(0, 1000, (function (option) {
   normal_floor_icon_img.setProperty(hmUI.prop.VISIBLE, hmBle.connectStatus());
  })); // end timer 
 }; // end timer check
}; // end screenType

                // end resume_call.js

              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerTimeUpdate) {
                  timer.stopTimer(normal_timerTimeUpdate);
                  normal_timerTimeUpdate = undefined;
                }
                if (idle_timerTimeUpdate) {
                  timer.stopTimer(idle_timerTimeUpdate);
                  idle_timerTimeUpdate = undefined;
                }

                console.log('pause_call.js');
                // start pause_call.js

                if (normal_timerTimeUpdate_2) {
                  timer.stopTimer(normal_timerTimeUpdate_2);
                  normal_timerTimeUpdate_2 = undefined;
                }


                // end pause_call.js

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
/*
** Facemaker bundle tool v0.0.3
* *huamiOS watchface js version v4.4.0.1
* *Copyright © Huami. All Rights Reserved
*/


try {
	(() => {
		var __$$app$$__ = __$$hmAppManager$$__.currentApp;
		var __$$module$$__ = __$$app$$__.current;

		//drink is a name,can modify
		var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

		'use strict';

		//dynamic modify start
		let normal_random_bg0 = '';
		let normal_random_bg0_array = ['0002.png','0003.png','0004.png','0005.png'];
		let normal_distance_imagecombo2 = '';
		let normal_heart_current_imagecombo4 = '';
		let normal_heart_min_imagecombo5 = new Array(3);
		let normal_heart_min_imagecombo5_padding = false;
		let normal_heart_min_imagecombo5_array = ['0028.png','0029.png','0030.png','0031.png','0032.png','0033.png','0034.png','0035.png','0036.png','0037.png','0038.png'];
		let normal_heart_max_imagecombo6 = new Array(3);
		let normal_heart_max_imagecombo6_padding = false;
		let normal_heart_max_imagecombo6_array = ['0028.png','0029.png','0030.png','0031.png','0032.png','0033.png','0034.png','0035.png','0036.png','0037.png','0038.png'];
		let normal_steps_imagecombo8 = '';
		let normal_calories_imagecombo10 = '';
		let normal_battery_imagecombo12 = '';
		let normal_battery_progress13 = '';
		let normal_stress_imagecombo15 = '';
		let normal_weather_imageset17 = '';
		let normal_temperature_current_imagecombo18 = '';
		let normal_temperature_high_imagecombo19 = '';
		let normal_temperature_low_imagecombo20 = '';
		let normal_bt_status22 = '';
		let normal_week_imageset24 = '';
		let normal_month_imageset25 = '';
		let normal_date_imagecombo26 = '';
		let normal_hour_imagecombo28 = '';
		let normal_minute_imagecombo29 = '';
		let normal_second_imagecombo30 = '';
		let normal_random_bg_trigger33 = '';
		let normal_calories_shortcut34 = '';
		let normal_heart_shortcut35 = '';
		let normal_steps_shortcut36 = '';
		let normal_alarm_shortcut37 = '';
		let normal_calendar_shortcut38 = '';
		let normal_stopwatch_shortcut39 = '';
		let normal_countdown_shortcut40 = '';
		let normal_stress_shortcut41 = '';
		let normal_weather_shortcut42 = '';
		let idle_hour_imagecombo44 = '';
		let idle_minute_imagecombo45 = '';
		let idle_img46 = '';
		let idle_week_imageset48 = '';
		let idle_month_imageset49 = '';
		let idle_date_imagecombo50 = '';
		//dynamic modify end

		//not required
		const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

		__$$module$$__.module = DeviceRuntimeCore.WatchFace({
			init_view() {

				const batterySensor = hmSensor.createSensor(hmSensor.id.BATTERY);
				const heartSensor = hmSensor.createSensor(hmSensor.id.HEART);
				let screenType = hmSetting.getScreenType();

				normal_random_bg0 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					src: '0002.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_distance_imagecombo2 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 184,
					y: 370,
					font_array: ["0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png"],
					padding: false,
					h_space: -3,
					dot_image: '0016.png',
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.DISTANCE,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_heart_current_imagecombo4 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 193,
					y: 440,
					font_array: ["0017.png","0018.png","0019.png","0020.png","0021.png","0022.png","0023.png","0024.png","0025.png","0026.png"],
					padding: false,
					h_space: -3,
					invalid_image: '0027.png',
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.HEART,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				for (let i = 0; i < normal_heart_min_imagecombo5.length; i++) {
					normal_heart_min_imagecombo5[i] = hmUI.createWidget(hmUI.widget.IMG, {
						x: 254 + i * 16,
						y: 415,
						w: 16,
						h: 29,
						enable: false,
						show_level: hmUI.show_level.ONLY_NORMAL,
					})

				}

				for (let i = 0; i < normal_heart_max_imagecombo6.length; i++) {
					normal_heart_max_imagecombo6[i] = hmUI.createWidget(hmUI.widget.IMG, {
						x: 255 + i * 16,
						y: 443,
						w: 16,
						h: 29,
						enable: false,
						show_level: hmUI.show_level.ONLY_NORMAL,
					})

				}

				normal_steps_imagecombo8 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 88,
					y: 370,
					font_array: ["0039.png","0040.png","0041.png","0042.png","0043.png","0044.png","0045.png","0046.png","0047.png","0048.png"],
					padding: false,
					h_space: -3,
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.STEP,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_calories_imagecombo10 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 284,
					y: 370,
					font_array: ["0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png"],
					padding: false,
					h_space: -3,
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.CAL,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_battery_imagecombo12 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 337,
					y: 86,
					font_array: ["0049.png","0050.png","0051.png","0052.png","0053.png","0054.png","0055.png","0056.png","0057.png","0058.png"],
					padding: false,
					h_space: -3,
					unit_sc: '0059.png',
					unit_tc: '0059.png',
					unit_en: '0059.png',
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.BATTERY,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_battery_progress13 = hmUI.createWidget(hmUI.widget.IMG, {
					w: 82,
					h: 12,
					x: 330,
					y: 123,
					src: '0060.png',
					auto_scale: false,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});
				normal_stress_imagecombo15 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 381,
					y: 344,
					font_array: ["0061.png","0062.png","0063.png","0064.png","0065.png","0066.png","0067.png","0068.png","0069.png","0070.png"],
					padding: false,
					h_space: -3,
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.STRESS,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_weather_imageset17 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
					x: 133,
					y: 9,
					image_array: ["0071.png","0072.png","0073.png","0074.png","0075.png","0076.png","0077.png","0078.png","0079.png","0080.png","0081.png","0082.png","0083.png","0084.png","0085.png","0086.png","0087.png","0088.png","0089.png","0090.png","0091.png","0092.png","0093.png","0094.png","0095.png","0096.png","0097.png","0098.png","0099.png"],
					image_length: 29,
					type: hmUI.data_type.WEATHER_CURRENT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_temperature_current_imagecombo18 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 219,
					y: 28,
					font_array: ["0100.png","0101.png","0102.png","0103.png","0104.png","0105.png","0106.png","0107.png","0108.png","0109.png"],
					padding: false,
					h_space: -3,
					unit_sc: ["0111.png"],
					unit_tc: ["0111.png"],
					unit_en: ["0111.png"],
					negative_image: ["0110.png"],
					invalid_image: ["0110.png"],
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.WEATHER_CURRENT,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_temperature_high_imagecombo19 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 251,
					y: 112,
					font_array: ["0112.png","0113.png","0114.png","0115.png","0116.png","0117.png","0118.png","0119.png","0120.png","0121.png"],
					padding: false,
					h_space: -3,
					unit_sc: ["0123.png"],
					unit_tc: ["0123.png"],
					unit_en: ["0123.png"],
					negative_image: ["0122.png"],
					invalid_image: ["0122.png"],
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.WEATHER_HIGH,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_temperature_low_imagecombo20 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 129,
					y: 93,
					font_array: ["0112.png","0113.png","0114.png","0115.png","0116.png","0117.png","0118.png","0119.png","0120.png","0121.png"],
					padding: false,
					h_space: -3,
					unit_sc: ["0123.png"],
					unit_tc: ["0123.png"],
					unit_en: ["0123.png"],
					negative_image: ["0122.png"],
					invalid_image: ["0122.png"],
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.WEATHER_LOW,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_bt_status22 = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
					x: 24,
					y: 265,
					w: 34,
					h: 34,
					type: hmUI.system_status.DISCONNECT,
					src: '0124.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_week_imageset24 = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
					x: 392,
					y: 260,
					week_en: ["0125.png","0126.png","0127.png","0128.png","0129.png","0130.png","0131.png"],
					week_tc: ["0125.png","0126.png","0127.png","0128.png","0129.png","0130.png","0131.png"],
					week_sc: ["0125.png","0126.png","0127.png","0128.png","0129.png","0130.png","0131.png"],
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_month_imageset25 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
					month_startX: 10,
					month_startY: 229,
					month_sc_array: ["0132.png","0133.png","0134.png","0135.png","0136.png","0137.png","0138.png","0139.png","0140.png","0141.png","0142.png","0143.png"],
					month_tc_array: ["0132.png","0133.png","0134.png","0135.png","0136.png","0137.png","0138.png","0139.png","0140.png","0141.png","0142.png","0143.png"],
					month_en_array: ["0132.png","0133.png","0134.png","0135.png","0136.png","0137.png","0138.png","0139.png","0140.png","0141.png","0142.png","0143.png"],
					month_is_character: true,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_date_imagecombo26 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
					day_startX: 22,
					day_startY: 188,
					day_sc_array: ["0144.png","0145.png","0146.png","0147.png","0148.png","0149.png","0150.png","0151.png","0152.png","0153.png"],
					day_tc_array: ["0144.png","0145.png","0146.png","0147.png","0148.png","0149.png","0150.png","0151.png","0152.png","0153.png"],
					day_en_array: ["0144.png","0145.png","0146.png","0147.png","0148.png","0149.png","0150.png","0151.png","0152.png","0153.png"],
					day_zero: true,
					day_space: -2,
					day_align: hmUI.align.CENTER_H,
					day_is_character: false,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_hour_imagecombo28 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					hour_startX: 73,
					hour_startY: 180,
					hour_array: ["0154.png","0155.png","0156.png","0157.png","0158.png","0159.png","0160.png","0161.png","0162.png","0163.png"],
					hour_zero: true,
					hour_space: 0,
					hour_align: hmUI.align.LEFT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_minute_imagecombo29 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					minute_startX: 241,
					minute_startY: 180,
					minute_array: ["0154.png","0155.png","0156.png","0157.png","0158.png","0159.png","0160.png","0161.png","0162.png","0163.png"],
					minute_zero: true,
					minute_space: 0,
					minute_align: hmUI.align.CENTER_H,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_second_imagecombo30 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					second_startX: 390,
					second_startY: 185,
					second_array: ["0164.png","0165.png","0166.png","0167.png","0168.png","0169.png","0170.png","0171.png","0172.png","0173.png"],
					second_zero: true,
					second_space: 0,
					second_align: hmUI.align.CENTER_H,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_random_bg_trigger33 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					src: '0174.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_random_bg_trigger33.addEventListener(hmUI.event.CLICK_DOWN, function() {
					normal_random_bg0.setProperty(hmUI.prop.SRC, normal_random_bg0_array[Math.floor(Math.random() * normal_random_bg0_array.length)]);
				});

				normal_calories_shortcut34 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 258,
					y: 337,
					w: 100,
					h: 63,
					src: '0174.png',
					type: hmUI.data_type.CAL,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_heart_shortcut35 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 193,
					y: 418,
					w: 100,
					h: 55,
					src: '',
					type: hmUI.data_type.HEART,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_steps_shortcut36 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 97,
					y: 342,
					w: 141,
					h: 57,
					src: '',
					type: hmUI.data_type.STEP,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_alarm_shortcut37 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 97,
					y: 193,
					w: 100,
					h: 100,
					src: '',
					type: hmUI.data_type.ALARM_CLOCK,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_calendar_shortcut38 = hmUI.createWidget(hmUI.widget.BUTTON, {
					x: 0,
					y: 186,
					w: 70,
					h: 100,
					text: '',
					normal_src: '',
					press_src: '',
					click_func: () => {
						hmApp.startApp({ url: 'ScheduleCalScreen', native: true });
					},
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_stopwatch_shortcut39 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 380,
					y: 188,
					w: 100,
					h: 100,
					src: '',
					type: hmUI.data_type.STOP_WATCH,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_countdown_shortcut40 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 241,
					y: 188,
					w: 100,
					h: 100,
					src: '',
					type: hmUI.data_type.COUNT_DOWN,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_stress_shortcut41 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 380,
					y: 337,
					w: 100,
					h: 100,
					src: '',
					type: hmUI.data_type.STRESS,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_weather_shortcut42 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 169,
					y: 25,
					w: 100,
					h: 100,
					src: '',
					type: hmUI.data_type.WEATHER_CURRENT,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				idle_hour_imagecombo44 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					hour_startX: 73,
					hour_startY: 180,
					hour_array: ["0154.png","0155.png","0156.png","0157.png","0158.png","0159.png","0160.png","0161.png","0162.png","0163.png"],
					hour_zero: true,
					hour_space: 0,
					hour_align: hmUI.align.LEFT,
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_minute_imagecombo45 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					minute_startX: 241,
					minute_startY: 180,
					minute_array: ["0154.png","0155.png","0156.png","0157.png","0158.png","0159.png","0160.png","0161.png","0162.png","0163.png"],
					minute_zero: true,
					minute_space: 0,
					minute_align: hmUI.align.CENTER_H,
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_img46 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 214,
					y: 174,
					w: 28,
					h: 130,
					src: '0175.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_week_imageset48 = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
					x: 392,
					y: 260,
					week_en: ["0125.png","0126.png","0127.png","0128.png","0129.png","0130.png","0131.png"],
					week_tc: ["0125.png","0126.png","0127.png","0128.png","0129.png","0130.png","0131.png"],
					week_sc: ["0125.png","0126.png","0127.png","0128.png","0129.png","0130.png","0131.png"],
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_month_imageset49 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
					month_startX: 10,
					month_startY: 229,
					month_sc_array: ["0132.png","0133.png","0134.png","0135.png","0136.png","0137.png","0138.png","0139.png","0140.png","0141.png","0142.png","0143.png"],
					month_tc_array: ["0132.png","0133.png","0134.png","0135.png","0136.png","0137.png","0138.png","0139.png","0140.png","0141.png","0142.png","0143.png"],
					month_en_array: ["0132.png","0133.png","0134.png","0135.png","0136.png","0137.png","0138.png","0139.png","0140.png","0141.png","0142.png","0143.png"],
					month_is_character: true,
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_date_imagecombo50 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
					day_startX: 22,
					day_startY: 188,
					day_sc_array: ["0144.png","0145.png","0146.png","0147.png","0148.png","0149.png","0150.png","0151.png","0152.png","0153.png"],
					day_tc_array: ["0144.png","0145.png","0146.png","0147.png","0148.png","0149.png","0150.png","0151.png","0152.png","0153.png"],
					day_en_array: ["0144.png","0145.png","0146.png","0147.png","0148.png","0149.png","0150.png","0151.png","0152.png","0153.png"],
					day_zero: true,
					day_space: -2,
					day_align: hmUI.align.CENTER_H,
					day_is_character: false,
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				function updateBattery() {
					var current_normal_battery_progress13 = batterySensor.current;
					var target_normal_battery_progress13 = 100;
					var progress_normal_battery_progress13 = current_normal_battery_progress13/target_normal_battery_progress13;

					normal_battery_progress13.setProperty(hmUI.prop.MORE, {
						w: Math.ceil(82*progress_normal_battery_progress13)
					})
				}

				function updateHeart() {
					let normal_heart_min_imagecombo5_current = Math.min(...heartSensor.today);
					if (normal_heart_min_imagecombo5_padding) {
						normal_heart_min_imagecombo5_current = normal_heart_min_imagecombo5_current.toString().padStart(normal_heart_min_imagecombo5.length, '0');
					}
					for (let i = 0; i < normal_heart_min_imagecombo5.length; i++) {
						normal_heart_min_imagecombo5[i].setProperty(hmUI.prop.MORE, { x: 254+((((normal_heart_min_imagecombo5.length-normal_heart_min_imagecombo5_current.toString().length)*16)/2)+16*i) });
						if ((normal_heart_min_imagecombo5.length-normal_heart_min_imagecombo5_current.length) < i && normal_heart_min_imagecombo5_padding === false) {
							normal_heart_min_imagecombo5[i].setProperty(hmUI.prop.VISIBLE, false);
						} else {
							normal_heart_min_imagecombo5[i].setProperty(hmUI.prop.VISIBLE, true);
							normal_heart_min_imagecombo5[i].setProperty(hmUI.prop.SRC, normal_heart_min_imagecombo5_array[normal_heart_min_imagecombo5_current.toString().charAt(i)]);
						}
					}
					let normal_heart_max_imagecombo6_current = Math.max(...heartSensor.today);
					if (normal_heart_max_imagecombo6_padding) {
						normal_heart_max_imagecombo6_current = normal_heart_max_imagecombo6_current.toString().padStart(normal_heart_max_imagecombo6.length, '0');
					}
					for (let i = 0; i < normal_heart_max_imagecombo6.length; i++) {
						normal_heart_max_imagecombo6[i].setProperty(hmUI.prop.MORE, { x: 255+((((normal_heart_max_imagecombo6.length-normal_heart_max_imagecombo6_current.toString().length)*16)/2)+16*i) });
						if ((normal_heart_max_imagecombo6.length-normal_heart_max_imagecombo6_current.length) < i && normal_heart_max_imagecombo6_padding === false) {
							normal_heart_max_imagecombo6[i].setProperty(hmUI.prop.VISIBLE, false);
						} else {
							normal_heart_max_imagecombo6[i].setProperty(hmUI.prop.VISIBLE, true);
							normal_heart_max_imagecombo6[i].setProperty(hmUI.prop.SRC, normal_heart_max_imagecombo6_array[normal_heart_max_imagecombo6_current.toString().charAt(i)]);
						}
					}
				}

				batterySensor.addEventListener(hmSensor.event.CHANGE, function() {
					updateBattery();
				});

				heartSensor.addEventListener(hmSensor.event.CHANGE, function() {
					updateHeart();
				});

				const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
					resume_call: (function () {
						updateBattery();
						updateHeart();
					}),
					pause_call: (function () {
					}),
				})
			},

		onInit() {
			console.log('index page.js on init invoke')
			this.init_view()
		},
		onReady() {
			console.log('index page.js on ready invoke')
		},
		onShow() {
			console.log('index page.js on show invoke')
		},
		onHide() {
			console.log('index page.js on hide invoke')
		},
		onDestroy() {
			console.log('index page.js on destroy invoke')
		},
	});	})()
} catch (e) {
	console.log(e)
}
﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_frame_animation_1 = ''
        let normal_frame_animation_2 = ''
        let normal_battery_text_text_img = ''
        let normal_battery_text_separator_img = ''
        let normal_battery_pointer_progress_img_pointer = ''
        let normal_stress_text_text_img = ''
        let normal_stress_text_separator_img = ''
        let normal_stress_pointer_progress_img_pointer = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_text_separator_img = ''
        let normal_heart_rate_pointer_progress_img_pointer = ''
        let normal_stand_current_text_img = ''
        let normal_stand_current_separator_img = ''
        let normal_stand_pointer_progress_img_pointer = ''
        let normal_calorie_current_text_img = ''
        let normal_calorie_current_separator_img = ''
        let normal_calorie_pointer_progress_img_pointer = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_step_pointer_progress_img_pointer = ''
        let normal_compass_direction_pointer_img = ''
        let normal_altimeter_pointer_progress_img_pointer = ''
        let normal_wind_icon_img = ''
        let normal_wind_direction_image_progress_img_level = ''
        let normal_analog_clock_pro_second_pointer_img = ''
        let normal_timerUpdateSecSmooth = undefined;
        let normal_analog_clock_pro_second_cover_pointer_img = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg_img = ''
        let idle_battery_text_text_img = ''
        let idle_battery_pointer_progress_img_pointer = ''
        let idle_heart_rate_text_text_img = ''
        let idle_heart_rate_pointer_progress_img_pointer = ''
        let idle_altimeter_pointer_progress_img_pointer = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let normal_step_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let timeSensor = ''
		
		let btn_zona1 = ''
        let zona1_num = 0
        let zona1_all = 2
		
		function click_zona1() {
		  zona1_num = (zona1_num + 1) % (zona1_all + 1);
          if (zona1_num == 0) {		
		    normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
            normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_step_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, true);
			normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_stand_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_stand_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_stand_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
		    hmUI.showToast({
            });
          };
		  
		 if (zona1_num == 1) {
			normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_step_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_calorie_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, true);
			normal_stand_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_stand_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_stand_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
		    hmUI.showToast({
            });
          };
		  
		  if (zona1_num == 2) {
			normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_step_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_stand_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_stand_current_separator_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_stand_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, true);
		    hmUI.showToast({
            });
          };
		}

		let btn_zona2 = ''
        let zona2_num = 0
        let zona2_all = 2
		
		function click_zona2() {
		  zona2_num = (zona2_num + 1) % (zona2_all + 1);
          if (zona2_num == 0) {		
		    normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
            normal_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_heart_rate_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, true);
			normal_stress_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_stress_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_stress_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_battery_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_battery_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
		    hmUI.showToast({
            });
          };
		  
		 if (zona2_num == 1) {
			normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_heart_rate_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_stress_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_stress_text_separator_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_stress_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, true);
			normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_battery_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_battery_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
		    hmUI.showToast({
            });
          };
		  
		  if (zona2_num == 2) {
			normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_heart_rate_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_stress_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_stress_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_stress_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_battery_text_separator_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_battery_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, true);
		    hmUI.showToast({
            });
          };
        }
		
		let btn_zona3 = ''
        let zona3_num = 0
        let zona3_all = 2
		
		function click_zona3() {
		  zona3_num = (zona3_num + 1) % (zona3_all + 1);
          if (zona3_num == 0) {		
		    normal_compass_direction_pointer_img.setProperty(hmUI.prop.VISIBLE, true);
            normal_wind_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_wind_direction_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
			normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, true);
			normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_analog_clock_pro_second_cover_pointer_img.setProperty(hmUI.prop.VISIBLE, false);
		    hmUI.showToast({
            });
          };
		  
		 if (zona3_num == 1) {
			normal_compass_direction_pointer_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_wind_icon_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_wind_direction_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);
			normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, true);
			normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_analog_clock_pro_second_cover_pointer_img.setProperty(hmUI.prop.VISIBLE, false);
		    hmUI.showToast({
            });
          };
		  
		  if (zona3_num == 2) {
			normal_compass_direction_pointer_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_wind_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_wind_direction_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
			normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, false);
			normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_analog_clock_pro_second_cover_pointer_img.setProperty(hmUI.prop.VISIBLE, true);
		    hmUI.showToast({
            });
          };
        }
		
		let longPress_Timer = null;
	    let longPressDelay = 700;   // задержка на долгое нажатие в мс
		
		function getLongPress2() {
		    if(longPress_Timer) timer.stopTimer(longPress_Timer);
			
			let url;

			switch(zona2_num) {
			   case 0:
					url = 'heart_app_Screen';
				break;
			   case 1:
					url = 'StressHomeScreen';
				break;
			   case 2:
					url = 'Settings_batteryManagerScreen';
				break;	
			   default:
				break;
			}
			hmApp.startApp({ url: url, native: true });
			
	    }


		function getLongPress3() {
		    if(longPress_Timer) timer.stopTimer(longPress_Timer);
			
			let url;

			switch(zona3_num) {
			   case 0:
					url = 'CompassScreen';
				break;
			   case 1:
					url = 'WeatherScreen';
				break;
			   case 2:
					url = 'CountdownAppScreen';
				break;	
			   default:
				break;
			}
			hmApp.startApp({ url: url, native: true });
			
	    }


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_frame_animation_1 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
              x: 156,
              y: 60,
              anim_path: "animation",
              anim_ext: "png",
              anim_prefix: "test_anim",
              anim_fps: 15,
              anim_size: 80,
              repeat_count: 0,
              anim_repeat: true,
              anim_status:hmUI.anim_status.START,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_frame_animation_2 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
              x: 156,
              y: 250,
              anim_path: "animation",
              anim_ext: "png",
              anim_prefix: "test_anim",
              anim_fps: 15,
              anim_size: 160,
              repeat_count: 0,
              anim_repeat: true,
              anim_status:hmUI.anim_status.START,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 212,
              y: 344,
              font_array: ["81.png","82.png","83.png","84.png","85.png","86.png","87.png","88.png","89.png","90.png"],
              padding: false,
              h_space: 0,
              unit_sc: '92.png',
              unit_tc: '92.png',
              unit_en: '92.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 224,
              y: 289,
              src: 'A100_127.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'A100_033.png',
              center_x: 240,
              center_y: 334,
              x: 12,
              y: 66,
              start_angle: -126,
              end_angle: 130,
              invalid_visible: false,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 219,
              y: 344,
              font_array: ["81.png","82.png","83.png","84.png","85.png","86.png","87.png","88.png","89.png","90.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STRESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 224,
              y: 289,
              src: 'A100_097.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'A100_033.png',
              center_x: 240,
              center_y: 334,
              x: 12,
              y: 66,
              start_angle: -126,
              end_angle: 130,
              invalid_visible: false,
              type: hmUI.data_type.STRESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 219,
              y: 344,
              font_array: ["81.png","82.png","83.png","84.png","85.png","86.png","87.png","88.png","89.png","90.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 222,
              y: 287,
              src: 'A100_095.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'A100_033.png',
              center_x: 240,
              center_y: 334,
              x: 12,
              y: 66,
              start_angle: -126,
              end_angle: 130,
              invalid_visible: false,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 213,
              y: 155,
              font_array: ["81.png","82.png","83.png","84.png","85.png","86.png","87.png","88.png","89.png","90.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STAND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 224,
              y: 99,
              src: 'A100_086.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'A100_033.png',
              center_x: 241,
              center_y: 143,
              x: 12,
              y: 66,
              start_angle: -126,
              end_angle: 130,
              invalid_visible: false,
              type: hmUI.data_type.STAND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 212,
              y: 150,
              font_array: ["81.png","82.png","83.png","84.png","85.png","86.png","87.png","88.png","89.png","90.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 222,
              y: 95,
              src: 'A100_085.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'A100_033.png',
              center_x: 241,
              center_y: 143,
              x: 12,
              y: 66,
              start_angle: -126,
              end_angle: 130,
              invalid_visible: false,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 204,
              y: 150,
              font_array: ["81.png","82.png","83.png","84.png","85.png","86.png","87.png","88.png","89.png","90.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 224,
              y: 95,
              src: 'A100_082.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'A100_033.png',
              center_x: 241,
              center_y: 143,
              x: 12,
              y: 66,
              start_angle: -126,
              end_angle: 130,
              invalid_visible: false,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const deviceInfo = hmSetting.getDeviceInfo();
            
            // normal_compass_custom_pointer_img = hmUI.createWidget(hmUI.widget.CUSTOM_POINTER, {
              // src: 'compass_direction_dial.png',
              // center_x: 240,
              // center_y: 240,
              // x: 240,
              // y: 240,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.COMPASS,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            //start of ignored block
            normal_compass_direction_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 240,
              pos_y: 240 - 240,
              center_x: 240,
              center_y: 240,
              src: 'compass_direction_dial.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            //end of ignored block

            normal_altimeter_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'A100_026.png',
              center_x: 240,
              center_y: 240,
              x: 12,
              y: 238,
              start_angle: 50,
              end_angle: 262,
              invalid_visible: false,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'wind.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_direction_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 0,
              y: 0,
              image_array: ["wind_1.png","wind_2.png","wind_3.png","wind_4.png","wind_5.png","wind_6.png","wind_7.png","wind_8.png"],
              image_length: 8,
              type: hmUI.data_type.WIND_DIRECTION,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'bezelsecon1.png',
              // center_x: 240,
              // center_y: 240,
              // x: 240,
              // y: 240,
              // start_angle: 0,
              // end_angle: 360,
              // cover_path: 'A100_032.png',
              // cover_x: 228,
              // cover_y: 25,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 240,
              pos_y: 240 - 240,
              center_x: 240,
              center_y: 240,
              src: 'bezelsecon1.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            normal_analog_clock_pro_second_cover_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 228,
              y: 25,
              src: 'A100_032.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_smooth_second = hmUI.createWidget(hmUI.widget.SMOOTH_SECOND, {
              // type: 2,
              // fps: 6,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'A100_005.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 18,
              hour_posY: 235,
              hour_cover_path: 'A100_013.png',
              hour_cover_x: 217,
              hour_cover_y: 217,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'A100_008.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 18,
              minute_posY: 241,
              minute_cover_path: 'A100_014.png',
              minute_cover_x: 220,
              minute_cover_y: 220,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'A100_011.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 12,
              second_posY: 233,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'A100_004.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 212,
              y: 344,
              font_array: ["81.png","82.png","83.png","84.png","85.png","86.png","87.png","88.png","89.png","90.png"],
              padding: false,
              h_space: 0,
              unit_sc: '92.png',
              unit_tc: '92.png',
              unit_en: '92.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'point.png',
              center_x: 240,
              center_y: 333,
              x: 12,
              y: 66,
              start_angle: -126,
              end_angle: 130,
              invalid_visible: false,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 219,
              y: 150,
              font_array: ["81.png","82.png","83.png","84.png","85.png","86.png","87.png","88.png","89.png","90.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'point.png',
              center_x: 240,
              center_y: 145,
              x: 12,
              y: 66,
              start_angle: -126,
              end_angle: 130,
              invalid_visible: false,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_altimeter_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'A100_026.png',
              center_x: 240,
              center_y: 240,
              x: 12,
              y: 238,
              start_angle: 50,
              end_angle: 262,
              invalid_visible: false,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'A100_005.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 18,
              hour_posY: 235,
              hour_cover_path: 'A100_013.png',
              hour_cover_x: 217,
              hour_cover_y: 217,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'A100_008.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 18,
              minute_posY: 241,
              minute_cover_path: 'A100_014.png',
              minute_cover_x: 220,
              minute_cover_y: 220,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');
			
			const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if (scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro() {
              vibrate.stop();
              if (timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            btn_zona1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 188,
              y: 115,
              text: '',
              w: 100,
              h: 65,
              normal_src: 'Empty.png',
              press_src: 'Empty.png',
              click_func: () => {
				vibro();
				click_zona1();
				click_Vibrate();
             },
			  longpress_func: () => {
             hmApp.startApp({ url: "activityAppScreen", native: true });
             },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btn_zona1.setProperty(hmUI.prop.VISIBLE, true);
			normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_stand_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_stand_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_stand_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);

            btn_zona2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 188,
              y: 305,
              text: '',
              w: 100,
              h: 65,
              normal_src: 'Empty.png',
              press_src: 'Empty.png',
              click_func: () => {
				vibro();
				click_zona2();
                click_Vibrate();
             },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btn_zona2.setProperty(hmUI.prop.VISIBLE, true);
			normal_stress_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_stress_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_stress_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_battery_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_battery_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			
			btn_zona2.addEventListener(hmUI.event.CLICK_DOWN, function () {
					if(longPress_Timer) timer.stopTimer(longPress_Timer);
					longPress_Timer = timer.createTimer(longPressDelay, 0, getLongPress2, {});
			});
			btn_zona2.addEventListener(hmUI.event.CLICK_UP, function () {
					if(longPress_Timer) timer.stopTimer(longPress_Timer);
			});

            btn_zona3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 203,
              y: 203,
              text: '',
              w: 75,
              h: 75,
              normal_src: 'Empty.png',
              press_src: 'Empty.png',
              click_func: () => {
				vibro();
				click_zona3();
                click_Vibrate();
             },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btn_zona3.setProperty(hmUI.prop.VISIBLE, true);
			normal_wind_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_wind_direction_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
			normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, true);
			normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_analog_clock_pro_second_cover_pointer_img.setProperty(hmUI.prop.VISIBLE, false);
			
			btn_zona3.addEventListener(hmUI.event.CLICK_DOWN, function () {
					if(longPress_Timer) timer.stopTimer(longPress_Timer);
					longPress_Timer = timer.createTimer(longPressDelay, 0, getLongPress3, {});
			});
			btn_zona3.addEventListener(hmUI.event.CLICK_UP, function () {
					if(longPress_Timer) timer.stopTimer(longPress_Timer);
			});

            //start of ignored block
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              let normal_fullAngle_second = 360;
              let normal_angle_second = 0 + normal_fullAngle_second*(second + (timeSensor.utc % 1000)/1000)/60;
              if (normal_analog_clock_pro_second_pointer_img) normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_second);

            };

            //end of ignored block
            //start of ignored block
            console.log('compass_update()');
            if (screenType == hmSetting.screen_type.WATCHFACE){
              compass = hmSensor.createSensor(hmSensor.id.COMPASS);
              compass.start();

              if (compass.direction_angle && compass.direction  && compass.direction_angle != 'INVALID') { // initial data
                // Compass Pointer
                let compass_direction_angle = parseInt(compass.direction_angle);
                normal_compass_direction_pointer_img.setProperty(hmUI.prop.ANGLE, -compass_direction_angle);

              } else { // error data
                normal_compass_direction_pointer_img.setProperty(hmUI.prop.ANGLE, 0);

              }

              compass.addEventListener(hmSensor.event.CHANGE, function (compass_res) { // change values when changing direction

                if (compass_res.calibration_status) {
                  // Compass Pointer
                  let compass_direction_angle = parseInt(compass_res.direction_angle);
                  normal_compass_direction_pointer_img.setProperty(hmUI.prop.ANGLE, -compass_direction_angle);

                } else { // error data
                  normal_compass_direction_pointer_img.setProperty(hmUI.prop.ANGLE, 0);

                }

              }); // Listener end

            };
            //end of ignored block

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                time_update(true, true);
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);
                normal_frame_animation_2.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);
                if (compass && screenType == hmSetting.screen_type.WATCHFACE) compass.start();
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSecSmooth) {
                    let animDelay = 0;
                    let animRepeat = 1000/6;
                    normal_timerUpdateSecSmooth = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, false);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                console.log('pause_call()');
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);
                normal_frame_animation_2.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);
                if (compass) compass.stop();
                if (normal_timerUpdateSecSmooth) {
                  timer.stopTimer(normal_timerUpdateSecSmooth);
                  normal_timerUpdateSecSmooth = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
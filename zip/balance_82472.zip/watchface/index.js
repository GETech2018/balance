﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (()=>{
        //dynamic modify start

        const lang = DeviceRuntimeCore.HmUtils.getLanguage()
        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_date_img_date_week_img = ''
        let normal_heart_rate_pointer_progress_img_pointer = ''
        let normal_heart_rate_text_text_img = ''
        let normal_date_img_date_year = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_battery_image_progress_img_level = ''
        let normal_stand_current_text_img = ''
        let normal_stand_image_progress_img_level = ''
        let normal_step_current_text_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_calorie_icon_img = ''
        let normal_calorie_pointer_progress_img_pointer = ''
        let normal_calorie_current_text_img = ''
        let normal_hour_TextCircle = new Array(2);
        let normal_hour_TextCircle_ASCIIARRAY = new Array(10);
        let normal_hour_TextCircle_img_width = 38;
        let normal_hour_TextCircle_img_height = 73;
        let normal_hour_TextCircle_unit = null;
        let normal_hour_TextCircle_unit_width = 20;
        let normal_timerTextUpdate = undefined;
        let normal_minute_TextCircle = new Array(2);
        let normal_minute_TextCircle_ASCIIARRAY = new Array(10);
        let normal_minute_TextCircle_img_width = 38;
        let normal_minute_TextCircle_img_height = 73;
        let normal_minute_TextCircle_unit = null;
        let normal_minute_TextCircle_unit_width = 20;
        let normal_second_TextCircle = new Array(2);
        let normal_second_TextCircle_ASCIIARRAY = new Array(10);
        let normal_second_TextCircle_img_width = 38;
        let normal_second_TextCircle_img_height = 73;
        let idle_digital_clock_img_time = ''
        let normal_step_jumpable_img_click = ''
        let normal_cal_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let Button_1 = ''
        let timeSensor = ''


        //dynamic modify end
        const e = __$$hmAppManager$$__.currentApp;
        const o = e.current
          , {px: i} = (new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(e,o)),
        e.__globals__)
          , n = Logger.getLogger("watchface6");
        o.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 333,
              y: 321,
              src: 'bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 124,
              y: 321,
              src: 'alarms.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			let dned=["week_0.png","week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png"]
			if(lang=='ru-RU'){
				dned=["weekru_0.png","weekru_1.png","weekru_2.png","weekru_3.png","weekru_4.png","weekru_5.png","weekru_6.png"]
			}
            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 203,
              y: 327,
              week_en: dned,
              week_tc: ["week_0.png","week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png"],
              week_sc: ["week_0.png","week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'point.png',
              center_x: 70,
              center_y: 256,
              x: 12,
              y: 59,
              start_angle: -134,
              end_angle: 138,
              invalid_visible: false,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 42,
              y: 235,
              font_array: ["long_type_time_num_0.png","long_type_time_num_1.png","long_type_time_num_2.png","long_type_time_num_3.png","long_type_time_num_4.png","long_type_time_num_5.png","long_type_time_num_6.png","long_type_time_num_7.png","long_type_time_num_8.png","long_type_time_num_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 278,
              year_startY: 280,
              year_sc_array: ["long_type_time_num_0.png","long_type_time_num_1.png","long_type_time_num_2.png","long_type_time_num_3.png","long_type_time_num_4.png","long_type_time_num_5.png","long_type_time_num_6.png","long_type_time_num_7.png","long_type_time_num_8.png","long_type_time_num_9.png"],
              year_tc_array: ["long_type_time_num_0.png","long_type_time_num_1.png","long_type_time_num_2.png","long_type_time_num_3.png","long_type_time_num_4.png","long_type_time_num_5.png","long_type_time_num_6.png","long_type_time_num_7.png","long_type_time_num_8.png","long_type_time_num_9.png"],
              year_en_array: ["long_type_time_num_0.png","long_type_time_num_1.png","long_type_time_num_2.png","long_type_time_num_3.png","long_type_time_num_4.png","long_type_time_num_5.png","long_type_time_num_6.png","long_type_time_num_7.png","long_type_time_num_8.png","long_type_time_num_9.png"],
              year_zero: 0,
              year_space: 0,
              year_align: hmUI.align.CENTER_H,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 221,
              month_startY: 280,
              month_sc_array: ["long_type_time_num_0.png","long_type_time_num_1.png","long_type_time_num_2.png","long_type_time_num_3.png","long_type_time_num_4.png","long_type_time_num_5.png","long_type_time_num_6.png","long_type_time_num_7.png","long_type_time_num_8.png","long_type_time_num_9.png"],
              month_tc_array: ["long_type_time_num_0.png","long_type_time_num_1.png","long_type_time_num_2.png","long_type_time_num_3.png","long_type_time_num_4.png","long_type_time_num_5.png","long_type_time_num_6.png","long_type_time_num_7.png","long_type_time_num_8.png","long_type_time_num_9.png"],
              month_en_array: ["long_type_time_num_0.png","long_type_time_num_1.png","long_type_time_num_2.png","long_type_time_num_3.png","long_type_time_num_4.png","long_type_time_num_5.png","long_type_time_num_6.png","long_type_time_num_7.png","long_type_time_num_8.png","long_type_time_num_9.png"],
              month_zero: 1,
              month_space: 0,
              month_unit_sc: 'sl.png',
              month_unit_tc: 'sl.png',
              month_unit_en: 'sl.png',
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 163,
              day_startY: 280,
              day_sc_array: ["long_type_time_num_0.png","long_type_time_num_1.png","long_type_time_num_2.png","long_type_time_num_3.png","long_type_time_num_4.png","long_type_time_num_5.png","long_type_time_num_6.png","long_type_time_num_7.png","long_type_time_num_8.png","long_type_time_num_9.png"],
              day_tc_array: ["long_type_time_num_0.png","long_type_time_num_1.png","long_type_time_num_2.png","long_type_time_num_3.png","long_type_time_num_4.png","long_type_time_num_5.png","long_type_time_num_6.png","long_type_time_num_7.png","long_type_time_num_8.png","long_type_time_num_9.png"],
              day_en_array: ["long_type_time_num_0.png","long_type_time_num_1.png","long_type_time_num_2.png","long_type_time_num_3.png","long_type_time_num_4.png","long_type_time_num_5.png","long_type_time_num_6.png","long_type_time_num_7.png","long_type_time_num_8.png","long_type_time_num_9.png"],
              day_zero: 1,
              day_space: 0,
              day_unit_sc: 'sl.png',
              day_unit_tc: 'sl.png',
              day_unit_en: 'sl.png',
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 199,
              y: 447,
              image_array: ["A100_029.png","A100_030.png","A100_031.png","A100_032.png","A100_033.png","A100_034.png","A100_035.png","A100_036.png","A100_037.png","A100_038.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 382,
              y: 278,
              font_array: ["num_0.png","num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STAND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 369,
              y: 218,
              image_array: ["stand_1.png","stand_2.png","stand_3.png","stand_4.png","stand_5.png","stand_6.png","stand_7.png","stand_8.png","stand_9.png","stand_10.png","stand_11.png","stand_12.png"],
              image_length: 12,
              type: hmUI.data_type.STAND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 375,
              y: 303,
              font_array: ["num_0.png","num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 354,
              y: 203,
              image_array: ["step_1.png","step_2.png","step_3.png","step_4.png","step_5.png","step_6.png","step_7.png","step_8.png","step_9.png","step_10.png","step_11.png","step_12.png","step_13.png"],
              image_length: 13,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			let dcal='cal.png'
			if(lang=='ru-RU'){
				dcal='cal_ru.png'
			}
            normal_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: dcal,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'A100_071.png',
              center_x: 239,
              center_y: 240,
              x: 13,
              y: 214,
              start_angle: -73,
              end_angle: 72,
              invalid_visible: false,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 166,
              y: 195,
              font_array: ["informative_analog_digital_time_num_0.png","informative_analog_digital_time_num_1.png","informative_analog_digital_time_num_2.png","informative_analog_digital_time_num_3.png","informative_analog_digital_time_num_4.png","informative_analog_digital_time_num_5.png","informative_analog_digital_time_num_6.png","informative_analog_digital_time_num_7.png","informative_analog_digital_time_num_8.png","informative_analog_digital_time_num_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_hour_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 240,
              // circle_center_Y: 240,
              // font_array: ["informative_analog_digital_time_num_0.png","informative_analog_digital_time_num_1.png","informative_analog_digital_time_num_2.png","informative_analog_digital_time_num_3.png","informative_analog_digital_time_num_4.png","informative_analog_digital_time_num_5.png","informative_analog_digital_time_num_6.png","informative_analog_digital_time_num_7.png","informative_analog_digital_time_num_8.png","informative_analog_digital_time_num_9.png"],
              // radius: 218,
              // angle: -145,
              // char_space_angle: 1,
              // unit: 'colon.png',
              // zero: true,
              // reverse_direction: true,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: LEFT,
              // type: hmUI.data_type.HOUR,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_hour_TextCircle_ASCIIARRAY[0] = 'informative_analog_digital_time_num_0.png';  // set of images with numbers
            normal_hour_TextCircle_ASCIIARRAY[1] = 'informative_analog_digital_time_num_1.png';  // set of images with numbers
            normal_hour_TextCircle_ASCIIARRAY[2] = 'informative_analog_digital_time_num_2.png';  // set of images with numbers
            normal_hour_TextCircle_ASCIIARRAY[3] = 'informative_analog_digital_time_num_3.png';  // set of images with numbers
            normal_hour_TextCircle_ASCIIARRAY[4] = 'informative_analog_digital_time_num_4.png';  // set of images with numbers
            normal_hour_TextCircle_ASCIIARRAY[5] = 'informative_analog_digital_time_num_5.png';  // set of images with numbers
            normal_hour_TextCircle_ASCIIARRAY[6] = 'informative_analog_digital_time_num_6.png';  // set of images with numbers
            normal_hour_TextCircle_ASCIIARRAY[7] = 'informative_analog_digital_time_num_7.png';  // set of images with numbers
            normal_hour_TextCircle_ASCIIARRAY[8] = 'informative_analog_digital_time_num_8.png';  // set of images with numbers
            normal_hour_TextCircle_ASCIIARRAY[9] = 'informative_analog_digital_time_num_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              normal_hour_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 240,
                center_y: 240,
                pos_x: 240 - normal_hour_TextCircle_img_width / 2,
                pos_y: 240 + 145,
                src: 'informative_analog_digital_time_num_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_hour_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_hour_TextCircle_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              center_x: 240,
              center_y: 240,
              pos_x: 240 - normal_hour_TextCircle_unit_width / 2,
              pos_y: 240 + 145,
              src: 'colon.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_hour_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            let screenType = hmSetting.getScreenType();            
            function toDegree (radian) {
              return radian * (180 / Math.PI);
            };

            // normal_minute_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 240,
              // circle_center_Y: 240,
              // font_array: ["informative_analog_digital_time_num_0.png","informative_analog_digital_time_num_1.png","informative_analog_digital_time_num_2.png","informative_analog_digital_time_num_3.png","informative_analog_digital_time_num_4.png","informative_analog_digital_time_num_5.png","informative_analog_digital_time_num_6.png","informative_analog_digital_time_num_7.png","informative_analog_digital_time_num_8.png","informative_analog_digital_time_num_9.png"],
              // radius: 219,
              // angle: -175,
              // char_space_angle: 1,
              // unit: 'colon.png',
              // zero: true,
              // reverse_direction: true,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: LEFT,
              // type: hmUI.data_type.MINUTE,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_minute_TextCircle_ASCIIARRAY[0] = 'informative_analog_digital_time_num_0.png';  // set of images with numbers
            normal_minute_TextCircle_ASCIIARRAY[1] = 'informative_analog_digital_time_num_1.png';  // set of images with numbers
            normal_minute_TextCircle_ASCIIARRAY[2] = 'informative_analog_digital_time_num_2.png';  // set of images with numbers
            normal_minute_TextCircle_ASCIIARRAY[3] = 'informative_analog_digital_time_num_3.png';  // set of images with numbers
            normal_minute_TextCircle_ASCIIARRAY[4] = 'informative_analog_digital_time_num_4.png';  // set of images with numbers
            normal_minute_TextCircle_ASCIIARRAY[5] = 'informative_analog_digital_time_num_5.png';  // set of images with numbers
            normal_minute_TextCircle_ASCIIARRAY[6] = 'informative_analog_digital_time_num_6.png';  // set of images with numbers
            normal_minute_TextCircle_ASCIIARRAY[7] = 'informative_analog_digital_time_num_7.png';  // set of images with numbers
            normal_minute_TextCircle_ASCIIARRAY[8] = 'informative_analog_digital_time_num_8.png';  // set of images with numbers
            normal_minute_TextCircle_ASCIIARRAY[9] = 'informative_analog_digital_time_num_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              normal_minute_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 240,
                center_y: 240,
                pos_x: 240 - normal_minute_TextCircle_img_width / 2,
                pos_y: 240 + 146,
                src: 'informative_analog_digital_time_num_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_minute_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_minute_TextCircle_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              center_x: 240,
              center_y: 240,
              pos_x: 240 - normal_minute_TextCircle_unit_width / 2,
              pos_y: 240 + 146,
              src: 'colon.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_minute_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block

            // normal_second_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 240,
              // circle_center_Y: 240,
              // font_array: ["informative_analog_digital_time_num_0.png","informative_analog_digital_time_num_1.png","informative_analog_digital_time_num_2.png","informative_analog_digital_time_num_3.png","informative_analog_digital_time_num_4.png","informative_analog_digital_time_num_5.png","informative_analog_digital_time_num_6.png","informative_analog_digital_time_num_7.png","informative_analog_digital_time_num_8.png","informative_analog_digital_time_num_9.png"],
              // radius: 218,
              // angle: 155,
              // char_space_angle: 1,
              // zero: true,
              // reverse_direction: true,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: LEFT,
              // type: hmUI.data_type.SECOND,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_second_TextCircle_ASCIIARRAY[0] = 'informative_analog_digital_time_num_0.png';  // set of images with numbers
            normal_second_TextCircle_ASCIIARRAY[1] = 'informative_analog_digital_time_num_1.png';  // set of images with numbers
            normal_second_TextCircle_ASCIIARRAY[2] = 'informative_analog_digital_time_num_2.png';  // set of images with numbers
            normal_second_TextCircle_ASCIIARRAY[3] = 'informative_analog_digital_time_num_3.png';  // set of images with numbers
            normal_second_TextCircle_ASCIIARRAY[4] = 'informative_analog_digital_time_num_4.png';  // set of images with numbers
            normal_second_TextCircle_ASCIIARRAY[5] = 'informative_analog_digital_time_num_5.png';  // set of images with numbers
            normal_second_TextCircle_ASCIIARRAY[6] = 'informative_analog_digital_time_num_6.png';  // set of images with numbers
            normal_second_TextCircle_ASCIIARRAY[7] = 'informative_analog_digital_time_num_7.png';  // set of images with numbers
            normal_second_TextCircle_ASCIIARRAY[8] = 'informative_analog_digital_time_num_8.png';  // set of images with numbers
            normal_second_TextCircle_ASCIIARRAY[9] = 'informative_analog_digital_time_num_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              normal_second_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 240,
                center_y: 240,
                pos_x: 240 - normal_second_TextCircle_img_width / 2,
                pos_y: 240 + 145,
                src: 'informative_analog_digital_time_num_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_second_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block


            console.log('Watch_Face.ScreenAOD');

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 91,
              hour_startY: 170,
              hour_array: ["d_0.png","d_1.png","d_2.png","d_3.png","d_4.png","d_5.png","d_6.png","d_7.png","d_8.png","d_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_unit_sc: 'colond_5.png',
              hour_unit_tc: 'colond_5.png',
              hour_unit_en: 'colond_5.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 251,
              minute_startY: 170,
              minute_array: ["d_0.png","d_1.png","d_2.png","d_3.png","d_4.png","d_5.png","d_6.png","d_7.png","d_8.png","d_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 372,
              y: 225,
              w: 75,
              h: 75,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_cal_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 191,
              y: 145,
              w: 100,
              h: 100,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 32,
              y: 225,
              w: 75,
              h: 75,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 214,
              y: 395,
              w: 55,
              h: 55,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 302,
              y: 370,
              w: 55,
              h: 55,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 123,
              y: 370,
              w: 55,
              h: 55,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 194,
              y: 293,
              w: 100,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            //start of ignored block
            function text_update() {
              console.log('text_update()');

              console.log('update text circle hour_TIME');
              let valueHour = timeSensor.format_hour;
              let normal_hour_circle_string = parseInt(valueHour).toString();
              normal_hour_circle_string = normal_hour_circle_string.padStart(2, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_hour_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_hour_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
                let char_Angle = 35;
                if (valueHour != null && valueHour != undefined && isFinite(valueHour) && normal_hour_circle_string.length > 0 && normal_hour_circle_string.length <= 2) {  // display data if it was possible to get it
                  let normal_hour_TextCircle_img_angle = 0;
                  let normal_hour_TextCircle_dot_img_angle = 0;
                  let normal_hour_TextCircle_unit_angle = 0;
                  normal_hour_TextCircle_img_angle = toDegree(Math.atan2(normal_hour_TextCircle_img_width/2, 218));
                  normal_hour_TextCircle_unit_angle = toDegree(Math.atan2(normal_hour_TextCircle_unit_width/2, 218));
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_hour_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= normal_hour_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_hour_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_hour_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - normal_hour_TextCircle_img_width / 2);
                      normal_hour_TextCircle[index].setProperty(hmUI.prop.SRC, normal_hour_TextCircle_ASCIIARRAY[charCode]);
                      normal_hour_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= normal_hour_TextCircle_img_angle + 1;
                      index++;
                    };  // end if digit
                  };  // end char of string
                  char_Angle -= normal_hour_TextCircle_unit_angle;
                  normal_hour_TextCircle_unit.setProperty(hmUI.prop.ANGLE, char_Angle);
                  normal_hour_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite

              };

              console.log('update text circle minute_TIME');
              let valueMinute = timeSensor.minute;
              let normal_minute_circle_string = parseInt(valueMinute).toString();
              normal_minute_circle_string = normal_minute_circle_string.padStart(2, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_minute_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_minute_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
                let char_Angle = 5;
                if (valueMinute != null && valueMinute != undefined && isFinite(valueMinute) && normal_minute_circle_string.length > 0 && normal_minute_circle_string.length <= 2) {  // display data if it was possible to get it
                  let normal_minute_TextCircle_img_angle = 0;
                  let normal_minute_TextCircle_dot_img_angle = 0;
                  let normal_minute_TextCircle_unit_angle = 0;
                  normal_minute_TextCircle_img_angle = toDegree(Math.atan2(normal_minute_TextCircle_img_width/2, 219));
                  normal_minute_TextCircle_unit_angle = toDegree(Math.atan2(normal_minute_TextCircle_unit_width/2, 219));
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_minute_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= normal_minute_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_minute_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_minute_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - normal_minute_TextCircle_img_width / 2);
                      normal_minute_TextCircle[index].setProperty(hmUI.prop.SRC, normal_minute_TextCircle_ASCIIARRAY[charCode]);
                      normal_minute_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= normal_minute_TextCircle_img_angle + 1;
                      index++;
                    };  // end if digit
                  };  // end char of string
                  char_Angle -= normal_minute_TextCircle_unit_angle;
                  normal_minute_TextCircle_unit.setProperty(hmUI.prop.ANGLE, char_Angle);
                  normal_minute_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite

              };

              console.log('update text circle second_TIME');
              let valueSecond = timeSensor.second;
              let normal_second_circle_string = parseInt(valueSecond).toString();
              normal_second_circle_string = normal_second_circle_string.padStart(2, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_second_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = 335;
                if (valueSecond != null && valueSecond != undefined && isFinite(valueSecond) && normal_second_circle_string.length > 0 && normal_second_circle_string.length <= 2) {  // display data if it was possible to get it
                  let normal_second_TextCircle_img_angle = 0;
                  let normal_second_TextCircle_dot_img_angle = 0;
                  normal_second_TextCircle_img_angle = toDegree(Math.atan2(normal_second_TextCircle_img_width/2, 218));
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_second_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= normal_second_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_second_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_second_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - normal_second_TextCircle_img_width / 2);
                      normal_second_TextCircle[index].setProperty(hmUI.prop.SRC, normal_second_TextCircle_ASCIIARRAY[charCode]);
                      normal_second_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= normal_second_TextCircle_img_angle + 1;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

            };

            //end of ignored block
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                text_update();
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerTextUpdate) {
                    normal_timerTextUpdate = timer.createTimer(0, 1000, (function (option) {
                      text_update();
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerTextUpdate) {
                  timer.stopTimer(normal_timerTextUpdate);
                  normal_timerTextUpdate = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_pai_icon_img = ''
        let normal_battery_text_text_img = ''
        let normal_digital_clock_img_time = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'FONDO1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 297,
              month_startY: 98,
              month_sc_array: ["ME00.png","ME01.png","ME02.png","ME03.png","ME04.png","ME05.png","ME06.png","ME07.png","ME08.png","ME09.png","ME10.png","ME11.png"],
              month_tc_array: ["ME00.png","ME01.png","ME02.png","ME03.png","ME04.png","ME05.png","ME06.png","ME07.png","ME08.png","ME09.png","ME10.png","ME11.png"],
              month_en_array: ["ME00.png","ME01.png","ME02.png","ME03.png","ME04.png","ME05.png","ME06.png","ME07.png","ME08.png","ME09.png","ME10.png","ME11.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 124,
              y: 98,
              week_en: ["DI00.png","DI01.png","DI02.png","DI03.png","DI04.png","DI05.png","DI06.png"],
              week_tc: ["DI00.png","DI01.png","DI02.png","DI03.png","DI04.png","DI05.png","DI06.png"],
              week_sc: ["DI00.png","DI01.png","DI02.png","DI03.png","DI04.png","DI05.png","DI06.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 222,
              day_startY: 99,
              day_sc_array: ["0123.png","0124.png","0125.png","0126.png","0127.png","0128.png","0129.png","0130.png","0131.png","0132.png"],
              day_tc_array: ["0123.png","0124.png","0125.png","0126.png","0127.png","0128.png","0129.png","0130.png","0131.png","0132.png"],
              day_en_array: ["0123.png","0124.png","0125.png","0126.png","0127.png","0128.png","0129.png","0130.png","0131.png","0132.png"],
              day_zero: 1,
              day_space: 1,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'negro.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 221,
              y: 428,
              font_array: ["NU00.png","NU01.png","NU02.png","NU03.png","NU04.png","NU05.png","NU06.png","NU07.png","NU08.png","NU09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 74,
              hour_startY: 183,
              hour_array: ["Ore_01.png","Ore_02.png","Ore_03.png","Ore_04.png","Ore_05.png","Ore_06.png","Ore_07.png","Ore_08.png","Ore_09.png","Ore_10.png"],
              hour_zero: 1,
              hour_space: 7,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 259,
              minute_startY: 183,
              minute_array: ["Ore_01.png","Ore_02.png","Ore_03.png","Ore_04.png","Ore_05.png","Ore_06.png","Ore_07.png","Ore_08.png","Ore_09.png","Ore_10.png"],
              minute_zero: 1,
              minute_space: 7,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 227,
              second_startY: 186,
              second_array: ["SEC01.png","SEC02.png","SEC03.png","SEC04.png","SEC05.png","SEC06.png","SEC07.png","SEC08.png","SEC09.png","SEC10.png"],
              second_zero: 1,
              second_space: -23,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
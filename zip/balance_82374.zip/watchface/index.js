﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

//// 24H icon
let time24 = hmSensor.createSensor(hmSensor.id.TIME);
let normal_24Hcheck =''

function check24h(){
if (time24.is24Hour){
normal_24Hcheck.setProperty(hmUI.prop.VISIBLE, true);
}

if (!time24.is24Hour){
normal_24Hcheck.setProperty(hmUI.prop.VISIBLE, false);
}

}

//////////////////////////////////////////////////////////////////////////////////////////////////

        // Start color change
        let colornumber_main = 1
        let totalcolors_main = 6
        let namecolor_main = ''
        const deviceInfoX = hmSetting.getDeviceInfo();

        function click_Color() {
            if(colornumber_main>=totalcolors_main) {
            colornumber_main=1;
                }
            else {
                colornumber_main=colornumber_main+1;
            }

if ( colornumber_main == 1) { namecolor_main = "LEMON"}
            normal_battery_TextRotate_unit.setProperty(hmUI.prop.SRC, "C_LAM/Batt_unit.png");

            normal_battery_TextRotate_ASCIIARRAY[0] = "C_LAM/Batt_0.png";  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[1] = "C_LAM/Batt_1.png"; // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[2] = "C_LAM/Batt_2.png"; // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[3] = "C_LAM/Batt_3.png"; // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[4] = "C_LAM/Batt_4.png"; // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[5] = "C_LAM/Batt_5.png"; // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[6] = "C_LAM/Batt_6.png"; // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[7] = "C_LAM/Batt_7.png"; // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[8] = "C_LAM/Batt_8.png"; // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[9] = "C_LAM/Batt_9.png"; // set of images with numbers

            normal_step_TextRotate_ASCIIARRAY[0] = "C_LAM/Batt_0.png";  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[1] = "C_LAM/Batt_1.png"; // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[2] = "C_LAM/Batt_2.png"; // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[3] = "C_LAM/Batt_3.png"; // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[4] = "C_LAM/Batt_4.png"; // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[5] = "C_LAM/Batt_5.png"; // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[6] = "C_LAM/Batt_6.png"; // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[7] = "C_LAM/Batt_7.png"; // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[8] = "C_LAM/Batt_8.png"; // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[9] = "C_LAM/Batt_9.png"; // set of images with numbers

            normal_date_img_date_day.setProperty(hmUI.prop.MORE, {
              day_startX: deviceInfoX.width / 480 * 205,
              day_startY: deviceInfoX.width / 480 * 142,
              day_sc_array: ["C_LAM/Day_0.png","C_LAM/Day_1.png","C_LAM/Day_2.png","C_LAM/Day_3.png","C_LAM/Day_4.png","C_LAM/Day_5.png","C_LAM/Day_6.png","C_LAM/Day_7.png","C_LAM/Day_8.png","C_LAM/Day_9.png"],
              day_tc_array: ["C_LAM/Day_0.png","C_LAM/Day_1.png","C_LAM/Day_2.png","C_LAM/Day_3.png","C_LAM/Day_4.png","C_LAM/Day_5.png","C_LAM/Day_6.png","C_LAM/Day_7.png","C_LAM/Day_8.png","C_LAM/Day_9.png"],
              day_en_array: ["C_LAM/Day_0.png","C_LAM/Day_1.png","C_LAM/Day_2.png","C_LAM/Day_3.png","C_LAM/Day_4.png","C_LAM/Day_5.png","C_LAM/Day_6.png","C_LAM/Day_7.png","C_LAM/Day_8.png","C_LAM/Day_9.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
           });


if ( colornumber_main == 2) { namecolor_main = "RED"

            normal_battery_TextRotate_unit.setProperty(hmUI.prop.SRC, "C_RED/Batt_unit.png");

            normal_battery_TextRotate_ASCIIARRAY[0] = "C_RED/Batt_0.png";  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[1] = "C_RED/Batt_1.png"; // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[2] = "C_RED/Batt_2.png"; // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[3] = "C_RED/Batt_3.png"; // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[4] = "C_RED/Batt_4.png"; // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[5] = "C_RED/Batt_5.png"; // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[6] = "C_RED/Batt_6.png"; // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[7] = "C_RED/Batt_7.png"; // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[8] = "C_RED/Batt_8.png"; // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[9] = "C_RED/Batt_9.png"; // set of images with numbers

            normal_step_TextRotate_ASCIIARRAY[0] = "C_RED/Batt_0.png";  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[1] = "C_RED/Batt_1.png"; // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[2] = "C_RED/Batt_2.png"; // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[3] = "C_RED/Batt_3.png"; // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[4] = "C_RED/Batt_4.png"; // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[5] = "C_RED/Batt_5.png"; // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[6] = "C_RED/Batt_6.png"; // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[7] = "C_RED/Batt_7.png"; // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[8] = "C_RED/Batt_8.png"; // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[9] = "C_RED/Batt_9.png"; // set of images with numbers

            normal_date_img_date_day.setProperty(hmUI.prop.MORE, {
              day_startX: deviceInfoX.width / 480 * 205,
              day_startY: deviceInfoX.width / 480 * 142,
              day_sc_array: ["C_RED/Day_0.png","C_RED/Day_1.png","C_RED/Day_2.png","C_RED/Day_3.png","C_RED/Day_4.png","C_RED/Day_5.png","C_RED/Day_6.png","C_RED/Day_7.png","C_RED/Day_8.png","C_RED/Day_9.png"],
              day_tc_array: ["C_RED/Day_0.png","C_RED/Day_1.png","C_RED/Day_2.png","C_RED/Day_3.png","C_RED/Day_4.png","C_RED/Day_5.png","C_RED/Day_6.png","C_RED/Day_7.png","C_RED/Day_8.png","C_RED/Day_9.png"],
              day_en_array: ["C_RED/Day_0.png","C_RED/Day_1.png","C_RED/Day_2.png","C_RED/Day_3.png","C_RED/Day_4.png","C_RED/Day_5.png","C_RED/Day_6.png","C_RED/Day_7.png","C_RED/Day_8.png","C_RED/Day_9.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
           });
       }
if ( colornumber_main == 3) { namecolor_main = "ORANGE"
           normal_battery_TextRotate_unit.setProperty(hmUI.prop.SRC, "C_ORA/Batt_unit.png");

            normal_battery_TextRotate_ASCIIARRAY[0] = "C_ORA/Batt_0.png";  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[1] = "C_ORA/Batt_1.png"; // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[2] = "C_ORA/Batt_2.png"; // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[3] = "C_ORA/Batt_3.png"; // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[4] = "C_ORA/Batt_4.png"; // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[5] = "C_ORA/Batt_5.png"; // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[6] = "C_ORA/Batt_6.png"; // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[7] = "C_ORA/Batt_7.png"; // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[8] = "C_ORA/Batt_8.png"; // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[9] = "C_ORA/Batt_9.png"; // set of images with numbers

            normal_step_TextRotate_ASCIIARRAY[0] = "C_ORA/Batt_0.png";  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[1] = "C_ORA/Batt_1.png"; // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[2] = "C_ORA/Batt_2.png"; // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[3] = "C_ORA/Batt_3.png"; // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[4] = "C_ORA/Batt_4.png"; // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[5] = "C_ORA/Batt_5.png"; // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[6] = "C_ORA/Batt_6.png"; // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[7] = "C_ORA/Batt_7.png"; // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[8] = "C_ORA/Batt_8.png"; // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[9] = "C_ORA/Batt_9.png"; // set of images with numbers

            normal_date_img_date_day.setProperty(hmUI.prop.MORE, {
              day_startX: deviceInfoX.width / 480 * 205,
              day_startY: deviceInfoX.width / 480 * 142,
              day_sc_array: ["C_ORA/Day_0.png","C_ORA/Day_1.png","C_ORA/Day_2.png","C_ORA/Day_3.png","C_ORA/Day_4.png","C_ORA/Day_5.png","C_ORA/Day_6.png","C_ORA/Day_7.png","C_ORA/Day_8.png","C_ORA/Day_9.png"],
              day_tc_array: ["C_ORA/Day_0.png","C_ORA/Day_1.png","C_ORA/Day_2.png","C_ORA/Day_3.png","C_ORA/Day_4.png","C_ORA/Day_5.png","C_ORA/Day_6.png","C_ORA/Day_7.png","C_ORA/Day_8.png","C_ORA/Day_9.png"],
              day_en_array: ["C_ORA/Day_0.png","C_ORA/Day_1.png","C_ORA/Day_2.png","C_ORA/Day_3.png","C_ORA/Day_4.png","C_ORA/Day_5.png","C_ORA/Day_6.png","C_ORA/Day_7.png","C_ORA/Day_8.png","C_ORA/Day_9.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
           });
}
if ( colornumber_main == 4) { namecolor_main = "YELLOW"
           normal_battery_TextRotate_unit.setProperty(hmUI.prop.SRC, "C_YEL/Batt_unit.png");

            normal_battery_TextRotate_ASCIIARRAY[0] = "C_YEL/Batt_0.png";  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[1] = "C_YEL/Batt_1.png"; // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[2] = "C_YEL/Batt_2.png"; // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[3] = "C_YEL/Batt_3.png"; // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[4] = "C_YEL/Batt_4.png"; // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[5] = "C_YEL/Batt_5.png"; // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[6] = "C_YEL/Batt_6.png"; // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[7] = "C_YEL/Batt_7.png"; // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[8] = "C_YEL/Batt_8.png"; // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[9] = "C_YEL/Batt_9.png"; // set of images with numbers

            normal_step_TextRotate_ASCIIARRAY[0] = "C_YEL/Batt_0.png";  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[1] = "C_YEL/Batt_1.png"; // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[2] = "C_YEL/Batt_2.png"; // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[3] = "C_YEL/Batt_3.png"; // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[4] = "C_YEL/Batt_4.png"; // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[5] = "C_YEL/Batt_5.png"; // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[6] = "C_YEL/Batt_6.png"; // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[7] = "C_YEL/Batt_7.png"; // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[8] = "C_YEL/Batt_8.png"; // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[9] = "C_YEL/Batt_9.png"; // set of images with numbers

            normal_date_img_date_day.setProperty(hmUI.prop.MORE, {
              day_startX: deviceInfoX.width / 480 * 205,
              day_startY: deviceInfoX.width / 480 * 142,
              day_sc_array: ["C_YEL/Day_0.png","C_YEL/Day_1.png","C_YEL/Day_2.png","C_YEL/Day_3.png","C_YEL/Day_4.png","C_YEL/Day_5.png","C_YEL/Day_6.png","C_YEL/Day_7.png","C_YEL/Day_8.png","C_YEL/Day_9.png"],
              day_tc_array: ["C_YEL/Day_0.png","C_YEL/Day_1.png","C_YEL/Day_2.png","C_YEL/Day_3.png","C_YEL/Day_4.png","C_YEL/Day_5.png","C_YEL/Day_6.png","C_YEL/Day_7.png","C_YEL/Day_8.png","C_YEL/Day_9.png"],
              day_en_array: ["C_YEL/Day_0.png","C_YEL/Day_1.png","C_YEL/Day_2.png","C_YEL/Day_3.png","C_YEL/Day_4.png","C_YEL/Day_5.png","C_YEL/Day_6.png","C_YEL/Day_7.png","C_YEL/Day_8.png","C_YEL/Day_9.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
           });
}
if ( colornumber_main == 5) { namecolor_main = "BLUE"
           normal_battery_TextRotate_unit.setProperty(hmUI.prop.SRC, "C_BLU/Batt_unit.png");

            normal_battery_TextRotate_ASCIIARRAY[0] = "C_BLU/Batt_0.png";  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[1] = "C_BLU/Batt_1.png"; // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[2] = "C_BLU/Batt_2.png"; // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[3] = "C_BLU/Batt_3.png"; // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[4] = "C_BLU/Batt_4.png"; // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[5] = "C_BLU/Batt_5.png"; // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[6] = "C_BLU/Batt_6.png"; // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[7] = "C_BLU/Batt_7.png"; // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[8] = "C_BLU/Batt_8.png"; // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[9] = "C_BLU/Batt_9.png"; // set of images with numbers

            normal_step_TextRotate_ASCIIARRAY[0] = "C_BLU/Batt_0.png";  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[1] = "C_BLU/Batt_1.png"; // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[2] = "C_BLU/Batt_2.png"; // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[3] = "C_BLU/Batt_3.png"; // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[4] = "C_BLU/Batt_4.png"; // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[5] = "C_BLU/Batt_5.png"; // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[6] = "C_BLU/Batt_6.png"; // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[7] = "C_BLU/Batt_7.png"; // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[8] = "C_BLU/Batt_8.png"; // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[9] = "C_BLU/Batt_9.png"; // set of images with numbers

            normal_date_img_date_day.setProperty(hmUI.prop.MORE, {
              day_startX: deviceInfoX.width / 480 * 205,
              day_startY: deviceInfoX.width / 480 * 142,
              day_sc_array: ["C_BLU/Day_0.png","C_BLU/Day_1.png","C_BLU/Day_2.png","C_BLU/Day_3.png","C_BLU/Day_4.png","C_BLU/Day_5.png","C_BLU/Day_6.png","C_BLU/Day_7.png","C_BLU/Day_8.png","C_BLU/Day_9.png"],
              day_tc_array: ["C_BLU/Day_0.png","C_BLU/Day_1.png","C_BLU/Day_2.png","C_BLU/Day_3.png","C_BLU/Day_4.png","C_BLU/Day_5.png","C_BLU/Day_6.png","C_BLU/Day_7.png","C_BLU/Day_8.png","C_BLU/Day_9.png"],
              day_en_array: ["C_BLU/Day_0.png","C_BLU/Day_1.png","C_BLU/Day_2.png","C_BLU/Day_3.png","C_BLU/Day_4.png","C_BLU/Day_5.png","C_BLU/Day_6.png","C_BLU/Day_7.png","C_BLU/Day_8.png","C_BLU/Day_9.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
           });
}
if ( colornumber_main == 6) { namecolor_main = "GRAY"
           normal_battery_TextRotate_unit.setProperty(hmUI.prop.SRC, "C_GRA/Batt_unit.png");

            normal_battery_TextRotate_ASCIIARRAY[0] = "C_GRA/Batt_0.png";  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[1] = "C_GRA/Batt_1.png"; // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[2] = "C_GRA/Batt_2.png"; // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[3] = "C_GRA/Batt_3.png"; // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[4] = "C_GRA/Batt_4.png"; // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[5] = "C_GRA/Batt_5.png"; // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[6] = "C_GRA/Batt_6.png"; // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[7] = "C_GRA/Batt_7.png"; // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[8] = "C_GRA/Batt_8.png"; // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[9] = "C_GRA/Batt_9.png"; // set of images with numbers

            normal_step_TextRotate_ASCIIARRAY[0] = "C_GRA/Batt_0.png";  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[1] = "C_GRA/Batt_1.png"; // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[2] = "C_GRA/Batt_2.png"; // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[3] = "C_GRA/Batt_3.png"; // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[4] = "C_GRA/Batt_4.png"; // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[5] = "C_GRA/Batt_5.png"; // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[6] = "C_GRA/Batt_6.png"; // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[7] = "C_GRA/Batt_7.png"; // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[8] = "C_GRA/Batt_8.png"; // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[9] = "C_GRA/Batt_9.png"; // set of images with numbers

            normal_date_img_date_day.setProperty(hmUI.prop.MORE, {
              day_startX: deviceInfoX.width / 480 * 205,
              day_startY: deviceInfoX.width / 480 * 142,
              day_sc_array: ["C_GRA/Day_0.png","C_GRA/Day_1.png","C_GRA/Day_2.png","C_GRA/Day_3.png","C_GRA/Day_4.png","C_GRA/Day_5.png","C_GRA/Day_6.png","C_GRA/Day_7.png","C_GRA/Day_8.png","C_GRA/Day_9.png"],
              day_tc_array: ["C_GRA/Day_0.png","C_GRA/Day_1.png","C_GRA/Day_2.png","C_GRA/Day_3.png","C_GRA/Day_4.png","C_GRA/Day_5.png","C_GRA/Day_6.png","C_GRA/Day_7.png","C_GRA/Day_8.png","C_GRA/Day_9.png"],
              day_en_array: ["C_GRA/Day_0.png","C_GRA/Day_1.png","C_GRA/Day_2.png","C_GRA/Day_3.png","C_GRA/Day_4.png","C_GRA/Day_5.png","C_GRA/Day_6.png","C_GRA/Day_7.png","C_GRA/Day_8.png","C_GRA/Day_9.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
           });
}
hmUI.showToast({text: namecolor_main });

             //hmUI.showToast({text: "color " + parseInt(colornumber_main) });
             normal_image_img.setProperty(hmUI.prop.SRC, "Top_main" + parseInt(colornumber_main) + ".png");
              const result = hmSetting.setScreenOff()             
        }
        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_rotate_animation_img_1 = '';
        let normal_rotate_animation_param_1 = null;
        let normal_rotate_animation_lastTime_1 = 0;
        let timer_anim_rotate_1;
        let normal_rotate_animation_count_1 = 0;
        let normal_image_img = ''
        let normal_sun_low_text_img = ''
        let normal_sun_high_text_img = ''
        let normal_date_img_date_week_img = ''
        let normal_altitude_target_text_img = ''
        let normal_humidity_text_text_img = ''
        let normal_humidity_text_separator_img = ''
        let normal_pai_weekly_text_img = ''
        let normal_pai_weekly_separator_img = ''
        let normal_spo2_text_text_img = ''
        let normal_spo2_text_separator_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_text_separator_img = ''
        let normal_compass_direction_pointer_img = ''
        let normal_compass_direction_img_level = ''
        let normal_compass_direction_arr = ["compass_direct_1.png", "compass_direct_2.png", "compass_direct_3.png", "compass_direct_4.png", "compass_direct_5.png", "compass_direct_6.png", "compass_direct_7.png", "compass_direct_8.png"];
        let normal_moon_image_progress_img_level = ''
        let normal_date_img_date_month_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_date_img_date_day = ''
        let normal_distance_TextRotate = new Array(5);
        let normal_distance_TextRotate_ASCIIARRAY = new Array(10);
        let normal_distance_TextRotate_img_width = 11;
        let normal_distance_TextRotate_unit = null;
        let normal_distance_TextRotate_unit_width = 22;
        let normal_distance_TextRotate_dot_width = 6;
        let normal_distance_TextRotate_error_img_width = 11;
        let normal_calorie_TextRotate = new Array(4);
        let normal_calorie_TextRotate_ASCIIARRAY = new Array(10);
        let normal_calorie_TextRotate_img_width = 11;
        let normal_calorie_TextRotate_error_img_width = 11;
        let normal_step_TextRotate = new Array(5);
        let normal_step_TextRotate_ASCIIARRAY = new Array(10);
        let normal_step_TextRotate_img_width = 21;
        let normal_step_TextRotate_error_img_width = 21;
        let normal_step_image_progress_img_level = ''
        let normal_battery_TextRotate = new Array(3);
        let normal_battery_TextRotate_ASCIIARRAY = new Array(10);
        let normal_battery_TextRotate_img_width = 21;
        let normal_battery_TextRotate_unit = null;
        let normal_battery_TextRotate_unit_width = 33;
        let normal_battery_TextRotate_error_img_width = 21;
        let normal_battery_image_progress_img_level = ''
        let normal_city_name_text = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time_second = ''
        let normal_digital_clock_img_time_minute = ''
        let normal_digital_clock_img_time_hour = ''
        let idle_background_bg_img = ''
        let idle_stress_icon_img = ''
        let idle_image_img = ''
        let idle_sun_low_text_img = ''
        let idle_sun_high_text_img = ''
        let idle_date_img_date_week_img = ''
        let idle_altitude_target_text_img = ''
        let idle_humidity_text_text_img = ''
        let idle_humidity_text_separator_img = ''
        let idle_pai_weekly_text_img = ''
        let idle_pai_weekly_separator_img = ''
        let idle_spo2_text_text_img = ''
        let idle_spo2_text_separator_img = ''
        let idle_heart_rate_text_text_img = ''
        let idle_heart_rate_text_separator_img = ''
        let idle_moon_image_progress_img_level = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_day = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_distance_TextRotate = new Array(5);
        let idle_distance_TextRotate_ASCIIARRAY = new Array(10);
        let idle_distance_TextRotate_img_width = 11;
        let idle_distance_TextRotate_unit = null;
        let idle_distance_TextRotate_unit_width = 22;
        let idle_distance_TextRotate_dot_width = 6;
        let idle_distance_TextRotate_error_img_width = 11;
        let idle_calorie_TextRotate = new Array(4);
        let idle_calorie_TextRotate_ASCIIARRAY = new Array(10);
        let idle_calorie_TextRotate_img_width = 11;
        let idle_calorie_TextRotate_error_img_width = 11;
        let idle_step_TextRotate = new Array(5);
        let idle_step_TextRotate_ASCIIARRAY = new Array(10);
        let idle_step_TextRotate_img_width = 21;
        let idle_step_TextRotate_error_img_width = 21;
        let idle_step_image_progress_img_level = ''
        let idle_battery_TextRotate = new Array(3);
        let idle_battery_TextRotate_ASCIIARRAY = new Array(10);
        let idle_battery_TextRotate_img_width = 21;
        let idle_battery_TextRotate_unit = null;
        let idle_battery_TextRotate_unit_width = 33;
        let idle_battery_TextRotate_error_img_width = 21;
        let idle_battery_image_progress_img_level = ''
        let idle_city_name_text = ''
        let idle_weather_image_progress_img_level = ''
        let idle_temperature_current_text_img = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time_second = ''
        let idle_digital_clock_img_time_minute = ''
        let idle_digital_clock_img_time_hour = ''
        let normal_step_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_moon_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_rotate_animation_img_1 = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 481,
              h: 481,
              pos_x: 0,
              pos_y: 0,
              center_x: 240,
              center_y: 240,
              angle: 0,
              src: 'animation/cir_0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_rotate_animation_param_1 = {
              anim_steps: [{
                anim_rate: 'linear',
                anim_duration: 100000,
                anim_from: 0,
                anim_to: 360,
                anim_key: "angle",
              }],
              anim_fps: 15,
              anim_auto_start: 1,
              anim_repeat: 1,
              anim_auto_destroy: 1,
            };

            let now = hmSensor.createSensor(hmSensor.id.TIME);

            function anim_rotate_1_complete_call() {
              normal_rotate_animation_img_1.setProperty(hmUI.prop.ANIM, normal_rotate_animation_param_1);
              normal_rotate_animation_lastTime_1 = now.utc;
              normal_rotate_animation_count_1 = normal_rotate_animation_count_1 - 1;
              if(normal_rotate_animation_count_1 < -1) normal_rotate_animation_count_1 = - 1;
              if(normal_rotate_animation_count_1 == 0) stop_anim_rotate_1();
            }; // end animation callback function
            
            function stop_anim_rotate_1() {
              if (timer_anim_rotate_1) {
                timer.stopTimer(timer_anim_rotate_1);
                timer_anim_rotate_1 = undefined;
              };
            }; // end stop_anim_rotate function

            // normal_rotate_anime_1 = hmUI.createWidget(hmUI.widget.Rotate_Animation, {
              // start_angle: 0,
              // end_angle: 360,
              // pos_x: 240,
              // pos_y: 240,
              // center_x: 240,
              // center_y: 240,
              // src: 'cir_0.png',
              // anim_fps: 15,
              // anim_duration: 100000,
              // repeat_count: 0,
              // anim_two_sides: False,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'Top_main1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 357,
              y: 230,
              font_array: ["SS_0.png","SS_1.png","SS_2.png","SS_3.png","SS_4.png","SS_5.png","SS_6.png","SS_7.png","SS_8.png","SS_9.png"],
              padding: false,
              h_space: 0,
              dot_image: 'SS_Dot.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 49,
              y: 230,
              font_array: ["SS_0.png","SS_1.png","SS_2.png","SS_3.png","SS_4.png","SS_5.png","SS_6.png","SS_7.png","SS_8.png","SS_9.png"],
              padding: false,
              h_space: 0,
              dot_image: 'SS_Dot.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 153,
              y: 206,
              week_en: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              week_tc: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              week_sc: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altitude_target_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 401,
              y: 196,
              font_array: ["Baro_0.png","Baro_1.png","Baro_2.png","Baro_3.png","Baro_4.png","Baro_5.png","Baro_6.png","Baro_7.png","Baro_8.png","Baro_9.png"],
              padding: false,
              h_space: 0,
              negative_image: 'Baro_Symbol1.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.ALTITUDE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 224,
              y: 284,
              font_array: ["Temp_0.png","Temp_1.png","Temp_2.png","Temp_3.png","Temp_4.png","Temp_5.png","Temp_6.png","Temp_7.png","Temp_8.png","Temp_9.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'P_unit.png',
              unit_tc: 'P_unit.png',
              unit_en: 'P_unit.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 197,
              y: 282,
              src: 'icon_hum.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_weekly_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 233,
              y: 332,
              font_array: ["heart_0.png","heart_1.png","heart_2.png","heart_3.png","heart_4.png","heart_5.png","heart_6.png","heart_7.png","heart_8.png","heart_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_weekly_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 190,
              y: 332,
              src: 'icon_pai.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 232,
              y: 378,
              font_array: ["Temp_0.png","Temp_1.png","Temp_2.png","Temp_3.png","Temp_4.png","Temp_5.png","Temp_6.png","Temp_7.png","Temp_8.png","Temp_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'P_unit.png',
              unit_tc: 'P_unit.png',
              unit_en: 'P_unit.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 194,
              y: 375,
              src: 'icon_O2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 233,
              y: 419,
              font_array: ["heart_0.png","heart_1.png","heart_2.png","heart_3.png","heart_4.png","heart_5.png","heart_6.png","heart_7.png","heart_8.png","heart_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 196,
              y: 424,
              src: 'icon_heart.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const deviceInfo = hmSetting.getDeviceInfo();
            
            // normal_compass_custom_pointer_img = hmUI.createWidget(hmUI.widget.CUSTOM_POINTER, {
              // src: 'Compass_pointer.png',
              // center_x: 31,
              // center_y: 176,
              // x: 17,
              // y: 17,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.COMPASS,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            //start of ignored block
            normal_compass_direction_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 31 - 17,
              pos_y: 176 - 17,
              center_x: 31,
              center_y: 176,
              src: 'Compass_pointer.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            //end of ignored block

            normal_compass_direction_img_level = hmUI.createWidget(hmUI.widget.IMG, {
              x: 46,
              y: 195,
              src: 'compass_direct_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
              // type: hmUI.data_type.COMPASS,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 19,
              y: 298,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 192,
              month_startY: 111,
              month_sc_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_tc_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_en_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 279,
              y: 14,
              src: 'System_BT_OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 182,
              y: 17,
              src: 'System_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 205,
              day_startY: 142,
              day_sc_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              day_tc_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              day_en_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_distance_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 350,
              // y: 94,
              // font_array: ["cal_0.png","cal_1.png","cal_2.png","cal_3.png","cal_4.png","cal_5.png","cal_6.png","cal_7.png","cal_8.png","cal_9.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: -34,
              // unit_en: 'Dis_KM.png',
              // imperial_unit_en: 'Dis_Mi.png',
              // negative_image: 'dis_dot.png',
              // invalid_image: 'cal_0.png',
              // dot_image: 'dis_dot.png',
              // align_h: hmUI.align.RIGHT,
              // type: hmUI.data_type.DISTANCE,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_distance_TextRotate_ASCIIARRAY[0] = 'cal_0.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[1] = 'cal_1.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[2] = 'cal_2.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[3] = 'cal_3.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[4] = 'cal_4.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[5] = 'cal_5.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[6] = 'cal_6.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[7] = 'cal_7.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[8] = 'cal_8.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[9] = 'cal_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              normal_distance_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 350,
                center_y: 94,
                pos_x: 350,
                pos_y: 94,
                angle: -34,
                src: 'cal_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_distance_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_distance_TextRotate_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              center_x: 350,
              center_y: 94,
              pos_x: 350,
              pos_y: 94,
              angle: -34,
              src: 'Dis_KM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_distance_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);

            const mileageUnit = hmSetting.getMileageUnit();
            if (mileageUnit == 1) {
              normal_distance_TextRotate_unit.setProperty(hmUI.prop.SRC, 'Dis_Mi.png');
            };
            //end of ignored block
            
            const distance = hmSensor.createSensor(hmSensor.id.DISTANCE);
            distance.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });
            
            function toDegree (radian) {
              return radian * (180 / Math.PI);
            };

            // normal_calorie_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 109,
              // y: 81,
              // font_array: ["cal_0.png","cal_1.png","cal_2.png","cal_3.png","cal_4.png","cal_5.png","cal_6.png","cal_7.png","cal_8.png","cal_9.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 1,
              // angle: 36,
              // invalid_image: 'cal_0.png',
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_calorie_TextRotate_ASCIIARRAY[0] = 'cal_0.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[1] = 'cal_1.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[2] = 'cal_2.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[3] = 'cal_3.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[4] = 'cal_4.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[5] = 'cal_5.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[6] = 'cal_6.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[7] = 'cal_7.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[8] = 'cal_8.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[9] = 'cal_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 4; i++) {
              normal_calorie_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 109,
                center_y: 81,
                pos_x: 109,
                pos_y: 81,
                angle: 36,
                src: 'cal_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_calorie_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            
            const calorie = hmSensor.createSensor(hmSensor.id.CALORIE);
            calorie.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            // normal_step_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 395,
              // y: 109,
              // font_array: ["Batt_0.png","Batt_1.png","Batt_2.png","Batt_3.png","Batt_4.png","Batt_5.png","Batt_6.png","Batt_7.png","Batt_8.png","Batt_9.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: -34,
              // invalid_image: 'Batt_0.png',
              // align_h: hmUI.align.RIGHT,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_step_TextRotate_ASCIIARRAY[0] = 'Batt_0.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[1] = 'Batt_1.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[2] = 'Batt_2.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[3] = 'Batt_3.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[4] = 'Batt_4.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[5] = 'Batt_5.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[6] = 'Batt_6.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[7] = 'Batt_7.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[8] = 'Batt_8.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[9] = 'Batt_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              normal_step_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 395,
                center_y: 109,
                pos_x: 395,
                pos_y: 109,
                angle: -34,
                src: 'Batt_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_step_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 336,
              y: 123,
              image_array: ["step_progress_01.png","step_progress_02.png","step_progress_03.png","step_progress_04.png","step_progress_05.png","step_progress_06.png","step_progress_07.png"],
              image_length: 7,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_battery_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 83,
              // y: 108,
              // font_array: ["Batt_0.png","Batt_1.png","Batt_2.png","Batt_3.png","Batt_4.png","Batt_5.png","Batt_6.png","Batt_7.png","Batt_8.png","Batt_9.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: 35,
              // unit_en: 'Batt_unit.png',
              // invalid_image: 'Batt_0.png',
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_battery_TextRotate_ASCIIARRAY[0] = 'Batt_0.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[1] = 'Batt_1.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[2] = 'Batt_2.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[3] = 'Batt_3.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[4] = 'Batt_4.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[5] = 'Batt_5.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[6] = 'Batt_6.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[7] = 'Batt_7.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[8] = 'Batt_8.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[9] = 'Batt_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 3; i++) {
              normal_battery_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 83,
                center_y: 108,
                pos_x: 83,
                pos_y: 108,
                angle: 35,
                src: 'Batt_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_battery_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_battery_TextRotate_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              center_x: 83,
              center_y: 108,
              pos_x: 83,
              pos_y: 108,
              angle: 35,
              src: 'Batt_unit.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_battery_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 25,
              y: 123,
              image_array: ["batt_progress_01.png","batt_progress_02.png","batt_progress_03.png","batt_progress_04.png","batt_progress_05.png","batt_progress_06.png","batt_progress_07.png"],
              image_length: 7,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 153,
              y: 61,
              w: 173,
              h: 34,
              text_size: 25,
              char_space: 0,
              line_space: 0,
              color: 0xFF000000,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 193,
              y: 236,
              image_array: ["Weather_image_01.png","Weather_image_02.png","Weather_image_03.png","Weather_image_04.png","Weather_image_05.png","Weather_image_06.png","Weather_image_07.png","Weather_image_08.png","Weather_image_09.png","Weather_image_10.png","Weather_image_11.png","Weather_image_12.png","Weather_image_13.png","Weather_image_14.png","Weather_image_15.png","Weather_image_16.png","Weather_image_17.png","Weather_image_18.png","Weather_image_19.png","Weather_image_20.png","Weather_image_21.png","Weather_image_22.png","Weather_image_23.png","Weather_image_24.png","Weather_image_25.png","Weather_image_26.png","Weather_image_27.png","Weather_image_28.png","Weather_image_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 238,
              y: 244,
              font_array: ["Temp_0.png","Temp_1.png","Temp_2.png","Temp_3.png","Temp_4.png","Temp_5.png","Temp_6.png","Temp_7.png","Temp_8.png","Temp_9.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'Temp_Symbol_1.png',
              unit_tc: 'Temp_Symbol_1.png',
              unit_en: 'Temp_Symbol_1.png',
              imperial_unit_sc: 'Temp_Symbol_2.png',
              imperial_unit_tc: 'Temp_Symbol_2.png',
              imperial_unit_en: 'Temp_Symbol_2.png',
              negative_image: 'Temp_Symbol_3.png',
              invalid_image: 'Temp_Symbol_3.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const temperatureUnit = hmSetting.getTemperatureUnit();
            //start of ignored block
            if (temperatureUnit == 1) {
              normal_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
                x: 238,
                y: 244,
                font_array: ["Temp_0.png","Temp_1.png","Temp_2.png","Temp_3.png","Temp_4.png","Temp_5.png","Temp_6.png","Temp_7.png","Temp_8.png","Temp_9.png"],
                padding: false,
                h_space: 1,
                unit_sc: 'Temp_Symbol_2.png',
                unit_tc: 'Temp_Symbol_2.png',
                unit_en: 'Temp_Symbol_2.png',
                imperial_unit_sc: 'Temp_Symbol_1.png',
                imperial_unit_tc: 'Temp_Symbol_1.png',
                imperial_unit_en: 'Temp_Symbol_1.png',
                negative_image: 'Temp_Symbol_3.png',
                invalid_image: 'Temp_Symbol_3.png',
                align_h: hmUI.align.CENTER_H,
                type: hmUI.data_type.WEATHER_CURRENT,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
            };
            //end of ignored block

            console.log('user_script.js');
            // start user_script.js
                         const deviceInfo1 = hmSetting.getDeviceInfo();
            normal_24Hcheck = hmUI.createWidget(hmUI.widget.IMG, {
              x: deviceInfo1.width / 480 * 8,
              y: deviceInfo1.height / 480 * 270,
              src: 'Clock_24H.png',
            show_level: hmUI.show_level.ALL,

            });
check24h()
            // end user_script.js

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 8,
              am_y: 270,
              am_sc_path: 'Clock_AM.png',
              am_en_path: 'Clock_AM.png',
              pm_x: 10,
              pm_y: 270,
              pm_sc_path: 'Clock_PM.png',
              pm_en_path: 'Clock_PM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_second = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              second_startX: 438,
              second_startY: 266,
              second_array: ["Time_S_0.png","Time_S_1.png","Time_S_2.png","Time_S_3.png","Time_S_4.png","Time_S_5.png","Time_S_6.png","Time_S_7.png","Time_S_8.png","Time_S_9.png"],
              second_zero: 1,
              second_space: 1,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 306,
              minute_startY: 266,
              minute_array: ["Time_0.png","Time_1.png","Time_2.png","Time_3.png","Time_4.png","Time_5.png","Time_6.png","Time_7.png","Time_8.png","Time_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 53,
              hour_startY: 266,
              hour_array: ["Time_0.png","Time_1.png","Time_2.png","Time_3.png","Time_4.png","Time_5.png","Time_6.png","Time_7.png","Time_8.png","Time_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg1.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_stress_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'cir_0.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'Top_main6.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 357,
              y: 230,
              font_array: ["SS_0.png","SS_1.png","SS_2.png","SS_3.png","SS_4.png","SS_5.png","SS_6.png","SS_7.png","SS_8.png","SS_9.png"],
              padding: false,
              h_space: 0,
              dot_image: 'SS_Dot.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 49,
              y: 230,
              font_array: ["SS_0.png","SS_1.png","SS_2.png","SS_3.png","SS_4.png","SS_5.png","SS_6.png","SS_7.png","SS_8.png","SS_9.png"],
              padding: false,
              h_space: 0,
              dot_image: 'SS_Dot.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 153,
              y: 206,
              week_en: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              week_tc: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              week_sc: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_altitude_target_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 401,
              y: 196,
              font_array: ["Baro_0.png","Baro_1.png","Baro_2.png","Baro_3.png","Baro_4.png","Baro_5.png","Baro_6.png","Baro_7.png","Baro_8.png","Baro_9.png"],
              padding: false,
              h_space: 0,
              negative_image: 'Baro_Symbol1.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.ALTITUDE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 224,
              y: 284,
              font_array: ["Temp_0.png","Temp_1.png","Temp_2.png","Temp_3.png","Temp_4.png","Temp_5.png","Temp_6.png","Temp_7.png","Temp_8.png","Temp_9.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'P_unit.png',
              unit_tc: 'P_unit.png',
              unit_en: 'P_unit.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_humidity_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 197,
              y: 282,
              src: 'icon_hum.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_pai_weekly_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 233,
              y: 332,
              font_array: ["heart_0.png","heart_1.png","heart_2.png","heart_3.png","heart_4.png","heart_5.png","heart_6.png","heart_7.png","heart_8.png","heart_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_pai_weekly_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 190,
              y: 332,
              src: 'icon_pai.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_spo2_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 232,
              y: 378,
              font_array: ["Temp_0.png","Temp_1.png","Temp_2.png","Temp_3.png","Temp_4.png","Temp_5.png","Temp_6.png","Temp_7.png","Temp_8.png","Temp_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'P_unit.png',
              unit_tc: 'P_unit.png',
              unit_en: 'P_unit.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_spo2_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 194,
              y: 375,
              src: 'icon_O2.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 233,
              y: 419,
              font_array: ["heart_0.png","heart_1.png","heart_2.png","heart_3.png","heart_4.png","heart_5.png","heart_6.png","heart_7.png","heart_8.png","heart_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 196,
              y: 424,
              src: 'icon_heart.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 19,
              y: 298,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 192,
              month_startY: 111,
              month_sc_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_tc_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_en_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 205,
              day_startY: 142,
              day_sc_array: ["Day_AOD_0.png","Day_AOD_1.png","Day_AOD_2.png","Day_AOD_3.png","Day_AOD_4.png","Day_AOD_5.png","Day_AOD_6.png","Day_AOD_7.png","Day_AOD_8.png","Day_AOD_9.png"],
              day_tc_array: ["Day_AOD_0.png","Day_AOD_1.png","Day_AOD_2.png","Day_AOD_3.png","Day_AOD_4.png","Day_AOD_5.png","Day_AOD_6.png","Day_AOD_7.png","Day_AOD_8.png","Day_AOD_9.png"],
              day_en_array: ["Day_AOD_0.png","Day_AOD_1.png","Day_AOD_2.png","Day_AOD_3.png","Day_AOD_4.png","Day_AOD_5.png","Day_AOD_6.png","Day_AOD_7.png","Day_AOD_8.png","Day_AOD_9.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 279,
              y: 14,
              src: 'System_BT_OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 182,
              y: 17,
              src: 'System_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_distance_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 350,
              // y: 94,
              // font_array: ["cal_0.png","cal_1.png","cal_2.png","cal_3.png","cal_4.png","cal_5.png","cal_6.png","cal_7.png","cal_8.png","cal_9.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: -34,
              // unit_en: 'Dis_KM.png',
              // imperial_unit_en: 'Dis_Mi.png',
              // negative_image: 'dis_dot.png',
              // invalid_image: 'cal_0.png',
              // dot_image: 'dis_dot.png',
              // align_h: hmUI.align.RIGHT,
              // type: hmUI.data_type.DISTANCE,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_distance_TextRotate_ASCIIARRAY[0] = 'cal_0.png';  // set of images with numbers
            idle_distance_TextRotate_ASCIIARRAY[1] = 'cal_1.png';  // set of images with numbers
            idle_distance_TextRotate_ASCIIARRAY[2] = 'cal_2.png';  // set of images with numbers
            idle_distance_TextRotate_ASCIIARRAY[3] = 'cal_3.png';  // set of images with numbers
            idle_distance_TextRotate_ASCIIARRAY[4] = 'cal_4.png';  // set of images with numbers
            idle_distance_TextRotate_ASCIIARRAY[5] = 'cal_5.png';  // set of images with numbers
            idle_distance_TextRotate_ASCIIARRAY[6] = 'cal_6.png';  // set of images with numbers
            idle_distance_TextRotate_ASCIIARRAY[7] = 'cal_7.png';  // set of images with numbers
            idle_distance_TextRotate_ASCIIARRAY[8] = 'cal_8.png';  // set of images with numbers
            idle_distance_TextRotate_ASCIIARRAY[9] = 'cal_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              idle_distance_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 350,
                center_y: 94,
                pos_x: 350,
                pos_y: 94,
                angle: -34,
                src: 'cal_0.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_distance_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            idle_distance_TextRotate_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              center_x: 350,
              center_y: 94,
              pos_x: 350,
              pos_y: 94,
              angle: -34,
              src: 'Dis_KM.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            idle_distance_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);

            if (mileageUnit == 1) {
              idle_distance_TextRotate_unit.setProperty(hmUI.prop.SRC, 'Dis_Mi.png');
            };
            //end of ignored block

            // idle_calorie_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 109,
              // y: 81,
              // font_array: ["cal_0.png","cal_1.png","cal_2.png","cal_3.png","cal_4.png","cal_5.png","cal_6.png","cal_7.png","cal_8.png","cal_9.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 1,
              // angle: 36,
              // invalid_image: 'cal_0.png',
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_calorie_TextRotate_ASCIIARRAY[0] = 'cal_0.png';  // set of images with numbers
            idle_calorie_TextRotate_ASCIIARRAY[1] = 'cal_1.png';  // set of images with numbers
            idle_calorie_TextRotate_ASCIIARRAY[2] = 'cal_2.png';  // set of images with numbers
            idle_calorie_TextRotate_ASCIIARRAY[3] = 'cal_3.png';  // set of images with numbers
            idle_calorie_TextRotate_ASCIIARRAY[4] = 'cal_4.png';  // set of images with numbers
            idle_calorie_TextRotate_ASCIIARRAY[5] = 'cal_5.png';  // set of images with numbers
            idle_calorie_TextRotate_ASCIIARRAY[6] = 'cal_6.png';  // set of images with numbers
            idle_calorie_TextRotate_ASCIIARRAY[7] = 'cal_7.png';  // set of images with numbers
            idle_calorie_TextRotate_ASCIIARRAY[8] = 'cal_8.png';  // set of images with numbers
            idle_calorie_TextRotate_ASCIIARRAY[9] = 'cal_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 4; i++) {
              idle_calorie_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 109,
                center_y: 81,
                pos_x: 109,
                pos_y: 81,
                angle: 36,
                src: 'cal_0.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_calorie_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            // idle_step_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 395,
              // y: 109,
              // font_array: ["Batt_AOD_0.png","Batt_AOD_1.png","Batt_AOD_2.png","Batt_AOD_3.png","Batt_AOD_4.png","Batt_AOD_5.png","Batt_AOD_6.png","Batt_AOD_7.png","Batt_AOD_8.png","Batt_AOD_9.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: -34,
              // invalid_image: 'Batt_0.png',
              // align_h: hmUI.align.RIGHT,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_step_TextRotate_ASCIIARRAY[0] = 'Batt_AOD_0.png';  // set of images with numbers
            idle_step_TextRotate_ASCIIARRAY[1] = 'Batt_AOD_1.png';  // set of images with numbers
            idle_step_TextRotate_ASCIIARRAY[2] = 'Batt_AOD_2.png';  // set of images with numbers
            idle_step_TextRotate_ASCIIARRAY[3] = 'Batt_AOD_3.png';  // set of images with numbers
            idle_step_TextRotate_ASCIIARRAY[4] = 'Batt_AOD_4.png';  // set of images with numbers
            idle_step_TextRotate_ASCIIARRAY[5] = 'Batt_AOD_5.png';  // set of images with numbers
            idle_step_TextRotate_ASCIIARRAY[6] = 'Batt_AOD_6.png';  // set of images with numbers
            idle_step_TextRotate_ASCIIARRAY[7] = 'Batt_AOD_7.png';  // set of images with numbers
            idle_step_TextRotate_ASCIIARRAY[8] = 'Batt_AOD_8.png';  // set of images with numbers
            idle_step_TextRotate_ASCIIARRAY[9] = 'Batt_AOD_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              idle_step_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 395,
                center_y: 109,
                pos_x: 395,
                pos_y: 109,
                angle: -34,
                src: 'Batt_AOD_0.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_step_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            idle_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 336,
              y: 123,
              image_array: ["step_progress_01.png","step_progress_02.png","step_progress_03.png","step_progress_04.png","step_progress_05.png","step_progress_06.png","step_progress_07.png"],
              image_length: 7,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_battery_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 83,
              // y: 108,
              // font_array: ["Batt_AOD_0.png","Batt_AOD_1.png","Batt_AOD_2.png","Batt_AOD_3.png","Batt_AOD_4.png","Batt_AOD_5.png","Batt_AOD_6.png","Batt_AOD_7.png","Batt_AOD_8.png","Batt_AOD_9.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: 35,
              // unit_en: 'Batt_AOD_unit.png',
              // invalid_image: 'Batt_AOD_0.png',
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_battery_TextRotate_ASCIIARRAY[0] = 'Batt_AOD_0.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[1] = 'Batt_AOD_1.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[2] = 'Batt_AOD_2.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[3] = 'Batt_AOD_3.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[4] = 'Batt_AOD_4.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[5] = 'Batt_AOD_5.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[6] = 'Batt_AOD_6.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[7] = 'Batt_AOD_7.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[8] = 'Batt_AOD_8.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[9] = 'Batt_AOD_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 3; i++) {
              idle_battery_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 83,
                center_y: 108,
                pos_x: 83,
                pos_y: 108,
                angle: 35,
                src: 'Batt_AOD_0.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_battery_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            idle_battery_TextRotate_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              center_x: 83,
              center_y: 108,
              pos_x: 83,
              pos_y: 108,
              angle: 35,
              src: 'Batt_AOD_unit.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            idle_battery_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 25,
              y: 123,
              image_array: ["batt_progress_01.png","batt_progress_02.png","batt_progress_03.png","batt_progress_04.png","batt_progress_05.png","batt_progress_06.png","batt_progress_07.png"],
              image_length: 7,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 153,
              y: 62,
              w: 173,
              h: 32,
              text_size: 25,
              char_space: 0,
              line_space: 0,
              color: 0xFF000000,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 193,
              y: 236,
              image_array: ["Weather_image_01.png","Weather_image_02.png","Weather_image_03.png","Weather_image_04.png","Weather_image_05.png","Weather_image_06.png","Weather_image_07.png","Weather_image_08.png","Weather_image_09.png","Weather_image_10.png","Weather_image_11.png","Weather_image_12.png","Weather_image_13.png","Weather_image_14.png","Weather_image_15.png","Weather_image_16.png","Weather_image_17.png","Weather_image_18.png","Weather_image_19.png","Weather_image_20.png","Weather_image_21.png","Weather_image_22.png","Weather_image_23.png","Weather_image_24.png","Weather_image_25.png","Weather_image_26.png","Weather_image_27.png","Weather_image_28.png","Weather_image_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 238,
              y: 244,
              font_array: ["Temp_0.png","Temp_1.png","Temp_2.png","Temp_3.png","Temp_4.png","Temp_5.png","Temp_6.png","Temp_7.png","Temp_8.png","Temp_9.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'Temp_Symbol_1.png',
              unit_tc: 'Temp_Symbol_1.png',
              unit_en: 'Temp_Symbol_1.png',
              imperial_unit_sc: 'Temp_Symbol_2.png',
              imperial_unit_tc: 'Temp_Symbol_2.png',
              imperial_unit_en: 'Temp_Symbol_2.png',
              negative_image: 'Temp_Symbol_3.png',
              invalid_image: 'Temp_Symbol_3.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            //start of ignored block
            if (temperatureUnit == 1) {
              idle_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
                x: 238,
                y: 244,
                font_array: ["Temp_0.png","Temp_1.png","Temp_2.png","Temp_3.png","Temp_4.png","Temp_5.png","Temp_6.png","Temp_7.png","Temp_8.png","Temp_9.png"],
                padding: false,
                h_space: 1,
                unit_sc: 'Temp_Symbol_2.png',
                unit_tc: 'Temp_Symbol_2.png',
                unit_en: 'Temp_Symbol_2.png',
                imperial_unit_sc: 'Temp_Symbol_1.png',
                imperial_unit_tc: 'Temp_Symbol_1.png',
                imperial_unit_en: 'Temp_Symbol_1.png',
                negative_image: 'Temp_Symbol_3.png',
                invalid_image: 'Temp_Symbol_3.png',
                align_h: hmUI.align.CENTER_H,
                type: hmUI.data_type.WEATHER_CURRENT,
                show_level: hmUI.show_level.ONLY_AOD,
              });
            };
            //end of ignored block

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 8,
              am_y: 270,
              am_sc_path: 'Clock_AM.png',
              am_en_path: 'Clock_AM.png',
              pm_x: 10,
              pm_y: 270,
              pm_sc_path: 'Clock_PM.png',
              pm_en_path: 'Clock_PM.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_second = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              second_startX: 438,
              second_startY: 266,
              second_array: ["Time_S_0.png","Time_S_1.png","Time_S_2.png","Time_S_3.png","Time_S_4.png","Time_S_5.png","Time_S_6.png","Time_S_7.png","Time_S_8.png","Time_S_9.png"],
              second_zero: 1,
              second_space: 1,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 306,
              minute_startY: 266,
              minute_array: ["Time_0.png","Time_1.png","Time_2.png","Time_3.png","Time_4.png","Time_5.png","Time_6.png","Time_7.png","Time_8.png","Time_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 53,
              hour_startY: 266,
              hour_array: ["Time_0.png","Time_1.png","Time_2.png","Time_3.png","Time_4.png","Time_5.png","Time_6.png","Time_7.png","Time_8.png","Time_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 400,
              y: 96,
              w: 100,
              h: 50,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 183,
              y: 417,
              w: 41,
              h: 28,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 182,
              y: 330,
              w: 44,
              h: 36,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 8,
              y: 226,
              w: 88,
              h: 35,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 15,
              y: 294,
              w: 37,
              h: 42,
              type: hmUI.data_type.MOON_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 194,
              y: 238,
              w: 91,
              h: 37,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 180,
              y: 371,
              w: 45,
              h: 38,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 428,
              y: 263,
              w: 46,
              h: 44,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 341,
              y: 294,
              w: 59,
              h: 74,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 171,
              y: 7,
              w: 48,
              h: 38,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 40,
              y: 97,
              w: 55,
              h: 52,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PowerSaveHintScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 206,
              y: 140,
              w: 73,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 11,
              y: 165,
              w: 66,
              h: 55,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'CompassScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 170,
              y: 450,
              w: 130,
              h: 30,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                //change color sytle
click_Color()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            let screenType = hmSetting.getScreenType();
            //start of ignored block
            function text_update() {
              console.log('text_update()');

              console.log('update text rotate DISTANCE');
              let distanceCurrent = distance.current;
              let normal_distance_rotate_string = (distanceCurrent / 1000).toFixed(2);

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  normal_distance_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_distance_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
                if (distanceCurrent != null && distanceCurrent != undefined && isFinite(distanceCurrent) && normal_distance_rotate_string.length > 0 && normal_distance_rotate_string.length <= 5) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = RIGHT
                  let normal_distance_TextRotate_posOffset = normal_distance_TextRotate_img_width * normal_distance_rotate_string.length;
                  normal_distance_TextRotate_posOffset = normal_distance_TextRotate_posOffset - normal_distance_TextRotate_img_width + normal_distance_TextRotate_dot_width;
                  img_offset -= normal_distance_TextRotate_posOffset;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_distance_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_distance_TextRotate[index].setProperty(hmUI.prop.POS_X, 350 + img_offset);
                      normal_distance_TextRotate[index].setProperty(hmUI.prop.SRC, normal_distance_TextRotate_ASCIIARRAY[charCode]);
                      normal_distance_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_distance_TextRotate_img_width;
                      index++;
                    }  // end if digit
                    else { 
                      normal_distance_TextRotate[index].setProperty(hmUI.prop.POS_X, 350 + img_offset);
                      normal_distance_TextRotate[index].setProperty(hmUI.prop.SRC, 'dis_dot.png');
                      normal_distance_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_distance_TextRotate_dot_width;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                  normal_distance_TextRotate_unit.setProperty(hmUI.prop.POS_X, 350 + img_offset);
                  normal_distance_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite
                else {
                  normal_distance_TextRotate[0].setProperty(hmUI.prop.POS_X, 350 - normal_distance_TextRotate_error_img_width / 2);
                  normal_distance_TextRotate[0].setProperty(hmUI.prop.SRC, 'cal_0.png');
                  normal_distance_TextRotate[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

              console.log('update text rotate calorie_CALORIE');
              let valueCalories = calorie.current;
              let normal_calorie_rotate_string = parseInt(valueCalories).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 4; i++) {  // hide all symbols
                  normal_calorie_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueCalories != null && valueCalories != undefined && isFinite(valueCalories) && normal_calorie_rotate_string.length > 0 && normal_calorie_rotate_string.length <= 4) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of normal_calorie_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 4) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_calorie_TextRotate[index].setProperty(hmUI.prop.POS_X, 109 + img_offset);
                      normal_calorie_TextRotate[index].setProperty(hmUI.prop.SRC, normal_calorie_TextRotate_ASCIIARRAY[charCode]);
                      normal_calorie_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_calorie_TextRotate_img_width + 1;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite
                else {
                  normal_calorie_TextRotate[0].setProperty(hmUI.prop.POS_X, 109);
                  normal_calorie_TextRotate[0].setProperty(hmUI.prop.SRC, 'cal_0.png');
                  normal_calorie_TextRotate[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

              console.log('update text rotate step_STEP');
              let valueStep = step.current;
              let normal_step_rotate_string = parseInt(valueStep).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  normal_step_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueStep != null && valueStep != undefined && isFinite(valueStep) && normal_step_rotate_string.length > 0 && normal_step_rotate_string.length <= 5) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = RIGHT
                  let normal_step_TextRotate_posOffset = normal_step_TextRotate_img_width * normal_step_rotate_string.length;
                  img_offset -= normal_step_TextRotate_posOffset;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_step_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_step_TextRotate[index].setProperty(hmUI.prop.POS_X, 395 + img_offset);
                      normal_step_TextRotate[index].setProperty(hmUI.prop.SRC, normal_step_TextRotate_ASCIIARRAY[charCode]);
                      normal_step_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_step_TextRotate_img_width;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite
                else {
                  normal_step_TextRotate[0].setProperty(hmUI.prop.POS_X, 395 - normal_step_TextRotate_error_img_width / 2);
                  normal_step_TextRotate[0].setProperty(hmUI.prop.SRC, 'Batt_0.png');
                  normal_step_TextRotate[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

              console.log('update text rotate battery_BATTERY');
              let valueBattery = battery.current;
              let normal_battery_rotate_string = parseInt(valueBattery).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  normal_battery_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_battery_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
                if (valueBattery != null && valueBattery != undefined && isFinite(valueBattery) && normal_battery_rotate_string.length > 0 && normal_battery_rotate_string.length <= 3) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of normal_battery_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_battery_TextRotate[index].setProperty(hmUI.prop.POS_X, 83 + img_offset);
                      normal_battery_TextRotate[index].setProperty(hmUI.prop.SRC, normal_battery_TextRotate_ASCIIARRAY[charCode]);
                      normal_battery_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_battery_TextRotate_img_width;
                      index++;
                    };  // end if digit
                  };  // end char of string
                  normal_battery_TextRotate_unit.setProperty(hmUI.prop.POS_X, 83 + img_offset);
                  normal_battery_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite
                else {
                  normal_battery_TextRotate[0].setProperty(hmUI.prop.POS_X, 83);
                  normal_battery_TextRotate[0].setProperty(hmUI.prop.SRC, 'Batt_0.png');
                  normal_battery_TextRotate[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

              console.log('update text rotate DISTANCE');
              let idle_distance_rotate_string = (distanceCurrent / 1000).toFixed(2);

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  idle_distance_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                idle_distance_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
                if (distanceCurrent != null && distanceCurrent != undefined && isFinite(distanceCurrent) && idle_distance_rotate_string.length > 0 && idle_distance_rotate_string.length <= 5) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = RIGHT
                  let idle_distance_TextRotate_posOffset = idle_distance_TextRotate_img_width * idle_distance_rotate_string.length;
                  idle_distance_TextRotate_posOffset = idle_distance_TextRotate_posOffset - idle_distance_TextRotate_img_width + idle_distance_TextRotate_dot_width;
                  img_offset -= idle_distance_TextRotate_posOffset;
                  // alignment end
                  
                  let index = 0;
                  for (let char of idle_distance_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_distance_TextRotate[index].setProperty(hmUI.prop.POS_X, 350 + img_offset);
                      idle_distance_TextRotate[index].setProperty(hmUI.prop.SRC, idle_distance_TextRotate_ASCIIARRAY[charCode]);
                      idle_distance_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_distance_TextRotate_img_width;
                      index++;
                    }  // end if digit
                    else { 
                      idle_distance_TextRotate[index].setProperty(hmUI.prop.POS_X, 350 + img_offset);
                      idle_distance_TextRotate[index].setProperty(hmUI.prop.SRC, 'dis_dot.png');
                      idle_distance_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_distance_TextRotate_dot_width;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                  idle_distance_TextRotate_unit.setProperty(hmUI.prop.POS_X, 350 + img_offset);
                  idle_distance_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite
                else {
                  idle_distance_TextRotate[0].setProperty(hmUI.prop.POS_X, 350 - idle_distance_TextRotate_error_img_width / 2);
                  idle_distance_TextRotate[0].setProperty(hmUI.prop.SRC, 'cal_0.png');
                  idle_distance_TextRotate[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

              console.log('update text rotate calorie_CALORIE');
              let idle_calorie_rotate_string = parseInt(valueCalories).toString();

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 4; i++) {  // hide all symbols
                  idle_calorie_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueCalories != null && valueCalories != undefined && isFinite(valueCalories) && idle_calorie_rotate_string.length > 0 && idle_calorie_rotate_string.length <= 4) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of idle_calorie_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 4) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_calorie_TextRotate[index].setProperty(hmUI.prop.POS_X, 109 + img_offset);
                      idle_calorie_TextRotate[index].setProperty(hmUI.prop.SRC, idle_calorie_TextRotate_ASCIIARRAY[charCode]);
                      idle_calorie_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_calorie_TextRotate_img_width + 1;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite
                else {
                  idle_calorie_TextRotate[0].setProperty(hmUI.prop.POS_X, 109);
                  idle_calorie_TextRotate[0].setProperty(hmUI.prop.SRC, 'cal_0.png');
                  idle_calorie_TextRotate[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

              console.log('update text rotate step_STEP');
              let idle_step_rotate_string = parseInt(valueStep).toString();

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  idle_step_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueStep != null && valueStep != undefined && isFinite(valueStep) && idle_step_rotate_string.length > 0 && idle_step_rotate_string.length <= 5) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = RIGHT
                  let idle_step_TextRotate_posOffset = idle_step_TextRotate_img_width * idle_step_rotate_string.length;
                  img_offset -= idle_step_TextRotate_posOffset;
                  // alignment end
                  
                  let index = 0;
                  for (let char of idle_step_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_step_TextRotate[index].setProperty(hmUI.prop.POS_X, 395 + img_offset);
                      idle_step_TextRotate[index].setProperty(hmUI.prop.SRC, idle_step_TextRotate_ASCIIARRAY[charCode]);
                      idle_step_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_step_TextRotate_img_width;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite
                else {
                  idle_step_TextRotate[0].setProperty(hmUI.prop.POS_X, 395 - idle_step_TextRotate_error_img_width / 2);
                  idle_step_TextRotate[0].setProperty(hmUI.prop.SRC, 'Batt_0.png');
                  idle_step_TextRotate[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

              console.log('update text rotate battery_BATTERY');
              let idle_battery_rotate_string = parseInt(valueBattery).toString();

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  idle_battery_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                idle_battery_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
                if (valueBattery != null && valueBattery != undefined && isFinite(valueBattery) && idle_battery_rotate_string.length > 0 && idle_battery_rotate_string.length <= 3) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of idle_battery_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_battery_TextRotate[index].setProperty(hmUI.prop.POS_X, 83 + img_offset);
                      idle_battery_TextRotate[index].setProperty(hmUI.prop.SRC, idle_battery_TextRotate_ASCIIARRAY[charCode]);
                      idle_battery_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_battery_TextRotate_img_width;
                      index++;
                    };  // end if digit
                  };  // end char of string
                  idle_battery_TextRotate_unit.setProperty(hmUI.prop.POS_X, 83 + img_offset);
                  idle_battery_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite
                else {
                  idle_battery_TextRotate[0].setProperty(hmUI.prop.POS_X, 83);
                  idle_battery_TextRotate[0].setProperty(hmUI.prop.SRC, 'Batt_AOD_0.png');
                  idle_battery_TextRotate[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

            };

            //end of ignored block
            //start of ignored block
            console.log('compass_update()');
            if (screenType == hmSetting.screen_type.WATCHFACE){
              compass = hmSensor.createSensor(hmSensor.id.COMPASS);
              compass.start();

              if (compass.direction_angle && compass.direction  && compass.direction_angle != 'INVALID') { // initial data
                // Compass Pointer
                let compass_direction_angle = parseInt(compass.direction_angle);
                normal_compass_direction_pointer_img.setProperty(hmUI.prop.ANGLE, -compass_direction_angle);
                // Compass Images
                let compass_direction_angle_img = compass_direction_angle + 45 / 2;
                let compass_direction_index = parseInt(compass_direction_angle_img/45);
                if (compass_direction_index > 7) compass_direction_index = 0;
                normal_compass_direction_img_level.setProperty(hmUI.prop.SRC, normal_compass_direction_arr[compass_direction_index]);

              } else { // error data
                normal_compass_direction_pointer_img.setProperty(hmUI.prop.ANGLE, 0);
                normal_compass_direction_img_level.setProperty(hmUI.prop.SRC, normal_compass_direction_arr[0]);

              }

              compass.addEventListener(hmSensor.event.CHANGE, function (compass_res) { // change values when changing direction

                if (compass_res.calibration_status) {
                  // Compass Pointer
                  let compass_direction_angle = parseInt(compass_res.direction_angle);
                  normal_compass_direction_pointer_img.setProperty(hmUI.prop.ANGLE, -compass_direction_angle);
                  // Compass Images
                  let compass_direction_angle_img = compass_direction_angle + 45 / 2;
                  let compass_direction_index = parseInt(compass_direction_angle_img/45);
                  if (compass_direction_index > 7) compass_direction_index = 0;
                  normal_compass_direction_img_level.setProperty(hmUI.prop.SRC, normal_compass_direction_arr[compass_direction_index]);

                } else { // error data
                  normal_compass_direction_pointer_img.setProperty(hmUI.prop.ANGLE, 0);
                  normal_compass_direction_img_level.setProperty(hmUI.prop.SRC, normal_compass_direction_arr[0]);

                }

              }); // Listener end

            };
            //end of ignored block

            function scale_call() {
              console.log('scale_call()');

              console.log('Weather city name');
              let weatherData = weatherSensor.getForecastWeather();
              normal_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

              console.log('Weather city name');
              idle_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                text_update();

                let nawAnimationTime = now.utc;;
                
                let delay_anim_rotate_1 = 0;
                let repeat_anim_rotate_1 = 100000;
                delay_anim_rotate_1 = repeat_anim_rotate_1 - (nawAnimationTime - normal_rotate_animation_lastTime_1);
                if(delay_anim_rotate_1 < 0) delay_anim_rotate_1 = 0; 
                if((nawAnimationTime - normal_rotate_animation_lastTime_1) > repeat_anim_rotate_1) {
                  normal_rotate_animation_count_1 = 0;
                  timer_anim_rotate_1_mirror = false;
                };

                if (!timer_anim_rotate_1) {
                  timer_anim_rotate_1 = timer.createTimer(delay_anim_rotate_1, repeat_anim_rotate_1, (function (option) {
                    anim_rotate_1_complete_call()
                  })); // end timer create
                };
                if (compass && screenType == hmSetting.screen_type.WATCHFACE) compass.start();

                console.log('resume_call.js');
                // start resume_call.js

 check24h()
                // end resume_call.js

              }),
              pause_call: (function () {
                console.log('pause_call()');
                stop_anim_rotate_1();
                if (compass) compass.stop();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
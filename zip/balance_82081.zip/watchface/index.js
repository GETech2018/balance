﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js



        // ON/OFF Analog hands
        let elementnumber_1 = 1
        let total_elemente = 2

        function click_elemente() {
            if(elementnumber_1==total_elemente) {
            elementnumber_1=1;
                UpdateElementeOne();
                }
            else {
                elementnumber_1=elementnumber_1+1;
                if(elementnumber_1==2) {
                  UpdateElementeTwo();
                }

            }
            if(elementnumber_1==1) hmUI.showToast({text: 'Hand clock ON'});
            if(elementnumber_1==2) hmUI.showToast({text: 'Hand clock OFF'});
        }

        //Hand clock on
        function UpdateElementeOne(){
        normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.VISIBLE, true);

        }

        //hand clock off
        function UpdateElementeTwo(){
        normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.VISIBLE, false);
        }



///////////////

function pop_menu_ON(){
        normal_stopwatch_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_countdown_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_alarm_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_sunrise_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_temperature_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_pai_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_spo2_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_heart_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_step_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        Button_1.setProperty(hmUI.prop.VISIBLE, false);
        Button_2.setProperty(hmUI.prop.VISIBLE, false);
        Button_3.setProperty(hmUI.prop.VISIBLE, false);
        Button_4.setProperty(hmUI.prop.VISIBLE, false);
        Button_5.setProperty(hmUI.prop.VISIBLE, false);

        Button_6.setProperty(hmUI.prop.VISIBLE, true);
        Button_7.setProperty(hmUI.prop.VISIBLE, true);
        Button_8.setProperty(hmUI.prop.VISIBLE, true);
        Button_9.setProperty(hmUI.prop.VISIBLE, true);
        Button_10.setProperty(hmUI.prop.VISIBLE, true);
        Button_11.setProperty(hmUI.prop.VISIBLE, true);

      
      normal_image_img.setProperty(hmUI.prop.VISIBLE, true);

}

function pop_menu_OFF(){
setTimeout(function(){
        normal_stopwatch_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
        normal_countdown_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
        normal_alarm_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
        normal_sunrise_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
        normal_temperature_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
        normal_pai_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
        normal_spo2_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
        normal_heart_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
        normal_step_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
        Button_1.setProperty(hmUI.prop.VISIBLE, true);
        Button_2.setProperty(hmUI.prop.VISIBLE, true);
        Button_3.setProperty(hmUI.prop.VISIBLE, true);
        Button_4.setProperty(hmUI.prop.VISIBLE, true);
        Button_5.setProperty(hmUI.prop.VISIBLE, true);

        Button_6.setProperty(hmUI.prop.VISIBLE, false);
        Button_7.setProperty(hmUI.prop.VISIBLE, false);
        Button_8.setProperty(hmUI.prop.VISIBLE, false);
        Button_9.setProperty(hmUI.prop.VISIBLE, false);
        Button_10.setProperty(hmUI.prop.VISIBLE, false);
        Button_11.setProperty(hmUI.prop.VISIBLE, false);
      
      normal_image_img.setProperty(hmUI.prop.VISIBLE, false);
      }, 1234);  
}

////////////////////////
      // Start color change
         let colornumber = 1
        let namecolor = ''

        function click_Color() {
       
if ( colornumber == 1) { namecolor = "RED"}
if ( colornumber == 2) { namecolor = "YELLOW"}
if ( colornumber == 3) { namecolor = "GREEN"}
if ( colornumber == 4) { namecolor = "ORANGE"}
if ( colornumber == 5) { namecolor = "BLUE"}
if ( colornumber == 6) { namecolor = "WHITE"}
hmUI.showToast({text: namecolor});

             //hmUI.showToast({text: "color " + parseInt(colornumber) });
             normal_background_bg_img.setProperty(hmUI.prop.SRC, "main" + parseInt(colornumber) + ".png");
                                       
        }
///////////

        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_group_ForecastWeather = ''
        let normal_forecast_date_week_font = new Array(5);
        let normal_forecast_date_week_font_Array = ['Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa', 'Su'];
        let normal_forecast_high_low_text_font = new Array(5);
        let normal_forecast_image_progress_img_level = new Array(5);
        let normal_forecast_image_array = ['Weather_small_01.png', 'Weather_small_02.png', 'Weather_small_03.png', 'Weather_small_04.png', 'Weather_small_05.png', 'Weather_small_06.png', 'Weather_small_07.png', 'Weather_small_08.png', 'Weather_small_09.png', 'Weather_small_10.png', 'Weather_small_11.png', 'Weather_small_12.png', 'Weather_small_13.png', 'Weather_small_14.png', 'Weather_small_15.png', 'Weather_small_16.png', 'Weather_small_17.png', 'Weather_small_18.png', 'Weather_small_19.png', 'Weather_small_20.png', 'Weather_small_21.png', 'Weather_small_22.png', 'Weather_small_23.png', 'Weather_small_24.png', 'Weather_small_25.png', 'Weather_small_26.png', 'Weather_small_27.png', 'Weather_small_28.png', 'Weather_small_29.png'];
        let normal_city_name_text = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_sun_low_text_img = ''
        let normal_sun_low_separator_img = ''
        let normal_sun_high_text_img = ''
        let normal_sun_high_separator_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_distance_icon_img = ''
        let normal_distance_TextRotate = new Array(5);
        let normal_distance_TextRotate_ASCIIARRAY = new Array(10);
        let normal_distance_TextRotate_img_width = 14;
        let normal_distance_TextRotate_unit = null;
        let normal_distance_TextRotate_unit_width = 1;
        let normal_distance_TextRotate_dot_width = 6;
        let normal_distance_TextRotate_error_img_width = 1;
        let normal_distance_text_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_step_icon_img = ''
        let normal_step_current_text_img = ''
        let normal_heart_rate_linear_scale = ''
        let normal_heart_rate_TextRotate = new Array(3);
        let normal_heart_rate_TextRotate_ASCIIARRAY = new Array(10);
        let normal_heart_rate_TextRotate_img_width = 21;
        let normal_heart_rate_image_progress_img_level = ''
        let normal_battery_linear_scale = ''
        let normal_battery_TextRotate = new Array(3);
        let normal_battery_TextRotate_ASCIIARRAY = new Array(10);
        let normal_battery_TextRotate_img_width = 21;
        let normal_battery_TextRotate_unit = null;
        let normal_battery_TextRotate_unit_width = 17;
        let normal_battery_TextRotate_error_img_width = 21;
        let normal_battery_image_progress_img_level = ''
        let normal_battery_icon_img = ''
        let normal_digital_clock_img_time_second = ''
        let normal_digital_clock_second_separator_img = ''
        let normal_digital_clock_img_time_minute = ''
        let normal_digital_clock_minute_separator_img = ''
        let normal_digital_clock_img_time_hour = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_analog_clock_pro_hour_pointer_img = ''
        let normal_analog_clock_pro_minute_pointer_img = ''
        let normal_timerUpdateSec = undefined;
        let normal_analog_clock_pro_second_pointer_img = ''
        let normal_timerUpdateSecSmooth = undefined;
        let lastTime = 0;
        let normal_image_img = ''
        let idle_background_bg_img = ''
        let idle_group_ForecastWeather = ''
        let idle_forecast_date_week_font = new Array(5);
        let idle_forecast_date_week_font_Array = ['Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa', 'Su'];
        let idle_forecast_high_low_text_font = new Array(5);
        let idle_forecast_image_progress_img_level = new Array(5);
        let idle_forecast_image_array = ['Weather_small_01.png', 'Weather_small_02.png', 'Weather_small_03.png', 'Weather_small_04.png', 'Weather_small_05.png', 'Weather_small_06.png', 'Weather_small_07.png', 'Weather_small_08.png', 'Weather_small_09.png', 'Weather_small_10.png', 'Weather_small_11.png', 'Weather_small_12.png', 'Weather_small_13.png', 'Weather_small_14.png', 'Weather_small_15.png', 'Weather_small_16.png', 'Weather_small_17.png', 'Weather_small_18.png', 'Weather_small_19.png', 'Weather_small_20.png', 'Weather_small_21.png', 'Weather_small_22.png', 'Weather_small_23.png', 'Weather_small_24.png', 'Weather_small_25.png', 'Weather_small_26.png', 'Weather_small_27.png', 'Weather_small_28.png', 'Weather_small_29.png'];
        let idle_city_name_text = ''
        let idle_weather_image_progress_img_level = ''
        let idle_temperature_current_text_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_moon_image_progress_img_level = ''
        let idle_sun_low_text_img = ''
        let idle_sun_low_separator_img = ''
        let idle_sun_high_text_img = ''
        let idle_sun_high_separator_img = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_day = ''
        let idle_distance_icon_img = ''
        let idle_distance_TextRotate = new Array(5);
        let idle_distance_TextRotate_ASCIIARRAY = new Array(10);
        let idle_distance_TextRotate_img_width = 14;
        let idle_distance_TextRotate_unit = null;
        let idle_distance_TextRotate_unit_width = 1;
        let idle_distance_TextRotate_dot_width = 6;
        let idle_distance_TextRotate_error_img_width = 1;
        let idle_distance_text_text_img = ''
        let idle_calorie_current_text_img = ''
        let idle_step_icon_img = ''
        let idle_step_current_text_img = ''
        let idle_heart_rate_linear_scale = ''
        let idle_heart_rate_TextRotate = new Array(3);
        let idle_heart_rate_TextRotate_ASCIIARRAY = new Array(10);
        let idle_heart_rate_TextRotate_img_width = 21;
        let idle_heart_rate_image_progress_img_level = ''
        let idle_battery_linear_scale = ''
        let idle_battery_TextRotate = new Array(3);
        let idle_battery_TextRotate_ASCIIARRAY = new Array(10);
        let idle_battery_TextRotate_img_width = 21;
        let idle_battery_TextRotate_unit = null;
        let idle_battery_TextRotate_unit_width = 17;
        let idle_battery_TextRotate_error_img_width = 21;
        let idle_battery_image_progress_img_level = ''
        let idle_battery_icon_img = ''
        let idle_digital_clock_img_time_second = ''
        let idle_digital_clock_second_separator_img = ''
        let idle_digital_clock_img_time_minute = ''
        let idle_digital_clock_minute_separator_img = ''
        let idle_digital_clock_img_time_hour = ''
        let idle_digital_clock_hour_separator_img = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_image_img = ''
        let idle_analog_clock_pro_hour_pointer_img = ''
        let idle_analog_clock_pro_minute_pointer_img = ''
        let idle_timerUpdateSec = undefined;
        let idle_analog_clock_pro_second_pointer_img = ''
        let idle_timerUpdateSecSmooth = undefined;
        let normal_stopwatch_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let Button_7 = ''
        let Button_8 = ''
        let Button_9 = ''
        let Button_10 = ''
        let Button_11 = ''
        let timeSensor = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'main1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();            
            // normal_Weather_FewDays = hmUI.createWidget(hmUI.widget.FewDays, {
              // x: 0,
              // y: 0,
              // ColumnWidth: 38,
              // DaysCount: 5,
            // });
            
            normal_group_ForecastWeather = hmUI.createWidget(hmUI.widget.GROUP, {
              x: 0,
              y: 0,
              h: 0,
              w: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_forecast_date_week_font = normal_group_ForecastWeather.createWidget(hmUI.widget.TEXT_Options, {
              // x: 151,
              // y: 217,
              // w: 189,
              // h: 25,
              // text_size: 20,
              // char_space: 0,
              // line_space: 0,
              // color: 0xFFD8D8D8,
              // color_2: 0xFFFF0000,
              // use_color_2: False,
              // align_h: hmUI.align.LEFT,
              // align_v: hmUI.align.TOP,
              // text_style: hmUI.text_style.ELLIPSIS,
              // type: hmUI.data_type.forecast_date_week_img,
              // unit_string: Mo, Tu, We, Th, Fr, Sa, Su,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            //start of ignored block
            if (screenType == hmSetting.screen_type.WATCHFACE) {
              for (let i = 0; i < 5; i++) {
                normal_forecast_date_week_font[i] = normal_group_ForecastWeather.createWidget(hmUI.widget.TEXT, {
                  x: 151 + i*38,
                  y: 217,
                  w: 189,
                  h: 25,
                  text_size: 20,
                  char_space: 0,
                  line_space: 0,
                  color: 0xFFD8D8D8,
                  // color_2: 0xFFFF0000,
                  align_h: hmUI.align.LEFT,
                  align_v: hmUI.align.TOP,
                  text_style: hmUI.text_style.ELLIPSIS,
                  // unit_string: Mo, Tu, We, Th, Fr, Sa, Su,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
              };
            };
            //end of ignored block

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            // normal_forecast_high_low_text_font = normal_group_ForecastWeather.createWidget(hmUI.widget.TEXT_Options, {
              // x: 88,
              // y: 273,
              // w: 150,
              // h: 30,
              // text_size: 10,
              // char_space: 0,
              // line_space: 0,
              // color: 0xFFFFFFFF,
              // color_2: 0xFFFF0000,
              // use_color_2: False,
              // align_h: hmUI.align.CENTER_H,
              // align_v: hmUI.align.CENTER_V,
              // text_style: hmUI.text_style.ELLIPSIS,
              // type: hmUI.data_type.forecast_high_low_text_font,
              // unit_type: 1,
              // unit_string: /,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            //start of ignored block
            if (screenType == hmSetting.screen_type.WATCHFACE) {
              for (let i = 0; i < 5; i++) {
                normal_forecast_high_low_text_font[i] = normal_group_ForecastWeather.createWidget(hmUI.widget.TEXT, {
                  x: 88 + i*38,
                  y: 273,
                  w: 150,
                  h: 30,
                  text_size: 10,
                  char_space: 0,
                  line_space: 0,
                  color: 0xFFFFFFFF,
                  align_h: hmUI.align.CENTER_H,
                  align_v: hmUI.align.CENTER_V,
                  text_style: hmUI.text_style.ELLIPSIS,
                  // unit_type: 1,
                  // unit_string: /,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
              };
            };
            //end of ignored block

            // normal_forecast_image_progress_img_level = normal_group_ForecastWeather.createWidget(hmUI.widget.IMG_LEVEL_Options, {
              // x: 145,
              // y: 244,
              // image_array: ["Weather_small_01.png","Weather_small_02.png","Weather_small_03.png","Weather_small_04.png","Weather_small_05.png","Weather_small_06.png","Weather_small_07.png","Weather_small_08.png","Weather_small_09.png","Weather_small_10.png","Weather_small_11.png","Weather_small_12.png","Weather_small_13.png","Weather_small_14.png","Weather_small_15.png","Weather_small_16.png","Weather_small_17.png","Weather_small_18.png","Weather_small_19.png","Weather_small_20.png","Weather_small_21.png","Weather_small_22.png","Weather_small_23.png","Weather_small_24.png","Weather_small_25.png","Weather_small_26.png","Weather_small_27.png","Weather_small_28.png","Weather_small_29.png"],
              // image_length: 29,
              // type: hmUI.data_type.forecast_image,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            //start of ignored block
            if (screenType == hmSetting.screen_type.WATCHFACE) {
              for (let i = 0; i < 5; i++) {
                normal_forecast_image_progress_img_level[i] = normal_group_ForecastWeather.createWidget(hmUI.widget.IMG, {
                  x: 145 + i*38,
                  y: 244,
                  src: normal_forecast_image_array[25],
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
              };
            };
            //end of ignored block
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 202,
              y: 158,
              w: 79,
              h: 26,
              text_size: 16,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 299,
              y: 178,
              image_array: ["Weather_small_01.png","Weather_small_02.png","Weather_small_03.png","Weather_small_04.png","Weather_small_05.png","Weather_small_06.png","Weather_small_07.png","Weather_small_08.png","Weather_small_09.png","Weather_small_10.png","Weather_small_11.png","Weather_small_12.png","Weather_small_13.png","Weather_small_14.png","Weather_small_15.png","Weather_small_16.png","Weather_small_17.png","Weather_small_18.png","Weather_small_19.png","Weather_small_20.png","Weather_small_21.png","Weather_small_22.png","Weather_small_23.png","Weather_small_24.png","Weather_small_25.png","Weather_small_26.png","Weather_small_27.png","Weather_small_28.png","Weather_small_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 144,
              y: 190,
              font_array: ["Act_mid_0.png","Act_mid_1.png","Act_mid_2.png","Act_mid_3.png","Act_mid_4.png","Act_mid_5.png","Act_mid_6.png","Act_mid_7.png","Act_mid_8.png","Act_mid_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Weather_symbol4.png',
              unit_tc: 'Weather_symbol4.png',
              unit_en: 'Weather_symbol4.png',
              imperial_unit_sc: 'Weather_symbol4.png',
              imperial_unit_tc: 'Weather_symbol4.png',
              imperial_unit_en: 'Weather_symbol4.png',
              negative_image: 'Weather_Symbol3.png',
              invalid_image: 'Weather_Symbol3.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const temperatureUnit = hmSetting.getTemperatureUnit();
            //start of ignored block
            if (temperatureUnit == 1) {
              normal_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
                x: 144,
                y: 190,
                font_array: ["Act_mid_0.png","Act_mid_1.png","Act_mid_2.png","Act_mid_3.png","Act_mid_4.png","Act_mid_5.png","Act_mid_6.png","Act_mid_7.png","Act_mid_8.png","Act_mid_9.png"],
                padding: false,
                h_space: 0,
                unit_sc: 'Weather_symbol4.png',
                unit_tc: 'Weather_symbol4.png',
                unit_en: 'Weather_symbol4.png',
                imperial_unit_sc: 'Weather_symbol4.png',
                imperial_unit_tc: 'Weather_symbol4.png',
                imperial_unit_en: 'Weather_symbol4.png',
                negative_image: 'Weather_Symbol3.png',
                invalid_image: 'Weather_Symbol3.png',
                align_h: hmUI.align.CENTER_H,
                type: hmUI.data_type.WEATHER_CURRENT,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
            };
            //end of ignored block

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 311,
              y: 54,
              src: 'System_BT_OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 378,
              y: 351,
              src: 'System_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 54,
              y: 266,
              image_array: ["moon_01.png","moon_02.png","moon_03.png","moon_04.png","moon_05.png","moon_06.png","moon_07.png","moon_08.png","moon_09.png","moon_10.png","moon_11.png","moon_12.png","moon_13.png","moon_14.png","moon_15.png","moon_16.png","moon_17.png","moon_18.png","moon_19.png","moon_20.png","moon_21.png","moon_22.png","moon_23.png","moon_24.png","moon_25.png","moon_26.png","moon_27.png","moon_28.png","moon_29.png","moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 206,
              y: 55,
              font_array: ["Act_mid_0.png","Act_mid_1.png","Act_mid_2.png","Act_mid_3.png","Act_mid_4.png","Act_mid_5.png","Act_mid_6.png","Act_mid_7.png","Act_mid_8.png","Act_mid_9.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'SS.png',
              unit_tc: 'SS.png',
              unit_en: 'SS.png',
              dot_image: 'SunRiseSet_Dot.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 176,
              y: 55,
              src: 'SS.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 208,
              y: 409,
              font_array: ["Act_mid_0.png","Act_mid_1.png","Act_mid_2.png","Act_mid_3.png","Act_mid_4.png","Act_mid_5.png","Act_mid_6.png","Act_mid_7.png","Act_mid_8.png","Act_mid_9.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'SR.png',
              unit_tc: 'SR.png',
              unit_en: 'SR.png',
              dot_image: 'SunRiseSet_Dot.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 178,
              y: 408,
              src: 'SR.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 271,
              month_startY: 95,
              month_sc_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_tc_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_en_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 129,
              y: 95,
              week_en: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              week_tc: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              week_sc: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 218,
              day_startY: 93,
              day_sc_array: ["Act_0.png","Act_1.png","Act_2.png","Act_3.png","Act_4.png","Act_5.png","Act_6.png","Act_7.png","Act_8.png","Act_9.png"],
              day_tc_array: ["Act_0.png","Act_1.png","Act_2.png","Act_3.png","Act_4.png","Act_5.png","Act_6.png","Act_7.png","Act_8.png","Act_9.png"],
              day_en_array: ["Act_0.png","Act_1.png","Act_2.png","Act_3.png","Act_4.png","Act_5.png","Act_6.png","Act_7.png","Act_8.png","Act_9.png"],
              day_zero: 0,
              day_space: 1,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 251,
              y: 315,
              src: 'line.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_distance_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 334,
              // y: 315,
              // font_array: ["Act_mid_0.png","Act_mid_1.png","Act_mid_2.png","Act_mid_3.png","Act_mid_4.png","Act_mid_5.png","Act_mid_6.png","Act_mid_7.png","Act_mid_8.png","Act_mid_9.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: 0,
              // unit_en: 'E0.png',
              // imperial_unit_en: 'E0.png',
              // negative_image: 'Dis_dot.png',
              // invalid_image: 'E0.png',
              // dot_image: 'Dis_dot.png',
              // align_h: hmUI.align.RIGHT,
              // type: hmUI.data_type.DISTANCE,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_distance_TextRotate_ASCIIARRAY[0] = 'Act_mid_0.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[1] = 'Act_mid_1.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[2] = 'Act_mid_2.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[3] = 'Act_mid_3.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[4] = 'Act_mid_4.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[5] = 'Act_mid_5.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[6] = 'Act_mid_6.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[7] = 'Act_mid_7.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[8] = 'Act_mid_8.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[9] = 'Act_mid_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              normal_distance_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 334,
                center_y: 315,
                pos_x: 334,
                pos_y: 315,
                angle: 0,
                src: 'Act_mid_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_distance_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_distance_TextRotate_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              center_x: 334,
              center_y: 315,
              pos_x: 334,
              pos_y: 315,
              angle: 0,
              src: 'E0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_distance_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);

            const mileageUnit = hmSetting.getMileageUnit();
            if (mileageUnit == 1) {
              normal_distance_TextRotate_unit.setProperty(hmUI.prop.SRC, 'E0.png');
            };
            //end of ignored block
            
            const distance = hmSensor.createSensor(hmSensor.id.DISTANCE);
            distance.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });
            
            function toDegree (radian) {
              return radian * (180 / Math.PI);
            };

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 357,
              y: 320,
              font_array: ["E0.png","E1.png","E2.png","E3.png","E4.png","E5.png","E6.png","E7.png","E8.png","E9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Dis_KM.png',
              unit_tc: 'Dis_KM.png',
              unit_en: 'Dis_KM.png',
              imperial_unit_sc: 'Dis_Mi.png',
              imperial_unit_tc: 'Dis_Mi.png',
              imperial_unit_en: 'Dis_Mi.png',
              dot_image: 'E0.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 73,
              y: 311,
              font_array: ["Act_mid_0.png","Act_mid_1.png","Act_mid_2.png","Act_mid_3.png","Act_mid_4.png","Act_mid_5.png","Act_mid_6.png","Act_mid_7.png","Act_mid_8.png","Act_mid_9.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 197,
              y: 126,
              src: 'AmazfitLogo.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 171,
              y: 315,
              font_array: ["Act_mid_0.png","Act_mid_1.png","Act_mid_2.png","Act_mid_3.png","Act_mid_4.png","Act_mid_5.png","Act_mid_6.png","Act_mid_7.png","Act_mid_8.png","Act_mid_9.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (screenType != hmSetting.screen_type.AOD) {
              normal_heart_rate_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // normal_heart_rate_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 369,
              // start_y: 282,
              // color: 0xFFFFFFFF,
              // lenght: -127,
              // line_width: 20,
              // line_cap: Flat,
              // vertical: True,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const heart_rate = hmSensor.createSensor(hmSensor.id.HEART);
            heart_rate.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
              scale_call();
            });

            // normal_heart_rate_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 401,
              // y: 212,
              // font_array: ["Act_0.png","Act_1.png","Act_2.png","Act_3.png","Act_4.png","Act_5.png","Act_6.png","Act_7.png","Act_8.png","Act_9.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 3,
              // angle: -90,
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_heart_rate_TextRotate_ASCIIARRAY[0] = 'Act_0.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[1] = 'Act_1.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[2] = 'Act_2.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[3] = 'Act_3.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[4] = 'Act_4.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[5] = 'Act_5.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[6] = 'Act_6.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[7] = 'Act_7.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[8] = 'Act_8.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[9] = 'Act_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 3; i++) {
              normal_heart_rate_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 401,
                center_y: 212,
                pos_x: 401,
                pos_y: 212,
                angle: -90,
                src: 'Act_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_heart_rate_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 339,
              y: 124,
              image_array: ["Zone1.png","Zone2.png","Zone3.png","Zone4.png","Zone5.png","Zone6.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (screenType != hmSetting.screen_type.AOD) {
              normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 90,
              // start_y: 282,
              // color: 0xFFFFFFFF,
              // lenght: -127,
              // line_width: 21,
              // line_cap: Flat,
              // vertical: True,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
              scale_call();
            });

            // normal_battery_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 54,
              // y: 224,
              // font_array: ["Act_0.png","Act_1.png","Act_2.png","Act_3.png","Act_4.png","Act_5.png","Act_6.png","Act_7.png","Act_8.png","Act_9.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 1,
              // angle: -90,
              // unit_en: 'Battery_Unit.png',
              // invalid_image: 'Act_0.png',
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_battery_TextRotate_ASCIIARRAY[0] = 'Act_0.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[1] = 'Act_1.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[2] = 'Act_2.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[3] = 'Act_3.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[4] = 'Act_4.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[5] = 'Act_5.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[6] = 'Act_6.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[7] = 'Act_7.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[8] = 'Act_8.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[9] = 'Act_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 3; i++) {
              normal_battery_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 54,
                center_y: 224,
                pos_x: 54,
                pos_y: 224,
                angle: -90,
                src: 'Act_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_battery_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_battery_TextRotate_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              center_x: 54,
              center_y: 224,
              pos_x: 54,
              pos_y: 224,
              angle: -90,
              src: 'Battery_Unit.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_battery_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 108,
              y: 127,
              image_array: ["Batt_Progress_01.png","Batt_Progress_02.png","Batt_Progress_03.png","Batt_Progress_04.png","Batt_Progress_05.png","Batt_Progress_06.png","Batt_Progress_07.png","Batt_Progress_08.png","Batt_Progress_09.png","Batt_Progress_10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 90,
              y: 154,
              src: 'top_heart_batt.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_second = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              second_startX: 282,
              second_startY: 357,
              second_array: ["Time_0.png","Time_1.png","Time_2.png","Time_3.png","Time_4.png","Time_5.png","Time_6.png","Time_7.png","Time_8.png","Time_9.png"],
              second_zero: 1,
              second_space: 1,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_second_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 112,
              y: 376,
              src: 'Clock_24.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 212,
              minute_startY: 357,
              minute_array: ["Time_0.png","Time_1.png","Time_2.png","Time_3.png","Time_4.png","Time_5.png","Time_6.png","Time_7.png","Time_8.png","Time_9.png"],
              minute_zero: 1,
              minute_space: 1,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_minute_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 269,
              y: 352,
              src: 'Time_Dot.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 141,
              hour_startY: 357,
              hour_array: ["Time_0.png","Time_1.png","Time_2.png","Time_3.png","Time_4.png","Time_5.png","Time_6.png","Time_7.png","Time_8.png","Time_9.png"],
              hour_zero: 1,
              hour_space: 1,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 198,
              y: 352,
              src: 'Time_Dot.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 112,
              am_y: 376,
              am_sc_path: 'Clock_AM.png',
              am_en_path: 'Clock_AM.png',
              pm_x: 112,
              pm_y: 376,
              pm_sc_path: 'Clock_PM.png',
              pm_en_path: 'Clock_PM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const deviceInfo = hmSetting.getDeviceInfo();
            timeSensor.addEventListener(timeSensor.event.MINUTEEND, function() {
              let updateHour = timeSensor.minute == 0;

              time_update(updateHour, true);
            });

            // normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'Hand_H1.png',
              // center_x: 240,
              // center_y: 240,
              // x: 26,
              // y: 219,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.hour,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 26,
              pos_y: 240 - 219,
              center_x: 240,
              center_y: 240,
              src: 'Hand_H1.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'Hand_M1.png',
              // center_x: 240,
              // center_y: 240,
              // x: 26,
              // y: 219,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.minute,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 26,
              pos_y: 240 - 219,
              center_x: 240,
              center_y: 240,
              src: 'Hand_M1.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'Hand_S1.png',
              // center_x: 240,
              // center_y: 240,
              // x: 26,
              // y: 219,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 26,
              pos_y: 240 - 219,
              center_x: 240,
              center_y: 240,
              src: 'Hand_S1.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            function startSecAnim(sec, animDuration) {
              const secAnim = {
                anim_steps: [{
                  anim_rate: 'linear',
                  anim_duration: animDuration,
                  anim_from: sec,
                  anim_to: sec + (360*(animDuration*6/1000))/360,
                  anim_key: 'angle',
                }],
                anim_fps: 15,
                anim_auto_start: 1,
                anim_repeat: 1,
                anim_auto_destroy: 1,
              }
              normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANIM, secAnim);
            }
            // normal_analog_clock_pro_smooth_second = hmUI.createWidget(hmUI.widget.SMOOTH_SECOND, {
              // type: 4,
              // fps: 15,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'Pop_menu.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'main6.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // idle_Weather_FewDays = hmUI.createWidget(hmUI.widget.FewDays, {
              // x: 0,
              // y: 0,
              // ColumnWidth: 38,
              // DaysCount: 5,
            // });
            
            idle_group_ForecastWeather = hmUI.createWidget(hmUI.widget.GROUP, {
              x: 0,
              y: 0,
              h: 0,
              w: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_forecast_date_week_font = idle_group_ForecastWeather.createWidget(hmUI.widget.TEXT_Options, {
              // x: 151,
              // y: 217,
              // w: 189,
              // h: 25,
              // text_size: 20,
              // char_space: 0,
              // line_space: 0,
              // color: 0xFFD8D8D8,
              // color_2: 0xFFFF0000,
              // use_color_2: False,
              // align_h: hmUI.align.LEFT,
              // align_v: hmUI.align.TOP,
              // text_style: hmUI.text_style.ELLIPSIS,
              // type: hmUI.data_type.forecast_date_week_img,
              // unit_string: Mo, Tu, We, Th, Fr, Sa, Su,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            //start of ignored block
            if (screenType == hmSetting.screen_type.AOD) {
              for (let i = 0; i < 5; i++) {
                idle_forecast_date_week_font[i] = idle_group_ForecastWeather.createWidget(hmUI.widget.TEXT, {
                  x: 151 + i*38,
                  y: 217,
                  w: 189,
                  h: 25,
                  text_size: 20,
                  char_space: 0,
                  line_space: 0,
                  color: 0xFFD8D8D8,
                  // color_2: 0xFFFF0000,
                  align_h: hmUI.align.LEFT,
                  align_v: hmUI.align.TOP,
                  text_style: hmUI.text_style.ELLIPSIS,
                  // unit_string: Mo, Tu, We, Th, Fr, Sa, Su,
                  show_level: hmUI.show_level.ONLY_AOD,
                });
              };
            };
            //end of ignored block

            // idle_forecast_high_low_text_font = idle_group_ForecastWeather.createWidget(hmUI.widget.TEXT_Options, {
              // x: 88,
              // y: 273,
              // w: 150,
              // h: 30,
              // text_size: 10,
              // char_space: 0,
              // line_space: 0,
              // color: 0xFFFFFFFF,
              // color_2: 0xFFFF0000,
              // use_color_2: False,
              // align_h: hmUI.align.CENTER_H,
              // align_v: hmUI.align.CENTER_V,
              // text_style: hmUI.text_style.ELLIPSIS,
              // type: hmUI.data_type.forecast_high_low_text_font,
              // unit_type: 1,
              // unit_string: /,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            //start of ignored block
            if (screenType == hmSetting.screen_type.AOD) {
              for (let i = 0; i < 5; i++) {
                idle_forecast_high_low_text_font[i] = idle_group_ForecastWeather.createWidget(hmUI.widget.TEXT, {
                  x: 88 + i*38,
                  y: 273,
                  w: 150,
                  h: 30,
                  text_size: 10,
                  char_space: 0,
                  line_space: 0,
                  color: 0xFFFFFFFF,
                  align_h: hmUI.align.CENTER_H,
                  align_v: hmUI.align.CENTER_V,
                  text_style: hmUI.text_style.ELLIPSIS,
                  // unit_type: 1,
                  // unit_string: /,
                  show_level: hmUI.show_level.ONLY_AOD,
                });
              };
            };
            //end of ignored block

            // idle_forecast_image_progress_img_level = idle_group_ForecastWeather.createWidget(hmUI.widget.IMG_LEVEL_Options, {
              // x: 145,
              // y: 244,
              // image_array: ["Weather_small_01.png","Weather_small_02.png","Weather_small_03.png","Weather_small_04.png","Weather_small_05.png","Weather_small_06.png","Weather_small_07.png","Weather_small_08.png","Weather_small_09.png","Weather_small_10.png","Weather_small_11.png","Weather_small_12.png","Weather_small_13.png","Weather_small_14.png","Weather_small_15.png","Weather_small_16.png","Weather_small_17.png","Weather_small_18.png","Weather_small_19.png","Weather_small_20.png","Weather_small_21.png","Weather_small_22.png","Weather_small_23.png","Weather_small_24.png","Weather_small_25.png","Weather_small_26.png","Weather_small_27.png","Weather_small_28.png","Weather_small_29.png"],
              // image_length: 29,
              // type: hmUI.data_type.forecast_image,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            //start of ignored block
            if (screenType == hmSetting.screen_type.AOD) {
              for (let i = 0; i < 5; i++) {
                idle_forecast_image_progress_img_level[i] = idle_group_ForecastWeather.createWidget(hmUI.widget.IMG, {
                  x: 145 + i*38,
                  y: 244,
                  src: idle_forecast_image_array[25],
                  show_level: hmUI.show_level.ONLY_AOD,
                });
              };
            };
            //end of ignored block

            idle_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 202,
              y: 158,
              w: 79,
              h: 26,
              text_size: 16,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 299,
              y: 178,
              image_array: ["Weather_small_01.png","Weather_small_02.png","Weather_small_03.png","Weather_small_04.png","Weather_small_05.png","Weather_small_06.png","Weather_small_07.png","Weather_small_08.png","Weather_small_09.png","Weather_small_10.png","Weather_small_11.png","Weather_small_12.png","Weather_small_13.png","Weather_small_14.png","Weather_small_15.png","Weather_small_16.png","Weather_small_17.png","Weather_small_18.png","Weather_small_19.png","Weather_small_20.png","Weather_small_21.png","Weather_small_22.png","Weather_small_23.png","Weather_small_24.png","Weather_small_25.png","Weather_small_26.png","Weather_small_27.png","Weather_small_28.png","Weather_small_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 144,
              y: 190,
              font_array: ["Act_mid_0.png","Act_mid_1.png","Act_mid_2.png","Act_mid_3.png","Act_mid_4.png","Act_mid_5.png","Act_mid_6.png","Act_mid_7.png","Act_mid_8.png","Act_mid_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Weather_symbol4.png',
              unit_tc: 'Weather_symbol4.png',
              unit_en: 'Weather_symbol4.png',
              imperial_unit_sc: 'Weather_symbol4.png',
              imperial_unit_tc: 'Weather_symbol4.png',
              imperial_unit_en: 'Weather_symbol4.png',
              negative_image: 'Weather_Symbol3.png',
              invalid_image: 'Weather_Symbol3.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            //start of ignored block
            if (temperatureUnit == 1) {
              idle_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
                x: 144,
                y: 190,
                font_array: ["Act_mid_0.png","Act_mid_1.png","Act_mid_2.png","Act_mid_3.png","Act_mid_4.png","Act_mid_5.png","Act_mid_6.png","Act_mid_7.png","Act_mid_8.png","Act_mid_9.png"],
                padding: false,
                h_space: 0,
                unit_sc: 'Weather_symbol4.png',
                unit_tc: 'Weather_symbol4.png',
                unit_en: 'Weather_symbol4.png',
                imperial_unit_sc: 'Weather_symbol4.png',
                imperial_unit_tc: 'Weather_symbol4.png',
                imperial_unit_en: 'Weather_symbol4.png',
                negative_image: 'Weather_Symbol3.png',
                invalid_image: 'Weather_Symbol3.png',
                align_h: hmUI.align.CENTER_H,
                type: hmUI.data_type.WEATHER_CURRENT,
                show_level: hmUI.show_level.ONLY_AOD,
              });
            };
            //end of ignored block

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 311,
              y: 54,
              src: 'System_BT_OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 378,
              y: 351,
              src: 'System_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 54,
              y: 266,
              image_array: ["moon_01.png","moon_02.png","moon_03.png","moon_04.png","moon_05.png","moon_06.png","moon_07.png","moon_08.png","moon_09.png","moon_10.png","moon_11.png","moon_12.png","moon_13.png","moon_14.png","moon_15.png","moon_16.png","moon_17.png","moon_18.png","moon_19.png","moon_20.png","moon_21.png","moon_22.png","moon_23.png","moon_24.png","moon_25.png","moon_26.png","moon_27.png","moon_28.png","moon_29.png","moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 206,
              y: 55,
              font_array: ["Act_mid_0.png","Act_mid_1.png","Act_mid_2.png","Act_mid_3.png","Act_mid_4.png","Act_mid_5.png","Act_mid_6.png","Act_mid_7.png","Act_mid_8.png","Act_mid_9.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'SS.png',
              unit_tc: 'SS.png',
              unit_en: 'SS.png',
              dot_image: 'SunRiseSet_Dot.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_sun_low_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 176,
              y: 55,
              src: 'SS.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 208,
              y: 409,
              font_array: ["Act_mid_0.png","Act_mid_1.png","Act_mid_2.png","Act_mid_3.png","Act_mid_4.png","Act_mid_5.png","Act_mid_6.png","Act_mid_7.png","Act_mid_8.png","Act_mid_9.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'SR.png',
              unit_tc: 'SR.png',
              unit_en: 'SR.png',
              dot_image: 'SunRiseSet_Dot.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_sun_high_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 178,
              y: 408,
              src: 'SR.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 271,
              month_startY: 95,
              month_sc_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_tc_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_en_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 129,
              y: 95,
              week_en: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              week_tc: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              week_sc: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 218,
              day_startY: 93,
              day_sc_array: ["Act_0.png","Act_1.png","Act_2.png","Act_3.png","Act_4.png","Act_5.png","Act_6.png","Act_7.png","Act_8.png","Act_9.png"],
              day_tc_array: ["Act_0.png","Act_1.png","Act_2.png","Act_3.png","Act_4.png","Act_5.png","Act_6.png","Act_7.png","Act_8.png","Act_9.png"],
              day_en_array: ["Act_0.png","Act_1.png","Act_2.png","Act_3.png","Act_4.png","Act_5.png","Act_6.png","Act_7.png","Act_8.png","Act_9.png"],
              day_zero: 0,
              day_space: 1,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_distance_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 251,
              y: 315,
              src: 'line.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_distance_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 334,
              // y: 315,
              // font_array: ["Act_mid_0.png","Act_mid_1.png","Act_mid_2.png","Act_mid_3.png","Act_mid_4.png","Act_mid_5.png","Act_mid_6.png","Act_mid_7.png","Act_mid_8.png","Act_mid_9.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: 0,
              // unit_en: 'E0.png',
              // imperial_unit_en: 'E0.png',
              // negative_image: 'Dis_dot.png',
              // invalid_image: 'E0.png',
              // dot_image: 'Dis_dot.png',
              // align_h: hmUI.align.RIGHT,
              // type: hmUI.data_type.DISTANCE,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_distance_TextRotate_ASCIIARRAY[0] = 'Act_mid_0.png';  // set of images with numbers
            idle_distance_TextRotate_ASCIIARRAY[1] = 'Act_mid_1.png';  // set of images with numbers
            idle_distance_TextRotate_ASCIIARRAY[2] = 'Act_mid_2.png';  // set of images with numbers
            idle_distance_TextRotate_ASCIIARRAY[3] = 'Act_mid_3.png';  // set of images with numbers
            idle_distance_TextRotate_ASCIIARRAY[4] = 'Act_mid_4.png';  // set of images with numbers
            idle_distance_TextRotate_ASCIIARRAY[5] = 'Act_mid_5.png';  // set of images with numbers
            idle_distance_TextRotate_ASCIIARRAY[6] = 'Act_mid_6.png';  // set of images with numbers
            idle_distance_TextRotate_ASCIIARRAY[7] = 'Act_mid_7.png';  // set of images with numbers
            idle_distance_TextRotate_ASCIIARRAY[8] = 'Act_mid_8.png';  // set of images with numbers
            idle_distance_TextRotate_ASCIIARRAY[9] = 'Act_mid_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              idle_distance_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 334,
                center_y: 315,
                pos_x: 334,
                pos_y: 315,
                angle: 0,
                src: 'Act_mid_0.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_distance_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            idle_distance_TextRotate_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              center_x: 334,
              center_y: 315,
              pos_x: 334,
              pos_y: 315,
              angle: 0,
              src: 'E0.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            idle_distance_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);

            if (mileageUnit == 1) {
              idle_distance_TextRotate_unit.setProperty(hmUI.prop.SRC, 'E0.png');
            };
            //end of ignored block

            idle_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 357,
              y: 320,
              font_array: ["E0.png","E1.png","E2.png","E3.png","E4.png","E5.png","E6.png","E7.png","E8.png","E9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Dis_KM.png',
              unit_tc: 'Dis_KM.png',
              unit_en: 'Dis_KM.png',
              imperial_unit_sc: 'Dis_Mi.png',
              imperial_unit_tc: 'Dis_Mi.png',
              imperial_unit_en: 'Dis_Mi.png',
              dot_image: 'E0.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 73,
              y: 311,
              font_array: ["Act_mid_0.png","Act_mid_1.png","Act_mid_2.png","Act_mid_3.png","Act_mid_4.png","Act_mid_5.png","Act_mid_6.png","Act_mid_7.png","Act_mid_8.png","Act_mid_9.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 197,
              y: 126,
              src: 'AmazfitLogo.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 171,
              y: 315,
              font_array: ["Act_mid_0.png","Act_mid_1.png","Act_mid_2.png","Act_mid_3.png","Act_mid_4.png","Act_mid_5.png","Act_mid_6.png","Act_mid_7.png","Act_mid_8.png","Act_mid_9.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            if (screenType == hmSetting.screen_type.AOD) {
              idle_heart_rate_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // idle_heart_rate_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 369,
              // start_y: 282,
              // color: 0xFFFFFFFF,
              // lenght: -127,
              // line_width: 20,
              // line_cap: Flat,
              // vertical: True,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            // idle_heart_rate_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 401,
              // y: 212,
              // font_array: ["Act_0.png","Act_1.png","Act_2.png","Act_3.png","Act_4.png","Act_5.png","Act_6.png","Act_7.png","Act_8.png","Act_9.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 3,
              // angle: -90,
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_heart_rate_TextRotate_ASCIIARRAY[0] = 'Act_0.png';  // set of images with numbers
            idle_heart_rate_TextRotate_ASCIIARRAY[1] = 'Act_1.png';  // set of images with numbers
            idle_heart_rate_TextRotate_ASCIIARRAY[2] = 'Act_2.png';  // set of images with numbers
            idle_heart_rate_TextRotate_ASCIIARRAY[3] = 'Act_3.png';  // set of images with numbers
            idle_heart_rate_TextRotate_ASCIIARRAY[4] = 'Act_4.png';  // set of images with numbers
            idle_heart_rate_TextRotate_ASCIIARRAY[5] = 'Act_5.png';  // set of images with numbers
            idle_heart_rate_TextRotate_ASCIIARRAY[6] = 'Act_6.png';  // set of images with numbers
            idle_heart_rate_TextRotate_ASCIIARRAY[7] = 'Act_7.png';  // set of images with numbers
            idle_heart_rate_TextRotate_ASCIIARRAY[8] = 'Act_8.png';  // set of images with numbers
            idle_heart_rate_TextRotate_ASCIIARRAY[9] = 'Act_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 3; i++) {
              idle_heart_rate_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 401,
                center_y: 212,
                pos_x: 401,
                pos_y: 212,
                angle: -90,
                src: 'Act_0.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_heart_rate_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            idle_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 339,
              y: 124,
              image_array: ["Zone1.png","Zone2.png","Zone3.png","Zone4.png","Zone5.png","Zone6.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            if (screenType == hmSetting.screen_type.AOD) {
              idle_battery_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // idle_battery_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 90,
              // start_y: 282,
              // color: 0xFFFFFFFF,
              // lenght: -127,
              // line_width: 21,
              // line_cap: Flat,
              // vertical: True,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            // idle_battery_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 54,
              // y: 224,
              // font_array: ["Act_0.png","Act_1.png","Act_2.png","Act_3.png","Act_4.png","Act_5.png","Act_6.png","Act_7.png","Act_8.png","Act_9.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 1,
              // angle: -90,
              // unit_en: 'Battery_Unit.png',
              // invalid_image: 'Act_0.png',
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_battery_TextRotate_ASCIIARRAY[0] = 'Act_0.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[1] = 'Act_1.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[2] = 'Act_2.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[3] = 'Act_3.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[4] = 'Act_4.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[5] = 'Act_5.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[6] = 'Act_6.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[7] = 'Act_7.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[8] = 'Act_8.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[9] = 'Act_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 3; i++) {
              idle_battery_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 54,
                center_y: 224,
                pos_x: 54,
                pos_y: 224,
                angle: -90,
                src: 'Act_0.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_battery_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            idle_battery_TextRotate_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              center_x: 54,
              center_y: 224,
              pos_x: 54,
              pos_y: 224,
              angle: -90,
              src: 'Battery_Unit.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            idle_battery_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 108,
              y: 127,
              image_array: ["Batt_Progress_01.png","Batt_Progress_02.png","Batt_Progress_03.png","Batt_Progress_04.png","Batt_Progress_05.png","Batt_Progress_06.png","Batt_Progress_07.png","Batt_Progress_08.png","Batt_Progress_09.png","Batt_Progress_10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 90,
              y: 154,
              src: 'top_heart_batt.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_second = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              second_startX: 282,
              second_startY: 357,
              second_array: ["Time_0.png","Time_1.png","Time_2.png","Time_3.png","Time_4.png","Time_5.png","Time_6.png","Time_7.png","Time_8.png","Time_9.png"],
              second_zero: 1,
              second_space: 1,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_second_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 112,
              y: 376,
              src: 'Clock_24.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 212,
              minute_startY: 357,
              minute_array: ["Time_0.png","Time_1.png","Time_2.png","Time_3.png","Time_4.png","Time_5.png","Time_6.png","Time_7.png","Time_8.png","Time_9.png"],
              minute_zero: 1,
              minute_space: 1,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_minute_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 269,
              y: 352,
              src: 'Time_Dot.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 141,
              hour_startY: 357,
              hour_array: ["Time_0.png","Time_1.png","Time_2.png","Time_3.png","Time_4.png","Time_5.png","Time_6.png","Time_7.png","Time_8.png","Time_9.png"],
              hour_zero: 1,
              hour_space: 1,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 198,
              y: 352,
              src: 'Time_Dot.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 112,
              am_y: 376,
              am_sc_path: 'Clock_AM.png',
              am_en_path: 'Clock_AM.png',
              pm_x: 112,
              pm_y: 376,
              pm_sc_path: 'Clock_PM.png',
              pm_en_path: 'Clock_PM.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'Top_AOD.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'Hand_H1.png',
              // center_x: 240,
              // center_y: 240,
              // x: 26,
              // y: 219,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.hour,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });


            idle_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 26,
              pos_y: 240 - 219,
              center_x: 240,
              center_y: 240,
              src: 'Hand_H1.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'Hand_M1.png',
              // center_x: 240,
              // center_y: 240,
              // x: 26,
              // y: 219,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.minute,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });


            idle_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 26,
              pos_y: 240 - 219,
              center_x: 240,
              center_y: 240,
              src: 'Hand_M1.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'E0.png',
              // center_x: 240,
              // center_y: 240,
              // x: 26,
              // y: 219,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });


            idle_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 26,
              pos_y: 240 - 219,
              center_x: 240,
              center_y: 240,
              src: 'E0.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_analog_clock_pro_smooth_second = hmUI.createWidget(hmUI.widget.SMOOTH_SECOND, {
              // type: 2,
              // fps: 15,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            console.log('Watch_Face.Shortcuts');

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 214,
              y: 354,
              w: 52,
              h: 39,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 287,
              y: 358,
              w: 54,
              h: 33,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 362,
              y: 347,
              w: 47,
              h: 37,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 178,
              y: 407,
              w: 124,
              h: 38,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 142,
              y: 169,
              w: 49,
              h: 55,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 69,
              y: 307,
              w: 63,
              h: 52,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 374,
              y: 183,
              w: 64,
              h: 52,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 371,
              y: 123,
              w: 48,
              h: 44,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 151,
              y: 310,
              w: 97,
              h: 27,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 52,
              y: 178,
              w: 82,
              h: 84,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PowerSaveHintScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 142,
              y: 91,
              w: 198,
              h: 29,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 266,
              y: 312,
              w: 79,
              h: 23,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'SportListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 389,
              y: 251,
              w: 54,
              h: 49,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                //change color
pop_menu_ON()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 214,
              y: 215,
              w: 54,
              h: 54,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                // Analog Hand ON/OFF
click_elemente()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 62,
              y: 123,
              w: 79,
              h: 76,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                //color1
                colornumber = 1
                click_Color()
                pop_menu_OFF()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_7 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 203,
              y: 122,
              w: 73,
              h: 77,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                //color2
                colornumber = 2
                click_Color()
                pop_menu_OFF()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_8 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 342,
              y: 123,
              w: 74,
              h: 77,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                //color3
                colornumber = 3
                click_Color()
                pop_menu_OFF()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_9 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 62,
              y: 284,
              w: 77,
              h: 71,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                //color4
                colornumber = 4
                click_Color()
                pop_menu_OFF()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_10 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 198,
              y: 282,
              w: 81,
              h: 71,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                //color5
                colornumber = 5
                click_Color()
                pop_menu_OFF()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_11 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 341,
              y: 279,
              w: 79,
              h: 70,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                //color6
                colornumber = 6
                click_Color()
                pop_menu_OFF()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            console.log('user_script_end.js');
            // start user_script_end.js

let cc = 0
if (cc==0){
pop_menu_OFF()
cc =1
}
            // end user_script_end.js

            //start of ignored block
            function weather_few_days() {
              console.log('weather_few_days()');
              let weatherData = weatherSensor.getForecastWeather();
              let forecastData = weatherData.forecastData;

              for (let i = 0; i < 5; i++) {
                // DayOfWeek font
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  let dowIndex = timeSensor.week - 1;
                  dowIndex += i;
                  while (dowIndex >= 7) {dowIndex -= 7;}
                  normal_forecast_date_week_font[i].setProperty(hmUI.prop.TEXT, normal_forecast_date_week_font_Array[dowIndex]);
                };
              
                // Number_Font_Maxmin
                let normal_max_min_Temperature_font = '-';
                if (i < forecastData.count) {
                  normal_max_min_Temperature_font = forecastData.data[i].high.toString();
                  normal_max_min_Temperature_font += '/';
                  normal_max_min_Temperature_font += forecastData.data[i].low.toString();
                };
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  normal_forecast_high_low_text_font[i].setProperty(hmUI.prop.TEXT, normal_max_min_Temperature_font + '°');
                };
                
                // Images
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  let weatherIndex = 25
                  if (i < forecastData.count) weatherIndex = forecastData.data[i].index;
                  normal_forecast_image_progress_img_level[i].setProperty(hmUI.prop.SRC, normal_forecast_image_array[weatherIndex]);
                };
              
                // DayOfWeek font
                if (screenType == hmSetting.screen_type.AOD) {
                  let dowIndex = timeSensor.week - 1;
                  dowIndex += i;
                  while (dowIndex >= 7) {dowIndex -= 7;}
                  idle_forecast_date_week_font[i].setProperty(hmUI.prop.TEXT, idle_forecast_date_week_font_Array[dowIndex]);
                };
              
                // Number_Font_Maxmin
                let idle_max_min_Temperature_font = '-';
                if (i < forecastData.count) {
                  idle_max_min_Temperature_font = forecastData.data[i].high.toString();
                  idle_max_min_Temperature_font += '/';
                  idle_max_min_Temperature_font += forecastData.data[i].low.toString();
                };
                if (screenType == hmSetting.screen_type.AOD) {
                  idle_forecast_high_low_text_font[i].setProperty(hmUI.prop.TEXT, idle_max_min_Temperature_font + '°');
                };
                
                // Images
                if (screenType == hmSetting.screen_type.AOD) {
                  let weatherIndex = 25
                  if (i < forecastData.count) weatherIndex = forecastData.data[i].index;
                  idle_forecast_image_progress_img_level[i].setProperty(hmUI.prop.SRC, idle_forecast_image_array[weatherIndex]);
                };
              
              };  // end for

            };
            //end of ignored block

            //start of ignored block
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              if (updateHour) {
                let normal_hour = hour;
                let normal_fullAngle_hour = 360;
                if (normal_hour > 11) normal_hour -= 12;
                let normal_angle_hour = 0 + normal_fullAngle_hour*normal_hour/12 + (normal_fullAngle_hour/12)*minute/60;
                if (normal_analog_clock_pro_hour_pointer_img) normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_hour);
              };

              if (updateMinute) {
                let normal_fullAngle_minute = 360;
                let normal_angle_minute = 0 + normal_fullAngle_minute*(minute + second/60)/60;
                if (normal_analog_clock_pro_minute_pointer_img) normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_minute);
              };

              if (updateHour) {
                let idle_hour = hour;
                let idle_fullAngle_hour = 360;
                if (idle_hour > 11) idle_hour -= 12;
                let idle_angle_hour = 0 + idle_fullAngle_hour*idle_hour/12 + (idle_fullAngle_hour/12)*minute/60;
                if (idle_analog_clock_pro_hour_pointer_img) idle_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.ANGLE, idle_angle_hour);
              };

              if (updateMinute) {
                let idle_fullAngle_minute = 360;
                let idle_angle_minute = 0 + idle_fullAngle_minute*(minute + second/60)/60;
                if (idle_analog_clock_pro_minute_pointer_img) idle_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.ANGLE, idle_angle_minute);
              };

              let idle_fullAngle_second = 360;
              let idle_angle_second = 0 + idle_fullAngle_second*(second + (timeSensor.utc % 1000)/1000)/60;
              if (idle_analog_clock_pro_second_pointer_img) idle_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, idle_angle_second);

            };

            //end of ignored block
            //start of ignored block
            function text_update() {
              console.log('text_update()');

              console.log('update text rotate DISTANCE');
              let distanceCurrent = distance.current;
              let normal_distance_rotate_string = (distanceCurrent / 1000).toFixed(2);

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  normal_distance_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_distance_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
                if (distanceCurrent != null && distanceCurrent != undefined && isFinite(distanceCurrent) && normal_distance_rotate_string.length > 0 && normal_distance_rotate_string.length <= 5) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = RIGHT
                  let normal_distance_TextRotate_posOffset = normal_distance_TextRotate_img_width * normal_distance_rotate_string.length;
                  normal_distance_TextRotate_posOffset = normal_distance_TextRotate_posOffset - normal_distance_TextRotate_img_width + normal_distance_TextRotate_dot_width;
                  img_offset -= normal_distance_TextRotate_posOffset;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_distance_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_distance_TextRotate[index].setProperty(hmUI.prop.POS_X, 334 + img_offset);
                      normal_distance_TextRotate[index].setProperty(hmUI.prop.SRC, normal_distance_TextRotate_ASCIIARRAY[charCode]);
                      normal_distance_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_distance_TextRotate_img_width;
                      index++;
                    }  // end if digit
                    else { 
                      normal_distance_TextRotate[index].setProperty(hmUI.prop.POS_X, 334 + img_offset);
                      normal_distance_TextRotate[index].setProperty(hmUI.prop.SRC, 'Dis_dot.png');
                      normal_distance_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_distance_TextRotate_dot_width;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                  normal_distance_TextRotate_unit.setProperty(hmUI.prop.POS_X, 334 + img_offset);
                  normal_distance_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite
                else {
                  normal_distance_TextRotate[0].setProperty(hmUI.prop.POS_X, 334 - normal_distance_TextRotate_error_img_width / 2);
                  normal_distance_TextRotate[0].setProperty(hmUI.prop.SRC, 'E0.png');
                  normal_distance_TextRotate[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

              console.log('update text rotate heart_rate_HEART');
              let valueHeartRate = heart_rate.last;
              let normal_heart_rate_rotate_string = parseInt(valueHeartRate).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  normal_heart_rate_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueHeartRate != null && valueHeartRate != undefined && isFinite(valueHeartRate) && normal_heart_rate_rotate_string.length > 0 && normal_heart_rate_rotate_string.length <= 3) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let normal_heart_rate_TextRotate_posOffset = normal_heart_rate_TextRotate_img_width * normal_heart_rate_rotate_string.length;
                  normal_heart_rate_TextRotate_posOffset = normal_heart_rate_TextRotate_posOffset + 3 * (normal_heart_rate_rotate_string.length - 1);
                  img_offset -= normal_heart_rate_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_heart_rate_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_heart_rate_TextRotate[index].setProperty(hmUI.prop.POS_X, 401 + img_offset);
                      normal_heart_rate_TextRotate[index].setProperty(hmUI.prop.SRC, normal_heart_rate_TextRotate_ASCIIARRAY[charCode]);
                      normal_heart_rate_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_heart_rate_TextRotate_img_width + 3;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate battery_BATTERY');
              let valueBattery = battery.current;
              let normal_battery_rotate_string = parseInt(valueBattery).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  normal_battery_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_battery_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
                if (valueBattery != null && valueBattery != undefined && isFinite(valueBattery) && normal_battery_rotate_string.length > 0 && normal_battery_rotate_string.length <= 3) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let normal_battery_TextRotate_posOffset = normal_battery_TextRotate_img_width * normal_battery_rotate_string.length;
                  normal_battery_TextRotate_posOffset = normal_battery_TextRotate_posOffset + 1 * (normal_battery_rotate_string.length - 1);
                  img_offset -= normal_battery_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_battery_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_battery_TextRotate[index].setProperty(hmUI.prop.POS_X, 54 + img_offset);
                      normal_battery_TextRotate[index].setProperty(hmUI.prop.SRC, normal_battery_TextRotate_ASCIIARRAY[charCode]);
                      normal_battery_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_battery_TextRotate_img_width + 1;
                      index++;
                    };  // end if digit
                  };  // end char of string
                  normal_battery_TextRotate_unit.setProperty(hmUI.prop.POS_X, 54 + img_offset);
                  normal_battery_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite
                else {
                  normal_battery_TextRotate[0].setProperty(hmUI.prop.POS_X, 54 - normal_battery_TextRotate_error_img_width / 2);
                  normal_battery_TextRotate[0].setProperty(hmUI.prop.SRC, 'Act_0.png');
                  normal_battery_TextRotate[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

              console.log('update text rotate DISTANCE');
              let idle_distance_rotate_string = (distanceCurrent / 1000).toFixed(2);

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  idle_distance_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                idle_distance_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
                if (distanceCurrent != null && distanceCurrent != undefined && isFinite(distanceCurrent) && idle_distance_rotate_string.length > 0 && idle_distance_rotate_string.length <= 5) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = RIGHT
                  let idle_distance_TextRotate_posOffset = idle_distance_TextRotate_img_width * idle_distance_rotate_string.length;
                  idle_distance_TextRotate_posOffset = idle_distance_TextRotate_posOffset - idle_distance_TextRotate_img_width + idle_distance_TextRotate_dot_width;
                  img_offset -= idle_distance_TextRotate_posOffset;
                  // alignment end
                  
                  let index = 0;
                  for (let char of idle_distance_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_distance_TextRotate[index].setProperty(hmUI.prop.POS_X, 334 + img_offset);
                      idle_distance_TextRotate[index].setProperty(hmUI.prop.SRC, idle_distance_TextRotate_ASCIIARRAY[charCode]);
                      idle_distance_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_distance_TextRotate_img_width;
                      index++;
                    }  // end if digit
                    else { 
                      idle_distance_TextRotate[index].setProperty(hmUI.prop.POS_X, 334 + img_offset);
                      idle_distance_TextRotate[index].setProperty(hmUI.prop.SRC, 'Dis_dot.png');
                      idle_distance_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_distance_TextRotate_dot_width;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                  idle_distance_TextRotate_unit.setProperty(hmUI.prop.POS_X, 334 + img_offset);
                  idle_distance_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite
                else {
                  idle_distance_TextRotate[0].setProperty(hmUI.prop.POS_X, 334 - idle_distance_TextRotate_error_img_width / 2);
                  idle_distance_TextRotate[0].setProperty(hmUI.prop.SRC, 'E0.png');
                  idle_distance_TextRotate[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

              console.log('update text rotate heart_rate_HEART');
              let idle_heart_rate_rotate_string = parseInt(valueHeartRate).toString();

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  idle_heart_rate_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueHeartRate != null && valueHeartRate != undefined && isFinite(valueHeartRate) && idle_heart_rate_rotate_string.length > 0 && idle_heart_rate_rotate_string.length <= 3) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let idle_heart_rate_TextRotate_posOffset = idle_heart_rate_TextRotate_img_width * idle_heart_rate_rotate_string.length;
                  idle_heart_rate_TextRotate_posOffset = idle_heart_rate_TextRotate_posOffset + 3 * (idle_heart_rate_rotate_string.length - 1);
                  img_offset -= idle_heart_rate_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of idle_heart_rate_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_heart_rate_TextRotate[index].setProperty(hmUI.prop.POS_X, 401 + img_offset);
                      idle_heart_rate_TextRotate[index].setProperty(hmUI.prop.SRC, idle_heart_rate_TextRotate_ASCIIARRAY[charCode]);
                      idle_heart_rate_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_heart_rate_TextRotate_img_width + 3;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate battery_BATTERY');
              let idle_battery_rotate_string = parseInt(valueBattery).toString();

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  idle_battery_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                idle_battery_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
                if (valueBattery != null && valueBattery != undefined && isFinite(valueBattery) && idle_battery_rotate_string.length > 0 && idle_battery_rotate_string.length <= 3) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let idle_battery_TextRotate_posOffset = idle_battery_TextRotate_img_width * idle_battery_rotate_string.length;
                  idle_battery_TextRotate_posOffset = idle_battery_TextRotate_posOffset + 1 * (idle_battery_rotate_string.length - 1);
                  img_offset -= idle_battery_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of idle_battery_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_battery_TextRotate[index].setProperty(hmUI.prop.POS_X, 54 + img_offset);
                      idle_battery_TextRotate[index].setProperty(hmUI.prop.SRC, idle_battery_TextRotate_ASCIIARRAY[charCode]);
                      idle_battery_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_battery_TextRotate_img_width + 1;
                      index++;
                    };  // end if digit
                  };  // end char of string
                  idle_battery_TextRotate_unit.setProperty(hmUI.prop.POS_X, 54 + img_offset);
                  idle_battery_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite
                else {
                  idle_battery_TextRotate[0].setProperty(hmUI.prop.POS_X, 54 - idle_battery_TextRotate_error_img_width / 2);
                  idle_battery_TextRotate[0].setProperty(hmUI.prop.SRC, 'Act_0.png');
                  idle_battery_TextRotate[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

            };

            //end of ignored block
            function scale_call() {
              console.log('scale_call()');

              console.log('Weather city name');
              let weatherData = weatherSensor.getForecastWeather();
              normal_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

                console.log('update scales HEART');
                
                let valueHeartRate = heart_rate.last;
                let targetHeartRate = 179;
                let progressHeartRate = (valueHeartRate - 71)/(targetHeartRate - 71);
                if (progressHeartRate < 0) progressHeartRate = 0;
                if (progressHeartRate > 1) progressHeartRate = 1;
                let progress_ls_normal_heart_rate = progressHeartRate;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_heart_rate_linear_scale
                  // initial parameters
                  let start_x_normal_heart_rate = 369;
                  let start_y_normal_heart_rate = 282;
                  let lenght_ls_normal_heart_rate = -127;
                  let line_width_ls_normal_heart_rate = 20;
                  let color_ls_normal_heart_rate = 0xFFFFFFFF;
                  
                  // calculated parameters
                  let start_x_normal_heart_rate_draw = start_x_normal_heart_rate;
                  let start_y_normal_heart_rate_draw = start_y_normal_heart_rate;
                  lenght_ls_normal_heart_rate = lenght_ls_normal_heart_rate * progress_ls_normal_heart_rate;
                  let lenght_ls_normal_heart_rate_draw = line_width_ls_normal_heart_rate;
                  let line_width_ls_normal_heart_rate_draw = lenght_ls_normal_heart_rate;
                  if (lenght_ls_normal_heart_rate < 0){
                    line_width_ls_normal_heart_rate_draw = -lenght_ls_normal_heart_rate;
                    start_y_normal_heart_rate_draw = start_y_normal_heart_rate_draw - line_width_ls_normal_heart_rate_draw;
                  };
                  
                  normal_heart_rate_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_heart_rate_draw,
                    y: start_y_normal_heart_rate_draw,
                    w: lenght_ls_normal_heart_rate_draw,
                    h: line_width_ls_normal_heart_rate_draw,
                    color: color_ls_normal_heart_rate,
                  });
                };

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_ls_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_linear_scale
                  // initial parameters
                  let start_x_normal_battery = 90;
                  let start_y_normal_battery = 282;
                  let lenght_ls_normal_battery = -127;
                  let line_width_ls_normal_battery = 21;
                  let color_ls_normal_battery = 0xFFFFFFFF;
                  
                  // calculated parameters
                  let start_x_normal_battery_draw = start_x_normal_battery;
                  let start_y_normal_battery_draw = start_y_normal_battery;
                  lenght_ls_normal_battery = lenght_ls_normal_battery * progress_ls_normal_battery;
                  let lenght_ls_normal_battery_draw = line_width_ls_normal_battery;
                  let line_width_ls_normal_battery_draw = lenght_ls_normal_battery;
                  if (lenght_ls_normal_battery < 0){
                    line_width_ls_normal_battery_draw = -lenght_ls_normal_battery;
                    start_y_normal_battery_draw = start_y_normal_battery_draw - line_width_ls_normal_battery_draw;
                  };
                  
                  normal_battery_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_battery_draw,
                    y: start_y_normal_battery_draw,
                    w: lenght_ls_normal_battery_draw,
                    h: line_width_ls_normal_battery_draw,
                    color: color_ls_normal_battery,
                  });
                };

              console.log('Weather city name');
              idle_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

                console.log('update scales HEART');
                let progress_ls_idle_heart_rate = progressHeartRate;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_heart_rate_linear_scale
                  // initial parameters
                  let start_x_idle_heart_rate = 369;
                  let start_y_idle_heart_rate = 282;
                  let lenght_ls_idle_heart_rate = -127;
                  let line_width_ls_idle_heart_rate = 20;
                  let color_ls_idle_heart_rate = 0xFFFFFFFF;
                  
                  // calculated parameters
                  let start_x_idle_heart_rate_draw = start_x_idle_heart_rate;
                  let start_y_idle_heart_rate_draw = start_y_idle_heart_rate;
                  lenght_ls_idle_heart_rate = lenght_ls_idle_heart_rate * progress_ls_idle_heart_rate;
                  let lenght_ls_idle_heart_rate_draw = line_width_ls_idle_heart_rate;
                  let line_width_ls_idle_heart_rate_draw = lenght_ls_idle_heart_rate;
                  if (lenght_ls_idle_heart_rate < 0){
                    line_width_ls_idle_heart_rate_draw = -lenght_ls_idle_heart_rate;
                    start_y_idle_heart_rate_draw = start_y_idle_heart_rate_draw - line_width_ls_idle_heart_rate_draw;
                  };
                  
                  idle_heart_rate_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_idle_heart_rate_draw,
                    y: start_y_idle_heart_rate_draw,
                    w: lenght_ls_idle_heart_rate_draw,
                    h: line_width_ls_idle_heart_rate_draw,
                    color: color_ls_idle_heart_rate,
                  });
                };

                console.log('update scales BATTERY');
                let progress_ls_idle_battery = progressBattery;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_battery_linear_scale
                  // initial parameters
                  let start_x_idle_battery = 90;
                  let start_y_idle_battery = 282;
                  let lenght_ls_idle_battery = -127;
                  let line_width_ls_idle_battery = 21;
                  let color_ls_idle_battery = 0xFFFFFFFF;
                  
                  // calculated parameters
                  let start_x_idle_battery_draw = start_x_idle_battery;
                  let start_y_idle_battery_draw = start_y_idle_battery;
                  lenght_ls_idle_battery = lenght_ls_idle_battery * progress_ls_idle_battery;
                  let lenght_ls_idle_battery_draw = line_width_ls_idle_battery;
                  let line_width_ls_idle_battery_draw = lenght_ls_idle_battery;
                  if (lenght_ls_idle_battery < 0){
                    line_width_ls_idle_battery_draw = -lenght_ls_idle_battery;
                    start_y_idle_battery_draw = start_y_idle_battery_draw - line_width_ls_idle_battery_draw;
                  };
                  
                  idle_battery_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_idle_battery_draw,
                    y: start_y_idle_battery_draw,
                    w: lenght_ls_idle_battery_draw,
                    h: line_width_ls_idle_battery_draw,
                    color: color_ls_idle_battery,
                  });
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                time_update(true, true);
                text_update();
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSec) {
                    let animDelay = timeSensor.utc % 1000;
                    let animRepeat = 1000;
                    normal_timerUpdateSec = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, true);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                let secAngle = 0 + (360*6)*(timeSensor.second + ((timeSensor.utc % 1000) / 1000))/360;
                normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, secAngle);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSecSmooth) {
                    let duration = 0;
                    let animDuration = 5000;
                    if (timeSensor.second > 55) animDuration = 1000*(60.1 - (timeSensor.second - (timeSensor.utc % 1000) / 1000));
                    let diffTime = timeSensor.utc - lastTime;
                    if (diffTime < animDuration) duration = animDuration - diffTime;
                    normal_timerUpdateSecSmooth = timer.createTimer(duration, animDuration, (function (option) {
                      lastTime = timeSensor.utc;
                      secAngle = 0 + (360*6)*(timeSensor.second + ((timeSensor.utc % 1000) / 1000))/360;
                      startSecAnim(secAngle, animDuration);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.AOD) {
                  if (!idle_timerUpdateSec) {
                    let animDelay = timeSensor.utc % 1000;
                    let animRepeat = 1000;
                    idle_timerUpdateSec = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, true);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.AOD) {
                  if (!idle_timerUpdateSecSmooth) {
                    let animDelay = 0;
                    let animRepeat = 1000/15;
                    idle_timerUpdateSecSmooth = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, false);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


                weather_few_days();
              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerUpdateSec) {
                  timer.stopTimer(normal_timerUpdateSec);
                  normal_timerUpdateSec = undefined;
                }
                if (normal_timerUpdateSecSmooth) {
                  timer.stopTimer(normal_timerUpdateSecSmooth);
                  normal_timerUpdateSecSmooth = undefined;
                }
                if (idle_timerUpdateSec) {
                  timer.stopTimer(idle_timerUpdateSec);
                  idle_timerUpdateSec = undefined;
                }
                if (idle_timerUpdateSecSmooth) {
                  timer.stopTimer(idle_timerUpdateSecSmooth);
                  idle_timerUpdateSecSmooth = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
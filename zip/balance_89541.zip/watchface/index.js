/*
** Facemaker bundle tool v0.0.3
* *huamiOS watchface js version v4.4.0.1
* *Copyright © Huami. All Rights Reserved
*/


try {
	(() => {
		var __$$app$$__ = __$$hmAppManager$$__.currentApp;
		var __$$module$$__ = __$$app$$__.current;

		//drink is a name,can modify
		var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

		'use strict';

		//dynamic modify start
		let normal_img0 = '';
		let normal_img1 = '';
		let normal_img2 = '';
		let normal_img3 = '';
		let normal_weather_imageset5 = '';
		let normal_img6 = '';
		let normal_temperature_current_imagecombo7 = '';
		let normal_temperature_low_imagecombo8 = '';
		let normal_temperature_high_imagecombo9 = '';
		let normal_img10 = '';
		let normal_img11 = '';
		let normal_img12 = '';
		let normal_weather_imageset13 = '';
		let normal_img15 = '';
		let normal_steps_imagecombo16 = '';
		let normal_img18 = '';
		let normal_distance_imagecombo19 = '';
		let normal_calories_imagecombo21 = '';
		let normal_img22 = '';
		let normal_heart_current_imagecombo24 = '';
		let normal_img25 = '';
		let normal_battery_imagecombo27 = '';
		let normal_img28 = '';
		let normal_sunrise_text30 = '';
		let normal_sunset_text31 = '';
		let normal_img32 = '';
		let normal_week_imageset34 = '';
		let normal_month_imageset35 = '';
		let normal_date_imagecombo36 = '';
		let normal_hour_imagecombo38 = '';
		let normal_minute_imagecombo39 = '';
		let normal_img40 = '';
		let normal_second_imagecombo41 = '';
		let normal_img42 = '';
		let normal_calories_shortcut45 = '';
		let normal_heart_shortcut46 = '';
		let normal_steps_shortcut47 = '';
		let normal_alarm_shortcut48 = '';
		let normal_countdown_shortcut49 = '';
		let normal_stopwatch_shortcut50 = '';
		let normal_calendar_shortcut51 = '';
		let normal_sun_shortcut52 = '';
		let normal_weather_shortcut53 = '';
		let idle_week_imageset55 = '';
		let idle_month_imageset56 = '';
		let idle_date_imagecombo57 = '';
		let idle_hour_imagecombo59 = '';
		let idle_minute_imagecombo60 = '';
		let idle_img61 = '';
		let idle_img62 = '';
		let idle_img63 = '';
		//dynamic modify end

		//not required
		const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

		__$$module$$__.module = DeviceRuntimeCore.WatchFace({
			init_view() {

				const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);
				let screenType = hmSetting.getScreenType();

				normal_img0 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					src: '0002.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img1 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					src: '0003.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img2 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 212,
					y: 363,
					w: 234,
					h: 4,
					src: '0004.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img3 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 73,
					y: 421,
					w: 330,
					h: 4,
					src: '0005.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_weather_imageset5 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
					x: 0,
					y: 0,
					image_array: ["0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png","0023.png","0024.png","0025.png","0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png","0033.png"],
					image_length: 29,
					type: hmUI.data_type.WEATHER_CURRENT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img6 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					src: '0003.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_temperature_current_imagecombo7 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 235,
					y: 123,
					font_array: ["0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png","0043.png"],
					padding: false,
					h_space: -7,
					unit_sc: ["0045.png"],
					unit_tc: ["0045.png"],
					unit_en: ["0045.png"],
					negative_image: ["0044.png"],
					invalid_image: ["0044.png"],
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.WEATHER_CURRENT,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_temperature_low_imagecombo8 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 157,
					y: 18,
					font_array: ["0046.png","0047.png","0048.png","0049.png","0050.png","0051.png","0052.png","0053.png","0054.png","0055.png"],
					padding: false,
					h_space: 0,
					unit_sc: ["0057.png"],
					unit_tc: ["0057.png"],
					unit_en: ["0057.png"],
					negative_image: ["0056.png"],
					invalid_image: ["0056.png"],
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.WEATHER_LOW,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_temperature_high_imagecombo9 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 239,
					y: 18,
					font_array: ["0046.png","0047.png","0048.png","0049.png","0050.png","0051.png","0052.png","0053.png","0054.png","0055.png"],
					padding: false,
					h_space: 0,
					unit_sc: ["0057.png"],
					unit_tc: ["0057.png"],
					unit_en: ["0057.png"],
					negative_image: ["0056.png"],
					invalid_image: ["0056.png"],
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.WEATHER_HIGH,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img10 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 231,
					y: 19,
					w: 17,
					h: 37,
					src: '0058.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img11 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 133,
					y: 24,
					w: 27,
					h: 27,
					src: '0059.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img12 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 321,
					y: 24,
					w: 27,
					h: 27,
					src: '0060.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_weather_imageset13 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
					x: 147,
					y: 73,
					image_array: ["0061.png","0062.png","0063.png","0064.png","0065.png","0066.png","0067.png","0066.png","0067.png","0068.png","0069.png","0070.png","0071.png","0072.png","0073.png","0074.png","0075.png","0076.png","0069.png","0077.png","0078.png","0069.png","0079.png","0080.png","0069.png","0081.png","0082.png","0083.png","0084.png"],
					image_length: 29,
					type: hmUI.data_type.WEATHER_CURRENT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img15 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 238,
					y: 310,
					w: 56,
					h: 42,
					src: '0085.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_steps_imagecombo16 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 307,
					y: 312,
					font_array: ["0086.png","0087.png","0088.png","0089.png","0090.png","0091.png","0092.png","0093.png","0094.png","0095.png"],
					padding: false,
					h_space: -2,
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.STEP,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img18 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 71,
					y: 377,
					w: 36,
					h: 29,
					src: '0096.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_distance_imagecombo19 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 104,
					y: 375,
					font_array: ["0097.png","0098.png","0099.png","0100.png","0101.png","0102.png","0103.png","0104.png","0105.png","0106.png"],
					padding: false,
					h_space: -3,
					dot_image: '0107.png',
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.DISTANCE,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_calories_imagecombo21 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 217,
					y: 375,
					font_array: ["0097.png","0098.png","0099.png","0100.png","0101.png","0102.png","0103.png","0104.png","0105.png","0106.png"],
					padding: false,
					h_space: -3,
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.CAL,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img22 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 191,
					y: 376,
					w: 27,
					h: 37,
					src: '0108.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_heart_current_imagecombo24 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 338,
					y: 375,
					font_array: ["0109.png","0110.png","0111.png","0112.png","0113.png","0114.png","0115.png","0116.png","0117.png","0118.png"],
					padding: false,
					h_space: -3,
					invalid_image: '0119.png',
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.HEART,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img25 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 302,
					y: 373,
					w: 41,
					h: 41,
					src: '0120.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_battery_imagecombo27 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 30,
					y: 325,
					font_array: ["0121.png","0122.png","0123.png","0124.png","0125.png","0126.png","0127.png","0128.png","0129.png","0130.png"],
					padding: false,
					h_space: -3,
					unit_sc: '0131.png',
					unit_tc: '0131.png',
					unit_en: '0131.png',
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.BATTERY,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img28 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 40,
					y: 301,
					w: 46,
					h: 22,
					src: '0132.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_sunrise_text30 = hmUI.createWidget(hmUI.widget.TEXT, {
					x: 125,
					y: 429,
					w: 100,
					h: 28,
					color: 0xFFFFFF,
					text_size: 28,
					align_h: hmUI.align.CENTER_H,
					align_v: hmUI.align.CENTER_V,
					text_style: hmUI.text_style.NONE,
					font: 'fonts/Roboto-Medium.ttf',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_sunset_text31 = hmUI.createWidget(hmUI.widget.TEXT, {
					x: 248,
					y: 429,
					w: 100,
					h: 28,
					color: 0xFFFFFF,
					text_size: 28,
					align_h: hmUI.align.CENTER_H,
					align_v: hmUI.align.CENTER_V,
					text_style: hmUI.text_style.NONE,
					font: 'fonts/Roboto-Medium.ttf',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img32 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 224,
					y: 431,
					w: 32,
					h: 27,
					src: '0133.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_week_imageset34 = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
					x: 142,
					y: 248,
					week_en: ["0134.png","0135.png","0136.png","0137.png","0138.png","0139.png","0140.png"],
					week_tc: ["0134.png","0135.png","0136.png","0137.png","0138.png","0139.png","0140.png"],
					week_sc: ["0134.png","0135.png","0136.png","0137.png","0138.png","0139.png","0140.png"],
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_month_imageset35 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
					month_startX: 141,
					month_startY: 318,
					month_sc_array: ["0141.png","0142.png","0143.png","0144.png","0145.png","0146.png","0147.png","0148.png","0149.png","0150.png","0151.png","0152.png"],
					month_tc_array: ["0141.png","0142.png","0143.png","0144.png","0145.png","0146.png","0147.png","0148.png","0149.png","0150.png","0151.png","0152.png"],
					month_en_array: ["0141.png","0142.png","0143.png","0144.png","0145.png","0146.png","0147.png","0148.png","0149.png","0150.png","0151.png","0152.png"],
					month_is_character: true,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_date_imagecombo36 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
					day_startX: 146,
					day_startY: 281,
					day_sc_array: ["0153.png","0154.png","0155.png","0156.png","0157.png","0158.png","0159.png","0160.png","0161.png","0162.png"],
					day_tc_array: ["0153.png","0154.png","0155.png","0156.png","0157.png","0158.png","0159.png","0160.png","0161.png","0162.png"],
					day_en_array: ["0153.png","0154.png","0155.png","0156.png","0157.png","0158.png","0159.png","0160.png","0161.png","0162.png"],
					day_zero: true,
					day_space: -5,
					day_align: hmUI.align.CENTER_H,
					day_is_character: false,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_hour_imagecombo38 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					hour_startX: 216,
					hour_startY: 184,
					hour_array: ["0163.png","0164.png","0165.png","0166.png","0167.png","0168.png","0169.png","0170.png","0171.png","0172.png"],
					hour_zero: true,
					hour_space: -14,
					hour_align: hmUI.align.CENTER_H,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_minute_imagecombo39 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					minute_startX: 350,
					minute_startY: 184,
					minute_array: ["0163.png","0164.png","0165.png","0166.png","0167.png","0168.png","0169.png","0170.png","0171.png","0172.png"],
					minute_zero: true,
					minute_space: -14,
					minute_align: hmUI.align.CENTER_H,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img40 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 335,
					y: 196,
					w: 27,
					h: 80,
					src: '0173.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_second_imagecombo41 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					second_startX: 366,
					second_startY: 120,
					second_array: ["0174.png","0175.png","0176.png","0177.png","0178.png","0179.png","0180.png","0181.png","0182.png","0183.png"],
					second_zero: true,
					second_space: -6,
					second_align: hmUI.align.CENTER_H,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img42 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					src: '0184.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_calories_shortcut45 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 198,
					y: 367,
					w: 100,
					h: 48,
					src: '',
					type: hmUI.data_type.CAL,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_heart_shortcut46 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 321,
					y: 368,
					w: 100,
					h: 51,
					src: '',
					type: hmUI.data_type.HEART,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_steps_shortcut47 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 277,
					y: 304,
					w: 132,
					h: 54,
					src: '',
					type: hmUI.data_type.STEP,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_alarm_shortcut48 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 232,
					y: 190,
					w: 100,
					h: 100,
					src: '',
					type: hmUI.data_type.ALARM_CLOCK,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_countdown_shortcut49 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 361,
					y: 190,
					w: 100,
					h: 100,
					src: '',
					type: hmUI.data_type.COUNT_DOWN,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_stopwatch_shortcut50 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 369,
					y: 121,
					w: 75,
					h: 57,
					src: '',
					type: hmUI.data_type.STOP_WATCH,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_calendar_shortcut51 = hmUI.createWidget(hmUI.widget.BUTTON, {
					x: 133,
					y: 245,
					w: 75,
					h: 100,
					text: '',
					normal_src: '',
					press_src: '',
					click_func: () => {
						hmApp.startApp({ url: 'ScheduleCalScreen', native: true });
					},
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_sun_shortcut52 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 193,
					y: 429,
					w: 100,
					h: 45,
					src: '',
					type: hmUI.data_type.SUN_CURRENT,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_weather_shortcut53 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 67,
					y: 80,
					w: 172,
					h: 98,
					src: '',
					type: hmUI.data_type.WEATHER_CURRENT,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				idle_week_imageset55 = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
					x: 142,
					y: 248,
					week_en: ["0134.png","0135.png","0136.png","0137.png","0138.png","0139.png","0140.png"],
					week_tc: ["0134.png","0135.png","0136.png","0137.png","0138.png","0139.png","0140.png"],
					week_sc: ["0134.png","0135.png","0136.png","0137.png","0138.png","0139.png","0140.png"],
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_month_imageset56 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
					month_startX: 141,
					month_startY: 318,
					month_sc_array: ["0141.png","0142.png","0143.png","0144.png","0145.png","0146.png","0147.png","0148.png","0149.png","0150.png","0151.png","0152.png"],
					month_tc_array: ["0141.png","0142.png","0143.png","0144.png","0145.png","0146.png","0147.png","0148.png","0149.png","0150.png","0151.png","0152.png"],
					month_en_array: ["0141.png","0142.png","0143.png","0144.png","0145.png","0146.png","0147.png","0148.png","0149.png","0150.png","0151.png","0152.png"],
					month_is_character: true,
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_date_imagecombo57 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
					day_startX: 146,
					day_startY: 281,
					day_sc_array: ["0153.png","0154.png","0155.png","0156.png","0157.png","0158.png","0159.png","0160.png","0161.png","0162.png"],
					day_tc_array: ["0153.png","0154.png","0155.png","0156.png","0157.png","0158.png","0159.png","0160.png","0161.png","0162.png"],
					day_en_array: ["0153.png","0154.png","0155.png","0156.png","0157.png","0158.png","0159.png","0160.png","0161.png","0162.png"],
					day_zero: true,
					day_space: -5,
					day_align: hmUI.align.CENTER_H,
					day_is_character: false,
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_hour_imagecombo59 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					hour_startX: 216,
					hour_startY: 184,
					hour_array: ["0163.png","0164.png","0165.png","0166.png","0167.png","0168.png","0169.png","0170.png","0171.png","0172.png"],
					hour_zero: true,
					hour_space: -14,
					hour_align: hmUI.align.CENTER_H,
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_minute_imagecombo60 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					minute_startX: 350,
					minute_startY: 184,
					minute_array: ["0163.png","0164.png","0165.png","0166.png","0167.png","0168.png","0169.png","0170.png","0171.png","0172.png"],
					minute_zero: true,
					minute_space: -14,
					minute_align: hmUI.align.CENTER_H,
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_img61 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 335,
					y: 196,
					w: 27,
					h: 80,
					src: '0173.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_img62 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					src: '0185.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_img63 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					src: '0184.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				function updateWeather() {
					let tideData = weatherSensor.getForecastWeather().tideData;
					normal_sunrise_text30.setProperty(hmUI.prop.TEXT, tideData.data[0].sunrise.hour.toString().padStart(2, '0') + ':' + tideData.data[0].sunrise.minute.toString().padStart(2, '0'));
					normal_sunset_text31.setProperty(hmUI.prop.TEXT, tideData.data[0].sunset.hour.toString().padStart(2, '0') + ':' + tideData.data[0].sunset.minute.toString().padStart(2, '0'));
				}

				weatherSensor.addEventListener(hmSensor.event.CHANGE, function() {
					updateWeather();
				});

				const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
					resume_call: (function () {
						updateWeather();
					}),
					pause_call: (function () {
					}),
				})
			},

		onInit() {
			console.log('index page.js on init invoke')
			this.init_view()
		},
		onReady() {
			console.log('index page.js on ready invoke')
		},
		onShow() {
			console.log('index page.js on show invoke')
		},
		onHide() {
			console.log('index page.js on hide invoke')
		},
		onDestroy() {
			console.log('index page.js on destroy invoke')
		},
	});	})()
} catch (e) {
	console.log(e)
}
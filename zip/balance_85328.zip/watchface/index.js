﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js


//////////////////////////////////////////////////////////////////////////////////////////////////

        // Start color Style
        let colornumber_main = 1
        let totalcolors_main = 6
        let namecolor_main = ''
        let Folder = ''

        function click_Color() {
            if(colornumber_main>=totalcolors_main) {
            colornumber_main=1;
                }
            else {
                colornumber_main=colornumber_main+1;
            }

if ( colornumber_main == 1) { namecolor_main = "RED"
Folder = "Red/"
}
if ( colornumber_main == 2) { namecolor_main = "BLUE"
Folder = "Blue/"
}
if ( colornumber_main == 3) { namecolor_main = "GREEN"
Folder = "Green/"
}
if ( colornumber_main == 4) { namecolor_main = "ORANGE"
Folder = "Orange/"
}
if ( colornumber_main == 5) { namecolor_main = "YELLOW"
Folder = "Yellow/"
}
if ( colornumber_main == 6) { namecolor_main = "WHITE"
Folder = "White/"
}
hmUI.showToast({text: namecolor_main });

             //hmUI.showToast({text: "color " + parseInt(colornumber_main) });
             normal_background_bg_img.setProperty(hmUI.prop.SRC, "Bg" + parseInt(colornumber_main) + ".png");

            normal_digital_clock_img_time_minute.setProperty(hmUI.prop.MORE, {
              minute_startX: 365,
              minute_startY: 121,
              minute_array: [Folder+"min_0.png",Folder+"min_1.png",Folder+"min_2.png",Folder+"min_3.png",Folder+"min_4.png",Folder+"min_5.png",Folder+"min_6.png",Folder+"min_7.png",Folder+"min_8.png",Folder+"min_9.png"],
              minute_zero: 1,
              minute_space: -6,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
                           
        }

//////////////////////////////////////////////////////////////////////////////////////////////////

        // Start color Style


        let colornumber_mainM = 1
        let totalcolors_mainM = 6
        let namecolor_mainM = ''

        function click_ColorM() {

            if(colornumber_mainM >= totalcolors_mainM) {
            colornumber_mainM=1;
                }
            else {
                colornumber_mainM=colornumber_mainM+1;
            }

if ( colornumber_mainM == 1) { namecolor_mainM = "RED"
Folder = "Red/"
}
if ( colornumber_mainM == 2) { namecolor_mainM = "BLUE"
Folder = "Blue/"
}
if ( colornumber_mainM == 3) { namecolor_mainM = "GREEN"
Folder = "Green/"
}
if ( colornumber_mainM == 4) { namecolor_mainM = "ORANGE"
Folder = "Orange/"
}
if ( colornumber_mainM == 5) { namecolor_mainM = "YELLOW"
Folder = "Yellow/"
}
if ( colornumber_mainM == 6) { namecolor_mainM = "WHITE"
Folder = "White/"
}
hmUI.showToast({text: namecolor_mainM });


            normal_digital_clock_img_time_minute.setProperty(hmUI.prop.MORE, {
              minute_startX: 365,
              minute_startY: 121,
              minute_array: [Folder+"min_0.png",Folder+"min_1.png",Folder+"min_2.png",Folder+"min_3.png",Folder+"min_4.png",Folder+"min_5.png",Folder+"min_6.png",Folder+"min_7.png",Folder+"min_8.png",Folder+"min_9.png"],
              minute_zero: 1,
              minute_space: -6,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
                           
        }

/////////////////////////////////////////////////////////////////////////////////////////////////
        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_city_name_text = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_distance_text_text_img = ''
        let normal_calorie_linear_scale = ''
        let normal_calorie_current_text_img = ''
        let normal_heart_rate_linear_scale = ''
        let normal_heart_rate_text_text_img = ''
        let normal_step_linear_scale = ''
        let normal_step_current_text_img = ''
        let normal_battery_linear_scale = ''
        let normal_battery_text_text_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time_second = ''
        let normal_digital_clock_img_time_minute = ''
        let normal_digital_clock_img_time_hour = ''
        let idle_background_bg_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_city_name_text = ''
        let idle_weather_image_progress_img_level = ''
        let idle_temperature_current_text_img = ''
        let idle_moon_image_progress_img_level = ''
        let idle_distance_text_text_img = ''
        let idle_calorie_linear_scale = ''
        let idle_calorie_current_text_img = ''
        let idle_heart_rate_linear_scale = ''
        let idle_heart_rate_text_text_img = ''
        let idle_step_linear_scale = ''
        let idle_step_current_text_img = ''
        let idle_battery_linear_scale = ''
        let idle_battery_text_text_img = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_week_img = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time_minute = ''
        let idle_digital_clock_img_time_hour = ''
        let normal_step_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_moon_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'Bg1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 80,
              y: 331,
              src: 'BT_OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 211,
              y: 165,
              src: 'Alarm_icon.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 206,
              y: 349,
              w: 108,
              h: 34,
              text_size: 22,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 179,
              y: 421,
              image_array: ["Weather_01.png","Weather_02.png","Weather_03.png","Weather_04.png","Weather_05.png","Weather_06.png","Weather_07.png","Weather_08.png","Weather_09.png","Weather_10.png","Weather_11.png","Weather_12.png","Weather_13.png","Weather_14.png","Weather_15.png","Weather_16.png","Weather_17.png","Weather_18.png","Weather_19.png","Weather_20.png","Weather_21.png","Weather_22.png","Weather_23.png","Weather_24.png","Weather_25.png","Weather_26.png","Weather_27.png","Weather_28.png","Weather_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 227,
              y: 436,
              font_array: ["num_0.png","num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png"],
              padding: false,
              h_space: -4,
              unit_sc: 'Temp_unit.png',
              unit_tc: 'Temp_unit.png',
              unit_en: 'Temp_unit.png',
              imperial_unit_sc: 'Temp_unit.png',
              imperial_unit_tc: 'Temp_unit.png',
              imperial_unit_en: 'Temp_unit.png',
              negative_image: 'Temp_Error.png',
              invalid_image: 'Temp_Error.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const temperatureUnit = hmSetting.getTemperatureUnit();
            //start of ignored block
            if (temperatureUnit == 1) {
              normal_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
                x: 227,
                y: 436,
                font_array: ["num_0.png","num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png"],
                padding: false,
                h_space: -4,
                unit_sc: 'Temp_unit.png',
                unit_tc: 'Temp_unit.png',
                unit_en: 'Temp_unit.png',
                imperial_unit_sc: 'Temp_unit.png',
                imperial_unit_tc: 'Temp_unit.png',
                imperial_unit_en: 'Temp_unit.png',
                negative_image: 'Temp_Error.png',
                invalid_image: 'Temp_Error.png',
                align_h: hmUI.align.CENTER_H,
                type: hmUI.data_type.WEATHER_CURRENT,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
            };
            //end of ignored block

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 164,
              y: 353,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 168,
              y: 388,
              font_array: ["num_0.png","num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png"],
              padding: false,
              h_space: -2,
              unit_sc: 'Dis_KM.png',
              unit_tc: 'Dis_KM.png',
              unit_en: 'Dis_KM.png',
              imperial_unit_sc: 'Dis_Mi.png',
              imperial_unit_tc: 'Dis_Mi.png',
              imperial_unit_en: 'Dis_Mi.png',
              dot_image: 'Dis_Dot.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            if (screenType != hmSetting.screen_type.AOD) {
              normal_calorie_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // normal_calorie_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 308,
              // start_y: 198,
              // color: 0xFFFF8C00,
              // lenght: 100,
              // line_width: 9,
              // line_cap: Rounded,
              // vertical: False,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const calorie = hmSensor.createSensor(hmSensor.id.CALORIE);
            calorie.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 292,
              y: 217,
              font_array: ["num_0.png","num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png"],
              padding: false,
              h_space: -2,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (screenType != hmSetting.screen_type.AOD) {
              normal_heart_rate_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // normal_heart_rate_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 129,
              // start_y: 198,
              // color: 0xFFFF2020,
              // lenght: 61,
              // line_width: 9,
              // line_cap: Rounded,
              // vertical: False,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const heart_rate = hmSensor.createSensor(hmSensor.id.HEART);
            heart_rate.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 112,
              y: 217,
              font_array: ["num_0.png","num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png"],
              padding: false,
              h_space: 0,
              invalid_image: 'num_0.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (screenType != hmSetting.screen_type.AOD) {
              normal_step_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // normal_step_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 126,
              // start_y: 319,
              // color: 0xFF0080FF,
              // lenght: 97,
              // line_width: 9,
              // line_cap: Rounded,
              // vertical: False,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 114,
              y: 279,
              font_array: ["num_0.png","num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png"],
              padding: false,
              h_space: -4,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (screenType != hmSetting.screen_type.AOD) {
              normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 322,
              // start_y: 319,
              // color: 0xFFFEDB00,
              // lenght: 83,
              // line_width: 9,
              // line_cap: Rounded,
              // vertical: False,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 317,
              y: 278,
              font_array: ["num_0.png","num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png"],
              padding: false,
              h_space: -4,
              unit_sc: 'Unit.png',
              unit_tc: 'Unit.png',
              unit_en: 'Unit.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 232,
              month_startY: 45,
              month_sc_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_tc_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_en_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 132,
              day_startY: 87,
              day_sc_array: ["num_0.png","num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png"],
              day_tc_array: ["num_0.png","num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png"],
              day_en_array: ["num_0.png","num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png"],
              day_zero: 0,
              day_space: -4,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 83,
              y: 29,
              week_en: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              week_tc: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              week_sc: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 56,
              am_y: 179,
              am_sc_path: 'Clock_AM.png',
              am_en_path: 'Clock_AM.png',
              pm_x: 56,
              pm_y: 179,
              pm_sc_path: 'Clock_PM.png',
              pm_en_path: 'Clock_PM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_second = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              second_startX: 380,
              second_startY: 94,
              second_array: ["SEC_0.png","SEC_1.png","SEC_2.png","SEC_3.png","SEC_4.png","SEC_5.png","SEC_6.png","SEC_7.png","SEC_8.png","SEC_9.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 365,
              minute_startY: 121,
              minute_array: ["min_0.png","min_1.png","min_2.png","min_3.png","min_4.png","min_5.png","min_6.png","min_7.png","min_8.png","min_9.png"],
              minute_zero: 1,
              minute_space: -6,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 233,
              hour_startY: 92,
              hour_array: ["Hour_0.png","Hour_1.png","Hour_2.png","Hour_3.png","Hour_4.png","Hour_5.png","Hour_6.png","Hour_7.png","Hour_8.png","Hour_9.png"],
              hour_zero: 1,
              hour_space: -10,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'Bg1.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 80,
              y: 331,
              src: 'BT_OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 211,
              y: 165,
              src: 'Alarm_icon.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 206,
              y: 349,
              w: 108,
              h: 34,
              text_size: 22,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 179,
              y: 421,
              image_array: ["Weather_01.png","Weather_02.png","Weather_03.png","Weather_04.png","Weather_05.png","Weather_06.png","Weather_07.png","Weather_08.png","Weather_09.png","Weather_10.png","Weather_11.png","Weather_12.png","Weather_13.png","Weather_14.png","Weather_15.png","Weather_16.png","Weather_17.png","Weather_18.png","Weather_19.png","Weather_20.png","Weather_21.png","Weather_22.png","Weather_23.png","Weather_24.png","Weather_25.png","Weather_26.png","Weather_27.png","Weather_28.png","Weather_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 227,
              y: 436,
              font_array: ["num_0.png","num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png"],
              padding: false,
              h_space: -4,
              unit_sc: 'Temp_unit.png',
              unit_tc: 'Temp_unit.png',
              unit_en: 'Temp_unit.png',
              imperial_unit_sc: 'Temp_unit.png',
              imperial_unit_tc: 'Temp_unit.png',
              imperial_unit_en: 'Temp_unit.png',
              negative_image: 'Temp_Error.png',
              invalid_image: 'Temp_Error.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            //start of ignored block
            if (temperatureUnit == 1) {
              idle_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
                x: 227,
                y: 436,
                font_array: ["num_0.png","num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png"],
                padding: false,
                h_space: -4,
                unit_sc: 'Temp_unit.png',
                unit_tc: 'Temp_unit.png',
                unit_en: 'Temp_unit.png',
                imperial_unit_sc: 'Temp_unit.png',
                imperial_unit_tc: 'Temp_unit.png',
                imperial_unit_en: 'Temp_unit.png',
                negative_image: 'Temp_Error.png',
                invalid_image: 'Temp_Error.png',
                align_h: hmUI.align.CENTER_H,
                type: hmUI.data_type.WEATHER_CURRENT,
                show_level: hmUI.show_level.ONLY_AOD,
              });
            };
            //end of ignored block

            idle_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 164,
              y: 353,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 168,
              y: 388,
              font_array: ["num_0.png","num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png"],
              padding: false,
              h_space: -2,
              unit_sc: 'Dis_KM.png',
              unit_tc: 'Dis_KM.png',
              unit_en: 'Dis_KM.png',
              imperial_unit_sc: 'Dis_Mi.png',
              imperial_unit_tc: 'Dis_Mi.png',
              imperial_unit_en: 'Dis_Mi.png',
              dot_image: 'Dis_Dot.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            if (screenType == hmSetting.screen_type.AOD) {
              idle_calorie_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // idle_calorie_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 308,
              // start_y: 198,
              // color: 0xFFFF8C00,
              // lenght: 100,
              // line_width: 9,
              // line_cap: Rounded,
              // vertical: False,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 292,
              y: 217,
              font_array: ["num_0.png","num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png"],
              padding: false,
              h_space: -2,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            if (screenType == hmSetting.screen_type.AOD) {
              idle_heart_rate_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // idle_heart_rate_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 129,
              // start_y: 198,
              // color: 0xFFFF2020,
              // lenght: 61,
              // line_width: 9,
              // line_cap: Rounded,
              // vertical: False,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 112,
              y: 217,
              font_array: ["num_0.png","num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png"],
              padding: false,
              h_space: 0,
              invalid_image: 'num_0.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            if (screenType == hmSetting.screen_type.AOD) {
              idle_step_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // idle_step_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 126,
              // start_y: 319,
              // color: 0xFF0080FF,
              // lenght: 97,
              // line_width: 9,
              // line_cap: Rounded,
              // vertical: False,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 114,
              y: 279,
              font_array: ["num_0.png","num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png"],
              padding: false,
              h_space: -4,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            if (screenType == hmSetting.screen_type.AOD) {
              idle_battery_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // idle_battery_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 322,
              // start_y: 319,
              // color: 0xFFFEDB00,
              // lenght: 83,
              // line_width: 9,
              // line_cap: Rounded,
              // vertical: False,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 317,
              y: 278,
              font_array: ["num_0.png","num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png"],
              padding: false,
              h_space: -4,
              unit_sc: 'Unit.png',
              unit_tc: 'Unit.png',
              unit_en: 'Unit.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 232,
              month_startY: 45,
              month_sc_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_tc_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_en_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 132,
              day_startY: 87,
              day_sc_array: ["num_0.png","num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png"],
              day_tc_array: ["num_0.png","num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png"],
              day_en_array: ["num_0.png","num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png"],
              day_zero: 0,
              day_space: -4,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 83,
              y: 29,
              week_en: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              week_tc: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              week_sc: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 56,
              am_y: 179,
              am_sc_path: 'Clock_AM.png',
              am_en_path: 'Clock_AM.png',
              pm_x: 56,
              pm_y: 179,
              pm_sc_path: 'Clock_PM.png',
              pm_en_path: 'Clock_PM.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 365,
              minute_startY: 121,
              minute_array: ["minW_0.png","minW_1.png","minW_2.png","minW_3.png","minW_4.png","minW_5.png","minW_6.png","minW_7.png","minW_8.png","minW_9.png"],
              minute_zero: 1,
              minute_space: -6,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 233,
              hour_startY: 92,
              hour_array: ["Hour_0.png","Hour_1.png","Hour_2.png","Hour_3.png","Hour_4.png","Hour_5.png","Hour_6.png","Hour_7.png","Hour_8.png","Hour_9.png"],
              hour_zero: 1,
              hour_space: -10,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 49,
              y: 271,
              w: 63,
              h: 58,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 117,
              y: 212,
              w: 76,
              h: 44,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 242,
              y: 204,
              w: 96,
              h: 50,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 174,
              y: 426,
              w: 56,
              h: 48,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 160,
              y: 350,
              w: 41,
              h: 39,
              type: hmUI.data_type.MOON_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 245,
              y: 430,
              w: 64,
              h: 43,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 52,
              y: 210,
              w: 53,
              h: 49,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 371,
              y: 85,
              w: 58,
              h: 38,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 270,
              y: 111,
              w: 65,
              h: 53,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 201,
              y: 156,
              w: 32,
              h: 28,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 258,
              y: 276,
              w: 71,
              h: 43,
              text: '',
              color: 0xFFFF8C00,
              text_size: 27,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PowerSaveHintScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 7,
              y: 182,
              w: 42,
              h: 41,
              text: '',
              color: 0xFFFF8C00,
              text_size: 27,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'Settings_homeScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 126,
              y: 70,
              w: 62,
              h: 66,
              text: '',
              color: 0xFFFF8C00,
              text_size: 27,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 324,
              y: 353,
              w: 90,
              h: 36,
              text: '',
              color: 0xFFFF8C00,
              text_size: 27,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'SportListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 433,
              y: 237,
              w: 43,
              h: 58,
              text: '',
              color: 0xFFFF8C00,
              text_size: 27,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                // Change color Style
click_Color()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 385,
              y: 128,
              w: 45,
              h: 44,
              text: '',
              color: 0xFFFF8C00,
              text_size: 27,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                //Change color minute
click_ColorM()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            function scale_call() {
              console.log('scale_call()');

              console.log('Weather city name');
              let weatherData = weatherSensor.getForecastWeather();
              normal_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

                console.log('update scales CALORIE');
                
                let valueCalories = calorie.current;
                let targetCalories = calorie.target;
                let progressCalories = valueCalories/targetCalories;
                if (progressCalories > 1) progressCalories = 1;
                let progress_ls_normal_calorie = progressCalories;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_calorie_linear_scale
                  // initial parameters
                  let start_x_normal_calorie = 308;
                  let start_y_normal_calorie = 198;
                  let lenght_ls_normal_calorie = 100;
                  let line_width_ls_normal_calorie = 9;
                  let color_ls_normal_calorie = 0xFFFF8C00;
                  
                  // calculated parameters
                  let start_x_normal_calorie_draw = start_x_normal_calorie;
                  let start_y_normal_calorie_draw = start_y_normal_calorie;
                  lenght_ls_normal_calorie = lenght_ls_normal_calorie * progress_ls_normal_calorie;
                  let lenght_ls_normal_calorie_draw = lenght_ls_normal_calorie;
                  let line_width_ls_normal_calorie_draw = line_width_ls_normal_calorie;
                  if (lenght_ls_normal_calorie < 0){
                    lenght_ls_normal_calorie_draw = -lenght_ls_normal_calorie;
                    start_x_normal_calorie_draw = start_x_normal_calorie - lenght_ls_normal_calorie_draw;
                  };
                  
                  normal_calorie_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_calorie_draw,
                    y: start_y_normal_calorie_draw,
                    w: lenght_ls_normal_calorie_draw,
                    h: line_width_ls_normal_calorie_draw,
                    radius: 4,
                    color: color_ls_normal_calorie,
                  });
                };

                console.log('update scales HEART');
                
                let valueHeartRate = heart_rate.last;
                let targetHeartRate = 184;
                let progressHeartRate = (valueHeartRate - 30)/(targetHeartRate - 30);
                if (progressHeartRate < 0) progressHeartRate = 0;
                if (progressHeartRate > 1) progressHeartRate = 1;
                let progress_ls_normal_heart_rate = progressHeartRate;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_heart_rate_linear_scale
                  // initial parameters
                  let start_x_normal_heart_rate = 129;
                  let start_y_normal_heart_rate = 198;
                  let lenght_ls_normal_heart_rate = 61;
                  let line_width_ls_normal_heart_rate = 9;
                  let color_ls_normal_heart_rate = 0xFFFF2020;
                  
                  // calculated parameters
                  let start_x_normal_heart_rate_draw = start_x_normal_heart_rate;
                  let start_y_normal_heart_rate_draw = start_y_normal_heart_rate;
                  lenght_ls_normal_heart_rate = lenght_ls_normal_heart_rate * progress_ls_normal_heart_rate;
                  let lenght_ls_normal_heart_rate_draw = lenght_ls_normal_heart_rate;
                  let line_width_ls_normal_heart_rate_draw = line_width_ls_normal_heart_rate;
                  if (lenght_ls_normal_heart_rate < 0){
                    lenght_ls_normal_heart_rate_draw = -lenght_ls_normal_heart_rate;
                    start_x_normal_heart_rate_draw = start_x_normal_heart_rate - lenght_ls_normal_heart_rate_draw;
                  };
                  
                  normal_heart_rate_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_heart_rate_draw,
                    y: start_y_normal_heart_rate_draw,
                    w: lenght_ls_normal_heart_rate_draw,
                    h: line_width_ls_normal_heart_rate_draw,
                    radius: 4,
                    color: color_ls_normal_heart_rate,
                  });
                };

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_ls_normal_step = progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_linear_scale
                  // initial parameters
                  let start_x_normal_step = 126;
                  let start_y_normal_step = 319;
                  let lenght_ls_normal_step = 97;
                  let line_width_ls_normal_step = 9;
                  let color_ls_normal_step = 0xFF0080FF;
                  
                  // calculated parameters
                  let start_x_normal_step_draw = start_x_normal_step;
                  let start_y_normal_step_draw = start_y_normal_step;
                  lenght_ls_normal_step = lenght_ls_normal_step * progress_ls_normal_step;
                  let lenght_ls_normal_step_draw = lenght_ls_normal_step;
                  let line_width_ls_normal_step_draw = line_width_ls_normal_step;
                  if (lenght_ls_normal_step < 0){
                    lenght_ls_normal_step_draw = -lenght_ls_normal_step;
                    start_x_normal_step_draw = start_x_normal_step - lenght_ls_normal_step_draw;
                  };
                  
                  normal_step_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_step_draw,
                    y: start_y_normal_step_draw,
                    w: lenght_ls_normal_step_draw,
                    h: line_width_ls_normal_step_draw,
                    radius: 4,
                    color: color_ls_normal_step,
                  });
                };

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_ls_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_linear_scale
                  // initial parameters
                  let start_x_normal_battery = 322;
                  let start_y_normal_battery = 319;
                  let lenght_ls_normal_battery = 83;
                  let line_width_ls_normal_battery = 9;
                  let color_ls_normal_battery = 0xFFFEDB00;
                  
                  // calculated parameters
                  let start_x_normal_battery_draw = start_x_normal_battery;
                  let start_y_normal_battery_draw = start_y_normal_battery;
                  lenght_ls_normal_battery = lenght_ls_normal_battery * progress_ls_normal_battery;
                  let lenght_ls_normal_battery_draw = lenght_ls_normal_battery;
                  let line_width_ls_normal_battery_draw = line_width_ls_normal_battery;
                  if (lenght_ls_normal_battery < 0){
                    lenght_ls_normal_battery_draw = -lenght_ls_normal_battery;
                    start_x_normal_battery_draw = start_x_normal_battery - lenght_ls_normal_battery_draw;
                  };
                  
                  normal_battery_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_battery_draw,
                    y: start_y_normal_battery_draw,
                    w: lenght_ls_normal_battery_draw,
                    h: line_width_ls_normal_battery_draw,
                    radius: 4,
                    color: color_ls_normal_battery,
                  });
                };

              console.log('Weather city name');
              idle_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

                console.log('update scales CALORIE');
                let progress_ls_idle_calorie = progressCalories;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_calorie_linear_scale
                  // initial parameters
                  let start_x_idle_calorie = 308;
                  let start_y_idle_calorie = 198;
                  let lenght_ls_idle_calorie = 100;
                  let line_width_ls_idle_calorie = 9;
                  let color_ls_idle_calorie = 0xFFFF8C00;
                  
                  // calculated parameters
                  let start_x_idle_calorie_draw = start_x_idle_calorie;
                  let start_y_idle_calorie_draw = start_y_idle_calorie;
                  lenght_ls_idle_calorie = lenght_ls_idle_calorie * progress_ls_idle_calorie;
                  let lenght_ls_idle_calorie_draw = lenght_ls_idle_calorie;
                  let line_width_ls_idle_calorie_draw = line_width_ls_idle_calorie;
                  if (lenght_ls_idle_calorie < 0){
                    lenght_ls_idle_calorie_draw = -lenght_ls_idle_calorie;
                    start_x_idle_calorie_draw = start_x_idle_calorie - lenght_ls_idle_calorie_draw;
                  };
                  
                  idle_calorie_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_idle_calorie_draw,
                    y: start_y_idle_calorie_draw,
                    w: lenght_ls_idle_calorie_draw,
                    h: line_width_ls_idle_calorie_draw,
                    radius: 4,
                    color: color_ls_idle_calorie,
                  });
                };

                console.log('update scales HEART');
                let progress_ls_idle_heart_rate = progressHeartRate;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_heart_rate_linear_scale
                  // initial parameters
                  let start_x_idle_heart_rate = 129;
                  let start_y_idle_heart_rate = 198;
                  let lenght_ls_idle_heart_rate = 61;
                  let line_width_ls_idle_heart_rate = 9;
                  let color_ls_idle_heart_rate = 0xFFFF2020;
                  
                  // calculated parameters
                  let start_x_idle_heart_rate_draw = start_x_idle_heart_rate;
                  let start_y_idle_heart_rate_draw = start_y_idle_heart_rate;
                  lenght_ls_idle_heart_rate = lenght_ls_idle_heart_rate * progress_ls_idle_heart_rate;
                  let lenght_ls_idle_heart_rate_draw = lenght_ls_idle_heart_rate;
                  let line_width_ls_idle_heart_rate_draw = line_width_ls_idle_heart_rate;
                  if (lenght_ls_idle_heart_rate < 0){
                    lenght_ls_idle_heart_rate_draw = -lenght_ls_idle_heart_rate;
                    start_x_idle_heart_rate_draw = start_x_idle_heart_rate - lenght_ls_idle_heart_rate_draw;
                  };
                  
                  idle_heart_rate_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_idle_heart_rate_draw,
                    y: start_y_idle_heart_rate_draw,
                    w: lenght_ls_idle_heart_rate_draw,
                    h: line_width_ls_idle_heart_rate_draw,
                    radius: 4,
                    color: color_ls_idle_heart_rate,
                  });
                };

                console.log('update scales STEP');
                let progress_ls_idle_step = progressStep;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_step_linear_scale
                  // initial parameters
                  let start_x_idle_step = 126;
                  let start_y_idle_step = 319;
                  let lenght_ls_idle_step = 97;
                  let line_width_ls_idle_step = 9;
                  let color_ls_idle_step = 0xFF0080FF;
                  
                  // calculated parameters
                  let start_x_idle_step_draw = start_x_idle_step;
                  let start_y_idle_step_draw = start_y_idle_step;
                  lenght_ls_idle_step = lenght_ls_idle_step * progress_ls_idle_step;
                  let lenght_ls_idle_step_draw = lenght_ls_idle_step;
                  let line_width_ls_idle_step_draw = line_width_ls_idle_step;
                  if (lenght_ls_idle_step < 0){
                    lenght_ls_idle_step_draw = -lenght_ls_idle_step;
                    start_x_idle_step_draw = start_x_idle_step - lenght_ls_idle_step_draw;
                  };
                  
                  idle_step_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_idle_step_draw,
                    y: start_y_idle_step_draw,
                    w: lenght_ls_idle_step_draw,
                    h: line_width_ls_idle_step_draw,
                    radius: 4,
                    color: color_ls_idle_step,
                  });
                };

                console.log('update scales BATTERY');
                let progress_ls_idle_battery = progressBattery;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_battery_linear_scale
                  // initial parameters
                  let start_x_idle_battery = 322;
                  let start_y_idle_battery = 319;
                  let lenght_ls_idle_battery = 83;
                  let line_width_ls_idle_battery = 9;
                  let color_ls_idle_battery = 0xFFFEDB00;
                  
                  // calculated parameters
                  let start_x_idle_battery_draw = start_x_idle_battery;
                  let start_y_idle_battery_draw = start_y_idle_battery;
                  lenght_ls_idle_battery = lenght_ls_idle_battery * progress_ls_idle_battery;
                  let lenght_ls_idle_battery_draw = lenght_ls_idle_battery;
                  let line_width_ls_idle_battery_draw = line_width_ls_idle_battery;
                  if (lenght_ls_idle_battery < 0){
                    lenght_ls_idle_battery_draw = -lenght_ls_idle_battery;
                    start_x_idle_battery_draw = start_x_idle_battery - lenght_ls_idle_battery_draw;
                  };
                  
                  idle_battery_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_idle_battery_draw,
                    y: start_y_idle_battery_draw,
                    w: lenght_ls_idle_battery_draw,
                    h: line_width_ls_idle_battery_draw,
                    radius: 4,
                    color: color_ls_idle_battery,
                  });
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
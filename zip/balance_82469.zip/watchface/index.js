﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js


        // Start hidden analog
        let elementnumber_1 = 1
        let total_elemente = 2

        function click_elemente() {
            if(elementnumber_1==total_elemente) {
            elementnumber_1=1;
                UpdateElementeOne();
                }
            else {
                elementnumber_1=elementnumber_1+1;
                if(elementnumber_1==2) {
                  UpdateElementeTwo();
                }

            }
            if(elementnumber_1==1) hmUI.showToast({text: 'Hand clock ON'});
            if(elementnumber_1==2) hmUI.showToast({text: 'Handclock OFF'});
        }

        //Hand clock on
        function UpdateElementeOne(){
                normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.VISIBLE, true);
                normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.VISIBLE, true);
                normal_digital_clock_img_time.setProperty(hmUI.prop.VISIBLE, false);
                normal_digital_clock_hour_separator_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_digital_clock_minute_separator_img.setProperty(hmUI.prop.VISIBLE, false);

        }

        //hand clock off
        function UpdateElementeTwo(){
                normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.VISIBLE, false);
                normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.VISIBLE, false);
                normal_digital_clock_img_time.setProperty(hmUI.prop.VISIBLE, true);
                normal_digital_clock_hour_separator_img.setProperty(hmUI.prop.VISIBLE, true);
                normal_digital_clock_minute_separator_img.setProperty(hmUI.prop.VISIBLE, true);
        }


//////////////////////////////////////////////////////////////////////////////////////////////////

        // Start color change
        let colornumber_mainM = 1
        let totalcolors_mainM = 6
        let namecolor_mainM = ''

        function click_Color() {
            if(colornumber_mainM>=totalcolors_mainM) {
            colornumber_mainM=1;
                }
            else {
                colornumber_mainM=colornumber_mainM+1;
            }

if ( colornumber_mainM == 1) { namecolor_mainM = "GRAY"}
if ( colornumber_mainM == 2) { namecolor_mainM = "GREEN"}
if ( colornumber_mainM == 3) { namecolor_mainM = "YELLOW"}
if ( colornumber_mainM == 4) { namecolor_mainM = "ROSE"}
if ( colornumber_mainM == 5) { namecolor_mainM = "BLUE"}
if ( colornumber_mainM == 6) { namecolor_mainM = "ORANGE"}
hmUI.showToast({text: namecolor_mainM });

             //hmUI.showToast({text: "color " + parseInt(colornumber_main) });
             normal_background_bg_img.setProperty(hmUI.prop.SRC, "main" + parseInt(colornumber_mainM) + ".png");
                           
        }


//////////////////////////////////////////////////////////////////////////////////////////////////

        // Start color change
        let colornumber_main = 1
        let totalcolors_main = 6
        let namecolor_main = ''

        function click_ColorTOP() {
            if(colornumber_main>=totalcolors_main) {
            colornumber_main=1;
                }
            else {
                colornumber_main=colornumber_main+1;
            }

if ( colornumber_main == 1) { namecolor_main = "GRAY"}
if ( colornumber_main == 2) { namecolor_main = "GREEN"}
if ( colornumber_main == 3) { namecolor_main = "YELLOW"}
if ( colornumber_main == 4) { namecolor_main = "ROSE"}
if ( colornumber_main == 5) { namecolor_main = "BLUE"}
if ( colornumber_main == 6) { namecolor_main = "ORANGE"}
hmUI.showToast({text: namecolor_main });

             //hmUI.showToast({text: "color " + parseInt(colornumber_main) });
             normal_image_img.setProperty(hmUI.prop.SRC, "TopMain" + parseInt(colornumber_main) + ".png");
                           
        }


/////////////////////////
     let deviceInfoS = hmSetting.getDeviceInfo();

       let normal_image_img_hour = ''
        let normal_time_circle_scale = ''

          const time = hmSensor.createSensor(hmSensor.id.TIME);

            function time_image_call() {
               
                      
          let image_hour = "DG"+ time.hour +".png"
                  normal_image_img_hour.setProperty(hmUI.prop.MORE, {
              x: deviceInfoS.width / 480 * 18 ,
              y: deviceInfoS.height / 480 * 22,
              src: image_hour,
              show_level: hmUI.show_level.ONLY_NORMAL,
                });  


 // hmUI.showToast({text: time.hour + ":" + time.minute +":" + time.second}); // for check only
               
             
             
                let valueTime = time.second;
                let targetTime = 60;
                let progressTime = valueTime/targetTime;
                if (progressTime > 1) progressTime = 1;
                let progress_cs_normal_time = progressTime;

                  // normal_time_circle_scale_circle_scale
                  let levelS = Math.round(progress_cs_normal_time * 100);
                   if (progress_cs_normal_time==0){levelS =360}
                    if (normal_time_circle_scale) {
                    normal_time_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: deviceInfoS.height / 480 * 240,
                      center_y: deviceInfoS.height / 480 * 240,
                      start_angle: 0,
                       end_angle: 360,
                      radius: deviceInfoS.height / 480 * 74,
                      line_width: deviceInfoS.height / 480 * 7,
                      corner_flag: 1,
                      color: 0xFF272727,
                      show_levelS: hmUI.show_level.ONLY_NORMAL,
                     level: levelS,
                

                    });
                  };
       
       };
      

function startInterval() {
setInterval(time_image_call, 1000); // เรียกใช้ฟังก์ชัน scale_call() ทุก 1 วินาที (1000 มิลลิวินาที)
}
        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_rotate_animation_img_1 = '';
        let normal_rotate_animation_param_1 = null;
        let normal_rotate_animation_lastTime_1 = 0;
        let timer_anim_rotate_1;
        let timer_anim_rotate_1_mirror = false;
        let normal_rotate_animation_param_1_mirror = null;
        let normal_rotate_animation_count_1 = 0;
        let normal_rotate_animation_img_2 = '';
        let normal_rotate_animation_param_2 = null;
        let normal_rotate_animation_lastTime_2 = 0;
        let timer_anim_rotate_2;
        let timer_anim_rotate_2_mirror = false;
        let normal_rotate_animation_param_2_mirror = null;
        let normal_rotate_animation_count_2 = 0;
        let normal_frame_animation_1 = ''
        let normal_frame_animation_2 = ''
        let normal_frame_animation_3 = ''
        let normal_frame_animation_4 = ''
        let normal_date_img_date_week_img = ''
        let normal_battery_circle_scale = ''
        let normal_battery_TextCircle = new Array(3);
        let normal_battery_TextCircle_ASCIIARRAY = new Array(10);
        let normal_battery_TextCircle_img_width = 14;
        let normal_battery_TextCircle_img_height = 11;
        let normal_battery_TextCircle_unit = null;
        let normal_battery_TextCircle_unit_width = 14;
        let normal_image_img = ''
        let normal_step_circle_scale = ''
        let normal_step_icon_img = ''
        let normal_step_TextRotate = new Array(5);
        let normal_step_TextRotate_ASCIIARRAY = new Array(10);
        let normal_step_TextRotate_img_width = 14;
        let normal_step_TextRotate_error_img_width = 14;
        let normal_step_image_progress_img_level = ''
        let normal_calorie_TextCircle = new Array(4);
        let normal_calorie_TextCircle_ASCIIARRAY = new Array(10);
        let normal_calorie_TextCircle_img_width = 15;
        let normal_calorie_TextCircle_img_height = 12;
        let normal_calorie_TextCircle_unit = null;
        let normal_calorie_TextCircle_unit_width = 36;
        let normal_calorie_TextCircle_dot_width = 6;
        let normal_calorie_TextCircle_error_img_width = 14;
        let normal_distance_TextCircle = new Array(5);
        let normal_distance_TextCircle_ASCIIARRAY = new Array(10);
        let normal_distance_TextCircle_img_width = 15;
        let normal_distance_TextCircle_img_height = 12;
        let normal_distance_TextCircle_unit = null;
        let normal_distance_TextCircle_unit_width = 27;
        let normal_distance_TextCircle_dot_width = 6;
        let normal_distance_TextCircle_error_img_width = 14;
        let normal_heart_rate_TextRotate = new Array(3);
        let normal_heart_rate_TextRotate_ASCIIARRAY = new Array(10);
        let normal_heart_rate_TextRotate_img_width = 15;
        let normal_heart_rate_TextRotate_error_img_width = 14;
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_month_img = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_digital_clock_minute_separator_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_pro_minute_pointer_img = ''
        let normal_timerUpdateSec = undefined;
        let normal_analog_clock_pro_second_pointer_img = ''
        let normal_timerUpdateSecSmooth = undefined;
        let lastTime = 0;
        let idle_background_bg_img = ''
        let idle_date_img_date_week_img = ''
        let idle_battery_circle_scale = ''
        let idle_battery_TextCircle = new Array(3);
        let idle_battery_TextCircle_ASCIIARRAY = new Array(10);
        let idle_battery_TextCircle_img_width = 14;
        let idle_battery_TextCircle_img_height = 11;
        let idle_battery_TextCircle_unit = null;
        let idle_battery_TextCircle_unit_width = 14;
        let idle_image_img = ''
        let idle_step_circle_scale = ''
        let idle_step_icon_img = ''
        let idle_step_TextRotate = new Array(5);
        let idle_step_TextRotate_ASCIIARRAY = new Array(10);
        let idle_step_TextRotate_img_width = 14;
        let idle_step_TextRotate_error_img_width = 14;
        let idle_step_image_progress_img_level = ''
        let idle_calorie_TextCircle = new Array(4);
        let idle_calorie_TextCircle_ASCIIARRAY = new Array(10);
        let idle_calorie_TextCircle_img_width = 15;
        let idle_calorie_TextCircle_img_height = 12;
        let idle_calorie_TextCircle_unit = null;
        let idle_calorie_TextCircle_unit_width = 36;
        let idle_calorie_TextCircle_dot_width = 6;
        let idle_calorie_TextCircle_error_img_width = 14;
        let idle_distance_TextCircle = new Array(5);
        let idle_distance_TextCircle_ASCIIARRAY = new Array(10);
        let idle_distance_TextCircle_img_width = 15;
        let idle_distance_TextCircle_img_height = 12;
        let idle_distance_TextCircle_unit = null;
        let idle_distance_TextCircle_unit_width = 27;
        let idle_distance_TextCircle_dot_width = 6;
        let idle_distance_TextCircle_error_img_width = 14;
        let idle_heart_rate_TextRotate = new Array(3);
        let idle_heart_rate_TextRotate_ASCIIARRAY = new Array(10);
        let idle_heart_rate_TextRotate_img_width = 15;
        let idle_heart_rate_TextRotate_error_img_width = 14;
        let idle_weather_image_progress_img_level = ''
        let idle_temperature_current_text_img = ''
        let idle_moon_image_progress_img_level = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_month_img = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''
        let idle_digital_clock_minute_separator_img = ''
        let normal_step_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let timeSensor = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'main1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_rotate_animation_img_1 = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 481,
              h: 481,
              pos_x: 0,
              pos_y: 0,
              center_x: 240,
              center_y: 240,
              angle: 0,
              src: 'animation/A0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_rotate_animation_param_1 = {
              anim_steps: [{
                anim_rate: 'linear',
                anim_duration: 8000,
                anim_from: 0,
                anim_to: 360,
                anim_key: "angle",
              }],
              anim_fps: 15,
              anim_auto_start: 1,
              anim_repeat: 1,
              anim_auto_destroy: 1,
            };

            let now = hmSensor.createSensor(hmSensor.id.TIME);

            normal_rotate_animation_param_1_mirror = {
              anim_steps: [{
                anim_rate: 'linear',
                anim_duration: 8000,
                anim_from: 360,
                anim_to: 0,
                anim_key: "angle",
              }],
              anim_fps: 15,
              anim_auto_start: 1,
              anim_repeat: 1,
              anim_auto_destroy: 1,
            };

            function anim_rotate_1_mirror() {
              normal_rotate_animation_img_1.setProperty(hmUI.prop.ANIM, normal_rotate_animation_param_1_mirror);
              normal_rotate_animation_lastTime_1 = now.utc;
              normal_rotate_animation_count_1 = normal_rotate_animation_count_1 - 1;
              if(normal_rotate_animation_count_1 < -1) normal_rotate_animation_count_1 = - 1;
              if(normal_rotate_animation_count_1 == 0) stop_anim_rotate_1();

            }; // end animation_mirror callback function

            function anim_rotate_1_complete_call() {
              normal_rotate_animation_img_1.setProperty(hmUI.prop.ANIM, normal_rotate_animation_param_1);
              normal_rotate_animation_lastTime_1 = now.utc;
            }; // end animation callback function
            
            function stop_anim_rotate_1() {
              if (timer_anim_rotate_1) {
                timer.stopTimer(timer_anim_rotate_1);
                timer_anim_rotate_1 = undefined;
              };
            }; // end stop_anim_rotate function

            // normal_rotate_anime_1 = hmUI.createWidget(hmUI.widget.Rotate_Animation, {
              // start_angle: 0,
              // end_angle: 360,
              // pos_x: 240,
              // pos_y: 240,
              // center_x: 240,
              // center_y: 240,
              // src: 'A0.png',
              // anim_fps: 15,
              // anim_duration: 8000,
              // repeat_count: 0,
              // anim_two_sides: True,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_rotate_animation_img_2 = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 481,
              h: 481,
              pos_x: 0,
              pos_y: 0,
              center_x: 240,
              center_y: 240,
              angle: 360,
              src: 'animation/A1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_rotate_animation_param_2 = {
              anim_steps: [{
                anim_rate: 'linear',
                anim_duration: 9000,
                anim_from: 360,
                anim_to: 0,
                anim_key: "angle",
              }],
              anim_fps: 15,
              anim_auto_start: 1,
              anim_repeat: 1,
              anim_auto_destroy: 1,
            };

            normal_rotate_animation_param_2_mirror = {
              anim_steps: [{
                anim_rate: 'linear',
                anim_duration: 9000,
                anim_from: 0,
                anim_to: 360,
                anim_key: "angle",
              }],
              anim_fps: 15,
              anim_auto_start: 1,
              anim_repeat: 1,
              anim_auto_destroy: 1,
            };

            function anim_rotate_2_mirror() {
              normal_rotate_animation_img_2.setProperty(hmUI.prop.ANIM, normal_rotate_animation_param_2_mirror);
              normal_rotate_animation_lastTime_2 = now.utc;
              normal_rotate_animation_count_2 = normal_rotate_animation_count_2 - 1;
              if(normal_rotate_animation_count_2 < -1) normal_rotate_animation_count_2 = - 1;
              if(normal_rotate_animation_count_2 == 0) stop_anim_rotate_2();

            }; // end animation_mirror callback function

            function anim_rotate_2_complete_call() {
              normal_rotate_animation_img_2.setProperty(hmUI.prop.ANIM, normal_rotate_animation_param_2);
              normal_rotate_animation_lastTime_2 = now.utc;
            }; // end animation callback function
            
            function stop_anim_rotate_2() {
              if (timer_anim_rotate_2) {
                timer.stopTimer(timer_anim_rotate_2);
                timer_anim_rotate_2 = undefined;
              };
            }; // end stop_anim_rotate function

            // normal_rotate_anime_2 = hmUI.createWidget(hmUI.widget.Rotate_Animation, {
              // start_angle: 360,
              // end_angle: 0,
              // pos_x: 240,
              // pos_y: 240,
              // center_x: 240,
              // center_y: 240,
              // src: 'A1.png',
              // anim_fps: 15,
              // anim_duration: 9000,
              // repeat_count: 0,
              // anim_two_sides: True,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_frame_animation_1 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
              x: 385,
              y: 359,
              anim_path: "animation",
              anim_ext: "png",
              anim_prefix: "H",
              anim_fps: 7,
              anim_size: 6,
              repeat_count: 0,
              anim_repeat: true,
              anim_status:hmUI.anim_status.START,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_frame_animation_2 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
              x: 224,
              y: 321,
              anim_path: "animation",
              anim_ext: "png",
              anim_prefix: "L",
              anim_fps: 5,
              anim_size: 6,
              repeat_count: 0,
              anim_repeat: true,
              anim_status:hmUI.anim_status.START,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_frame_animation_3 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
              x: 175,
              y: 17,
              anim_path: "animation",
              anim_ext: "png",
              anim_prefix: "C",
              anim_fps: 4,
              anim_size: 6,
              repeat_count: 0,
              anim_repeat: true,
              anim_status:hmUI.anim_status.START,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_frame_animation_4 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
              x: 279,
              y: 35,
              anim_path: "animation",
              anim_ext: "png",
              anim_prefix: "C",
              anim_fps: 7,
              anim_size: 6,
              repeat_count: 0,
              anim_repeat: true,
              anim_status:hmUI.anim_status.START,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 210,
              y: 278,
              week_en: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              week_tc: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              week_sc: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 240,
              // center_y: 240,
              // start_angle: 211,
              // end_angle: 271,
              // radius: 103,
              // line_width: 6,
              // line_cap: Flat,
              // color: 0xFF000000,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            let screenType = hmSetting.getScreenType();
            normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 240,
              center_y: 240,
              start_angle: 211,
              end_angle: 271,
              radius: 100,
              line_width: 6,
              corner_flag: 3,
              color: 0xFF000000,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
              scale_call();
            });

            // normal_battery_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 240,
              // circle_center_Y: 240,
              // font_array: ["Act_0.png","Act_1.png","Act_2.png","Act_3.png","Act_4.png","Act_5.png","Act_6.png","Act_7.png","Act_8.png","Act_9.png"],
              // radius: 119,
              // angle: -124,
              // char_space_angle: 1,
              // unit: 'Batt_unit.png',
              // zero: false,
              // reverse_direction: true,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_battery_TextCircle_ASCIIARRAY[0] = 'Act_0.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[1] = 'Act_1.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[2] = 'Act_2.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[3] = 'Act_3.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[4] = 'Act_4.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[5] = 'Act_5.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[6] = 'Act_6.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[7] = 'Act_7.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[8] = 'Act_8.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[9] = 'Act_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 3; i++) {
              normal_battery_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 240,
                center_y: 240,
                pos_x: 240 - normal_battery_TextCircle_img_width / 2,
                pos_y: 240 + 108,
                src: 'Act_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_battery_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_battery_TextCircle_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              center_x: 240,
              center_y: 240,
              pos_x: 240 - normal_battery_TextCircle_unit_width / 2,
              pos_y: 240 + 108,
              src: 'Batt_unit.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_battery_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block
            
            function toDegree (radian) {
              return radian * (180 / Math.PI);
            };

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 24,
              y: 28,
              src: 'TopMain2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 240,
              // center_y: 240,
              // start_angle: 136,
              // end_angle: 89,
              // radius: 175,
              // line_width: 79,
              // line_cap: Flat,
              // color: 0xFF4F4F4F,
              // mirror: False,
              // inversion: True,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 240,
              center_y: 240,
              start_angle: 89,
              end_angle: 136,
              radius: 136,
              line_width: 79,
              corner_flag: 3,
              color: 0xFF4F4F4F,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
              scale_call();
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 296,
              y: 220,
              src: 'icon_step.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_step_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 351,
              // y: 320,
              // font_array: ["Act_0.png","Act_1.png","Act_2.png","Act_3.png","Act_4.png","Act_5.png","Act_6.png","Act_7.png","Act_8.png","Act_9.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: 44,
              // invalid_image: 'Act_0.png',
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_step_TextRotate_ASCIIARRAY[0] = 'Act_0.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[1] = 'Act_1.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[2] = 'Act_2.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[3] = 'Act_3.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[4] = 'Act_4.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[5] = 'Act_5.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[6] = 'Act_6.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[7] = 'Act_7.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[8] = 'Act_8.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[9] = 'Act_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              normal_step_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 351,
                center_y: 320,
                pos_x: 351,
                pos_y: 320,
                angle: 44,
                src: 'Act_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_step_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 351,
              y: 254,
              image_array: ["step_img_1.png","step_img_2.png","step_img_3.png","step_img_4.png","step_img_5.png"],
              image_length: 5,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('user_script.js');
            // start user_script.js
         normal_image_img_hour = hmUI.createWidget(hmUI.widget.IMG, {
              x: deviceInfoS.width / 480 * 18,
              y: deviceInfoS.height / 480 * 22,
              src: 'DG1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,

            });


            normal_time_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: deviceInfoS.width / 480 * 240,
              center_y: deviceInfoS.height / 480 * 240,
              start_angle: 0,
              end_angle: 360,
              radius: deviceInfoS.height / 480 * 78,
              line_width: deviceInfoS.height / 480 * 7,
              corner_flag: 0,
              color: 0xFF232323,
              show_level: hmUI.show_level.ONLY_NORMAL,
              level: 0,
            });
            

            // end user_script.js

            // normal_calorie_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 240,
              // circle_center_Y: 240,
              // font_array: ["TempNum_0.png","TempNum_1.png","TempNum_2.png","TempNum_3.png","TempNum_4.png","TempNum_5.png","TempNum_6.png","TempNum_7.png","TempNum_8.png","TempNum_9.png"],
              // radius: 225,
              // angle: 95,
              // char_space_angle: 0,
              // unit: 'Cal_unit.png',
              // imperial_unit: 'Dis_Mi.png',
              // dot_image: 'Dis_dot.png',
              // error_image: 'Act_0.png',
              // zero: false,
              // reverse_direction: true,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: RIGHT,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_calorie_TextCircle_ASCIIARRAY[0] = 'TempNum_0.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[1] = 'TempNum_1.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[2] = 'TempNum_2.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[3] = 'TempNum_3.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[4] = 'TempNum_4.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[5] = 'TempNum_5.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[6] = 'TempNum_6.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[7] = 'TempNum_7.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[8] = 'TempNum_8.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[9] = 'TempNum_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 4; i++) {
              normal_calorie_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 240,
                center_y: 240,
                pos_x: 240 - normal_calorie_TextCircle_img_width / 2,
                pos_y: 240 + 213,
                src: 'TempNum_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_calorie_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_calorie_TextCircle_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              center_x: 240,
              center_y: 240,
              pos_x: 240 - normal_calorie_TextCircle_unit_width / 2,
              pos_y: 240 + 213,
              src: 'Cal_unit.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_calorie_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block
            
            const calorie = hmSensor.createSensor(hmSensor.id.CALORIE);
            calorie.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            // normal_distance_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 240,
              // circle_center_Y: 240,
              // font_array: ["TempNum_0.png","TempNum_1.png","TempNum_2.png","TempNum_3.png","TempNum_4.png","TempNum_5.png","TempNum_6.png","TempNum_7.png","TempNum_8.png","TempNum_9.png"],
              // radius: 202,
              // angle: 94,
              // char_space_angle: 0,
              // unit: 'Dis_KM.png',
              // imperial_unit: 'Dis_Mi.png',
              // dot_image: 'Dis_dot.png',
              // error_image: 'Act_0.png',
              // zero: false,
              // reverse_direction: true,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: RIGHT,
              // type: hmUI.data_type.DISTANCE,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_distance_TextCircle_ASCIIARRAY[0] = 'TempNum_0.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[1] = 'TempNum_1.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[2] = 'TempNum_2.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[3] = 'TempNum_3.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[4] = 'TempNum_4.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[5] = 'TempNum_5.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[6] = 'TempNum_6.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[7] = 'TempNum_7.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[8] = 'TempNum_8.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[9] = 'TempNum_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              normal_distance_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 240,
                center_y: 240,
                pos_x: 240 - normal_distance_TextCircle_img_width / 2,
                pos_y: 240 + 190,
                src: 'TempNum_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_distance_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_distance_TextCircle_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              center_x: 240,
              center_y: 240,
              pos_x: 240 - normal_distance_TextCircle_unit_width / 2,
              pos_y: 240 + 190,
              src: 'Dis_KM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_distance_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);

            const mileageUnit = hmSetting.getMileageUnit();
            if (mileageUnit == 1) {
              normal_distance_TextCircle_unit.setProperty(hmUI.prop.SRC, 'Dis_Mi.png');
            };
            //end of ignored block
            
            const distance = hmSensor.createSensor(hmSensor.id.DISTANCE);
            distance.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            // normal_heart_rate_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 412,
              // y: 353,
              // font_array: ["TempNum_0.png","TempNum_1.png","TempNum_2.png","TempNum_3.png","TempNum_4.png","TempNum_5.png","TempNum_6.png","TempNum_7.png","TempNum_8.png","TempNum_9.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: 40,
              // invalid_image: 'Act_0.png',
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_heart_rate_TextRotate_ASCIIARRAY[0] = 'TempNum_0.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[1] = 'TempNum_1.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[2] = 'TempNum_2.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[3] = 'TempNum_3.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[4] = 'TempNum_4.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[5] = 'TempNum_5.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[6] = 'TempNum_6.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[7] = 'TempNum_7.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[8] = 'TempNum_8.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[9] = 'TempNum_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 3; i++) {
              normal_heart_rate_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 412,
                center_y: 353,
                pos_x: 412,
                pos_y: 353,
                angle: 40,
                src: 'TempNum_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_heart_rate_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            
            const heart_rate = hmSensor.createSensor(hmSensor.id.HEART);
            heart_rate.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 63,
              y: 240,
              image_array: ["WeatherF_01.png","WeatherF_02.png","WeatherF_03.png","WeatherF_04.png","WeatherF_05.png","WeatherF_06.png","WeatherF_07.png","WeatherF_08.png","WeatherF_09.png","WeatherF_10.png","WeatherF_11.png","WeatherF_12.png","WeatherF_13.png","WeatherF_14.png","WeatherF_15.png","WeatherF_16.png","WeatherF_17.png","WeatherF_18.png","WeatherF_19.png","WeatherF_20.png","WeatherF_21.png","WeatherF_22.png","WeatherF_23.png","WeatherF_24.png","WeatherF_25.png","WeatherF_26.png","WeatherF_27.png","WeatherF_28.png","WeatherF_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 76,
              y: 315,
              font_array: ["TempNum_0.png","TempNum_1.png","TempNum_2.png","TempNum_3.png","TempNum_4.png","TempNum_5.png","TempNum_6.png","TempNum_7.png","TempNum_8.png","TempNum_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Temp_Symbol1.png',
              unit_tc: 'Temp_Symbol1.png',
              unit_en: 'Temp_Symbol1.png',
              imperial_unit_sc: 'Temp_Symbol1.png',
              imperial_unit_tc: 'Temp_Symbol1.png',
              imperial_unit_en: 'Temp_Symbol1.png',
              negative_image: 'Temp_Symbol2.png',
              invalid_image: 'Temp_Symbol2.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const temperatureUnit = hmSetting.getTemperatureUnit();
            //start of ignored block
            if (temperatureUnit == 1) {
              normal_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
                x: 76,
                y: 315,
                font_array: ["TempNum_0.png","TempNum_1.png","TempNum_2.png","TempNum_3.png","TempNum_4.png","TempNum_5.png","TempNum_6.png","TempNum_7.png","TempNum_8.png","TempNum_9.png"],
                padding: false,
                h_space: 0,
                unit_sc: 'Temp_Symbol1.png',
                unit_tc: 'Temp_Symbol1.png',
                unit_en: 'Temp_Symbol1.png',
                imperial_unit_sc: 'Temp_Symbol1.png',
                imperial_unit_tc: 'Temp_Symbol1.png',
                imperial_unit_en: 'Temp_Symbol1.png',
                negative_image: 'Temp_Symbol2.png',
                invalid_image: 'Temp_Symbol2.png',
                align_h: hmUI.align.CENTER_H,
                type: hmUI.data_type.WEATHER_CURRENT,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
            };
            //end of ignored block

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 127,
              y: 353,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 218,
              day_startY: 372,
              day_sc_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              day_tc_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              day_en_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 221,
              month_startY: 353,
              month_sc_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_tc_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_en_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 191,
              hour_startY: 234,
              hour_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 242,
              minute_startY: 234,
              minute_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 188,
              y: 221,
              src: 'Digital_Time_Box.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_minute_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 237,
              y: 234,
              src: 'Time_DOT.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 307,
              y: 57,
              src: 'System_BT_OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 188,
              y: 206,
              src: 'System_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'Hand_H1.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 23,
              hour_posY: 233,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'Hand_M1.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 23,
              minute_posY: 233,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const deviceInfo = hmSetting.getDeviceInfo();
            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            // normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'Hand_MP1.png',
              // center_x: 240,
              // center_y: 240,
              // x: 15,
              // y: 140,
              // start_angle: 282,
              // end_angle: 421,
              // type: hmUI.data_type.minute,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 15,
              pos_y: 240 - 140,
              center_x: 240,
              center_y: 240,
              src: 'Hand_MP1.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'Hand_SP1.png',
              // center_x: 240,
              // center_y: 240,
              // x: 200,
              // y: 220,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 200,
              pos_y: 240 - 220,
              center_x: 240,
              center_y: 240,
              src: 'Hand_SP1.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            function startSecAnim(sec, animDuration) {
              const secAnim = {
                anim_steps: [{
                  anim_rate: 'linear',
                  anim_duration: animDuration,
                  anim_from: sec,
                  anim_to: sec + (360*(animDuration*6/1000))/360,
                  anim_key: 'angle',
                }],
                anim_fps: 15,
                anim_auto_start: 1,
                anim_repeat: 1,
                anim_auto_destroy: 1,
              }
              normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANIM, secAnim);
            }
            // normal_analog_clock_pro_smooth_second = hmUI.createWidget(hmUI.widget.SMOOTH_SECOND, {
              // type: 4,
              // fps: 15,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });



            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'main1.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 210,
              y: 278,
              week_en: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              week_tc: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              week_sc: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 240,
              // center_y: 240,
              // start_angle: 211,
              // end_angle: 271,
              // radius: 103,
              // line_width: 6,
              // line_cap: Flat,
              // color: 0xFF000000,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 240,
              center_y: 240,
              start_angle: 211,
              end_angle: 271,
              radius: 100,
              line_width: 6,
              corner_flag: 3,
              color: 0xFF000000,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_battery_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 240,
              // circle_center_Y: 240,
              // font_array: ["Act_0.png","Act_1.png","Act_2.png","Act_3.png","Act_4.png","Act_5.png","Act_6.png","Act_7.png","Act_8.png","Act_9.png"],
              // radius: 119,
              // angle: -124,
              // char_space_angle: 1,
              // unit: 'Batt_unit.png',
              // zero: false,
              // reverse_direction: true,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_battery_TextCircle_ASCIIARRAY[0] = 'Act_0.png';  // set of images with numbers
            idle_battery_TextCircle_ASCIIARRAY[1] = 'Act_1.png';  // set of images with numbers
            idle_battery_TextCircle_ASCIIARRAY[2] = 'Act_2.png';  // set of images with numbers
            idle_battery_TextCircle_ASCIIARRAY[3] = 'Act_3.png';  // set of images with numbers
            idle_battery_TextCircle_ASCIIARRAY[4] = 'Act_4.png';  // set of images with numbers
            idle_battery_TextCircle_ASCIIARRAY[5] = 'Act_5.png';  // set of images with numbers
            idle_battery_TextCircle_ASCIIARRAY[6] = 'Act_6.png';  // set of images with numbers
            idle_battery_TextCircle_ASCIIARRAY[7] = 'Act_7.png';  // set of images with numbers
            idle_battery_TextCircle_ASCIIARRAY[8] = 'Act_8.png';  // set of images with numbers
            idle_battery_TextCircle_ASCIIARRAY[9] = 'Act_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 3; i++) {
              idle_battery_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 240,
                center_y: 240,
                pos_x: 240 - idle_battery_TextCircle_img_width / 2,
                pos_y: 240 + 108,
                src: 'Act_0.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_battery_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            idle_battery_TextCircle_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              center_x: 240,
              center_y: 240,
              pos_x: 240 - idle_battery_TextCircle_unit_width / 2,
              pos_y: 240 + 108,
              src: 'Batt_unit.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            idle_battery_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 24,
              y: 28,
              src: 'TopMain1.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 240,
              // center_y: 240,
              // start_angle: 136,
              // end_angle: 89,
              // radius: 175,
              // line_width: 79,
              // line_cap: Flat,
              // color: 0xFF4F4F4F,
              // mirror: False,
              // inversion: True,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 240,
              center_y: 240,
              start_angle: 89,
              end_angle: 136,
              radius: 136,
              line_width: 79,
              corner_flag: 3,
              color: 0xFF4F4F4F,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 296,
              y: 220,
              src: 'icon_step.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_step_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 351,
              // y: 320,
              // font_array: ["Act_0.png","Act_1.png","Act_2.png","Act_3.png","Act_4.png","Act_5.png","Act_6.png","Act_7.png","Act_8.png","Act_9.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: 44,
              // invalid_image: 'Act_0.png',
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_step_TextRotate_ASCIIARRAY[0] = 'Act_0.png';  // set of images with numbers
            idle_step_TextRotate_ASCIIARRAY[1] = 'Act_1.png';  // set of images with numbers
            idle_step_TextRotate_ASCIIARRAY[2] = 'Act_2.png';  // set of images with numbers
            idle_step_TextRotate_ASCIIARRAY[3] = 'Act_3.png';  // set of images with numbers
            idle_step_TextRotate_ASCIIARRAY[4] = 'Act_4.png';  // set of images with numbers
            idle_step_TextRotate_ASCIIARRAY[5] = 'Act_5.png';  // set of images with numbers
            idle_step_TextRotate_ASCIIARRAY[6] = 'Act_6.png';  // set of images with numbers
            idle_step_TextRotate_ASCIIARRAY[7] = 'Act_7.png';  // set of images with numbers
            idle_step_TextRotate_ASCIIARRAY[8] = 'Act_8.png';  // set of images with numbers
            idle_step_TextRotate_ASCIIARRAY[9] = 'Act_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              idle_step_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 351,
                center_y: 320,
                pos_x: 351,
                pos_y: 320,
                angle: 44,
                src: 'Act_0.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_step_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            idle_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 351,
              y: 254,
              image_array: ["step_img_1.png","step_img_2.png","step_img_3.png","step_img_4.png","step_img_5.png"],
              image_length: 5,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_calorie_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 240,
              // circle_center_Y: 240,
              // font_array: ["TempNum_0.png","TempNum_1.png","TempNum_2.png","TempNum_3.png","TempNum_4.png","TempNum_5.png","TempNum_6.png","TempNum_7.png","TempNum_8.png","TempNum_9.png"],
              // radius: 225,
              // angle: 95,
              // char_space_angle: 0,
              // unit: 'Cal_unit.png',
              // imperial_unit: 'Dis_Mi.png',
              // dot_image: 'Dis_dot.png',
              // error_image: 'Act_0.png',
              // zero: false,
              // reverse_direction: true,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: RIGHT,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_calorie_TextCircle_ASCIIARRAY[0] = 'TempNum_0.png';  // set of images with numbers
            idle_calorie_TextCircle_ASCIIARRAY[1] = 'TempNum_1.png';  // set of images with numbers
            idle_calorie_TextCircle_ASCIIARRAY[2] = 'TempNum_2.png';  // set of images with numbers
            idle_calorie_TextCircle_ASCIIARRAY[3] = 'TempNum_3.png';  // set of images with numbers
            idle_calorie_TextCircle_ASCIIARRAY[4] = 'TempNum_4.png';  // set of images with numbers
            idle_calorie_TextCircle_ASCIIARRAY[5] = 'TempNum_5.png';  // set of images with numbers
            idle_calorie_TextCircle_ASCIIARRAY[6] = 'TempNum_6.png';  // set of images with numbers
            idle_calorie_TextCircle_ASCIIARRAY[7] = 'TempNum_7.png';  // set of images with numbers
            idle_calorie_TextCircle_ASCIIARRAY[8] = 'TempNum_8.png';  // set of images with numbers
            idle_calorie_TextCircle_ASCIIARRAY[9] = 'TempNum_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 4; i++) {
              idle_calorie_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 240,
                center_y: 240,
                pos_x: 240 - idle_calorie_TextCircle_img_width / 2,
                pos_y: 240 + 213,
                src: 'TempNum_0.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_calorie_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            idle_calorie_TextCircle_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              center_x: 240,
              center_y: 240,
              pos_x: 240 - idle_calorie_TextCircle_unit_width / 2,
              pos_y: 240 + 213,
              src: 'Cal_unit.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            idle_calorie_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block

            // idle_distance_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 240,
              // circle_center_Y: 240,
              // font_array: ["TempNum_0.png","TempNum_1.png","TempNum_2.png","TempNum_3.png","TempNum_4.png","TempNum_5.png","TempNum_6.png","TempNum_7.png","TempNum_8.png","TempNum_9.png"],
              // radius: 202,
              // angle: 94,
              // char_space_angle: 0,
              // unit: 'Dis_KM.png',
              // imperial_unit: 'Dis_Mi.png',
              // dot_image: 'Dis_dot.png',
              // error_image: 'Act_0.png',
              // zero: false,
              // reverse_direction: true,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: RIGHT,
              // type: hmUI.data_type.DISTANCE,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_distance_TextCircle_ASCIIARRAY[0] = 'TempNum_0.png';  // set of images with numbers
            idle_distance_TextCircle_ASCIIARRAY[1] = 'TempNum_1.png';  // set of images with numbers
            idle_distance_TextCircle_ASCIIARRAY[2] = 'TempNum_2.png';  // set of images with numbers
            idle_distance_TextCircle_ASCIIARRAY[3] = 'TempNum_3.png';  // set of images with numbers
            idle_distance_TextCircle_ASCIIARRAY[4] = 'TempNum_4.png';  // set of images with numbers
            idle_distance_TextCircle_ASCIIARRAY[5] = 'TempNum_5.png';  // set of images with numbers
            idle_distance_TextCircle_ASCIIARRAY[6] = 'TempNum_6.png';  // set of images with numbers
            idle_distance_TextCircle_ASCIIARRAY[7] = 'TempNum_7.png';  // set of images with numbers
            idle_distance_TextCircle_ASCIIARRAY[8] = 'TempNum_8.png';  // set of images with numbers
            idle_distance_TextCircle_ASCIIARRAY[9] = 'TempNum_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              idle_distance_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 240,
                center_y: 240,
                pos_x: 240 - idle_distance_TextCircle_img_width / 2,
                pos_y: 240 + 190,
                src: 'TempNum_0.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_distance_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            idle_distance_TextCircle_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              center_x: 240,
              center_y: 240,
              pos_x: 240 - idle_distance_TextCircle_unit_width / 2,
              pos_y: 240 + 190,
              src: 'Dis_KM.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            idle_distance_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);

            if (mileageUnit == 1) {
              idle_distance_TextCircle_unit.setProperty(hmUI.prop.SRC, 'Dis_Mi.png');
            };
            //end of ignored block

            // idle_heart_rate_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 412,
              // y: 353,
              // font_array: ["TempNum_0.png","TempNum_1.png","TempNum_2.png","TempNum_3.png","TempNum_4.png","TempNum_5.png","TempNum_6.png","TempNum_7.png","TempNum_8.png","TempNum_9.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: 40,
              // invalid_image: 'Act_0.png',
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_heart_rate_TextRotate_ASCIIARRAY[0] = 'TempNum_0.png';  // set of images with numbers
            idle_heart_rate_TextRotate_ASCIIARRAY[1] = 'TempNum_1.png';  // set of images with numbers
            idle_heart_rate_TextRotate_ASCIIARRAY[2] = 'TempNum_2.png';  // set of images with numbers
            idle_heart_rate_TextRotate_ASCIIARRAY[3] = 'TempNum_3.png';  // set of images with numbers
            idle_heart_rate_TextRotate_ASCIIARRAY[4] = 'TempNum_4.png';  // set of images with numbers
            idle_heart_rate_TextRotate_ASCIIARRAY[5] = 'TempNum_5.png';  // set of images with numbers
            idle_heart_rate_TextRotate_ASCIIARRAY[6] = 'TempNum_6.png';  // set of images with numbers
            idle_heart_rate_TextRotate_ASCIIARRAY[7] = 'TempNum_7.png';  // set of images with numbers
            idle_heart_rate_TextRotate_ASCIIARRAY[8] = 'TempNum_8.png';  // set of images with numbers
            idle_heart_rate_TextRotate_ASCIIARRAY[9] = 'TempNum_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 3; i++) {
              idle_heart_rate_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 412,
                center_y: 353,
                pos_x: 412,
                pos_y: 353,
                angle: 40,
                src: 'TempNum_0.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_heart_rate_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 63,
              y: 240,
              image_array: ["WeatherF_01.png","WeatherF_02.png","WeatherF_03.png","WeatherF_04.png","WeatherF_05.png","WeatherF_06.png","WeatherF_07.png","WeatherF_08.png","WeatherF_09.png","WeatherF_10.png","WeatherF_11.png","WeatherF_12.png","WeatherF_13.png","WeatherF_14.png","WeatherF_15.png","WeatherF_16.png","WeatherF_17.png","WeatherF_18.png","WeatherF_19.png","WeatherF_20.png","WeatherF_21.png","WeatherF_22.png","WeatherF_23.png","WeatherF_24.png","WeatherF_25.png","WeatherF_26.png","WeatherF_27.png","WeatherF_28.png","WeatherF_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 76,
              y: 315,
              font_array: ["TempNum_0.png","TempNum_1.png","TempNum_2.png","TempNum_3.png","TempNum_4.png","TempNum_5.png","TempNum_6.png","TempNum_7.png","TempNum_8.png","TempNum_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Temp_Symbol1.png',
              unit_tc: 'Temp_Symbol1.png',
              unit_en: 'Temp_Symbol1.png',
              imperial_unit_sc: 'Temp_Symbol1.png',
              imperial_unit_tc: 'Temp_Symbol1.png',
              imperial_unit_en: 'Temp_Symbol1.png',
              negative_image: 'Temp_Symbol2.png',
              invalid_image: 'Temp_Symbol2.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            //start of ignored block
            if (temperatureUnit == 1) {
              idle_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
                x: 76,
                y: 315,
                font_array: ["TempNum_0.png","TempNum_1.png","TempNum_2.png","TempNum_3.png","TempNum_4.png","TempNum_5.png","TempNum_6.png","TempNum_7.png","TempNum_8.png","TempNum_9.png"],
                padding: false,
                h_space: 0,
                unit_sc: 'Temp_Symbol1.png',
                unit_tc: 'Temp_Symbol1.png',
                unit_en: 'Temp_Symbol1.png',
                imperial_unit_sc: 'Temp_Symbol1.png',
                imperial_unit_tc: 'Temp_Symbol1.png',
                imperial_unit_en: 'Temp_Symbol1.png',
                negative_image: 'Temp_Symbol2.png',
                invalid_image: 'Temp_Symbol2.png',
                align_h: hmUI.align.CENTER_H,
                type: hmUI.data_type.WEATHER_CURRENT,
                show_level: hmUI.show_level.ONLY_AOD,
              });
            };
            //end of ignored block

            idle_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 127,
              y: 353,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 218,
              day_startY: 372,
              day_sc_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              day_tc_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              day_en_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 221,
              month_startY: 353,
              month_sc_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_tc_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_en_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 191,
              hour_startY: 234,
              hour_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 242,
              minute_startY: 234,
              minute_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 188,
              y: 221,
              src: 'Digital_Time_Box.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_minute_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 237,
              y: 234,
              src: 'Time_DOT.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 316,
              y: 217,
              w: 76,
              h: 24,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 386,
              y: 334,
              w: 42,
              h: 57,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 419,
              y: 243,
              w: 47,
              h: 79,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 123,
              y: 347,
              w: 44,
              h: 49,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 79,
              y: 297,
              w: 42,
              h: 46,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 174,
              y: 229,
              w: 31,
              h: 30,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 265,
              y: 228,
              w: 29,
              h: 27,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 184,
              y: 195,
              w: 28,
              h: 28,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 139,
              y: 261,
              w: 52,
              h: 65,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PowerSaveHintScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 213,
              y: 342,
              w: 52,
              h: 65,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 402,
              y: 192,
              w: 52,
              h: 45,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'SportListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 1,
              y: 282,
              w: 52,
              h: 45,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                //chang color main
click_Color()

              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 315,
              y: 412,
              w: 52,
              h: 45,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                // change color topmain
click_ColorTOP()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 219,
              y: 222,
              w: 41,
              h: 42,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                // hidden analog
click_elemente()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            console.log('user_script_end.js');
            // start user_script_end.js

startInterval();
UpdateElementeOne()
            // end user_script_end.js

            //start of ignored block
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              if (updateMinute) {
                let normal_fullAngle_minute = 139;
                let normal_angle_minute = 282 + normal_fullAngle_minute*(minute + second/60)/60;
                if (normal_analog_clock_pro_minute_pointer_img) normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_minute);
              };

            };

            //end of ignored block
            //start of ignored block
            function text_update() {
              console.log('text_update()');

              console.log('update text circle battery_BATTERY');
              let valueBattery = battery.current;
              let normal_battery_circle_string = parseInt(valueBattery).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  normal_battery_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_battery_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
                let char_Angle = 56;
                if (valueBattery != null && valueBattery != undefined && isFinite(valueBattery) && normal_battery_circle_string.length > 0 && normal_battery_circle_string.length <= 3) {  // display data if it was possible to get it
                  let normal_battery_TextCircle_img_angle = 0;
                  let normal_battery_TextCircle_dot_img_angle = 0;
                  let normal_battery_TextCircle_unit_angle = 0;
                  normal_battery_TextCircle_img_angle = toDegree(Math.atan2(normal_battery_TextCircle_img_width/2, 119));
                  normal_battery_TextCircle_unit_angle = toDegree(Math.atan2(normal_battery_TextCircle_unit_width/2, 119));
                  // alignment = CENTER_H
                  let normal_battery_TextCircle_angleOffset = normal_battery_TextCircle_img_angle * (normal_battery_circle_string.length - 1);
                  normal_battery_TextCircle_angleOffset = normal_battery_TextCircle_angleOffset + 1 * (normal_battery_circle_string.length - 1) / 2;
                  normal_battery_TextCircle_angleOffset = normal_battery_TextCircle_angleOffset + (normal_battery_TextCircle_img_angle + normal_battery_TextCircle_unit_angle + 1) / 2;
                  normal_battery_TextCircle_angleOffset = -normal_battery_TextCircle_angleOffset;
                  char_Angle -= normal_battery_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_battery_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= normal_battery_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_battery_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_battery_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - normal_battery_TextCircle_img_width / 2);
                      normal_battery_TextCircle[index].setProperty(hmUI.prop.SRC, normal_battery_TextCircle_ASCIIARRAY[charCode]);
                      normal_battery_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= normal_battery_TextCircle_img_angle + 1;
                      index++;
                    };  // end if digit
                  };  // end char of string
                  char_Angle -= normal_battery_TextCircle_unit_angle;
                  normal_battery_TextCircle_unit.setProperty(hmUI.prop.ANGLE, char_Angle);
                  normal_battery_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite

              };

              console.log('update text rotate step_STEP');
              let valueStep = step.current;
              let normal_step_rotate_string = parseInt(valueStep).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  normal_step_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueStep != null && valueStep != undefined && isFinite(valueStep) && normal_step_rotate_string.length > 0 && normal_step_rotate_string.length <= 5) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let normal_step_TextRotate_posOffset = normal_step_TextRotate_img_width * normal_step_rotate_string.length;
                  img_offset -= normal_step_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_step_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_step_TextRotate[index].setProperty(hmUI.prop.POS_X, 351 + img_offset);
                      normal_step_TextRotate[index].setProperty(hmUI.prop.SRC, normal_step_TextRotate_ASCIIARRAY[charCode]);
                      normal_step_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_step_TextRotate_img_width;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite
                else {
                  normal_step_TextRotate[0].setProperty(hmUI.prop.POS_X, 351 - normal_step_TextRotate_error_img_width / 2);
                  normal_step_TextRotate[0].setProperty(hmUI.prop.SRC, 'Act_0.png');
                  normal_step_TextRotate[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

              console.log('update text circle calorie_CALORIE');
              let valueCalories = calorie.current;
              let normal_calorie_circle_string = parseInt(valueCalories).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 4; i++) {  // hide all symbols
                  normal_calorie_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_calorie_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
                let char_Angle = 275;
                if (valueCalories != null && valueCalories != undefined && isFinite(valueCalories) && normal_calorie_circle_string.length > 0 && normal_calorie_circle_string.length <= 4) {  // display data if it was possible to get it
                  let normal_calorie_TextCircle_img_angle = 0;
                  let normal_calorie_TextCircle_dot_img_angle = 0;
                  let normal_calorie_TextCircle_unit_angle = 0;
                  normal_calorie_TextCircle_img_angle = toDegree(Math.atan2(normal_calorie_TextCircle_img_width/2, 225));
                  normal_calorie_TextCircle_dot_img_angle = toDegree(Math.atan2(normal_calorie_TextCircle_dot_width/2, 225));
                  normal_calorie_TextCircle_unit_angle = toDegree(Math.atan2(normal_calorie_TextCircle_unit_width/2, 225));
                  // alignment = RIGHT
                  let normal_calorie_TextCircle_angleOffset = normal_calorie_TextCircle_img_angle * (normal_calorie_circle_string.length - 1);
                  normal_calorie_TextCircle_angleOffset = normal_calorie_TextCircle_angleOffset + (normal_calorie_TextCircle_img_angle + normal_calorie_TextCircle_unit_angle + 0) / 2;
                  normal_calorie_TextCircle_angleOffset = -normal_calorie_TextCircle_angleOffset;
                  char_Angle -= 2 * normal_calorie_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_calorie_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 4) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= normal_calorie_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_calorie_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_calorie_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - normal_calorie_TextCircle_img_width / 2);
                      normal_calorie_TextCircle[index].setProperty(hmUI.prop.SRC, normal_calorie_TextCircle_ASCIIARRAY[charCode]);
                      normal_calorie_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= normal_calorie_TextCircle_img_angle;
                      index++;
                    }  // end if digit
                    else { 
                      if (!firstSymbol) char_Angle -= normal_calorie_TextCircle_dot_img_angle; 
                      firstSymbol = false;
                      normal_calorie_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_calorie_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - normal_calorie_TextCircle_dot_width / 2);
                      normal_calorie_TextCircle[index].setProperty(hmUI.prop.SRC, 'Dis_dot.png');
                      normal_calorie_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= normal_calorie_TextCircle_dot_img_angle;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                  char_Angle -= normal_calorie_TextCircle_unit_angle;
                  normal_calorie_TextCircle_unit.setProperty(hmUI.prop.ANGLE, char_Angle);
                  normal_calorie_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite
                else {
                  normal_calorie_TextCircle[0].setProperty(hmUI.prop.ANGLE, char_Angle);
                  normal_calorie_TextCircle[0].setProperty(hmUI.prop.POS_X, 240 - normal_calorie_TextCircle_error_img_width / 2);
                  normal_calorie_TextCircle[0].setProperty(hmUI.prop.SRC, 'Act_0.png');
                  normal_calorie_TextCircle[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

              console.log('update text circle DISTANCE');
              let distanceCurrent = distance.current;
              let normal_distance_circle_string = (distanceCurrent / 1000).toFixed(2);

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  normal_distance_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_distance_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
                let char_Angle = 274;
                if (distanceCurrent != null && distanceCurrent != undefined && isFinite(distanceCurrent) && normal_distance_circle_string.length > 0 && normal_distance_circle_string.length <= 5) {  // display data if it was possible to get it
                  let normal_distance_TextCircle_img_angle = 0;
                  let normal_distance_TextCircle_dot_img_angle = 0;
                  let normal_distance_TextCircle_unit_angle = 0;
                  normal_distance_TextCircle_img_angle = toDegree(Math.atan2(normal_distance_TextCircle_img_width/2, 202));
                  normal_distance_TextCircle_dot_img_angle = toDegree(Math.atan2(normal_distance_TextCircle_dot_width/2, 202));
                  normal_distance_TextCircle_unit_angle = toDegree(Math.atan2(normal_distance_TextCircle_unit_width/2, 202));
                  // alignment = RIGHT
                  let normal_distance_TextCircle_angleOffset = normal_distance_TextCircle_img_angle * (normal_distance_circle_string.length - 1);
                  normal_distance_TextCircle_angleOffset = normal_distance_TextCircle_angleOffset - normal_distance_TextCircle_img_angle + normal_distance_TextCircle_dot_img_angle;
                  normal_distance_TextCircle_angleOffset = normal_distance_TextCircle_angleOffset + (normal_distance_TextCircle_img_angle + normal_distance_TextCircle_unit_angle + 0) / 2;
                  normal_distance_TextCircle_angleOffset = -normal_distance_TextCircle_angleOffset;
                  char_Angle -= 2 * normal_distance_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_distance_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= normal_distance_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_distance_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_distance_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - normal_distance_TextCircle_img_width / 2);
                      normal_distance_TextCircle[index].setProperty(hmUI.prop.SRC, normal_distance_TextCircle_ASCIIARRAY[charCode]);
                      normal_distance_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= normal_distance_TextCircle_img_angle;
                      index++;
                    }  // end if digit
                    else { 
                      if (!firstSymbol) char_Angle -= normal_distance_TextCircle_dot_img_angle; 
                      firstSymbol = false;
                      normal_distance_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_distance_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - normal_distance_TextCircle_dot_width / 2);
                      normal_distance_TextCircle[index].setProperty(hmUI.prop.SRC, 'Dis_dot.png');
                      normal_distance_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= normal_distance_TextCircle_dot_img_angle;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                  char_Angle -= normal_distance_TextCircle_unit_angle;
                  normal_distance_TextCircle_unit.setProperty(hmUI.prop.ANGLE, char_Angle);
                  normal_distance_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite
                else {
                  normal_distance_TextCircle[0].setProperty(hmUI.prop.ANGLE, char_Angle);
                  normal_distance_TextCircle[0].setProperty(hmUI.prop.POS_X, 240 - normal_distance_TextCircle_error_img_width / 2);
                  normal_distance_TextCircle[0].setProperty(hmUI.prop.SRC, 'Act_0.png');
                  normal_distance_TextCircle[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

              console.log('update text rotate heart_rate_HEART');
              let valueHeartRate = heart_rate.last;
              let normal_heart_rate_rotate_string = parseInt(valueHeartRate).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  normal_heart_rate_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueHeartRate != null && valueHeartRate != undefined && isFinite(valueHeartRate) && normal_heart_rate_rotate_string.length > 0 && normal_heart_rate_rotate_string.length <= 3) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let normal_heart_rate_TextRotate_posOffset = normal_heart_rate_TextRotate_img_width * normal_heart_rate_rotate_string.length;
                  img_offset -= normal_heart_rate_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_heart_rate_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_heart_rate_TextRotate[index].setProperty(hmUI.prop.POS_X, 412 + img_offset);
                      normal_heart_rate_TextRotate[index].setProperty(hmUI.prop.SRC, normal_heart_rate_TextRotate_ASCIIARRAY[charCode]);
                      normal_heart_rate_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_heart_rate_TextRotate_img_width;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite
                else {
                  normal_heart_rate_TextRotate[0].setProperty(hmUI.prop.POS_X, 412 - normal_heart_rate_TextRotate_error_img_width / 2);
                  normal_heart_rate_TextRotate[0].setProperty(hmUI.prop.SRC, 'Act_0.png');
                  normal_heart_rate_TextRotate[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

              console.log('update text circle battery_BATTERY');
              let idle_battery_circle_string = parseInt(valueBattery).toString();

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  idle_battery_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                idle_battery_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
                let char_Angle = 56;
                if (valueBattery != null && valueBattery != undefined && isFinite(valueBattery) && idle_battery_circle_string.length > 0 && idle_battery_circle_string.length <= 3) {  // display data if it was possible to get it
                  let idle_battery_TextCircle_img_angle = 0;
                  let idle_battery_TextCircle_dot_img_angle = 0;
                  let idle_battery_TextCircle_unit_angle = 0;
                  idle_battery_TextCircle_img_angle = toDegree(Math.atan2(idle_battery_TextCircle_img_width/2, 119));
                  idle_battery_TextCircle_unit_angle = toDegree(Math.atan2(idle_battery_TextCircle_unit_width/2, 119));
                  // alignment = CENTER_H
                  let idle_battery_TextCircle_angleOffset = idle_battery_TextCircle_img_angle * (idle_battery_circle_string.length - 1);
                  idle_battery_TextCircle_angleOffset = idle_battery_TextCircle_angleOffset + 1 * (idle_battery_circle_string.length - 1) / 2;
                  idle_battery_TextCircle_angleOffset = idle_battery_TextCircle_angleOffset + (idle_battery_TextCircle_img_angle + idle_battery_TextCircle_unit_angle + 1) / 2;
                  idle_battery_TextCircle_angleOffset = -idle_battery_TextCircle_angleOffset;
                  char_Angle -= idle_battery_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of idle_battery_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= idle_battery_TextCircle_img_angle;
                      firstSymbol = false;
                      idle_battery_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      idle_battery_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - idle_battery_TextCircle_img_width / 2);
                      idle_battery_TextCircle[index].setProperty(hmUI.prop.SRC, idle_battery_TextCircle_ASCIIARRAY[charCode]);
                      idle_battery_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= idle_battery_TextCircle_img_angle + 1;
                      index++;
                    };  // end if digit
                  };  // end char of string
                  char_Angle -= idle_battery_TextCircle_unit_angle;
                  idle_battery_TextCircle_unit.setProperty(hmUI.prop.ANGLE, char_Angle);
                  idle_battery_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite

              };

              console.log('update text rotate step_STEP');
              let idle_step_rotate_string = parseInt(valueStep).toString();

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  idle_step_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueStep != null && valueStep != undefined && isFinite(valueStep) && idle_step_rotate_string.length > 0 && idle_step_rotate_string.length <= 5) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let idle_step_TextRotate_posOffset = idle_step_TextRotate_img_width * idle_step_rotate_string.length;
                  img_offset -= idle_step_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of idle_step_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_step_TextRotate[index].setProperty(hmUI.prop.POS_X, 351 + img_offset);
                      idle_step_TextRotate[index].setProperty(hmUI.prop.SRC, idle_step_TextRotate_ASCIIARRAY[charCode]);
                      idle_step_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_step_TextRotate_img_width;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite
                else {
                  idle_step_TextRotate[0].setProperty(hmUI.prop.POS_X, 351 - idle_step_TextRotate_error_img_width / 2);
                  idle_step_TextRotate[0].setProperty(hmUI.prop.SRC, 'Act_0.png');
                  idle_step_TextRotate[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

              console.log('update text circle calorie_CALORIE');
              let idle_calorie_circle_string = parseInt(valueCalories).toString();

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 4; i++) {  // hide all symbols
                  idle_calorie_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                idle_calorie_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
                let char_Angle = 275;
                if (valueCalories != null && valueCalories != undefined && isFinite(valueCalories) && idle_calorie_circle_string.length > 0 && idle_calorie_circle_string.length <= 4) {  // display data if it was possible to get it
                  let idle_calorie_TextCircle_img_angle = 0;
                  let idle_calorie_TextCircle_dot_img_angle = 0;
                  let idle_calorie_TextCircle_unit_angle = 0;
                  idle_calorie_TextCircle_img_angle = toDegree(Math.atan2(idle_calorie_TextCircle_img_width/2, 225));
                  idle_calorie_TextCircle_dot_img_angle = toDegree(Math.atan2(idle_calorie_TextCircle_dot_width/2, 225));
                  idle_calorie_TextCircle_unit_angle = toDegree(Math.atan2(idle_calorie_TextCircle_unit_width/2, 225));
                  // alignment = RIGHT
                  let idle_calorie_TextCircle_angleOffset = idle_calorie_TextCircle_img_angle * (idle_calorie_circle_string.length - 1);
                  idle_calorie_TextCircle_angleOffset = idle_calorie_TextCircle_angleOffset + (idle_calorie_TextCircle_img_angle + idle_calorie_TextCircle_unit_angle + 0) / 2;
                  idle_calorie_TextCircle_angleOffset = -idle_calorie_TextCircle_angleOffset;
                  char_Angle -= 2 * idle_calorie_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of idle_calorie_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 4) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= idle_calorie_TextCircle_img_angle;
                      firstSymbol = false;
                      idle_calorie_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      idle_calorie_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - idle_calorie_TextCircle_img_width / 2);
                      idle_calorie_TextCircle[index].setProperty(hmUI.prop.SRC, idle_calorie_TextCircle_ASCIIARRAY[charCode]);
                      idle_calorie_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= idle_calorie_TextCircle_img_angle;
                      index++;
                    }  // end if digit
                    else { 
                      if (!firstSymbol) char_Angle -= idle_calorie_TextCircle_dot_img_angle; 
                      firstSymbol = false;
                      idle_calorie_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      idle_calorie_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - idle_calorie_TextCircle_dot_width / 2);
                      idle_calorie_TextCircle[index].setProperty(hmUI.prop.SRC, 'Dis_dot.png');
                      idle_calorie_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= idle_calorie_TextCircle_dot_img_angle;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                  char_Angle -= idle_calorie_TextCircle_unit_angle;
                  idle_calorie_TextCircle_unit.setProperty(hmUI.prop.ANGLE, char_Angle);
                  idle_calorie_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite
                else {
                  idle_calorie_TextCircle[0].setProperty(hmUI.prop.ANGLE, char_Angle);
                  idle_calorie_TextCircle[0].setProperty(hmUI.prop.POS_X, 240 - idle_calorie_TextCircle_error_img_width / 2);
                  idle_calorie_TextCircle[0].setProperty(hmUI.prop.SRC, 'Act_0.png');
                  idle_calorie_TextCircle[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

              console.log('update text circle DISTANCE');
              let idle_distance_circle_string = (distanceCurrent / 1000).toFixed(2);

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  idle_distance_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                idle_distance_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
                let char_Angle = 274;
                if (distanceCurrent != null && distanceCurrent != undefined && isFinite(distanceCurrent) && idle_distance_circle_string.length > 0 && idle_distance_circle_string.length <= 5) {  // display data if it was possible to get it
                  let idle_distance_TextCircle_img_angle = 0;
                  let idle_distance_TextCircle_dot_img_angle = 0;
                  let idle_distance_TextCircle_unit_angle = 0;
                  idle_distance_TextCircle_img_angle = toDegree(Math.atan2(idle_distance_TextCircle_img_width/2, 202));
                  idle_distance_TextCircle_dot_img_angle = toDegree(Math.atan2(idle_distance_TextCircle_dot_width/2, 202));
                  idle_distance_TextCircle_unit_angle = toDegree(Math.atan2(idle_distance_TextCircle_unit_width/2, 202));
                  // alignment = RIGHT
                  let idle_distance_TextCircle_angleOffset = idle_distance_TextCircle_img_angle * (idle_distance_circle_string.length - 1);
                  idle_distance_TextCircle_angleOffset = idle_distance_TextCircle_angleOffset - idle_distance_TextCircle_img_angle + idle_distance_TextCircle_dot_img_angle;
                  idle_distance_TextCircle_angleOffset = idle_distance_TextCircle_angleOffset + (idle_distance_TextCircle_img_angle + idle_distance_TextCircle_unit_angle + 0) / 2;
                  idle_distance_TextCircle_angleOffset = -idle_distance_TextCircle_angleOffset;
                  char_Angle -= 2 * idle_distance_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of idle_distance_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= idle_distance_TextCircle_img_angle;
                      firstSymbol = false;
                      idle_distance_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      idle_distance_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - idle_distance_TextCircle_img_width / 2);
                      idle_distance_TextCircle[index].setProperty(hmUI.prop.SRC, idle_distance_TextCircle_ASCIIARRAY[charCode]);
                      idle_distance_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= idle_distance_TextCircle_img_angle;
                      index++;
                    }  // end if digit
                    else { 
                      if (!firstSymbol) char_Angle -= idle_distance_TextCircle_dot_img_angle; 
                      firstSymbol = false;
                      idle_distance_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      idle_distance_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - idle_distance_TextCircle_dot_width / 2);
                      idle_distance_TextCircle[index].setProperty(hmUI.prop.SRC, 'Dis_dot.png');
                      idle_distance_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= idle_distance_TextCircle_dot_img_angle;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                  char_Angle -= idle_distance_TextCircle_unit_angle;
                  idle_distance_TextCircle_unit.setProperty(hmUI.prop.ANGLE, char_Angle);
                  idle_distance_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite
                else {
                  idle_distance_TextCircle[0].setProperty(hmUI.prop.ANGLE, char_Angle);
                  idle_distance_TextCircle[0].setProperty(hmUI.prop.POS_X, 240 - idle_distance_TextCircle_error_img_width / 2);
                  idle_distance_TextCircle[0].setProperty(hmUI.prop.SRC, 'Act_0.png');
                  idle_distance_TextCircle[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

              console.log('update text rotate heart_rate_HEART');
              let idle_heart_rate_rotate_string = parseInt(valueHeartRate).toString();

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  idle_heart_rate_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueHeartRate != null && valueHeartRate != undefined && isFinite(valueHeartRate) && idle_heart_rate_rotate_string.length > 0 && idle_heart_rate_rotate_string.length <= 3) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let idle_heart_rate_TextRotate_posOffset = idle_heart_rate_TextRotate_img_width * idle_heart_rate_rotate_string.length;
                  img_offset -= idle_heart_rate_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of idle_heart_rate_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_heart_rate_TextRotate[index].setProperty(hmUI.prop.POS_X, 412 + img_offset);
                      idle_heart_rate_TextRotate[index].setProperty(hmUI.prop.SRC, idle_heart_rate_TextRotate_ASCIIARRAY[charCode]);
                      idle_heart_rate_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_heart_rate_TextRotate_img_width;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite
                else {
                  idle_heart_rate_TextRotate[0].setProperty(hmUI.prop.POS_X, 412 - idle_heart_rate_TextRotate_error_img_width / 2);
                  idle_heart_rate_TextRotate[0].setProperty(hmUI.prop.SRC, 'Act_0.png');
                  idle_heart_rate_TextRotate[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

            };

            //end of ignored block
            function scale_call() {
              console.log('scale_call()');

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_cs_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_battery * 100);
                  if (normal_battery_circle_scale) {
                    normal_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 240,
                      center_y: 240,
                      start_angle: 211,
                      end_angle: 271,
                      radius: 100,
                      line_width: 6,
                      corner_flag: 3,
                      color: 0xFF000000,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_cs_normal_step = 1 - progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_step * 100);
                  if (normal_step_circle_scale) {
                    normal_step_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 240,
                      center_y: 240,
                      start_angle: 89,
                      end_angle: 136,
                      radius: 136,
                      line_width: 79,
                      corner_flag: 3,
                      color: 0xFF4F4F4F,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales BATTERY');
                let progress_cs_idle_battery = progressBattery;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_battery_circle_scale_circle_scale
                  let level = Math.round(progress_cs_idle_battery * 100);
                  if (idle_battery_circle_scale) {
                    idle_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 240,
                      center_y: 240,
                      start_angle: 211,
                      end_angle: 271,
                      radius: 100,
                      line_width: 6,
                      corner_flag: 3,
                      color: 0xFF000000,
                      show_level: hmUI.show_level.ONLY_AOD,
                      level: level,
                    });
                  };
                };

                console.log('update scales STEP');
                let progress_cs_idle_step = 1 - progressStep;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_step_circle_scale_circle_scale
                  let level = Math.round(progress_cs_idle_step * 100);
                  if (idle_step_circle_scale) {
                    idle_step_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 240,
                      center_y: 240,
                      start_angle: 89,
                      end_angle: 136,
                      radius: 136,
                      line_width: 79,
                      corner_flag: 3,
                      color: 0xFF4F4F4F,
                      show_level: hmUI.show_level.ONLY_AOD,
                      level: level,
                    });
                  };
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                time_update(true, true);
                text_update();

                let nawAnimationTime = now.utc;;
                
                let delay_anim_rotate_1 = 0;
                let repeat_anim_rotate_1 = 8000;
                delay_anim_rotate_1 = repeat_anim_rotate_1 - (nawAnimationTime - normal_rotate_animation_lastTime_1);
                if(delay_anim_rotate_1 < 0) delay_anim_rotate_1 = 0; 
                if((nawAnimationTime - normal_rotate_animation_lastTime_1) > repeat_anim_rotate_1*2) {
                  normal_rotate_animation_count_1 = 0;
                  timer_anim_rotate_1_mirror = false;
                };

                if (!timer_anim_rotate_1) {
                  timer_anim_rotate_1 = timer.createTimer(delay_anim_rotate_1, repeat_anim_rotate_1, (function (option) {
                    if(timer_anim_rotate_1_mirror) {
                      anim_rotate_1_mirror()
                    } else {
                      anim_rotate_1_complete_call()
                    };
                    timer_anim_rotate_1_mirror = !timer_anim_rotate_1_mirror;
                  })); // end timer create
                };
                
                let delay_anim_rotate_2 = 0;
                let repeat_anim_rotate_2 = 9000;
                delay_anim_rotate_2 = repeat_anim_rotate_2 - (nawAnimationTime - normal_rotate_animation_lastTime_2);
                if(delay_anim_rotate_2 < 0) delay_anim_rotate_2 = 0; 
                if((nawAnimationTime - normal_rotate_animation_lastTime_2) > repeat_anim_rotate_2*2) {
                  normal_rotate_animation_count_2 = 0;
                  timer_anim_rotate_2_mirror = false;
                };

                if (!timer_anim_rotate_2) {
                  timer_anim_rotate_2 = timer.createTimer(delay_anim_rotate_2, repeat_anim_rotate_2, (function (option) {
                    if(timer_anim_rotate_2_mirror) {
                      anim_rotate_2_mirror()
                    } else {
                      anim_rotate_2_complete_call()
                    };
                    timer_anim_rotate_2_mirror = !timer_anim_rotate_2_mirror;
                  })); // end timer create
                };
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);
                normal_frame_animation_2.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);
                normal_frame_animation_3.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);
                normal_frame_animation_4.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSec) {
                    let animDelay = timeSensor.utc % 1000;
                    let animRepeat = 1000;
                    normal_timerUpdateSec = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, true);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                let secAngle = 0 + (360*6)*(timeSensor.second + ((timeSensor.utc % 1000) / 1000))/360;
                normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, secAngle);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSecSmooth) {
                    let duration = 0;
                    let animDuration = 5000;
                    if (timeSensor.second > 55) animDuration = 1000*(60.1 - (timeSensor.second - (timeSensor.utc % 1000) / 1000));
                    let diffTime = timeSensor.utc - lastTime;
                    if (diffTime < animDuration) duration = animDuration - diffTime;
                    normal_timerUpdateSecSmooth = timer.createTimer(duration, animDuration, (function (option) {
                      lastTime = timeSensor.utc;
                      secAngle = 0 + (360*6)*(timeSensor.second + ((timeSensor.utc % 1000) / 1000))/360;
                      startSecAnim(secAngle, animDuration);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                console.log('pause_call()');
                stop_anim_rotate_1();
                stop_anim_rotate_2();
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);
                normal_frame_animation_2.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);
                normal_frame_animation_3.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);
                normal_frame_animation_4.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);
                if (normal_timerUpdateSec) {
                  timer.stopTimer(normal_timerUpdateSec);
                  normal_timerUpdateSec = undefined;
                }
                if (normal_timerUpdateSecSmooth) {
                  timer.stopTimer(normal_timerUpdateSecSmooth);
                  normal_timerUpdateSecSmooth = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
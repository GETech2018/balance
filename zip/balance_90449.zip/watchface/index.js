try {
    ((() => {
        const {beforeModuleCreate = () => {
            }, afterModuleCreate = () => {
            }} = DeviceRuntimeCore.LifeCycle;
        beforeModuleCreate();
        const {beforePageCreate = () => {
            }, afterPageCreate = () => {
            }} = DeviceRuntimeCore.LifeCycle;
        beforePageCreate();
        const __$$G$$__ = __$$hmAppManager$$__.currentApp.current.__globals__.__$$G$$__;
        !function (context) {
            with (context) {
                const __$$RQR$$__ = __$$R$$__;
                const ui = __$$RQR$$__('@zos/ui');
                const app = __$$RQR$$__('@zos/app');
                const sensor = __$$RQR$$__('@zos/sensor');
                const storage = __$$RQR$$__('@zos/storage');
                const router = __$$RQR$$__('@zos/router');
                const _interopDefaultCompat = e => e && typeof e === 'object' && 'default' in e ? e : { default: e };
                const ui__default = _interopDefaultCompat(ui);
                const positions = {
                    'north-0.png': [
                        230,
                        2
                    ],
                    'north-1.png': [
                        253,
                        3
                    ],
                    'north-2.png': [
                        276,
                        8
                    ],
                    'north-3.png': [
                        299,
                        14
                    ],
                    'north-4.png': [
                        320,
                        22
                    ],
                    'north-5.png': [
                        341,
                        34
                    ],
                    'north-6.png': [
                        361,
                        47
                    ],
                    'north-7.png': [
                        379,
                        62
                    ],
                    'north-8.png': [
                        396,
                        80
                    ],
                    'north-9.png': [
                        411,
                        99
                    ],
                    'north-10.png': [
                        424,
                        120
                    ],
                    'north-11.png': [
                        435,
                        141
                    ],
                    'north-12.png': [
                        444,
                        162
                    ],
                    'north-13.png': [
                        451,
                        185
                    ],
                    'north-14.png': [
                        455,
                        207
                    ],
                    'north-15.png': [
                        457,
                        230
                    ],
                    'north-16.png': [
                        455,
                        253
                    ],
                    'north-17.png': [
                        451,
                        276
                    ],
                    'north-18.png': [
                        444,
                        299
                    ],
                    'north-19.png': [
                        435,
                        320
                    ],
                    'north-20.png': [
                        424,
                        341
                    ],
                    'north-21.png': [
                        411,
                        361
                    ],
                    'north-22.png': [
                        396,
                        379
                    ],
                    'north-23.png': [
                        379,
                        396
                    ],
                    'north-24.png': [
                        361,
                        411
                    ],
                    'north-25.png': [
                        341,
                        424
                    ],
                    'north-26.png': [
                        320,
                        435
                    ],
                    'north-27.png': [
                        299,
                        444
                    ],
                    'north-28.png': [
                        276,
                        451
                    ],
                    'north-29.png': [
                        253,
                        455
                    ],
                    'north-30.png': [
                        230,
                        457
                    ],
                    'north-31.png': [
                        207,
                        455
                    ],
                    'north-32.png': [
                        185,
                        451
                    ],
                    'north-33.png': [
                        162,
                        444
                    ],
                    'north-34.png': [
                        141,
                        435
                    ],
                    'north-35.png': [
                        120,
                        424
                    ],
                    'north-36.png': [
                        99,
                        411
                    ],
                    'north-37.png': [
                        80,
                        396
                    ],
                    'north-38.png': [
                        62,
                        379
                    ],
                    'north-39.png': [
                        47,
                        361
                    ],
                    'north-40.png': [
                        34,
                        341
                    ],
                    'north-41.png': [
                        23,
                        320
                    ],
                    'north-42.png': [
                        14,
                        299
                    ],
                    'north-43.png': [
                        8,
                        276
                    ],
                    'north-44.png': [
                        4,
                        253
                    ],
                    'north-45.png': [
                        2,
                        230
                    ],
                    'north-46.png': [
                        4,
                        207
                    ],
                    'north-47.png': [
                        8,
                        185
                    ],
                    'north-48.png': [
                        14,
                        162
                    ],
                    'north-49.png': [
                        23,
                        141
                    ],
                    'north-50.png': [
                        34,
                        120
                    ],
                    'north-51.png': [
                        47,
                        99
                    ],
                    'north-52.png': [
                        62,
                        80
                    ],
                    'north-53.png': [
                        80,
                        62
                    ],
                    'north-54.png': [
                        99,
                        47
                    ],
                    'north-55.png': [
                        120,
                        34
                    ],
                    'north-56.png': [
                        141,
                        22
                    ],
                    'north-57.png': [
                        162,
                        14
                    ],
                    'north-58.png': [
                        185,
                        8
                    ],
                    'north-59.png': [
                        207,
                        3
                    ]
                };
                var __defProp = Object.defineProperty;
                var __defProps = Object.defineProperties;
                var __getOwnPropDescs = Object.getOwnPropertyDescriptors;
                var __getOwnPropSymbols = Object.getOwnPropertySymbols;
                var __hasOwnProp = Object.prototype.hasOwnProperty;
                var __propIsEnum = Object.prototype.propertyIsEnumerable;
                var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, {
                    enumerable: true,
                    configurable: true,
                    writable: true,
                    value
                }) : obj[key] = value;
                var __spreadValues = (a, b) => {
                    for (var prop in b || (b = {}))
                        if (__hasOwnProp.call(b, prop))
                            __defNormalProp(a, prop, b[prop]);
                    if (__getOwnPropSymbols)
                        for (var prop of __getOwnPropSymbols(b)) {
                            if (__propIsEnum.call(b, prop))
                                __defNormalProp(a, prop, b[prop]);
                        }
                    return a;
                };
                var __spreadProps = (a, b) => __defProps(a, __getOwnPropDescs(b));
                const themes = [
                    16752640,
                    57343,
                    4257628,
                    15619583
                ];
                const N = ui__default.default.show_level.ONLY_NORMAL, A = ui__default.default.show_level.ONLY_AOD;
                const safe = f => {
                    try {
                        return f();
                    } catch (e) {
                        return void 0;
                    }
                };
                const add = (kind, p, level = N) => ui__default.default.createWidget(kind, __spreadProps(__spreadValues({}, p), { show_level: level }));
                const passive = w => {
                    var _a;
                    (_a = w.setEnable) == null ? void 0 : _a.call(w, false);
                    return w;
                };
                const img = (src, x, y, level = N) => passive(add(ui__default.default.widget.IMG, {
                    src,
                    x,
                    y
                }, level));
                const visible = (w, v) => w.setProperty(ui__default.default.prop.VISIBLE, v);
                const text = (x, y, w, h, size, color = 16777215) => passive(add(ui__default.default.widget.TEXT, {
                    x,
                    y,
                    w,
                    h,
                    text: '',
                    text_size: size,
                    color,
                    align_h: ui__default.default.align.CENTER_H,
                    align_v: ui__default.default.align.CENTER_V
                }));
                const put = (w, t) => w.setProperty(ui__default.default.prop.TEXT, String(t));
                const two = n => String(n).padStart(2, '0');
                let cleanup = () => {
                };
                __$$module$$__.module = WatchFace({
                    build() {
                        cleanup();
                        add(ui__default.default.widget.IMG_TIME, {
                            hour_startX: 105,
                            hour_startY: 170,
                            hour_array: Array.from({ length: 10 }, (_, i) => 'aod-' + i + '.png'),
                            hour_space: 0,
                            hour_zero: 1,
                            minute_zero: 1,
                            minute_startX: 245,
                            minute_startY: 170,
                            minute_array: Array.from({ length: 10 }, (_, i) => 'aod-' + i + '.png'),
                            minute_space: 0
                        }, A);
                        img('colon.png', 231, 191, A);
                        if (app.getScene() === app.SCENE_AOD)
                            return;
                        const store = new storage.LocalStorage();
                        const readIndex = (key, count) => {
                            const saved = store.getItem(key);
                            return Number.isInteger(saved) && saved >= 0 && saved < count ? saved : 0;
                        };
                        let theme = readIndex('diagonal-theme', 4);
                        const background = img('t' + theme + '-dial.png', 0, 0);
                        const themed = name => 't' + theme + '-' + name;
                        const now = Date.now();
                        let trial = store.getItem('artist-diagonal-trial-v1');
                        if (!trial || !Number.isFinite(trial.started) || !Number.isFinite(trial.last)) {
                            trial = {
                                started: now,
                                last: now,
                                expired: false
                            };
                            store.setItem('artist-diagonal-trial-v1', trial);
                        }
                        let expired = false, awake = false, timer = null, registered = false;
                        const step = safe(() => new sensor.Step()), heart = safe(() => new sensor.HeartRate());
                        const battery = safe(() => new sensor.Battery()), barometer = safe(() => new sensor.Barometer());
                        const compass = safe(() => new sensor.Compass());
                        const hour = img('hour-00.png', 65, 126), minute = img(themed('minute-00.png'), 223, 192);
                        const seconds = text(377, 188, 55, 45, 35, 16752640);
                        const steps = text(110, 78, 80, 30, 24);
                        const pulse = text(84, 272, 84, 30, 24);
                        const altitude = text(282, 148, 114, 32, 26);
                        const pressure = text(199, 41, 130, 38, 26);
                        const date = text(151, 302, 145, 34, 27, 16756224);
                        const charge = text(352, 303, 82, 32, 27);
                        const stepbar = img(themed('stepbar-0.png'), 201, 89);
                        const rightArc = img(themed('alt-0.png'), 336, 61);
                        const leftArc = img(themed('pulse-0.png'), 30, 247);
                        const days = img(themed('week-0.png'), 95, 331);
                        const north = img('north-0.png', positions['north-0.png'][0], positions['north-0.png'][1]);
                        visible(north, false);
                        const demo = img('demo.png', 64, 134);
                        visible(demo, false);
                        const routes = {
                            activity: router.SYSTEM_APP_STATUS,
                            hr: router.SYSTEM_APP_HR,
                            stress: router.SYSTEM_APP_PRESSURE,
                            oxygen: router.SYSTEM_APP_SPO2,
                            pai: router.SYSTEM_APP_PAI,
                            barometer: router.SYSTEM_APP_ALTIMETER,
                            compass: router.SYSTEM_APP_COMPASS,
                            weather: router.SYSTEM_APP_WEATHER
                        };
                        const open = appId => {
                            if (!isExpired())
                                safe(() => router.launchApp({
                                    appId,
                                    native: true
                                }));
                        };
                        const timeoutIds = new Set();
                        function clearTaps() {
                            timeoutIds.forEach(clearTimeout);
                            timeoutIds.clear();
                        }
                        function button(x, y, w, h, action) {
                            return add(ui__default.default.widget.BUTTON, {
                                x,
                                y,
                                w,
                                h,
                                text: '',
                                normal_src: 'hit-' + w + '-' + h + '.png',
                                press_src: 'hit-' + w + '-' + h + '.png',
                                click_func: () => {
                                    if (!awake || isExpired()) {
                                        refresh();
                                        return;
                                    }
                                    action();
                                }
                            });
                        }
                        function doubleAction(x, y, w, h, single, double) {
                            let pending = null, lastTap = 0;
                            return button(x, y, w, h, () => {
                                const now2 = Date.now();
                                if (pending !== null && timeoutIds.has(pending) && now2 - lastTap <= 330) {
                                    clearTimeout(pending);
                                    timeoutIds.delete(pending);
                                    pending = null;
                                    double();
                                    return;
                                }
                                lastTap = now2;
                                pending = setTimeout(() => {
                                    timeoutIds.delete(pending);
                                    pending = null;
                                    if (awake && !isExpired())
                                        single();
                                }, 330);
                                timeoutIds.add(pending);
                            });
                        }
                        const numFont = Array.from({ length: 10 }, (_, i) => 'small-' + i + '.png');
                        function nativeValue(type, x, y, w) {
                            if (ui__default.default.data_type[type] === void 0)
                                return null;
                            return passive(add(ui__default.default.widget.TEXT_IMG, {
                                x,
                                y,
                                w,
                                h: 30,
                                type: ui__default.default.data_type[type],
                                font_array: numFont,
                                h_space: 0,
                                dot_image: 'small-dot.png',
                                negative_image: 'small-minus.png',
                                invalid_image: 'small-invalid.png',
                                align_h: ui__default.default.align.CENTER_H
                            }));
                        }
                        const fields = [
                            {
                                key: 'activity',
                                count: 4,
                                index: readIndex('diagonal-activity', 4),
                                icon: img('icon-steps.png', 77, 83),
                                iconPos: [
                                    90,
                                    85
                                ],
                                iconNames: [
                                    'steps',
                                    'distance',
                                    'calories',
                                    'active'
                                ],
                                labels: [
                                    '',
                                    'km',
                                    'kcal',
                                    'min'
                                ],
                                zero: steps,
                                units: text(110, 104, 80, 14, 11),
                                values: [
                                    'STEP',
                                    'DISTANCE',
                                    'CAL',
                                    'FAT_BURNING'
                                ].map(t => nativeValue(t, 110, 78, 80)),
                                custom: false,
                                routes: [
                                    'activity',
                                    'activity',
                                    'activity',
                                    'activity'
                                ]
                            },
                            {
                                key: 'health',
                                count: 4,
                                index: readIndex('diagonal-health', 4),
                                icon: img('icon-heart.png', 109, 242),
                                iconPos: [
                                    108,
                                    251
                                ],
                                iconNames: [
                                    'heart',
                                    'stress',
                                    'oxygen',
                                    'pai'
                                ],
                                labels: [
                                    'bpm',
                                    'STR',
                                    '%',
                                    'PAI'
                                ],
                                zero: pulse,
                                units: text(84, 299, 84, 17, 13),
                                values: [
                                    'HEART',
                                    'STRESS',
                                    'SPO2',
                                    'PAI_WEEKLY'
                                ].map(t => nativeValue(t, 84, 272, 84)),
                                custom: false,
                                routes: [
                                    'hr',
                                    'stress',
                                    'oxygen',
                                    'pai'
                                ]
                            },
                            {
                                key: 'altitude',
                                count: 3,
                                index: readIndex('diagonal-altitude', 3),
                                icon: img('icon-mountain.png', 322, 111),
                                iconPos: [
                                    324,
                                    116
                                ],
                                iconNames: [
                                    'mountain',
                                    'pressure',
                                    'compass'
                                ],
                                labels: [
                                    'm',
                                    'hPa',
                                    '\xB0'
                                ],
                                zero: altitude,
                                units: null,
                                values: [],
                                custom: true,
                                routes: [
                                    'barometer',
                                    'barometer',
                                    'compass'
                                ]
                            },
                            {
                                key: 'top',
                                count: 4,
                                index: readIndex('diagonal-top', 4),
                                icon: img('icon-pressure.png', 159, 43),
                                iconPos: [
                                    164,
                                    46
                                ],
                                iconNames: [
                                    'pressure',
                                    'temperature',
                                    'humidity',
                                    'wind'
                                ],
                                labels: [
                                    'hPa',
                                    '\xB0C',
                                    '%',
                                    'Bft'
                                ],
                                zero: pressure,
                                units: text(279, 44, 48, 30, 15),
                                values: [
                                    null,
                                    nativeValue('WEATHER_CURRENT', 203, 44, 76),
                                    nativeValue('HUMIDITY', 203, 44, 76),
                                    nativeValue('WIND', 203, 44, 76)
                                ],
                                custom: false,
                                routes: [
                                    'barometer',
                                    'weather',
                                    'weather',
                                    'weather'
                                ]
                            }
                        ];
                        img('icon-battery.png', 317, 302);
                        let batteryTap = null;
                        function syncFields() {
                            fields.forEach(field => {
                                field.icon.setProperty(ui__default.default.prop.SRC, 'icon-' + field.iconNames[field.index] + '.png');
                                field.values.forEach((value, i) => {
                                    if (value)
                                        visible(value, !expired && i === field.index);
                                });
                                const native = field.values[field.index];
                                visible(field.zero, expired || field.custom || !native);
                                if (field.units) {
                                    visible(field.units, !expired && !!native);
                                    put(field.units, field.labels[field.index]);
                                }
                            });
                            if (batteryTap)
                                visible(batteryTap, !expired);
                        }
                        function applyTheme() {
                            background.setProperty(ui__default.default.prop.SRC, themed('dial.png'));
                            seconds.setProperty(ui__default.default.prop.MORE, { color: themes[theme] });
                            date.setProperty(ui__default.default.prop.MORE, { color: themes[theme] });
                        }
                        function isExpired() {
                            const time = Date.now();
                            trial.expired = trial.expired || time < trial.last - 5000 || time - trial.started >= 1800000;
                            trial.last = Math.max(trial.last, time);
                            store.setItem('artist-diagonal-trial-v1', trial);
                            return trial.expired;
                        }
                        function direction() {
                            if (!awake || expired || !compass)
                                return;
                            const heading = safe(() => compass.getDirectionAngle());
                            const valid = Number.isFinite(heading);
                            visible(north, valid);
                            if (valid) {
                                const src = 'north-' + Math.round((360 - heading) / 6) % 60 + '.png';
                                north.setProperty(ui__default.default.prop.MORE, {
                                    src,
                                    x: positions[src][0],
                                    y: positions[src][1]
                                });
                            }
                        }
                        function stopCompass() {
                            if (registered) {
                                safe(() => compass.offChange(direction));
                                safe(() => compass.stop());
                                registered = false;
                            }
                            visible(north, false);
                        }
                        const frame = (w, p, n) => w.setProperty(ui__default.default.prop.SRC, themed(p + Math.max(0, Math.min(20, Math.round(Number.isFinite(n) ? n : 0))) + '.png'));
                        function refresh() {
                            if (!awake)
                                return;
                            expired = isExpired();
                            syncFields();
                            visible(demo, expired);
                            visible(hour, !expired);
                            visible(minute, !expired);
                            if (expired) {
                                stopCompass();
                                clearTaps();
                                put(seconds, '00');
                                put(steps, '0');
                                put(pulse, '0 bpm');
                                put(altitude, '0 m');
                                put(pressure, '0 hPa');
                                put(date, '00 ---');
                                put(charge, '0%');
                                frame(stepbar, 'stepbar-', 0);
                                frame(leftArc, 'pulse-', 0);
                                frame(rightArc, 'alt-', 0);
                                days.setProperty(ui__default.default.prop.SRC, themed('week-0.png'));
                                return;
                            }
                            const d = new Date();
                            hour.setProperty(ui__default.default.prop.SRC, 'hour-' + two(d.getHours()) + '.png');
                            minute.setProperty(ui__default.default.prop.SRC, themed('minute-' + two(d.getMinutes()) + '.png'));
                            put(seconds, two(d.getSeconds()));
                            const count = safe(() => step.getCurrent()), goal = safe(() => step.getTarget());
                            const hr = safe(() => heart.getLast()), alt = safe(() => barometer.getAltitude());
                            const air = safe(() => barometer.getAirPressure()), bat = safe(() => battery.getCurrent());
                            put(steps, '--');
                            put(pulse, '--');
                            const altitudeField = fields[2];
                            const heading = safe(() => compass.getDirectionAngle());
                            const altValues = [
                                alt,
                                air,
                                heading
                            ];
                            const altValue = altValues[altitudeField.index];
                            const altDisplay = Number.isFinite(altValue) ? Math.round(altValue) + ' ' + altitudeField.labels[altitudeField.index] : '-- ' + altitudeField.labels[altitudeField.index];
                            altitude.setProperty(ui__default.default.prop.MORE, { text_size: altDisplay.length > 7 ? 22 : 26 });
                            put(altitude, altDisplay);
                            pressure.setProperty(ui__default.default.prop.MORE, {
                                x: 199,
                                y: 41,
                                w: 130,
                                h: 38,
                                text_size: 26
                            });
                            put(pressure, fields[3].index === 0 && Number.isFinite(air) && air > 0 ? Math.round(air) + ' hPa' : '-- ' + fields[3].labels[fields[3].index]);
                            put(charge, Number.isFinite(bat) ? Math.round(bat) + '%' : '--%');
                            put(date, two(d.getDate()) + ' ' + [
                                'JAN',
                                'FEB',
                                'MAR',
                                'APR',
                                'MAY',
                                'JUN',
                                'JUL',
                                'AUG',
                                'SEP',
                                'OCT',
                                'NOV',
                                'DEC'
                            ][d.getMonth()]);
                            frame(stepbar, 'stepbar-', goal > 0 ? count / goal * 20 : 0);
                            frame(leftArc, 'pulse-', hr > 0 ? (hr - 40) / 140 * 20 : 0);
                            frame(rightArc, 'alt-', Number.isFinite(alt) ? alt / 4000 * 20 : 0);
                            days.setProperty(ui__default.default.prop.SRC, themed('week-' + ((d.getDay() + 6) % 7 + 1) + '.png'));
                            direction();
                        }
                        function pause() {
                            awake = false;
                            clearTaps();
                            if (timer !== null) {
                                clearInterval(timer);
                                timer = null;
                            }
                            stopCompass();
                        }
                        function resume() {
                            pause();
                            awake = true;
                            refresh();
                            if (!expired && compass) {
                                registered = true;
                                safe(() => compass.onChange(direction));
                                safe(() => compass.start());
                                direction();
                            }
                            timer = setInterval(refresh, 1000);
                        }
                        cleanup = pause;
                        add(ui__default.default.widget.WIDGET_DELEGATE, {
                            resume_call: resume,
                            pause_call: pause
                        });
                        const targets = [
                            [
                                88,
                                78,
                                108,
                                40
                            ],
                            [
                                67,
                                248,
                                111,
                                54
                            ],
                            [
                                294,
                                112,
                                106,
                                62
                            ],
                            [
                                159,
                                40,
                                174,
                                38
                            ]
                        ];
                        fields.forEach((field, i) => doubleAction(...targets[i], () => {
                            field.index = (field.index + 1) % field.count;
                            store.setItem('diagonal-' + field.key, field.index);
                            refresh();
                        }, () => open(routes[field.routes[field.index]])));
                        button(68, 132, 151, 105, () => open(router.SYSTEM_APP_ALARM));
                        button(232, 196, 143, 105, () => open(router.SYSTEM_APP_ALARM));
                        button(150, 305, 155, 30, () => open(router.SYSTEM_APP_CALENDAR));
                        button(100, 338, 301, 33, () => open(router.SYSTEM_APP_CALENDAR));
                        button(160, 386, 160, 40, () => {
                            theme = (theme + 1) % 4;
                            store.setItem('diagonal-theme', theme);
                            applyTheme();
                            refresh();
                        });
                        for (const [x, y, w, h] of [
                                [
                                    223,
                                    14,
                                    34,
                                    25
                                ],
                                [
                                    436,
                                    225,
                                    34,
                                    30
                                ],
                                [
                                    223,
                                    435,
                                    34,
                                    30
                                ],
                                [
                                    10,
                                    225,
                                    32,
                                    30
                                ]
                            ]) {
                            button(x, y, w, h, () => open(router.SYSTEM_APP_COMPASS));
                        }
                        if (ui__default.default.data_type.BATTERY !== void 0) {
                            batteryTap = add(ui__default.default.widget.IMG_CLICK, {
                                x: 320,
                                y: 305,
                                w: 106,
                                h: 30,
                                src: 'hit-106-30.png',
                                type: ui__default.default.data_type.BATTERY
                            });
                        }
                        applyTheme();
                        resume();
                    },
                    onDestroy() {
                        cleanup();
                    }
                });
                ;
            }
        }.bind(__$$G$$__)(__$$G$$__);
        afterPageCreate();
        afterModuleCreate();
        ;
    })());
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
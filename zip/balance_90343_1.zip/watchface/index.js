﻿    /*
    ** Watch_Face_Editor tool v 18.2
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_battery_TextRotate = new Array(3);
        let normal_battery_TextRotate_ASCIIARRAY = new Array(10);
        let normal_battery_TextRotate_img_width = 40;
        let normal_battery_TextRotate_unit = null;
        let normal_battery_TextRotate_unit_width = 40;
        let normal_battery_TextRotate_error_img_width = 40;
        let normal_heart_rate_TextRotate = new Array(3);
        let normal_heart_rate_TextRotate_ASCIIARRAY = new Array(10);
        let normal_heart_rate_TextRotate_img_width = 40;
        let normal_step_TextRotate = new Array(5);
        let normal_step_TextRotate_ASCIIARRAY = new Array(10);
        let normal_step_TextRotate_img_width = 40;
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let normal_time_second_text_font = ''
        let normal_timerTimeUpdate = undefined;
        let normal_analog_clock_time_pointer_second = ''
        let normal_image_img = ''
        let idle_background_bg_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_week_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_temperature_current_text_img = ''
        let idle_battery_TextRotate = new Array(3);
        let idle_battery_TextRotate_ASCIIARRAY = new Array(10);
        let idle_battery_TextRotate_img_width = 40;
        let idle_battery_TextRotate_unit = null;
        let idle_battery_TextRotate_unit_width = 40;
        let idle_battery_TextRotate_error_img_width = 40;
        let idle_heart_rate_TextRotate = new Array(3);
        let idle_heart_rate_TextRotate_ASCIIARRAY = new Array(10);
        let idle_heart_rate_TextRotate_img_width = 40;
        let idle_step_TextRotate = new Array(5);
        let idle_step_TextRotate_ASCIIARRAY = new Array(10);
        let idle_step_TextRotate_img_width = 40;
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let idle_time_second_text_font = ''
        let idle_timerTimeUpdate = undefined;
        let idle_analog_clock_time_pointer_second = ''
        let idle_image_img = ''
        let image_top_img = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let Button_7 = ''
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            // FontName: FjallaOne-Regular.ttf; FontSize: 30
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 439,
              h: 42,
              text_size: 30,
              char_space: 2,
              line_space: 0,
              font: 'fonts/FjallaOne-Regular.ttf',
              color: 0xFFFF5555,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _+-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: '00.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 50,
              y: 67,
              src: 'Alarm_2.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 57,
              y: 33,
              src: 'Clock-1.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 260,
              month_startY: 182,
              month_sc_array: ["M_month_01.png","M_month_02.png","M_month_03.png","M_month_04.png","M_month_05.png","M_month_06.png","M_month_07.png","M_month_08.png","M_month_09.png","M_month_10.png","M_month_11.png","M_month_12.png"],
              month_tc_array: ["M_month_01.png","M_month_02.png","M_month_03.png","M_month_04.png","M_month_05.png","M_month_06.png","M_month_07.png","M_month_08.png","M_month_09.png","M_month_10.png","M_month_11.png","M_month_12.png"],
              month_en_array: ["M_month_01.png","M_month_02.png","M_month_03.png","M_month_04.png","M_month_05.png","M_month_06.png","M_month_07.png","M_month_08.png","M_month_09.png","M_month_10.png","M_month_11.png","M_month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 212,
              day_startY: 182,
              day_sc_array: ["A_digit_01.png","A_digit_02.png","A_digit_03.png","A_digit_04.png","A_digit_05.png","A_digit_06.png","A_digit_07.png","A_digit_08.png","A_digit_09.png","A_digit_10.png"],
              day_tc_array: ["A_digit_01.png","A_digit_02.png","A_digit_03.png","A_digit_04.png","A_digit_05.png","A_digit_06.png","A_digit_07.png","A_digit_08.png","A_digit_09.png","A_digit_10.png"],
              day_en_array: ["A_digit_01.png","A_digit_02.png","A_digit_03.png","A_digit_04.png","A_digit_05.png","A_digit_06.png","A_digit_07.png","A_digit_08.png","A_digit_09.png","A_digit_10.png"],
              day_zero: 1,
              day_space: -24,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 165,
              y: 182,
              week_en: ["D_day_01.png","D_day_02.png","D_day_03.png","D_day_04.png","D_day_05.png","D_day_06.png","D_day_07.png"],
              week_tc: ["D_day_01.png","D_day_02.png","D_day_03.png","D_day_04.png","D_day_05.png","D_day_06.png","D_day_07.png"],
              week_sc: ["D_day_01.png","D_day_02.png","D_day_03.png","D_day_04.png","D_day_05.png","D_day_06.png","D_day_07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 27,
              y: 226,
              image_array: ["W_1.png","W_2.png","W_3.png","W_4.png","W_5.png","W_5_-_Copy.png","W_6.png","W_7.png","W_8.png","w_9.png","W_10.png","w_11.png","W_12.png","W_13.png","W_14.png","W_15.png","W_16.png","W_17.png","W_18.png","W_19.png","W_20.png","W_21.png","W_22.png","w_23.png","W_24.png","W_25.png","W_26.png","W_27.png","W_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 80,
              y: 353,
              font_array: ["T_digit_01.png","T_digit_02.png","T_digit_03.png","T_digit_04.png","T_digit_05.png","T_digit_06.png","T_digit_07.png","T_digit_08.png","T_digit_09.png","T_digit_10.png"],
              padding: false,
              h_space: -13,
              unit_sc: 'T_special_13.png',
              unit_tc: 'T_special_13.png',
              unit_en: 'T_special_13.png',
              negative_image: 'T_special_11.png',
              invalid_image: 'T_special_16.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_battery_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 329,
              // y: 343,
              // font_array: ["T_digit_01.png","T_digit_02.png","T_digit_03.png","T_digit_04.png","T_digit_05.png","T_digit_06.png","T_digit_07.png","T_digit_08.png","T_digit_09.png","T_digit_10.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: -10,
              // angle: -44,
              // unit_en: 'T_special_15.png',
              // invalid_image: 'T_special_16.png',
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_battery_TextRotate_ASCIIARRAY[0] = 'T_digit_01.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[1] = 'T_digit_02.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[2] = 'T_digit_03.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[3] = 'T_digit_04.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[4] = 'T_digit_05.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[5] = 'T_digit_06.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[6] = 'T_digit_07.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[7] = 'T_digit_08.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[8] = 'T_digit_09.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[9] = 'T_digit_10.png';  // set of images with numbers

            //#region TextRotate
            for (let i = 0; i < 3; i++) {
              normal_battery_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 329,
                center_y: 343,
                pos_x: 329,
                pos_y: 343,
                angle: -44,
                src: 'T_digit_01.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_battery_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_battery_TextRotate_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              center_x: 329,
              center_y: 343,
              pos_x: 329,
              pos_y: 343,
              angle: -44,
              src: 'T_special_15.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_battery_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
            //#endregion
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            // normal_heart_rate_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 132,
              // y: 98,
              // font_array: ["T_digit_01.png","T_digit_02.png","T_digit_03.png","T_digit_04.png","T_digit_05.png","T_digit_06.png","T_digit_07.png","T_digit_08.png","T_digit_09.png","T_digit_10.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: -9,
              // angle: -43,
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_heart_rate_TextRotate_ASCIIARRAY[0] = 'T_digit_01.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[1] = 'T_digit_02.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[2] = 'T_digit_03.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[3] = 'T_digit_04.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[4] = 'T_digit_05.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[5] = 'T_digit_06.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[6] = 'T_digit_07.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[7] = 'T_digit_08.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[8] = 'T_digit_09.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[9] = 'T_digit_10.png';  // set of images with numbers

            //#region TextRotate
            for (let i = 0; i < 3; i++) {
              normal_heart_rate_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 132,
                center_y: 98,
                pos_x: 132,
                pos_y: 98,
                angle: -43,
                src: 'T_digit_01.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_heart_rate_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //#endregion
            
            const heart_rate = hmSensor.createSensor(hmSensor.id.HEART);
            heart_rate.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            // normal_step_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 374,
              // y: 125,
              // font_array: ["T_digit_01.png","T_digit_02.png","T_digit_03.png","T_digit_04.png","T_digit_05.png","T_digit_06.png","T_digit_07.png","T_digit_08.png","T_digit_09.png","T_digit_10.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: -9,
              // angle: 45,
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_step_TextRotate_ASCIIARRAY[0] = 'T_digit_01.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[1] = 'T_digit_02.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[2] = 'T_digit_03.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[3] = 'T_digit_04.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[4] = 'T_digit_05.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[5] = 'T_digit_06.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[6] = 'T_digit_07.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[7] = 'T_digit_08.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[8] = 'T_digit_09.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[9] = 'T_digit_10.png';  // set of images with numbers

            //#region TextRotate
            for (let i = 0; i < 5; i++) {
              normal_step_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 374,
                center_y: 125,
                pos_x: 374,
                pos_y: 125,
                angle: 45,
                src: 'T_digit_01.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_step_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //#endregion
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 215,
              am_y: 294,
              am_sc_path: 'A_special_11.png',
              am_en_path: 'A_special_11.png',
              pm_x: 215,
              pm_y: 294,
              pm_sc_path: 'A_special_12.png',
              pm_en_path: 'A_special_12.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 170,
              hour_startY: 231,
              hour_array: ["digit_01.png","digit_02.png","digit_03.png","digit_04.png","digit_05.png","digit_06.png","digit_07.png","digit_08.png","digit_09.png","digit_10.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_unit_sc: 'dots_1.png',
              hour_unit_tc: 'dots_1.png',
              hour_unit_en: 'dots_1.png',
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 0,
              minute_startY: 0,
              minute_array: ["digit_01.png","digit_02.png","digit_03.png","digit_04.png","digit_05.png","digit_06.png","digit_07.png","digit_08.png","digit_09.png","digit_10.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 1,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            let screenType = hmSetting.getScreenType();
            normal_time_second_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 247,
              y: 258,
              w: 150,
              h: 30,
              text_size: 30,
              char_space: 2,
              font: 'fonts/FjallaOne-Regular.ttf',
              color: 0xFFFF5555,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'seg.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 240,
              second_posY: 240,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 307,
              y: 251,
              src: '922.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: '00.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 50,
              y: 67,
              src: 'Alarm_2.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 57,
              y: 33,
              src: 'Clock-1.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 260,
              month_startY: 182,
              month_sc_array: ["M_month_01.png","M_month_02.png","M_month_03.png","M_month_04.png","M_month_05.png","M_month_06.png","M_month_07.png","M_month_08.png","M_month_09.png","M_month_10.png","M_month_11.png","M_month_12.png"],
              month_tc_array: ["M_month_01.png","M_month_02.png","M_month_03.png","M_month_04.png","M_month_05.png","M_month_06.png","M_month_07.png","M_month_08.png","M_month_09.png","M_month_10.png","M_month_11.png","M_month_12.png"],
              month_en_array: ["M_month_01.png","M_month_02.png","M_month_03.png","M_month_04.png","M_month_05.png","M_month_06.png","M_month_07.png","M_month_08.png","M_month_09.png","M_month_10.png","M_month_11.png","M_month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 212,
              day_startY: 182,
              day_sc_array: ["A_digit_01.png","A_digit_02.png","A_digit_03.png","A_digit_04.png","A_digit_05.png","A_digit_06.png","A_digit_07.png","A_digit_08.png","A_digit_09.png","A_digit_10.png"],
              day_tc_array: ["A_digit_01.png","A_digit_02.png","A_digit_03.png","A_digit_04.png","A_digit_05.png","A_digit_06.png","A_digit_07.png","A_digit_08.png","A_digit_09.png","A_digit_10.png"],
              day_en_array: ["A_digit_01.png","A_digit_02.png","A_digit_03.png","A_digit_04.png","A_digit_05.png","A_digit_06.png","A_digit_07.png","A_digit_08.png","A_digit_09.png","A_digit_10.png"],
              day_zero: 1,
              day_space: -24,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 165,
              y: 182,
              week_en: ["D_day_01.png","D_day_02.png","D_day_03.png","D_day_04.png","D_day_05.png","D_day_06.png","D_day_07.png"],
              week_tc: ["D_day_01.png","D_day_02.png","D_day_03.png","D_day_04.png","D_day_05.png","D_day_06.png","D_day_07.png"],
              week_sc: ["D_day_01.png","D_day_02.png","D_day_03.png","D_day_04.png","D_day_05.png","D_day_06.png","D_day_07.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 27,
              y: 226,
              image_array: ["W_1.png","W_2.png","W_3.png","W_4.png","W_5.png","W_5_-_Copy.png","W_6.png","W_7.png","W_8.png","w_9.png","W_10.png","w_11.png","W_12.png","W_13.png","W_14.png","W_15.png","W_16.png","W_17.png","W_18.png","W_19.png","W_20.png","W_21.png","W_22.png","w_23.png","W_24.png","W_25.png","W_26.png","W_27.png","W_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 80,
              y: 353,
              font_array: ["T_digit_01.png","T_digit_02.png","T_digit_03.png","T_digit_04.png","T_digit_05.png","T_digit_06.png","T_digit_07.png","T_digit_08.png","T_digit_09.png","T_digit_10.png"],
              padding: false,
              h_space: -13,
              unit_sc: 'T_special_13.png',
              unit_tc: 'T_special_13.png',
              unit_en: 'T_special_13.png',
              negative_image: 'T_special_11.png',
              invalid_image: 'T_special_16.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_battery_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 329,
              // y: 343,
              // font_array: ["T_digit_01.png","T_digit_02.png","T_digit_03.png","T_digit_04.png","T_digit_05.png","T_digit_06.png","T_digit_07.png","T_digit_08.png","T_digit_09.png","T_digit_10.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: -10,
              // angle: -44,
              // unit_en: 'T_special_15.png',
              // invalid_image: 'T_special_16.png',
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_battery_TextRotate_ASCIIARRAY[0] = 'T_digit_01.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[1] = 'T_digit_02.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[2] = 'T_digit_03.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[3] = 'T_digit_04.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[4] = 'T_digit_05.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[5] = 'T_digit_06.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[6] = 'T_digit_07.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[7] = 'T_digit_08.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[8] = 'T_digit_09.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[9] = 'T_digit_10.png';  // set of images with numbers

            //#region TextRotate
            for (let i = 0; i < 3; i++) {
              idle_battery_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 329,
                center_y: 343,
                pos_x: 329,
                pos_y: 343,
                angle: -44,
                src: 'T_digit_01.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_battery_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            idle_battery_TextRotate_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              center_x: 329,
              center_y: 343,
              pos_x: 329,
              pos_y: 343,
              angle: -44,
              src: 'T_special_15.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            idle_battery_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
            //#endregion

            // idle_heart_rate_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 132,
              // y: 98,
              // font_array: ["T_digit_01.png","T_digit_02.png","T_digit_03.png","T_digit_04.png","T_digit_05.png","T_digit_06.png","T_digit_07.png","T_digit_08.png","T_digit_09.png","T_digit_10.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: -9,
              // angle: -43,
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_heart_rate_TextRotate_ASCIIARRAY[0] = 'T_digit_01.png';  // set of images with numbers
            idle_heart_rate_TextRotate_ASCIIARRAY[1] = 'T_digit_02.png';  // set of images with numbers
            idle_heart_rate_TextRotate_ASCIIARRAY[2] = 'T_digit_03.png';  // set of images with numbers
            idle_heart_rate_TextRotate_ASCIIARRAY[3] = 'T_digit_04.png';  // set of images with numbers
            idle_heart_rate_TextRotate_ASCIIARRAY[4] = 'T_digit_05.png';  // set of images with numbers
            idle_heart_rate_TextRotate_ASCIIARRAY[5] = 'T_digit_06.png';  // set of images with numbers
            idle_heart_rate_TextRotate_ASCIIARRAY[6] = 'T_digit_07.png';  // set of images with numbers
            idle_heart_rate_TextRotate_ASCIIARRAY[7] = 'T_digit_08.png';  // set of images with numbers
            idle_heart_rate_TextRotate_ASCIIARRAY[8] = 'T_digit_09.png';  // set of images with numbers
            idle_heart_rate_TextRotate_ASCIIARRAY[9] = 'T_digit_10.png';  // set of images with numbers

            //#region TextRotate
            for (let i = 0; i < 3; i++) {
              idle_heart_rate_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 132,
                center_y: 98,
                pos_x: 132,
                pos_y: 98,
                angle: -43,
                src: 'T_digit_01.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_heart_rate_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //#endregion

            // idle_step_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 374,
              // y: 125,
              // font_array: ["T_digit_01.png","T_digit_02.png","T_digit_03.png","T_digit_04.png","T_digit_05.png","T_digit_06.png","T_digit_07.png","T_digit_08.png","T_digit_09.png","T_digit_10.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: -9,
              // angle: 45,
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_step_TextRotate_ASCIIARRAY[0] = 'T_digit_01.png';  // set of images with numbers
            idle_step_TextRotate_ASCIIARRAY[1] = 'T_digit_02.png';  // set of images with numbers
            idle_step_TextRotate_ASCIIARRAY[2] = 'T_digit_03.png';  // set of images with numbers
            idle_step_TextRotate_ASCIIARRAY[3] = 'T_digit_04.png';  // set of images with numbers
            idle_step_TextRotate_ASCIIARRAY[4] = 'T_digit_05.png';  // set of images with numbers
            idle_step_TextRotate_ASCIIARRAY[5] = 'T_digit_06.png';  // set of images with numbers
            idle_step_TextRotate_ASCIIARRAY[6] = 'T_digit_07.png';  // set of images with numbers
            idle_step_TextRotate_ASCIIARRAY[7] = 'T_digit_08.png';  // set of images with numbers
            idle_step_TextRotate_ASCIIARRAY[8] = 'T_digit_09.png';  // set of images with numbers
            idle_step_TextRotate_ASCIIARRAY[9] = 'T_digit_10.png';  // set of images with numbers

            //#region TextRotate
            for (let i = 0; i < 5; i++) {
              idle_step_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 374,
                center_y: 125,
                pos_x: 374,
                pos_y: 125,
                angle: 45,
                src: 'T_digit_01.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_step_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //#endregion

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 215,
              am_y: 294,
              am_sc_path: 'A_special_11.png',
              am_en_path: 'A_special_11.png',
              pm_x: 215,
              pm_y: 294,
              pm_sc_path: 'A_special_12.png',
              pm_en_path: 'A_special_12.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 170,
              hour_startY: 231,
              hour_array: ["digit_01.png","digit_02.png","digit_03.png","digit_04.png","digit_05.png","digit_06.png","digit_07.png","digit_08.png","digit_09.png","digit_10.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_unit_sc: 'dots_1.png',
              hour_unit_tc: 'dots_1.png',
              hour_unit_en: 'dots_1.png',
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 0,
              minute_startY: 0,
              minute_array: ["digit_01.png","digit_02.png","digit_03.png","digit_04.png","digit_05.png","digit_06.png","digit_07.png","digit_08.png","digit_09.png","digit_10.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 1,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_time_second_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 247,
              y: 258,
              w: 150,
              h: 30,
              text_size: 30,
              char_space: 2,
              font: 'fonts/FjallaOne-Regular.ttf',
              color: 0xFFFF5555,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // padding: true,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'seg.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 240,
              second_posY: 240,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 307,
              y: 251,
              src: '922.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 0,
              // disconneсnt_toast_text: RUSH OFF,
              // conneсnt_vibrate_type: 0,
              // conneсnt_toast_text: RUSH ON,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              console.log('checkConnection()');
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  hmUI.showToast({text: "RUSH OFF"});
                  vibro(0);
                }
                if(status) {
                  hmUI.showToast({text: "RUSH ON"});
                  vibro(0);
                }
              });
            }

            // end vibration when connecting or disconnecting
            //#region vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              if (scene != 1) timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            //#endregion

            image_top_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'com.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 80,
              y: 56,
              w: 100,
              h: 80,
              text: '',
              color: 0xFF00FF00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'heart_app_Screen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 306,
              y: 56,
              w: 100,
              h: 80,
              text: '',
              color: 0xFF00FF00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'activityAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 306,
              y: 324,
              w: 100,
              h: 80,
              text: '',
              color: 0xFF00FF00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'Settings_batteryManagerScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 88,
              y: 324,
              w: 100,
              h: 80,
              text: '',
              color: 0xFF00FF00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'TideScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 30,
              y: 216,
              w: 100,
              h: 80,
              text: '',
              color: 0xFF00FF00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'WeatherScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 186,
              y: 137,
              w: 40,
              h: 40,
              text: '',
              color: 0xFF00FF00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'AlarmInfoScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_7 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 165,
              y: 182,
              w: 151,
              h: 40,
              text: '',
              color: 0xFF00FF00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            //#region time_update
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              console.log('second font');
                let normal_secondStr = second.toString();
                normal_secondStr = normal_secondStr.padStart(2, '0');
                normal_time_second_text_font.setProperty(hmUI.prop.TEXT, normal_secondStr );
              console.log('second font');
                let idle_secondStr = second.toString();
                idle_secondStr = idle_secondStr.padStart(2, '0');
                idle_time_second_text_font.setProperty(hmUI.prop.TEXT, idle_secondStr );
            };

            //#endregion
            //#region text_update
            function text_update() {
              console.log('text_update()');

              console.log('update text rotate battery_BATTERY');
              let valueBattery = battery.current;
              let normal_battery_rotate_string = parseInt(valueBattery).toString();
              normal_battery_rotate_string = normal_battery_rotate_string.padStart(3, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  normal_battery_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_battery_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
                if (valueBattery != null && valueBattery != undefined && isFinite(valueBattery) && normal_battery_rotate_string.length > 0 && normal_battery_rotate_string.length <= 3) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let normal_battery_TextRotate_posOffset = normal_battery_TextRotate_img_width * normal_battery_rotate_string.length;
                  normal_battery_TextRotate_posOffset = normal_battery_TextRotate_posOffset + -10 * (normal_battery_rotate_string.length - 1);
                  img_offset -= normal_battery_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_battery_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_battery_TextRotate[index].setProperty(hmUI.prop.POS_X, 329 + img_offset);
                      normal_battery_TextRotate[index].setProperty(hmUI.prop.SRC, normal_battery_TextRotate_ASCIIARRAY[charCode]);
                      normal_battery_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_battery_TextRotate_img_width + -10;
                      index++;
                    };  // end if digit
                  };  // end char of string
                  normal_battery_TextRotate_unit.setProperty(hmUI.prop.POS_X, 329 + img_offset);
                  normal_battery_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite
                else {
                  normal_battery_TextRotate[0].setProperty(hmUI.prop.POS_X, 329 - normal_battery_TextRotate_error_img_width / 2);
                  normal_battery_TextRotate[0].setProperty(hmUI.prop.SRC, 'T_special_16.png');
                  normal_battery_TextRotate[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

              console.log('update text rotate heart_rate_HEART');
              let valueHeartRate = heart_rate.last;
              let normal_heart_rate_rotate_string = parseInt(valueHeartRate).toString();
              normal_heart_rate_rotate_string = normal_heart_rate_rotate_string.padStart(3, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  normal_heart_rate_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueHeartRate != null && valueHeartRate != undefined && isFinite(valueHeartRate) && normal_heart_rate_rotate_string.length > 0 && normal_heart_rate_rotate_string.length <= 3) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let normal_heart_rate_TextRotate_posOffset = normal_heart_rate_TextRotate_img_width * normal_heart_rate_rotate_string.length;
                  normal_heart_rate_TextRotate_posOffset = normal_heart_rate_TextRotate_posOffset + -9 * (normal_heart_rate_rotate_string.length - 1);
                  img_offset -= normal_heart_rate_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_heart_rate_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_heart_rate_TextRotate[index].setProperty(hmUI.prop.POS_X, 132 + img_offset);
                      normal_heart_rate_TextRotate[index].setProperty(hmUI.prop.SRC, normal_heart_rate_TextRotate_ASCIIARRAY[charCode]);
                      normal_heart_rate_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_heart_rate_TextRotate_img_width + -9;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate step_STEP');
              let valueStep = step.current;
              let normal_step_rotate_string = parseInt(valueStep).toString();
              normal_step_rotate_string = normal_step_rotate_string.padStart(5, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  normal_step_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueStep != null && valueStep != undefined && isFinite(valueStep) && normal_step_rotate_string.length > 0 && normal_step_rotate_string.length <= 5) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let normal_step_TextRotate_posOffset = normal_step_TextRotate_img_width * normal_step_rotate_string.length;
                  normal_step_TextRotate_posOffset = normal_step_TextRotate_posOffset + -9 * (normal_step_rotate_string.length - 1);
                  img_offset -= normal_step_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_step_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_step_TextRotate[index].setProperty(hmUI.prop.POS_X, 374 + img_offset);
                      normal_step_TextRotate[index].setProperty(hmUI.prop.SRC, normal_step_TextRotate_ASCIIARRAY[charCode]);
                      normal_step_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_step_TextRotate_img_width + -9;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate battery_BATTERY');
              let idle_battery_rotate_string = parseInt(valueBattery).toString();
              idle_battery_rotate_string = idle_battery_rotate_string.padStart(3, '0');

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  idle_battery_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                idle_battery_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
                if (valueBattery != null && valueBattery != undefined && isFinite(valueBattery) && idle_battery_rotate_string.length > 0 && idle_battery_rotate_string.length <= 3) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let idle_battery_TextRotate_posOffset = idle_battery_TextRotate_img_width * idle_battery_rotate_string.length;
                  idle_battery_TextRotate_posOffset = idle_battery_TextRotate_posOffset + -10 * (idle_battery_rotate_string.length - 1);
                  img_offset -= idle_battery_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of idle_battery_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_battery_TextRotate[index].setProperty(hmUI.prop.POS_X, 329 + img_offset);
                      idle_battery_TextRotate[index].setProperty(hmUI.prop.SRC, idle_battery_TextRotate_ASCIIARRAY[charCode]);
                      idle_battery_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_battery_TextRotate_img_width + -10;
                      index++;
                    };  // end if digit
                  };  // end char of string
                  idle_battery_TextRotate_unit.setProperty(hmUI.prop.POS_X, 329 + img_offset);
                  idle_battery_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite
                else {
                  idle_battery_TextRotate[0].setProperty(hmUI.prop.POS_X, 329 - idle_battery_TextRotate_error_img_width / 2);
                  idle_battery_TextRotate[0].setProperty(hmUI.prop.SRC, 'T_special_16.png');
                  idle_battery_TextRotate[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

              console.log('update text rotate heart_rate_HEART');
              let idle_heart_rate_rotate_string = parseInt(valueHeartRate).toString();
              idle_heart_rate_rotate_string = idle_heart_rate_rotate_string.padStart(3, '0');

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  idle_heart_rate_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueHeartRate != null && valueHeartRate != undefined && isFinite(valueHeartRate) && idle_heart_rate_rotate_string.length > 0 && idle_heart_rate_rotate_string.length <= 3) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let idle_heart_rate_TextRotate_posOffset = idle_heart_rate_TextRotate_img_width * idle_heart_rate_rotate_string.length;
                  idle_heart_rate_TextRotate_posOffset = idle_heart_rate_TextRotate_posOffset + -9 * (idle_heart_rate_rotate_string.length - 1);
                  img_offset -= idle_heart_rate_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of idle_heart_rate_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_heart_rate_TextRotate[index].setProperty(hmUI.prop.POS_X, 132 + img_offset);
                      idle_heart_rate_TextRotate[index].setProperty(hmUI.prop.SRC, idle_heart_rate_TextRotate_ASCIIARRAY[charCode]);
                      idle_heart_rate_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_heart_rate_TextRotate_img_width + -9;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate step_STEP');
              let idle_step_rotate_string = parseInt(valueStep).toString();
              idle_step_rotate_string = idle_step_rotate_string.padStart(5, '0');

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  idle_step_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueStep != null && valueStep != undefined && isFinite(valueStep) && idle_step_rotate_string.length > 0 && idle_step_rotate_string.length <= 5) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let idle_step_TextRotate_posOffset = idle_step_TextRotate_img_width * idle_step_rotate_string.length;
                  idle_step_TextRotate_posOffset = idle_step_TextRotate_posOffset + -9 * (idle_step_rotate_string.length - 1);
                  img_offset -= idle_step_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of idle_step_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_step_TextRotate[index].setProperty(hmUI.prop.POS_X, 374 + img_offset);
                      idle_step_TextRotate[index].setProperty(hmUI.prop.SRC, idle_step_TextRotate_ASCIIARRAY[charCode]);
                      idle_step_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_step_TextRotate_img_width + -9;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

            };

            //#endregion
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                time_update(true, true);
                text_update();
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerTimeUpdate) {
                    normal_timerTimeUpdate = timer.createTimer(0, 1000, (function (option) {
                      let updateHour = timeSensor.minute == 0 && timeSensor.second < 2;
                      let updateMinute = timeSensor.second < 2;
                      time_update(updateHour, updateMinute);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.AOD) {
                  if (!idle_timerTimeUpdate) {
                    idle_timerTimeUpdate = timer.createTimer(0, 1000, (function (option) {
                      let updateHour = timeSensor.minute == 0 && timeSensor.second < 2;
                      let updateMinute = timeSensor.second < 2;
                      time_update(updateHour, updateMinute);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                checkConnection();
                stopVibro();

              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerTimeUpdate) {
                  timer.stopTimer(normal_timerTimeUpdate);
                  normal_timerTimeUpdate = undefined;
                }
                if (idle_timerTimeUpdate) {
                  timer.stopTimer(idle_timerTimeUpdate);
                  idle_timerTimeUpdate = undefined;
                }
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                heart_rate.removeEventListener(heart.event.CURRENT, hrCurrListener);
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
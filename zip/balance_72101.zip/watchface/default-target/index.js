try {
    ((() => {
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        let normal$_$text_f55737581e34449199ac38471283226c = '';
        let timeSensor = '';
        const logger = Logger.getLogger('watchface6');
        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 3,
                    y: 0,
                    src: '2.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_f55737581e34449199ac38471283226c = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 128,
                    y: 57,
                    w: 270,
                    h: 80,
                    text: '[HOUR_24]:[MIN_Z]:[SEC_Z]',
                    color: '0xFFe45f0b',
                    text_size: 60,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                if (!timeSensor) {
                    timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
                }
                timeSensor.addEventListener(timeSensor.event.MINUTEEND, function () {
                    normal$_$text_f55737581e34449199ac38471283226c.setProperty(hmUI.prop.MORE, { text: `${ timeSensor.hour }:${ String(timeSensor.minute).padStart(2, '0') }:${ String(timeSensor.second).padStart(2, '0') }` });
                });
                normal$_$text_f55737581e34449199ac38471283226c.setProperty(hmUI.prop.MORE, { text: `${ timeSensor.hour }:${ String(timeSensor.minute).padStart(2, '0') }:${ String(timeSensor.second).padStart(2, '0') }` });
                timer.createTimer(0, 1000, function (timeSensor2) {
                    normal$_$text_f55737581e34449199ac38471283226c.setProperty(hmUI.prop.MORE, { text: `${ timeSensor2.hour }:${ String(timeSensor2.minute).padStart(2, '0') }:${ String(timeSensor2.second).padStart(2, '0') }` });
                }, timeSensor);
                hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
                    resume_call: function () {
                        normal$_$text_f55737581e34449199ac38471283226c.setProperty(hmUI.prop.MORE, { text: `${ timeSensor.hour }:${ String(timeSensor.minute).padStart(2, '0') }:${ String(timeSensor.second).padStart(2, '0') }` });
                    }
                });
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })());
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
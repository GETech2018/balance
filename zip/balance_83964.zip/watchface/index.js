﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_pai_icon_img = ''
        let normal_system_dnd_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_battery_text_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_distance_icon_img = ''
        let normal_step_icon_img = ''
        let normal_step_current_text_img = ''
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_digital_clock_img_time = ''
        let normal_analog_clock_pro_hour_pointer_img = ''
        let normal_analog_clock_pro_minute_pointer_img = ''
        let normal_timerUpdateSec = undefined;
        let normal_analog_clock_pro_second_pointer_img = ''
        let normal_timerUpdateSecSmooth = undefined;
        let lastTime = 0;
        let idle_background_bg = ''
        let idle_image_img = ''
        let idle_battery_circle_scale = ''
        let idle_heart_rate_text_font = ''
        let idle_date_img_date_day = ''
        let idle_analog_clock_pro_hour_pointer_img = ''
        let idle_analog_clock_pro_minute_pointer_img = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            // FontName: Winner-CondMedium.ttf; FontSize: 35
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 410,
              h: 60,
              text_size: 35,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Winner-CondMedium.ttf',
              color: 0xFF640A0A,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'A100_002.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'A100_020.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 334,
              y: 379,
              src: '0075.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 124,
              y: 380,
              src: '0074.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 230,
              y: 326,
              src: '0076.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 193,
              y: 47,
              font_array: ["A100_004.png","A100_005.png","A100_006.png","A100_007.png","A100_008.png","A100_009.png","A100_010.png","A100_011.png","A100_012.png","A100_013.png"],
              padding: false,
              h_space: -4,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 267,
              y: 309,
              font_array: ["A100_026.png","A100_027.png","A100_028.png","A100_029.png","A100_030.png","A100_031.png","A100_032.png","A100_033.png","A100_034.png","A100_035.png"],
              padding: false,
              h_space: -2,
              dot_image: 'A100_036.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 267,
              y: 287,
              src: 'DISTANCE.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 112,
              y: 287,
              src: 'STEPS.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 94,
              y: 312,
              font_array: ["A100_026.png","A100_027.png","A100_028.png","A100_029.png","A100_030.png","A100_031.png","A100_032.png","A100_033.png","A100_034.png","A100_035.png"],
              padding: false,
              h_space: -2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 292,
              y: 391,
              src: 'A100_015.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 196,
              y: 375,
              font_array: ["A100_004.png","A100_005.png","A100_006.png","A100_007.png","A100_008.png","A100_009.png","A100_010.png","A100_011.png","A100_012.png","A100_013.png"],
              padding: false,
              h_space: -4,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 296,
              y: 394,
              image_array: ["pu_1.png","pu_2.png","pu_3.png","pu_4.png","pu_5.png","pu_6.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 292,
              month_startY: 122,
              month_sc_array: ["A100_050.png","A100_051.png","A100_052.png","A100_053.png","A100_054.png","A100_055.png","A100_056.png","A100_057.png","A100_058.png","A100_059.png","A100_060.png","A100_061.png"],
              month_tc_array: ["A100_050.png","A100_051.png","A100_052.png","A100_053.png","A100_054.png","A100_055.png","A100_056.png","A100_057.png","A100_058.png","A100_059.png","A100_060.png","A100_061.png"],
              month_en_array: ["A100_050.png","A100_051.png","A100_052.png","A100_053.png","A100_054.png","A100_055.png","A100_056.png","A100_057.png","A100_058.png","A100_059.png","A100_060.png","A100_061.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 208,
              day_startY: 118,
              day_sc_array: ["A100_040.png","A100_041.png","A100_042.png","A100_043.png","A100_044.png","A100_045.png","A100_046.png","A100_047.png","A100_048.png","A100_049.png"],
              day_tc_array: ["A100_040.png","A100_041.png","A100_042.png","A100_043.png","A100_044.png","A100_045.png","A100_046.png","A100_047.png","A100_048.png","A100_049.png"],
              day_en_array: ["A100_040.png","A100_041.png","A100_042.png","A100_043.png","A100_044.png","A100_045.png","A100_046.png","A100_047.png","A100_048.png","A100_049.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 103,
              y: 126,
              week_en: ["A100_062.png","A100_063.png","A100_064.png","A100_065.png","A100_066.png","A100_067.png","A100_068.png"],
              week_tc: ["A100_062.png","A100_063.png","A100_064.png","A100_065.png","A100_066.png","A100_067.png","A100_068.png"],
              week_sc: ["A100_062.png","A100_063.png","A100_064.png","A100_065.png","A100_066.png","A100_067.png","A100_068.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 60,
              hour_startY: 186,
              hour_array: ["A100_069.png","A100_070.png","A100_071.png","A100_072.png","A100_073.png","A100_074.png","A100_075.png","A100_076.png","A100_077.png","A100_078.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 192,
              minute_startY: 186,
              minute_array: ["A100_069.png","A100_070.png","A100_071.png","A100_072.png","A100_073.png","A100_074.png","A100_075.png","A100_076.png","A100_077.png","A100_078.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 324,
              second_startY: 186,
              second_array: ["A100_069.png","A100_070.png","A100_071.png","A100_072.png","A100_073.png","A100_074.png","A100_075.png","A100_076.png","A100_077.png","A100_078.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const deviceInfo = hmSetting.getDeviceInfo();
            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.MINUTEEND, function() {
              let updateHour = timeSensor.minute == 0;

              time_update(updateHour, true);
            });

            // normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'arm_hour.png',
              // center_x: 240,
              // center_y: 240,
              // x: 240,
              // y: 240,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.hour,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 240,
              pos_y: 240 - 240,
              center_x: 240,
              center_y: 240,
              src: 'arm_hour.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            // normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'arm_min.png',
              // center_x: 240,
              // center_y: 240,
              // x: 240,
              // y: 240,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.minute,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 240,
              pos_y: 240 - 240,
              center_x: 240,
              center_y: 240,
              src: 'arm_min.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'arm_sec.png',
              // center_x: 240,
              // center_y: 240,
              // x: 240,
              // y: 240,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 240,
              pos_y: 240 - 240,
              center_x: 240,
              center_y: 240,
              src: 'arm_sec.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            function startSecAnim(sec, animDuration) {
              const secAnim = {
                anim_steps: [{
                  anim_rate: 'linear',
                  anim_duration: animDuration,
                  anim_from: sec,
                  anim_to: sec + (360*(animDuration*6/1000))/360,
                  anim_key: 'angle',
                }],
                anim_fps: 15,
                anim_auto_start: 1,
                anim_repeat: 0,
                anim_auto_destroy: 1,
              }
              normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANIM, secAnim);
            }
            // normal_analog_clock_pro_smooth_second = hmUI.createWidget(hmUI.widget.SMOOTH_SECOND, {
              // type: 4,
              // fps: 15,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });



            console.log('Watch_Face.ScreenAOD');
            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'BG_AOD.png',
              // alpha: 127,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img.setAlpha(127);

            // idle_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 240,
              // center_y: 240,
              // start_angle: 360,
              // end_angle: 0,
              // radius: 30,
              // line_width: 5,
              // line_cap: Rounded,
              // color: 0xFF0A640A,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 240,
              center_y: 240,
              start_angle: 360,
              end_angle: 0,
              radius: 28,
              line_width: 5,
              corner_flag: 0,
              color: 0xFF0A640A,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            idle_heart_rate_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 190,
              y: 186,
              w: 100,
              h: 100,
              text_size: 35,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Winner-CondMedium.ttf',
              color: 0xFF640A0A,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 208,
              day_startY: 118,
              day_sc_array: ["A100_040.png","A100_041.png","A100_042.png","A100_043.png","A100_044.png","A100_045.png","A100_046.png","A100_047.png","A100_048.png","A100_049.png"],
              day_tc_array: ["A100_040.png","A100_041.png","A100_042.png","A100_043.png","A100_044.png","A100_045.png","A100_046.png","A100_047.png","A100_048.png","A100_049.png"],
              day_en_array: ["A100_040.png","A100_041.png","A100_042.png","A100_043.png","A100_044.png","A100_045.png","A100_046.png","A100_047.png","A100_048.png","A100_049.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              // alpha: 50,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day.setAlpha(50);

            // idle_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'arm_hour.png',
              // center_x: 240,
              // center_y: 240,
              // x: 240,
              // y: 240,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.hour,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });


            idle_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 240,
              pos_y: 240 - 240,
              center_x: 240,
              center_y: 240,
              src: 'arm_hour.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'arm_min.png',
              // center_x: 240,
              // center_y: 240,
              // x: 240,
              // y: 240,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.minute,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });


            idle_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 240,
              pos_y: 240 - 240,
              center_x: 240,
              center_y: 240,
              src: 'arm_min.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 67,
              y: 194,
              w: 350,
              h: 80,
              text: '',
              color: 0xFFFF8C00,
              text_size: 26,
              press_src: 'null.png',
              normal_src: 'null.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'CountdownAppScreen', native: true });
              }, // end func
              longpress_func: (button_widget) => {
                hmApp.startApp({url: 'StopWatchScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 210,
              y: 374,
              w: 60,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 26,
              press_src: 'null.png',
              normal_src: 'null.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'heart_app_Screen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 207,
              y: 44,
              w: 60,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 26,
              press_src: 'null.png',
              normal_src: 'null.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PowerSaveHintScreen', native: true });
              }, // end func
              longpress_func: (button_widget) => {
                hmApp.startApp({url: 'LowBatteryScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 210,
              y: 120,
              w: 60,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 26,
              press_src: 'null.png',
              normal_src: 'null.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'AlarmInfoScreen', native: true });
              }, // end func
              longpress_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            //start of ignored block
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              if (updateMinute) {
                let normal_hour = hour;
                let normal_fullAngle_hour = 360;
                if (normal_hour > 11) normal_hour -= 12;
                let normal_angle_hour = 0 + normal_fullAngle_hour*normal_hour/12 + (normal_fullAngle_hour/12)*minute/60;
                if (normal_analog_clock_pro_hour_pointer_img) normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_hour);
              };

                let normal_fullAngle_minute = 360;
                let normal_angle_minute = 0 + normal_fullAngle_minute*(minute + second/60)/60;
                if (normal_analog_clock_pro_minute_pointer_img) normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_minute);
              if (updateMinute) {
                let idle_hour = hour;
                let idle_fullAngle_hour = 360;
                if (idle_hour > 11) idle_hour -= 12;
                let idle_angle_hour = 0 + idle_fullAngle_hour*idle_hour/12 + (idle_fullAngle_hour/12)*minute/60;
                if (idle_analog_clock_pro_hour_pointer_img) idle_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.ANGLE, idle_angle_hour);
              };

              if (updateMinute) {
                let idle_fullAngle_minute = 360;
                let idle_angle_minute = 0 + idle_fullAngle_minute*minute/60;
                if (idle_analog_clock_pro_minute_pointer_img) idle_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.ANGLE, idle_angle_minute);
              };

            };

            //end of ignored block
            function scale_call() {
              console.log('scale_call()');

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_cs_idle_battery = progressBattery;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_battery_circle_scale_circle_scale
                  let level = Math.round(progress_cs_idle_battery * 100);
                  if (idle_battery_circle_scale) {
                    idle_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 240,
                      center_y: 240,
                      start_angle: 360,
                      end_angle: 0,
                      radius: 28,
                      line_width: 5,
                      corner_flag: 0,
                      color: 0xFF0A640A,
                      show_level: hmUI.show_level.ONLY_AOD,
                      level: level,
                    });
                  };
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                time_update(true, true);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSec) {
                    let animDelay = timeSensor.utc % 1000;
                    let animRepeat = 1000;
                    normal_timerUpdateSec = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, true);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                let secAngle = 0 + (360*6)*(timeSensor.second + ((timeSensor.utc % 1000) / 1000))/360;
                normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, secAngle);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSecSmooth) {
                    let duration = 0;
                    let animDuration = 5000;
                    if (timeSensor.second > 55) animDuration = 1000*(60.1 - (timeSensor.second - (timeSensor.utc % 1000) / 1000));
                    let diffTime = timeSensor.utc - lastTime;
                    if (diffTime < animDuration) duration = animDuration - diffTime;
                    normal_timerUpdateSecSmooth = timer.createTimer(duration, animDuration, (function (option) {
                      lastTime = timeSensor.utc;
                      secAngle = 0 + (360*6)*(timeSensor.second + ((timeSensor.utc % 1000) / 1000))/360;
                      startSecAnim(secAngle, animDuration);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerUpdateSec) {
                  timer.stopTimer(normal_timerUpdateSec);
                  normal_timerUpdateSec = undefined;
                }
                if (normal_timerUpdateSecSmooth) {
                  timer.stopTimer(normal_timerUpdateSecSmooth);
                  normal_timerUpdateSecSmooth = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
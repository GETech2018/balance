try {
    ((() => {
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        let normal$_$text_be200104919a45a087b130d63566fcf3 = '';
        let normal$_$text_90db534d5f524f5587891bbcecc61bed = '';
        let dateFormat = '';
        let dateFormatMap = '';
        let timeSensor = '';
        const logger = Logger.getLogger('watchface');
        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 480,
                    h: 480,
                    src: '2.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    hour_zero: 1,
                    hour_startX: 74,
                    hour_startY: 180,
                    hour_array: [
                        '3.png',
                        '4.png',
                        '5.png',
                        '6.png',
                        '7.png',
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png',
                        '12.png'
                    ],
                    hour_space: 0,
                    hour_align: hmUI.align.LEFT,
                    minute_zero: 1,
                    minute_startX: 242,
                    minute_startY: 180,
                    minute_array: [
                        '13.png',
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png'
                    ],
                    minute_space: 0,
                    minute_align: hmUI.align.RIGHT,
                    minute_follow: 0,
                    am_x: 412,
                    am_y: 208,
                    am_en_path: '23.png',
                    pm_x: 412,
                    pm_y: 248,
                    pm_en_path: '24.png',
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 130,
                    y: 400,
                    type: hmUI.data_type.VO2MAX,
                    font_array: [
                        '25.png',
                        '26.png',
                        '27.png',
                        '28.png',
                        '29.png',
                        '30.png',
                        '31.png',
                        '32.png',
                        '33.png',
                        '34.png'
                    ],
                    align_h: hmUI.align.CENTER_H,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    invalid_image: '35.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 120,
                    y: 340,
                    src: '36.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 212,
                    y: 400,
                    type: hmUI.data_type.HEART,
                    font_array: [
                        '25.png',
                        '26.png',
                        '27.png',
                        '28.png',
                        '29.png',
                        '30.png',
                        '31.png',
                        '32.png',
                        '33.png',
                        '34.png'
                    ],
                    align_h: hmUI.align.CENTER_H,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    invalid_image: '37.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 212,
                    y: 344,
                    src: '38.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 302,
                    y: 400,
                    type: hmUI.data_type.SPO2,
                    font_array: [
                        '25.png',
                        '26.png',
                        '27.png',
                        '28.png',
                        '29.png',
                        '30.png',
                        '31.png',
                        '32.png',
                        '33.png',
                        '34.png'
                    ],
                    align_h: hmUI.align.CENTER_H,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    invalid_image: '39.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 305,
                    y: 340,
                    src: '40.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_be200104919a45a087b130d63566fcf3 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 74,
                    y: 120,
                    w: 314,
                    h: 32,
                    text: '[WEEK_EN_F]',
                    color: '0xFFb3b3b3',
                    text_size: 24,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_90db534d5f524f5587891bbcecc61bed = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 74,
                    y: 78,
                    w: 314,
                    h: 40,
                    text: '[YEAR]-[MON_Z]-[DAY_Z]',
                    color: '0xFFb3b3b3',
                    text_size: 28,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 212,
                    y: 17,
                    type: hmUI.data_type.BATTERY,
                    font_array: [
                        '25.png',
                        '26.png',
                        '27.png',
                        '28.png',
                        '29.png',
                        '30.png',
                        '31.png',
                        '32.png',
                        '33.png',
                        '34.png'
                    ],
                    align_h: hmUI.align.LEFT,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    unit_sc: '42.png',
                    unit_tc: '42.png',
                    unit_en: '42.png',
                    invalid_image: '41.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 184,
                    y: 15,
                    src: '43.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    hour_zero: 1,
                    hour_startX: 74,
                    hour_startY: 180,
                    hour_array: [
                        '3.png',
                        '4.png',
                        '5.png',
                        '6.png',
                        '7.png',
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png',
                        '12.png'
                    ],
                    hour_space: 0,
                    hour_align: hmUI.align.LEFT,
                    minute_zero: 1,
                    minute_startX: 242,
                    minute_startY: 180,
                    minute_array: [
                        '13.png',
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png'
                    ],
                    minute_space: 0,
                    minute_align: hmUI.align.RIGHT,
                    minute_follow: 0,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_AOD
                });
                if (!timeSensor) {
                    timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
                }
                timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function () {
                    const WEEK_EN_F = function (val) {
                        const valueMap = {
                            '1': 'Monday',
                            '2': 'Tuesday',
                            '3': 'Wednesday',
                            '4': 'Thursday',
                            '5': 'Friday',
                            '6': 'Saturday',
                            '7': 'Sunday'
                        };
                        return valueMap[val];
                    };
                    normal$_$text_be200104919a45a087b130d63566fcf3.setProperty(hmUI.prop.MORE, { text: `${ WEEK_EN_F(timeSensor.week) }` });
                    dateFormat = hmSetting.getDateFormat();
                    dateFormatMap = [
                        () => {
                            normal$_$text_90db534d5f524f5587891bbcecc61bed.setProperty(hmUI.prop.MORE, { text: `${ timeSensor.year }-${ String(timeSensor.month).padStart(2, '0') }-${ String(timeSensor.day).padStart(2, '0') }` });
                        },
                        () => {
                            normal$_$text_90db534d5f524f5587891bbcecc61bed.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.day).padStart(2, '0') }-${ String(timeSensor.month).padStart(2, '0') }-${ timeSensor.year }` });
                        },
                        () => {
                            normal$_$text_90db534d5f524f5587891bbcecc61bed.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.month).padStart(2, '0') }-${ String(timeSensor.day).padStart(2, '0') }-${ timeSensor.year }` });
                        }
                    ];
                    dateFormatMap[dateFormat]();
                });
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 120,
                    y: 340,
                    w: 48,
                    h: 90,
                    type: hmUI.data_type.VO2MAX,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 212,
                    y: 340,
                    w: 48,
                    h: 90,
                    type: hmUI.data_type.HEART,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 304,
                    y: 340,
                    w: 48,
                    h: 90,
                    type: hmUI.data_type.SPO2,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 184,
                    y: 10,
                    w: 100,
                    h: 36,
                    type: hmUI.data_type.BATTERY,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
                    resume_call: function () {
                        const WEEK_EN_F = function (val) {
                            const valueMap = {
                                '1': 'Monday',
                                '2': 'Tuesday',
                                '3': 'Wednesday',
                                '4': 'Thursday',
                                '5': 'Friday',
                                '6': 'Saturday',
                                '7': 'Sunday'
                            };
                            return valueMap[val];
                        };
                        normal$_$text_be200104919a45a087b130d63566fcf3.setProperty(hmUI.prop.MORE, { text: `${ WEEK_EN_F(timeSensor.week) }` });
                        dateFormat = hmSetting.getDateFormat();
                        dateFormatMap = [
                            () => {
                                normal$_$text_90db534d5f524f5587891bbcecc61bed.setProperty(hmUI.prop.MORE, { text: `${ timeSensor.year }-${ String(timeSensor.month).padStart(2, '0') }-${ String(timeSensor.day).padStart(2, '0') }` });
                            },
                            () => {
                                normal$_$text_90db534d5f524f5587891bbcecc61bed.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.day).padStart(2, '0') }-${ String(timeSensor.month).padStart(2, '0') }-${ timeSensor.year }` });
                            },
                            () => {
                                normal$_$text_90db534d5f524f5587891bbcecc61bed.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.month).padStart(2, '0') }-${ String(timeSensor.day).padStart(2, '0') }-${ timeSensor.year }` });
                            }
                        ];
                        dateFormatMap[dateFormat]();
                    }
                });
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })());
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
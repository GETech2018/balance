/*
** Facemaker bundle tool v0.0.3
* *huamiOS watchface js version v4.4.0.1
* *Copyright © Huami. All Rights Reserved
*/


try {
	(() => {
		var __$$app$$__ = __$$hmAppManager$$__.currentApp;
		var __$$module$$__ = __$$app$$__.current;

		//drink is a name,can modify
		var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

		'use strict';

		//dynamic modify start
		let normal_img0 = '';
		let normal_img1 = '';
		let normal_img2 = '';
		let normal_img3 = '';
		let normal_img4 = '';
		let normal_img5 = '';
		let normal_img6 = '';
		let normal_weather_imageset8 = '';
		let normal_weather_imageset9 = '';
		let normal_temperature_current_imagecombo10 = '';
		let normal_temperature_low_imagecombo11 = '';
		let normal_temperature_high_imagecombo12 = '';
		let normal_heart_current_imagecombo14 = '';
		let normal_calories_imagecombo16 = '';
		let normal_distance_imagecombo18 = '';
		let normal_steps_imagecombo20 = '';
		let normal_battery_imagecombo22 = '';
		let normal_airpressure_imagecombo24 = '';
		let normal_sleep_imagecombo26 = new Array(4);
		let normal_sleep_imagecombo26_padding = false;
		let normal_sleep_imagecombo26_array = ['0100.png','0101.png','0102.png','0103.png','0104.png','0105.png','0106.png','0107.png','0108.png','0109.png','0110.png'];
		let normal_stress_imagecombo28 = '';
		let normal_week_imageset30 = '';
		let normal_month_imageset31 = '';
		let normal_date_imagecombo32 = '';
		let normal_hour_imagecombo34 = '';
		let normal_minute_imagecombo35 = '';
		let normal_second_imagecombo36 = '';
		let normal_img37 = '';
		let normal_img38 = '';
		let normal_calories_shortcut41 = '';
		let normal_heart_shortcut42 = '';
		let normal_steps_shortcut43 = '';
		let normal_alarm_shortcut44 = '';
		let normal_calendar_shortcut45 = '';
		let normal_countdown_shortcut46 = '';
		let normal_stopwatch_shortcut47 = '';
		let normal_weather_shortcut48 = '';
		let normal_sleep_shortcut49 = '';
		let normal_stress_shortcut50 = '';
		let normal_battery_shortcut51 = '';
		let idle_hour_imagecombo53 = '';
		let idle_minute_imagecombo54 = '';
		let idle_img55 = '';
		let idle_week_imageset57 = '';
		let idle_month_imageset58 = '';
		let idle_date_imagecombo59 = '';
		//dynamic modify end

		//not required
		const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

		__$$module$$__.module = DeviceRuntimeCore.WatchFace({
			init_view() {

				const sleepSensor = hmSensor.createSensor(hmSensor.id.SLEEP);
				let screenType = hmSetting.getScreenType();

				normal_img0 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					src: '0002.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img1 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 211,
					y: 74,
					w: 24,
					h: 24,
					src: '0003.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img2 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 380,
					y: 74,
					w: 24,
					h: 24,
					src: '0004.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img3 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 27,
					y: 119,
					w: 36,
					h: 36,
					src: '0005.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img4 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 145,
					y: 124,
					w: 25,
					h: 25,
					src: '0006.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img5 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 242,
					y: 122,
					w: 26,
					h: 26,
					src: '0007.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img6 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 358,
					y: 121,
					w: 28,
					h: 28,
					src: '0008.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_weather_imageset8 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
					x: 116,
					y: 18,
					image_array: ["0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png","0016.png","0023.png","0017.png","0024.png","0024.png","0017.png","0025.png","0026.png","0017.png","0027.png","0028.png","0029.png","0030.png"],
					image_length: 29,
					type: hmUI.data_type.WEATHER_CURRENT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_weather_imageset9 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
					x: 57,
					y: 85,
					image_array: ["0031.png","0032.png","0033.png","0034.png","0035.png","0036.png","0037.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png","0043.png","0044.png","0045.png","0046.png","0039.png","0047.png","0048.png","0039.png","0049.png","0050.png","0039.png","0051.png","0052.png","0053.png","0054.png"],
					image_length: 29,
					type: hmUI.data_type.WEATHER_CURRENT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_temperature_current_imagecombo10 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 217,
					y: 10,
					font_array: ["0055.png","0056.png","0057.png","0058.png","0059.png","0060.png","0061.png","0062.png","0063.png","0064.png"],
					padding: false,
					h_space: -4,
					unit_sc: ["0066.png"],
					unit_tc: ["0066.png"],
					unit_en: ["0066.png"],
					negative_image: ["0065.png"],
					invalid_image: ["0065.png"],
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.WEATHER_CURRENT,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_temperature_low_imagecombo11 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 226,
					y: 65,
					font_array: ["0055.png","0056.png","0057.png","0058.png","0059.png","0060.png","0061.png","0062.png","0063.png","0064.png"],
					padding: false,
					h_space: -4,
					unit_sc: ["0066.png"],
					unit_tc: ["0066.png"],
					unit_en: ["0066.png"],
					negative_image: ["0065.png"],
					invalid_image: ["0065.png"],
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.WEATHER_LOW,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_temperature_high_imagecombo12 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 301,
					y: 65,
					font_array: ["0055.png","0056.png","0057.png","0058.png","0059.png","0060.png","0061.png","0062.png","0063.png","0064.png"],
					padding: false,
					h_space: -4,
					unit_sc: ["0066.png"],
					unit_tc: ["0066.png"],
					unit_en: ["0066.png"],
					negative_image: ["0065.png"],
					invalid_image: ["0065.png"],
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.WEATHER_HIGH,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_heart_current_imagecombo14 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 373,
					y: 284,
					font_array: ["0067.png","0068.png","0069.png","0070.png","0071.png","0072.png","0073.png","0074.png","0075.png","0076.png"],
					padding: false,
					h_space: -4,
					invalid_image: '0077.png',
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.HEART,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_calories_imagecombo16 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 323,
					y: 328,
					font_array: ["0055.png","0056.png","0057.png","0058.png","0059.png","0060.png","0061.png","0062.png","0063.png","0064.png"],
					padding: false,
					h_space: -4,
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.CAL,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_distance_imagecombo18 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 278,
					y: 372,
					font_array: ["0055.png","0056.png","0057.png","0058.png","0059.png","0060.png","0061.png","0062.png","0063.png","0064.png"],
					padding: false,
					h_space: -4,
					dot_image: '0078.png',
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.DISTANCE,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_steps_imagecombo20 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 223,
					y: 418,
					font_array: ["0079.png","0080.png","0081.png","0082.png","0083.png","0084.png","0085.png","0086.png","0087.png","0088.png"],
					padding: false,
					h_space: -4,
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.STEP,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_battery_imagecombo22 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 64,
					y: 121,
					font_array: ["0089.png","0090.png","0091.png","0092.png","0093.png","0094.png","0095.png","0096.png","0097.png","0098.png"],
					padding: false,
					h_space: -4,
					unit_sc: '0099.png',
					unit_tc: '0099.png',
					unit_en: '0099.png',
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.BATTERY,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_airpressure_imagecombo24 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 173,
					y: 121,
					font_array: ["0089.png","0090.png","0091.png","0092.png","0093.png","0094.png","0095.png","0096.png","0097.png","0098.png"],
					padding: false,
					h_space: -4,
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.ALTIMETER,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				for (let i = 0; i < normal_sleep_imagecombo26.length; i++) {
					normal_sleep_imagecombo26[i] = hmUI.createWidget(hmUI.widget.IMG, {
						x: 270 + i * 20,
						y: 121,
						w: 20,
						h: 33,
						enable: false,
						show_level: hmUI.show_level.ONLY_NORMAL,
					})

				}

				normal_stress_imagecombo28 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 385,
					y: 121,
					font_array: ["0111.png","0112.png","0113.png","0114.png","0115.png","0116.png","0117.png","0118.png","0119.png","0120.png"],
					padding: false,
					h_space: -4,
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.STRESS,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_week_imageset30 = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
					x: 32,
					y: 290,
					week_en: ["0121.png","0122.png","0123.png","0124.png","0125.png","0126.png","0127.png"],
					week_tc: ["0121.png","0122.png","0123.png","0124.png","0125.png","0126.png","0127.png"],
					week_sc: ["0121.png","0122.png","0123.png","0124.png","0125.png","0126.png","0127.png"],
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_month_imageset31 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
					month_startX: 64,
					month_startY: 325,
					month_sc_array: ["0128.png","0129.png","0130.png","0131.png","0132.png","0133.png","0134.png","0135.png","0136.png","0137.png","0138.png","0139.png"],
					month_tc_array: ["0128.png","0129.png","0130.png","0131.png","0132.png","0133.png","0134.png","0135.png","0136.png","0137.png","0138.png","0139.png"],
					month_en_array: ["0128.png","0129.png","0130.png","0131.png","0132.png","0133.png","0134.png","0135.png","0136.png","0137.png","0138.png","0139.png"],
					month_is_character: true,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_date_imagecombo32 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
					day_startX: 99,
					day_startY: 355,
					day_sc_array: ["0140.png","0141.png","0142.png","0143.png","0144.png","0145.png","0146.png","0147.png","0148.png","0149.png"],
					day_tc_array: ["0140.png","0141.png","0142.png","0143.png","0144.png","0145.png","0146.png","0147.png","0148.png","0149.png"],
					day_en_array: ["0140.png","0141.png","0142.png","0143.png","0144.png","0145.png","0146.png","0147.png","0148.png","0149.png"],
					day_zero: true,
					day_space: 0,
					day_align: hmUI.align.CENTER_H,
					day_is_character: false,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_hour_imagecombo34 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					hour_startX: 25,
					hour_startY: 171,
					hour_array: ["0150.png","0151.png","0152.png","0153.png","0154.png","0155.png","0156.png","0157.png","0158.png","0159.png"],
					hour_zero: true,
					hour_space: 0,
					hour_align: hmUI.align.CENTER_H,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_minute_imagecombo35 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					minute_startX: 178,
					minute_startY: 171,
					minute_array: ["0150.png","0151.png","0152.png","0153.png","0154.png","0155.png","0156.png","0157.png","0158.png","0159.png"],
					minute_zero: true,
					minute_space: 0,
					minute_align: hmUI.align.CENTER_H,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_second_imagecombo36 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					second_startX: 328,
					second_startY: 171,
					second_array: ["0150.png","0151.png","0152.png","0153.png","0154.png","0155.png","0156.png","0157.png","0158.png","0159.png"],
					second_zero: true,
					second_space: 0,
					second_align: hmUI.align.CENTER_H,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img37 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 163,
					y: 190,
					w: 11,
					h: 52,
					src: '0160.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img38 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 313,
					y: 190,
					w: 11,
					h: 52,
					src: '0160.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_calories_shortcut41 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 320,
					y: 330,
					w: 100,
					h: 35,
					src: '',
					type: hmUI.data_type.CAL,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_heart_shortcut42 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 366,
					y: 285,
					w: 100,
					h: 35,
					src: '',
					type: hmUI.data_type.HEART,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_steps_shortcut43 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 253,
					y: 377,
					w: 100,
					h: 100,
					src: '',
					type: hmUI.data_type.STEP,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_alarm_shortcut44 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 49,
					y: 169,
					w: 100,
					h: 100,
					src: '',
					type: hmUI.data_type.ALARM_CLOCK,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_calendar_shortcut45 = hmUI.createWidget(hmUI.widget.BUTTON, {
					x: 73,
					y: 289,
					w: 100,
					h: 100,
					text: '',
					normal_src: '',
					press_src: '',
					click_func: () => {
						hmApp.startApp({ url: 'ScheduleCalScreen', native: true });
					},
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_countdown_shortcut46 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 193,
					y: 169,
					w: 100,
					h: 100,
					src: '',
					type: hmUI.data_type.COUNT_DOWN,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_stopwatch_shortcut47 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 349,
					y: 167,
					w: 100,
					h: 100,
					src: '',
					type: hmUI.data_type.STOP_WATCH,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_weather_shortcut48 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 181,
					y: 7,
					w: 100,
					h: 100,
					src: '',
					type: hmUI.data_type.WEATHER_CURRENT,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_sleep_shortcut49 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 241,
					y: 113,
					w: 100,
					h: 41,
					src: '',
					type: hmUI.data_type.SLEEP,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_stress_shortcut50 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 360,
					y: 116,
					w: 100,
					h: 38,
					src: '',
					type: hmUI.data_type.STRESS,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_battery_shortcut51 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 37,
					y: 119,
					w: 100,
					h: 37,
					src: '',
					type: hmUI.data_type.BATTERY,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				idle_hour_imagecombo53 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					hour_startX: 25,
					hour_startY: 171,
					hour_array: ["0150.png","0151.png","0152.png","0153.png","0154.png","0155.png","0156.png","0157.png","0158.png","0159.png"],
					hour_zero: true,
					hour_space: 0,
					hour_align: hmUI.align.CENTER_H,
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_minute_imagecombo54 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					minute_startX: 178,
					minute_startY: 171,
					minute_array: ["0150.png","0151.png","0152.png","0153.png","0154.png","0155.png","0156.png","0157.png","0158.png","0159.png"],
					minute_zero: true,
					minute_space: 0,
					minute_align: hmUI.align.CENTER_H,
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_img55 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 163,
					y: 190,
					w: 11,
					h: 52,
					src: '0160.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_week_imageset57 = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
					x: 32,
					y: 290,
					week_en: ["0121.png","0122.png","0123.png","0124.png","0125.png","0126.png","0127.png"],
					week_tc: ["0121.png","0122.png","0123.png","0124.png","0125.png","0126.png","0127.png"],
					week_sc: ["0121.png","0122.png","0123.png","0124.png","0125.png","0126.png","0127.png"],
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_month_imageset58 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
					month_startX: 64,
					month_startY: 325,
					month_sc_array: ["0128.png","0129.png","0130.png","0131.png","0132.png","0133.png","0134.png","0135.png","0136.png","0137.png","0138.png","0139.png"],
					month_tc_array: ["0128.png","0129.png","0130.png","0131.png","0132.png","0133.png","0134.png","0135.png","0136.png","0137.png","0138.png","0139.png"],
					month_en_array: ["0128.png","0129.png","0130.png","0131.png","0132.png","0133.png","0134.png","0135.png","0136.png","0137.png","0138.png","0139.png"],
					month_is_character: true,
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_date_imagecombo59 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
					day_startX: 99,
					day_startY: 355,
					day_sc_array: ["0140.png","0141.png","0142.png","0143.png","0144.png","0145.png","0146.png","0147.png","0148.png","0149.png"],
					day_tc_array: ["0140.png","0141.png","0142.png","0143.png","0144.png","0145.png","0146.png","0147.png","0148.png","0149.png"],
					day_en_array: ["0140.png","0141.png","0142.png","0143.png","0144.png","0145.png","0146.png","0147.png","0148.png","0149.png"],
					day_zero: true,
					day_space: 0,
					day_align: hmUI.align.CENTER_H,
					day_is_character: false,
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				function updateSleep() {
					let normal_sleep_imagecombo26_h = Math.floor(sleepSensor.getTotalTime() / 60).toString();
					let normal_sleep_imagecombo26_m = Math.floor(sleepSensor.getTotalTime() % 60).toString().padStart(2, '0');
					let normal_sleep_imagecombo26_current = (normal_sleep_imagecombo26_padding === true ? normal_sleep_imagecombo26_h.padStart(2, '0') : normal_sleep_imagecombo26_h) + ':' + normal_sleep_imagecombo26_m;
					let normal_sleep_imagecombo26_cp = (normal_sleep_imagecombo26_padding === true || normal_sleep_imagecombo26_h.length == 2) ? 2 : 1;
					for (let i = 0; i < normal_sleep_imagecombo26.length; i++) {
						if (i == normal_sleep_imagecombo26_cp) {
							normal_sleep_imagecombo26[i].setProperty(hmUI.prop.SRC, normal_sleep_imagecombo26_array[10]);
						} else {
							normal_sleep_imagecombo26[i].setProperty(hmUI.prop.SRC, normal_sleep_imagecombo26_array[normal_sleep_imagecombo26_current.toString().charAt(i)]);
						}
					}
				}

				sleepSensor.addEventListener(hmSensor.event.CHANGE, function() {
					updateSleep();
				});

				const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
					resume_call: (function () {
						updateSleep();
					}),
					pause_call: (function () {
					}),
				})
			},

		onInit() {
			console.log('index page.js on init invoke')
			this.init_view()
		},
		onReady() {
			console.log('index page.js on ready invoke')
		},
		onShow() {
			console.log('index page.js on show invoke')
		},
		onHide() {
			console.log('index page.js on hide invoke')
		},
		onDestroy() {
			console.log('index page.js on destroy invoke')
		},
	});	})()
} catch (e) {
	console.log(e)
}
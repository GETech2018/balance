﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js
/////////////////////////////////////////////////////////////////////////////////////////////////
		let deviceInfo = hmSetting.getDeviceInfo();
        let colornumber = 1
        let totalcolors = 9
        let namecolor = ''
		let Rootpath = ''
		let AODpath = 'Color9/'
		let normal_digital_clock_img_time_minute = ''
		
        function click_COLOR() {
            if(colornumber >= totalcolors) {
            colornumber=1;
                }
            else {
                colornumber = colornumber+1;
            }
			if ( colornumber == 1) { namecolor = "COLOR 1/9"
				Rootpath = ''
			}
			if ( colornumber == 2) { namecolor = "COLOR 2/9"
				Rootpath = "Color2/"
			}
			if ( colornumber == 3) { namecolor = "COLOR 3/9"
				Rootpath = "Color3/"
			}
			if ( colornumber == 4) { namecolor = "COLOR 4/9"
				Rootpath = "Color4/"
			}
			if ( colornumber == 5) { namecolor = "COLOR 5/9"
				Rootpath = "Color5/"
			}
			if ( colornumber == 6) { namecolor = "COLOR 6/9"
				Rootpath = "Color6/"
			}
			if ( colornumber == 7) { namecolor = "COLOR 7/9"
				Rootpath = "Color7/"
			}
			if ( colornumber == 8) { namecolor = "COLOR 8/9"
				Rootpath = "Color8/"
			}
			if ( colornumber == 9) { namecolor = "COLOR 9/9"
				Rootpath = "Color9/"
			}
			hmUI.showToast({text: namecolor });
			
			normal_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
              x: deviceInfo.width / 480 * 200,
              y: deviceInfo.width / 480 * 407,
              font_array: [Rootpath+"num_00.png",Rootpath+"num_01.png",Rootpath+"num_02.png",Rootpath+"num_03.png",Rootpath+"num_04.png",Rootpath+"num_05.png",Rootpath+"num_06.png",Rootpath+"num_07.png",Rootpath+"num_08.png",Rootpath+"num_09.png"],
              padding: false,
              h_space: 2,
              unit_sc: [Rootpath+"num_11.png"],
              unit_tc: [Rootpath+"num_11.png"],
              unit_en: [Rootpath+"num_11.png"],
              negative_image: [Rootpath+"num_10.png"],
              invalid_image: [Rootpath+"num_12.png"],
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			normal_heart_rate_text_text_img.setProperty(hmUI.prop.MORE, {
              x: deviceInfo.width / 480 * 212,
              y: deviceInfo.width / 480 * 407,
              font_array: [Rootpath+"num_00.png",Rootpath+"num_01.png",Rootpath+"num_02.png",Rootpath+"num_03.png",Rootpath+"num_04.png",Rootpath+"num_05.png",Rootpath+"num_06.png",Rootpath+"num_07.png",Rootpath+"num_08.png",Rootpath+"num_09.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			normal_step_current_text_img.setProperty(hmUI.prop.MORE, {
              x: deviceInfo.width / 480 * 191,
              y: deviceInfo.width / 480 * 407,
              font_array: [Rootpath+"num_00.png",Rootpath+"num_01.png",Rootpath+"num_02.png",Rootpath+"num_03.png",Rootpath+"num_04.png",Rootpath+"num_05.png",Rootpath+"num_06.png",Rootpath+"num_07.png",Rootpath+"num_08.png",Rootpath+"num_09.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			normal_battery_text_text_img.setProperty(hmUI.prop.MORE, {
              x: deviceInfo.width / 480 * 200,
              y: deviceInfo.width / 480 * 407,
              font_array: [Rootpath+"num_00.png",Rootpath+"num_01.png",Rootpath+"num_02.png",Rootpath+"num_03.png",Rootpath+"num_04.png",Rootpath+"num_05.png",Rootpath+"num_06.png",Rootpath+"num_07.png",Rootpath+"num_08.png",Rootpath+"num_09.png"],
              padding: false,
              h_space: 2,
              unit_sc: [Rootpath+"num_13.png"],
              unit_tc: [Rootpath+"num_13.png"],
              unit_en: [Rootpath+"num_13.png"],
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			normal_date_img_date_day.setProperty(hmUI.prop.MORE, {
              day_startX: deviceInfo.width / 480 * 270,
              day_startY: deviceInfo.width / 480 * 98,
              day_sc_array: [Rootpath+"num_00.png",Rootpath+"num_01.png",Rootpath+"num_02.png",Rootpath+"num_03.png",Rootpath+"num_04.png",Rootpath+"num_05.png",Rootpath+"num_06.png",Rootpath+"num_07.png",Rootpath+"num_08.png",Rootpath+"num_09.png"],
              day_tc_array: [Rootpath+"num_00.png",Rootpath+"num_01.png",Rootpath+"num_02.png",Rootpath+"num_03.png",Rootpath+"num_04.png",Rootpath+"num_05.png",Rootpath+"num_06.png",Rootpath+"num_07.png",Rootpath+"num_08.png",Rootpath+"num_09.png"],
              day_en_array: [Rootpath+"num_00.png",Rootpath+"num_01.png",Rootpath+"num_02.png",Rootpath+"num_03.png",Rootpath+"num_04.png",Rootpath+"num_05.png",Rootpath+"num_06.png",Rootpath+"num_07.png",Rootpath+"num_08.png",Rootpath+"num_09.png"],
              day_zero: 1,
              day_space: 2,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			normal_digital_clock_img_time_AmPm.setProperty(hmUI.prop.MORE, {
              am_x: deviceInfo.width / 480 * 300,
              am_y: deviceInfo.width / 480 * 210,
              am_sc_path: [Rootpath+"time_am.png"],
              am_en_path: [Rootpath+"time_am.png"],
              pm_x: deviceInfo.width / 480 * 300,
              pm_y: deviceInfo.width / 480 * 210,
              pm_sc_path: [Rootpath+"time_pm.png"],
              pm_en_path: [Rootpath+"time_pm.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

		}
		
		let element_index = 1;
        let element_count = 4;
		
		function click_CONTENT() {
              element_index++;
              if(element_index > element_count) element_index = 1;

              normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, element_index == 1);
              normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, element_index == 1);
			  Button_1.setProperty(hmUI.prop.VISIBLE, element_index == 1);

              normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, element_index == 2);
              normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, element_index == 2);
			  Button_2.setProperty(hmUI.prop.VISIBLE, element_index == 2);

              normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, element_index == 3);
              normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, element_index == 3);
			  Button_3.setProperty(hmUI.prop.VISIBLE, element_index == 3);
			  
			  normal_battery_icon_img.setProperty(hmUI.prop.VISIBLE, element_index == 4);
              normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, element_index == 4);
			  Button_4.setProperty(hmUI.prop.VISIBLE, element_index == 4);

               if (element_index == 1) {
                 hmUI.showToast({text: 'WEATHER'});
               };
               if (element_index == 2) {
                 hmUI.showToast({text: 'STEPS'});
               };
               if (element_index == 3) {
                 hmUI.showToast({text: 'HEARTRATE'});
               };
			   if (element_index == 4) {
                 hmUI.showToast({text: 'BATTERY'});
               };
            };

/////////////////////////////////////////////////////////////////////////////////////////////////
        // end user_functions.js

        let normal_background_bg = ''
        let normal_image_img = ''
        let normal_system_disconnect_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_step_icon_img = ''
        let normal_step_current_text_img = ''
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_battery_icon_img = ''
        let normal_battery_text_text_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_hour_TextRotate = new Array(2);
        let normal_hour_TextRotate_ASCIIARRAY = new Array(10);
        let normal_hour_TextRotate_img_width = 120;
        let normal_timerTextUpdate = undefined;
        let normal_minute_TextRotate = new Array(2);
        let normal_minute_TextRotate_ASCIIARRAY = new Array(10);
        let normal_minute_TextRotate_img_width = 45;
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg = ''
        let idle_image_img = ''
        let idle_system_disconnect_img = ''
        let idle_battery_icon_img = ''
        let idle_battery_text_text_img = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_week_img = ''
        let idle_hour_TextRotate = new Array(2);
        let idle_hour_TextRotate_ASCIIARRAY = new Array(10);
        let idle_hour_TextRotate_img_width = 120;
        let idle_timerTextUpdate = undefined;
        let idle_minute_TextRotate = new Array(2);
        let idle_minute_TextRotate_ASCIIARRAY = new Array(10);
        let idle_minute_TextRotate_img_width = 45;
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let Button_7 = ''
        let Button_8 = ''
        let Button_9 = ''
        let Button_10 = ''
        let Button_11 = ''
        let timeSensor = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'main.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 310,
              y: 165,
              src: 'st_bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 200,
              y: 407,
              font_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'num_11.png',
              unit_tc: 'num_11.png',
              unit_en: 'num_11.png',
              negative_image: 'num_10.png',
              invalid_image: 'num_12.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 145,
              y: 373,
              image_array: ["weather_01.png","weather_02.png","weather_03.png","weather_04.png","weather_05.png","weather_06.png","weather_07.png","weather_08.png","weather_09.png","weather_10.png","weather_11.png","weather_12.png","weather_13.png","weather_14.png","weather_15.png","weather_16.png","weather_17.png","weather_18.png","weather_19.png","weather_20.png","weather_21.png","weather_22.png","weather_23.png","weather_24.png","weather_25.png","weather_26.png","weather_27.png","weather_28.png","weather_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'sym_steps.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 191,
              y: 407,
              font_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'sym_pulse.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 212,
              y: 407,
              font_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'sym_battery.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 200,
              y: 407,
              font_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'num_13.png',
              unit_tc: 'num_13.png',
              unit_en: 'num_13.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 270,
              day_startY: 98,
              day_sc_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              day_tc_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              day_en_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              day_zero: 1,
              day_space: 2,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 160,
              y: 98,
              week_en: ["wd1.png","wd2.png","wd3.png","wd4.png","wd5.png","wd6.png","wd7.png"],
              week_tc: ["wd1.png","wd2.png","wd3.png","wd4.png","wd5.png","wd6.png","wd7.png"],
              week_sc: ["wd1.png","wd2.png","wd3.png","wd4.png","wd5.png","wd6.png","wd7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_hour_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 92,
              // y: 156,
              // font_array: ["hour2_0.png","hour2_1.png","hour2_2.png","hour2_3.png","hour2_4.png","hour2_5.png","hour2_6.png","hour2_7.png","hour2_8.png","hour2_9.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: 300,
              // angle: 0,
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.HOUR,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_hour_TextRotate_ASCIIARRAY[0] = 'hour2_0.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[1] = 'hour2_1.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[2] = 'hour2_2.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[3] = 'hour2_3.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[4] = 'hour2_4.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[5] = 'hour2_5.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[6] = 'hour2_6.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[7] = 'hour2_7.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[8] = 'hour2_8.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[9] = 'hour2_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              normal_hour_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 92,
                center_y: 156,
                pos_x: 92,
                pos_y: 156,
                angle: 0,
                src: 'hour2_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_hour_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            let screenType = hmSetting.getScreenType();
            // normal_minute_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 290,
              // y: 254,
              // font_array: ["min2_0.png","min2_1.png","min2_2.png","min2_3.png","min2_4.png","min2_5.png","min2_6.png","min2_7.png","min2_8.png","min2_9.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: 300,
              // angle: 0,
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.MINUTE,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_minute_TextRotate_ASCIIARRAY[0] = 'min2_0.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[1] = 'min2_1.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[2] = 'min2_2.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[3] = 'min2_3.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[4] = 'min2_4.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[5] = 'min2_5.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[6] = 'min2_6.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[7] = 'min2_7.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[8] = 'min2_8.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[9] = 'min2_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              normal_minute_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 290,
                center_y: 254,
                pos_x: 290,
                pos_y: 254,
                angle: 0,
                src: 'min2_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_minute_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 300,
              am_y: 210,
              am_sc_path: 'time_am.png',
              am_en_path: 'time_am.png',
              pm_x: 300,
              pm_y: 210,
              pm_sc_path: 'time_pm.png',
              pm_en_path: 'time_pm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: -240,
              hour_startY: 156,
              hour_array: ["hour1_0.png","hour1_1.png","hour1_2.png","hour1_3.png","hour1_4.png","hour1_5.png","hour1_6.png","hour1_7.png","hour1_8.png","hour1_9.png"],
              hour_zero: 1,
              hour_space: 300,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: -125,
              minute_startY: 254,
              minute_array: ["min1_0.png","min1_1.png","min1_2.png","min1_3.png","min1_4.png","min1_5.png","min1_6.png","min1_7.png","min1_8.png","min1_9.png"],
              minute_zero: 1,
              minute_space: 400,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'aod.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 310,
              y: 165,
              src: 'st_bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'sym_battery.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 200,
              y: 407,
              font_array: [AODpath+"num_00.png",AODpath+"num_01.png",AODpath+"num_02.png",AODpath+"num_03.png",AODpath+"num_04.png",AODpath+"num_05.png",AODpath+"num_06.png",AODpath+"num_07.png",AODpath+"num_08.png",AODpath+"num_09.png"],
              padding: false,
              h_space: 2,
              unit_sc: [AODpath+"num_13.png"],
              unit_tc: [AODpath+"num_13.png"],
              unit_en: [AODpath+"num_13.png"],
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 270,
              day_startY: 98,
              day_sc_array: [AODpath+"num_00.png",AODpath+"num_01.png",AODpath+"num_02.png",AODpath+"num_03.png",AODpath+"num_04.png",AODpath+"num_05.png",AODpath+"num_06.png",AODpath+"num_07.png",AODpath+"num_08.png",AODpath+"num_09.png"],
              day_tc_array: [AODpath+"num_00.png",AODpath+"num_01.png",AODpath+"num_02.png",AODpath+"num_03.png",AODpath+"num_04.png",AODpath+"num_05.png",AODpath+"num_06.png",AODpath+"num_07.png",AODpath+"num_08.png",AODpath+"num_09.png"],
              day_en_array: [AODpath+"num_00.png",AODpath+"num_01.png",AODpath+"num_02.png",AODpath+"num_03.png",AODpath+"num_04.png",AODpath+"num_05.png",AODpath+"num_06.png",AODpath+"num_07.png",AODpath+"num_08.png",AODpath+"num_09.png"],
              day_zero: 1,
              day_space: 2,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 160,
              y: 98,
              week_en: ["wd1.png","wd2.png","wd3.png","wd4.png","wd5.png","wd6.png","wd7.png"],
              week_tc: ["wd1.png","wd2.png","wd3.png","wd4.png","wd5.png","wd6.png","wd7.png"],
              week_sc: ["wd1.png","wd2.png","wd3.png","wd4.png","wd5.png","wd6.png","wd7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_hour_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 92,
              // y: 156,
              // font_array: ["hour2_0.png","hour2_1.png","hour2_2.png","hour2_3.png","hour2_4.png","hour2_5.png","hour2_6.png","hour2_7.png","hour2_8.png","hour2_9.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: 300,
              // angle: 0,
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.HOUR,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_hour_TextRotate_ASCIIARRAY[0] = 'hour2_0.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[1] = 'hour2_1.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[2] = 'hour2_2.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[3] = 'hour2_3.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[4] = 'hour2_4.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[5] = 'hour2_5.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[6] = 'hour2_6.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[7] = 'hour2_7.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[8] = 'hour2_8.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[9] = 'hour2_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              idle_hour_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 92,
                center_y: 156,
                pos_x: 92,
                pos_y: 156,
                angle: 0,
                src: 'hour2_0.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_hour_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            // idle_minute_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 290,
              // y: 254,
              // font_array: ["min2_0.png","min2_1.png","min2_2.png","min2_3.png","min2_4.png","min2_5.png","min2_6.png","min2_7.png","min2_8.png","min2_9.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: 300,
              // angle: 0,
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.MINUTE,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_minute_TextRotate_ASCIIARRAY[0] = 'min2_0.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[1] = 'min2_1.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[2] = 'min2_2.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[3] = 'min2_3.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[4] = 'min2_4.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[5] = 'min2_5.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[6] = 'min2_6.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[7] = 'min2_7.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[8] = 'min2_8.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[9] = 'min2_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              idle_minute_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 290,
                center_y: 254,
                pos_x: 290,
                pos_y: 254,
                angle: 0,
                src: 'min2_0.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_minute_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 300,
              am_y: 210,
              am_sc_path: [AODpath+"time_am.png"],
              am_en_path: [AODpath+"time_am.png"],
              pm_x: 300,
              pm_y: 210,
              pm_sc_path: [AODpath+"time_pm.png"],
              pm_en_path: [AODpath+"time_pm.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: -240,
              hour_startY: 156,
              hour_array: ["hour1_0.png","hour1_1.png","hour1_2.png","hour1_3.png","hour1_4.png","hour1_5.png","hour1_6.png","hour1_7.png","hour1_8.png","hour1_9.png"],
              hour_zero: 1,
              hour_space: 300,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: -125,
              minute_startY: 254,
              minute_array: ["min1_0.png","min1_1.png","min1_2.png","min1_3.png","min1_4.png","min1_5.png","min1_6.png","min1_7.png","min1_8.png","min1_9.png"],
              minute_zero: 1,
              minute_space: 400,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 190,
              y: 400,
              w: 100,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'WeatherScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 190,
              y: 400,
              w: 100,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'activityAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 190,
              y: 400,
              w: 100,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'heart_app_Screen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 190,
              y: 400,
              w: 100,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PowerSaveHintScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 140,
              y: 190,
              w: 100,
              h: 100,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'CountdownAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 300,
              y: 255,
              w: 60,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'StopWatchScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_7 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 300,
              y: 160,
              w: 60,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'FindPhoneScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_8 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 190,
              y: 90,
              w: 100,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_9 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 190,
              y: 30,
              w: 100,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'Settings_homeScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_10 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 420,
              y: 215,
              w: 50,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                click_CONTENT();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_11 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 10,
              y: 215,
              w: 50,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                click_COLOR();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            console.log('user_script_end.js');
            // start user_script_end.js
			let cc = 0
			if (cc ==0 ){
			  normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, false);
              normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			  Button_2.setProperty(hmUI.prop.VISIBLE, false);

              normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, false);
              normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			  Button_3.setProperty(hmUI.prop.VISIBLE, false);
			  
			  normal_battery_icon_img.setProperty(hmUI.prop.VISIBLE, false);
              normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			  Button_4.setProperty(hmUI.prop.VISIBLE, false);
			cc = 1;
			}
            // end user_script_end.js

            //start of ignored block
            function text_update() {
              console.log('text_update()');

              console.log('update text rotate hour_TIME');
              let valueHour = timeSensor.format_hour;
              let normal_hour_rotate_string = parseInt(valueHour).toString();
              normal_hour_rotate_string = normal_hour_rotate_string.padStart(2, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_hour_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueHour != null && valueHour != undefined && isFinite(valueHour) && normal_hour_rotate_string.length > 0 && normal_hour_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of normal_hour_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_hour_TextRotate[index].setProperty(hmUI.prop.POS_X, 92 + img_offset);
                      normal_hour_TextRotate[index].setProperty(hmUI.prop.SRC, normal_hour_TextRotate_ASCIIARRAY[charCode]);
                      normal_hour_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_hour_TextRotate_img_width + 300;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate minute_TIME');
              let valueMinute = timeSensor.minute;
              let normal_minute_rotate_string = parseInt(valueMinute).toString();
              normal_minute_rotate_string = normal_minute_rotate_string.padStart(2, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_minute_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueMinute != null && valueMinute != undefined && isFinite(valueMinute) && normal_minute_rotate_string.length > 0 && normal_minute_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of normal_minute_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_minute_TextRotate[index].setProperty(hmUI.prop.POS_X, 290 + img_offset);
                      normal_minute_TextRotate[index].setProperty(hmUI.prop.SRC, normal_minute_TextRotate_ASCIIARRAY[charCode]);
                      normal_minute_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_minute_TextRotate_img_width + 300;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate hour_TIME');
              let idle_hour_rotate_string = parseInt(valueHour).toString();
              idle_hour_rotate_string = idle_hour_rotate_string.padStart(2, '0');

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  idle_hour_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueHour != null && valueHour != undefined && isFinite(valueHour) && idle_hour_rotate_string.length > 0 && idle_hour_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of idle_hour_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_hour_TextRotate[index].setProperty(hmUI.prop.POS_X, 92 + img_offset);
                      idle_hour_TextRotate[index].setProperty(hmUI.prop.SRC, idle_hour_TextRotate_ASCIIARRAY[charCode]);
                      idle_hour_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_hour_TextRotate_img_width + 300;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate minute_TIME');
              let idle_minute_rotate_string = parseInt(valueMinute).toString();
              idle_minute_rotate_string = idle_minute_rotate_string.padStart(2, '0');

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  idle_minute_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueMinute != null && valueMinute != undefined && isFinite(valueMinute) && idle_minute_rotate_string.length > 0 && idle_minute_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of idle_minute_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_minute_TextRotate[index].setProperty(hmUI.prop.POS_X, 290 + img_offset);
                      idle_minute_TextRotate[index].setProperty(hmUI.prop.SRC, idle_minute_TextRotate_ASCIIARRAY[charCode]);
                      idle_minute_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_minute_TextRotate_img_width + 300;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

            };

            //end of ignored block
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                text_update();
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerTextUpdate) {
                    normal_timerTextUpdate = timer.createTimer(0, 1000, (function (option) {
                      text_update();
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.AOD) {
                  if (!idle_timerTextUpdate) {
                    idle_timerTextUpdate = timer.createTimer(0, 1000, (function (option) {
                      text_update();
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerTextUpdate) {
                  timer.stopTimer(normal_timerTextUpdate);
                  normal_timerTextUpdate = undefined;
                }
                if (idle_timerTextUpdate) {
                  timer.stopTimer(idle_timerTextUpdate);
                  idle_timerTextUpdate = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
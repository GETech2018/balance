﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

const {
       width: D_W,
       height: D_H
      } = hmSetting.getDeviceInfo();


      function read_pressure() {
       console.log("read_pressure()");
       const file_name_alt = "../../../baro_altim/pressure.dat";
       const [fs_stat, err] = hmFS.stat(file_name_alt);
       if (err == 0) {
        let file_size = fs_stat.size;
        const len = file_size / 4;
        console.log(`size_alt: ${file_size}, lenght: ${len}`)
        const fh = hmFS.open(file_name_alt, hmFS.O_RDONLY)

        let array_buffer = new Float32Array(len);
        hmFS.read(fh, array_buffer.buffer, 0, file_size);
        hmFS.close(fh);
        console.log(`value ${array_buffer[array_buffer.length -1]}`);
        return array_buffer;
       } else {
        console.log('err:', err)
       }
       return null;
      }

      function getPressureValue(pressure_array) {
       console.log("getPressureValue()");
       if (pressure_array == null || pressure_array == undefined || pressure_array.length == 0) return 0;
       let start_index = pressure_array.length - 1;
       let end_index = start_index - 30 * 3; // 3 часа
       if (end_index < 0) end_index = 0;
       for (let index = start_index; index >= end_index; index--) {
        if (pressure_array[index] != 0) return parseInt(pressure_array[index] / 100);
       }
       return 0;
      }

      function changesPressure(pressure_array) {
       console.log("changesPressure()");
       if (pressure_array == null || pressure_array == undefined || pressure_array.length == 0) return 0;
       let start_index = pressure_array.length - 1;
       let end_index = start_index - 30 * 3; // 3 часа
       let value = pressure_array[start_index];
       let result = 0;
       if (end_index < 0) end_index = 0;
       for (let index = start_index; index >= end_index; index--) {
        let element = pressure_array[index];
        if (element != 0) {
         if (Math.abs(value - element) > 10) { // учитываем только если разниза больше 0,1 hPa
          value = value - element;
          console.log(`element = ${element}`);
          console.log(`pressere_changes = ${value}`);
          return value;
         }
        }
       }
       return result;
      }

      function hPa_To_mmHg(hPa_value = 0) {
       let mmHg = Math.round(hPa_value * 0.750064);
       return mmHg;
      }
      //#endregion

      let text_pressere; // отображаем давление
      let text_pressere_changes; // отображаем изменение давления 


      function updatePressere() {
       let pressure_array = read_pressure();
       let value = getPressureValue(pressure_array);
       value = hPa_To_mmHg(value); // если нужно перевести в мм.рт.ст.


         normal_altimeter_current_text_font.setProperty(hmUI.prop.TEXT, String(value));
         idle_altimeter_current_text_font.setProperty(hmUI.prop.TEXT, String(value));

       
       
      }
      
let grafik = 0;
function clik_grafik() {
grafik = (grafik + 1)%2
normal_group_ForecastWeather.setProperty(hmUI.prop.VISIBLE, grafik==1);
Button_Switch_BG.setProperty(hmUI.prop.VISIBLE, grafik==0);
Button_2.setProperty(hmUI.prop.VISIBLE, grafik==0);
      }




        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_step_icon_img = ''
        let normal_step_current_text_font = ''
        let normal_sun_low_text_font = ''
        let normal_sun_high_text_font = ''
        let normal_heart_rate_text_font = ''
        let normal_digital_clock_img_time = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_high_text_font = ''
        let normal_temperature_low_text_font = ''
        let normal_temperature_current_text_font = ''
        let normal_battery_icon_img = ''
        let normal_battery_linear_scale = ''
        let normal_battery_current_text_font = ''
        let normal_moon_image_progress_img_level = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_group_ForecastWeather = ''
        let normal_forecast_background = ''
        let normal_forecast_date_week_font = new Array(8);
        let normal_forecast_date_week_font_Array = ['ПН', 'ВТ', 'СР', 'ЧТ', 'ПТ', 'СБ', 'ВС'];
        let normal_canvas1 = '';
        let normal_canvas2 = '';
        let normal_forecast_low_text_font = new Array(8);
        let normal_forecast_high_text_font = new Array(8);
        let normal_forecast_image_progress_img_level = new Array(8);
        let normal_forecast_image_array = ['wm_0.png', 'wm_1.png', 'wm_2.png', 'wm_3.png', 'wm_4.png', 'wm_5.png', 'wm_6.png', 'wm_7.png', 'wm_8.png', 'wm_9.png', 'wm_10.png', 'wm_11.png', 'wm_12.png', 'wm_13.png', 'wm_14.png', 'wm_15.png', 'wm_16.png', 'wm_17.png', 'wm_18.png', 'wm_19.png', 'wm_20.png', 'wm_21.png', 'wm_22.png', 'wm_23.png', 'wm_24.png', 'wm_25.png', 'wm_26.png', 'wm_27.png', 'wm_28.png'];
        let idle_background_bg_img = ''
        let idle_step_icon_img = ''
        let idle_step_current_text_font = ''
        let idle_sun_low_text_font = ''
        let idle_sun_high_text_font = ''
        let idle_heart_rate_text_font = ''
        let idle_digital_clock_img_time = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_day = ''
        let idle_weather_image_progress_img_level = ''
        let idle_temperature_high_text_font = ''
        let idle_temperature_low_text_font = ''
        let idle_temperature_current_text_font = ''
        let idle_altimeter_current_text_font = ''
        let idle_battery_icon_img = ''
        let idle_battery_linear_scale = ''
        let idle_battery_current_text_font = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let editGroup_1  = ''
        let fg_mask = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_Switch_BG = ''

        let backgroundIndex = 0;
        let backgroundList = ['bg_2.png', 'bg_1.png', 'bg_2.png', 'bg_3.png', 'bg_4.png', 'bg_5.png'];
        let backgroundToastList = ['Фон %s', 'Фон %s', 'Фон %s', 'Фон %s', 'Фон %s', 'Фон %s'];
        const watchfaceId = hmApp.packageInfo().watchfaceId;
        
        let degreeSum = 0;
        let crownSensitivity = 70;  // crown sensitivity level
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            // FontName: zero_gregular.ttf; FontSize: 27
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 782,
              h: 40,
              text_size: 27,
              char_space: 0,
              line_space: 0,
              font: 'fonts/zero_gregular.ttf',
              color: 0xFF000000,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: russo_one.ttf; FontSize: 22
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 312,
              h: 30,
              text_size: 22,
              char_space: 0,
              line_space: 0,
              font: 'fonts/russo_one.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: russo_one.ttf; FontSize: 25
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 358,
              h: 34,
              text_size: 25,
              char_space: 0,
              line_space: 0,
              font: 'fonts/russo_one.ttf',
              color: 0xFF000000,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: russo_one.ttf; FontSize: 26
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 384,
              h: 37,
              text_size: 26,
              char_space: 0,
              line_space: 0,
              font: 'fonts/russo_one.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            //start of ignored block
            console.log('onDigitalCrown()');
            function onDigitalCrown() {
              setTimeout(() => {
                hmApp.registerSpinEvent(function (key, degree) {
                  if (key === hmApp.key.HOME) {
                    degreeSum += degree;
                    if (Math.abs(degreeSum) > crownSensitivity){
                      let step = degreeSum < 0 ? -1 : 1;
                      degreeSum = 0;
                      
                      console.log('SwitchBackground use crown');
                      backgroundIndex += step;
                      backgroundIndex = backgroundIndex < 0 ? backgroundList.length + backgroundIndex : backgroundIndex % backgroundList.length;
                      hmFS.SysProSetInt(`backgroundIndex_${watchfaceId}`, backgroundIndex);
                      let toastText = backgroundToastList[backgroundIndex].replace('%s', `${backgroundIndex + 1}`);
                      if (toastText.length > 0) hmUI.showToast({text: toastText});
                      normal_background_bg_img.setProperty(hmUI.prop.SRC, backgroundList[backgroundIndex]);
                      vibro(28);
                    }
                  } // key
                }) // crown
              }, 250);
            }
            //end of ignored block

            //start of ignored block
            console.log('SwitchBackground');
            function switchBackground() {
              backgroundIndex++;
              if (backgroundIndex >= backgroundList.length) backgroundIndex = 0;
              hmFS.SysProSetInt(`backgroundIndex_${watchfaceId}`, backgroundIndex);
              let toastText = backgroundToastList[backgroundIndex].replace('%s', `${backgroundIndex + 1}`);
              if (toastText.length > 0) hmUI.showToast({text: toastText});
              normal_background_bg_img.setProperty(hmUI.prop.SRC, backgroundList[backgroundIndex]);
              vibro(28);
            };
            //end of ignored block

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg_2.png',
              show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'ic_step.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 0,
              y: 138,
              w: 480,
              h: 52,
              text_size: 27,
              char_space: 0,
              line_space: 0,
              font: 'fonts/zero_gregular.ttf',
              color: 0xFF000000,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 287,
              y: 365,
              w: 155,
              h: 31,
              text_size: 22,
              char_space: 0,
              line_space: 0,
              font: 'fonts/russo_one.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 177,
              y: 365,
              w: 155,
              h: 31,
              text_size: 22,
              char_space: 0,
              line_space: 0,
              font: 'fonts/russo_one.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 0,
              y: 92,
              w: 480,
              h: 52,
              text_size: 27,
              char_space: 0,
              line_space: 0,
              font: 'fonts/zero_gregular.ttf',
              color: 0xFF000000,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 21,
              hour_startY: 176,
              hour_array: ["H_0.png","H_1.png","H_2.png","H_3.png","H_4.png","H_5.png","H_6.png","H_7.png","H_8.png","H_9.png"],
              hour_zero: 1,
              hour_space: -16,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 249,
              minute_startY: 176,
              minute_array: ["H_0.png","H_1.png","H_2.png","H_3.png","H_4.png","H_5.png","H_6.png","H_7.png","H_8.png","H_9.png"],
              minute_zero: 1,
              minute_space: -16,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'str_sek.png',
              second_centerX: 423,
              second_centerY: 116,
              second_posX: 62,
              second_posY: 62,
              second_cover_path: 'cap_sek.png',
              second_cover_x: 370,
              second_cover_y: 64,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 49,
              y: 332,
              week_en: ["week_0.png","week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png"],
              week_tc: ["week_0.png","week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png"],
              week_sc: ["week_0.png","week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 216,
              month_startY: 280,
              month_sc_array: ["month_0.png","month_1.png","month_2.png","month_3.png","month_4.png","month_5.png","month_6.png","month_7.png","month_8.png","month_9.png","month_10.png","month_11.png"],
              month_tc_array: ["month_0.png","month_1.png","month_2.png","month_3.png","month_4.png","month_5.png","month_6.png","month_7.png","month_8.png","month_9.png","month_10.png","month_11.png"],
              month_en_array: ["month_0.png","month_1.png","month_2.png","month_3.png","month_4.png","month_5.png","month_6.png","month_7.png","month_8.png","month_9.png","month_10.png","month_11.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 103,
              day_startY: 281,
              day_sc_array: ["data_0.png","data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png"],
              day_tc_array: ["data_0.png","data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png"],
              day_en_array: ["data_0.png","data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 71,
              y: 87,
              image_array: ["w_0.png","w_1.png","w_2.png","w_3.png","w_4.png","w_5.png","w_6.png","w_7.png","w_8.png","w_9.png","w_10.png","w_11.png","w_12.png","w_13.png","w_14.png","w_15.png","w_16.png","w_17.png","w_18.png","w_19.png","w_20.png","w_21.png","w_22.png","w_23.png","w_24.png","w_25.png","w_26.png","w_27.png","w_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 294,
              y: 44,
              w: 155,
              h: 31,
              text_size: 22,
              char_space: 0,
              line_space: 0,
              font: 'fonts/russo_one.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 180,
              y: 44,
              w: 155,
              h: 31,
              text_size: 22,
              char_space: 0,
              line_space: 0,
              font: 'fonts/russo_one.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 22,
              y: 130,
              w: 155,
              h: 52,
              text_size: 25,
              char_space: 0,
              line_space: 0,
              font: 'fonts/russo_one.ttf',
              color: 0xFF000000,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('user_script.js');
            // start user_script.js

            normal_altimeter_current_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: -27*D_W/466,
              y: 8,
              w: D_W,
              h: 30,
              text_size: 21*D_W/466,
              char_space: 0,
              line_space: 0,
                padding: true,
              font: 'fonts/russo_one.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
             // type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            
            

            // end user_script.js

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 160,
              y: 404,
              src: 'ic_bat.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            if (screenType != hmSetting.screen_type.AOD) {
              normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);

            normal_battery_linear_scale.setAlpha(128);
            };

            // normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 160,
              // start_y: 403,
              // color: 0xFF000000,
              // lenght: 161,
              // line_width: 12,
              // line_cap: Flat,
              // vertical: False,
              // mirror: False,
              // inversion: True,
              // alpha: 128,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 235,
              y: 410,
              w: 155,
              h: 52,
              text_size: 26,
              char_space: 0,
              line_space: 0,
              font: 'fonts/russo_one.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 38,
              y: 282,
              image_array: ["moon_0.png","moon_1.png","moon_2.png","moon_3.png","moon_4.png","moon_5.png","moon_6.png"],
              image_length: 7,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 75,
              y: 368,
              src: 'stat_B_on.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 384,
              y: 370,
              src: 'stat_H_on.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            // normal_Weather_FewDays = hmUI.createWidget(hmUI.widget.FewDays, {
              // x: 0,
              // y: 0,
              // ColumnWidth: 47,
              // DaysCount: 8,
              // Background: 'bg_grafik.png',
            // });
            
            normal_group_ForecastWeather = hmUI.createWidget(hmUI.widget.GROUP, {
              x: 0,
              y: 0,
              h: 0,
              w: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            //start of ignored block
            if (screenType == hmSetting.screen_type.WATCHFACE) {
              normal_forecast_background = normal_group_ForecastWeather.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                src: 'bg_grafik.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
            };
            //end of ignored block
            // normal_forecast_date_week_font = normal_group_ForecastWeather.createWidget(hmUI.widget.TEXT_Options, {
              // x: -4,
              // y: 333,
              // w: 155,
              // h: 31,
              // text_size: 24,
              // char_space: 0,
              // line_space: 0,
              // alpha: 255,
              // color: 0xFFFFFFFF,
              // color_2: 0xFFFF0000,
              // use_color_2: True,
              // align_h: hmUI.align.CENTER_H,
              // align_v: hmUI.align.CENTER_V,
              // text_style: hmUI.text_style.ELLIPSIS,
              // type: hmUI.data_type.forecast_date_week_img,
              // unit_string: ПН, ВТ, СР, ЧТ, ПТ, СБ, ВС,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            //start of ignored block
            if (screenType == hmSetting.screen_type.WATCHFACE) {
              for (let i = 0; i < 8; i++) {
                normal_forecast_date_week_font[i] = normal_group_ForecastWeather.createWidget(hmUI.widget.TEXT, {
                  x: -4 + i*47,
                  y: 333,
                  w: 155,
                  h: 31,
                  text_size: 24,
                  char_space: 0,
                  line_space: 0,
                  color: 0xFFFFFFFF,
                  // color_2: 0xFFFF0000,
                  align_h: hmUI.align.CENTER_H,
                  align_v: hmUI.align.CENTER_V,
                  text_style: hmUI.text_style.ELLIPSIS,
                  // unit_string: ПН, ВТ, СР, ЧТ, ПТ, СБ, ВС,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
              };
            };
            //end of ignored block

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);            
            //start of ignored block
            function drawLine(canvas1, canvas2, x1, y1, x2, y2, color, line_width) {
              if (x1 > x2) {
                let temp_x = x1;
                let temp_y = y1;
                x1 = x2;
                y1 = y2;
                x2 = temp_x;
                y2 = temp_y;
              };
              canvas2.setPaint({ color: color, line_width: line_width });
              canvas2.drawLine({ x1: x1, y1: y1, x2: x2, y2: y2 });
            };
            
            function drawRect(canvas1, canvas2, x1, y1, x2, y2, color) {
              if (x1 > x2) {
                let temp_x = x1;
                let temp_y = y1;
                x1 = x2;
                y1 = y2;
                x2 = temp_x;
                y2 = temp_y;
              };
              
              canvas2.drawRect({ x1: x1, y1: y1, x2: x2, y2: y2, color: color });
            };
            
            function drawCircle(canvas1, canvas2, center_x, center_y, color, radius) {
              canvas2.drawCircle({ center_x: center_x, center_y: center_y, radius: radius, color: color });
            };
            
            function drawGraphPoint(canvas1, canvas2, x, y, color, pointSize, pointType) {
              switch (pointType) {
                case 1:
                  x -= pointSize/2;
                  y -= pointSize/2;
                  drawRect(canvas1, canvas2, x, y, x+pointSize, y+pointSize, color);
                  break;
                case 2:
                  let posX = x - pointSize/2;
                  let posY = y - pointSize/2;
                  drawRect(canvas1, canvas2, posX, posY, posX+pointSize, posY+pointSize, color );
                  posX = x - pointSize/4;
                  posY = y - pointSize/4;
                  drawRect(canvas1, canvas2, posX, posY, posX+pointSize/2, posY+pointSize/2, 0xffffff );
                  break;
                case 3:
                  drawCircle(canvas1, canvas2, x, y, color, pointSize/2 );
                  break;
                case 4:
                  drawCircle(canvas1, canvas2, x, y, color, pointSize/2 );
                  drawCircle(canvas1, canvas2, x, y, 0xffffff, pointSize/4 );
                  break;
              }
            };

            //end of ignored block
            

            //start of ignored block
            function graphScale(heightGraph, maxPointSize, minPointSize, forecastData, daysCount) {
              console.log(`function graphScale`);
              heightGraph -= (maxPointSize + minPointSize) / 2;
              let high = -300;
              let low = 300;
              for (let index = 0; index < daysCount; index++) {
                if (index < forecastData.length) {
                  let item = forecastData[index];
                  if (item.high > high) high = item.high;;
                  if (item.low < low) low = item.low; ;
                } // end if
              } // end for
              let delta = high - low;
              let scale = heightGraph / delta;
              console.log(`heightGraph: ${heightGraph}; high: ${high}; low : ${low}`);
              return {graphScale: scale, maximal_temp: high};
            };

            //end of ignored block

            //start of ignored block
            if (screenType == hmSetting.screen_type.WATCHFACE) {
              normal_canvas1 = normal_group_ForecastWeather.createWidget(hmUI.widget.CANVAS, {
                x: 0,
                y: 0,
                w: 0,
                h: 0,
              });

              normal_canvas2 = normal_group_ForecastWeather.createWidget(hmUI.widget.CANVAS, {
                x: -5,
                y: 162,
                w: 480,
                h: 480,
              });
            };
            //end of ignored block

            // normal_forecast_low_text_font = normal_group_ForecastWeather.createWidget(hmUI.widget.TEXT_Options, {
              // x: -79,
              // y: 2,
              // w: 155,
              // h: 31,
              // text_size: 28,
              // char_space: 0,
              // line_space: 0,
              // alpha: 255,
              // color: 0xFFFFFFFF,
              // color_2: 0xFFFF0000,
              // use_color_2: False,
              // align_h: hmUI.align.CENTER_H,
              // align_v: hmUI.align.CENTER_V,
              // text_style: hmUI.text_style.ELLIPSIS,
              // type: hmUI.data_type.forecast_low_text_font,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            //start of ignored block
            if (screenType == hmSetting.screen_type.WATCHFACE) {
              for (let i = 0; i < 8; i++) {
                normal_forecast_low_text_font[i] = normal_group_ForecastWeather.createWidget(hmUI.widget.TEXT, {
                  x: -4 + i*47,
                  y: 2,
                  w: 155,
                  h: 31,
                  text_size: 28,
                  char_space: 0,
                  line_space: 0,
                  color: 0xFFFFFFFF,
                  align_h: hmUI.align.CENTER_H,
                  align_v: hmUI.align.CENTER_V,
                  text_style: hmUI.text_style.ELLIPSIS,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
              };
            };
            //end of ignored block

            // normal_forecast_high_text_font = normal_group_ForecastWeather.createWidget(hmUI.widget.TEXT_Options, {
              // x: -79,
              // y: -38,
              // w: 155,
              // h: 31,
              // text_size: 28,
              // char_space: 0,
              // line_space: 0,
              // alpha: 255,
              // color: 0xFFFFFFFF,
              // color_2: 0xFFFF0000,
              // use_color_2: False,
              // align_h: hmUI.align.CENTER_H,
              // align_v: hmUI.align.CENTER_V,
              // text_style: hmUI.text_style.ELLIPSIS,
              // type: hmUI.data_type.forecast_high_text_font,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            //start of ignored block
            if (screenType == hmSetting.screen_type.WATCHFACE) {
              for (let i = 0; i < 8; i++) {
                normal_forecast_high_text_font[i] = normal_group_ForecastWeather.createWidget(hmUI.widget.TEXT, {
                  x: -4 + i*47,
                  y: -38,
                  w: 155,
                  h: 31,
                  text_size: 28,
                  char_space: 0,
                  line_space: 0,
                  color: 0xFFFFFFFF,
                  align_h: hmUI.align.CENTER_H,
                  align_v: hmUI.align.CENTER_V,
                  text_style: hmUI.text_style.ELLIPSIS,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
              };
            };
            //end of ignored block

            // normal_forecast_image_progress_img_level = normal_group_ForecastWeather.createWidget(hmUI.widget.IMG_LEVEL_Options, {
              // x: 52,
              // y: 93,
              // image_array: ["wm_0.png","wm_1.png","wm_2.png","wm_3.png","wm_4.png","wm_5.png","wm_6.png","wm_7.png","wm_8.png","wm_9.png","wm_10.png","wm_11.png","wm_12.png","wm_13.png","wm_14.png","wm_15.png","wm_16.png","wm_17.png","wm_18.png","wm_19.png","wm_20.png","wm_21.png","wm_22.png","wm_23.png","wm_24.png","wm_25.png","wm_26.png","wm_27.png","wm_28.png"],
              // image_length: 29,
              // type: hmUI.data_type.forecast_image,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            //start of ignored block
            if (screenType == hmSetting.screen_type.WATCHFACE) {
              for (let i = 0; i < 8; i++) {
                normal_forecast_image_progress_img_level[i] = normal_group_ForecastWeather.createWidget(hmUI.widget.IMG, {
                  x: 52 + i*47,
                  y: 93,
                  src: normal_forecast_image_array[25],
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
              };
            };
            //end of ignored block


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg_6.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'Aic_step.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 0,
              y: 138,
              w: 480,
              h: 52,
              text_size: 27,
              char_space: 0,
              line_space: 0,
              font: 'fonts/zero_gregular.ttf',
              color: 0xFF8D8E90,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_sun_low_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 287,
              y: 365,
              w: 155,
              h: 31,
              text_size: 22,
              char_space: 0,
              line_space: 0,
              font: 'fonts/russo_one.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_sun_high_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 177,
              y: 365,
              w: 155,
              h: 31,
              text_size: 22,
              char_space: 0,
              line_space: 0,
              font: 'fonts/russo_one.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 0,
              y: 92,
              w: 480,
              h: 52,
              text_size: 27,
              char_space: 0,
              line_space: 0,
              font: 'fonts/zero_gregular.ttf',
              color: 0xFF8D8E90,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 21,
              hour_startY: 176,
              hour_array: ["AH_0.png","AH_1.png","AH_2.png","AH_3.png","AH_4.png","AH_5.png","AH_6.png","AH_7.png","AH_8.png","AH_9.png"],
              hour_zero: 1,
              hour_space: -16,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 249,
              minute_startY: 176,
              minute_array: ["AH_0.png","AH_1.png","AH_2.png","AH_3.png","AH_4.png","AH_5.png","AH_6.png","AH_7.png","AH_8.png","AH_9.png"],
              minute_zero: 1,
              minute_space: -16,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 49,
              y: 332,
              week_en: ["Aweek_0.png","Aweek_1.png","Aweek_2.png","Aweek_3.png","Aweek_4.png","Aweek_5.png","Aweek_6.png"],
              week_tc: ["Aweek_0.png","Aweek_1.png","Aweek_2.png","Aweek_3.png","Aweek_4.png","Aweek_5.png","Aweek_6.png"],
              week_sc: ["Aweek_0.png","Aweek_1.png","Aweek_2.png","Aweek_3.png","Aweek_4.png","Aweek_5.png","Aweek_6.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 216,
              month_startY: 280,
              month_sc_array: ["Amonth_0.png","Amonth_1.png","Amonth_2.png","Amonth_3.png","Amonth_4.png","Amonth_5.png","Amonth_6.png","Amonth_7.png","Amonth_8.png","Amonth_9.png","Amonth_10.png","Amonth_11.png"],
              month_tc_array: ["Amonth_0.png","Amonth_1.png","Amonth_2.png","Amonth_3.png","Amonth_4.png","Amonth_5.png","Amonth_6.png","Amonth_7.png","Amonth_8.png","Amonth_9.png","Amonth_10.png","Amonth_11.png"],
              month_en_array: ["Amonth_0.png","Amonth_1.png","Amonth_2.png","Amonth_3.png","Amonth_4.png","Amonth_5.png","Amonth_6.png","Amonth_7.png","Amonth_8.png","Amonth_9.png","Amonth_10.png","Amonth_11.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 103,
              day_startY: 281,
              day_sc_array: ["Adata_0.png","Adata_1.png","Adata_2.png","Adata_3.png","Adata_4.png","Adata_5.png","Adata_6.png","Adata_7.png","Adata_8.png","Adata_9.png"],
              day_tc_array: ["Adata_0.png","Adata_1.png","Adata_2.png","Adata_3.png","Adata_4.png","Adata_5.png","Adata_6.png","Adata_7.png","Adata_8.png","Adata_9.png"],
              day_en_array: ["Adata_0.png","Adata_1.png","Adata_2.png","Adata_3.png","Adata_4.png","Adata_5.png","Adata_6.png","Adata_7.png","Adata_8.png","Adata_9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 71,
              y: 87,
              image_array: ["Aw_0.png","Aw_1.png","Aw_2.png","Aw_3.png","Aw_4.png","Aw_5.png","Aw_6.png","Aw_7.png","Aw_8.png","Aw_9.png","Aw_10.png","Aw_11.png","Aw_12.png","Aw_13.png","Aw_14.png","Aw_15.png","Aw_16.png","Aw_17.png","Aw_18.png","Aw_19.png","Aw_20.png","Aw_21.png","Aw_22.png","Aw_23.png","Aw_24.png","Aw_25.png","Aw_26.png","Aw_27.png","Aw_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_high_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 294,
              y: 44,
              w: 155,
              h: 31,
              text_size: 22,
              char_space: 0,
              line_space: 0,
              font: 'fonts/russo_one.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_low_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 180,
              y: 44,
              w: 155,
              h: 31,
              text_size: 22,
              char_space: 0,
              line_space: 0,
              font: 'fonts/russo_one.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 22,
              y: 130,
              w: 155,
              h: 52,
              text_size: 25,
              char_space: 0,
              line_space: 0,
              font: 'fonts/russo_one.ttf',
              color: 0xFF8D8E90,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_altimeter_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: -28,
              y: 8,
              w: 480,
              h: 31,
              text_size: 22,
              char_space: 0,
              line_space: 0,
              font: 'fonts/russo_one.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 160,
              y: 404,
              src: 'ic_bat.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            if (screenType == hmSetting.screen_type.AOD) {
              idle_battery_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);

            idle_battery_linear_scale.setAlpha(128);
            };

            // idle_battery_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 160,
              // start_y: 403,
              // color: 0xFF000000,
              // lenght: 161,
              // line_width: 12,
              // line_cap: Flat,
              // vertical: False,
              // mirror: False,
              // inversion: True,
              // alpha: 128,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 235,
              y: 410,
              w: 155,
              h: 52,
              text_size: 26,
              char_space: 0,
              line_space: 0,
              font: 'fonts/russo_one.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 75,
              y: 368,
              src: 'Astat_B_on.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 384,
              y: 370,
              src: 'Astat_H_on.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Editable_Elements');

            editGroup_1 = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
              edit_id: 10021,
              x: 409,
              y: 276,
              w: 45,
              h: 45,
              select_image: 'edit_red.png',
              un_select_image: 'edit_green.png',
              default_type: hmUI.edit_type.APPLIST,
              optional_types: [
                { type: hmUI.edit_type.APPLIST, preview: 'ez(2)_APPLIST.png' },
              ],
              count: 1,
              select_list: {
                title_font_size: 34,
                title_align_h: hmUI.align.CENTER_H,
                list_item_vspace: 8,
                list_tips_text_font_size: 32,
                list_tips_text_align_h: hmUI.align.LEFT
              },
              tips_BG: 'tips_bg.png',
              tips_x: -174,
              tips_y: 49,
              tips_width: 201,
              tips_margin: 0,
            });

            const editType_1 = editGroup_1.getProperty(hmUI.prop.CURRENT_TYPE);

            fg_mask = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_FG_MASK, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'edit_mask.png',
              show_level: hmUI.show_level.ONLY_EDIT,
            });

            console.log('user_script_beforeShortcuts.js');
            // start user_script_beforeShortcuts.js



        normal_group_ForecastWeather.setProperty(hmUI.prop.VISIBLE, false);

            // end user_script_beforeShortcuts.js

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 188,
              y: 188,
              w: 103,
              h: 103,
              text: '',
              color: 0xFFFF8C00,
              text_size: 26,
              press_src: 'pusto.png',
              normal_src: 'pusto.png',
              click_func: (button_widget) => {
                vibro(28);
clik_grafik();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 3,
              y: 131,
              w: 82,
              h: 82,
              text: '',
              color: 0xFFFF8C00,
              text_size: 26,
              press_src: 'pusto.png',
              normal_src: 'pusto.png',
              click_func: (button_widget) => {
                vibro(28);
hmApp.startApp({url: 'AlarmInfoScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            console.log('Watch_Face.SwitchBackground');
            // Button_Switch_BG = hmUI.createWidget(hmUI.widget.SwitchBackground, {
              // x: 188,
              // y: 377,
              // w: 103,
              // h: 103,
              // text: '',
              // color: 0xFFFF8C00,
              // text_size: 26,
              // press_src: 'pusto.png',
              // normal_src: 'pusto.png',
              // bg_list: bg_2|bg_1|bg_2|bg_3|bg_4|bg_5,
              // toast_list: Фон %s|Фон %s|Фон %s|Фон %s|Фон %s|Фон %s,
              // use_crown: True,
              // use_in_AOD: False,
              // vibro: True,
            // });

            Button_Switch_BG = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 188,
              y: 377,
              w: 103,
              h: 103,
              text: '',
              color: 0xFFFF8C00,
              text_size: 26,
              press_src: 'pusto.png',
              normal_src: 'pusto.png',
              click_func: (button_widget) => {
                switchBackground();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            // vibrate function
            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;

            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function

            console.log('user_script_end.js');
            // start user_script_end.js

             idle_altimeter_current_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: -27*D_W/466,
              y: 8,
              w: D_W,
              h: 30,
              text_size: 21*D_W/466,
              char_space: 0,
              line_space: 0,
                padding: true,
              font: 'fonts/russo_one.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
             // type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            // end user_script_end.js

            const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);
            //start of ignored block
            function weather_few_days() {
              console.log('weather_few_days()');
              let weatherData = weatherSensor.getForecastWeather();
              let forecastData = weatherData.forecastData;
              let result = {graphScale: 1, maximal_temp: 0};
              let maxOldX = 0;
              let averageOldX = 0;
              let minOldX = 0;

              if (screenType == hmSetting.screen_type.WATCHFACE) result = graphScale(151, 10, 10, forecastData.data, 8);
              let forecastGraphScale = result.graphScale;
              let maximal_temp = result.maximal_temp;
              console.log(`forecastGraphScale = ${forecastGraphScale}, maximal_temp = ${maximal_temp}`);

              if (screenType == hmSetting.screen_type.WATCHFACE) {
                normal_canvas1.clear({x: 0, y:0, w: 0, h: 0});
                normal_canvas2.clear({x: 0, y:0, w: 480, h: 480});
              };
              let normal_max_offsetX = 80;
              if (screenType == hmSetting.screen_type.WATCHFACE)  maxOldX = normal_max_offsetX;
              let maxOldY = (maximal_temp - forecastData.data[0].high) * forecastGraphScale + 5;
              let endPointMax = false;
              let normal_average_offsetX = 78;
              if (screenType == hmSetting.screen_type.WATCHFACE) averageOldX = normal_average_offsetX;
              let averageOldY = (maximal_temp - (forecastData.data[0].high + forecastData.data[0].low) / 2) * forecastGraphScale + 5;
              let endPointAverage = false;
              let normal_min_offsetX = 80;
              if (screenType == hmSetting.screen_type.WATCHFACE) minOldX = normal_min_offsetX;
              let minOldY = (maximal_temp - forecastData.data[0].low) * forecastGraphScale + 5;
              let endPointMin = false;
              for (let i = 0; i < 8; i++) {
                // DayOfWeek font
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  let dowIndex = timeSensor.week - 1;
                  dowIndex += i;
                  while (dowIndex >= 7) {dowIndex -= 7;}
                  normal_forecast_date_week_font[i].setProperty(hmUI.prop.TEXT, normal_forecast_date_week_font_Array[dowIndex]);
                  if (dowIndex >= 5) normal_forecast_date_week_font[i].setProperty(hmUI.prop.COLOR, 0xFFFF0000);
                  else normal_forecast_date_week_font[i].setProperty(hmUI.prop.COLOR, 0xFFFFFFFF);
                };
              
                // Graph
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (i < forecastData.count) {
                    let maxStartX = maxOldX;
                    let maxStartY = maxOldY;
                    maxOldX = normal_max_offsetX + i * 47;
                    maxOldY = (maximal_temp - forecastData.data[i].high) * forecastGraphScale + 5;
                    let maxEndX = maxOldX;
                    let maxEndY = maxOldY;
                    if (maxStartX != maxEndX) {
                      drawLine(normal_canvas1, normal_canvas2, maxStartX, maxStartY, maxEndX, maxEndY, 0xFFFF0000, 4)
                      drawGraphPoint(normal_canvas1, normal_canvas2, maxStartX, maxStartY, 0xFFFF0000, 10, 3)
                      endPointMax = true;
                    };
                  
                    let averageStartX = averageOldX;
                    let averageStartY = averageOldY;
                    averageOldX = normal_average_offsetX + i * 47;
                    averageOldY = (maximal_temp - (forecastData.data[i].high + forecastData.data[i].low) / 2) * forecastGraphScale + 5;
                    let averageEndX = averageOldX;
                    let averageEndY = averageOldY;
                    if (averageStartX != averageEndX) {
                      drawLine(normal_canvas1, normal_canvas2, averageStartX, averageStartY, averageEndX, averageEndY, 0xFFC0C0C0, 4)
                      drawGraphPoint(normal_canvas1, normal_canvas2, averageStartX, averageStartY, 0xFFC0C0C0, 12, 0)
                      endPointAverage = true;
                    };
                  
                    let minStartX = minOldX;
                    let minStartY = minOldY;
                    minOldX = normal_min_offsetX + i * 47;
                    minOldY = (maximal_temp - forecastData.data[i].low) * forecastGraphScale + 5;
                    let minEndX = minOldX;
                    let minEndY = minOldY;
                    if (minStartX != minEndX) {
                      drawLine(normal_canvas1, normal_canvas2, minStartX, minStartY, minEndX, minEndY, 0xFF00FFFF, 4)
                      drawGraphPoint(normal_canvas1, normal_canvas2, minStartX, minStartY, 0xFF00FFFF, 10, 3)
                      endPointMin = true;
                    };
                  
                  };
                };  // end screen_type
                
                // Number_Font_Min
                let minTemperature = '-';
                if (i < forecastData.count) minTemperature = forecastData.data[i].low.toString();
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  let normal_forecast_low_text_font_posY = (maximal_temp - forecastData.data[i].low) * forecastGraphScale + 169;
                  normal_forecast_low_text_font[i].setProperty(hmUI.prop.Y, normal_forecast_low_text_font_posY);
                  normal_forecast_low_text_font[i].setProperty(hmUI.prop.TEXT, minTemperature);
                };
                
                // Number_Font_Max
                let maxTemperature = '-';
                if (i < forecastData.count) maxTemperature = forecastData.data[i].high.toString();
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  let normal_forecast_high_text_font_posY = (maximal_temp - forecastData.data[i].high) * forecastGraphScale + 129;
                  normal_forecast_high_text_font[i].setProperty(hmUI.prop.Y, normal_forecast_high_text_font_posY);
                  normal_forecast_high_text_font[i].setProperty(hmUI.prop.TEXT, maxTemperature);
                };
                
                // Images
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  let weatherIndex = 25
                  if (i < forecastData.count) weatherIndex = forecastData.data[i].index;
                  normal_forecast_image_progress_img_level[i].setProperty(hmUI.prop.SRC, normal_forecast_image_array[weatherIndex]);
                };
              
              };  // end for

              if (screenType == hmSetting.screen_type.WATCHFACE && endPointMax) {
                drawGraphPoint(normal_canvas1, normal_canvas2, maxOldX, maxOldY, 0xFFFF0000, 10, 3)
              };
              if (screenType == hmSetting.screen_type.WATCHFACE && endPointAverage) {
                drawGraphPoint(normal_canvas1, normal_canvas2, averageOldX, averageOldY, 0xFFC0C0C0, 12, 0)
              };
              if (screenType == hmSetting.screen_type.WATCHFACE && endPointMin) {
                drawGraphPoint(normal_canvas1, normal_canvas2, minOldX, minOldY, 0xFF00FFFF, 10, 3)
              };
            };
            //end of ignored block

            function scale_call() {
              console.log('scale_call()');

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_ls_normal_battery = 1 - progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_linear_scale
                  // initial parameters
                  let start_x_normal_battery = 321;
                  let start_y_normal_battery = 403;
                  let lenght_ls_normal_battery = -161;
                  let line_width_ls_normal_battery = 12;
                  let color_ls_normal_battery = 0xFF000000;
                  
                  // calculated parameters
                  let start_x_normal_battery_draw = start_x_normal_battery;
                  let start_y_normal_battery_draw = start_y_normal_battery;
                  lenght_ls_normal_battery = lenght_ls_normal_battery * progress_ls_normal_battery;
                  let lenght_ls_normal_battery_draw = lenght_ls_normal_battery;
                  let line_width_ls_normal_battery_draw = line_width_ls_normal_battery;
                  if (lenght_ls_normal_battery < 0){
                    lenght_ls_normal_battery_draw = -lenght_ls_normal_battery;
                    start_x_normal_battery_draw = start_x_normal_battery - lenght_ls_normal_battery_draw;
                  };
                  
                  normal_battery_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_battery_draw,
                    y: start_y_normal_battery_draw,
                    w: lenght_ls_normal_battery_draw,
                    h: line_width_ls_normal_battery_draw,
                    color: color_ls_normal_battery,
                  });
                };

                console.log('update scales BATTERY');
                let progress_ls_idle_battery = 1 - progressBattery;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_battery_linear_scale
                  // initial parameters
                  let start_x_idle_battery = 321;
                  let start_y_idle_battery = 403;
                  let lenght_ls_idle_battery = -161;
                  let line_width_ls_idle_battery = 12;
                  let color_ls_idle_battery = 0xFF000000;
                  
                  // calculated parameters
                  let start_x_idle_battery_draw = start_x_idle_battery;
                  let start_y_idle_battery_draw = start_y_idle_battery;
                  lenght_ls_idle_battery = lenght_ls_idle_battery * progress_ls_idle_battery;
                  let lenght_ls_idle_battery_draw = lenght_ls_idle_battery;
                  let line_width_ls_idle_battery_draw = line_width_ls_idle_battery;
                  if (lenght_ls_idle_battery < 0){
                    lenght_ls_idle_battery_draw = -lenght_ls_idle_battery;
                    start_x_idle_battery_draw = start_x_idle_battery - lenght_ls_idle_battery_draw;
                  };
                  
                  idle_battery_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_idle_battery_draw,
                    y: start_y_idle_battery_draw,
                    w: lenght_ls_idle_battery_draw,
                    h: line_width_ls_idle_battery_draw,
                    color: color_ls_idle_battery,
                  });
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();

                //SwitchBackground
                if (hmFS.SysProGetInt(`backgroundIndex_${watchfaceId}`) === undefined) {
                  backgroundIndex = 0;
                  hmFS.SysProSetInt(`backgroundIndex_${watchfaceId}`, backgroundIndex);
                } else {
                  backgroundIndex = hmFS.SysProGetInt(`backgroundIndex_${watchfaceId}`);
                };
                if (screenType == hmSetting.screen_type.WATCHFACE && normal_background_bg_img) normal_background_bg_img.setProperty(hmUI.prop.SRC, backgroundList[backgroundIndex]);
                onDigitalCrown();
                console.log('resume_call.js');
                // start resume_call.js


          updatePressere()

                // end resume_call.js

                weather_few_days();
              }),
              pause_call: (function () {
                console.log('pause_call()');

                hmApp.unregisterSpinEvent();
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_step_image_progress_img_level = ''
        let normal_step_TextCircle = new Array(5);
        let normal_step_TextCircle_ASCIIARRAY = new Array(10);
        let normal_step_TextCircle_img_width = 15;
        let normal_step_TextCircle_img_height = 27;
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_fat_burning_image_progress_img_level = ''
        let normal_fat_burning_TextCircle = new Array(3);
        let normal_fat_burning_TextCircle_ASCIIARRAY = new Array(10);
        let normal_fat_burning_TextCircle_img_width = 15;
        let normal_fat_burning_TextCircle_img_height = 27;
        let normal_stand_image_progress_img_level = ''
        let normal_stand_target_TextCircle = new Array(2);
        let normal_stand_target_TextCircle_ASCIIARRAY = new Array(10);
        let normal_stand_target_TextCircle_img_width = 15;
        let normal_stand_target_TextCircle_img_height = 27;
        let normal_stand_TextCircle = new Array(2);
        let normal_stand_TextCircle_ASCIIARRAY = new Array(10);
        let normal_stand_TextCircle_img_width = 15;
        let normal_stand_TextCircle_img_height = 27;
        let normal_stand_TextCircle_unit = null;
        let normal_stand_TextCircle_unit_width = 15;
        let normal_digital_clock_img_time = ''
        let idle_background_bg = ''
        let idle_digital_clock_img_time = ''
        let normal_step_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_battery_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 61,
              y: 164,
              font_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 38,
              y: 132,
              image_array: ["batt_1.png","batt_2.png","batt_3.png","batt_4.png","batt_5.png","batt_6.png","batt_7.png","batt_8.png"],
              image_length: 8,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 40,
              y: 129,
              image_array: ["step_1.png","step_2.png","step_3.png","step_4.png","step_5.png","step_6.png","step_7.png","step_8.png","step_9.png","step_10.png","step_11.png","step_12.png","step_13.png","step_14.png","step_15.png","step_16.png"],
              image_length: 16,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_step_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 240,
              // circle_center_Y: 240,
              // font_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
              // radius: 233,
              // angle: -141,
              // char_space_angle: 0,
              // zero: false,
              // reverse_direction: true,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_step_TextCircle_ASCIIARRAY[0] = 'font_0.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[1] = 'font_1.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[2] = 'font_2.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[3] = 'font_3.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[4] = 'font_4.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[5] = 'font_5.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[6] = 'font_6.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[7] = 'font_7.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[8] = 'font_8.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[9] = 'font_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              normal_step_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 240,
                center_y: 240,
                pos_x: 240 - normal_step_TextCircle_img_width / 2,
                pos_y: 240 + 206,
                src: 'font_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_step_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });
            
            function toDegree (radian) {
              return radian * (180 / Math.PI);
            };

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 52,
              y: 280,
              font_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 52,
              y: 236,
              image_array: ["P_1.png","P_2.png","P_3.png","P_4.png","P_5.png","P_6.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_fat_burning_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 75,
              y: 147,
              image_array: ["fat_1.png","fat_2.png","fat_3.png","fat_4.png","fat_5.png","fat_6.png","fat_7.png","fat_8.png","fat_9.png","fat_10.png","fat_11.png","fat_12.png","fat_13.png","fat_14.png"],
              image_length: 14,
              type: hmUI.data_type.FAT_BURNING,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_fat_burning_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 240,
              // circle_center_Y: 240,
              // font_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
              // radius: 193,
              // angle: 219,
              // char_space_angle: 0,
              // zero: false,
              // reverse_direction: true,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.FAT_BURNING,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_fat_burning_TextCircle_ASCIIARRAY[0] = 'font_0.png';  // set of images with numbers
            normal_fat_burning_TextCircle_ASCIIARRAY[1] = 'font_1.png';  // set of images with numbers
            normal_fat_burning_TextCircle_ASCIIARRAY[2] = 'font_2.png';  // set of images with numbers
            normal_fat_burning_TextCircle_ASCIIARRAY[3] = 'font_3.png';  // set of images with numbers
            normal_fat_burning_TextCircle_ASCIIARRAY[4] = 'font_4.png';  // set of images with numbers
            normal_fat_burning_TextCircle_ASCIIARRAY[5] = 'font_5.png';  // set of images with numbers
            normal_fat_burning_TextCircle_ASCIIARRAY[6] = 'font_6.png';  // set of images with numbers
            normal_fat_burning_TextCircle_ASCIIARRAY[7] = 'font_7.png';  // set of images with numbers
            normal_fat_burning_TextCircle_ASCIIARRAY[8] = 'font_8.png';  // set of images with numbers
            normal_fat_burning_TextCircle_ASCIIARRAY[9] = 'font_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 3; i++) {
              normal_fat_burning_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 240,
                center_y: 240,
                pos_x: 240 - normal_fat_burning_TextCircle_img_width / 2,
                pos_y: 240 + 166,
                src: 'font_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_fat_burning_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            
            const fat_burning = hmSensor.createSensor(hmSensor.id.FAT_BURRING);
            fat_burning.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            normal_stand_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 111,
              y: 166,
              image_array: ["stand_1.png","stand_2.png","stand_3.png","stand_4.png","stand_5.png","stand_6.png","stand_7.png","stand_8.png","stand_9.png","stand_10.png","stand_11.png","stand_12.png"],
              image_length: 12,
              type: hmUI.data_type.STAND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_stand_target_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 240,
              // circle_center_Y: 240,
              // font_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
              // radius: 153,
              // angle: -150,
              // char_space_angle: 0,
              // zero: false,
              // reverse_direction: true,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.STAND_TARGET,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_stand_target_TextCircle_ASCIIARRAY[0] = 'font_0.png';  // set of images with numbers
            normal_stand_target_TextCircle_ASCIIARRAY[1] = 'font_1.png';  // set of images with numbers
            normal_stand_target_TextCircle_ASCIIARRAY[2] = 'font_2.png';  // set of images with numbers
            normal_stand_target_TextCircle_ASCIIARRAY[3] = 'font_3.png';  // set of images with numbers
            normal_stand_target_TextCircle_ASCIIARRAY[4] = 'font_4.png';  // set of images with numbers
            normal_stand_target_TextCircle_ASCIIARRAY[5] = 'font_5.png';  // set of images with numbers
            normal_stand_target_TextCircle_ASCIIARRAY[6] = 'font_6.png';  // set of images with numbers
            normal_stand_target_TextCircle_ASCIIARRAY[7] = 'font_7.png';  // set of images with numbers
            normal_stand_target_TextCircle_ASCIIARRAY[8] = 'font_8.png';  // set of images with numbers
            normal_stand_target_TextCircle_ASCIIARRAY[9] = 'font_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              normal_stand_target_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 240,
                center_y: 240,
                pos_x: 240 - normal_stand_target_TextCircle_img_width / 2,
                pos_y: 240 + 126,
                src: 'font_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_stand_target_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            
            const stand = hmSensor.createSensor(hmSensor.id.STAND);
            stand.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            // normal_stand_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 240,
              // circle_center_Y: 240,
              // font_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
              // radius: 153,
              // angle: -142,
              // char_space_angle: 0,
              // unit: 'dot_1.png',
              // zero: true,
              // reverse_direction: true,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: RIGHT,
              // type: hmUI.data_type.STAND,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_stand_TextCircle_ASCIIARRAY[0] = 'font_0.png';  // set of images with numbers
            normal_stand_TextCircle_ASCIIARRAY[1] = 'font_1.png';  // set of images with numbers
            normal_stand_TextCircle_ASCIIARRAY[2] = 'font_2.png';  // set of images with numbers
            normal_stand_TextCircle_ASCIIARRAY[3] = 'font_3.png';  // set of images with numbers
            normal_stand_TextCircle_ASCIIARRAY[4] = 'font_4.png';  // set of images with numbers
            normal_stand_TextCircle_ASCIIARRAY[5] = 'font_5.png';  // set of images with numbers
            normal_stand_TextCircle_ASCIIARRAY[6] = 'font_6.png';  // set of images with numbers
            normal_stand_TextCircle_ASCIIARRAY[7] = 'font_7.png';  // set of images with numbers
            normal_stand_TextCircle_ASCIIARRAY[8] = 'font_8.png';  // set of images with numbers
            normal_stand_TextCircle_ASCIIARRAY[9] = 'font_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              normal_stand_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 240,
                center_y: 240,
                pos_x: 240 - normal_stand_TextCircle_img_width / 2,
                pos_y: 240 + 126,
                src: 'font_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_stand_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_stand_TextCircle_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              center_x: 240,
              center_y: 240,
              pos_x: 240 - normal_stand_TextCircle_unit_width / 2,
              pos_y: 240 + 126,
              src: 'dot_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_stand_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 145,
              hour_startY: 109,
              hour_array: ["A100_010.png","A100_012.png","A100_013.png","A100_014.png","A100_015.png","A100_016.png","A100_017.png","A100_018.png","A100_019.png","A100_020.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 145,
              minute_startY: 220,
              minute_array: ["A100_010.png","A100_012.png","A100_013.png","A100_014.png","A100_015.png","A100_016.png","A100_017.png","A100_018.png","A100_019.png","A100_020.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 221,
              second_startY: 50,
              second_array: ["A100_058.png","A100_059.png","A100_061.png","A100_062.png","A100_063.png","A100_064.png","A100_065.png","A100_066.png","A100_067.png","A100_068.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 145,
              hour_startY: 130,
              hour_array: ["A100_010.png","A100_012.png","A100_013.png","A100_014.png","A100_015.png","A100_016.png","A100_017.png","A100_018.png","A100_019.png","A100_020.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 145,
              minute_startY: 254,
              minute_array: ["A100_010.png","A100_012.png","A100_013.png","A100_014.png","A100_015.png","A100_016.png","A100_017.png","A100_018.png","A100_019.png","A100_020.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 78,
              y: 355,
              w: 80,
              h: 80,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 35,
              y: 239,
              w: 75,
              h: 75,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 50,
              y: 145,
              w: 65,
              h: 65,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 200,
              y: 240,
              w: 80,
              h: 70,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 200,
              y: 135,
              w: 80,
              h: 70,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            //start of ignored block
            function text_update() {
              console.log('text_update()');

              console.log('update text circle step_STEP');
              let valueStep = step.current;
              let normal_step_circle_string = parseInt(valueStep).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  normal_step_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = 39;
                if (valueStep != null && valueStep != undefined && isFinite(valueStep) && normal_step_circle_string.length > 0 && normal_step_circle_string.length <= 5) {  // display data if it was possible to get it
                  let normal_step_TextCircle_img_angle = 0;
                  let normal_step_TextCircle_dot_img_angle = 0;
                  normal_step_TextCircle_img_angle = toDegree(Math.atan2(normal_step_TextCircle_img_width/2, 233));
                  // alignment = CENTER_H
                  let normal_step_TextCircle_angleOffset = normal_step_TextCircle_img_angle * (normal_step_circle_string.length - 1);
                  normal_step_TextCircle_angleOffset = -normal_step_TextCircle_angleOffset;
                  char_Angle -= normal_step_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_step_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= normal_step_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_step_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_step_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - normal_step_TextCircle_img_width / 2);
                      normal_step_TextCircle[index].setProperty(hmUI.prop.SRC, normal_step_TextCircle_ASCIIARRAY[charCode]);
                      normal_step_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= normal_step_TextCircle_img_angle;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text circle fat_burning_FAT_BURRING');
              let valueFatBurning = fat_burning.current;
              let normal_fat_burning_circle_string = parseInt(valueFatBurning).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  normal_fat_burning_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = 399;
                if (valueFatBurning != null && valueFatBurning != undefined && isFinite(valueFatBurning) && normal_fat_burning_circle_string.length > 0 && normal_fat_burning_circle_string.length <= 3) {  // display data if it was possible to get it
                  let normal_fat_burning_TextCircle_img_angle = 0;
                  let normal_fat_burning_TextCircle_dot_img_angle = 0;
                  normal_fat_burning_TextCircle_img_angle = toDegree(Math.atan2(normal_fat_burning_TextCircle_img_width/2, 193));
                  // alignment = CENTER_H
                  let normal_fat_burning_TextCircle_angleOffset = normal_fat_burning_TextCircle_img_angle * (normal_fat_burning_circle_string.length - 1);
                  normal_fat_burning_TextCircle_angleOffset = -normal_fat_burning_TextCircle_angleOffset;
                  char_Angle -= normal_fat_burning_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_fat_burning_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= normal_fat_burning_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_fat_burning_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_fat_burning_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - normal_fat_burning_TextCircle_img_width / 2);
                      normal_fat_burning_TextCircle[index].setProperty(hmUI.prop.SRC, normal_fat_burning_TextCircle_ASCIIARRAY[charCode]);
                      normal_fat_burning_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= normal_fat_burning_TextCircle_img_angle;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text circle stand_target_STAND');
              let targetStand = stand.target;
              let normal_stand_target_circle_string = parseInt(targetStand).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_stand_target_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = 30;
                if (targetStand != null && targetStand != undefined && isFinite(targetStand) && normal_stand_target_circle_string.length > 0 && normal_stand_target_circle_string.length <= 2) {  // display data if it was possible to get it
                  let normal_stand_target_TextCircle_img_angle = 0;
                  let normal_stand_target_TextCircle_dot_img_angle = 0;
                  normal_stand_target_TextCircle_img_angle = toDegree(Math.atan2(normal_stand_target_TextCircle_img_width/2, 153));
                  // alignment = CENTER_H
                  let normal_stand_target_TextCircle_angleOffset = normal_stand_target_TextCircle_img_angle * (normal_stand_target_circle_string.length - 1);
                  normal_stand_target_TextCircle_angleOffset = -normal_stand_target_TextCircle_angleOffset;
                  char_Angle -= normal_stand_target_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_stand_target_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= normal_stand_target_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_stand_target_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_stand_target_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - normal_stand_target_TextCircle_img_width / 2);
                      normal_stand_target_TextCircle[index].setProperty(hmUI.prop.SRC, normal_stand_target_TextCircle_ASCIIARRAY[charCode]);
                      normal_stand_target_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= normal_stand_target_TextCircle_img_angle;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text circle stand_STAND');
              let valueStand = stand.current;
              let normal_stand_circle_string = parseInt(valueStand).toString();
              normal_stand_circle_string = normal_stand_circle_string.padStart(2, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_stand_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_stand_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
                let char_Angle = 38;
                if (valueStand != null && valueStand != undefined && isFinite(valueStand) && normal_stand_circle_string.length > 0 && normal_stand_circle_string.length <= 2) {  // display data if it was possible to get it
                  let normal_stand_TextCircle_img_angle = 0;
                  let normal_stand_TextCircle_dot_img_angle = 0;
                  let normal_stand_TextCircle_unit_angle = 0;
                  normal_stand_TextCircle_img_angle = toDegree(Math.atan2(normal_stand_TextCircle_img_width/2, 153));
                  normal_stand_TextCircle_unit_angle = toDegree(Math.atan2(normal_stand_TextCircle_unit_width/2, 153));
                  // alignment = RIGHT
                  let normal_stand_TextCircle_angleOffset = normal_stand_TextCircle_img_angle * (normal_stand_circle_string.length - 1);
                  normal_stand_TextCircle_angleOffset = normal_stand_TextCircle_angleOffset + (normal_stand_TextCircle_img_angle + normal_stand_TextCircle_unit_angle + 0) / 2;
                  normal_stand_TextCircle_angleOffset = -normal_stand_TextCircle_angleOffset;
                  char_Angle -= 2 * normal_stand_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_stand_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= normal_stand_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_stand_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_stand_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - normal_stand_TextCircle_img_width / 2);
                      normal_stand_TextCircle[index].setProperty(hmUI.prop.SRC, normal_stand_TextCircle_ASCIIARRAY[charCode]);
                      normal_stand_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= normal_stand_TextCircle_img_angle;
                      index++;
                    };  // end if digit
                  };  // end char of string
                  char_Angle -= normal_stand_TextCircle_unit_angle;
                  normal_stand_TextCircle_unit.setProperty(hmUI.prop.ANGLE, char_Angle);
                  normal_stand_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite

              };

            };

            //end of ignored block
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                text_update();
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let editBg = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_battery_text_text_img = ''
        let normal_battery_pointer_progress_img_pointer = ''
        let normal_heart_rate_text_text_img = ''
        let normal_step_pointer_progress_img_pointer = ''
        let normal_step_current_text_img = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_temperature_current_text_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_day = ''
        let idle_battery_text_text_img = ''
        let idle_battery_pointer_progress_img_pointer = ''
        let idle_heart_rate_text_text_img = ''
        let idle_step_pointer_progress_img_pointer = ''
        let idle_step_current_text_img = ''
        let idle_digital_clock_img_time = ''
        let editableTimePointers = ''
        let normal_step_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_battery_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            editBg = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_BG, {
              edit_id: 1002,
              x: 0,
              y: 0,
              // w: 480,
              // h: 480,
              // AOD_show: False,
              bg_config: [
                { id: 1, preview: 'bg_edit_1_preview.png', path: 'bg_Tit.png' },
                { id: 2, preview: 'bg_edit_2_preview.png', path: 'bg_Tit2.png' },
                { id: 3, preview: 'bg_edit_3_preview.png', path: 'bg_Tit3.png' },
                { id: 4, preview: 'bg_edit_4_preview.png', path: 'bg_Tit4.png' },
                { id: 5, preview: 'bg_edit_5_preview.png', path: 'bg_Tit5.png' },
                { id: 6, preview: 'bg_edit_6_preview.png', path: 'bg_Tit6.png' },
                { id: 7, preview: 'bg_edit_7_preview.png', path: 'bg_Tit7.png' },
                { id: 8, preview: 'bg_edit_8_preview.png', path: 'bg_Tit8.png' },
                { id: 9, preview: 'bg_edit_9_preview.png', path: 'bg_Tit9.png' },
              ],
              count: 9,
              default_id: 1,
              fg: '.png',
              tips_bg: '.png',
              tips_x: 0,
              tips_y: 0,
              show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 262,
              y: 118,
              src: 'bluetooth.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 315,
              y: 86,
              src: 'alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 185,
              y: 107,
              image_array: ["0142.png","0143.png","0144.png","0145.png","0146.png","0147.png","0148.png","0149.png","0150.png","0151.png","0152.png","0153.png","0154.png","0155.png","0156.png","0157.png","0158.png","0159.png","0160.png","0161.png","0162.png","0163.png","0164.png","0165.png","0166.png","0167.png","0168.png","0169.png","0170.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 131,
              y: 118,
              font_array: ["30.png","31.png","32.png","33.png","34.png","35.png","36.png","37.png","38.png","39.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'deg.png',
              unit_tc: 'deg.png',
              unit_en: 'deg.png',
              negative_image: 'neg.png',
              invalid_image: 'nodata.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 274,
              y: 153,
              week_en: ["w1.png","w2.png","w3.png","w4.png","w5.png","w6.png","w7.png"],
              week_tc: ["w1.png","w2.png","w3.png","w4.png","w5.png","w6.png","w7.png"],
              week_sc: ["w1.png","w2.png","w3.png","w4.png","w5.png","w6.png","w7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 321,
              day_startY: 118,
              day_sc_array: ["30.png","31.png","32.png","33.png","34.png","35.png","36.png","37.png","38.png","39.png"],
              day_tc_array: ["30.png","31.png","32.png","33.png","34.png","35.png","36.png","37.png","38.png","39.png"],
              day_en_array: ["30.png","31.png","32.png","33.png","34.png","35.png","36.png","37.png","38.png","39.png"],
              day_zero: 0,
              day_space: 3,
              day_align: hmUI.align.RIGHT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 95,
              y: 267,
              font_array: ["0.png","1.png","2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'lancetta_rossa.png',
              center_x: 115,
              center_y: 240,
              x: 18,
              y: 65,
              start_angle: 0,
              end_angle: 360,
              invalid_visible: false,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 108,
              y: 355,
              font_array: ["30.png","31.png","32.png","33.png","34.png","35.png","36.png","37.png","38.png","39.png"],
              padding: false,
              h_space: 0,
              angle: 1,
              invalid_image: 'nodata.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'lancetta_grigia.png',
              center_x: 241,
              center_y: 367,
              x: 18,
              y: 65,
              start_angle: 0,
              end_angle: 360,
              invalid_visible: false,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 326,
              y: 355,
              font_array: ["30.png","31.png","32.png","33.png","34.png","35.png","36.png","37.png","38.png","39.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 180,
              hour_startY: 58,
              hour_array: ["60.png","61.png","62.png","63.png","64.png","65.png","66.png","67.png","68.png","69.png"],
              hour_zero: 1,
              hour_space: 3,
              hour_angle: 0,
              hour_unit_sc: '70.png',
              hour_unit_tc: '70.png',
              hour_unit_en: '70.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 0,
              minute_startY: 0,
              minute_array: ["60.png","61.png","62.png","63.png","64.png","65.png","66.png","67.png","68.png","69.png"],
              minute_zero: 1,
              minute_space: 3,
              minute_angle: 0,
              minute_follow: 1,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'AOD.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 262,
              y: 118,
              src: 'bluetooth.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 315,
              y: 86,
              src: 'alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 185,
              y: 107,
              image_array: ["0142.png","0143.png","0144.png","0145.png","0146.png","0147.png","0148.png","0149.png","0150.png","0151.png","0152.png","0153.png","0154.png","0155.png","0156.png","0157.png","0158.png","0159.png","0160.png","0161.png","0162.png","0163.png","0164.png","0165.png","0166.png","0167.png","0168.png","0169.png","0170.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 131,
              y: 118,
              font_array: ["30.png","31.png","32.png","33.png","34.png","35.png","36.png","37.png","38.png","39.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'deg.png',
              unit_tc: 'deg.png',
              unit_en: 'deg.png',
              negative_image: 'neg.png',
              invalid_image: 'nodata.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 274,
              y: 153,
              week_en: ["w1.png","w2.png","w3.png","w4.png","w5.png","w6.png","w7.png"],
              week_tc: ["w1.png","w2.png","w3.png","w4.png","w5.png","w6.png","w7.png"],
              week_sc: ["w1.png","w2.png","w3.png","w4.png","w5.png","w6.png","w7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 321,
              day_startY: 118,
              day_sc_array: ["30.png","31.png","32.png","33.png","34.png","35.png","36.png","37.png","38.png","39.png"],
              day_tc_array: ["30.png","31.png","32.png","33.png","34.png","35.png","36.png","37.png","38.png","39.png"],
              day_en_array: ["30.png","31.png","32.png","33.png","34.png","35.png","36.png","37.png","38.png","39.png"],
              day_zero: 0,
              day_space: 3,
              day_align: hmUI.align.RIGHT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 95,
              y: 267,
              font_array: ["0.png","1.png","2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'lancetta_rossa.png',
              center_x: 115,
              center_y: 240,
              x: 18,
              y: 65,
              start_angle: 0,
              end_angle: 360,
              invalid_visible: false,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 108,
              y: 355,
              font_array: ["30.png","31.png","32.png","33.png","34.png","35.png","36.png","37.png","38.png","39.png"],
              padding: false,
              h_space: 0,
              angle: 1,
              invalid_image: 'nodata.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'lancetta_grigia.png',
              center_x: 241,
              center_y: 367,
              x: 18,
              y: 65,
              start_angle: 0,
              end_angle: 360,
              invalid_visible: false,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 326,
              y: 355,
              font_array: ["30.png","31.png","32.png","33.png","34.png","35.png","36.png","37.png","38.png","39.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 180,
              hour_startY: 58,
              hour_array: ["60.png","61.png","62.png","63.png","64.png","65.png","66.png","67.png","68.png","69.png"],
              hour_zero: 1,
              hour_space: 3,
              hour_angle: 0,
              hour_unit_sc: '70.png',
              hour_unit_tc: '70.png',
              hour_unit_en: '70.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 0,
              minute_startY: 0,
              minute_array: ["60.png","61.png","62.png","63.png","64.png","65.png","66.png","67.png","68.png","69.png"],
              minute_zero: 1,
              minute_space: 3,
              minute_angle: 0,
              minute_follow: 1,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.ElementEditablePointers');

            const pointerEdit = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_POINTER, {
              edit_id: 1003,
              x: 0,
              y: 0,
              config: [
                {
                  id: 1,
                  second: {
                    centerX: 240,
                    centerY: 240,
                    posX: 240,
                    posY: 240,
                    path: 'secondi_red.png',
                  },
                  hour: {
                    centerX: 240,
                    centerY: 240,
                    posX: 240,
                    posY: 240,
                    path: 'hands_h_1.png',
                  },
                  minute: {
                    centerX: 240,
                    centerY: 240,
                    posX: 240,
                    posY: 240,
                    path: 'hands_m_1.png',
                  },
                  preview: 'pointer_edit_1_preview.png',
                },
                {
                  id: 2,
                  second: {
                    centerX: 240,
                    centerY: 240,
                    posX: 240,
                    posY: 240,
                    path: 'secondi_red.png',
                  },
                  hour: {
                    centerX: 240,
                    centerY: 240,
                    posX: 240,
                    posY: 240,
                    path: 'hands_h_2.png',
                  },
                  minute: {
                    centerX: 240,
                    centerY: 240,
                    posX: 240,
                    posY: 240,
                    path: 'hands_m_2.png',
                  },
                  preview: 'pointer_edit_2_preview.png',
                },
                {
                  id: 3,
                  second: {
                    centerX: 240,
                    centerY: 240,
                    posX: 26,
                    posY: 221,
                    path: 'h3.png',
                  },
                  hour: {
                    centerX: 240,
                    centerY: 240,
                    posX: 32,
                    posY: 178,
                    path: 'h1.png',
                  },
                  minute: {
                    centerX: 240,
                    centerY: 240,
                    posX: 30,
                    posY: 209,
                    path: 'h2.png',
                  },
                  preview: 'pointer_edit_3_preview.png',
                },
                {
                  id: 4,
                  second: {
                    centerX: 240,
                    centerY: 240,
                    posX: 240,
                    posY: 240,
                    path: 'e_0137.png',
                  },
                  hour: {
                    centerX: 240,
                    centerY: 240,
                    posX: 240,
                    posY: 240,
                    path: 'e_0135.png',
                  },
                  minute: {
                    centerX: 240,
                    centerY: 240,
                    posX: 240,
                    posY: 240,
                    path: 'e_0136.png',
                  },
                  preview: 'pointer_edit_4_preview.png',
                },
                {
                  id: 5,
                  second: {
                    centerX: 240,
                    centerY: 240,
                    posX: 240,
                    posY: 240,
                    path: 'e_0137.png',
                  },
                  hour: {
                    centerX: 240,
                    centerY: 240,
                    posX: 240,
                    posY: 240,
                    path: 'e_hours.png',
                  },
                  minute: {
                    centerX: 240,
                    centerY: 240,
                    posX: 240,
                    posY: 240,
                    path: 'e_minutes.png',
                  },
                  preview: 'pointer_edit_5_preview.png',
                },
                {
                  id: 6,
                  second: {
                    centerX: 240,
                    centerY: 240,
                    posX: 240,
                    posY: 240,
                    path: 'GWS.png',
                  },
                  hour: {
                    centerX: 240,
                    centerY: 240,
                    posX: 240,
                    posY: 240,
                    path: 'GWH.png',
                  },
                  minute: {
                    centerX: 240,
                    centerY: 240,
                    posX: 240,
                    posY: 240,
                    path: 'GWM.png',
                  },
                  preview: 'pointer_edit_6_preview.png',
                },
                {
                  id: 7,
                  second: {
                    centerX: 240,
                    centerY: 240,
                    posX: 240,
                    posY: 240,
                    path: 'secondi_red.png',
                  },
                  hour: {
                    centerX: 240,
                    centerY: 240,
                    posX: 29,
                    posY: 178,
                    path: 'time_hour.png',
                  },
                  minute: {
                    centerX: 240,
                    centerY: 240,
                    posX: 39,
                    posY: 239,
                    path: 'time_min.png',
                  },
                  preview: 'pointer_edit_7_preview.png',
                },
                {
                  id: 8,
                  second: {
                    centerX: 240,
                    centerY: 240,
                    posX: 13,
                    posY: 223,
                    path: 'DBS.png',
                  },
                  hour: {
                    centerX: 240,
                    centerY: 240,
                    posX: 32,
                    posY: 151,
                    path: 'DBH.png',
                  },
                  minute: {
                    centerX: 240,
                    centerY: 240,
                    posX: 21,
                    posY: 211,
                    path: 'DBM.png',
                  },
                  preview: 'pointer_edit_8_preview.png',
                },
              ],
              count: 8,
              default_id: 1,
              fg: 'empty.png',
              tips_x: 0,
              tips_y: -5,
              tips_bg: '.png',
            });
            const pointerProp = pointerEdit.getProperty(hmUI.prop.CURRENT_CONFIG, true);
            editableTimePointers = hmUI.createWidget(hmUI.widget.TIME_POINTER, pointerProp);
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 182,
              y: 314,
              w: 220,
              h: 100,
              src: 'empty.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 70,
              y: 343,
              w: 100,
              h: 50,
              src: 'empty.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 40,
              y: 165,
              w: 150,
              h: 150,
              src: 'empty.png',
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 117,
              y: 110,
              w: 50,
              h: 50,
              src: 'empty.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 312,
              y: 84,
              w: 60,
              h: 60,
              src: 'empty.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
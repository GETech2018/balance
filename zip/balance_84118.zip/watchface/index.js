﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_humidity_icon_img = ''
        let normal_humidity_text_text_img = ''
        let normal_distance_icon_img = ''
        let normal_distance_text_text_img = ''
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_sun_icon_img = ''
        let normal_sun_high_text_img = ''
        let normal_sun_low_text_img = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_month_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_date_img_date_week_img = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_date_img_date_week_img = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: '0001.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 329,
              y: 76,
              src: 'Z18_P.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 361,
              y: 91,
              font_array: ["blc_00.png","blc_01.png","blc_02.png","blc_03.png","blc_04.png","blc_05.png","blc_06.png","blc_07.png","blc_08.png","blc_09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'blc_10.png',
              unit_tc: 'blc_10.png',
              unit_en: 'blc_10.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 23,
              y: 264,
              src: 'Z17_P.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 61,
              y: 274,
              font_array: ["blc_00.png","blc_01.png","blc_02.png","blc_03.png","blc_04.png","blc_05.png","blc_06.png","blc_07.png","blc_08.png","blc_09.png"],
              padding: false,
              h_space: -1,
              dot_image: 'blc_13.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 31,
              y: 308,
              src: 'Z16_P.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 65,
              y: 309,
              font_array: ["blc_00.png","blc_01.png","blc_02.png","blc_03.png","blc_04.png","blc_05.png","blc_06.png","blc_07.png","blc_08.png","blc_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 61,
              y: 74,
              src: 'Z15_P.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 115,
              y: 73,
              font_array: ["blc_00.png","blc_01.png","blc_02.png","blc_03.png","blc_04.png","blc_05.png","blc_06.png","blc_07.png","blc_08.png","blc_09.png"],
              padding: false,
              h_space: 0,
              dot_image: 'blc_13.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 114,
              y: 98,
              font_array: ["blc_00.png","blc_01.png","blc_02.png","blc_03.png","blc_04.png","blc_05.png","blc_06.png","blc_07.png","blc_08.png","blc_09.png"],
              padding: false,
              h_space: 0,
              dot_image: 'blc_13.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 389,
              month_startY: 282,
              month_sc_array: ["pulse_00011.png","pulse_00022.png","pulse_00033.png","pulse_00044.png","pulse_00055.png","pulse_00066.png","pulse_00077.png","pulse_00088.png","pulse_00099.png","pulse_001010.png"],
              month_tc_array: ["pulse_00011.png","pulse_00022.png","pulse_00033.png","pulse_00044.png","pulse_00055.png","pulse_00066.png","pulse_00077.png","pulse_00088.png","pulse_00099.png","pulse_001010.png"],
              month_en_array: ["pulse_00011.png","pulse_00022.png","pulse_00033.png","pulse_00044.png","pulse_00055.png","pulse_00066.png","pulse_00077.png","pulse_00088.png","pulse_00099.png","pulse_001010.png"],
              month_zero: 0,
              month_space: -5,
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 393,
              month_startY: 253,
              month_sc_array: ["m0046.png","m0047.png","m0048.png","m0049.png","m0050.png","m0051.png","m0052.png","m0053.png","m0054.png","m0055.png","m0056.png","m0057.png"],
              month_tc_array: ["m0046.png","m0047.png","m0048.png","m0049.png","m0050.png","m0051.png","m0052.png","m0053.png","m0054.png","m0055.png","m0056.png","m0057.png"],
              month_en_array: ["m0046.png","m0047.png","m0048.png","m0049.png","m0050.png","m0051.png","m0052.png","m0053.png","m0054.png","m0055.png","m0056.png","m0057.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 284,
              y: 343,
              src: 'BT_OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 170,
              y: 348,
              src: 'ALARM.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 199,
              y: 11,
              image_array: ["wather001.png","wather002.png","wather003.png","wather004.png","wather005.png","wather006.png","wather007.png","wather008.png","wather009.png","wather010.png","wather011.png","wather012.png","wather013.png","wather014.png","wather015.png","wather016.png","wather017.png","wather018.png","wather019.png","wather020.png","wather021.png","wather022.png","wather023.png","wather024.png","wather025.png","wather026.png","wather027.png","wather028.png","wather029.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 266,
              y: 49,
              font_array: ["blc_00.png","blc_01.png","blc_02.png","blc_03.png","blc_04.png","blc_05.png","blc_06.png","blc_07.png","blc_08.png","blc_09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'blc_12.png',
              unit_tc: 'blc_12.png',
              unit_en: 'blc_12.png',
              negative_image: 'blc_11.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 108,
              y: 236,
              font_array: ["blc_00.png","blc_01.png","blc_02.png","blc_03.png","blc_04.png","blc_05.png","blc_06.png","blc_07.png","blc_08.png","blc_09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'blc_10.png',
              unit_tc: 'blc_10.png',
              unit_en: 'blc_10.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 17,
              y: 228,
              image_array: ["ENE01_resultat.png","ENE02_resultat.png","ENE03_resultat.png","ENE04_resultat.png","ENE05_resultat.png","ENE06_resultat.png","ENE07_resultat.png","ENE08_resultat.png","ENE09_resultat.png","ENE10_resultat.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 131,
              y: 387,
              week_en: ["S01.png","S02.png","S03.png","S04.png","S05.png","S06.png","S07.png"],
              week_tc: ["S01.png","S02.png","S03.png","S04.png","S05.png","S06.png","S07.png"],
              week_sc: ["S01.png","S02.png","S03.png","S04.png","S05.png","S06.png","S07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 44,
              hour_startY: 120,
              hour_array: ["Z00_P.png","Z01_P.png","Z02_P.png","Z03_P.png","Z04_P.png","Z05_P.png","Z06_P.png","Z07_P.png","Z08_P.png","Z09_P.png"],
              hour_zero: 1,
              hour_space: -34,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 248,
              minute_startY: 120,
              minute_array: ["Z00_P.png","Z01_P.png","Z02_P.png","Z03_P.png","Z04_P.png","Z05_P.png","Z06_P.png","Z07_P.png","Z08_P.png","Z09_P.png"],
              minute_zero: 1,
              minute_space: -34,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 424,
              second_startY: 183,
              second_array: ["blc_00.png","blc_01.png","blc_02.png","blc_03.png","blc_04.png","blc_05.png","blc_06.png","blc_07.png","blc_08.png","blc_09.png"],
              second_zero: 1,
              second_space: -2,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 201,
              y: 117,
              src: 'Z14_P.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 374,
              y: 241,
              src: 'BT_OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 90,
              y: 247,
              src: 'ALARM.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 133,
              y: 226,
              week_en: ["S01.png","S02.png","S03.png","S04.png","S05.png","S06.png","S07.png"],
              week_tc: ["S01.png","S02.png","S03.png","S04.png","S05.png","S06.png","S07.png"],
              week_sc: ["S01.png","S02.png","S03.png","S04.png","S05.png","S06.png","S07.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 44,
              hour_startY: 120,
              hour_array: ["Z00_P.png","Z01_P.png","Z02_P.png","Z03_P.png","Z04_P.png","Z05_P.png","Z06_P.png","Z07_P.png","Z08_P.png","Z09_P.png"],
              hour_zero: 1,
              hour_space: -34,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 248,
              minute_startY: 120,
              minute_array: ["Z00_P.png","Z01_P.png","Z02_P.png","Z03_P.png","Z04_P.png","Z05_P.png","Z06_P.png","Z07_P.png","Z08_P.png","Z09_P.png"],
              minute_zero: 1,
              minute_space: -34,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 424,
              second_startY: 183,
              second_array: ["blc_00.png","blc_01.png","blc_02.png","blc_03.png","blc_04.png","blc_05.png","blc_06.png","blc_07.png","blc_08.png","blc_09.png"],
              second_zero: 1,
              second_space: -2,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 201,
              y: 117,
              src: 'Z14_P.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
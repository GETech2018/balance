﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_battery_current_text_font = ''
        let normal_sun_high_text_font = ''
        let normal_sun_low_text_font = ''
        let normal_alarm_clock_current_text_font = ''
        let normal_distance_icon_img = ''
        let normal_distance_text_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_pai_icon_img = ''
        let normal_image_img = ''
        let normal_digital_clock_img_time_minute = ''
        let normal_digital_clock_img_time_hour = ''
        let idle_system_clock_img = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_week_img = ''
        let idle_pai_icon_img = ''
        let idle_image_img = ''
        let idle_digital_clock_img_time_minute = ''
        let idle_digital_clock_img_time_hour = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let Button_7 = ''
        let Button_8 = ''
        let Button_9 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: '1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 168,
              y: 419,
              w: 150,
              h: 50,
              text_size: 36,
              char_space: 2,
              color: 0xFF00FF00,
              line_space: 0,
              align_v: hmUI.align.BOTTOM,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              padding: true,
              unit_type: 1,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 254,
              y: 341,
              w: 150,
              h: 40,
              text_size: 28,
              char_space: 0,
              color: 0xFF8CC6FF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 254,
              y: 374,
              w: 150,
              h: 40,
              text_size: 28,
              char_space: 0,
              color: 0xFFFFFF00,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_clock_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 253,
              y: 306,
              w: 150,
              h: 40,
              text_size: 28,
              char_space: 0,
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              padding: true,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'com.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 98,
              y: 351,
              font_array: ["A_digit_01.png","A_digit_02.png","A_digit_03.png","A_digit_04.png","A_digit_05.png","A_digit_06.png","A_digit_07.png","A_digit_08.png","A_digit_09.png","A_digit_10.png"],
              padding: false,
              h_space: -3,
              dot_image: 'A_special_01.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 138,
              y: 317,
              font_array: ["A_digit_01.png","A_digit_02.png","A_digit_03.png","A_digit_04.png","A_digit_05.png","A_digit_06.png","A_digit_07.png","A_digit_08.png","A_digit_09.png","A_digit_10.png"],
              padding: true,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 101,
              y: 282,
              font_array: ["A_digit_01.png","A_digit_02.png","A_digit_03.png","A_digit_04.png","A_digit_05.png","A_digit_06.png","A_digit_07.png","A_digit_08.png","A_digit_09.png","A_digit_10.png"],
              padding: true,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 53,
              y: 237,
              image_array: ["W_weather_01.png","W_weather_02.png","W_weather_03.png","W_weather_04.png","W_weather_05.png","W_weather_06.png","W_weather_07.png","W_weather_08.png","W_weather_09.png","W_weather_10.png","W_weather_11.png","W_weather_12.png","W_weather_13.png","W_weather_14.png","W_weather_15.png","W_weather_16.png","W_weather_17.png","W_weather_18.png","W_weather_19.png","W_weather_20.png","W_weather_21.png","W_weather_22.png","W_weather_23.png","W_weather_24.png","W_weather_25.png","W_weather_26.png","W_weather_27.png","W_weather_28.png","W_weather_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 335,
              y: 224,
              font_array: ["B_digit_01.png","B_digit_02.png","B_digit_03.png","B_digit_04.png","B_digit_05.png","B_digit_06.png","B_digit_07.png","B_digit_08.png","B_digit_09.png","B_digit_10.png"],
              padding: false,
              h_space: -38,
              unit_sc: 'B_special_13.png',
              unit_tc: 'B_special_13.png',
              unit_en: 'B_special_13.png',
              negative_image: 'B_special_11.png',
              invalid_image: 'A_special_03.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 196,
              day_startY: -28,
              day_sc_array: ["B_digit_01.png","B_digit_02.png","B_digit_03.png","B_digit_04.png","B_digit_05.png","B_digit_06.png","B_digit_07.png","B_digit_08.png","B_digit_09.png","B_digit_10.png"],
              day_tc_array: ["B_digit_01.png","B_digit_02.png","B_digit_03.png","B_digit_04.png","B_digit_05.png","B_digit_06.png","B_digit_07.png","B_digit_08.png","B_digit_09.png","B_digit_10.png"],
              day_en_array: ["B_digit_01.png","B_digit_02.png","B_digit_03.png","B_digit_04.png","B_digit_05.png","B_digit_06.png","B_digit_07.png","B_digit_08.png","B_digit_09.png","B_digit_10.png"],
              day_zero: 1,
              day_space: -37,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 136,
              y: -3,
              week_en: ["D_day_01.png","D_day_02.png","D_day_03.png","D_day_04.png","D_day_05.png","D_day_06.png","D_day_07.png"],
              week_tc: ["D_day_01.png","D_day_02.png","D_day_03.png","D_day_04.png","D_day_05.png","D_day_06.png","D_day_07.png"],
              week_sc: ["D_day_01.png","D_day_02.png","D_day_03.png","D_day_04.png","D_day_05.png","D_day_06.png","D_day_07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 72,
              y: -2,
              src: '922.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 214,
              src: '922.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 187,
              minute_startY: 65,
              minute_array: ["M_digit_01.png","M_digit_02.png","M_digit_03.png","M_digit_04.png","M_digit_05.png","M_digit_06.png","M_digit_07.png","M_digit_08.png","M_digit_09.png","M_digit_10.png"],
              minute_zero: 1,
              minute_space: -11,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 17,
              hour_startY: 65,
              hour_array: ["H_digit_01.png","H_digit_02.png","H_digit_03.png","H_digit_04.png","H_digit_05.png","H_digit_06.png","H_digit_07.png","H_digit_08.png","H_digit_09.png","H_digit_10.png"],
              hour_zero: 1,
              hour_space: -11,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 220,
              y: 24,
              src: 'alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 193,
              day_startY: 50,
              day_sc_array: ["B_digit_01.png","B_digit_02.png","B_digit_03.png","B_digit_04.png","B_digit_05.png","B_digit_06.png","B_digit_07.png","B_digit_08.png","B_digit_09.png","B_digit_10.png"],
              day_tc_array: ["B_digit_01.png","B_digit_02.png","B_digit_03.png","B_digit_04.png","B_digit_05.png","B_digit_06.png","B_digit_07.png","B_digit_08.png","B_digit_09.png","B_digit_10.png"],
              day_en_array: ["B_digit_01.png","B_digit_02.png","B_digit_03.png","B_digit_04.png","B_digit_05.png","B_digit_06.png","B_digit_07.png","B_digit_08.png","B_digit_09.png","B_digit_10.png"],
              day_zero: 1,
              day_space: -37,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 142,
              y: 80,
              week_en: ["D_day_01.png","D_day_02.png","D_day_03.png","D_day_04.png","D_day_05.png","D_day_06.png","D_day_07.png"],
              week_tc: ["D_day_01.png","D_day_02.png","D_day_03.png","D_day_04.png","D_day_05.png","D_day_06.png","D_day_07.png"],
              week_sc: ["D_day_01.png","D_day_02.png","D_day_03.png","D_day_04.png","D_day_05.png","D_day_06.png","D_day_07.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_pai_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 72,
              y: 65,
              src: '922.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 214,
              src: '922.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 187,
              minute_startY: 150,
              minute_array: ["M_digit_01.png","M_digit_02.png","M_digit_03.png","M_digit_04.png","M_digit_05.png","M_digit_06.png","M_digit_07.png","M_digit_08.png","M_digit_09.png","M_digit_10.png"],
              minute_zero: 1,
              minute_space: -11,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 17,
              hour_startY: 150,
              hour_array: ["H_digit_01.png","H_digit_02.png","H_digit_03.png","H_digit_04.png","H_digit_05.png","H_digit_06.png","H_digit_07.png","H_digit_08.png","H_digit_09.png","H_digit_10.png"],
              hour_zero: 1,
              hour_space: -11,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 0,
              // disconneсnt_toast_text: RUSH OFF,
              // conneсnt_vibrate_type: 0,
              // conneсnt_toast_text: RUSH ON,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              console.log('checkConnection()');
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  hmUI.showToast({text: "RUSH OFF"});
                  vibro(0);
                }
                if(status) {
                  hmUI.showToast({text: "RUSH ON"});
                  vibro(0);
                }
              });
            }

            // end vibration when connecting or disconnecting
            //#region vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              if (scene != 1) timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            //#endregion

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 162,
              y: 10,
              w: 150,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'transparent.png',
              normal_src: 'transparent.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 141,
              y: 249,
              w: 150,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'transparent.png',
              normal_src: 'transparent.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'WeatherScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 320,
              y: 249,
              w: 150,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'transparent.png',
              normal_src: 'transparent.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'WeatherScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 270,
              y: 307,
              w: 150,
              h: 35,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'transparent.png',
              normal_src: 'transparent.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'AlarmInfoScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 270,
              y: 348,
              w: 150,
              h: 65,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'transparent.png',
              normal_src: 'transparent.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'TideScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 164,
              y: 425,
              w: 150,
              h: 65,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'transparent.png',
              normal_src: 'transparent.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'Settings_batteryManagerScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_7 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 76,
              y: 384,
              w: 150,
              h: 30,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'transparent.png',
              normal_src: 'transparent.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PAI_app_Screen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_8 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 76,
              y: 348,
              w: 150,
              h: 30,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'transparent.png',
              normal_src: 'transparent.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'heart_app_Screen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_9 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 76,
              y: 311,
              w: 150,
              h: 30,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'transparent.png',
              normal_src: 'transparent.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'activityAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                checkConnection();
                stopVibro();

              }),
              pause_call: (function () {
                console.log('pause_call()');
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
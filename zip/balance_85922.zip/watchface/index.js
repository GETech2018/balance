﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_clock_img = ''
        let normal_sun_icon_img = ''
        let normal_sun_high_text_font = ''
        let normal_sun_low_text_font = ''
        let normal_temperature_icon_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_font = ''
        let normal_day_text_font = ''
        let normal_dow_text_font = ''
        let normal_DOW_Array = ['LUN', 'MAR', 'MER', 'GIO', 'VEN', 'SAB', 'DOM'];
        let normal_distance_icon_img = ''
        let normal_distance_current_text_font = ''
        let normal_battery_current_text_font = ''
        let normal_battery_image_progress_img_level = ''
        let normal_step_icon_img = ''
        let normal_step_current_text_font = ''
        let normal_heart_rate_text_font = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg_img = ''
        let idle_system_clock_img = ''
        let idle_sun_icon_img = ''
        let idle_sun_high_text_font = ''
        let idle_sun_low_text_font = ''
        let idle_temperature_icon_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_temperature_current_text_font = ''
        let idle_day_text_font = ''
        let idle_dow_text_font = ''
        let idle_DOW_Array = ['LUN', 'MAR', 'MER', 'GIO', 'VEN', 'SAB', 'DOM'];
        let idle_distance_icon_img = ''
        let idle_distance_current_text_font = ''
        let idle_battery_current_text_font = ''
        let idle_battery_image_progress_img_level = ''
        let idle_step_icon_img = ''
        let idle_step_current_text_font = ''
        let idle_heart_rate_text_font = ''
        let idle_heart_rate_image_progress_img_level = ''
        let idle_digital_clock_img_time = ''
        let normal_sunrise_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let Button_7 = ''
        let Button_Switch_BG = ''

        let backgroundIndex = 0;
        let backgroundList = ['wfs_01_c4a91dc3_4f38_4d89_b68c_0c6fa2900dbb.png', 'wfs_02_50b01b53_9b56_42d2_8400_35cb636522e0.png', 'wfs_03_16c3781a_c453_46d6_85b8_d20bd3edbc2d.png', 'wfs_04_ea00877e_5da4_4cd8_96d0_169c282fc472.png', 'wfs_06_5b7407c2_f171_4e3d_ac36_e9c773c962cd.png', 'wfs_09_62af8151_d336_4d7c_8669_ec257b3947d4.png', 'wfs_10_448dfa8f_d938_42b8_a771_87b26edd02e1.png', 'wfs_11_4aeb7732_596f_4479_a42e_42ab19d3d83f.png', 'wfs_14_3d9c8ad6_c746_408d_a8fb_836b3a26bb0d.png', 'wfs_15_b5e3d484_ac22_4c36_bcc8_88ded4d6d9e2.png'];
        let backgroundToastList = ['Sfondo %s', 'Sfondo %s', 'Sfondo %s', 'Sfondo %s', 'Sfondo %s', 'Sfondo %s', 'Sfondo %s', 'Sfondo %s', 'Sfondo %s', 'Sfondo %s'];
        const watchfaceId = hmApp.packageInfo().watchfaceId;
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            // FontName: wfs_orbitronbold_8abab466_334b_425e_abf3_51bb69b082c2.ttf; FontSize: 22
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 386,
              h: 32,
              text_size: 22,
              char_space: 0,
              line_space: 0,
              font: 'fonts/wfs_orbitronbold_8abab466_334b_425e_abf3_51bb69b082c2.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: wfs_orbitronbold_8abab466_334b_425e_abf3_51bb69b082c2.ttf; FontSize: 25
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 442,
              h: 37,
              text_size: 25,
              char_space: 0,
              line_space: 0,
              font: 'fonts/wfs_orbitronbold_8abab466_334b_425e_abf3_51bb69b082c2.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: wfs_orbitronbold_8abab466_334b_425e_abf3_51bb69b082c2.ttf; FontSize: 55
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 927,
              h: 79,
              text_size: 55,
              char_space: 0,
              line_space: 0,
              font: 'fonts/wfs_orbitronbold_8abab466_334b_425e_abf3_51bb69b082c2.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: wfs_orbitronbold_8abab466_334b_425e_abf3_51bb69b082c2.ttf; FontSize: 40; Cache: full
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 48,
              h: 48,
              text_size: 40,
              char_space: 0,
              line_space: 0,
              font: 'fonts/wfs_orbitronbold_8abab466_334b_425e_abf3_51bb69b082c2.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.NONE,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: wfs_orbitronbold_8abab466_334b_425e_abf3_51bb69b082c2.ttf; FontSize: 30
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 526,
              h: 44,
              text_size: 30,
              char_space: 0,
              line_space: 0,
              font: 'fonts/wfs_orbitronbold_8abab466_334b_425e_abf3_51bb69b082c2.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            //start of ignored block
            console.log('SwitchBackground');
            function switchBackground() {
              backgroundIndex++;
              if (backgroundIndex >= backgroundList.length) backgroundIndex = 0;
              hmFS.SysProSetInt(`backgroundIndex_${watchfaceId}`, backgroundIndex);
              let toastText = backgroundToastList[backgroundIndex].replace('%s', `${backgroundIndex + 1}`);
              if (toastText.length > 0) hmUI.showToast({text: toastText});
              normal_background_bg_img.setProperty(hmUI.prop.SRC, backgroundList[backgroundIndex]);
              vibro(28);
            };
            //end of ignored block

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'wfs_01_c4a91dc3_4f38_4d89_b68c_0c6fa2900dbb.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 223,
              y: 6,
              src: 'bottone_sveglia.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 63,
              y: 92,
              src: 'ALBA.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 7,
              y: 130,
              w: 150,
              h: 40,
              text_size: 22,
              char_space: 0,
              line_space: 0,
              font: 'fonts/wfs_orbitronbold_8abab466_334b_425e_abf3_51bb69b082c2.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 7,
              y: 155,
              w: 150,
              h: 40,
              text_size: 22,
              char_space: 0,
              line_space: 0,
              font: 'fonts/wfs_orbitronbold_8abab466_334b_425e_abf3_51bb69b082c2.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 63,
              y: 179,
              src: 'TRAMONTO.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 335,
              y: 90,
              image_array: ["m001.png","m002.png","m003.png","m004.png","m005.png","m006.png","m007.png","m008.png","m009.png","m010.png","m011.png","m012.png","m013.png","m014.png","m015.png","m016.png","m017.png","m018.png","m019.png","m020.png","m021.png","m022.png","m023.png","m024.png","m025.png","m026.png","m027.png","m028.png","m029.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 340,
              y: 68,
              w: 150,
              h: 30,
              text_size: 25,
              char_space: 0,
              line_space: 0,
              font: 'fonts/wfs_orbitronbold_8abab466_334b_425e_abf3_51bb69b082c2.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function() {
              time_update(true);
            });

            normal_day_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 303,
              y: 204,
              w: 200,
              h: 60,
              text_size: 55,
              char_space: 0,
              line_space: 0,
              font: 'fonts/wfs_orbitronbold_8abab466_334b_425e_abf3_51bb69b082c2.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_dow_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 3,
              y: 213,
              w: 150,
              h: 50,
              text_size: 40,
              char_space: 0,
              line_space: 0,
              font: 'fonts/wfs_orbitronbold_8abab466_334b_425e_abf3_51bb69b082c2.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              // unit_string: LUN,MAR,MER,GIO,VEN,SAB,DOM,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 220,
              y: 91,
              src: 'km_2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 165,
              y: 49,
              w: 150,
              h: 50,
              text_size: 30,
              char_space: 0,
              line_space: 0,
              font: 'fonts/wfs_orbitronbold_8abab466_334b_425e_abf3_51bb69b082c2.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 33,
              y: 347,
              w: 150,
              h: 50,
              text_size: 30,
              char_space: 0,
              line_space: 0,
              font: 'fonts/wfs_orbitronbold_8abab466_334b_425e_abf3_51bb69b082c2.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 83,
              y: 304,
              image_array: ["bat_1.png","bat_2.png","bat_3.png","bat_4.png","bat_5.png","bat_6.png","bat_7.png","bat_8.png","bat_9.png","bat_10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 213,
              y: 342,
              src: '24scarpa.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 165,
              y: 388,
              w: 150,
              h: 40,
              text_size: 30,
              char_space: 0,
              line_space: 0,
              font: 'fonts/wfs_orbitronbold_8abab466_334b_425e_abf3_51bb69b082c2.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 297,
              y: 347,
              w: 150,
              h: 50,
              text_size: 30,
              char_space: 0,
              line_space: 0,
              font: 'fonts/wfs_orbitronbold_8abab466_334b_425e_abf3_51bb69b082c2.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 354,
              y: 314,
              image_array: ["h_01.png","h_02.png","h_03.png","h_04.png","h_05.png","h_06.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 153,
              hour_startY: 132,
              hour_array: ["b20.png","b21.png","b22.png","b23.png","b24.png","b25.png","b26.png","b27.png","b28.png","b29.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 154,
              minute_startY: 227,
              minute_array: ["20.png","21.png","22.png","23.png","24.png","25.png","26.png","27.png","28.png","29.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'wfs_01_c4a91dc3_4f38_4d89_b68c_0c6fa2900dbb.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 223,
              y: 6,
              src: 'bottone_sveglia.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_sun_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 63,
              y: 92,
              src: 'ALBA.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_sun_high_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 7,
              y: 130,
              w: 150,
              h: 40,
              text_size: 22,
              char_space: 0,
              line_space: 0,
              font: 'fonts/wfs_orbitronbold_8abab466_334b_425e_abf3_51bb69b082c2.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_sun_low_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 7,
              y: 155,
              w: 150,
              h: 40,
              text_size: 22,
              char_space: 0,
              line_space: 0,
              font: 'fonts/wfs_orbitronbold_8abab466_334b_425e_abf3_51bb69b082c2.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 63,
              y: 179,
              src: 'TRAMONTO.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 335,
              y: 90,
              image_array: ["m001.png","m002.png","m003.png","m004.png","m005.png","m006.png","m007.png","m008.png","m009.png","m010.png","m011.png","m012.png","m013.png","m014.png","m015.png","m016.png","m017.png","m018.png","m019.png","m020.png","m021.png","m022.png","m023.png","m024.png","m025.png","m026.png","m027.png","m028.png","m029.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 340,
              y: 68,
              w: 150,
              h: 30,
              text_size: 25,
              char_space: 0,
              line_space: 0,
              font: 'fonts/wfs_orbitronbold_8abab466_334b_425e_abf3_51bb69b082c2.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_day_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 303,
              y: 204,
              w: 200,
              h: 60,
              text_size: 55,
              char_space: 0,
              line_space: 0,
              font: 'fonts/wfs_orbitronbold_8abab466_334b_425e_abf3_51bb69b082c2.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              // padding: true,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_dow_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 3,
              y: 213,
              w: 150,
              h: 50,
              text_size: 40,
              char_space: 0,
              line_space: 0,
              font: 'fonts/wfs_orbitronbold_8abab466_334b_425e_abf3_51bb69b082c2.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              // unit_string: LUN,MAR,MER,GIO,VEN,SAB,DOM,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_distance_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 220,
              y: 91,
              src: 'km_2.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_distance_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 165,
              y: 49,
              w: 150,
              h: 50,
              text_size: 30,
              char_space: 0,
              line_space: 0,
              font: 'fonts/wfs_orbitronbold_8abab466_334b_425e_abf3_51bb69b082c2.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 33,
              y: 347,
              w: 150,
              h: 50,
              text_size: 30,
              char_space: 0,
              line_space: 0,
              font: 'fonts/wfs_orbitronbold_8abab466_334b_425e_abf3_51bb69b082c2.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 83,
              y: 304,
              image_array: ["bat_1.png","bat_2.png","bat_3.png","bat_4.png","bat_5.png","bat_6.png","bat_7.png","bat_8.png","bat_9.png","bat_10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 213,
              y: 342,
              src: '24scarpa.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 165,
              y: 388,
              w: 150,
              h: 40,
              text_size: 30,
              char_space: 0,
              line_space: 0,
              font: 'fonts/wfs_orbitronbold_8abab466_334b_425e_abf3_51bb69b082c2.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 297,
              y: 347,
              w: 150,
              h: 50,
              text_size: 30,
              char_space: 0,
              line_space: 0,
              font: 'fonts/wfs_orbitronbold_8abab466_334b_425e_abf3_51bb69b082c2.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 354,
              y: 314,
              image_array: ["h_01.png","h_02.png","h_03.png","h_04.png","h_05.png","h_06.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 153,
              hour_startY: 132,
              hour_array: ["b20.png","b21.png","b22.png","b23.png","b24.png","b25.png","b26.png","b27.png","b28.png","b29.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 154,
              minute_startY: 227,
              minute_array: ["20.png","21.png","22.png","23.png","24.png","25.png","26.png","27.png","28.png","29.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 42,
              y: 105,
              w: 100,
              h: 100,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 337,
              y: 85,
              w: 100,
              h: 100,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_empty.png',
              normal_src: '0_empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'WeatherScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 335,
              y: 307,
              w: 100,
              h: 100,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_empty.png',
              normal_src: '0_empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'heart_app_Screen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 63,
              y: 309,
              w: 100,
              h: 100,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_empty.png',
              normal_src: '0_empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PowerSaveHintScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 199,
              y: 322,
              w: 100,
              h: 100,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_empty.png',
              normal_src: '0_empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'activityAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 357,
              y: 208,
              w: 93,
              h: 70,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_empty.png',
              normal_src: '0_empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 188,
              y: 50,
              w: 100,
              h: 80,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_empty.png',
              normal_src: '0_empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'SportListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_7 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 215,
              y: 2,
              w: 40,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_empty.png',
              normal_src: '0_empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'AlarmInfoScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            console.log('Watch_Face.SwitchBackground');
            // Button_Switch_BG = hmUI.createWidget(hmUI.widget.SwitchBackground, {
              // x: 189,
              // y: 429,
              // w: 100,
              // h: 53,
              // text: '',
              // color: 0xFFFF8C00,
              // text_size: 25,
              // press_src: '0_empty.png',
              // normal_src: '0_empty.png',
              // bg_list: wfs_01_c4a91dc3_4f38_4d89_b68c_0c6fa2900dbb|wfs_02_50b01b53_9b56_42d2_8400_35cb636522e0|wfs_03_16c3781a_c453_46d6_85b8_d20bd3edbc2d|wfs_04_ea00877e_5da4_4cd8_96d0_169c282fc472|wfs_06_5b7407c2_f171_4e3d_ac36_e9c773c962cd|wfs_09_62af8151_d336_4d7c_8669_ec257b3947d4|wfs_10_448dfa8f_d938_42b8_a771_87b26edd02e1|wfs_11_4aeb7732_596f_4479_a42e_42ab19d3d83f|wfs_14_3d9c8ad6_c746_408d_a8fb_836b3a26bb0d|wfs_15_b5e3d484_ac22_4c36_bcc8_88ded4d6d9e2,
              // toast_list: Sfondo %s|Sfondo %s|Sfondo %s|Sfondo %s|Sfondo %s|Sfondo %s|Sfondo %s|Sfondo %s|Sfondo %s|Sfondo %s,
              // use_crown: False,
              // use_in_AOD: True,
              // vibro: True,
            // });

            Button_Switch_BG = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 189,
              y: 429,
              w: 100,
              h: 53,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_empty.png',
              normal_src: '0_empty.png',
              click_func: (button_widget) => {
                switchBackground();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            let screenType = hmSetting.getScreenType();
            // vibrate function
            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;

            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function

            //start of ignored block
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              console.log('day font');
              if (updateHour) {
                let normal_dayStr = timeSensor.day.toString();
                normal_dayStr = normal_dayStr.padStart(2, '0');
                normal_day_text_font.setProperty(hmUI.prop.TEXT, normal_dayStr );
              };

              console.log('day of week font');
              if (updateHour) {
                let normal_DOW_Str = normal_DOW_Array[timeSensor.week-1];
                normal_dow_text_font.setProperty(hmUI.prop.TEXT, normal_DOW_Str );
              };

              console.log('day font');
              if (updateHour) {
                let idle_dayStr = timeSensor.day.toString();
                idle_dayStr = idle_dayStr.padStart(2, '0');
                idle_day_text_font.setProperty(hmUI.prop.TEXT, idle_dayStr );
              };

              console.log('day of week font');
              if (updateHour) {
                let idle_DOW_Str = idle_DOW_Array[timeSensor.week-1];
                idle_dow_text_font.setProperty(hmUI.prop.TEXT, idle_DOW_Str );
              };

            };

            //end of ignored block
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                time_update(true, true);

                //SwitchBackground
                if (hmFS.SysProGetInt(`backgroundIndex_${watchfaceId}`) === undefined) {
                  backgroundIndex = 0;
                  hmFS.SysProSetInt(`backgroundIndex_${watchfaceId}`, backgroundIndex);
                } else {
                  backgroundIndex = hmFS.SysProGetInt(`backgroundIndex_${watchfaceId}`);
                };
                if (screenType == hmSetting.screen_type.WATCHFACE && normal_background_bg_img) normal_background_bg_img.setProperty(hmUI.prop.SRC, backgroundList[backgroundIndex]);
                if (screenType == hmSetting.screen_type.AOD && idle_background_bg_img) idle_background_bg_img.setProperty(hmUI.prop.SRC, backgroundList[backgroundIndex]);
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
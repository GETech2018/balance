﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

let cc=0;
let nLucaAnim=0;
let nMaxAnim=3

function click_LucaAnim(){
    nLucaAnim=nLucaAnim+1;
	if(nLucaAnim>nMaxAnim){nLucaAnim=0;}
    Show_LucaAnim();
}

//////////////////////////////////////////////////////////////////////////////////////////////////

// Animation ON
function Show_LucaAnim(){

  if(nLucaAnim==0){
	hmUI.showToast({text: 'Animation: OFF'});
    normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);
	normal_frame_animation_1.setProperty(hmUI.prop.VISIBLE,    false);
    normal_frame_animation_2.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);
	normal_frame_animation_2.setProperty(hmUI.prop.VISIBLE,    false);
	normal_background_bg_img.setProperty(hmUI.prop.SRC,    "bg-BTsfc.png");
  }

  if(nLucaAnim==1){
	hmUI.showToast({text: 'Swimming'});
	normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);
	normal_frame_animation_1.setProperty(hmUI.prop.VISIBLE,    true);
	normal_frame_animation_2.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);
	normal_frame_animation_2.setProperty(hmUI.prop.VISIBLE,    false);
	normal_background_bg_img.setProperty(hmUI.prop.SRC,    "bg-black.png");
  }
  if(nLucaAnim==2){
	hmUI.showToast({text: 'Riding'});
	normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);
	normal_frame_animation_1.setProperty(hmUI.prop.VISIBLE,    false);
	normal_frame_animation_2.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);
	normal_frame_animation_2.setProperty(hmUI.prop.VISIBLE,    true);
	normal_background_bg_img.setProperty(hmUI.prop.SRC,    "bg-black.png");
  }
  if(nLucaAnim==3){
	hmUI.showToast({text: 'Weather'});
	normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);
	normal_frame_animation_1.setProperty(hmUI.prop.VISIBLE,    false);
	normal_frame_animation_2.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);
	normal_frame_animation_2.setProperty(hmUI.prop.VISIBLE,    false);
	normal_background_bg_img.setProperty(hmUI.prop.SRC,    "bg-BTsun.png");
  }

   for (let i = 0; i < 8; i++) {
       normal_forecast_image_progress_img_level[i].setProperty(hmUI.prop.VISIBLE, (nLucaAnim==3));  
       normal_forecast_date_week_font[i].setProperty(hmUI.prop.VISIBLE, (nLucaAnim==3)); 
       normal_forecast_average_text_font[i].setProperty(hmUI.prop.VISIBLE, (nLucaAnim==3)); 
       normal_forecast_low_text_font[i].setProperty(hmUI.prop.VISIBLE, (nLucaAnim==3));  
       normal_forecast_high_text_font[i].setProperty(hmUI.prop.VISIBLE, (nLucaAnim==3)); 
   }
}

// a kész index.js -ben az init részben lecserélni a magyarításhoz
//        let normal_forecast_date_week_font_Array = ['Hé', 'Ke', 'Sze', 'Cs', 'Pé', 'Szo', 'Va']; //['Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa', 'Su'];
        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_group_ForecastWeather = ''
        let normal_forecast_image_progress_img_level = new Array(8);
        let normal_forecast_image_array = ['058.png', '059.png', '060.png', '061.png', '062.png', '063.png', '064.png', '065.png', '066.png', '067.png', '068.png', '069.png', '070.png', '071.png', '072.png', '073.png', '074.png', '075.png', '076.png', '077.png', '078.png', '079.png', '080.png', '081.png', '082.png', '083.png', '084.png', '085.png', '086.png'];
        let normal_forecast_date_week_font = new Array(8);
        let normal_forecast_date_week_font_Array = ['Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa', 'Su'];
        let normal_forecast_average_text_font = new Array(8);
        let normal_forecast_low_text_font = new Array(8);
        let normal_forecast_high_text_font = new Array(8);
        let normal_digital_clock_img_time_second = ''
        let normal_digital_clock_img_time_minute = ''
        let normal_digital_clock_img_time_hour = ''
        let normal_frame_animation_1 = ''
        let normal_frame_animation_2 = ''
        let idle_background_bg = ''
        let idle_digital_clock_img_time_second = ''
        let idle_digital_clock_img_time_minute = ''
        let idle_digital_clock_img_time_hour = ''
        let Button_1 = ''
        let timeSensor = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg-BTsfc.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();            
            // normal_Weather_FewDays = hmUI.createWidget(hmUI.widget.FewDays, {
              // x: -60,
              // y: 125,
              // ColumnWidth: 58,
              // DaysCount: 8,
            // });
            
            normal_group_ForecastWeather = hmUI.createWidget(hmUI.widget.GROUP, {
              x: -60,
              y: 125,
              h: 0,
              w: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_forecast_image_progress_img_level = normal_group_ForecastWeather.createWidget(hmUI.widget.IMG_LEVEL_Options, {
              // x: 67,
              // y: 142,
              // image_array: ["058.png","059.png","060.png","061.png","062.png","063.png","064.png","065.png","066.png","067.png","068.png","069.png","070.png","071.png","072.png","073.png","074.png","075.png","076.png","077.png","078.png","079.png","080.png","081.png","082.png","083.png","084.png","085.png","086.png"],
              // image_length: 29,
              // type: hmUI.data_type.forecast_image,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            //start of ignored block
            if (screenType == hmSetting.screen_type.WATCHFACE) {
              for (let i = 0; i < 8; i++) {
                normal_forecast_image_progress_img_level[i] = normal_group_ForecastWeather.createWidget(hmUI.widget.IMG, {
                  x: 67 + i*58,
                  y: 142,
                  src: normal_forecast_image_array[25],
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
              };
            };
            //end of ignored block

            // normal_forecast_date_week_font = normal_group_ForecastWeather.createWidget(hmUI.widget.TEXT_Options, {
              // x: -75,
              // y: 0,
              // w: 190,
              // h: 50,
              // text_size: 40,
              // char_space: -5,
              // line_space: 0,
              // color: 0xFFFF8000,
              // color_2: 0xFFFF0000,
              // use_color_2: False,
              // align_h: hmUI.align.RIGHT,
              // align_v: hmUI.align.TOP,
              // text_style: hmUI.text_style.ELLIPSIS,
              // type: hmUI.data_type.forecast_date_week_img,
              // unit_string: Mo, Tu, We, Th, Fr, Sa, Su,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            //start of ignored block
            if (screenType == hmSetting.screen_type.WATCHFACE) {
              for (let i = 0; i < 8; i++) {
                normal_forecast_date_week_font[i] = normal_group_ForecastWeather.createWidget(hmUI.widget.TEXT, {
                  x: -75 + i*58,
                  y: 0,
                  w: 190,
                  h: 50,
                  text_size: 40,
                  char_space: -5,
                  line_space: 0,
                  color: 0xFFFF8000,
                  // color_2: 0xFFFF0000,
                  align_h: hmUI.align.RIGHT,
                  align_v: hmUI.align.TOP,
                  text_style: hmUI.text_style.ELLIPSIS,
                  // unit_string: Mo, Tu, We, Th, Fr, Sa, Su,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
              };
            };
            //end of ignored block

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            // normal_forecast_average_text_font = normal_group_ForecastWeather.createWidget(hmUI.widget.TEXT_Options, {
              // x: -30,
              // y: 110,
              // w: 150,
              // h: 40,
              // text_size: 30,
              // char_space: 0,
              // line_space: 0,
              // color: 0xFFC0C0C0,
              // color_2: 0xFFFF0000,
              // use_color_2: False,
              // align_h: hmUI.align.RIGHT,
              // align_v: hmUI.align.TOP,
              // text_style: hmUI.text_style.ELLIPSIS,
              // type: hmUI.data_type.forecast_average_text_font,
              // unit_type: 1,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            //start of ignored block
            if (screenType == hmSetting.screen_type.WATCHFACE) {
              for (let i = 0; i < 8; i++) {
                normal_forecast_average_text_font[i] = normal_group_ForecastWeather.createWidget(hmUI.widget.TEXT, {
                  x: -30 + i*58,
                  y: 110,
                  w: 150,
                  h: 40,
                  text_size: 30,
                  char_space: 0,
                  line_space: 0,
                  color: 0xFFC0C0C0,
                  align_h: hmUI.align.RIGHT,
                  align_v: hmUI.align.TOP,
                  text_style: hmUI.text_style.ELLIPSIS,
                  // unit_type: 1,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
              };
            };
            //end of ignored block

            // normal_forecast_low_text_font = normal_group_ForecastWeather.createWidget(hmUI.widget.TEXT_Options, {
              // x: -30,
              // y: 80,
              // w: 150,
              // h: 40,
              // text_size: 30,
              // char_space: 0,
              // line_space: 0,
              // color: 0xFF00FF40,
              // color_2: 0xFFFF0000,
              // use_color_2: False,
              // align_h: hmUI.align.RIGHT,
              // align_v: hmUI.align.TOP,
              // text_style: hmUI.text_style.ELLIPSIS,
              // type: hmUI.data_type.forecast_low_text_font,
              // unit_type: 1,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            //start of ignored block
            if (screenType == hmSetting.screen_type.WATCHFACE) {
              for (let i = 0; i < 8; i++) {
                normal_forecast_low_text_font[i] = normal_group_ForecastWeather.createWidget(hmUI.widget.TEXT, {
                  x: -30 + i*58,
                  y: 80,
                  w: 150,
                  h: 40,
                  text_size: 30,
                  char_space: 0,
                  line_space: 0,
                  color: 0xFF00FF40,
                  align_h: hmUI.align.RIGHT,
                  align_v: hmUI.align.TOP,
                  text_style: hmUI.text_style.ELLIPSIS,
                  // unit_type: 1,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
              };
            };
            //end of ignored block

            // normal_forecast_high_text_font = normal_group_ForecastWeather.createWidget(hmUI.widget.TEXT_Options, {
              // x: -30,
              // y: 50,
              // w: 150,
              // h: 40,
              // text_size: 30,
              // char_space: 0,
              // line_space: 0,
              // color: 0xFFFF0000,
              // color_2: 0xFFFF0000,
              // use_color_2: False,
              // align_h: hmUI.align.RIGHT,
              // align_v: hmUI.align.TOP,
              // text_style: hmUI.text_style.ELLIPSIS,
              // type: hmUI.data_type.forecast_high_text_font,
              // unit_type: 2,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            //start of ignored block
            if (screenType == hmSetting.screen_type.WATCHFACE) {
              for (let i = 0; i < 8; i++) {
                normal_forecast_high_text_font[i] = normal_group_ForecastWeather.createWidget(hmUI.widget.TEXT, {
                  x: -30 + i*58,
                  y: 50,
                  w: 150,
                  h: 40,
                  text_size: 30,
                  char_space: 0,
                  line_space: 0,
                  color: 0xFFFF0000,
                  align_h: hmUI.align.RIGHT,
                  align_v: hmUI.align.TOP,
                  text_style: hmUI.text_style.ELLIPSIS,
                  // unit_type: 2,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
              };
            };
            //end of ignored block

            normal_digital_clock_img_time_second = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              second_startX: 278,
              second_startY: 305,
              second_array: ["numg00.png","numg01.png","numg02.png","numg03.png","numg04.png","numg05.png","numg06.png","numg07.png","numg08.png","numg09.png"],
              second_zero: 1,
              second_space: -40,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 160,
              minute_startY: 305,
              minute_array: ["numr00.png","numr01.png","numr02.png","numr03.png","numr04.png","numr05.png","numr06.png","numr07.png","numr08.png","numr09.png"],
              minute_zero: 1,
              minute_space: -40,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 35,
              hour_startY: 305,
              hour_array: ["numo00.png","numo01.png","numo02.png","numo03.png","numo04.png","numo05.png","numo06.png","numo07.png","numo08.png","numo09.png"],
              hour_zero: 1,
              hour_space: -35,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_frame_animation_1 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
              x: 0,
              y: 0,
              anim_path: "animation",
              anim_ext: "png",
              anim_prefix: "anim",
              anim_fps: 15,
              anim_size: 10,
              repeat_count: 0,
              anim_repeat: true,
              anim_status:hmUI.anim_status.START,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_frame_animation_2 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
              x: 76,
              y: 1,
              anim_path: "animation",
              anim_ext: "png",
              anim_prefix: "frame",
              anim_fps: 15,
              anim_size: 14,
              repeat_count: 0,
              anim_repeat: true,
              anim_status:hmUI.anim_status.START,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_second = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              second_startX: 278,
              second_startY: 305,
              second_array: ["numg00.png","numg01.png","numg02.png","numg03.png","numg04.png","numg05.png","numg06.png","numg07.png","numg08.png","numg09.png"],
              second_zero: 1,
              second_space: -40,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 160,
              minute_startY: 305,
              minute_array: ["numr00.png","numr01.png","numr02.png","numr03.png","numr04.png","numr05.png","numr06.png","numr07.png","numr08.png","numr09.png"],
              minute_zero: 1,
              minute_space: -40,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 35,
              hour_startY: 305,
              hour_array: ["numo00.png","numo01.png","numo02.png","numo03.png","numo04.png","numo05.png","numo06.png","numo07.png","numo08.png","numo09.png"],
              hour_zero: 1,
              hour_space: -35,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 100,
              y: 100,
              w: 300,
              h: 300,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'numblank.png',
              normal_src: 'numblank.png',
              click_func: (button_widget) => {
                click_LucaAnim();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            console.log('user_script_end.js');
            // start user_script_end.js

if (cc==0 ){
nLucaAnim=0;
Show_LucaAnim();
hmUI.showToast({text: 'Init'});
cc =1;
}
// a 'körbeírt' szövegek automatikus megjelenítését meg kell akadályozni, 
// hogy csak a saját fázisukban jelenjenek meg...
// if (screenType == hmSetting.screen_type.WATCHFACE && nLucaAnim==3) {
            // end user_script_end.js

            const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);
            //start of ignored block
            function weather_few_days() {
              console.log('weather_few_days()');
              let weatherData = weatherSensor.getForecastWeather();
              let forecastData = weatherData.forecastData;

              for (let i = 0; i < 8; i++) {
                // Images
                if (screenType == hmSetting.screen_type.WATCHFACE && nLucaAnim==3) {
                  let weatherIndex = 25
                  if (i < forecastData.count) weatherIndex = forecastData.data[i].index;
                  normal_forecast_image_progress_img_level[i].setProperty(hmUI.prop.SRC, normal_forecast_image_array[weatherIndex]);
                };
              
                // DayOfWeek font
                if (screenType == hmSetting.screen_type.WATCHFACE && nLucaAnim==3) {
                  let dowIndex = timeSensor.week - 1;
                  dowIndex += i;
                  while (dowIndex >= 7) {dowIndex -= 7;}
                  normal_forecast_date_week_font[i].setProperty(hmUI.prop.TEXT, normal_forecast_date_week_font_Array[dowIndex]);
                };
              
                // Number_Font_Average
                let averageTemperature = '-';
                if (i < forecastData.count) averageTemperature = parseInt((forecastData.data[i].high + forecastData.data[i].low)/2).toString();
                if (screenType == hmSetting.screen_type.WATCHFACE && nLucaAnim==3) {
                  normal_forecast_average_text_font[i].setProperty(hmUI.prop.TEXT, averageTemperature + '°');
                };
                
                // Number_Font_Min
                let minTemperature = '-';
                if (i < forecastData.count) minTemperature = forecastData.data[i].low.toString();
                if (screenType == hmSetting.screen_type.WATCHFACE && nLucaAnim==3) {
                  normal_forecast_low_text_font[i].setProperty(hmUI.prop.TEXT, minTemperature + '°');
                };
                
                // Number_Font_Max
                let maxTemperature = '-';
                if (i < forecastData.count) maxTemperature = forecastData.data[i].high.toString();
                if (screenType == hmSetting.screen_type.WATCHFACE && nLucaAnim==3) {
                  normal_forecast_high_text_font[i].setProperty(hmUI.prop.TEXT, maxTemperature + '°');
                };
                
              };  // end for

            };
            //end of ignored block

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);
                normal_frame_animation_2.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);

                weather_few_days();
              }),
              pause_call: (function () {
                console.log('pause_call()');
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);
                normal_frame_animation_2.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
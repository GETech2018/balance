﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg = ''
        let normal_image_img = ''
        let normal_temperature_icon_img = ''
        let normal_temperature_current_text_font = ''
        let normal_step_icon_img = ''
        let normal_step_current_text_font = ''
        let normal_battery_icon_img = ''
        let normal_battery_current_text_font = ''
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_text_font = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg = ''
        let idle_image_img = ''
        let idle_temperature_icon_img = ''
        let idle_temperature_current_text_font = ''
        let idle_step_icon_img = ''
        let idle_step_current_text_font = ''
        let idle_battery_icon_img = ''
        let idle_battery_current_text_font = ''
        let idle_heart_rate_icon_img = ''
        let idle_heart_rate_text_font = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_day = ''
        let idle_digital_clock_img_time = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'img_binario.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 186,
              y: 11,
              src: 'METEO_HP.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 233,
              y: 9,
              w: 150,
              h: 30,
              text_size: 25,
              char_space: 0,
              line_space: 0,
              color: 0xFFEADCAB,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 165,
              y: 416,
              src: 'SCOPAHP.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 239,
              y: 430,
              w: 150,
              h: 30,
              text_size: 25,
              char_space: 0,
              line_space: 0,
              color: 0xFFEADCAB,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 432,
              y: 180,
              src: 'fulmine_hp.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 427,
              y: 235,
              w: 150,
              h: 30,
              text_size: 25,
              char_space: 0,
              line_space: 0,
              color: 0xFFEADCAB,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 20,
              y: 200,
              src: 'cuorehp2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 18,
              y: 235,
              w: 150,
              h: 30,
              text_size: 25,
              char_space: 0,
              line_space: 0,
              color: 0xFFEADCAB,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              padding: true,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 266,
              month_startY: 355,
              month_sc_array: ["B1.png","B2.png","B3.png","B4.png","B5.png","B6.png","B7.png","B8.png","B9.png","BB10.png","BB11.png","BB12.png"],
              month_tc_array: ["B1.png","B2.png","B3.png","B4.png","B5.png","B6.png","B7.png","B8.png","B9.png","BB10.png","BB11.png","BB12.png"],
              month_en_array: ["B1.png","B2.png","B3.png","B4.png","B5.png","B6.png","B7.png","B8.png","B9.png","BB10.png","BB11.png","BB12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 143,
              y: 355,
              week_en: ["a1.png","a2.png","a3.png","a4.png","a5.png","a6.png","a7.png"],
              week_tc: ["a1.png","a2.png","a3.png","a4.png","a5.png","a6.png","a7.png"],
              week_sc: ["a1.png","a2.png","a3.png","a4.png","a5.png","a6.png","a7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 210,
              day_startY: 347,
              day_sc_array: ["d0.png","d1.png","d2.png","d3.png","d4.png","d5.png","d6.png","d7.png","d8.png","d9.png"],
              day_tc_array: ["d0.png","d1.png","d2.png","d3.png","d4.png","d5.png","d6.png","d7.png","d8.png","d9.png"],
              day_en_array: ["d0.png","d1.png","d2.png","d3.png","d4.png","d5.png","d6.png","d7.png","d8.png","d9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 80,
              hour_startY: 191,
              hour_array: ["g0.png","g1.png","g2.png","g3.png","g4.png","g5.png","g6.png","g7.png","g8.png","g9.png"],
              hour_zero: 1,
              hour_space: -22,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 275,
              minute_startY: 178,
              minute_array: ["img00.png","img01.png","img02.png","img03.png","img04.png","img05.png","img06.png","img07.png","img08.png","img09.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 275,
              second_startY: 269,
              second_array: ["r0.png","r1.png","r2.png","r3.png","r4.png","r5.png","r6.png","r7.png","r8.png","r9.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'img_binario.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 186,
              y: 11,
              src: 'METEO_HP.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 233,
              y: 9,
              w: 150,
              h: 30,
              text_size: 25,
              char_space: 0,
              line_space: 0,
              color: 0xFFEADCAB,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 165,
              y: 416,
              src: 'SCOPAHP.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 239,
              y: 430,
              w: 150,
              h: 30,
              text_size: 25,
              char_space: 0,
              line_space: 0,
              color: 0xFFEADCAB,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 432,
              y: 180,
              src: 'fulmine_hp.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 427,
              y: 235,
              w: 150,
              h: 30,
              text_size: 25,
              char_space: 0,
              line_space: 0,
              color: 0xFFEADCAB,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 20,
              y: 200,
              src: 'cuorehp2.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 18,
              y: 235,
              w: 150,
              h: 30,
              text_size: 25,
              char_space: 0,
              line_space: 0,
              color: 0xFFEADCAB,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              padding: true,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 266,
              month_startY: 355,
              month_sc_array: ["B1.png","B2.png","B3.png","B4.png","B5.png","B6.png","B7.png","B8.png","B9.png","BB10.png","BB11.png","BB12.png"],
              month_tc_array: ["B1.png","B2.png","B3.png","B4.png","B5.png","B6.png","B7.png","B8.png","B9.png","BB10.png","BB11.png","BB12.png"],
              month_en_array: ["B1.png","B2.png","B3.png","B4.png","B5.png","B6.png","B7.png","B8.png","B9.png","BB10.png","BB11.png","BB12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 143,
              y: 355,
              week_en: ["a1.png","a2.png","a3.png","a4.png","a5.png","a6.png","a7.png"],
              week_tc: ["a1.png","a2.png","a3.png","a4.png","a5.png","a6.png","a7.png"],
              week_sc: ["a1.png","a2.png","a3.png","a4.png","a5.png","a6.png","a7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 210,
              day_startY: 347,
              day_sc_array: ["d0.png","d1.png","d2.png","d3.png","d4.png","d5.png","d6.png","d7.png","d8.png","d9.png"],
              day_tc_array: ["d0.png","d1.png","d2.png","d3.png","d4.png","d5.png","d6.png","d7.png","d8.png","d9.png"],
              day_en_array: ["d0.png","d1.png","d2.png","d3.png","d4.png","d5.png","d6.png","d7.png","d8.png","d9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 80,
              hour_startY: 191,
              hour_array: ["g0.png","g1.png","g2.png","g3.png","g4.png","g5.png","g6.png","g7.png","g8.png","g9.png"],
              hour_zero: 1,
              hour_space: -22,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 275,
              minute_startY: 178,
              minute_array: ["img00.png","img01.png","img02.png","img03.png","img04.png","img05.png","img06.png","img07.png","img08.png","img09.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 275,
              second_startY: 269,
              second_array: ["r0.png","r1.png","r2.png","r3.png","r4.png","r5.png","r6.png","r7.png","r8.png","r9.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
try {
    (() => {
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface6');
        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 480,
                    h: 480,
                    src: '4.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                    x: 20,
                    y: 15,
                    image_array: [
                        '5.png',
                        '6.png',
                        '7.png',
                        '8.png',
                        '9.png'
                    ],
                    image_length: 5,
                    type: hmUI.data_type.PAI_WEEKLY,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 272,
                    y: 31,
                    type: hmUI.data_type.PAI_WEEKLY,
                    font_array: [
                        '10.png',
                        '11.png',
                        '12.png',
                        '13.png',
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png'
                    ],
                    align_h: hmUI.align.LEFT,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    invalid_image: '20.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG_PROGRESS, {
                    x: [
                        48,
                        48,
                        48,
                        48,
                        48
                    ],
                    y: [
                        52,
                        52,
                        52,
                        52,
                        52
                    ],
                    image_array: [
                        '22.png',
                        '23.png',
                        '24.png',
                        '25.png',
                        '26.png'
                    ],
                    image_length: 5,
                    type: hmUI.data_type.UVI,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 272,
                    y: 55,
                    type: hmUI.data_type.UVI,
                    font_array: [
                        '10.png',
                        '11.png',
                        '12.png',
                        '13.png',
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png'
                    ],
                    align_h: hmUI.align.LEFT,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    invalid_image: '27.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                    x: 72,
                    y: 72,
                    image_array: [
                        '29.png',
                        '30.png',
                        '31.png',
                        '32.png',
                        '33.png',
                        '34.png'
                    ],
                    image_length: 6,
                    type: hmUI.data_type.AQI,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 272,
                    y: 78,
                    type: hmUI.data_type.AQI,
                    font_array: [
                        '35.png',
                        '36.png',
                        '37.png',
                        '38.png',
                        '39.png',
                        '40.png',
                        '41.png',
                        '42.png',
                        '43.png',
                        '44.png'
                    ],
                    align_h: hmUI.align.LEFT,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    invalid_image: '45.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                    x: 92,
                    y: 93,
                    image_array: [
                        '47.png',
                        '48.png',
                        '49.png',
                        '50.png',
                        '51.png'
                    ],
                    image_length: 5,
                    type: hmUI.data_type.HUMIDITY,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 272,
                    y: 99,
                    type: hmUI.data_type.HUMIDITY,
                    font_array: [
                        '35.png',
                        '36.png',
                        '37.png',
                        '38.png',
                        '39.png',
                        '40.png',
                        '41.png',
                        '42.png',
                        '43.png',
                        '44.png'
                    ],
                    align_h: hmUI.align.LEFT,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    unit_sc: '53.png',
                    unit_tc: '53.png',
                    unit_en: '53.png',
                    invalid_image: '52.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                    x: 114,
                    y: 114,
                    image_array: [
                        '54.png',
                        '55.png',
                        '56.png',
                        '57.png',
                        '58.png'
                    ],
                    image_length: 5,
                    type: hmUI.data_type.HEART,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 272,
                    y: 121,
                    type: hmUI.data_type.HEART,
                    font_array: [
                        '35.png',
                        '36.png',
                        '37.png',
                        '38.png',
                        '39.png',
                        '40.png',
                        '41.png',
                        '42.png',
                        '43.png',
                        '44.png'
                    ],
                    align_h: hmUI.align.LEFT,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    unit_sc: '60.png',
                    unit_tc: '60.png',
                    unit_en: '60.png',
                    invalid_image: '59.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                    x: 170,
                    y: 168,
                    image_array: [
                        '62.png',
                        '63.png',
                        '64.png',
                        '65.png',
                        '66.png',
                        '67.png',
                        '68.png',
                        '69.png',
                        '70.png',
                        '71.png',
                        '72.png',
                        '73.png',
                        '74.png',
                        '75.png',
                        '76.png',
                        '77.png',
                        '78.png',
                        '79.png',
                        '80.png',
                        '81.png',
                        '82.png',
                        '83.png',
                        '84.png',
                        '85.png',
                        '86.png',
                        '87.png',
                        '88.png',
                        '89.png',
                        '90.png'
                    ],
                    image_length: 29,
                    type: hmUI.data_type.WEATHER_CURRENT,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_DATE, {
                    month_startX: 216,
                    month_startY: 412,
                    month_sc_array: [
                        '103.png',
                        '104.png',
                        '105.png',
                        '106.png',
                        '107.png',
                        '108.png',
                        '109.png',
                        '110.png',
                        '111.png',
                        '112.png',
                        '113.png',
                        '114.png'
                    ],
                    month_tc_array: [
                        '115.png',
                        '116.png',
                        '117.png',
                        '118.png',
                        '119.png',
                        '120.png',
                        '121.png',
                        '122.png',
                        '123.png',
                        '124.png',
                        '125.png',
                        '126.png'
                    ],
                    month_en_array: [
                        '127.png',
                        '128.png',
                        '129.png',
                        '130.png',
                        '131.png',
                        '132.png',
                        '133.png',
                        '134.png',
                        '135.png',
                        '136.png',
                        '137.png',
                        '138.png'
                    ],
                    month_align: hmUI.align.LEFT,
                    month_zero: 0,
                    month_follow: 0,
                    month_space: 0,
                    month_is_character: true,
                    day_startX: 249,
                    day_startY: 175,
                    day_sc_array: [
                        '139.png',
                        '140.png',
                        '141.png',
                        '142.png',
                        '143.png',
                        '144.png',
                        '145.png',
                        '146.png',
                        '147.png',
                        '148.png'
                    ],
                    day_tc_array: [
                        '139.png',
                        '140.png',
                        '141.png',
                        '142.png',
                        '143.png',
                        '144.png',
                        '145.png',
                        '146.png',
                        '147.png',
                        '148.png'
                    ],
                    day_en_array: [
                        '139.png',
                        '140.png',
                        '141.png',
                        '142.png',
                        '143.png',
                        '144.png',
                        '145.png',
                        '146.png',
                        '147.png',
                        '148.png'
                    ],
                    day_align: hmUI.align.LEFT,
                    day_zero: 1,
                    day_follow: 0,
                    day_space: 2,
                    day_is_character: false,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_WEEK, {
                    x: 288,
                    y: 175,
                    week_en: [
                        '156.png',
                        '157.png',
                        '158.png',
                        '159.png',
                        '160.png',
                        '161.png',
                        '162.png'
                    ],
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 249,
                    y: 212,
                    type: hmUI.data_type.WEATHER_CURRENT,
                    font_array: [
                        '139.png',
                        '140.png',
                        '141.png',
                        '142.png',
                        '143.png',
                        '144.png',
                        '145.png',
                        '146.png',
                        '147.png',
                        '148.png'
                    ],
                    align_h: hmUI.align.LEFT,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    unit_sc: '165.png',
                    unit_tc: '165.png',
                    unit_en: '165.png',
                    negative_image: '164.png',
                    invalid_image: '163.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 347,
                    y: 212,
                    type: hmUI.data_type.WEATHER_HIGH,
                    font_array: [
                        '139.png',
                        '140.png',
                        '141.png',
                        '142.png',
                        '143.png',
                        '144.png',
                        '145.png',
                        '146.png',
                        '147.png',
                        '148.png'
                    ],
                    align_h: hmUI.align.LEFT,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    unit_sc: '168.png',
                    unit_tc: '168.png',
                    unit_en: '168.png',
                    negative_image: '167.png',
                    invalid_image: '166.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 291,
                    y: 212,
                    type: hmUI.data_type.WEATHER_LOW,
                    font_array: [
                        '139.png',
                        '140.png',
                        '141.png',
                        '142.png',
                        '143.png',
                        '144.png',
                        '145.png',
                        '146.png',
                        '147.png',
                        '148.png'
                    ],
                    align_h: hmUI.align.RIGHT,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    unit_sc: '171.png',
                    unit_tc: '171.png',
                    unit_en: '171.png',
                    negative_image: '170.png',
                    invalid_image: '169.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    hour_zero: 1,
                    hour_startX: 96,
                    hour_startY: 260,
                    hour_array: [
                        '173.png',
                        '174.png',
                        '175.png',
                        '176.png',
                        '177.png',
                        '178.png',
                        '179.png',
                        '180.png',
                        '181.png',
                        '182.png'
                    ],
                    hour_space: 8,
                    hour_unit_sc: '183.png',
                    hour_unit_tc: '183.png',
                    hour_unit_en: '183.png',
                    hour_align: hmUI.align.LEFT,
                    minute_zero: 1,
                    minute_startX: 251,
                    minute_startY: 260,
                    minute_array: [
                        '173.png',
                        '174.png',
                        '175.png',
                        '176.png',
                        '177.png',
                        '178.png',
                        '179.png',
                        '180.png',
                        '181.png',
                        '182.png'
                    ],
                    minute_space: 9,
                    minute_align: hmUI.align.LEFT,
                    minute_follow: 0,
                    second_zero: 1,
                    second_startX: 374,
                    second_startY: 308,
                    second_array: [
                        '184.png',
                        '185.png',
                        '186.png',
                        '187.png',
                        '188.png',
                        '189.png',
                        '190.png',
                        '191.png',
                        '192.png',
                        '193.png'
                    ],
                    second_space: 2,
                    second_align: hmUI.align.LEFT,
                    second_follow: 0,
                    am_x: 58,
                    am_y: 321,
                    am_en_path: '194.png',
                    pm_x: 58,
                    pm_y: 321,
                    pm_en_path: '195.png',
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                    second_centerX: 240,
                    second_centerY: 240,
                    second_posX: 13,
                    second_posY: 240,
                    second_path: '196.png',
                    second_cover_x: 0,
                    second_cover_y: 0,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 139,
                    y: 372,
                    type: hmUI.data_type.STEP,
                    font_array: [
                        '139.png',
                        '140.png',
                        '141.png',
                        '142.png',
                        '143.png',
                        '144.png',
                        '145.png',
                        '146.png',
                        '147.png',
                        '148.png'
                    ],
                    align_h: hmUI.align.LEFT,
                    h_space: 1,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    invalid_image: '197.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 248,
                    y: 372,
                    type: hmUI.data_type.CAL,
                    font_array: [
                        '139.png',
                        '140.png',
                        '141.png',
                        '142.png',
                        '143.png',
                        '144.png',
                        '145.png',
                        '146.png',
                        '147.png',
                        '148.png'
                    ],
                    align_h: hmUI.align.LEFT,
                    h_space: 1,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    invalid_image: '199.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 336,
                    y: 372,
                    type: hmUI.data_type.BATTERY,
                    font_array: [
                        '139.png',
                        '140.png',
                        '141.png',
                        '142.png',
                        '143.png',
                        '144.png',
                        '145.png',
                        '146.png',
                        '147.png',
                        '148.png'
                    ],
                    align_h: hmUI.align.LEFT,
                    h_space: 1,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    unit_sc: '202.png',
                    unit_tc: '202.png',
                    unit_en: '202.png',
                    invalid_image: '201.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 480,
                    h: 480,
                    src: '204.png',
                    show_level: hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    hour_zero: 1,
                    hour_startX: 96,
                    hour_startY: 260,
                    hour_array: [
                        '173.png',
                        '174.png',
                        '175.png',
                        '176.png',
                        '177.png',
                        '178.png',
                        '179.png',
                        '180.png',
                        '181.png',
                        '182.png'
                    ],
                    hour_space: 8,
                    hour_unit_sc: '183.png',
                    hour_unit_tc: '183.png',
                    hour_unit_en: '183.png',
                    hour_align: hmUI.align.LEFT,
                    minute_zero: 1,
                    minute_startX: 251,
                    minute_startY: 260,
                    minute_array: [
                        '173.png',
                        '174.png',
                        '175.png',
                        '176.png',
                        '177.png',
                        '178.png',
                        '179.png',
                        '180.png',
                        '181.png',
                        '182.png'
                    ],
                    minute_space: 9,
                    minute_align: hmUI.align.LEFT,
                    minute_follow: 0,
                    am_x: 58,
                    am_y: 321,
                    am_en_path: '194.png',
                    pm_x: 58,
                    pm_y: 321,
                    pm_en_path: '195.png',
                    enable: false,
                    show_level: hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 240,
                    y: 31,
                    w: 100,
                    h: 20,
                    src: '21.png',
                    type: hmUI.data_type.PAI_WEEKLY,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 240,
                    y: 50,
                    w: 100,
                    h: 20,
                    src: '28.png',
                    type: hmUI.data_type.UVI,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 240,
                    y: 75,
                    w: 100,
                    h: 20,
                    src: '46.png',
                    type: hmUI.data_type.AQI,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 240,
                    y: 98,
                    w: 100,
                    h: 20,
                    type: hmUI.data_type.HUMIDITY,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 240,
                    y: 120,
                    w: 100,
                    h: 20,
                    src: '61.png',
                    type: hmUI.data_type.HEART,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 175,
                    y: 170,
                    w: 214,
                    h: 70,
                    src: '172.png',
                    type: hmUI.data_type.WEATHER_CURRENT,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 90,
                    y: 351,
                    w: 110,
                    h: 80,
                    src: '198.png',
                    type: hmUI.data_type.STEP,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 200,
                    y: 348,
                    w: 100,
                    h: 80,
                    src: '200.png',
                    type: hmUI.data_type.CAL,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 302,
                    y: 354,
                    w: 90,
                    h: 60,
                    src: '203.png',
                    type: hmUI.data_type.BATTERY,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_calorie_icon_img = ''
        let normal_calorie_current_text_img = ''
        let normal_battery_icon_img = ''
        let normal_battery_text_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_step_icon_img = ''
        let normal_step_current_text_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_digital_clock_img_time = ''
        let normal_image_img = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let idle_background_bg_img = ''
        let idle_digital_clock_img_time = ''
        let idle_analog_clock_time_pointer_second = ''
        let image_top_img = ''
        let normal_step_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_fatBurning_jumpable_img_click = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: '0001.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 245,
              y: 373,
              src: 'COEUR.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 294,
              y: 380,
              font_array: ["MINI-00.png","MINI-01.png","MINI-02.png","MINI-03.png","MINI-04.png","MINI-05.png","MINI-06.png","MINI-07.png","MINI-08.png","MINI-09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 181,
              y: 368,
              src: 'CALORIE.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 100,
              y: 379,
              font_array: ["MINI-00.png","MINI-01.png","MINI-02.png","MINI-03.png","MINI-04.png","MINI-05.png","MINI-06.png","MINI-07.png","MINI-08.png","MINI-09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 172,
              y: 421,
              src: 'ENERGIE.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 207,
              y: 426,
              font_array: ["MINI-00.png","MINI-01.png","MINI-02.png","MINI-03.png","MINI-04.png","MINI-05.png","MINI-06.png","MINI-07.png","MINI-08.png","MINI-09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'POURCENT.png',
              unit_tc: 'POURCENT.png',
              unit_en: 'POURCENT.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 254,
              y: 331,
              font_array: ["MINI-00.png","MINI-01.png","MINI-02.png","MINI-03.png","MINI-04.png","MINI-05.png","MINI-06.png","MINI-07.png","MINI-08.png","MINI-09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'KM.png',
              unit_tc: 'KM.png',
              unit_en: 'KM.png',
              dot_image: 'POINT-1.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 215,
              y: 313,
              src: 'MARCHE.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 105,
              y: 331,
              font_array: ["MINI-00.png","MINI-01.png","MINI-02.png","MINI-03.png","MINI-04.png","MINI-05.png","MINI-06.png","MINI-07.png","MINI-08.png","MINI-09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 137,
              month_startY: 93,
              month_sc_array: ["MOIS-01.png","MOIS-02.png","MOIS-03.png","MOIS-04.png","MOIS-05.png","MOIS-06.png","MOIS-07.png","MOIS-08.png","MOIS-09.png","MOIS-10.png","MOIS-11.png","MOIS-12.png"],
              month_tc_array: ["MOIS-01.png","MOIS-02.png","MOIS-03.png","MOIS-04.png","MOIS-05.png","MOIS-06.png","MOIS-07.png","MOIS-08.png","MOIS-09.png","MOIS-10.png","MOIS-11.png","MOIS-12.png"],
              month_en_array: ["MOIS-01.png","MOIS-02.png","MOIS-03.png","MOIS-04.png","MOIS-05.png","MOIS-06.png","MOIS-07.png","MOIS-08.png","MOIS-09.png","MOIS-10.png","MOIS-11.png","MOIS-12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 85,
              day_startY: 85,
              day_sc_array: ["MOYEN-00.png","MOYEN-01.png","MOYEN-02.png","MOYEN-03.png","MOYEN-04.png","MOYEN-05.png","MOYEN-06.png","MOYEN-07.png","MOYEN-08.png","MOYEN-09.png"],
              day_tc_array: ["MOYEN-00.png","MOYEN-01.png","MOYEN-02.png","MOYEN-03.png","MOYEN-04.png","MOYEN-05.png","MOYEN-06.png","MOYEN-07.png","MOYEN-08.png","MOYEN-09.png"],
              day_en_array: ["MOYEN-00.png","MOYEN-01.png","MOYEN-02.png","MOYEN-03.png","MOYEN-04.png","MOYEN-05.png","MOYEN-06.png","MOYEN-07.png","MOYEN-08.png","MOYEN-09.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.RIGHT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 83,
              y: 122,
              week_en: ["SEM-01.png","SEM-02.png","SEM-03.png","SEM-04.png","SEM-05.png","SEM-06.png","SEM-07.png"],
              week_tc: ["SEM-01.png","SEM-02.png","SEM-03.png","SEM-04.png","SEM-05.png","SEM-06.png","SEM-07.png"],
              week_sc: ["SEM-01.png","SEM-02.png","SEM-03.png","SEM-04.png","SEM-05.png","SEM-06.png","SEM-07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 217,
              y: 18,
              image_array: ["METEO-01.png","METEO-02.png","METEO-03.png","METEO-04.png","METEO-05.png","METEO-06.png","METEO-07.png","METEO-08.png","METEO-09.png","METEO-10.png","METEO-11.png","METEO-12.png","METEO-13.png","METEO-14.png","METEO-15.png","METEO-16.png","METEO-17.png","METEO-18.png","METEO-19.png","METEO-20.png","METEO-21.png","METEO-22.png","METEO-23.png","METEO-24.png","METEO-25.png","METEO-26.png","METEO-27.png","METEO-28.png","METEO-29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 279,
              y: 67,
              font_array: ["MINI-00.png","MINI-01.png","MINI-02.png","MINI-03.png","MINI-04.png","MINI-05.png","MINI-06.png","MINI-07.png","MINI-08.png","MINI-09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'DEGRE.png',
              unit_tc: 'DEGRE.png',
              unit_en: 'DEGRE.png',
              negative_image: 'MOINS.png',
              invalid_image: '0060.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 27,
              hour_startY: 160,
              hour_array: ["H-00.png","H-01.png","H-02.png","H-03.png","H-04.png","H-05.png","H-06.png","H-07.png","H-08.png","H-09.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_unit_sc: 'G-10.png',
              hour_unit_tc: 'G-10.png',
              hour_unit_en: 'G-10.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 263,
              minute_startY: 160,
              minute_array: ["G-00.png","G-01.png","G-02.png","G-03.png","G-04.png","G-05.png","G-06.png","G-07.png","G-08.png","G-09.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 213,
              second_startY: 217,
              second_array: ["MINI-00.png","MINI-01.png","MINI-02.png","MINI-03.png","MINI-04.png","MINI-05.png","MINI-06.png","MINI-07.png","MINI-08.png","MINI-09.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 1,
              y: 4,
              src: 'AL BT.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'sec.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 240,
              second_posY: 240,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 359,
              y: 109,
              src: 'BT1.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 312,
              y: 112,
              src: 'ALARME1.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: '0001.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 27,
              hour_startY: 160,
              hour_array: ["H-00.png","H-01.png","H-02.png","H-03.png","H-04.png","H-05.png","H-06.png","H-07.png","H-08.png","H-09.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_unit_sc: 'G-10.png',
              hour_unit_tc: 'G-10.png',
              hour_unit_en: 'G-10.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 263,
              minute_startY: 160,
              minute_array: ["G-00.png","G-01.png","G-02.png","G-03.png","G-04.png","G-05.png","G-06.png","G-07.png","G-08.png","G-09.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 213,
              second_startY: 217,
              second_array: ["MINI-00.png","MINI-01.png","MINI-02.png","MINI-03.png","MINI-04.png","MINI-05.png","MINI-06.png","MINI-07.png","MINI-08.png","MINI-09.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'sec2.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 240,
              second_posY: 240,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            image_top_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'VERRE.png',
              show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 86,
              y: 318,
              w: 313,
              h: 48,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 245,
              y: 370,
              w: 125,
              h: 40,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 304,
              y: 103,
              w: 50,
              h: 50,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_fatBurning_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 90,
              y: 371,
              w: 143,
              h: 40,
              type: hmUI.data_type.FAT_BURNING,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_sun_high_text_font = ''
        let normal_sun_low_text_font = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_calorie_current_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_distance_icon_img = ''
        let normal_distance_text_text_img = ''
        let normal_step_icon_img = ''
        let normal_step_current_text_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_date_img_date_year = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_digital_clock_img_time = ''
        let idle_digital_clock_img_time = ''
        let normal_step_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_fatBurning_jumpable_img_click = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'fond01.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 101,
              y: 70,
              w: 150,
              h: 58,
              text_size: 25,
              char_space: 0,
              line_space: 0,
              color: 0xFFFAC905,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 101,
              y: 98,
              w: 150,
              h: 50,
              text_size: 24,
              char_space: 0,
              line_space: 0,
              color: 0xFFCC7DDF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 331,
              y: 414,
              src: 'BT.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 118,
              y: 417,
              src: 'Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 293,
              y: 304,
              font_array: ["Number-00.png","Number-01.png","Number-02.png","Number-03.png","Number-04.png","Number-05.png","Number-06.png","Number-07.png","Number-08.png","Number-09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 71,
              y: 304,
              font_array: ["Number-00.png","Number-01.png","Number-02.png","Number-03.png","Number-04.png","Number-05.png","Number-06.png","Number-07.png","Number-08.png","Number-09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 169,
              y: 0,
              image_array: ["Weather_01.png","Weather_02.png","Weather_03.png","Weather_04.png","Weather_05.png","Weather_06.png","Weather_07.png","Weather_08.png","Weather_09.png","Weather_10.png","Weather_11.png","Weather_12.png","Weather_13.png","Weather_14.png","Weather_15.png","Weather_16.png","Weather_17.png","Weather_18.png","Weather_19.png","Weather_20.png","Weather_21.png","Weather_22.png","Weather_23.png","Weather_24.png","Weather_25.png","Weather_26.png","Weather_27.png","Weather_28.png","Weather_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 305,
              y: 57,
              font_array: ["Number-00.png","Number-01.png","Number-02.png","Number-03.png","Number-04.png","Number-05.png","Number-06.png","Number-07.png","Number-08.png","Number-09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Number-....png',
              unit_tc: 'Number-....png',
              unit_en: 'Number-....png',
              negative_image: 'Number--.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 248,
              y: 129,
              src: 'KM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 291,
              y: 135,
              font_array: ["N-00.png","N-01.png","N-02.png","N-03.png","N-04.png","N-05.png","N-06.png","N-07.png","N-08.png","N-09.png"],
              padding: false,
              h_space: -1,
              dot_image: 'N-10.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 353,
              y: 126,
              src: 'marche.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 381,
              y: 135,
              font_array: ["N-00.png","N-01.png","N-02.png","N-03.png","N-04.png","N-05.png","N-06.png","N-07.png","N-08.png","N-09.png"],
              padding: false,
              h_space: -2,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 154,
              y: 133,
              font_array: ["Nu-00.png","Nu-01.png","Nu-02.png","Nu-03.png","Nu-04.png","Nu-05.png","Nu-06.png","Nu-07.png","Nu-08.png","Nu-09.png"],
              padding: false,
              h_space: -3,
              unit_sc: 'Nu%.png',
              unit_tc: 'Nu%.png',
              unit_en: 'Nu%.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 33,
              y: 136,
              image_array: ["BatV01).png","BatV02).png","BatV03).png","BatV04).png","BatV05).png","BatV06).png","BatV07).png","BatV08).png","BatV09).png","BatV10).png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 257,
              year_startY: 418,
              year_sc_array: ["Number-00.png","Number-01.png","Number-02.png","Number-03.png","Number-04.png","Number-05.png","Number-06.png","Number-07.png","Number-08.png","Number-09.png"],
              year_tc_array: ["Number-00.png","Number-01.png","Number-02.png","Number-03.png","Number-04.png","Number-05.png","Number-06.png","Number-07.png","Number-08.png","Number-09.png"],
              year_en_array: ["Number-00.png","Number-01.png","Number-02.png","Number-03.png","Number-04.png","Number-05.png","Number-06.png","Number-07.png","Number-08.png","Number-09.png"],
              year_zero: 1,
              year_space: 0,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 211,
              month_startY: 418,
              month_sc_array: ["Number-00.png","Number-01.png","Number-02.png","Number-03.png","Number-04.png","Number-05.png","Number-06.png","Number-07.png","Number-08.png","Number-09.png"],
              month_tc_array: ["Number-00.png","Number-01.png","Number-02.png","Number-03.png","Number-04.png","Number-05.png","Number-06.png","Number-07.png","Number-08.png","Number-09.png"],
              month_en_array: ["Number-00.png","Number-01.png","Number-02.png","Number-03.png","Number-04.png","Number-05.png","Number-06.png","Number-07.png","Number-08.png","Number-09.png"],
              month_zero: 1,
              month_space: 0,
              month_unit_sc: 'Number-10.png',
              month_unit_tc: 'Number-10.png',
              month_unit_en: 'Number-10.png',
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 163,
              day_startY: 418,
              day_sc_array: ["Number-00.png","Number-01.png","Number-02.png","Number-03.png","Number-04.png","Number-05.png","Number-06.png","Number-07.png","Number-08.png","Number-09.png"],
              day_tc_array: ["Number-00.png","Number-01.png","Number-02.png","Number-03.png","Number-04.png","Number-05.png","Number-06.png","Number-07.png","Number-08.png","Number-09.png"],
              day_en_array: ["Number-00.png","Number-01.png","Number-02.png","Number-03.png","Number-04.png","Number-05.png","Number-06.png","Number-07.png","Number-08.png","Number-09.png"],
              day_zero: 1,
              day_space: 0,
              day_unit_sc: 'Number-10.png',
              day_unit_tc: 'Number-10.png',
              day_unit_en: 'Number-10.png',
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 126,
              y: 360,
              week_en: ["sem-01.png","sem-02.png","sem-03.png","sem-04.png","sem-05.png","sem-06.png","sem-07.png"],
              week_tc: ["sem-01.png","sem-02.png","sem-03.png","sem-04.png","sem-05.png","sem-06.png","sem-07.png"],
              week_sc: ["sem-01.png","sem-02.png","sem-03.png","sem-04.png","sem-05.png","sem-06.png","sem-07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: -19,
              hour_startY: 175,
              hour_array: ["h00.png","h01.png","h02.png","h03.png","h04.png","h05.png","h06.png","h07.png","h08.png","h09.png"],
              hour_zero: 1,
              hour_space: -37,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 225,
              minute_startY: 175,
              minute_array: ["G00.png","G01.png","G02.png","G03.png","G04.png","G05.png","G06.png","G07.png","G08.png","G09.png"],
              minute_zero: 1,
              minute_space: -37,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 411,
              second_startY: 287,
              second_array: ["Number-00.png","Number-01.png","Number-02.png","Number-03.png","Number-04.png","Number-05.png","Number-06.png","Number-07.png","Number-08.png","Number-09.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 3,
              hour_startY: 167,
              hour_array: ["X00.png","X01.png","X02.png","X03.png","X04.png","X05.png","X06.png","X07.png","X08.png","X09.png"],
              hour_zero: 1,
              hour_space: -39,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 220,
              minute_startY: 169,
              minute_array: ["V00.png","V01.png","V02.png","V03.png","V04.png","V05.png","V06.png","V07.png","V08.png","V09.png"],
              minute_zero: 0,
              minute_space: -37,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 9,
              // disconneсnt_toast_text: BT OFF,
              // conneсnt_vibrate_type: 9,
              // conneсnt_toast_text: BT ON,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              console.log('checkConnection()');
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  hmUI.showToast({text: "BT OFF"});
                  vibro(9);
                }
                if(status) {
                  hmUI.showToast({text: "BT ON"});
                  vibro(9);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              if (scene != 1) timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 246,
              y: 133,
              w: 200,
              h: 30,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 23,
              y: 292,
              w: 100,
              h: 50,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 52,
              y: 77,
              w: 114,
              h: 53,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 173,
              y: 28,
              w: 193,
              h: 100,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 108,
              y: 414,
              w: 50,
              h: 50,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_fatBurning_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 256,
              y: 292,
              w: 100,
              h: 50,
              type: hmUI.data_type.FAT_BURNING,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                checkConnection();
                stopVibro();

              }),
              pause_call: (function () {
                console.log('pause_call()');
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
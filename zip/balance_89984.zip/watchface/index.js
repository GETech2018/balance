﻿    /*
    ** Watch_Face_Editor tool v 18.1
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg = ''
        let normal_image_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_text_separator_img = ''
        let normal_distance_text_text_img = ''
        let normal_distance_text_separator_img = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_sleep_icon_img = ''
        let normal_stand_current_text_img = ''
        let normal_stand_current_separator_img = ''
        let normal_temperature_icon_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_high_text_img = ''
        let normal_temperature_low_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_wind_icon_img = ''
        let normal_wind_direction_image_progress_img_level = ''
        let normal_wind_text_text_img = ''
        let normal_uvi_text_text_img = ''
        let normal_uvi_text_separator_img = ''
        let normal_sun_low_text_img = ''
        let normal_sun_high_text_img = ''
        let normal_digital_clock_img_time = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let idle_background_bg = ''
        let idle_image_img = ''
        let idle_heart_rate_text_text_img = ''
        let idle_heart_rate_text_separator_img = ''
        let idle_calorie_current_text_img = ''
        let idle_calorie_current_separator_img = ''
        let idle_calorie_image_progress_img_level = ''
        let idle_fat_burning_current_text_img = ''
        let idle_fat_burning_current_separator_img = ''
        let idle_spo2_text_text_img = ''
        let idle_spo2_text_separator_img = ''
        let idle_sleep_icon_img = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_week_img = ''
        let idle_pai_weekly_text_img = ''
        let idle_pai_weekly_separator_img = ''
        let idle_date_img_date_day = ''
        let idle_temperature_icon_img = ''
        let idle_temperature_high_text_img = ''
        let idle_temperature_low_text_img = ''
        let idle_temperature_current_text_img = ''
        let idle_moon_low_text_img = ''
        let idle_moon_high_text_img = ''
        let idle_moon_image_progress_img_level = ''
        let idle_humidity_text_text_img = ''
        let idle_humidity_text_separator_img = ''
        let idle_pressure_text_text_img = ''
        let idle_pressure_text_separator_img = ''
        let idle_digital_clock_img_time = ''
        let idle_second_TextRotate = new Array(2);
        let idle_second_TextRotate_ASCIIARRAY = new Array(10);
        let idle_second_TextRotate_img_width = 38;
        let idle_timerTextUpdate = undefined;
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFFFF0000',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'bg16.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 215,
              y: 420,
              font_array: ["05_M_0.png","05_M_1.png","05_M_2.png","05_M_3.png","05_M_4.png","05_M_5.png","05_M_6.png","05_M_7.png","05_M_8.png","05_M_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: '10_percent_M.png',
              unit_tc: '10_percent_M.png',
              unit_en: '10_percent_M.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 170,
              y: 420,
              src: '10_batt.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 250,
              y: 355,
              font_array: ["05_M_0.png","05_M_1.png","05_M_2.png","05_M_3.png","05_M_4.png","05_M_5.png","05_M_6.png","05_M_7.png","05_M_8.png","05_M_9.png"],
              padding: false,
              h_space: 0,
              dot_image: '10_dot.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 365,
              y: 350,
              src: '10_dist.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 260,
              y: 300,
              font_array: ["05_M_0.png","05_M_1.png","05_M_2.png","05_M_3.png","05_M_4.png","05_M_5.png","05_M_6.png","05_M_7.png","05_M_8.png","05_M_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 395,
              y: 295,
              src: '10_steps.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 45,
              y: 298,
              image_array: ["10_target_1.png","10_target_2.png","10_target_3.png","10_target_4.png","10_target_5.png","10_target_6.png"],
              image_length: 6,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 137,
              month_startY: 337,
              month_sc_array: ["A100_037.png","A100_038.png","A100_039.png","A100_040.png","A100_041.png","A100_042.png","A100_043.png","A100_044.png","A100_045.png","A100_046.png","A100_047.png","A100_048.png"],
              month_tc_array: ["A100_037.png","A100_038.png","A100_039.png","A100_040.png","A100_041.png","A100_042.png","A100_043.png","A100_044.png","A100_045.png","A100_046.png","A100_047.png","A100_048.png"],
              month_en_array: ["A100_037.png","A100_038.png","A100_039.png","A100_040.png","A100_041.png","A100_042.png","A100_043.png","A100_044.png","A100_045.png","A100_046.png","A100_047.png","A100_048.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 130,
              y: 374,
              week_en: ["A100_029_(1).png","A100_030_(1).png","A100_031_(1).png","A100_032_(1).png","A100_033_(1).png","A100_034_(1).png","A100_035_(1).png"],
              week_tc: ["A100_029_(1).png","A100_030_(1).png","A100_031_(1).png","A100_032_(1).png","A100_033_(1).png","A100_034_(1).png","A100_035_(1).png"],
              week_sc: ["A100_029_(1).png","A100_030_(1).png","A100_031_(1).png","A100_032_(1).png","A100_033_(1).png","A100_034_(1).png","A100_035_(1).png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 60,
              day_startY: 338,
              day_sc_array: ["04_L_0.png","04_L_1.png","04_L_2.png","04_L_3.png","04_L_4.png","04_L_5.png","04_L_6.png","04_L_7.png","04_L_8.png","04_L_9.png"],
              day_tc_array: ["04_L_0.png","04_L_1.png","04_L_2.png","04_L_3.png","04_L_4.png","04_L_5.png","04_L_6.png","04_L_7.png","04_L_8.png","04_L_9.png"],
              day_en_array: ["04_L_0.png","04_L_1.png","04_L_2.png","04_L_3.png","04_L_4.png","04_L_5.png","04_L_6.png","04_L_7.png","04_L_8.png","04_L_9.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.RIGHT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sleep_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: -6,
              y: -15,
              src: '01_bg_cover_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 355,
              y: 254,
              font_array: ["05_M_0.png","05_M_1.png","05_M_2.png","05_M_3.png","05_M_4.png","05_M_5.png","05_M_6.png","05_M_7.png","05_M_8.png","05_M_9.png"],
              padding: true,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STAND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 435,
              y: 247,
              src: '10_stand.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: -6,
              y: -15,
              src: '00_top_cover.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 215,
              y: 80,
              image_array: ["09_forecast_01.png","09_forecast_02.png","09_forecast_03.png","09_forecast_04.png","09_forecast_05.png","09_forecast_06.png","09_forecast_07.png","09_forecast_08.png","09_forecast_09.png","09_forecast_10.png","09_forecast_11.png","09_forecast_12.png","09_forecast_13.png","09_forecast_14.png","09_forecast_15.png","09_forecast_16.png","09_forecast_17.png","09_forecast_18.png","09_forecast_19.png","09_forecast_20.png","09_forecast_21.png","09_forecast_22.png","09_forecast_23.png","09_forecast_24.png","09_forecast_25.png","09_forecast_26.png","09_forecast_27.png","09_forecast_28.png","09_forecast_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 300,
              y: 50,
              font_array: ["06_S_0.png","06_S_1.png","06_S_2.png","06_S_3.png","06_S_4.png","06_S_5.png","06_S_6.png","06_S_7.png","06_S_8.png","06_S_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: '10_degree_S.png',
              unit_tc: '10_degree_S.png',
              unit_en: '10_degree_S.png',
              negative_image: '10_dash_S.png',
              invalid_image: '10_dash_S.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 110,
              y: 50,
              font_array: ["06_S_0.png","06_S_1.png","06_S_2.png","06_S_3.png","06_S_4.png","06_S_5.png","06_S_6.png","06_S_7.png","06_S_8.png","06_S_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: '10_degree_S.png',
              unit_tc: '10_degree_S.png',
              unit_en: '10_degree_S.png',
              negative_image: '10_dash_S.png',
              invalid_image: '10_dash_S.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 197,
              y: 30,
              font_array: ["05_M_0.png","05_M_1.png","05_M_2.png","05_M_3.png","05_M_4.png","05_M_5.png","05_M_6.png","05_M_7.png","05_M_8.png","05_M_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: '10_degree_L.png',
              unit_tc: '10_degree_L.png',
              unit_en: '10_degree_L.png',
              negative_image: '10_dash_L.png',
              invalid_image: '10_dash_L.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 405,
              y: 136,
              src: '10_wind.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_direction_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 355,
              y: 145,
              image_array: ["wind_0.png","wind_1.png","wind_2.png","wind_3.png","wind_4.png","wind_5.png","wind_6.png","wind_7.png"],
              image_length: 8,
              type: hmUI.data_type.WIND_DIRECTION,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 295,
              y: 142,
              font_array: ["05_M_0.png","05_M_1.png","05_M_2.png","05_M_3.png","05_M_4.png","05_M_5.png","05_M_6.png","05_M_7.png","05_M_8.png","05_M_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WIND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_uvi_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 110,
              y: 142,
              font_array: ["05_M_0.png","05_M_1.png","05_M_2.png","05_M_3.png","05_M_4.png","05_M_5.png","05_M_6.png","05_M_7.png","05_M_8.png","05_M_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.UVI,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_uvi_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 60,
              y: 138,
              src: '10_uv.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 320,
              y: 95,
              font_array: ["06_S_0.png","06_S_1.png","06_S_2.png","06_S_3.png","06_S_4.png","06_S_5.png","06_S_6.png","06_S_7.png","06_S_8.png","06_S_9.png"],
              padding: false,
              h_space: 0,
              dot_image: '10_separator_S.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 75,
              y: 95,
              font_array: ["06_S_0.png","06_S_1.png","06_S_2.png","06_S_3.png","06_S_4.png","06_S_5.png","06_S_6.png","06_S_7.png","06_S_8.png","06_S_9.png"],
              padding: false,
              h_space: 0,
              dot_image: '10_separator_S.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 40,
              hour_startY: 193,
              hour_array: ["02_hhmm_0.png","02_hhmm_1.png","02_hhmm_2.png","02_hhmm_3.png","02_hhmm_4.png","02_hhmm_5.png","02_hhmm_6.png","02_hhmm_7.png","02_hhmm_8.png","02_hhmm_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_unit_sc: '10_sep_hhmm.png',
              hour_unit_tc: '10_sep_hhmm.png',
              hour_unit_en: '10_sep_hhmm.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 0,
              minute_startY: 0,
              minute_array: ["02_hhmm_0.png","02_hhmm_1.png","02_hhmm_2.png","02_hhmm_3.png","02_hhmm_4.png","02_hhmm_5.png","02_hhmm_6.png","02_hhmm_7.png","02_hhmm_8.png","02_hhmm_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 1,
              minute_align: hmUI.align.LEFT,

              second_startX: 366,
              second_startY: 193,
              second_array: ["03_ss_0.png","03_ss_1.png","03_ss_2.png","03_ss_3.png","03_ss_4.png","03_ss_5.png","03_ss_6.png","03_ss_7.png","03_ss_8.png","03_ss_9.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 178,
              y: 160,
              src: '0500.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 221,
              y: 337,
              src: '10_AL_ON.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFFFF8000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'bg16.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 275,
              y: 355,
              font_array: ["05_M_0.png","05_M_1.png","05_M_2.png","05_M_3.png","05_M_4.png","05_M_5.png","05_M_6.png","05_M_7.png","05_M_8.png","05_M_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 365,
              y: 352,
              src: '10_bpm.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 275,
              y: 300,
              font_array: ["05_M_0.png","05_M_1.png","05_M_2.png","05_M_3.png","05_M_4.png","05_M_5.png","05_M_6.png","05_M_7.png","05_M_8.png","05_M_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 390,
              y: 295,
              src: '10_cal.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 45,
              y: 298,
              image_array: ["10_target_1.png","10_target_2.png","10_target_3.png","10_target_4.png","10_target_5.png","10_target_6.png"],
              image_length: 6,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_fat_burning_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 155,
              y: 415,
              font_array: ["06_S_0.png","06_S_1.png","06_S_2.png","06_S_3.png","06_S_4.png","06_S_5.png","06_S_6.png","06_S_7.png","06_S_8.png","06_S_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.FAT_BURNING,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_fat_burning_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 110,
              y: 410,
              src: '10_fat_burn.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_spo2_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 240,
              y: 415,
              font_array: ["06_S_0.png","06_S_1.png","06_S_2.png","06_S_3.png","06_S_4.png","06_S_5.png","06_S_6.png","06_S_7.png","06_S_8.png","06_S_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: '10_percent_S.png',
              unit_tc: '10_percent_S.png',
              unit_en: '10_percent_S.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_spo2_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 335,
              y: 406,
              src: '10_spo2.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_sleep_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: -5,
              y: -15,
              src: '01_bg_cover_4.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 137,
              month_startY: 337,
              month_sc_array: ["A100_037.png","A100_038.png","A100_039.png","A100_040.png","A100_041.png","A100_042.png","A100_043.png","A100_044.png","A100_045.png","A100_046.png","A100_047.png","A100_048.png"],
              month_tc_array: ["A100_037.png","A100_038.png","A100_039.png","A100_040.png","A100_041.png","A100_042.png","A100_043.png","A100_044.png","A100_045.png","A100_046.png","A100_047.png","A100_048.png"],
              month_en_array: ["A100_037.png","A100_038.png","A100_039.png","A100_040.png","A100_041.png","A100_042.png","A100_043.png","A100_044.png","A100_045.png","A100_046.png","A100_047.png","A100_048.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 130,
              y: 374,
              week_en: ["A100_029_(1).png","A100_030_(1).png","A100_031_(1).png","A100_032_(1).png","A100_033_(1).png","A100_034_(1).png","A100_035_(1).png"],
              week_tc: ["A100_029_(1).png","A100_030_(1).png","A100_031_(1).png","A100_032_(1).png","A100_033_(1).png","A100_034_(1).png","A100_035_(1).png"],
              week_sc: ["A100_029_(1).png","A100_030_(1).png","A100_031_(1).png","A100_032_(1).png","A100_033_(1).png","A100_034_(1).png","A100_035_(1).png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_pai_weekly_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 364,
              y: 260,
              font_array: ["06_S_0.png","06_S_1.png","06_S_2.png","06_S_3.png","06_S_4.png","06_S_5.png","06_S_6.png","06_S_7.png","06_S_8.png","06_S_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_pai_weekly_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 434,
              y: 253,
              src: '10_PAI.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 60,
              day_startY: 338,
              day_sc_array: ["04_L_0.png","04_L_1.png","04_L_2.png","04_L_3.png","04_L_4.png","04_L_5.png","04_L_6.png","04_L_7.png","04_L_8.png","04_L_9.png"],
              day_tc_array: ["04_L_0.png","04_L_1.png","04_L_2.png","04_L_3.png","04_L_4.png","04_L_5.png","04_L_6.png","04_L_7.png","04_L_8.png","04_L_9.png"],
              day_en_array: ["04_L_0.png","04_L_1.png","04_L_2.png","04_L_3.png","04_L_4.png","04_L_5.png","04_L_6.png","04_L_7.png","04_L_8.png","04_L_9.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.RIGHT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: -6,
              y: -15,
              src: '00_top_cover.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 300,
              y: 50,
              font_array: ["06_S_0.png","06_S_1.png","06_S_2.png","06_S_3.png","06_S_4.png","06_S_5.png","06_S_6.png","06_S_7.png","06_S_8.png","06_S_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: '10_degree_S.png',
              unit_tc: '10_degree_S.png',
              unit_en: '10_degree_S.png',
              negative_image: '10_dash_S.png',
              invalid_image: '10_dash_S.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 110,
              y: 50,
              font_array: ["06_S_0.png","06_S_1.png","06_S_2.png","06_S_3.png","06_S_4.png","06_S_5.png","06_S_6.png","06_S_7.png","06_S_8.png","06_S_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: '10_degree_S.png',
              unit_tc: '10_degree_S.png',
              unit_en: '10_degree_S.png',
              negative_image: '10_dash_S.png',
              invalid_image: '10_dash_S.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 197,
              y: 30,
              font_array: ["05_M_0.png","05_M_1.png","05_M_2.png","05_M_3.png","05_M_4.png","05_M_5.png","05_M_6.png","05_M_7.png","05_M_8.png","05_M_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: '10_degree_L.png',
              unit_tc: '10_degree_L.png',
              unit_en: '10_degree_L.png',
              negative_image: '10_dash_L.png',
              invalid_image: '10_dash_L.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_moon_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 320,
              y: 95,
              font_array: ["06_S_0.png","06_S_1.png","06_S_2.png","06_S_3.png","06_S_4.png","06_S_5.png","06_S_6.png","06_S_7.png","06_S_8.png","06_S_9.png"],
              padding: false,
              h_space: 0,
              dot_image: '10_separator_S.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.MOON_SET,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_moon_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 75,
              y: 95,
              font_array: ["06_S_0.png","06_S_1.png","06_S_2.png","06_S_3.png","06_S_4.png","06_S_5.png","06_S_6.png","06_S_7.png","06_S_8.png","06_S_9.png"],
              padding: false,
              h_space: 0,
              dot_image: '10_separator_S.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.MOON_RISE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 206,
              y: 72,
              image_array: ["12_moon_01.png","12_moon_02.png","12_moon_03.png","12_moon_04.png","12_moon_05.png","12_moon_06.png","12_moon_07.png","12_moon_08.png","12_moon_09.png","12_moon_10.png","12_moon_11.png","12_moon_12.png","12_moon_13.png","12_moon_14.png","12_moon_15.png","12_moon_16.png","12_moon_17.png","12_moon_18.png","12_moon_19.png","12_moon_20.png","12_moon_21.png","12_moon_22.png","12_moon_23.png","12_moon_24.png","12_moon_25.png","12_moon_26.png","12_moon_27.png","12_moon_28.png","12_moon_29.png","12_moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 100,
              y: 142,
              font_array: ["05_M_0.png","05_M_1.png","05_M_2.png","05_M_3.png","05_M_4.png","05_M_5.png","05_M_6.png","05_M_7.png","05_M_8.png","05_M_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: '10_percent_M.png',
              unit_tc: '10_percent_M.png',
              unit_en: '10_percent_M.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_humidity_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 49,
              y: 139,
              src: '10_hum.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_pressure_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 280,
              y: 142,
              font_array: ["05_M_0.png","05_M_1.png","05_M_2.png","05_M_3.png","05_M_4.png","05_M_5.png","05_M_6.png","05_M_7.png","05_M_8.png","05_M_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.BARO,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            const baroSensor = hmSensor.createSensor(hmSensor.id.BARO);

            idle_pressure_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 395,
              y: 141,
              src: '10_baro.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 40,
              hour_startY: 193,
              hour_array: ["02_hhmm_0.png","02_hhmm_1.png","02_hhmm_2.png","02_hhmm_3.png","02_hhmm_4.png","02_hhmm_5.png","02_hhmm_6.png","02_hhmm_7.png","02_hhmm_8.png","02_hhmm_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_unit_sc: '10_sep_hhmm.png',
              hour_unit_tc: '10_sep_hhmm.png',
              hour_unit_en: '10_sep_hhmm.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 0,
              minute_startY: 0,
              minute_array: ["02_hhmm_0.png","02_hhmm_1.png","02_hhmm_2.png","02_hhmm_3.png","02_hhmm_4.png","02_hhmm_5.png","02_hhmm_6.png","02_hhmm_7.png","02_hhmm_8.png","02_hhmm_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 1,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_second_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 366,
              // y: 193,
              // font_array: ["03_ss_0.png","03_ss_1.png","03_ss_2.png","03_ss_3.png","03_ss_4.png","03_ss_5.png","03_ss_6.png","03_ss_7.png","03_ss_8.png","03_ss_9.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: 0,
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.SECOND,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_second_TextRotate_ASCIIARRAY[0] = '03_ss_0.png';  // set of images with numbers
            idle_second_TextRotate_ASCIIARRAY[1] = '03_ss_1.png';  // set of images with numbers
            idle_second_TextRotate_ASCIIARRAY[2] = '03_ss_2.png';  // set of images with numbers
            idle_second_TextRotate_ASCIIARRAY[3] = '03_ss_3.png';  // set of images with numbers
            idle_second_TextRotate_ASCIIARRAY[4] = '03_ss_4.png';  // set of images with numbers
            idle_second_TextRotate_ASCIIARRAY[5] = '03_ss_5.png';  // set of images with numbers
            idle_second_TextRotate_ASCIIARRAY[6] = '03_ss_6.png';  // set of images with numbers
            idle_second_TextRotate_ASCIIARRAY[7] = '03_ss_7.png';  // set of images with numbers
            idle_second_TextRotate_ASCIIARRAY[8] = '03_ss_8.png';  // set of images with numbers
            idle_second_TextRotate_ASCIIARRAY[9] = '03_ss_9.png';  // set of images with numbers

            //#region TextRotate
            for (let i = 0; i < 2; i++) {
              idle_second_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 366,
                center_y: 193,
                pos_x: 366,
                pos_y: 193,
                angle: 0,
                src: '03_ss_0.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_second_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //#endregion

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            let screenType = hmSetting.getScreenType();
            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 178,
              y: 160,
              src: '0500.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 221,
              y: 337,
              src: '10_AL_ON.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            //#region text_update
            function text_update() {
              console.log('text_update()');
              // Pressure Number
              let pressureValue = baroSensor.pressure;
              let idle_pressure_text = '-';
              if (pressureValue) idle_pressure_text = Math.round(pressureValue * 0.75006375541921).toString();
              idle_pressure_text_text_img.setProperty(hmUI.prop.TEXT, idle_pressure_text);

              console.log('update text rotate second_TIME');
              let valueSecond = timeSensor.second;
              let idle_second_rotate_string = parseInt(valueSecond).toString();
              idle_second_rotate_string = idle_second_rotate_string.padStart(2, '0');

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  idle_second_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueSecond != null && valueSecond != undefined && isFinite(valueSecond) && idle_second_rotate_string.length > 0 && idle_second_rotate_string.length <= 2) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of idle_second_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_second_TextRotate[index].setProperty(hmUI.prop.POS_X, 366 + img_offset);
                      idle_second_TextRotate[index].setProperty(hmUI.prop.SRC, idle_second_TextRotate_ASCIIARRAY[charCode]);
                      idle_second_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_second_TextRotate_img_width;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

            };

            //#endregion
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                text_update();
                if (screenType == hmSetting.screen_type.AOD) {
                  if (!idle_timerTextUpdate) {
                    idle_timerTextUpdate = timer.createTimer(0, 1000, (function (option) {
                      text_update();
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (idle_timerTextUpdate) {
                  timer.stopTimer(idle_timerTextUpdate);
                  idle_timerTextUpdate = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
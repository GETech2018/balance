import * as hmUI from '@zos/ui'
import { Step } from '@zos/sensor'

// Diseño original en 454 px, escalado x1,057 para los 480 px del Balance
const HM = ['DigHM00.png','DigHM01.png','DigHM02.png','DigHM03.png','DigHM04.png',
            'DigHM05.png','DigHM06.png','DigHM07.png','DigHM08.png','DigHM09.png']
const SS = ['DigS00.png','DigS01.png','DigS02.png','DigS03.png','DigS04.png',
            'DigS05.png','DigS06.png','DigS07.png','DigS08.png','DigS09.png']
const WEEK = ['Week01.png','Week02.png','Week03.png','Week04.png','Week05.png','Week06.png','Week07.png']

const NORMAL = hmUI.show_level.ONLY_NORMAL

WatchFace({
  build() {
    // ---------- Fondo ----------
    hmUI.createWidget(hmUI.widget.IMG, {
      x: 0, y: 0, w: 480, h: 480,
      src: 'Esfera_SK3.png',
      show_level: NORMAL
    })

    // ---------- Anillo de pasos (arco negro que descubre las marcas) ----------
    const stepArc = hmUI.createWidget(hmUI.widget.ARC, { show_level: NORMAL })
    const step = new Step()

    function updateSteps() {
      const target = step.getTarget()
      let progress = target > 0 ? step.getCurrent() / target : 0
      if (progress > 1) progress = 1
      const remaining = 1 - progress

      const startAngle = 267
      const endAngle = -93
      const centerX = 240
      const centerY = 239
      const radius = 237
      const drawEnd = startAngle + (endAngle - startAngle) * remaining

      stepArc.setProperty(hmUI.prop.MORE, {
        x: centerX - radius,
        y: centerY - radius,
        w: radius * 2,
        h: radius * 2,
        start_angle: startAngle,
        end_angle: drawEnd,
        color: 0x000000,
        line_width: 42
      })
    }
    updateSteps()
    step.onChange(updateSteps)

    // ---------- Fecha ----------
    hmUI.createWidget(hmUI.widget.IMG_DATE, {
      month_startX: 120, month_startY: 324,
      month_sc_array: SS, month_tc_array: SS, month_en_array: SS,
      month_zero: 0, month_space: -4,
      month_unit_sc: 'Icon-M.png', month_unit_tc: 'Icon-M.png', month_unit_en: 'Icon-M.png',
      month_align: hmUI.align.RIGHT,
      month_is_character: false,
      show_level: NORMAL
    })
    hmUI.createWidget(hmUI.widget.IMG_DATE, {
      day_startX: 251, day_startY: 324,
      day_sc_array: SS, day_tc_array: SS, day_en_array: SS,
      day_zero: 0, day_space: -6,
      day_unit_sc: 'Icon-D.png', day_unit_tc: 'Icon-D.png', day_unit_en: 'Icon-D.png',
      day_align: hmUI.align.LEFT,
      day_is_character: false,
      show_level: NORMAL
    })

    // ---------- Día de la semana ----------
    hmUI.createWidget(hmUI.widget.IMG_WEEK, {
      x: 143, y: 76,
      week_en: WEEK, week_tc: WEEK, week_sc: WEEK,
      show_level: NORMAL
    })

    // ---------- Hora digital ----------
    hmUI.createWidget(hmUI.widget.IMG_TIME, {
      am_x: 0, am_y: 0, am_sc_path: 'PMw000.png', am_en_path: 'PMw000.png',
      pm_x: 66, pm_y: 170, pm_sc_path: 'PMw000.png', pm_en_path: 'PMw000.png',
      show_level: NORMAL
    })
    hmUI.createWidget(hmUI.widget.IMG_TIME, {
      hour_startX: 75, hour_startY: 197,
      hour_array: HM, hour_zero: 0, hour_space: -6, hour_align: hmUI.align.RIGHT,

      minute_startX: 212, minute_startY: 196,
      minute_array: HM, minute_zero: 1, minute_space: -6, minute_follow: 0, minute_align: hmUI.align.LEFT,

      second_startX: 340, second_startY: 241,
      second_array: SS, second_zero: 1, second_space: -10, second_follow: 0, second_align: hmUI.align.LEFT,

      show_level: NORMAL
    })

    // ---------- Acceso al temporizador ----------
    hmUI.createWidget(hmUI.widget.IMG_CLICK, {
      x: 337, y: 200, w: 92, h: 53,
      src: 'TIMER.png',
      type: hmUI.data_type.COUNT_DOWN,
      show_level: NORMAL
    })

    // Actualiza el anillo al volver a la esfera
    hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
      resume_call: () => { updateSteps() }
    })
  }
})

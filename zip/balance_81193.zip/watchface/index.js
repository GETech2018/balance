﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_battery_linear_scale = ''
        let normal_battery_text_text_img = ''
        let normal_battery_text_separator_img = ''
        let normal_step_linear_scale = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_calorie_linear_scale = ''
        let normal_calorie_current_text_img = ''
        let normal_calorie_current_separator_img = ''
        let normal_temperature_current_text_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg_img = ''
        let idle_calorie_current_text_img = ''
        let idle_calorie_current_separator_img = ''
        let idle_step_current_text_img = ''
        let idle_step_current_separator_img = ''
        let idle_battery_text_text_img = ''
        let idle_battery_text_separator_img = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let image_top_img = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            if (screenType != hmSetting.screen_type.AOD) {
              normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 241,
              // start_y: 475,
              // color: 0xFF9B59B6,
              // lenght: -470,
              // line_width: 8,
              // line_cap: Rounded,
              // vertical: True,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 330,
              y: 296,
              font_array: ["sml_dark_00.png","sml_dark_01.png","sml_dark_02.png","sml_dark_03.png","sml_dark_04.png","sml_dark_05.png","sml_dark_06.png","sml_dark_07.png","sml_dark_08.png","sml_dark_09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'sml_dark_pctg.png',
              unit_tc: 'sml_dark_pctg.png',
              unit_en: 'sml_dark_pctg.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 290,
              y: 299,
              src: 'battery.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (screenType != hmSetting.screen_type.AOD) {
              normal_step_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // normal_step_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 255,
              // start_y: 475,
              // color: 0xFF27AE60,
              // lenght: -470,
              // line_width: 8,
              // line_cap: Rounded,
              // vertical: True,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 330,
              y: 219,
              font_array: ["sml_dark_00.png","sml_dark_01.png","sml_dark_02.png","sml_dark_03.png","sml_dark_04.png","sml_dark_05.png","sml_dark_06.png","sml_dark_07.png","sml_dark_08.png","sml_dark_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 290,
              y: 222,
              src: 'steps.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (screenType != hmSetting.screen_type.AOD) {
              normal_calorie_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // normal_calorie_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 269,
              // start_y: 475,
              // color: 0xFFE67E22,
              // lenght: -470,
              // line_width: 8,
              // line_cap: Rounded,
              // vertical: True,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const calorie = hmSensor.createSensor(hmSensor.id.CALORIE);
            calorie.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 330,
              y: 142,
              font_array: ["sml_dark_00.png","sml_dark_01.png","sml_dark_02.png","sml_dark_03.png","sml_dark_04.png","sml_dark_05.png","sml_dark_06.png","sml_dark_07.png","sml_dark_08.png","sml_dark_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 290,
              y: 145,
              src: 'calories.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 164,
              y: 414,
              font_array: ["sml_lght_00.png","sml_lght_01.png","sml_lght_02.png","sml_lght_03.png","sml_lght_04.png","sml_lght_05.png","sml_lght_06.png","sml_lght_07.png","sml_lght_08.png","sml_lght_09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'sml_lght_degree.png',
              unit_tc: 'sml_lght_degree.png',
              unit_en: 'sml_lght_degree.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 163,
              y: 366,
              week_en: ["wday01.png","wday02.png","wday03.png","wday04.png","wday05.png","wday06.png","wday07.png"],
              week_tc: ["wday01.png","wday02.png","wday03.png","wday04.png","wday05.png","wday06.png","wday07.png"],
              week_sc: ["wday01.png","wday02.png","wday03.png","wday04.png","wday05.png","wday06.png","wday07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 169,
              month_startY: 80,
              month_sc_array: ["mnth01.png","mnth02.png","mnth03.png","mnth04.png","mnth05.png","mnth06.png","mnth07.png","mnth08.png","mnth09.png","mnth10.png","mnth11.png","mnth12.png"],
              month_tc_array: ["mnth01.png","mnth02.png","mnth03.png","mnth04.png","mnth05.png","mnth06.png","mnth07.png","mnth08.png","mnth09.png","mnth10.png","mnth11.png","mnth12.png"],
              month_en_array: ["mnth01.png","mnth02.png","mnth03.png","mnth04.png","mnth05.png","mnth06.png","mnth07.png","mnth08.png","mnth09.png","mnth10.png","mnth11.png","mnth12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 196,
              day_startY: 32,
              day_sc_array: ["sml_lght_00.png","sml_lght_01.png","sml_lght_02.png","sml_lght_03.png","sml_lght_04.png","sml_lght_05.png","sml_lght_06.png","sml_lght_07.png","sml_lght_08.png","sml_lght_09.png"],
              day_tc_array: ["sml_lght_00.png","sml_lght_01.png","sml_lght_02.png","sml_lght_03.png","sml_lght_04.png","sml_lght_05.png","sml_lght_06.png","sml_lght_07.png","sml_lght_08.png","sml_lght_09.png"],
              day_en_array: ["sml_lght_00.png","sml_lght_01.png","sml_lght_02.png","sml_lght_03.png","sml_lght_04.png","sml_lght_05.png","sml_lght_06.png","sml_lght_07.png","sml_lght_08.png","sml_lght_09.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.RIGHT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 64,
              am_y: 223,
              am_sc_path: 'am.png',
              am_en_path: 'am.png',
              pm_x: 64,
              pm_y: 223,
              pm_sc_path: 'pm.png',
              pm_en_path: 'pm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 110,
              hour_startY: 119,
              hour_array: ["big00.png","big01.png","big02.png","big03.png","big04.png","big05.png","big06.png","big07.png","big08.png","big09.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 110,
              minute_startY: 243,
              minute_array: ["big00.png","big01.png","big02.png","big03.png","big04.png","big05.png","big06.png","big07.png","big08.png","big09.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg_aod.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 330,
              y: 142,
              font_array: ["sml_med_00.png","sml_med_01.png","sml_med_02.png","sml_med_03.png","sml_med_04.png","sml_med_05.png","sml_med_06.png","sml_med_07.png","sml_med_08.png","sml_med_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 290,
              y: 145,
              src: 'calories_aod.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 330,
              y: 219,
              font_array: ["sml_med_00.png","sml_med_01.png","sml_med_02.png","sml_med_03.png","sml_med_04.png","sml_med_05.png","sml_med_06.png","sml_med_07.png","sml_med_08.png","sml_med_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 290,
              y: 222,
              src: 'steps_aod.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 330,
              y: 296,
              font_array: ["sml_med_00.png","sml_med_01.png","sml_med_02.png","sml_med_03.png","sml_med_04.png","sml_med_05.png","sml_med_06.png","sml_med_07.png","sml_med_08.png","sml_med_09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'sml_med_pctg.png',
              unit_tc: 'sml_med_pctg.png',
              unit_en: 'sml_med_pctg.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 290,
              y: 299,
              src: 'battery_aod.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 64,
              am_y: 223,
              am_sc_path: 'am.png',
              am_en_path: 'am.png',
              pm_x: 64,
              pm_y: 223,
              pm_sc_path: 'pm.png',
              pm_en_path: 'pm.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 110,
              hour_startY: 119,
              hour_array: ["bigaod00.png","bigaod01.png","bigaod02.png","bigaod03.png","bigaod04.png","bigaod05.png","bigaod06.png","bigaod07.png","bigaod08.png","bigaod09.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 110,
              minute_startY: 243,
              minute_array: ["bigaod00.png","bigaod01.png","bigaod02.png","bigaod03.png","bigaod04.png","bigaod05.png","bigaod06.png","bigaod07.png","bigaod08.png","bigaod09.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            image_top_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'top.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            console.log('Watch_Face.Shortcuts');

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 110,
              y: 243,
              w: 123,
              h: 120,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 110,
              y: 118,
              w: 123,
              h: 120,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 290,
              y: 140,
              w: 150,
              h: 46,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 290,
              y: 217,
              w: 150,
              h: 46,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 168,
              y: 365,
              w: 65,
              h: 86,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'spacer.png',
              normal_src: 'spacer.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'WeatherScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 290,
              y: 369,
              w: 60,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'apps.png',
              normal_src: 'apps.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'DragListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 290,
              y: 52,
              w: 60,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'audio-phone.png',
              normal_src: 'audio-phone.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PhoneMusicCtrlScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 168,
              y: 29,
              w: 65,
              h: 87,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'spacer.png',
              normal_src: 'spacer.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 290,
              y: 294,
              w: 150,
              h: 46,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'spacer.png',
              normal_src: 'spacer.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'Settings_batteryManagerScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            function scale_call() {
              console.log('scale_call()');

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_ls_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_linear_scale
                  // initial parameters
                  let start_x_normal_battery = 241;
                  let start_y_normal_battery = 475;
                  let lenght_ls_normal_battery = -470;
                  let line_width_ls_normal_battery = 8;
                  let color_ls_normal_battery = 0xFF9B59B6;
                  
                  // calculated parameters
                  let start_x_normal_battery_draw = start_x_normal_battery;
                  let start_y_normal_battery_draw = start_y_normal_battery;
                  lenght_ls_normal_battery = lenght_ls_normal_battery * progress_ls_normal_battery;
                  let lenght_ls_normal_battery_draw = line_width_ls_normal_battery;
                  let line_width_ls_normal_battery_draw = lenght_ls_normal_battery;
                  if (lenght_ls_normal_battery < 0){
                    line_width_ls_normal_battery_draw = -lenght_ls_normal_battery;
                    start_y_normal_battery_draw = start_y_normal_battery_draw - line_width_ls_normal_battery_draw;
                  };
                  
                  normal_battery_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_battery_draw,
                    y: start_y_normal_battery_draw,
                    w: lenght_ls_normal_battery_draw,
                    h: line_width_ls_normal_battery_draw,
                    radius: 4,
                    color: color_ls_normal_battery,
                  });
                };

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_ls_normal_step = progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_linear_scale
                  // initial parameters
                  let start_x_normal_step = 255;
                  let start_y_normal_step = 475;
                  let lenght_ls_normal_step = -470;
                  let line_width_ls_normal_step = 8;
                  let color_ls_normal_step = 0xFF27AE60;
                  
                  // calculated parameters
                  let start_x_normal_step_draw = start_x_normal_step;
                  let start_y_normal_step_draw = start_y_normal_step;
                  lenght_ls_normal_step = lenght_ls_normal_step * progress_ls_normal_step;
                  let lenght_ls_normal_step_draw = line_width_ls_normal_step;
                  let line_width_ls_normal_step_draw = lenght_ls_normal_step;
                  if (lenght_ls_normal_step < 0){
                    line_width_ls_normal_step_draw = -lenght_ls_normal_step;
                    start_y_normal_step_draw = start_y_normal_step_draw - line_width_ls_normal_step_draw;
                  };
                  
                  normal_step_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_step_draw,
                    y: start_y_normal_step_draw,
                    w: lenght_ls_normal_step_draw,
                    h: line_width_ls_normal_step_draw,
                    radius: 4,
                    color: color_ls_normal_step,
                  });
                };

                console.log('update scales CALORIE');
                
                let valueCalories = calorie.current;
                let targetCalories = calorie.target;
                let progressCalories = valueCalories/targetCalories;
                if (progressCalories > 1) progressCalories = 1;
                let progress_ls_normal_calorie = progressCalories;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_calorie_linear_scale
                  // initial parameters
                  let start_x_normal_calorie = 269;
                  let start_y_normal_calorie = 475;
                  let lenght_ls_normal_calorie = -470;
                  let line_width_ls_normal_calorie = 8;
                  let color_ls_normal_calorie = 0xFFE67E22;
                  
                  // calculated parameters
                  let start_x_normal_calorie_draw = start_x_normal_calorie;
                  let start_y_normal_calorie_draw = start_y_normal_calorie;
                  lenght_ls_normal_calorie = lenght_ls_normal_calorie * progress_ls_normal_calorie;
                  let lenght_ls_normal_calorie_draw = line_width_ls_normal_calorie;
                  let line_width_ls_normal_calorie_draw = lenght_ls_normal_calorie;
                  if (lenght_ls_normal_calorie < 0){
                    line_width_ls_normal_calorie_draw = -lenght_ls_normal_calorie;
                    start_y_normal_calorie_draw = start_y_normal_calorie_draw - line_width_ls_normal_calorie_draw;
                  };
                  
                  normal_calorie_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_calorie_draw,
                    y: start_y_normal_calorie_draw,
                    w: lenght_ls_normal_calorie_draw,
                    h: line_width_ls_normal_calorie_draw,
                    radius: 4,
                    color: color_ls_normal_calorie,
                  });
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
﻿/*
** Watch_Face_Editor tool
** watchface js version v2.1.1
** Copyright © SashaCX75. All Rights Reserved
*/

try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const { px } = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        const isAOD = hmSetting.getScreenType() == hmSetting.screen_type.AOD;
        const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);
        const device = hmSetting.getDeviceInfo();

        let normal_step_icon_img, normal_step_current_text_font
        let normal_dow_text_font, normal_day_text_font, normal_month_name_font
        let normal_day_of_year_text_font, normal_week_of_year_text_font, normal_day_text_IMG, normal_bg, normal_ampm_img, week_number
        let normal_temperature_high_text_font, normal_temperature_low_text_font, normal_temperature_current_text_font
        let normal_heart_rate_text_font, normal_battery_current_text_font
        let normal_time_hour_text_font, normal_time_second_text_font, normal_time_minute_text_font
        let normal_image_img
        let normal_frame_animation_1 = ''
        let animation_running = true;
        let showWeek = true;
        let bg_color = [0xDDBD46, 0xABFB37, 0x02ABF2, 0x366AF8, 0x2BBAB3, 0x015A7C, 0xFF7801, 0x01A453, 0x095C24, 0x39FB4F, 0xEB202C, 0xEE6E7D, 0xFB39DD, 0xFB90FE, 0xB339FB, 0x534740, 0xA3A3A3, 0xFFFFFE];
        let bg_index = 0;
        let normal_weather_icon_text, normal_weather_names_text, normal_weather_BIG_icon_text
        const array_ic_weather_day = ["A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z", "a", "b", "c"];
        const array_ic_weather_night = ["a", "b", "k", "c", "E", "l", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z", "a", "b", "c"];

        let array_names_weather_day = [
            "ОБЛАЧНО", "МЕСТАМИ ДОЖДЬ", "МЕСТАМИ СНЕГ", "СОЛНЕЧНО", "ПАСМУРНО",
            "СЛАБЫЙ ДОЖДЬ", "СЛАБЫЙ СНЕГ", "УМЕРННЫЙ ДОЖДЬ", "УМЕРЕННЫЙ СНЕГ",
            "СИЛЬНЫЙ СНЕГОПАД", "СИЛЬНЫЙ ДОЖДЬ", "ПЕСЧАНАЯ БУРЯ", "МОКРЫЙ СНЕГ",
            "ТУМАН", "ДЫМКА", "ДОЖДЬ С ГРОЗОЙ", "МЕТЕЛЬ", "ПЫЛЬНО", "ЛИВЕНЬ",
            "ДОЖДЬ С ГРАДОМ", "ГРОЗА С ГРАДОМ", "СИЛЬНЫЙ ДОЖДЬ", "ПЫЛЬНО",
            "ПЕСЧАНАЯ БУРЯ", "СИЛЬНЫЙ ДОЖДЬ", "НЕИЗВЕСТНАЯ ПОГОДА", "ОБЛАЧНО НОЧЬЮ",
            "ДОЖДЛИВО НОЧЬЮ", "ЯСНО НОЧЬЮ"
        ];

        let array_names_weather_night = [
            "ОБЛАЧНО НОЧЬЮ", "ДОЖДЛИВО НОЧЬЮ", "МЕСТАМИ СНЕГ", "ЯСНО НОЧЬЮ",
            "ПАСМУРНО НОЧЬЮ", "СЛАБЫЙ ДОЖДЬ", "СЛАБЫЙ СНЕГ", "УМЕРННЫЙ ДОЖДЬ",
            "УМЕРЕННЫЙ СНЕГ", "СИЛЬНЫЙ СНЕГОПАД", "СИЛЬНЫЙ ДОЖДЬ", "ПЕСЧАНАЯ БУРЯ",
            "МОКРЫЙ СНЕГ", "ТУМАН", "ДЫМКА", "ДОЖДЬ С ГРОЗОЙ", "МЕТЕЛЬ", "ПЫЛЬНО",
            "ЛИВЕНЬ", "ДОЖДЬ С ГРАДОМ", "ГРОЗА С ГРАДОМ", "СИЛЬНЫЙ ДОЖДЬ", "ПЫЛЬНО",
            "ПЕСЧАНАЯ БУРЯ", "СИЛЬНЫЙ ДОЖДЬ", "НЕИЗВЕСТНАЯ ПОГОДА", "ОБЛАЧНО НОЧЬЮ",
            "ДОЖДЛИВО НОЧЬЮ", "ЯСНО НОЧЬЮ"
        ];

        let normal_DOW_Array = ['ПОНЕДЕЛЬНИК', 'ВТОРНИК', 'СРЕДА', 'ЧЕТВЕРГ', 'ПЯТНИЦА', 'СУББОТА', 'ВОСКРЕСЕНЬЕ'];
        let normal_Month_Array = ['ЯНВ', 'ФЕВ', 'МРТ', 'АПР', 'МАЙ', 'ИЮН', 'ИЮЛ', 'АВГ', 'СЕН', 'ОКТ', 'НОЯ', 'ДЕК',];

        let week = 'НЕДЕЛЯ';
        let day = 'ДЕНЬ';
        let animOff = 'Анимация Отключена';
        let animOn = 'Анимация Включена';

        let isDayIcons = true;
        let sunsetMins = 20 * 60;
        let sunriseMins = 8 * 60;

        function loadSettings() {
            if (hmFS.SysProGetInt('MaxCL_color') === undefined) {
                bg_index = 0;
                hmFS.SysProSetInt('MaxCL_color', bg_index);
            } else {
                bg_index = hmFS.SysProGetInt('MaxCL_color');
            }
            if (hmFS.SysProGetBool('MaxCL_pointers_visible') === undefined) {
                pointersVisible = true;
                hmFS.SysProSetBool('MaxCL_pointers_visible', pointersVisible);
            } else {
                pointersVisible = hmFS.SysProGetBool('MaxCL_pointers_visible');
            }
            if (hmFS.SysProGetBool('MaxCL_showWeek') === undefined) {
                showWeek = true;
                hmFS.SysProSetBool('MaxCL_showWeek', showWeek);
            } else {
                showWeek = hmFS.SysProGetBool('MaxCL_showWeek');
            }
            if (hmFS.SysProGetBool('MaxCL_animation_running') === undefined) {
                animation_running = true;
                hmFS.SysProSetBool('MaxCL_animation_running', animation_running);
            } else {
                animation_running = hmFS.SysProGetBool('MaxCL_animation_running');
            }
        }

        function updateWeather() {
            try {
                if (!normal_weather_icon_text || !normal_weather_BIG_icon_text || !normal_weather_names_text) {
                    return;
                }

                const curAirIconIndex = weatherSensor.curAirIconIndex;
                const weatherData = weatherSensor.getForecastWeather();

                if (weatherData?.tideData?.count > 0) {
                    const today = weatherData.tideData.data[0];
                    sunriseMins = today.sunrise.hour * 60 + today.sunrise.minute;
                    sunsetMins = today.sunset.hour * 60 + today.sunset.minute;
                }

                const curTime = hmSensor.createSensor(hmSensor.id.TIME);
                const curMins = curTime.hour * 60 + curTime.minute;
                isDayIcons = (curMins >= sunriseMins && curMins < sunsetMins);

                const iconArray = isDayIcons ? array_ic_weather_day : array_ic_weather_night;
                const nameArray = isDayIcons ? array_names_weather_day : array_names_weather_night;

                const icon = iconArray[curAirIconIndex] || "Z";
                const name = nameArray[curAirIconIndex] || "НЕИЗВЕСТНАЯ ПОГОДА";

                normal_weather_icon_text.setProperty(hmUI.prop.TEXT, icon);
                normal_weather_BIG_icon_text.setProperty(hmUI.prop.TEXT, icon);
                normal_weather_names_text.setProperty(hmUI.prop.TEXT, name);

            } catch (error) {
                console.log("Weather update error:", error);
            }
        }

        let curTime = hmSensor.createSensor(hmSensor.id.TIME);

        let pointersVisible = true
        let pointers = []
        let scale_timer = ''

        let second_centerX = 240;
        let second_centerY = 240;
        let second_posX = 13;
        let second_posY = 225;
        let secPointer_img = 'second.png';
        let sec_pointer;
        let shadow_shift_centerX = 0;
        let shadow_shift_centerY = 19;
        let shadow_posX = 13;
        let shadow_posY = 225;
        let shadow_img = 'second_sh.png';
        let shadow_sec_pointer;

        function showHidePointers() {
            pointersVisible = !pointersVisible;
            hmFS.SysProSetBool('MaxCL_pointers_visible', pointersVisible);

            pointers.forEach(item => {
                item.setProperty(hmUI.prop.VISIBLE, pointersVisible);
                if (pointersVisible) {
                    startSecPointerAnim();
                } else {
                    stopSecPointerAnim();
                }
            });
        }

        function startSecPointerAnim() {
            if (scale_timer) timer.stopTimer(scale_timer);
            scale_timer = timer.createTimer(0, 150, (function (option) {
            }));
        }

        function stopSecPointerAnim() {
            if (scale_timer) {
                timer.stopTimer(scale_timer);
                scale_timer = undefined;
            }
        }

        function getCurrentDayOfYear() {
            let janFirst = new Date(curTime.year, 0, 1);
            let currentDate = new Date(curTime.year, curTime.month - 1, curTime.day);
            let dayOfYear = Math.floor((currentDate - janFirst) / (24 * 60 * 60 * 1000)) + 1;
            return dayOfYear;
        }

        function getWeekNumber(date) {
            let janFirst = new Date(date.getFullYear(), 0, 1);
            let days = Math.floor((date - janFirst) / (24 * 60 * 60 * 1000));
            return Math.ceil((days + janFirst.getDay()) / 7);
        }

        function getCurrentWeekNumber() {
            let currentDate = new Date(curTime.year, curTime.month - 1, curTime.day);
            return getWeekNumber(currentDate);
        }

        function getCurrentDate() {
            return curTime.day.toString().padStart(2, '0');
        }

        function getCurrentDayName() {
            return normal_DOW_Array[curTime.week - 1];
        }

        function getCurrentMonthName() {
            return normal_Month_Array[curTime.month - 1];
        }

        function updateDate() {
            setLanguage()
            normal_day_text_font.setProperty(hmUI.prop.TEXT, getCurrentDate());
            normal_dow_text_font.setProperty(hmUI.prop.TEXT, getCurrentDayName());
            normal_month_name_font.setProperty(hmUI.prop.TEXT, getCurrentMonthName());

            normal_week_of_year_text_font.setProperty(hmUI.prop.TEXT, week);//+ '     ' + getCurrentWeekNumber());
            week_number.setProperty(hmUI.prop.TEXT, getCurrentWeekNumber());
            normal_day_of_year_text_font.setProperty(hmUI.prop.TEXT, day + '         ' + getCurrentDayOfYear());
        }




        function toggleWeekDayVisibility() {
            showWeek = !showWeek;
            normal_week_of_year_text_font.setProperty(hmUI.prop.VISIBLE, !showWeek);
            week_number.setProperty(hmUI.prop.VISIBLE, !showWeek);
            normal_day_of_year_text_font.setProperty(hmUI.prop.VISIBLE, showWeek);

            hmFS.SysProSetBool('MaxCL_showWeek', showWeek);
        }

        function updateAMPM() {
            const hour = curTime.hour;
            const isAM = hour < 12;
            normal_ampm_img.setProperty(
                hmUI.prop.SRC,
                isAOD
                    ? (isAM ? 'am2.png' : 'pm2.png')
                    : (isAM ? 'am1.png' : 'pm1.png')
            );
        }


        function bg_click_forward() {
            bg_index = (bg_index + 1) % bg_color.length;
            bg_switching();
        }

        function bg_click_back() {
            bg_index = bg_index - 1;
            if (bg_index < 0) {
                bg_index = bg_color.length - 1;
            };
            bg_switching();
        }

        function bg_switching() {
            normal_bg.setProperty(hmUI.prop.COLOR, bg_color[bg_index],);
            normal_week_of_year_text_font.setProperty(hmUI.prop.COLOR, bg_color[bg_index]);
            week_number.setProperty(hmUI.prop.COLOR, bg_color[bg_index]);
            normal_day_of_year_text_font.setProperty(hmUI.prop.COLOR, bg_color[bg_index]);

            hmFS.SysProSetInt('MaxCL_color', bg_index);
        }

        const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
        let stopVibro_Timer = null;
        let clicks = 0;
        let clicksDelay = 370;

        function vibro(scene = 25) {
            let stopDelay = 50;
            vibrate.stop();
            vibrate.scene = scene;
            if (scene < 23 || scene > 25) stopDelay = 1220;
            vibrate.start();
            stopVibro_Timer = timer.createTimer(stopDelay, 0, stopVibro, {});
        }

        function stopVibro() {
            vibrate.stop();
            timer.stopTimer(stopVibro_Timer);
        }

        function setLanguage() {
            const lang = DeviceRuntimeCore.HmUtils.getLanguage();
            if (lang == 'en-US') {
                week = 'WEEK';
                day = 'DAY';
                animOff = 'Animation OFF';
                animOn = 'Animation ON';
                normal_DOW_Array = ['MONDAY', 'TUESDAY', 'WEDNESDAY', 'THURSDAY', 'FRIDAY', 'SATURDAY', 'SUNDAY'];
                normal_Month_Array = ['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN', 'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC'];
                array_names_weather_day = [
                    'CLOUDY', 'SHOWERS', 'SNOW SHOWERS', 'SUNNY', 'OVERCAST', 'LIGHT RAIN',
                    'LIGHT SNOW', 'MODERATE RAIN', 'MODERATE SNOW', 'HEAVY SNOW',
                    'HEAVY RAIN', 'SANDSTORM', 'RAIN AND SNOW', 'FOG', 'HAZY', 'T-STORMS',
                    'SNOWSTORM', 'FLOATING DUST', 'VERY HEAVY RAINSTORM', 'RAIN AND HAIL',
                    'T-STORMS AND HAIL', 'HEAVY RAINSTORM', 'DUST', 'HEAVY SAND STORM', 'RAINSTORM',
                    'UNKNOWN', 'CLOUDY NIGHTTIME', 'SHOWERS NIGHTTIME', 'SUNNY NIGHTTIME'
                ];
                array_names_weather_night = [
                    'CLOUDY NIGHT', 'SHOWERS NIGHT', 'SNOW SHOWERS NIGHT', 'CLEAR NIGHT', 'OVERCAST NIGHT',
                    'LIGHT RAIN', 'LIGHT SNOW', 'MODERATE RAIN', 'MODERATE SNOW', 'HEAVY SNOW',
                    'HEAVY RAIN', 'SANDSTORM', 'RAIN AND SNOW', 'FOG', 'HAZY', 'T-STORMS',
                    'SNOWSTORM', 'FLOATING DUST', 'VERY HEAVY RAINSTORM', 'RAIN AND HAIL',
                    'T-STORMS AND HAIL', 'HEAVY RAINSTORM', 'DUST', 'HEAVY SAND STORM', 'RAINSTORM',
                    'UNKNOWN', 'CLOUDY NIGHTTIME', 'SHOWERS NIGHTTIME', 'SUNNY NIGHTTIME'
                ];
            }
            if (lang == 'ru-RU') {
                week = 'НЕДЕЛЯ';
                day = 'ДЕНЬ';
                animOff = 'Анимация Отключена';
                animOn = 'Анимация Включена';
                normal_DOW_Array = ['ПОНЕДЕЛЬНИК', 'ВТОРНИК', 'СРЕДА', 'ЧЕТВЕРГ', 'ПЯТНИЦА', 'СУББОТА', 'ВОСКРЕСЕНЬЕ'];
                normal_Month_Array = ['ЯНВ', 'ФЕВ', 'МРТ', 'АПР', 'МАЙ', 'ИЮН', 'ИЮЛ', 'АВГ', 'СЕН', 'ОКТ', 'НОЯ', 'ДЕК'];
                array_names_weather_day = [
                    "ОБЛАЧНО", "МЕСТАМИ ДОЖДЬ", "МЕСТАМИ СНЕГ", "СОЛНЕЧНО", "ПАСМУРНО",
                    "СЛАБЫЙ ДОЖДЬ", "СЛАБЫЙ СНЕГ", "УМЕРННЫЙ ДОЖДЬ", "УМЕРЕННЫЙ СНЕГ",
                    "СИЛЬНЫЙ СНЕГОПАД", "СИЛЬНЫЙ ДОЖДЬ", "ПЕСЧАНАЯ БУРЯ", "МОКРЫЙ СНЕГ",
                    "ТУМАН", "ДЫМКА", "ДОЖДЬ С ГРОЗОЙ", "МЕТЕЛЬ", "ПЫЛЬНО", "ЛИВЕНЬ",
                    "ДОЖДЬ С ГРАДОМ", "ГРОЗА С ГРАДОМ", "СИЛЬНЫЙ ДОЖДЬ", "ПЫЛЬНО",
                    "ПЕСЧАНАЯ БУРЯ", "СИЛЬНЫЙ ДОЖДЬ", "НЕИЗВЕСТНАЯ ПОГОДА", "ОБЛАЧНО НОЧЬЮ",
                    "ДОЖДЛИВО НОЧЬЮ", "ЯСНО НОЧЬЮ"
                ];
                array_names_weather_night = [
                    "ОБЛАЧНО НОЧЬЮ", "ДОЖДЛИВО НОЧЬЮ", "МЕСТАМИ СНЕГ", "ЯСНО НОЧЬЮ",
                    "ПАСМУРНО НОЧЬЮ", "СЛАБЫЙ ДОЖДЬ", "СЛАБЫЙ СНЕГ", "УМЕРННЫЙ ДОЖДЬ",
                    "УМЕРЕННЫЙ СНЕГ", "СИЛЬНЫЙ СНЕГОПАД", "СИЛЬНЫЙ ДОЖДЬ", "ПЕСЧАНАЯ БУРЯ",
                    "МОКРЫЙ СНЕГ", "ТУМАН", "ДЫМКА", "ДОЖДЬ С ГРОЗОЙ", "МЕТЕЛЬ", "ПЫЛЬНО",
                    "ЛИВЕНЬ", "ДОЖДЬ С ГРАДОМ", "ГРОЗА С ГРАДОМ", "СИЛЬНЫЙ ДОЖДЬ", "ПЫЛЬНО",
                    "ПЕСЧАНАЯ БУРЯ", "СИЛЬНЫЙ ДОЖДЬ", "НЕИЗВЕСТНАЯ ПОГОДА", "ОБЛАЧНО НОЧЬЮ",
                    "ДОЖДЛИВО НОЧЬЮ", "ЯСНО НОЧЬЮ"
                ];
            }
            if (lang == 'uk-UA') {
                week = 'ТИЖДЕНЬ';
                day = 'ДЕНЬ'
                animOff = 'Анімацію Вимкнено';
                animOn = 'Анімацію Ввімкнено';
                normal_DOW_Array = ["ПОНЕДІЛОК", "ВІВТОРОК", "СЕРЕДА", "ЧЕТВЕР", "П’ЯТНИЦЯ", "СУБОТА", "НЕДІЛЯ"];
                normal_Month_Array = ["СІЧ", "ЛЮТ", "БЕР", "КВІ", "ТРА", "ЧЕР", "ЛИП", "СЕР", "ВЕР", "ЖОВ", "ЛИСТ", "ГРУ"];
                array_names_weather_day = [
                    'ХМАРНО', 'ЧАСОМ ДОЩ', 'ЧАСОМ СНІГ', 'СОНЯЧНО', 'ПОХМУРО', 'НЕВЕЛИКИЙ ДОЩ',
                    'НЕВЕЛИКИЙ СНІГ', 'ПОМІРНИЙ ДОЩ', 'ПОМІРНИЙ СНІГ', 'СИЛЬНИЙ СНІГ',
                    'СИЛЬНИЙ ДОЩ', 'ПІЩАНА БУРЯ', 'ДОЩ ТА СНІГ', 'ТУМАН', 'ДИМКА', 'ДОЩ З ГРОЗОЮ',
                    'ХУРТОВИНА', 'ЛЕТЮЧИЙ ПИЛ', 'ЗЛИВА', 'ДОЩ ТА ГРАД', 'ЗЛИВА ТА ГРАД',
                    'СИЛЬНА ЗЛИВА', 'ПИЛОВА БУРЯ', 'СИЛЬНА ПІЩАНА БУРЯ', 'СИЛЬНА ЗЛИВА',
                    'НЕВІДОМО', 'ХМАРНО ВНОЧІ', 'ДОЩ ВНОЧІ', 'ЯСНО ВНОЧІ'
                ];
                array_names_weather_night = [
                    'ХМАРНО ВНОЧІ', 'ДОЩ ВНОЧІ', 'ЧАСОМ СНІГ', 'ЯСНО ВНОЧІ', 'ПОХМУРО ВНОЧІ',
                    'НЕВЕЛИКИЙ ДОЩ', 'НЕВЕЛИКИЙ СНІГ', 'ПОМІРНИЙ ДОЩ', 'ПОМІРНИЙ СНІГ', 'СИЛЬНИЙ СНІГ',
                    'СИЛЬНИЙ ДОЩ', 'ПІЩАНА БУРЯ', 'ДОЩ ТА СНІГ', 'ТУМАН', 'ДИМКА', 'ДОЩ З ГРОЗОЮ',
                    'ХУРТОВИНА', 'ЛЕТЮЧИЙ ПИЛ', 'ЗЛИВА', 'ДОЩ ТА ГРАД', 'ЗЛИВА ТА ГРАД',
                    'СИЛЬНА ЗЛИВА', 'ПИЛОВА БУРЯ', 'СИЛЬНА ПІЩАНА БУРЯ', 'СИЛЬНА ЗЛИВА',
                    'НЕВІДОМО', 'ХМАРНО ВНОЧІ', 'ДОЩ ВНОЧІ', 'ЯСНО ВНОЧІ'
                ];
            }
        }

        function updateAllDate() {
            //setLanguage();
            updateDate();
            updateAMPM();
            try {
                updateWeather();
            } catch (error) {
                console.log("UpdateAllDate error:", error);
            }
        }

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {

                //--------- Кеш шрифтов ----
                // погода
                hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 478,
                    y: 478,
                    w: 400,
                    h: 25,
                    text_size: 20,
                    char_space: 0,
                    line_space: 0,
                    font: 'fonts/interTight_Regular.ttf',
                    color: 0xffffff,
                    align_h: hmUI.align.LEFT,
                    align_v: hmUI.align.CENTER_V,
                    text_style: hmUI.text_style.ELLIPSIS,
                    text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZАБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯ ҐЄІЇ_-.,:;`'%°\\/",
                });

                // неделя
                hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 478,
                    y: 478,
                    w: 400,
                    h: 30,
                    text_size: 22,
                    char_space: 0,
                    line_space: 0,
                    font: 'fonts/interTight_Regular.ttf',
                    color: 0xffffff,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    text_style: hmUI.text_style.ELLIPSIS,
                    text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZАБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯҐЄІЇ_-.,:;`'%°",
                });

                // месяц
                hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 478,
                    y: 478,
                    w: 400,
                    h: 49,
                    text_size: 45,
                    char_space: 0,
                    line_space: 0,
                    font: 'fonts/interTight_Regular.ttf',
                    color: 0xffffff,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    text_style: hmUI.text_style.ELLIPSIS,
                    text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZАБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯҐЄІЇ_-.,:;`'%°",
                });

                // шаги
                hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 478,
                    y: 478,
                    w: 400,
                    h: 45,
                    text_size: 48,
                    char_space: 0,
                    line_space: 0,
                    font: 'fonts/interTight_Regular.ttf',
                    color: 0xffffff,
                    align_h: hmUI.align.LEFT,
                    align_v: hmUI.align.CENTER_V,
                    text_style: hmUI.text_style.ELLIPSIS,
                    text: "0123456789.-_, "
                });

                // температура
                hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 478,
                    y: 478,
                    w: 400,
                    h: 30,
                    text_size: 33,
                    char_space: 0,
                    line_space: 0,
                    font: 'fonts/interTight_Regular.ttf',
                    color: 0xffffff,
                    align_h: hmUI.align.LEFT,
                    align_v: hmUI.align.CENTER_V,
                    text_style: hmUI.text_style.ELLIPSIS,
                    text: "0123456789.-° "
                });

                // секунды, батарея, пульс
                hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 478,
                    y: 478,
                    w: 400,
                    h: 30,
                    text_size: 27,
                    char_space: 0,
                    line_space: 0,
                    font: 'fonts/interTight_Regular.ttf',
                    color: 0x000000,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    text_style: hmUI.text_style.ELLIPSIS,
                    text: "0123456789.-_% "
                });

                hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 478,
                    y: 478,
                    w: 400,
                    h: 29,
                    text_size: 28,
                    char_space: -1,
                    line_space: 0,
                    font: 'fonts/interTight_Regular.ttf',
                    color: 0xffffff,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    text_style: hmUI.text_style.ELLIPSIS,
                    text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZАБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯҐЄІЇ_-.,:;`'%°",
                });

                // минуты
                hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 478,
                    y: 478,
                    w: 400,
                    h: 70,
                    text_size: 88,
                    char_space: -7,
                    line_space: 0,
                    font: 'fonts/interTight_Regular.ttf',
                    color: 0xffffff,
                    align_h: hmUI.align.LEFT,
                    align_v: hmUI.align.CENTER_V,
                    text_style: hmUI.text_style.NONE,
                    text: "0123456789 _-.",
                });

                // час
                hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 478,
                    y: 478,
                    w: 400,
                    h: 120,
                    text_size: 113,
                    char_space: -8,
                    line_space: 0,
                    font: 'fonts/interTight_Regular.ttf',
                    color: 0xffffff,
                    align_h: hmUI.align.RIGHT,
                    align_v: hmUI.align.CENTER_V,
                    text_style: hmUI.text_style.NONE,
                    text: "0123456789 _-.",
                });

                // число
                hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 478,
                    y: 478,
                    w: 400,
                    h: 135,
                    text_size: 133,
                    char_space: -8,
                    line_space: 0,
                    font: 'fonts/interTight_Regular.ttf',
                    color: 0xffffff,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    text_style: hmUI.text_style.ELLIPSIS,
                    text: "0123456789 _-.",
                });

                normal_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
                    x: 0,
                    y: 0,
                    w: device.width,
                    h: device.height,
                    radius: 240,
                    color: bg_color[bg_index],
                    show_level: hmUI.show_level.ONLY_NORMAL,
                });

                normal_mask = hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: device.width,
                    h: device.height,
                    src: 'mask0.png',
                    show_level: hmUI.show_level.ONLY_NORMAL,
                });

                AOD_mask = hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: device.width,
                    h: device.height,
                    src: 'mask0AOD.png',
                    alpha: 100,
                    show_level: hmUI.show_level.ONLY_AOD,
                });

                normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
                    x: 132,
                    y: 14,
                    src: 'half.png',
                    alpha: 60,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                });

                normal_shadow = hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: device.width,
                    h: device.height,
                    src: 'shadow.png',
                    show_level: hmUI.show_level.ONLY_NORMAL,
                });

                normal_weather_BIG_icon_text = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 238,
                    y: 250,
                    w: 158,
                    h: 164,
                    text_size: 100,
                    char_space: 0,
                    line_space: 0,
                    font: 'fonts/weatherIconsBig.ttf',
                    color: isAOD ? 0xFFFFFFFF : 0x00000000,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    text_style: hmUI.text_style.ELLIPSIS,
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                normal_weather_BIG_icon_text.setAlpha(30);

                normal_weather_icon_text = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 222,
                    y: 264,
                    w: 40,
                    h: 40,
                    text_size: 32,
                    char_space: 0,
                    line_space: 0,
                    color: isAOD ? 0xe6e6e6 : 0x000000,
                    font: 'fonts/weatherIconsBig.ttf',
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    text_style: hmUI.text_style.ELLIPSIS,
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                normal_weather_names_text = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 261,
                    y: 272,
                    w: 218,
                    h: 25,
                    text_size: 20,
                    char_space: 0,
                    line_space: 0,
                    font: 'fonts/interTight_Regular.ttf',
                    color: isAOD ? 0xe6e6e6 : 0x000000,
                    align_h: hmUI.align.LEFT,
                    align_v: hmUI.align.CENTER_V,
                    text_style: hmUI.text_style.ELLIPSIS,
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                normal_step_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
                    x: 226,
                    y: 356,
                    w: 150,
                    h: 45,
                    text_size: 48,
                    char_space: 0,
                    line_space: 0,
                    font: 'fonts/interTight_Regular.ttf',
                    color: isAOD ? 0xe6e6e6 : 0x000000,
                    align_h: hmUI.align.LEFT,
                    align_v: hmUI.align.CENTER_V,
                    text_style: hmUI.text_style.ELLIPSIS,
                    type: hmUI.data_type.STEP,
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                function toggleAnimation() {
                    animation_running = !animation_running;

                    normal_frame_animation_1.setProperty(
                        hmUI.prop.ANIM_STATUS,
                        animation_running ? hmUI.anim_status.START : hmUI.anim_status.STOP
                    );

                    hmFS.SysProSetBool('MaxCL_animation_running', animation_running);
                    hmUI.showToast({ text: animation_running ? animOn : animOff });
                }

                normal_frame_animation_1 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
                    x: 345,
                    y: 343,
                    anim_path: "animation",
                    anim_ext: "png",
                    anim_prefix: "anim",
                    anim_fps: 7,
                    anim_size: 17,
                    repeat_count: 0,
                    anim_repeat: true,
                    anim_status: hmUI.anim_status.START,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                });

                normal_ampm_img = hmUI.createWidget(hmUI.widget.IMG, {
                    x: 224,
                    y: 82,
                    src: isAOD ? 'am2.png' : 'am1.png',
                    alpha: isAOD ? 150 : 255,
                    enable: true,
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                })

                normal_time_hour_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 204,
                    y: 100,
                    w: 135,
                    h: 120,
                    text_size: 113,
                    char_space: -8,
                    line_space: 0,
                    font: 'fonts/interTight_Regular.ttf',
                    color: isAOD ? 0xFFFFFF : 0x000000,
                    align_h: hmUI.align.RIGHT,
                    align_v: hmUI.align.CENTER_V,
                    text_style: hmUI.text_style.NONE,
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD
                });

                normal_time_minute_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
                    x: 337,
                    y: 134,
                    w: 117,
                    h: 70,
                    text_size: 88,
                    char_space: -7,
                    line_space: 0,
                    font: 'fonts/interTight_Regular.ttf',
                    color: isAOD ? 0xFFFFFF : 0x000000,
                    align_h: hmUI.align.LEFT,
                    align_v: hmUI.align.CENTER_V,
                    text_style: hmUI.text_style.NONE,
                    padding: true,
                    alpha: isAOD ? 150 : 120,
                    type: hmUI.data_type.MINUTE,
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD
                });

                normal_time_second_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
                    x: 310,
                    y: 75,
                    w: 35,
                    h: 30,
                    text_size: 27,
                    char_space: 0,
                    line_space: 0,
                    font: 'fonts/interTight_Regular.ttf',
                    color: 0x000000,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    text_style: hmUI.text_style.ELLIPSIS,
                    padding: true,
                    type: hmUI.data_type.SECOND,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                });

                normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
                    x: 219,
                    y: 219,
                    src: 'linija.png',
                    alpha: 100,
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                normal_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
                    x: 104,
                    y: 365,
                    w: 51,
                    h: 30,
                    text_size: 27,
                    char_space: 0,
                    line_space: 0,
                    font: 'fonts/interTight_Regular.ttf',
                    color: isAOD ? 0x828282 : 0x000000,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    text_style: hmUI.text_style.ELLIPSIS,
                    type: hmUI.data_type.BATTERY,
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                normal_heart_rate_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
                    x: 275,
                    y: 418,
                    w: 55,
                    h: 30,
                    text_size: 27,
                    char_space: 0,
                    line_space: 0,
                    font: 'fonts/interTight_Regular.ttf',
                    color: isAOD ? 0x828282 : 0x000000,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    text_style: hmUI.text_style.ELLIPSIS,
                    type: hmUI.data_type.HEART,
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                normal_temperature_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
                    x: 224,
                    y: 314,
                    w: 70,
                    h: 30,
                    text_size: 33,
                    char_space: 0,
                    line_space: 0,
                    font: 'fonts/interTight_Regular.ttf',
                    color: isAOD ? 0xe6e6e6 : 0x000000,
                    align_h: hmUI.align.LEFT,
                    align_v: hmUI.align.CENTER_V,
                    unit_type: 1,
                    text_style: hmUI.text_style.ELLIPSIS,
                    type: hmUI.data_type.WEATHER_CURRENT,
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                normal_temperature_low_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
                    x: 384,
                    y: 312,
                    w: 44,
                    h: 25,
                    text_size: 20,
                    char_space: 0,
                    line_space: 0,
                    font: 'fonts/interTight_Regular.ttf',
                    color: isAOD ? 0x828282 : 0x000000,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    unit_type: 1,
                    text_style: hmUI.text_style.ELLIPSIS,
                    type: hmUI.data_type.WEATHER_LOW,
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                normal_temperature_high_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
                    x: 328,
                    y: 312,
                    w: 44,
                    h: 25,
                    text_size: 20,
                    char_space: 0,
                    line_space: 0,
                    font: 'fonts/interTight_Regular.ttf',
                    color: isAOD ? 0x828282 : 0x000000,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    unit_type: 1,
                    text_style: hmUI.text_style.ELLIPSIS,
                    type: hmUI.data_type.WEATHER_HIGH,
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                normal_day_text_IMG = hmUI.createWidget(hmUI.widget.IMG_DATE, {
                    day_startX: 20,
                    day_startY: 139,
                    day_sc_array: isAOD
                        ? ["w0.png", "w1.png", "w2.png", "w3.png", "w4.png", "w5.png", "w6.png", "w7.png", "w8.png", "w9.png"]
                        : ["n0.png", "n1.png", "n2.png", "n3.png", "n4.png", "n5.png", "n6.png", "n7.png", "n8.png", "n9.png"],
                    day_tc_array: isAOD
                        ? ["w0.png", "w1.png", "w2.png", "w3.png", "w4.png", "w5.png", "w6.png", "w7.png", "w8.png", "w9.png"]
                        : ["n0.png", "n1.png", "n2.png", "n3.png", "n4.png", "n5.png", "n6.png", "n7.png", "n8.png", "n9.png"],
                    day_en_array: isAOD
                        ? ["w0.png", "w1.png", "w2.png", "w3.png", "w4.png", "w5.png", "w6.png", "w7.png", "w8.png", "w9.png"]
                        : ["n0.png", "n1.png", "n2.png", "n3.png", "n4.png", "n5.png", "n6.png", "n7.png", "n8.png", "n9.png"],
                    day_zero: 1,
                    day_space: -38,
                    day_align: hmUI.align.CENTER_H,
                    day_is_character: false,
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                normal_day_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 38,
                    y: 172,
                    w: 150,
                    h: 135,
                    text_size: 133,
                    char_space: -8,
                    line_space: 0,
                    //text: getCurrentDate(),
                    font: 'fonts/interTight_Regular.ttf',
                    color: isAOD ? 0x828282 : 0x000000,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    text_style: hmUI.text_style.ELLIPSIS,
                    padding: true,
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                normal_dow_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 18,
                    y: 309,
                    w: 177,
                    h: 30,
                    text_size: 22,
                    char_space: 0,
                    line_space: 0,
                    //text: getCurrentDayName(),
                    font: 'fonts/interTight_Regular.ttf',
                    color: isAOD ? 0x828282 : 0x000000,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    text_style: hmUI.text_style.ELLIPSIS,
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                normal_month_name_font = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 56,
                    y: 97,
                    w: 117,
                    h: 49,
                    text_size: 45,
                    char_space: 0,
                    line_space: 0,
                    //text: getCurrentMonthName(),
                    font: 'fonts/interTight_Regular.ttf',
                    color: isAOD ? 0x828282 : 0x000000,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    text_style: hmUI.text_style.ELLIPSIS,
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                normal_week_of_year_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 260,
                    y: 224,
                    w: 136,
                    h: 29,
                    text_size: 28,
                    char_space: -1,
                    line_space: 0,
                    //text: week + '     ' + getCurrentWeekNumber(),
                    font: 'fonts/interTight_Regular.ttf',
                    color: isAOD ? 0xe6e6e6 : bg_color[bg_index],
                    align_h: hmUI.align.CENTER_H, //LEFT,
                    align_v: hmUI.align.CENTER_V,
                    text_style: hmUI.text_style.ELLIPSIS,
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                week_number = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 397,
                    y: 224,
                    w: 52,
                    h: 29,
                    text_size: 28,
                    char_space: -1,
                    line_space: 0,
                    text: getCurrentWeekNumber(),//text: week + '     ' + getCurrentWeekNumber(),
                    font: 'fonts/interTight_Regular.ttf',
                    color: isAOD ? 0xe6e6e6 : bg_color[bg_index],
                    align_h: hmUI.align.CENTER_H, //LEFT,
                    align_v: hmUI.align.CENTER_V,
                    text_style: hmUI.text_style.ELLIPSIS,
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                normal_day_of_year_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 265,
                    y: 224,
                    w: 170,
                    h: 29,
                    text_size: 28,
                    char_space: -1,
                    line_space: 0,
                    //text: day + '         ' + getCurrentDayOfYear(),
                    font: 'fonts/interTight_Regular.ttf',
                    color: isAOD ? 0xe6e6e6 : bg_color[bg_index],
                    align_h: hmUI.align.RIGHT,
                    align_v: hmUI.align.CENTER_V,
                    text_style: hmUI.text_style.ELLIPSIS,
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                pointers[0] = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                    hour_path: 'hour_shadow.png',
                    hour_centerX: 240,
                    hour_centerY: 259,
                    hour_posX: 22,
                    hour_posY: 131,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                pointers[1] = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                    hour_path: isAOD ? 'hour_yellow.png' : 'hour.png',
                    hour_centerX: 240,
                    hour_centerY: 240,
                    hour_posX: 22,
                    hour_posY: 131,
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                pointers[2] = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                    minute_path: 'minute_shadow.png',
                    minute_centerX: 240,
                    minute_centerY: 259,
                    minute_posX: 19,
                    minute_posY: 216,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                pointers[3] = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                    minute_path: isAOD ? 'minute_yellow.png' : 'minute.png',
                    minute_centerX: 240,
                    minute_centerY: 240,
                    minute_posX: 19,
                    minute_posY: 216,
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });
                pointers[4] = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                    second_centerX: second_centerX + shadow_shift_centerX,
                    second_centerY: second_centerY + shadow_shift_centerY,
                    second_posX: shadow_posX,
                    second_posY: shadow_posY,
                    second_path: shadow_img,
                    fresh_frequency: 25,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                });
                pointers[5] = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                    second_centerX: second_centerX,
                    second_centerY: second_centerY,
                    second_posX: second_posX,
                    second_posY: second_posY,
                    second_path: secPointer_img,
                    fresh_frequency: 25,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                });
                pointers[6] = hmUI.createWidget(hmUI.widget.IMG, {
                    x: 221,
                    y: 221,
                    src: 'aodCover.png',
                    show_level: hmUI.show_level.ONLY_AOD,
                });

                function updateTime() {
                    const hour = curTime.hour;
                    const is24Hour = curTime.is24Hour;
                    const format_hour = curTime.format_hour;
                    let hourStr

                    if (is24Hour) {
                        hourStr = format_hour.toString().padStart(2, '0');
                    } else {
                        hourStr = format_hour > 12 ? (format_hour - 12).toString() : format_hour.toString();
                    }

                    normal_time_hour_text_font.setProperty(hmUI.prop.TEXT, hourStr);
                }

                curTime.addEventListener(hmSensor.event.CHANGE, function () {
                    updateDate();
                    updateAMPM();
                    updateTime();
                });

                // запуск приложения с заданным appId (если оно установлено) или системного приложения
                function launchAppOrAppId(url, appId, page = 'page/index') {
                    let appInstalled = false;

                    try {
                        const id16 = appId.toString(16).padStart(8, "0");// переводим appId в 16-ричный формат

                        const [fs_stat, err] = hmFS.stat_asset(`../../../js_apps/${id16}/app.json`);// проверяем наличие файла 'app.json' в папке приложения

                        if (err == 0) {	//  если файл есть,  то приложение установлено
                            appInstalled = true;
                        } else {
                            console.log("err:", err);
                        }
                    } catch (error) {
                        console.log("error:", error);
                        console.log("FAIL: No access to hmFS.");
                    }

                    if (appInstalled) hmApp.startApp({ appid: appId, url: page })
                    else hmApp.startApp({ url: url, native: true });
                }

                //================================================================

                hmUI.createWidget(hmUI.widget.BUTTON, {
                    x: 190,
                    y: 190,
                    w: 90,
                    h: 90,
                    text: '',
                    normal_src: 'blank.png',
                    press_src: 'blank.png',
                    click_func: () => {
                        showHidePointers()
                        vibro();
                    },
                    show_level: hmUI.show_level.ONLY_NORMAL,
                });

                btn_bgColor1 = hmUI.createWidget(hmUI.widget.BUTTON, {
                    x: 3,
                    y: 152,
                    w: 80,
                    h: 80,
                    text: '',
                    normal_src: 'blank.png',
                    press_src: 'blank.png',
                    click_func: () => {
                        bg_click_forward();
                        vibro();
                    },
                    show_level: hmUI.show_level.ONLY_NORMAL,
                });

                btn_bgColor2 = hmUI.createWidget(hmUI.widget.BUTTON, {
                    x: 3,
                    y: 246,
                    w: 80,
                    h: 80,
                    text: '',
                    normal_src: 'blank.png',
                    press_src: 'blank.png',
                    click_func: () => {
                        bg_click_back();
                        vibro();
                    },
                    show_level: hmUI.show_level.ONLY_NORMAL,
                });

                bt_week = hmUI.createWidget(hmUI.widget.BUTTON, {
                    x: 304,
                    y: 220,
                    w: 100,
                    h: 40,
                    text: '',
                    normal_src: 'blank.png',
                    press_src: 'blank.png',
                    click_func: () => {
                        toggleWeekDayVisibility()
                        vibro();
                    },
                    show_level: hmUI.show_level.ONLY_NORMAL,
                });
                normal_day_of_year_text_font.setProperty(hmUI.prop.VISIBLE, false);

                bt_step_AnimOff = hmUI.createWidget(hmUI.widget.BUTTON, {
                    x: 243,
                    y: 355,
                    w: 148,
                    h: 46,
                    text: '',
                    normal_src: 'blank.png',
                    press_src: 'blank.png',
                    click_func: () => {
                        hmApp.startApp({ url: 'activityAppScreen', native: true });
                        vibro();
                    },
                    longpress_func: () => {
                        toggleAnimation();
                        vibro();
                    },
                    show_level: hmUI.show_level.ONLY_NORMAL,
                });

                bt_weather = hmUI.createWidget(hmUI.widget.BUTTON, {
                    x: 267,
                    y: 279,
                    w: 95,
                    h: 69,
                    text: '',
                    normal_src: 'blank.png',
                    press_src: 'blank.png',
                    click_func: () => {
                        launchAppOrAppId('WeatherScreen', 1051195);
                        vibro();
                    },
                    longpress_func: () => {
                        hmApp.startApp({ appid: 1065824, url: 'page/index' })
                        vibro();
                    },
                    show_level: hmUI.show_level.ONLY_NORMAL,
                });

                bt_heart = hmUI.createWidget(hmUI.widget.BUTTON, {
                    x: 237,
                    y: 410,
                    w: 91,
                    h: 61,
                    text: '',
                    normal_src: 'blank.png',
                    press_src: 'blank.png',
                    click_func: () => {
                        hmApp.startApp({ url: 'heart_app_Screen', native: true });
                        vibro();
                    },
                    show_level: hmUI.show_level.ONLY_NORMAL,
                });

                bt_calendar = hmUI.createWidget(hmUI.widget.BUTTON, {
                    x: 96,
                    y: 204,
                    w: 70,
                    h: 70,
                    text: '',
                    normal_src: 'blank.png',
                    press_src: 'blank.png',
                    click_func: () => {
                        launchAppOrAppId('ScheduleCalScreen', 1057409);
                        vibro();
                    },
                    show_level: hmUI.show_level.ONLY_NORMAL,
                });

                const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
                    resume_call: (function () {
                        console.log('resume_call()');
                        updateAllDate();
                        updateTime();

                        if (animation_running) {
                            normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS, hmUI.anim_status.START);
                        } else {
                            normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS, hmUI.anim_status.STOP);
                        }

                        if (hmSetting.getScreenType() == hmSetting.screen_type.WATCHFACE) {
                            startSecPointerAnim();
                        }

                        pointersVisible = hmFS.SysProGetBool('MaxCL_pointers_visible');
                        pointers.forEach(pointer => {
                            pointer.setProperty(hmUI.prop.VISIBLE, pointersVisible);
                        });

                        showWeek = hmFS.SysProGetBool('MaxCL_showWeek');
                        normal_week_of_year_text_font.setProperty(hmUI.prop.VISIBLE, !showWeek);
                        week_number.setProperty(hmUI.prop.VISIBLE, !showWeek);
                        normal_day_of_year_text_font.setProperty(hmUI.prop.VISIBLE, showWeek);
                    }),

                    pause_call: (function () {
                        console.log('pause_call()');
                        if (animation_running) {
                            normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS, hmUI.anim_status.STOP);
                        }
                        if (scale_timer) {
                            stopSecPointerAnim();
                        }
                    }),
                });


            },


            onInit() {
                logger.log('index page.js on init invoke');
                loadSettings();
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
                vibrate && vibrate.stop();
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
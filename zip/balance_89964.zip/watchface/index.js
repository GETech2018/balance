﻿    /*
    ** Watch_Face_Editor tool v 18.2
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

/**
 * Reading call history from btCallRecode
 * Zepp OS API 1
 *
 * File format:
 *
 * [Number]
 * [Name]
 * [CallType]
 * [CallStatus]
 * [Timestamp]
 *
 * Result:
 * [
 *   {
 *     number: "+380123456789",
 *     name: "Name",
 *     callType: 2, 0 = Incoming, 1 = Outgoing, 2 = Missed
 *     callStatus: 3,
 *     timestamp: 1791104727
 *   }
 * ]
 */

class CallHistoryReader {

  static FILE_PATH = "../../../Downloads/PhoneBook/btCallRecode"

  /**
   * Reads the file and returns an array of calls.
   *
   * @returns {Array<Object>}
   */
  static read() {
    let fileId = -1

    try {
      // Getting information about a file.
      const [stat, statErr] = hmFS.stat(this.FILE_PATH);
      console.log("[CallHistoryReader] hmFS.stat: " + statErr + ", size: " + (stat ? stat.size : "N/A"));

      if (statErr !== 0 || !stat) {
        throw new Error(
          "Failed to find file. hmFS.stat error: " + statErr
        )
      }

      if (stat.size <= 0) {
        return []
      }

      // Opening the file only for reading.
      fileId = hmFS.open(this.FILE_PATH, hmFS.O_RDONLY);
      console.log("[CallHistoryReader] hmFS.open: fileId: " + fileId);

      if (fileId < 0) {
        throw new Error(
          "Failed to open file. fileId: " + fileId
        )
      }

      // Reading the entire file.
      const buffer = new ArrayBuffer(stat.size)

      const readResult = hmFS.read(
        fileId,
        buffer,
        0,
        stat.size
      )

      if (readResult !== 0 && readResult !== stat.size) {
        throw new Error(
          "Failed to read file. hmFS.read error: " + readResult
        )
      }

      // Преобразуем UTF-8 байты в JS-строку.
      const text = this._decodeUtf8(buffer)

      return this._parse(text)

    } catch (error) {
      console.log(
        "[CallHistoryReader] Error: " + error
      )

      return []

    } finally {
      // Файл обязательно закрываем.
      if (fileId >= 0) {
        hmFS.close(fileId)
      }
    }
  }

  /**
   * Parses the text of the file.
   *
   * @param {string} text
   * @returns {Array<Object>}
   */
  static _parse(text) {
    // Remove the BOM, if there is one.
    text = text.replace(/^\uFEFF/, "")

    // Supports CRLF and LF.
    const lines = text.split(/\r?\n/)

    // Removing empty lines.
    const data = []

    for (let i = 0; i < lines.length; i++) {
      const line = lines[i].trim()

      if (line.length > 0) {
        data.push(line)
      }
    }

    const calls = []

    // One record = 5 lines.
    for (let i = 0; i + 4 < data.length; i += 5) {

      const number = data[i]
      const name = data[i + 1]

      const callType = parseInt(data[i + 2], 10)
      const callStatus = parseInt(data[i + 3], 10)
      const timestamp = parseInt(data[i + 4], 10)

      const date = new Date(timestamp * 1000)
      const time = {
        year: date.getFullYear(),
        month: date.getMonth() + 1,
        day: date.getDate(),
        hour: date.getHours(),
        minute: date.getMinutes(),
        second: date.getSeconds()
      }

      // Checking numeric fields.
      if (
        isNaN(callType) ||
        isNaN(callStatus) ||
        isNaN(timestamp)
      ) {
        console.log(
          "[CallHistoryReader] Invalid record starting from line " +
          i
        )

        continue
      }

      calls.push({
        number: number,
        name: name,
        callType: callType,
        callStatus: callStatus,
        timestamp: timestamp,
        time: time
      })
    }

    calls.sort(function(a, b) {
      return b.timestamp - a.timestamp
    })

    return calls
  }

  /**
   * Converts ArrayBuffer UTF-8 -> JavaScript String.
   *
   * A custom decoder is needed to correctly read
   * Cyrillic characters without dependency on TextDecoder.
   *
   * @param {ArrayBuffer} buffer
   * @returns {string}
   */
  static _decodeUtf8(buffer) {
    const bytes = new Uint8Array(buffer)

    let result = ""
    let i = 0

    while (i < bytes.length) {
      const b1 = bytes[i]

      // ASCII
      if (b1 < 0x80) {
        result += String.fromCharCode(b1)
        i++
        continue
      }

      // 2-byte UTF-8
      if (
        (b1 & 0xE0) === 0xC0 &&
        i + 1 < bytes.length
      ) {
        const b2 = bytes[i + 1]

        const code =
          ((b1 & 0x1F) << 6) |
          (b2 & 0x3F)

        result += String.fromCharCode(code)
        i += 2
        continue
      }

      // 3-byte UTF-8
      if (
        (b1 & 0xF0) === 0xE0 &&
        i + 2 < bytes.length
      ) {
        const b2 = bytes[i + 1]
        const b3 = bytes[i + 2]

        const code =
          ((b1 & 0x0F) << 12) |
          ((b2 & 0x3F) << 6) |
          (b3 & 0x3F)

        result += String.fromCharCode(code)
        i += 3
        continue
      }

      // 4-byte UTF-8
      if (
        (b1 & 0xF8) === 0xF0 &&
        i + 3 < bytes.length
      ) {
        const b2 = bytes[i + 1]
        const b3 = bytes[i + 2]
        const b4 = bytes[i + 3]

        const code =
          ((b1 & 0x07) << 18) |
          ((b2 & 0x3F) << 12) |
          ((b3 & 0x3F) << 6) |
          (b4 & 0x3F)

        // Convert to a surrogate pair.
        const code2 = code - 0x10000

        result += String.fromCharCode(
          0xD800 + (code2 >> 10),
          0xDC00 + (code2 & 0x3FF)
        )

        i += 4
        continue
      }

      // Invalid UTF-8 byte.
      result += "\uFFFD"
      i++
    }

    return result
  }
}

let calls;
        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_image_img = ''
        let normal_widget_text_1 = ''
        let normal_dow_text_font = ''
        let normal_DOW_Array = ['Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa', 'Su'];
        let normal_day_text_font = ''
        let normal_battery_current_text_font = ''
        let normal_heart_rate_text_font = ''
        let normal_calorie_current_text_font = ''
        let normal_step_current_text_font = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg_img = ''
        let idle_image_img = ''
        let idle_widget_text_1 = ''
        let idle_dow_text_font = ''
        let idle_DOW_Array = ['Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa', 'Su'];
        let idle_day_text_font = ''
        let idle_battery_current_text_font = ''
        let idle_heart_rate_text_font = ''
        let idle_calorie_current_text_font = ''
        let idle_step_current_text_font = ''
        let idle_digital_clock_img_time = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let Button_7 = ''
        let Button_8 = ''
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 96,
              y: 83,
              src: 'phone.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_1 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 130,
              y: 10,
              w: 220,
              h: 55,
              text_size: 30,
              char_space: 0,
              color: 0xFFFFFFFF,
              line_space: -10,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              align_h: hmUI.align.CENTER_H,
              text: '--',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function() {
              time_update(true);
            });

            normal_dow_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 15,
              y: 150,
              w: 90,
              h: 40,
              text_size: 30,
              char_space: 0,
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // unit_string: Mo, Tu, We, Th, Fr, Sa, Su,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_day_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 15,
              y: 190,
              w: 90,
              h: 40,
              text_size: 30,
              char_space: 0,
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 15,
              y: 250,
              w: 90,
              h: 40,
              text_size: 30,
              char_space: 0,
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              unit_type: 1,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 374,
              y: 250,
              w: 90,
              h: 40,
              text_size: 30,
              char_space: 0,
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 374,
              y: 190,
              w: 90,
              h: 40,
              text_size: 30,
              char_space: 0,
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 150,
              y: 405,
              w: 180,
              h: 55,
              text_size: 40,
              char_space: 0,
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 173,
              hour_startY: 135,
              hour_array: ["time_0.png","time_1.png","time_2.png","time_3.png","time_4.png","time_5.png","time_6.png","time_7.png","time_8.png","time_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 173,
              minute_startY: 242,
              minute_array: ["time_0.png","time_1.png","time_2.png","time_3.png","time_4.png","time_5.png","time_6.png","time_7.png","time_8.png","time_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'aod.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 96,
              y: 83,
              src: 'phone.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_widget_text_1 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 130,
              y: 10,
              w: 220,
              h: 55,
              text_size: 30,
              char_space: 0,
              color: 0xFF9A9A9A,
              line_space: -10,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              align_h: hmUI.align.CENTER_H,
              text: '--',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_dow_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 15,
              y: 150,
              w: 90,
              h: 40,
              text_size: 30,
              char_space: 0,
              color: 0xFF9A9A9A,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // unit_string: Mo, Tu, We, Th, Fr, Sa, Su,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_day_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 15,
              y: 190,
              w: 90,
              h: 40,
              text_size: 30,
              char_space: 0,
              color: 0xFF9A9A9A,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 15,
              y: 250,
              w: 90,
              h: 40,
              text_size: 30,
              char_space: 0,
              color: 0xFF9A9A9A,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              unit_type: 1,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 374,
              y: 250,
              w: 90,
              h: 40,
              text_size: 30,
              char_space: 0,
              color: 0xFF9A9A9A,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 374,
              y: 190,
              w: 90,
              h: 40,
              text_size: 30,
              char_space: 0,
              color: 0xFF9A9A9A,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 150,
              y: 405,
              w: 180,
              h: 55,
              text_size: 40,
              char_space: 0,
              color: 0xFF9A9A9A,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 173,
              hour_startY: 135,
              hour_array: ["time_aod_0.png","time_aod_1.png","time_aod_2.png","time_aod_3.png","time_aod_4.png","time_aod_5.png","time_aod_6.png","time_aod_7.png","time_aod_8.png","time_aod_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 173,
              minute_startY: 242,
              minute_array: ["time_aod_0.png","time_aod_1.png","time_aod_2.png","time_aod_3.png","time_aod_4.png","time_aod_5.png","time_aod_6.png","time_aod_7.png","time_aod_8.png","time_aod_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 326,
              y: 63,
              w: 80,
              h: 80,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'alarm.png',
              normal_src: 'alarm.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'AlarmInfoScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 74,
              y: 63,
              w: 80,
              h: 80,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'transparent_img.png',
              normal_src: 'transparent_img.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PhoneHomeScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 326,
              y: 338,
              w: 80,
              h: 80,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'music.png',
              normal_src: 'music.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'MusicCommonScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 74,
              y: 338,
              w: 80,
              h: 80,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'sport.png',
              normal_src: 'sport.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'activityAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 15,
              y: 150,
              w: 90,
              h: 80,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'transparent_img.png',
              normal_src: 'transparent_img.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 375,
              y: 150,
              w: 90,
              h: 80,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'transparent_img.png',
              normal_src: 'transparent_img.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'activityWeekShowScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_7 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 15,
              y: 250,
              w: 90,
              h: 80,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'transparent_img.png',
              normal_src: 'transparent_img.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'Settings_batteryManagerScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_8 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 375,
              y: 250,
              w: 90,
              h: 80,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'transparent_img.png',
              normal_src: 'transparent_img.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'heart_app_Screen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            console.log('user_script_end.js');
            // start user_script_end.js

let screenType = hmSetting.getScreenType();
            // end user_script_end.js

            //#region time_update
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              console.log('day of week font');
              if (updateHour) {
                let normal_DOW_Str = normal_DOW_Array[timeSensor.week-1];
                normal_dow_text_font.setProperty(hmUI.prop.TEXT, normal_DOW_Str );
              };

              console.log('day font');
              if (updateHour) {
                let normal_dayStr = timeSensor.day.toString();
                normal_day_text_font.setProperty(hmUI.prop.TEXT, normal_dayStr );
              };

              console.log('day of week font');
              if (updateHour) {
                let idle_DOW_Str = idle_DOW_Array[timeSensor.week-1];
                idle_dow_text_font.setProperty(hmUI.prop.TEXT, idle_DOW_Str );
              };

              console.log('day font');
              if (updateHour) {
                let idle_dayStr = timeSensor.day.toString();
                idle_day_text_font.setProperty(hmUI.prop.TEXT, idle_dayStr );
              };

            };

            //#endregion
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                time_update(true, true);

                console.log('resume_call.js');
                // start resume_call.js

calls = CallHistoryReader.read();
let text = "-- No calls --";
let src = 'phone.png';
let src_aod = 'phone_aod.png';
if (calls.length > 0) {
    const lastCall = calls[0];
    // console.log(`name: ${lastCall.name}`);
    // console.log(`callType: ${lastCall.callType}`);
    // console.log(`callStatus: ${lastCall.callStatus}`);
    text = lastCall.name;

    switch (lastCall.callType) {
        case 0:
          src = 'incoming_call.png'
          src_aod = 'incoming_call.png'
          break
        case 1:
          src = 'outgoing_call.png'
          src_aod = 'outgoing_call.png'
          break
        case 2:
          src = 'missed_call.png'
          src_aod = 'missed_call.png'
          break
      }
}
if (screenType == hmSetting.screen_type.WATCHFACE) {
  if (normal_widget_text_1) normal_widget_text_1.setProperty(hmUI.prop.TEXT, text);
  if (normal_image_img) normal_image_img.setProperty(hmUI.prop.SRC, src);
}
else {
  if (idle_widget_text_1) idle_widget_text_1.setProperty(hmUI.prop.TEXT, text);
  if (idle_image_img) idle_image_img.setProperty(hmUI.prop.SRC, src_aod);
}
                // end resume_call.js

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
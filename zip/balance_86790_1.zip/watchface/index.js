﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_calorie_current_text_img = ''
        let normal_date_img_date_year = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_month_img = ''
        let normal_heart_rate_circle_scale_2 = ''
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_step_circle_scale = ''
        let normal_step_icon_img = ''
        let normal_step_current_text_img = ''
        let normal_date_img_date_week_img = ''
        let normal_battery_linear_scale = ''
        let normal_battery_icon_img = ''
        let normal_battery_text_text_img = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let idle_background_bg_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_date_img_date_year = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_week_img = ''
        let idle_battery_linear_scale = ''
        let idle_battery_icon_img = ''
        let idle_battery_text_text_img = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''
        let normal_step_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_battery_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'Quadrante_00.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 379,
              y: 146,
              src: 'Off_00.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 60,
              y: 141,
              src: 'Al_00.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 50,
              y: 301,
              font_array: ["Sistema_00.png","Sistema_01.png","Sistema_02.png","Sistema_03.png","Sistema_04.png","Sistema_05.png","Sistema_06.png","Sistema_07.png","Sistema_08.png","Sistema_09.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 284,
              year_startY: 107,
              year_sc_array: ["Sistema_00.png","Sistema_01.png","Sistema_02.png","Sistema_03.png","Sistema_04.png","Sistema_05.png","Sistema_06.png","Sistema_07.png","Sistema_08.png","Sistema_09.png"],
              year_tc_array: ["Sistema_00.png","Sistema_01.png","Sistema_02.png","Sistema_03.png","Sistema_04.png","Sistema_05.png","Sistema_06.png","Sistema_07.png","Sistema_08.png","Sistema_09.png"],
              year_en_array: ["Sistema_00.png","Sistema_01.png","Sistema_02.png","Sistema_03.png","Sistema_04.png","Sistema_05.png","Sistema_06.png","Sistema_07.png","Sistema_08.png","Sistema_09.png"],
              year_zero: 0,
              year_space: 5,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 202,
              day_startY: 60,
              day_sc_array: ["Sistema_00.png","Sistema_01.png","Sistema_02.png","Sistema_03.png","Sistema_04.png","Sistema_05.png","Sistema_06.png","Sistema_07.png","Sistema_08.png","Sistema_09.png"],
              day_tc_array: ["Sistema_00.png","Sistema_01.png","Sistema_02.png","Sistema_03.png","Sistema_04.png","Sistema_05.png","Sistema_06.png","Sistema_07.png","Sistema_08.png","Sistema_09.png"],
              day_en_array: ["Sistema_00.png","Sistema_01.png","Sistema_02.png","Sistema_03.png","Sistema_04.png","Sistema_05.png","Sistema_06.png","Sistema_07.png","Sistema_08.png","Sistema_09.png"],
              day_zero: 1,
              day_space: 4,
              day_align: hmUI.align.RIGHT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 120,
              month_startY: 107,
              month_sc_array: ["Mase_00.png","Mase_01.png","Mase_02.png","Mase_03.png","Mase_04.png","Mase_05.png","Mase_06.png","Mase_07.png","Mase_08.png","Mase_09.png","Mase_10.png","Mase_11.png"],
              month_tc_array: ["Mase_00.png","Mase_01.png","Mase_02.png","Mase_03.png","Mase_04.png","Mase_05.png","Mase_06.png","Mase_07.png","Mase_08.png","Mase_09.png","Mase_10.png","Mase_11.png"],
              month_en_array: ["Mase_00.png","Mase_01.png","Mase_02.png","Mase_03.png","Mase_04.png","Mase_05.png","Mase_06.png","Mase_07.png","Mase_08.png","Mase_09.png","Mase_10.png","Mase_11.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_circle_scale_2 = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 240,
              center_y: 240,
              start_angle: 158,
              end_angle: 122,
              radius: 201,
              line_width: 7,
              corner_flag: 0,
              type: hmUI.data_type.HEART,
              color: 0xFFFF0000,
              // mirror: False,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_circle_scale_2.setAlpha(164);

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 313,
              y: 345,
              src: 'BPM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 253,
              y: 301,
              font_array: ["Sistema_00.png","Sistema_01.png","Sistema_02.png","Sistema_03.png","Sistema_04.png","Sistema_05.png","Sistema_06.png","Sistema_07.png","Sistema_08.png","Sistema_09.png"],
              padding: false,
              h_space: 3,
              invalid_image: 'Sistema_10.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 240,
              // center_y: 240,
              // start_angle: 202,
              // end_angle: 238,
              // radius: 205,
              // line_width: 7,
              // line_cap: Rounded,
              // color: 0xFFFF4646,
              // mirror: False,
              // inversion: False,
              // alpha: 164,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            let screenType = hmSetting.getScreenType();
            normal_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 240,
              center_y: 240,
              start_angle: 202,
              end_angle: 238,
              radius: 202,
              line_width: 7,
              corner_flag: 0,
              color: 0xFFFF4646,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_circle_scale.setAlpha(164);
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 66,
              y: 346,
              src: 'Passi.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 142,
              y: 350,
              font_array: ["Sistema_00.png","Sistema_01.png","Sistema_02.png","Sistema_03.png","Sistema_04.png","Sistema_05.png","Sistema_06.png","Sistema_07.png","Sistema_08.png","Sistema_09.png"],
              padding: false,
              h_space: 4,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 0,
              y: 0,
              week_en: ["Giorno_00.png","Giorno_01.png","Giorno_02.png","Giorno_03.png","Giorno_04.png","Giorno_05.png","Giorno_06.png"],
              week_tc: ["Giorno_00.png","Giorno_01.png","Giorno_02.png","Giorno_03.png","Giorno_04.png","Giorno_05.png","Giorno_06.png"],
              week_sc: ["Giorno_00.png","Giorno_01.png","Giorno_02.png","Giorno_03.png","Giorno_04.png","Giorno_05.png","Giorno_06.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (screenType != hmSetting.screen_type.AOD) {
              normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);

            normal_battery_linear_scale.setAlpha(164);
            };

            // normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 206,
              // start_y: 406,
              // color: 0xFFFF5151,
              // lenght: 65,
              // line_width: 24,
              // line_cap: Flat,
              // vertical: False,
              // mirror: False,
              // inversion: False,
              // alpha: 164,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 200,
              y: 402,
              src: 'Batt_00.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 181,
              y: 443,
              font_array: ["Sistema_00.png","Sistema_01.png","Sistema_02.png","Sistema_03.png","Sistema_04.png","Sistema_05.png","Sistema_06.png","Sistema_07.png","Sistema_08.png","Sistema_09.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 44,
              hour_startY: 203,
              hour_array: ["Ore_00.png","Ore_01.png","Ore_02.png","Ore_03.png","Ore_04.png","Ore_05.png","Ore_06.png","Ore_07.png","Ore_08.png","Ore_09.png"],
              hour_zero: 1,
              hour_space: 6,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 259,
              minute_startY: 203,
              minute_array: ["Minuti_00.png","Minuti_01.png","Minuti_02.png","Minuti_03.png","Minuti_04.png","Minuti_05.png","Minuti_06.png","Minuti_07.png","Minuti_08.png","Minuti_09.png"],
              minute_zero: 1,
              minute_space: 6,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 285,
              second_startY: 147,
              second_array: ["Sistema_00.png","Sistema_01.png","Sistema_02.png","Sistema_03.png","Sistema_04.png","Sistema_05.png","Sistema_06.png","Sistema_07.png","Sistema_08.png","Sistema_09.png"],
              second_zero: 1,
              second_space: 4,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.RIGHT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 232,
              y: 203,
              src: 'Ore_10.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'Quadrante_01.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 379,
              y: 146,
              src: 'Off_00.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 60,
              y: 141,
              src: 'Al_00.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 284,
              year_startY: 107,
              year_sc_array: ["Sistema_00.png","Sistema_01.png","Sistema_02.png","Sistema_03.png","Sistema_04.png","Sistema_05.png","Sistema_06.png","Sistema_07.png","Sistema_08.png","Sistema_09.png"],
              year_tc_array: ["Sistema_00.png","Sistema_01.png","Sistema_02.png","Sistema_03.png","Sistema_04.png","Sistema_05.png","Sistema_06.png","Sistema_07.png","Sistema_08.png","Sistema_09.png"],
              year_en_array: ["Sistema_00.png","Sistema_01.png","Sistema_02.png","Sistema_03.png","Sistema_04.png","Sistema_05.png","Sistema_06.png","Sistema_07.png","Sistema_08.png","Sistema_09.png"],
              year_zero: 0,
              year_space: 5,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 202,
              day_startY: 60,
              day_sc_array: ["Sistema_00.png","Sistema_01.png","Sistema_02.png","Sistema_03.png","Sistema_04.png","Sistema_05.png","Sistema_06.png","Sistema_07.png","Sistema_08.png","Sistema_09.png"],
              day_tc_array: ["Sistema_00.png","Sistema_01.png","Sistema_02.png","Sistema_03.png","Sistema_04.png","Sistema_05.png","Sistema_06.png","Sistema_07.png","Sistema_08.png","Sistema_09.png"],
              day_en_array: ["Sistema_00.png","Sistema_01.png","Sistema_02.png","Sistema_03.png","Sistema_04.png","Sistema_05.png","Sistema_06.png","Sistema_07.png","Sistema_08.png","Sistema_09.png"],
              day_zero: 1,
              day_space: 4,
              day_align: hmUI.align.RIGHT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 120,
              month_startY: 107,
              month_sc_array: ["Mase_00.png","Mase_01.png","Mase_02.png","Mase_03.png","Mase_04.png","Mase_05.png","Mase_06.png","Mase_07.png","Mase_08.png","Mase_09.png","Mase_10.png","Mase_11.png"],
              month_tc_array: ["Mase_00.png","Mase_01.png","Mase_02.png","Mase_03.png","Mase_04.png","Mase_05.png","Mase_06.png","Mase_07.png","Mase_08.png","Mase_09.png","Mase_10.png","Mase_11.png"],
              month_en_array: ["Mase_00.png","Mase_01.png","Mase_02.png","Mase_03.png","Mase_04.png","Mase_05.png","Mase_06.png","Mase_07.png","Mase_08.png","Mase_09.png","Mase_10.png","Mase_11.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 0,
              y: 0,
              week_en: ["Giorno_00.png","Giorno_01.png","Giorno_02.png","Giorno_03.png","Giorno_04.png","Giorno_05.png","Giorno_06.png"],
              week_tc: ["Giorno_00.png","Giorno_01.png","Giorno_02.png","Giorno_03.png","Giorno_04.png","Giorno_05.png","Giorno_06.png"],
              week_sc: ["Giorno_00.png","Giorno_01.png","Giorno_02.png","Giorno_03.png","Giorno_04.png","Giorno_05.png","Giorno_06.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            if (screenType == hmSetting.screen_type.AOD) {
              idle_battery_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);

            idle_battery_linear_scale.setAlpha(164);
            };

            // idle_battery_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 206,
              // start_y: 406,
              // color: 0xFFFF5151,
              // lenght: 65,
              // line_width: 24,
              // line_cap: Flat,
              // vertical: False,
              // mirror: False,
              // inversion: False,
              // alpha: 164,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 200,
              y: 402,
              src: 'Batt_00.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 181,
              y: 443,
              font_array: ["Sistema_00.png","Sistema_01.png","Sistema_02.png","Sistema_03.png","Sistema_04.png","Sistema_05.png","Sistema_06.png","Sistema_07.png","Sistema_08.png","Sistema_09.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 44,
              hour_startY: 203,
              hour_array: ["Ore_00.png","Ore_01.png","Ore_02.png","Ore_03.png","Ore_04.png","Ore_05.png","Ore_06.png","Ore_07.png","Ore_08.png","Ore_09.png"],
              hour_zero: 1,
              hour_space: 6,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 259,
              minute_startY: 203,
              minute_array: ["Minuti_00.png","Minuti_01.png","Minuti_02.png","Minuti_03.png","Minuti_04.png","Minuti_05.png","Minuti_06.png","Minuti_07.png","Minuti_08.png","Minuti_09.png"],
              minute_zero: 1,
              minute_space: 6,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 232,
              y: 203,
              src: 'Ore_10.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 133,
              y: 340,
              w: 209,
              h: 51,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 343,
              y: 292,
              w: 100,
              h: 100,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 189,
              y: 392,
              w: 100,
              h: 100,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 289,
              y: 134,
              w: 100,
              h: 67,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 189,
              y: 192,
              w: 100,
              h: 100,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 15,
              y: 102,
              w: 100,
              h: 100,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            function scale_call() {
              console.log('scale_call()');

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_cs_normal_step = progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_step * 100);
                  if (normal_step_circle_scale) {
                    normal_step_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 240,
                      center_y: 240,
                      start_angle: 202,
                      end_angle: 238,
                      radius: 202,
                      line_width: 7,
                      corner_flag: 0,
                      color: 0xFFFF4646,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_ls_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_linear_scale
                  // initial parameters
                  let start_x_normal_battery = 206;
                  let start_y_normal_battery = 406;
                  let lenght_ls_normal_battery = 65;
                  let line_width_ls_normal_battery = 24;
                  let color_ls_normal_battery = 0xFFFF5151;
                  
                  // calculated parameters
                  let start_x_normal_battery_draw = start_x_normal_battery;
                  let start_y_normal_battery_draw = start_y_normal_battery;
                  lenght_ls_normal_battery = lenght_ls_normal_battery * progress_ls_normal_battery;
                  let lenght_ls_normal_battery_draw = lenght_ls_normal_battery;
                  let line_width_ls_normal_battery_draw = line_width_ls_normal_battery;
                  if (lenght_ls_normal_battery < 0){
                    lenght_ls_normal_battery_draw = -lenght_ls_normal_battery;
                    start_x_normal_battery_draw = start_x_normal_battery - lenght_ls_normal_battery_draw;
                  };
                  
                  normal_battery_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_battery_draw,
                    y: start_y_normal_battery_draw,
                    w: lenght_ls_normal_battery_draw,
                    h: line_width_ls_normal_battery_draw,
                    color: color_ls_normal_battery,
                  });
                };

                console.log('update scales BATTERY');
                let progress_ls_idle_battery = progressBattery;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_battery_linear_scale
                  // initial parameters
                  let start_x_idle_battery = 206;
                  let start_y_idle_battery = 406;
                  let lenght_ls_idle_battery = 65;
                  let line_width_ls_idle_battery = 24;
                  let color_ls_idle_battery = 0xFFFF5151;
                  
                  // calculated parameters
                  let start_x_idle_battery_draw = start_x_idle_battery;
                  let start_y_idle_battery_draw = start_y_idle_battery;
                  lenght_ls_idle_battery = lenght_ls_idle_battery * progress_ls_idle_battery;
                  let lenght_ls_idle_battery_draw = lenght_ls_idle_battery;
                  let line_width_ls_idle_battery_draw = line_width_ls_idle_battery;
                  if (lenght_ls_idle_battery < 0){
                    lenght_ls_idle_battery_draw = -lenght_ls_idle_battery;
                    start_x_idle_battery_draw = start_x_idle_battery - lenght_ls_idle_battery_draw;
                  };
                  
                  idle_battery_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_idle_battery_draw,
                    y: start_y_idle_battery_draw,
                    w: lenght_ls_idle_battery_draw,
                    h: line_width_ls_idle_battery_draw,
                    color: color_ls_idle_battery,
                  });
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

        // смена фона
        let mask_img = ''
        let btn_mask = ''
        let mask_num = 1
        let mask_all = 4          
        function click_mask() {
           if(mask_num>=mask_all) {mask_num=1;}
            else { mask_num=mask_num+1;}
            hmUI.showToast({text: "<Цвет> " + parseInt(mask_num) });
            normal_background_bg_img.setProperty(hmUI.prop.SRC, "mask_" + parseInt(mask_num) + ".png");
            //normal_heart_rate_icon_img.setProperty(hmUI.prop.SRC, "color_" + parseInt(mask_num) + ".png");
            }
        
             
       
        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_image_img = ''
        let normal_pai_icon_img = ''
        let normal_system_dnd_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_temperature_icon_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_high_text_font = ''
        let normal_temperature_low_text_font = ''
        let normal_temperature_current_text_font = ''
        let normal_group_ForecastWeather = ''
        let normal_forecast_average_text_font = new Array(3);
        let normal_forecast_image_progress_img_level = new Array(3);
        let normal_forecast_image_array = ['wz_1.png', 'wz_2.png', 'wz_3.png', 'wz_4.png', 'wz_5.png', 'wz_6.png', 'wz_7.png', 'wz_8.png', 'wz_9.png', 'wz_10.png', 'wz_11.png', 'wz_12.png', 'wz_13.png', 'wz_14.png', 'wz_15.png', 'wz_16.png', 'wz_17.png', 'wz_18.png', 'wz_19.png', 'wz_20.png', 'wz_21.png', 'wz_22.png', 'wz_23.png', 'wz_24.png', 'wz_25.png', 'wz_26.png', 'wz_27.png', 'wz_28.png', 'wz_29.png'];
        let normal_battery_circle_scale = ''
        let normal_battery_current_text_font = ''
        let normal_day_text_font = ''
        let normal_date_img_date_week_img = ''
        let normal_distance_icon_img = ''
        let normal_distance_current_text_font = ''
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_text_font = ''
        let normal_step_icon_img = ''
        let normal_step_current_text_font = ''
        let normal_digital_clock_img_time = ''
        let normal_time_second_text_font = ''
        let normal_timerTimeUpdate = undefined;
        let idle_system_dnd_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_digital_clock_img_time = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let Button_7 = ''
        let Button_8 = ''
        let Button_9 = ''
        let Button_10 = ''
        let Button_11 = ''
        let timeSensor = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            // FontName: wfs_ofontru_solomonsans_690a71fd_de75_4ba1_ac75_0eaf156f2d24.ttf; FontSize: 24
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 334,
              h: 34,
              text_size: 24,
              char_space: 0,
              line_space: 0,
              font: 'fonts/wfs_ofontru_solomonsans_690a71fd_de75_4ba1_ac75_0eaf156f2d24.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.RIGHT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: wfs_ofontru_solomonsans_690a71fd_de75_4ba1_ac75_0eaf156f2d24.ttf; FontSize: 31
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 450,
              h: 45,
              text_size: 31,
              char_space: 0,
              line_space: 0,
              font: 'fonts/wfs_ofontru_solomonsans_690a71fd_de75_4ba1_ac75_0eaf156f2d24.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: wfs_ofontru_solomonsans_690a71fd_de75_4ba1_ac75_0eaf156f2d24.ttf; FontSize: 26
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 378,
              h: 38,
              text_size: 26,
              char_space: 0,
              line_space: 0,
              font: 'fonts/wfs_ofontru_solomonsans_690a71fd_de75_4ba1_ac75_0eaf156f2d24.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: wfs_ofontru_solomonsans_690a71fd_de75_4ba1_ac75_0eaf156f2d24.ttf; FontSize: 46
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 657,
              h: 67,
              text_size: 46,
              char_space: 0,
              line_space: 0,
              font: 'fonts/wfs_ofontru_solomonsans_690a71fd_de75_4ba1_ac75_0eaf156f2d24.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: Oswald-Medium.ttf; FontSize: 23; Cache: full
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 27,
              h: 27,
              text_size: 23,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Oswald-Medium.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.NONE,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: Oswald-Medium.ttf; FontSize: 22
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 289,
              h: 46,
              text_size: 22,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Oswald-Medium.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: wfs_ofontru_solomonsans_690a71fd_de75_4ba1_ac75_0eaf156f2d24.ttf; FontSize: 51
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 728,
              h: 75,
              text_size: 51,
              char_space: 0,
              line_space: 0,
              font: 'fonts/wfs_ofontru_solomonsans_690a71fd_de75_4ba1_ac75_0eaf156f2d24.ttf',
              color: 0xFF040200,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'mask_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'bg_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'mask_org.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 298,
              y: 215,
              src: 'DND.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 261,
              y: 208,
              src: 'status_bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 215,
              y: 210,
              src: 'status_clock.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 107,
              y: 56,
              image_array: ["67.png","68.png","69.png","70.png","71.png","72.png","73.png","74.png","75.png","76.png","77.png","78.png","79.png","80.png","81.png","82.png","83.png","84.png","85.png","86.png","87.png","88.png","89.png","90.png","91.png","92.png","93.png","94.png","95.png","96.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'mask_org.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 344,
              y: 179,
              image_array: ["wz_1.png","wz_2.png","wz_3.png","wz_4.png","wz_5.png","wz_6.png","wz_7.png","wz_8.png","wz_9.png","wz_10.png","wz_11.png","wz_12.png","wz_13.png","wz_14.png","wz_15.png","wz_16.png","wz_17.png","wz_18.png","wz_19.png","wz_20.png","wz_21.png","wz_22.png","wz_23.png","wz_24.png","wz_25.png","wz_26.png","wz_27.png","wz_28.png","wz_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 288,
              y: 215,
              w: 150,
              h: 30,
              text_size: 24,
              char_space: 0,
              line_space: 0,
              font: 'fonts/wfs_ofontru_solomonsans_690a71fd_de75_4ba1_ac75_0eaf156f2d24.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.RIGHT,
              align_v: hmUI.align.TOP,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 334,
              y: 215,
              w: 150,
              h: 30,
              text_size: 24,
              char_space: 0,
              line_space: 0,
              font: 'fonts/wfs_ofontru_solomonsans_690a71fd_de75_4ba1_ac75_0eaf156f2d24.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.RIGHT,
              align_v: hmUI.align.TOP,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 362,
              y: 183,
              w: 150,
              h: 30,
              text_size: 31,
              char_space: 0,
              line_space: 0,
              font: 'fonts/wfs_ofontru_solomonsans_690a71fd_de75_4ba1_ac75_0eaf156f2d24.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();            
            // normal_Weather_FewDays = hmUI.createWidget(hmUI.widget.FewDays, {
              // x: 198,
              // y: 44,
              // ColumnWidth: 60,
              // DaysCount: 3,
            // });
            
            normal_group_ForecastWeather = hmUI.createWidget(hmUI.widget.GROUP, {
              x: 198,
              y: 44,
              h: 0,
              w: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_forecast_average_text_font = normal_group_ForecastWeather.createWidget(hmUI.widget.TEXT_Options, {
              // x: -33,
              // y: 97,
              // w: 125,
              // h: 39,
              // text_size: 26,
              // char_space: 0,
              // line_space: 0,
              // alpha: 255,
              // font: 'fonts/wfs_ofontru_solomonsans_690a71fd_de75_4ba1_ac75_0eaf156f2d24.ttf',
              // color: 0xFFFFFFFF,
              // color_2: 0xFFFF0000,
              // use_color_2: False,
              // align_h: hmUI.align.CENTER_H,
              // align_v: hmUI.align.TOP,
              // text_style: hmUI.text_style.ELLIPSIS,
              // type: hmUI.data_type.forecast_average_text_font,
              // unit_type: 1,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            //start of ignored block
            if (screenType == hmSetting.screen_type.WATCHFACE) {
              for (let i = 0; i < 3; i++) {
                normal_forecast_average_text_font[i] = normal_group_ForecastWeather.createWidget(hmUI.widget.TEXT, {
                  x: -33 + i*60,
                  y: 97,
                  w: 125,
                  h: 39,
                  text_size: 26,
                  char_space: 0,
                  line_space: 0,
                  font: 'fonts/wfs_ofontru_solomonsans_690a71fd_de75_4ba1_ac75_0eaf156f2d24.ttf',
                  color: 0xFFFFFFFF,
                  align_h: hmUI.align.CENTER_H,
                  align_v: hmUI.align.TOP,
                  text_style: hmUI.text_style.ELLIPSIS,
                  // unit_type: 1,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
              };
            };
            //end of ignored block

            // normal_forecast_image_progress_img_level = normal_group_ForecastWeather.createWidget(hmUI.widget.IMG_LEVEL_Options, {
              // x: 1,
              // y: 39,
              // image_array: ["wz_1.png","wz_2.png","wz_3.png","wz_4.png","wz_5.png","wz_6.png","wz_7.png","wz_8.png","wz_9.png","wz_10.png","wz_11.png","wz_12.png","wz_13.png","wz_14.png","wz_15.png","wz_16.png","wz_17.png","wz_18.png","wz_19.png","wz_20.png","wz_21.png","wz_22.png","wz_23.png","wz_24.png","wz_25.png","wz_26.png","wz_27.png","wz_28.png","wz_29.png"],
              // image_length: 29,
              // type: hmUI.data_type.forecast_image,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            //start of ignored block
            if (screenType == hmSetting.screen_type.WATCHFACE) {
              for (let i = 0; i < 3; i++) {
                normal_forecast_image_progress_img_level[i] = normal_group_ForecastWeather.createWidget(hmUI.widget.IMG, {
                  x: 1 + i*60,
                  y: 39,
                  src: normal_forecast_image_array[25],
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
              };
            };
            //end of ignored block

            // normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 240,
              // center_y: 240,
              // start_angle: 191,
              // end_angle: 167,
              // radius: 230,
              // line_width: 8,
              // line_cap: Rounded,
              // color: 0xFF25DA5B,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 240,
              center_y: 240,
              start_angle: 191,
              end_angle: 167,
              radius: 226,
              line_width: 8,
              corner_flag: 0,
              color: 0xFF25DA5B,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 224,
              y: 429,
              w: 150,
              h: 39,
              text_size: 24,
              char_space: 0,
              line_space: 0,
              font: 'fonts/wfs_ofontru_solomonsans_690a71fd_de75_4ba1_ac75_0eaf156f2d24.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function() {
              time_update(true);
            });

            normal_day_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 159,
              y: 257,
              w: 150,
              h: 71,
              text_size: 46,
              char_space: 0,
              line_space: 0,
              font: 'fonts/wfs_ofontru_solomonsans_690a71fd_de75_4ba1_ac75_0eaf156f2d24.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 263,
              y: 263,
              week_en: ["dn_1.png","dn_2.png","dn_3.png","dn_4.png","dn_5.png","dn_6.png","dn_7.png"],
              week_tc: ["dn_1.png","dn_2.png","dn_3.png","dn_4.png","dn_5.png","dn_6.png","dn_7.png"],
              week_sc: ["dn_1.png","dn_2.png","dn_3.png","dn_4.png","dn_5.png","dn_6.png","dn_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 268,
              y: 347,
              src: 'maps.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 335,
              y: 346,
              w: 150,
              h: 30,
              text_size: 23,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Oswald-Medium.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 241,
              y: 390,
              src: 'puls.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 260,
              y: 387,
              w: 150,
              h: 30,
              text_size: 22,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Oswald-Medium.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 283,
              y: 295,
              src: 'steps.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 315,
              y: 306,
              w: 150,
              h: 30,
              text_size: 22,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Oswald-Medium.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 20,
              hour_startY: 115,
              hour_array: ["num_0.png","num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png"],
              hour_zero: 1,
              hour_space: -20,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 20,
              minute_startY: 244,
              minute_array: ["num_0.png","num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png"],
              minute_zero: 1,
              minute_space: -20,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_time_second_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 55,
              y: 371,
              w: 150,
              h: 68,
              text_size: 51,
              char_space: 0,
              line_space: 0,
              font: 'fonts/wfs_ofontru_solomonsans_690a71fd_de75_4ba1_ac75_0eaf156f2d24.ttf',
              color: 0xFF040200,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');

            idle_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 234,
              y: 215,
              src: 'DND.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 198,
              y: 208,
              src: 'status_bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 156,
              y: 210,
              src: 'status_clock.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 280,
              hour_startY: 115,
              hour_array: ["anum_0.png","anum_1.png","anum_2.png","anum_3.png","anum__4.png","anum__5.png","anum__6.png","anum__7.png","anum__8.png","anum__9.png"],
              hour_zero: 1,
              hour_space: -20,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 280,
              minute_startY: 244,
              minute_array: ["anum_0.png","anum_1.png","anum_2.png","anum_3.png","anum__4.png","anum__5.png","anum__6.png","anum__7.png","anum__8.png","anum__9.png"],
              minute_zero: 1,
              minute_space: -20,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 207,
              y: 86,
              w: 152,
              h: 90,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'null.png',
              normal_src: 'null.png',
              click_func: (button_widget) => {
                hmApp.startApp({ appid: 1051195, url: 'page/index', params: { from_wf: true} });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 352,
              y: 184,
              w: 115,
              h: 72,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'null.png',
              normal_src: 'null.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'WeatherScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 280,
              y: 387,
              w: 100,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'null.png',
              normal_src: 'null.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'heart_app_Screen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 324,
              y: 298,
              w: 100,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'null.png',
              normal_src: 'null.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'activityAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 311,
              y: 342,
              w: 100,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'null.png',
              normal_src: 'null.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'spo_HomeScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 206,
              y: 259,
              w: 76,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'null.png',
              normal_src: 'null.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_7 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 91,
              y: 52,
              w: 76,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'null.png',
              normal_src: 'null.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'TideScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_8 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 50,
              y: 125,
              w: 95,
              h: 100,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'null.png',
              normal_src: 'null.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'StopWatchScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_9 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 50,
              y: 251,
              w: 95,
              h: 100,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'null.png',
              normal_src: 'null.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'CountdownAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_10 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 197,
              y: 434,
              w: 100,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'null.png',
              normal_src: 'null.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PowerSaveHintScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_11 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 84,
              y: 366,
              w: 91,
              h: 63,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'null.png',
              normal_src: 'null.png',
              click_func: (button_widget) => {
                click_mask();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);
            //start of ignored block
            function weather_few_days() {
              console.log('weather_few_days()');
              let weatherData = weatherSensor.getForecastWeather();
              let forecastData = weatherData.forecastData;

              for (let i = 0; i < 3; i++) {
                // Number_Font_Average
                let averageTemperature = '-';
                if (i < forecastData.count) averageTemperature = parseInt((forecastData.data[i].high + forecastData.data[i].low)/2).toString();
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  normal_forecast_average_text_font[i].setProperty(hmUI.prop.TEXT, averageTemperature + '°');
                };
                
                // Images
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  let weatherIndex = 25
                  if (i < forecastData.count) weatherIndex = forecastData.data[i].index;
                  normal_forecast_image_progress_img_level[i].setProperty(hmUI.prop.SRC, normal_forecast_image_array[weatherIndex]);
                };
              
              };  // end for

            };
            //end of ignored block

            //start of ignored block
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              console.log('day font');
              if (updateHour) {
                let normal_dayStr = timeSensor.day.toString();
                normal_day_text_font.setProperty(hmUI.prop.TEXT, normal_dayStr );
              };

              console.log('second font');
                let normal_secondStr = second.toString();
                normal_secondStr = normal_secondStr.padStart(2, '0');
                normal_time_second_text_font.setProperty(hmUI.prop.TEXT, normal_secondStr );
            };

            //end of ignored block
            function scale_call() {
              console.log('scale_call()');

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_cs_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_battery * 100);
                  if (normal_battery_circle_scale) {
                    normal_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 240,
                      center_y: 240,
                      start_angle: 191,
                      end_angle: 167,
                      radius: 226,
                      line_width: 8,
                      corner_flag: 0,
                      color: 0xFF25DA5B,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                time_update(true, true);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerTimeUpdate) {
                    normal_timerTimeUpdate = timer.createTimer(0, 1000, (function (option) {
                      let updateHour = timeSensor.minute == 0 && timeSensor.second < 2;
                      let updateMinute = timeSensor.second < 2;
                      time_update(updateHour, updateMinute);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


                weather_few_days();
              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerTimeUpdate) {
                  timer.stopTimer(normal_timerTimeUpdate);
                  normal_timerTimeUpdate = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
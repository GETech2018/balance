﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

var activeColor = -1;
var colors = [
    "Z E L E N A",
    "R U Z O V A",
    "S V E T L E - M O D R A",
    "M O D R A"
];

function click_Color() {
    activeColor++;

    if(activeColor >= colors.length) {
        activeColor = 0;
    }

    hmUI.showToast({text: colors[activeColor] });
    normal_background_bg_img.setProperty(hmUI.prop.SRC, "color_" + parseInt(activeColor + 1) + ".png");
}

        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_image_img = ''
        let normal_rotate_animation_img_1 = '';
        let normal_rotate_animation_param_1 = null;
        let normal_rotate_animation_lastTime_1 = 0;
        let timer_anim_rotate_1;
        let normal_rotate_animation_count_1 = 0;
        let normal_rotate_animation_img_2 = '';
        let normal_rotate_animation_param_2 = null;
        let normal_rotate_animation_lastTime_2 = 0;
        let timer_anim_rotate_2;
        let normal_rotate_animation_count_2 = 0;
        let normal_system_lock_img = ''
        let normal_system_dnd_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_sunrise_TextRotate = new Array(5);
        let normal_sunrise_TextRotate_ASCIIARRAY = new Array(10);
        let normal_sunrise_TextRotate_img_width = 17;
        let normal_sunrise_TextRotate_dot_width = 5;
        let normal_sunrise_TextRotate_error_img_width = 1;
        let normal_sunset_TextRotate = new Array(5);
        let normal_sunset_TextRotate_ASCIIARRAY = new Array(10);
        let normal_sunset_TextRotate_img_width = 17;
        let normal_sunset_TextRotate_dot_width = 5;
        let normal_sunset_TextRotate_error_img_width = 1;
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_high_TextRotate = new Array(4);
        let normal_temperature_high_TextRotate_ASCIIARRAY = new Array(10);
        let normal_temperature_high_TextRotate_img_width = 17;
        let normal_temperature_high_TextRotate_unit = null;
        let normal_temperature_high_TextRotate_unit_width = 17;
        let normal_temperature_high_TextRotate_dot_width = 17;
        let normal_temperature_high_TextRotate_error_img_width = 1;
        let normal_temperature_low_TextRotate = new Array(4);
        let normal_temperature_low_TextRotate_ASCIIARRAY = new Array(10);
        let normal_temperature_low_TextRotate_img_width = 17;
        let normal_temperature_low_TextRotate_unit = null;
        let normal_temperature_low_TextRotate_unit_width = 17;
        let normal_temperature_low_TextRotate_dot_width = 17;
        let normal_temperature_low_TextRotate_error_img_width = 1;
        let normal_temperature_current_TextRotate = new Array(4);
        let normal_temperature_current_TextRotate_ASCIIARRAY = new Array(10);
        let normal_temperature_current_TextRotate_img_width = 17;
        let normal_temperature_current_TextRotate_unit = null;
        let normal_temperature_current_TextRotate_unit_width = 17;
        let normal_temperature_current_TextRotate_dot_width = 17;
        let normal_temperature_current_TextRotate_error_img_width = 1;
        let normal_battery_text_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_pai_weekly_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_step_current_text_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month_img = ''
        let normal_day_TextRotate = new Array(2);
        let normal_day_TextRotate_ASCIIARRAY = new Array(10);
        let normal_day_TextRotate_img_width = 18;
        let normal_day_TextRotate_error_img_width = 1;
        let normal_timerTextUpdate = undefined;
        let normal_hour_TextRotate = new Array(2);
        let normal_hour_TextRotate_ASCIIARRAY = new Array(10);
        let normal_hour_TextRotate_img_width = 40;
        let normal_hour_TextRotate_unit = null;
        let normal_hour_TextRotate_unit_width = 15;
        let normal_hour_TextRotate_error_img_width = 1;
        let normal_minute_TextRotate = new Array(2);
        let normal_minute_TextRotate_ASCIIARRAY = new Array(10);
        let normal_minute_TextRotate_img_width = 40;
        let normal_minute_TextRotate_unit = null;
        let normal_minute_TextRotate_unit_width = 15;
        let normal_minute_TextRotate_error_img_width = 1;
        let normal_second_TextRotate = new Array(2);
        let normal_second_TextRotate_ASCIIARRAY = new Array(10);
        let normal_second_TextRotate_img_width = 40;
        let normal_second_TextRotate_error_img_width = 1;
        let idle_background_bg_img = ''
        let idle_image_img = ''
        let idle_system_lock_img = ''
        let idle_system_dnd_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_sunrise_TextRotate = new Array(5);
        let idle_sunrise_TextRotate_ASCIIARRAY = new Array(10);
        let idle_sunrise_TextRotate_img_width = 17;
        let idle_sunrise_TextRotate_dot_width = 5;
        let idle_sunrise_TextRotate_error_img_width = 1;
        let idle_sunset_TextRotate = new Array(5);
        let idle_sunset_TextRotate_ASCIIARRAY = new Array(10);
        let idle_sunset_TextRotate_img_width = 17;
        let idle_sunset_TextRotate_dot_width = 5;
        let idle_sunset_TextRotate_error_img_width = 1;
        let idle_weather_image_progress_img_level = ''
        let idle_temperature_high_TextRotate = new Array(4);
        let idle_temperature_high_TextRotate_ASCIIARRAY = new Array(10);
        let idle_temperature_high_TextRotate_img_width = 17;
        let idle_temperature_high_TextRotate_unit = null;
        let idle_temperature_high_TextRotate_unit_width = 17;
        let idle_temperature_high_TextRotate_dot_width = 17;
        let idle_temperature_high_TextRotate_error_img_width = 1;
        let idle_temperature_low_TextRotate = new Array(4);
        let idle_temperature_low_TextRotate_ASCIIARRAY = new Array(10);
        let idle_temperature_low_TextRotate_img_width = 17;
        let idle_temperature_low_TextRotate_unit = null;
        let idle_temperature_low_TextRotate_unit_width = 17;
        let idle_temperature_low_TextRotate_dot_width = 17;
        let idle_temperature_low_TextRotate_error_img_width = 1;
        let idle_temperature_current_TextRotate = new Array(4);
        let idle_temperature_current_TextRotate_ASCIIARRAY = new Array(10);
        let idle_temperature_current_TextRotate_img_width = 17;
        let idle_temperature_current_TextRotate_unit = null;
        let idle_temperature_current_TextRotate_unit_width = 17;
        let idle_temperature_current_TextRotate_dot_width = 17;
        let idle_temperature_current_TextRotate_error_img_width = 1;
        let idle_battery_text_text_img = ''
        let idle_distance_text_text_img = ''
        let idle_pai_weekly_text_img = ''
        let idle_heart_rate_text_text_img = ''
        let idle_calorie_current_text_img = ''
        let idle_step_current_text_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_month_img = ''
        let idle_day_TextRotate = new Array(2);
        let idle_day_TextRotate_ASCIIARRAY = new Array(10);
        let idle_day_TextRotate_img_width = 18;
        let idle_day_TextRotate_error_img_width = 1;
        let idle_timerTextUpdate = undefined;
        let idle_hour_TextRotate = new Array(2);
        let idle_hour_TextRotate_ASCIIARRAY = new Array(10);
        let idle_hour_TextRotate_img_width = 40;
        let idle_hour_TextRotate_unit = null;
        let idle_hour_TextRotate_unit_width = 15;
        let idle_hour_TextRotate_error_img_width = 1;
        let idle_minute_TextRotate = new Array(2);
        let idle_minute_TextRotate_ASCIIARRAY = new Array(10);
        let idle_minute_TextRotate_img_width = 40;
        let idle_minute_TextRotate_unit = null;
        let idle_minute_TextRotate_unit_width = 15;
        let idle_minute_TextRotate_error_img_width = 1;
        let idle_second_TextRotate = new Array(2);
        let idle_second_TextRotate_ASCIIARRAY = new Array(10);
        let idle_second_TextRotate_img_width = 40;
        let idle_second_TextRotate_error_img_width = 1;
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let Button_7 = ''
        let Button_8 = ''
        let Button_9 = ''
        let timeSensor = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'background.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'image.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_rotate_animation_img_1 = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 481,
              h: 481,
              pos_x: 355,
              pos_y: 382,
              center_x: 367,
              center_y: 394,
              angle: 0,
              src: 'animation/ring_0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_rotate_animation_param_1 = {
              anim_steps: [{
                anim_rate: 'linear',
                anim_duration: 15000,
                anim_from: 0,
                anim_to: 360,
                anim_key: "angle",
              }],
              anim_fps: 15,
              anim_auto_start: 1,
              anim_repeat: 0,
              anim_auto_destroy: 1,
            };

            let now = hmSensor.createSensor(hmSensor.id.TIME);

            function anim_rotate_1_complete_call() {
              normal_rotate_animation_img_1.setProperty(hmUI.prop.ANIM, normal_rotate_animation_param_1);
              normal_rotate_animation_lastTime_1 = now.utc;
              normal_rotate_animation_count_1 = normal_rotate_animation_count_1 - 1;
              if(normal_rotate_animation_count_1 < -1) normal_rotate_animation_count_1 = - 1;
              if(normal_rotate_animation_count_1 == 0) stop_anim_rotate_1();
            }; // end animation callback function
            
            function stop_anim_rotate_1() {
              if (timer_anim_rotate_1) {
                timer.stopTimer(timer_anim_rotate_1);
                timer_anim_rotate_1 = undefined;
              };
            }; // end stop_anim_rotate function

            // normal_rotate_anime_1 = hmUI.createWidget(hmUI.widget.Rotate_Animation, {
              // start_angle: 0,
              // end_angle: 360,
              // pos_x: 12,
              // pos_y: 12,
              // center_x: 367,
              // center_y: 394,
              // src: 'ring_0.png',
              // anim_fps: 15,
              // anim_duration: 15000,
              // repeat_count: 0,
              // anim_two_sides: False,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_rotate_animation_img_2 = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 481,
              h: 481,
              pos_x: 374,
              pos_y: 386,
              center_x: 386,
              center_y: 398,
              angle: 360,
              src: 'animation/ring1_0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_rotate_animation_param_2 = {
              anim_steps: [{
                anim_rate: 'linear',
                anim_duration: 15000,
                anim_from: 360,
                anim_to: 0,
                anim_key: "angle",
              }],
              anim_fps: 15,
              anim_auto_start: 1,
              anim_repeat: 0,
              anim_auto_destroy: 1,
            };

            function anim_rotate_2_complete_call() {
              normal_rotate_animation_img_2.setProperty(hmUI.prop.ANIM, normal_rotate_animation_param_2);
              normal_rotate_animation_lastTime_2 = now.utc;
              normal_rotate_animation_count_2 = normal_rotate_animation_count_2 - 1;
              if(normal_rotate_animation_count_2 < -1) normal_rotate_animation_count_2 = - 1;
              if(normal_rotate_animation_count_2 == 0) stop_anim_rotate_2();
            }; // end animation callback function
            
            function stop_anim_rotate_2() {
              if (timer_anim_rotate_2) {
                timer.stopTimer(timer_anim_rotate_2);
                timer_anim_rotate_2 = undefined;
              };
            }; // end stop_anim_rotate function

            // normal_rotate_anime_2 = hmUI.createWidget(hmUI.widget.Rotate_Animation, {
              // start_angle: 360,
              // end_angle: 0,
              // pos_x: 12,
              // pos_y: 12,
              // center_x: 386,
              // center_y: 398,
              // src: 'ring1_0.png',
              // anim_fps: 15,
              // anim_duration: 15000,
              // repeat_count: 0,
              // anim_two_sides: False,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 287,
              y: 365,
              src: 'status.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 245,
              y: 350,
              src: 'status.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 149,
              y: 311,
              src: 'bt_off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 203,
              y: 335,
              src: 'status.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_sunrise_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 152,
              // y: 396,
              // font_array: ["act_0.png","act_1.png","act_2.png","act_3.png","act_4.png","act_5.png","act_6.png","act_7.png","act_8.png","act_9.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: 19,
              // negative_image: 'pointer_1.png',
              // invalid_image: 'dot.png',
              // dot_image: 'pointer_1.png',
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.SUN_RISE,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_sunrise_TextRotate_ASCIIARRAY[0] = 'act_0.png';  // set of images with numbers
            normal_sunrise_TextRotate_ASCIIARRAY[1] = 'act_1.png';  // set of images with numbers
            normal_sunrise_TextRotate_ASCIIARRAY[2] = 'act_2.png';  // set of images with numbers
            normal_sunrise_TextRotate_ASCIIARRAY[3] = 'act_3.png';  // set of images with numbers
            normal_sunrise_TextRotate_ASCIIARRAY[4] = 'act_4.png';  // set of images with numbers
            normal_sunrise_TextRotate_ASCIIARRAY[5] = 'act_5.png';  // set of images with numbers
            normal_sunrise_TextRotate_ASCIIARRAY[6] = 'act_6.png';  // set of images with numbers
            normal_sunrise_TextRotate_ASCIIARRAY[7] = 'act_7.png';  // set of images with numbers
            normal_sunrise_TextRotate_ASCIIARRAY[8] = 'act_8.png';  // set of images with numbers
            normal_sunrise_TextRotate_ASCIIARRAY[9] = 'act_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              normal_sunrise_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 152,
                center_y: 396,
                pos_x: 152,
                pos_y: 396,
                angle: 19,
                src: 'act_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_sunrise_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

            // normal_sunset_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 255,
              // y: 433,
              // font_array: ["act_0.png","act_1.png","act_2.png","act_3.png","act_4.png","act_5.png","act_6.png","act_7.png","act_8.png","act_9.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: 19,
              // negative_image: 'pointer_1.png',
              // invalid_image: 'dot.png',
              // dot_image: 'pointer_1.png',
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.SUN_SET,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_sunset_TextRotate_ASCIIARRAY[0] = 'act_0.png';  // set of images with numbers
            normal_sunset_TextRotate_ASCIIARRAY[1] = 'act_1.png';  // set of images with numbers
            normal_sunset_TextRotate_ASCIIARRAY[2] = 'act_2.png';  // set of images with numbers
            normal_sunset_TextRotate_ASCIIARRAY[3] = 'act_3.png';  // set of images with numbers
            normal_sunset_TextRotate_ASCIIARRAY[4] = 'act_4.png';  // set of images with numbers
            normal_sunset_TextRotate_ASCIIARRAY[5] = 'act_5.png';  // set of images with numbers
            normal_sunset_TextRotate_ASCIIARRAY[6] = 'act_6.png';  // set of images with numbers
            normal_sunset_TextRotate_ASCIIARRAY[7] = 'act_7.png';  // set of images with numbers
            normal_sunset_TextRotate_ASCIIARRAY[8] = 'act_8.png';  // set of images with numbers
            normal_sunset_TextRotate_ASCIIARRAY[9] = 'act_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              normal_sunset_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 255,
                center_y: 433,
                pos_x: 255,
                pos_y: 433,
                angle: 19,
                src: 'act_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_sunset_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 28,
              y: 235,
              image_array: ["weather_1.png","weather_2.png","weather_3.png","weather_4.png","weather_5.png","weather_6.png","weather_7.png","weather_8.png","weather_9.png","weather_10.png","weather_11.png","weather_12.png","weather_13.png","weather_14.png","weather_15.png","weather_16.png","weather_17.png","weather_18.png","weather_19.png","weather_20.png","weather_21.png","weather_22.png","weather_23.png","weather_24.png","weather_25.png","weather_26.png","weather_27.png","weather_28.png","weather_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_temperature_high_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 312,
              // y: 414,
              // font_array: ["act_0.png","act_1.png","act_2.png","act_3.png","act_4.png","act_5.png","act_6.png","act_7.png","act_8.png","act_9.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: 19,
              // unit_en: 'pointer_4.png',
              // imperial_unit_en: 'pointer_4.png',
              // negative_image: 'pointer_3.png',
              // invalid_image: 'dot.png',
              // dot_image: 'pointer_3.png',
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.WEATHER_HIGH,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_temperature_high_TextRotate_ASCIIARRAY[0] = 'act_0.png';  // set of images with numbers
            normal_temperature_high_TextRotate_ASCIIARRAY[1] = 'act_1.png';  // set of images with numbers
            normal_temperature_high_TextRotate_ASCIIARRAY[2] = 'act_2.png';  // set of images with numbers
            normal_temperature_high_TextRotate_ASCIIARRAY[3] = 'act_3.png';  // set of images with numbers
            normal_temperature_high_TextRotate_ASCIIARRAY[4] = 'act_4.png';  // set of images with numbers
            normal_temperature_high_TextRotate_ASCIIARRAY[5] = 'act_5.png';  // set of images with numbers
            normal_temperature_high_TextRotate_ASCIIARRAY[6] = 'act_6.png';  // set of images with numbers
            normal_temperature_high_TextRotate_ASCIIARRAY[7] = 'act_7.png';  // set of images with numbers
            normal_temperature_high_TextRotate_ASCIIARRAY[8] = 'act_8.png';  // set of images with numbers
            normal_temperature_high_TextRotate_ASCIIARRAY[9] = 'act_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 4; i++) {
              normal_temperature_high_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 312,
                center_y: 414,
                pos_x: 312,
                pos_y: 414,
                angle: 19,
                src: 'act_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_temperature_high_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_temperature_high_TextRotate_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              center_x: 312,
              center_y: 414,
              pos_x: 312,
              pos_y: 414,
              angle: 19,
              src: 'pointer_4.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_temperature_high_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);

            const temperatureUnit = hmSetting.getTemperatureUnit();
            if (temperatureUnit == 1) {
              normal_temperature_high_TextRotate_unit.setProperty(hmUI.prop.SRC, 'pointer_4.png');
            };
            //end of ignored block

            // normal_temperature_low_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 228,
              // y: 383,
              // font_array: ["act_0.png","act_1.png","act_2.png","act_3.png","act_4.png","act_5.png","act_6.png","act_7.png","act_8.png","act_9.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: 19,
              // unit_en: 'pointer_4.png',
              // imperial_unit_en: 'pointer_4.png',
              // negative_image: 'pointer_3.png',
              // invalid_image: 'dot.png',
              // dot_image: 'pointer_3.png',
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.WEATHER_LOW,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_temperature_low_TextRotate_ASCIIARRAY[0] = 'act_0.png';  // set of images with numbers
            normal_temperature_low_TextRotate_ASCIIARRAY[1] = 'act_1.png';  // set of images with numbers
            normal_temperature_low_TextRotate_ASCIIARRAY[2] = 'act_2.png';  // set of images with numbers
            normal_temperature_low_TextRotate_ASCIIARRAY[3] = 'act_3.png';  // set of images with numbers
            normal_temperature_low_TextRotate_ASCIIARRAY[4] = 'act_4.png';  // set of images with numbers
            normal_temperature_low_TextRotate_ASCIIARRAY[5] = 'act_5.png';  // set of images with numbers
            normal_temperature_low_TextRotate_ASCIIARRAY[6] = 'act_6.png';  // set of images with numbers
            normal_temperature_low_TextRotate_ASCIIARRAY[7] = 'act_7.png';  // set of images with numbers
            normal_temperature_low_TextRotate_ASCIIARRAY[8] = 'act_8.png';  // set of images with numbers
            normal_temperature_low_TextRotate_ASCIIARRAY[9] = 'act_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 4; i++) {
              normal_temperature_low_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 228,
                center_y: 383,
                pos_x: 228,
                pos_y: 383,
                angle: 19,
                src: 'act_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_temperature_low_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_temperature_low_TextRotate_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              center_x: 228,
              center_y: 383,
              pos_x: 228,
              pos_y: 383,
              angle: 19,
              src: 'pointer_4.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_temperature_low_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);

            if (temperatureUnit == 1) {
              normal_temperature_low_TextRotate_unit.setProperty(hmUI.prop.SRC, 'pointer_4.png');
            };
            //end of ignored block

            // normal_temperature_current_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 140,
              // y: 348,
              // font_array: ["act_0.png","act_1.png","act_2.png","act_3.png","act_4.png","act_5.png","act_6.png","act_7.png","act_8.png","act_9.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: 19,
              // unit_en: 'pointer_4.png',
              // imperial_unit_en: 'pointer_4.png',
              // negative_image: 'pointer_3.png',
              // invalid_image: 'dot.png',
              // dot_image: 'pointer_3.png',
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.WEATHER_CURRENT,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_temperature_current_TextRotate_ASCIIARRAY[0] = 'act_0.png';  // set of images with numbers
            normal_temperature_current_TextRotate_ASCIIARRAY[1] = 'act_1.png';  // set of images with numbers
            normal_temperature_current_TextRotate_ASCIIARRAY[2] = 'act_2.png';  // set of images with numbers
            normal_temperature_current_TextRotate_ASCIIARRAY[3] = 'act_3.png';  // set of images with numbers
            normal_temperature_current_TextRotate_ASCIIARRAY[4] = 'act_4.png';  // set of images with numbers
            normal_temperature_current_TextRotate_ASCIIARRAY[5] = 'act_5.png';  // set of images with numbers
            normal_temperature_current_TextRotate_ASCIIARRAY[6] = 'act_6.png';  // set of images with numbers
            normal_temperature_current_TextRotate_ASCIIARRAY[7] = 'act_7.png';  // set of images with numbers
            normal_temperature_current_TextRotate_ASCIIARRAY[8] = 'act_8.png';  // set of images with numbers
            normal_temperature_current_TextRotate_ASCIIARRAY[9] = 'act_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 4; i++) {
              normal_temperature_current_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 140,
                center_y: 348,
                pos_x: 140,
                pos_y: 348,
                angle: 19,
                src: 'act_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_temperature_current_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_temperature_current_TextRotate_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              center_x: 140,
              center_y: 348,
              pos_x: 140,
              pos_y: 348,
              angle: 19,
              src: 'pointer_4.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_temperature_current_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);

            if (temperatureUnit == 1) {
              normal_temperature_current_TextRotate_unit.setProperty(hmUI.prop.SRC, 'pointer_4.png');
            };
            //end of ignored block

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 306,
              y: 168,
              font_array: ["act_0.png","act_1.png","act_2.png","act_3.png","act_4.png","act_5.png","act_6.png","act_7.png","act_8.png","act_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'percent.png',
              unit_tc: 'percent.png',
              unit_en: 'percent.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 211,
              y: 96,
              font_array: ["act_0.png","act_1.png","act_2.png","act_3.png","act_4.png","act_5.png","act_6.png","act_7.png","act_8.png","act_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'km.png',
              unit_tc: 'km.png',
              unit_en: 'km.png',
              imperial_unit_sc: 'ml.png',
              imperial_unit_tc: 'ml.png',
              imperial_unit_en: 'ml.png',
              dot_image: 'pointer_2.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_weekly_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 81,
              y: 87,
              font_array: ["act_0.png","act_1.png","act_2.png","act_3.png","act_4.png","act_5.png","act_6.png","act_7.png","act_8.png","act_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 't.png',
              unit_tc: 't.png',
              unit_en: 't.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 375,
              y: 102,
              font_array: ["act_0.png","act_1.png","act_2.png","act_3.png","act_4.png","act_5.png","act_6.png","act_7.png","act_8.png","act_9.png"],
              padding: false,
              h_space: 0,
              invalid_image: 'dot.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 288,
              y: 35,
              font_array: ["act_0.png","act_1.png","act_2.png","act_3.png","act_4.png","act_5.png","act_6.png","act_7.png","act_8.png","act_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 138,
              y: 27,
              font_array: ["act_0.png","act_1.png","act_2.png","act_3.png","act_4.png","act_5.png","act_6.png","act_7.png","act_8.png","act_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 318,
              y: 213,
              week_en: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              week_tc: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              week_sc: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 304,
              month_startY: 246,
              month_sc_array: ["month_1.png","month_2.png","month_3.png","month_4.png","month_5.png","month_6.png","month_7.png","month_8.png","month_9.png","month_10.png","month_11.png","month_12.png"],
              month_tc_array: ["month_1.png","month_2.png","month_3.png","month_4.png","month_5.png","month_6.png","month_7.png","month_8.png","month_9.png","month_10.png","month_11.png","month_12.png"],
              month_en_array: ["month_1.png","month_2.png","month_3.png","month_4.png","month_5.png","month_6.png","month_7.png","month_8.png","month_9.png","month_10.png","month_11.png","month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_day_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 414,
              // y: 293,
              // font_array: ["date_0.png","date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png","date_8.png","date_9.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: 19,
              // invalid_image: 'dot.png',
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.DAY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_day_TextRotate_ASCIIARRAY[0] = 'date_0.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[1] = 'date_1.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[2] = 'date_2.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[3] = 'date_3.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[4] = 'date_4.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[5] = 'date_5.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[6] = 'date_6.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[7] = 'date_7.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[8] = 'date_8.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[9] = 'date_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              normal_day_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 414,
                center_y: 293,
                pos_x: 414,
                pos_y: 293,
                angle: 19,
                src: 'date_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_day_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            let screenType = hmSetting.getScreenType();
            // normal_hour_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 48,
              // y: 121,
              // font_array: ["time_0.png","time_1.png","time_2.png","time_3.png","time_4.png","time_5.png","time_6.png","time_7.png","time_8.png","time_9.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: 2,
              // angle: 19,
              // unit_en: 'pointer_0.png',
              // invalid_image: 'dot.png',
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.HOUR,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_hour_TextRotate_ASCIIARRAY[0] = 'time_0.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[1] = 'time_1.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[2] = 'time_2.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[3] = 'time_3.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[4] = 'time_4.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[5] = 'time_5.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[6] = 'time_6.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[7] = 'time_7.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[8] = 'time_8.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[9] = 'time_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              normal_hour_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 48,
                center_y: 121,
                pos_x: 48,
                pos_y: 121,
                angle: 19,
                src: 'time_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_hour_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_hour_TextRotate_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              center_x: 48,
              center_y: 121,
              pos_x: 48,
              pos_y: 121,
              angle: 19,
              src: 'pointer_0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_hour_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block

            // normal_minute_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 144,
              // y: 157,
              // font_array: ["time_0.png","time_1.png","time_2.png","time_3.png","time_4.png","time_5.png","time_6.png","time_7.png","time_8.png","time_9.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: 2,
              // angle: 19,
              // unit_en: 'pointer_0.png',
              // invalid_image: 'dot.png',
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.MINUTE,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_minute_TextRotate_ASCIIARRAY[0] = 'time_0.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[1] = 'time_1.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[2] = 'time_2.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[3] = 'time_3.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[4] = 'time_4.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[5] = 'time_5.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[6] = 'time_6.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[7] = 'time_7.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[8] = 'time_8.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[9] = 'time_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              normal_minute_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 144,
                center_y: 157,
                pos_x: 144,
                pos_y: 157,
                angle: 19,
                src: 'time_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_minute_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_minute_TextRotate_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              center_x: 144,
              center_y: 157,
              pos_x: 144,
              pos_y: 157,
              angle: 19,
              src: 'pointer_0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_minute_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block

            // normal_second_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 240,
              // y: 193,
              // font_array: ["time_0.png","time_1.png","time_2.png","time_3.png","time_4.png","time_5.png","time_6.png","time_7.png","time_8.png","time_9.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: 2,
              // angle: 19,
              // invalid_image: 'dot.png',
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.SECOND,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_second_TextRotate_ASCIIARRAY[0] = 'time_0.png';  // set of images with numbers
            normal_second_TextRotate_ASCIIARRAY[1] = 'time_1.png';  // set of images with numbers
            normal_second_TextRotate_ASCIIARRAY[2] = 'time_2.png';  // set of images with numbers
            normal_second_TextRotate_ASCIIARRAY[3] = 'time_3.png';  // set of images with numbers
            normal_second_TextRotate_ASCIIARRAY[4] = 'time_4.png';  // set of images with numbers
            normal_second_TextRotate_ASCIIARRAY[5] = 'time_5.png';  // set of images with numbers
            normal_second_TextRotate_ASCIIARRAY[6] = 'time_6.png';  // set of images with numbers
            normal_second_TextRotate_ASCIIARRAY[7] = 'time_7.png';  // set of images with numbers
            normal_second_TextRotate_ASCIIARRAY[8] = 'time_8.png';  // set of images with numbers
            normal_second_TextRotate_ASCIIARRAY[9] = 'time_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              normal_second_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 240,
                center_y: 193,
                pos_x: 240,
                pos_y: 193,
                angle: 19,
                src: 'time_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_second_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'background.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'aod.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 287,
              y: 365,
              src: 'status.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 245,
              y: 350,
              src: 'status.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 149,
              y: 311,
              src: 'bt_off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 203,
              y: 335,
              src: 'status.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_sunrise_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 152,
              // y: 396,
              // font_array: ["act_0.png","act_1.png","act_2.png","act_3.png","act_4.png","act_5.png","act_6.png","act_7.png","act_8.png","act_9.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: 19,
              // negative_image: 'pointer_1.png',
              // invalid_image: 'dot.png',
              // dot_image: 'pointer_1.png',
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.SUN_RISE,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_sunrise_TextRotate_ASCIIARRAY[0] = 'act_0.png';  // set of images with numbers
            idle_sunrise_TextRotate_ASCIIARRAY[1] = 'act_1.png';  // set of images with numbers
            idle_sunrise_TextRotate_ASCIIARRAY[2] = 'act_2.png';  // set of images with numbers
            idle_sunrise_TextRotate_ASCIIARRAY[3] = 'act_3.png';  // set of images with numbers
            idle_sunrise_TextRotate_ASCIIARRAY[4] = 'act_4.png';  // set of images with numbers
            idle_sunrise_TextRotate_ASCIIARRAY[5] = 'act_5.png';  // set of images with numbers
            idle_sunrise_TextRotate_ASCIIARRAY[6] = 'act_6.png';  // set of images with numbers
            idle_sunrise_TextRotate_ASCIIARRAY[7] = 'act_7.png';  // set of images with numbers
            idle_sunrise_TextRotate_ASCIIARRAY[8] = 'act_8.png';  // set of images with numbers
            idle_sunrise_TextRotate_ASCIIARRAY[9] = 'act_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              idle_sunrise_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 152,
                center_y: 396,
                pos_x: 152,
                pos_y: 396,
                angle: 19,
                src: 'act_0.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_sunrise_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            // idle_sunset_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 255,
              // y: 433,
              // font_array: ["act_0.png","act_1.png","act_2.png","act_3.png","act_4.png","act_5.png","act_6.png","act_7.png","act_8.png","act_9.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: 19,
              // negative_image: 'pointer_1.png',
              // invalid_image: 'dot.png',
              // dot_image: 'pointer_1.png',
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.SUN_SET,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_sunset_TextRotate_ASCIIARRAY[0] = 'act_0.png';  // set of images with numbers
            idle_sunset_TextRotate_ASCIIARRAY[1] = 'act_1.png';  // set of images with numbers
            idle_sunset_TextRotate_ASCIIARRAY[2] = 'act_2.png';  // set of images with numbers
            idle_sunset_TextRotate_ASCIIARRAY[3] = 'act_3.png';  // set of images with numbers
            idle_sunset_TextRotate_ASCIIARRAY[4] = 'act_4.png';  // set of images with numbers
            idle_sunset_TextRotate_ASCIIARRAY[5] = 'act_5.png';  // set of images with numbers
            idle_sunset_TextRotate_ASCIIARRAY[6] = 'act_6.png';  // set of images with numbers
            idle_sunset_TextRotate_ASCIIARRAY[7] = 'act_7.png';  // set of images with numbers
            idle_sunset_TextRotate_ASCIIARRAY[8] = 'act_8.png';  // set of images with numbers
            idle_sunset_TextRotate_ASCIIARRAY[9] = 'act_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              idle_sunset_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 255,
                center_y: 433,
                pos_x: 255,
                pos_y: 433,
                angle: 19,
                src: 'act_0.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_sunset_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 28,
              y: 235,
              image_array: ["weather_1.png","weather_2.png","weather_3.png","weather_4.png","weather_5.png","weather_6.png","weather_7.png","weather_8.png","weather_9.png","weather_10.png","weather_11.png","weather_12.png","weather_13.png","weather_14.png","weather_15.png","weather_16.png","weather_17.png","weather_18.png","weather_19.png","weather_20.png","weather_21.png","weather_22.png","weather_23.png","weather_24.png","weather_25.png","weather_26.png","weather_27.png","weather_28.png","weather_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_temperature_high_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 312,
              // y: 414,
              // font_array: ["act_0.png","act_1.png","act_2.png","act_3.png","act_4.png","act_5.png","act_6.png","act_7.png","act_8.png","act_9.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: 19,
              // unit_en: 'pointer_4.png',
              // imperial_unit_en: 'pointer_4.png',
              // negative_image: 'pointer_3.png',
              // invalid_image: 'dot.png',
              // dot_image: 'pointer_3.png',
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.WEATHER_HIGH,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_temperature_high_TextRotate_ASCIIARRAY[0] = 'act_0.png';  // set of images with numbers
            idle_temperature_high_TextRotate_ASCIIARRAY[1] = 'act_1.png';  // set of images with numbers
            idle_temperature_high_TextRotate_ASCIIARRAY[2] = 'act_2.png';  // set of images with numbers
            idle_temperature_high_TextRotate_ASCIIARRAY[3] = 'act_3.png';  // set of images with numbers
            idle_temperature_high_TextRotate_ASCIIARRAY[4] = 'act_4.png';  // set of images with numbers
            idle_temperature_high_TextRotate_ASCIIARRAY[5] = 'act_5.png';  // set of images with numbers
            idle_temperature_high_TextRotate_ASCIIARRAY[6] = 'act_6.png';  // set of images with numbers
            idle_temperature_high_TextRotate_ASCIIARRAY[7] = 'act_7.png';  // set of images with numbers
            idle_temperature_high_TextRotate_ASCIIARRAY[8] = 'act_8.png';  // set of images with numbers
            idle_temperature_high_TextRotate_ASCIIARRAY[9] = 'act_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 4; i++) {
              idle_temperature_high_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 312,
                center_y: 414,
                pos_x: 312,
                pos_y: 414,
                angle: 19,
                src: 'act_0.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_temperature_high_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            idle_temperature_high_TextRotate_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              center_x: 312,
              center_y: 414,
              pos_x: 312,
              pos_y: 414,
              angle: 19,
              src: 'pointer_4.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            idle_temperature_high_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);

            if (temperatureUnit == 1) {
              idle_temperature_high_TextRotate_unit.setProperty(hmUI.prop.SRC, 'pointer_4.png');
            };
            //end of ignored block

            // idle_temperature_low_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 228,
              // y: 383,
              // font_array: ["act_0.png","act_1.png","act_2.png","act_3.png","act_4.png","act_5.png","act_6.png","act_7.png","act_8.png","act_9.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: 19,
              // unit_en: 'pointer_4.png',
              // imperial_unit_en: 'pointer_4.png',
              // negative_image: 'pointer_3.png',
              // invalid_image: 'dot.png',
              // dot_image: 'pointer_3.png',
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.WEATHER_LOW,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_temperature_low_TextRotate_ASCIIARRAY[0] = 'act_0.png';  // set of images with numbers
            idle_temperature_low_TextRotate_ASCIIARRAY[1] = 'act_1.png';  // set of images with numbers
            idle_temperature_low_TextRotate_ASCIIARRAY[2] = 'act_2.png';  // set of images with numbers
            idle_temperature_low_TextRotate_ASCIIARRAY[3] = 'act_3.png';  // set of images with numbers
            idle_temperature_low_TextRotate_ASCIIARRAY[4] = 'act_4.png';  // set of images with numbers
            idle_temperature_low_TextRotate_ASCIIARRAY[5] = 'act_5.png';  // set of images with numbers
            idle_temperature_low_TextRotate_ASCIIARRAY[6] = 'act_6.png';  // set of images with numbers
            idle_temperature_low_TextRotate_ASCIIARRAY[7] = 'act_7.png';  // set of images with numbers
            idle_temperature_low_TextRotate_ASCIIARRAY[8] = 'act_8.png';  // set of images with numbers
            idle_temperature_low_TextRotate_ASCIIARRAY[9] = 'act_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 4; i++) {
              idle_temperature_low_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 228,
                center_y: 383,
                pos_x: 228,
                pos_y: 383,
                angle: 19,
                src: 'act_0.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_temperature_low_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            idle_temperature_low_TextRotate_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              center_x: 228,
              center_y: 383,
              pos_x: 228,
              pos_y: 383,
              angle: 19,
              src: 'pointer_4.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            idle_temperature_low_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);

            if (temperatureUnit == 1) {
              idle_temperature_low_TextRotate_unit.setProperty(hmUI.prop.SRC, 'pointer_4.png');
            };
            //end of ignored block

            // idle_temperature_current_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 140,
              // y: 348,
              // font_array: ["act_0.png","act_1.png","act_2.png","act_3.png","act_4.png","act_5.png","act_6.png","act_7.png","act_8.png","act_9.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: 19,
              // unit_en: 'pointer_4.png',
              // imperial_unit_en: 'pointer_4.png',
              // negative_image: 'pointer_3.png',
              // invalid_image: 'dot.png',
              // dot_image: 'pointer_3.png',
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.WEATHER_CURRENT,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_temperature_current_TextRotate_ASCIIARRAY[0] = 'act_0.png';  // set of images with numbers
            idle_temperature_current_TextRotate_ASCIIARRAY[1] = 'act_1.png';  // set of images with numbers
            idle_temperature_current_TextRotate_ASCIIARRAY[2] = 'act_2.png';  // set of images with numbers
            idle_temperature_current_TextRotate_ASCIIARRAY[3] = 'act_3.png';  // set of images with numbers
            idle_temperature_current_TextRotate_ASCIIARRAY[4] = 'act_4.png';  // set of images with numbers
            idle_temperature_current_TextRotate_ASCIIARRAY[5] = 'act_5.png';  // set of images with numbers
            idle_temperature_current_TextRotate_ASCIIARRAY[6] = 'act_6.png';  // set of images with numbers
            idle_temperature_current_TextRotate_ASCIIARRAY[7] = 'act_7.png';  // set of images with numbers
            idle_temperature_current_TextRotate_ASCIIARRAY[8] = 'act_8.png';  // set of images with numbers
            idle_temperature_current_TextRotate_ASCIIARRAY[9] = 'act_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 4; i++) {
              idle_temperature_current_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 140,
                center_y: 348,
                pos_x: 140,
                pos_y: 348,
                angle: 19,
                src: 'act_0.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_temperature_current_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            idle_temperature_current_TextRotate_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              center_x: 140,
              center_y: 348,
              pos_x: 140,
              pos_y: 348,
              angle: 19,
              src: 'pointer_4.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            idle_temperature_current_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);

            if (temperatureUnit == 1) {
              idle_temperature_current_TextRotate_unit.setProperty(hmUI.prop.SRC, 'pointer_4.png');
            };
            //end of ignored block

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 306,
              y: 168,
              font_array: ["act_0.png","act_1.png","act_2.png","act_3.png","act_4.png","act_5.png","act_6.png","act_7.png","act_8.png","act_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'percent.png',
              unit_tc: 'percent.png',
              unit_en: 'percent.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 211,
              y: 96,
              font_array: ["act_0.png","act_1.png","act_2.png","act_3.png","act_4.png","act_5.png","act_6.png","act_7.png","act_8.png","act_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'km.png',
              unit_tc: 'km.png',
              unit_en: 'km.png',
              imperial_unit_sc: 'ml.png',
              imperial_unit_tc: 'ml.png',
              imperial_unit_en: 'ml.png',
              dot_image: 'pointer_2.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_pai_weekly_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 81,
              y: 87,
              font_array: ["act_0.png","act_1.png","act_2.png","act_3.png","act_4.png","act_5.png","act_6.png","act_7.png","act_8.png","act_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 't.png',
              unit_tc: 't.png',
              unit_en: 't.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 375,
              y: 102,
              font_array: ["act_0.png","act_1.png","act_2.png","act_3.png","act_4.png","act_5.png","act_6.png","act_7.png","act_8.png","act_9.png"],
              padding: false,
              h_space: 0,
              invalid_image: 'dot.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 288,
              y: 35,
              font_array: ["act_0.png","act_1.png","act_2.png","act_3.png","act_4.png","act_5.png","act_6.png","act_7.png","act_8.png","act_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 138,
              y: 27,
              font_array: ["act_0.png","act_1.png","act_2.png","act_3.png","act_4.png","act_5.png","act_6.png","act_7.png","act_8.png","act_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 318,
              y: 213,
              week_en: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              week_tc: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              week_sc: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 304,
              month_startY: 246,
              month_sc_array: ["month_1.png","month_2.png","month_3.png","month_4.png","month_5.png","month_6.png","month_7.png","month_8.png","month_9.png","month_10.png","month_11.png","month_12.png"],
              month_tc_array: ["month_1.png","month_2.png","month_3.png","month_4.png","month_5.png","month_6.png","month_7.png","month_8.png","month_9.png","month_10.png","month_11.png","month_12.png"],
              month_en_array: ["month_1.png","month_2.png","month_3.png","month_4.png","month_5.png","month_6.png","month_7.png","month_8.png","month_9.png","month_10.png","month_11.png","month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_day_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 414,
              // y: 293,
              // font_array: ["date_0.png","date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png","date_8.png","date_9.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: 19,
              // invalid_image: 'dot.png',
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.DAY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_day_TextRotate_ASCIIARRAY[0] = 'date_0.png';  // set of images with numbers
            idle_day_TextRotate_ASCIIARRAY[1] = 'date_1.png';  // set of images with numbers
            idle_day_TextRotate_ASCIIARRAY[2] = 'date_2.png';  // set of images with numbers
            idle_day_TextRotate_ASCIIARRAY[3] = 'date_3.png';  // set of images with numbers
            idle_day_TextRotate_ASCIIARRAY[4] = 'date_4.png';  // set of images with numbers
            idle_day_TextRotate_ASCIIARRAY[5] = 'date_5.png';  // set of images with numbers
            idle_day_TextRotate_ASCIIARRAY[6] = 'date_6.png';  // set of images with numbers
            idle_day_TextRotate_ASCIIARRAY[7] = 'date_7.png';  // set of images with numbers
            idle_day_TextRotate_ASCIIARRAY[8] = 'date_8.png';  // set of images with numbers
            idle_day_TextRotate_ASCIIARRAY[9] = 'date_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              idle_day_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 414,
                center_y: 293,
                pos_x: 414,
                pos_y: 293,
                angle: 19,
                src: 'date_0.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_day_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            // idle_hour_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 48,
              // y: 121,
              // font_array: ["time_0.png","time_1.png","time_2.png","time_3.png","time_4.png","time_5.png","time_6.png","time_7.png","time_8.png","time_9.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: 2,
              // angle: 19,
              // unit_en: 'pointer_0.png',
              // invalid_image: 'dot.png',
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.HOUR,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_hour_TextRotate_ASCIIARRAY[0] = 'time_0.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[1] = 'time_1.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[2] = 'time_2.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[3] = 'time_3.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[4] = 'time_4.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[5] = 'time_5.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[6] = 'time_6.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[7] = 'time_7.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[8] = 'time_8.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[9] = 'time_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              idle_hour_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 48,
                center_y: 121,
                pos_x: 48,
                pos_y: 121,
                angle: 19,
                src: 'time_0.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_hour_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            idle_hour_TextRotate_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              center_x: 48,
              center_y: 121,
              pos_x: 48,
              pos_y: 121,
              angle: 19,
              src: 'pointer_0.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            idle_hour_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block

            // idle_minute_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 144,
              // y: 157,
              // font_array: ["time_0.png","time_1.png","time_2.png","time_3.png","time_4.png","time_5.png","time_6.png","time_7.png","time_8.png","time_9.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: 2,
              // angle: 19,
              // unit_en: 'pointer_0.png',
              // invalid_image: 'dot.png',
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.MINUTE,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_minute_TextRotate_ASCIIARRAY[0] = 'time_0.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[1] = 'time_1.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[2] = 'time_2.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[3] = 'time_3.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[4] = 'time_4.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[5] = 'time_5.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[6] = 'time_6.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[7] = 'time_7.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[8] = 'time_8.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[9] = 'time_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              idle_minute_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 144,
                center_y: 157,
                pos_x: 144,
                pos_y: 157,
                angle: 19,
                src: 'time_0.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_minute_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            idle_minute_TextRotate_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              center_x: 144,
              center_y: 157,
              pos_x: 144,
              pos_y: 157,
              angle: 19,
              src: 'pointer_0.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            idle_minute_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block

            // idle_second_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 240,
              // y: 193,
              // font_array: ["time_0.png","time_1.png","time_2.png","time_3.png","time_4.png","time_5.png","time_6.png","time_7.png","time_8.png","time_9.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: 2,
              // angle: 19,
              // invalid_image: 'dot.png',
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.SECOND,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_second_TextRotate_ASCIIARRAY[0] = 'time_0.png';  // set of images with numbers
            idle_second_TextRotate_ASCIIARRAY[1] = 'time_1.png';  // set of images with numbers
            idle_second_TextRotate_ASCIIARRAY[2] = 'time_2.png';  // set of images with numbers
            idle_second_TextRotate_ASCIIARRAY[3] = 'time_3.png';  // set of images with numbers
            idle_second_TextRotate_ASCIIARRAY[4] = 'time_4.png';  // set of images with numbers
            idle_second_TextRotate_ASCIIARRAY[5] = 'time_5.png';  // set of images with numbers
            idle_second_TextRotate_ASCIIARRAY[6] = 'time_6.png';  // set of images with numbers
            idle_second_TextRotate_ASCIIARRAY[7] = 'time_7.png';  // set of images with numbers
            idle_second_TextRotate_ASCIIARRAY[8] = 'time_8.png';  // set of images with numbers
            idle_second_TextRotate_ASCIIARRAY[9] = 'time_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              idle_second_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 240,
                center_y: 193,
                pos_x: 240,
                pos_y: 193,
                angle: 19,
                src: 'time_0.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_second_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 354,
              y: 379,
              w: 57,
              h: 51,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'dot.png',
              normal_src: 'dot.png',
              click_func: (button_widget) => {
                click_Color();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 140,
              y: 20,
              w: 93,
              h: 51,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'dot.png',
              normal_src: 'dot.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'activityAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 360,
              y: 88,
              w: 93,
              h: 51,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'dot.png',
              normal_src: 'dot.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'heart_app_Screen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 71,
              y: 57,
              w: 58,
              h: 51,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'dot.png',
              normal_src: 'dot.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PAI_app_Screen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 306,
              y: 367,
              w: 30,
              h: 30,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'dot.png',
              normal_src: 'dot.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'Sleep_HomeScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 202,
              y: 87,
              w: 107,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'dot.png',
              normal_src: 'dot.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'spo_HomeScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_7 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 222,
              y: 336,
              w: 30,
              h: 30,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'dot.png',
              normal_src: 'dot.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'AlarmInfoScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_8 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 318,
              y: 230,
              w: 140,
              h: 80,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'dot.png',
              normal_src: 'dot.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_9 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 20,
              y: 230,
              w: 106,
              h: 80,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'dot.png',
              normal_src: 'dot.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'WeatherScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            //start of ignored block
            function text_update() {
              console.log('text_update()');
              let weatherData = weatherSensor.getForecastWeather();
              let tideData = weatherData.tideData;
              let sunrise_hour = -1;
              let sunrise_minute = -1;
              if (tideData.count > 0) {
                sunrise_hour = tideData.data[0].sunrise.hour;
                sunrise_minute = tideData.data[0].sunrise.minute;
              }; // end tideData;

              console.log('update text rotate sunrise_tideData');
              let sunriseTime = undefined;
              let normal_sunrise_rotate_string = undefined;
              if (sunrise_hour >= 0 && sunrise_minute >= 0) {
                sunriseTime = 0;
                normal_sunrise_rotate_string = String(sunrise_hour).padStart(2, '0') + '.' + String(sunrise_minute).padStart(2, '0');
              };

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  normal_sunrise_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (sunriseTime != null && sunriseTime != undefined && isFinite(sunriseTime) && normal_sunrise_rotate_string.length > 0 && normal_sunrise_rotate_string.length <= 5) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let normal_sunrise_TextRotate_posOffset = normal_sunrise_TextRotate_img_width * normal_sunrise_rotate_string.length;
                  img_offset -= normal_sunrise_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_sunrise_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_sunrise_TextRotate[index].setProperty(hmUI.prop.POS_X, 152 + img_offset);
                      normal_sunrise_TextRotate[index].setProperty(hmUI.prop.SRC, normal_sunrise_TextRotate_ASCIIARRAY[charCode]);
                      normal_sunrise_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_sunrise_TextRotate_img_width;
                      index++;
                    }  // end if digit
                    else { 
                      normal_sunrise_TextRotate[index].setProperty(hmUI.prop.POS_X, 152 + img_offset);
                      normal_sunrise_TextRotate[index].setProperty(hmUI.prop.SRC, 'pointer_1.png');
                      normal_sunrise_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_sunrise_TextRotate_dot_width;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                }  // end isFinite
                else {
                  normal_sunrise_TextRotate[0].setProperty(hmUI.prop.POS_X, 152 - normal_sunrise_TextRotate_error_img_width / 2);
                  normal_sunrise_TextRotate[0].setProperty(hmUI.prop.SRC, 'dot.png');
                  normal_sunrise_TextRotate[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };
              let sunset_hour = -1;
              let sunset_minute = -1;
              if (tideData.count > 0) {
                sunset_hour = tideData.data[0].sunset.hour;
                sunset_minute = tideData.data[0].sunset.minute;
              }; // end tideData;

              console.log('update text rotate sunset_tideData');
              let sunsetTime = undefined;
              let normal_sunset_rotate_string = undefined;
              if (sunset_hour >= 0 && sunset_minute >= 0) {
                sunsetTime = 0;
                normal_sunset_rotate_string = String(sunset_hour).padStart(2, '0') + '.' + String(sunset_minute).padStart(2, '0');
              };

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  normal_sunset_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (sunsetTime != null && sunsetTime != undefined && isFinite(sunsetTime) && normal_sunset_rotate_string.length > 0 && normal_sunset_rotate_string.length <= 5) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let normal_sunset_TextRotate_posOffset = normal_sunset_TextRotate_img_width * normal_sunset_rotate_string.length;
                  img_offset -= normal_sunset_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_sunset_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_sunset_TextRotate[index].setProperty(hmUI.prop.POS_X, 255 + img_offset);
                      normal_sunset_TextRotate[index].setProperty(hmUI.prop.SRC, normal_sunset_TextRotate_ASCIIARRAY[charCode]);
                      normal_sunset_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_sunset_TextRotate_img_width;
                      index++;
                    }  // end if digit
                    else { 
                      normal_sunset_TextRotate[index].setProperty(hmUI.prop.POS_X, 255 + img_offset);
                      normal_sunset_TextRotate[index].setProperty(hmUI.prop.SRC, 'pointer_1.png');
                      normal_sunset_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_sunset_TextRotate_dot_width;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                }  // end isFinite
                else {
                  normal_sunset_TextRotate[0].setProperty(hmUI.prop.POS_X, 255 - normal_sunset_TextRotate_error_img_width / 2);
                  normal_sunset_TextRotate[0].setProperty(hmUI.prop.SRC, 'dot.png');
                  normal_sunset_TextRotate[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };
              let forecastData = weatherData.forecastData;
              let temperature_high_temp = -100;
              if (forecastData.count > 0) {
                temperature_high_temp = forecastData.data[0].high;
              }; // end forecastData;

              console.log('update text rotate temperature_high_forecastData');
              let temperatureHigh = undefined;
              let normal_temperature_high_rotate_string = undefined;
              if (temperature_high_temp > -100) {
                temperatureHigh = 0;
                normal_temperature_high_rotate_string = String(temperature_high_temp)
              };

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 4; i++) {  // hide all symbols
                  normal_temperature_high_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_temperature_high_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
                if (temperatureHigh != null && temperatureHigh != undefined && isFinite(temperatureHigh) && normal_temperature_high_rotate_string.length > 0 && normal_temperature_high_rotate_string.length <= 4) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let normal_temperature_high_TextRotate_posOffset = normal_temperature_high_TextRotate_img_width * normal_temperature_high_rotate_string.length;
                  img_offset -= normal_temperature_high_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_temperature_high_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 4) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_temperature_high_TextRotate[index].setProperty(hmUI.prop.POS_X, 312 + img_offset);
                      normal_temperature_high_TextRotate[index].setProperty(hmUI.prop.SRC, normal_temperature_high_TextRotate_ASCIIARRAY[charCode]);
                      normal_temperature_high_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_temperature_high_TextRotate_img_width;
                      index++;
                    }  // end if digit
                    else { 
                      normal_temperature_high_TextRotate[index].setProperty(hmUI.prop.POS_X, 312 + img_offset);
                      normal_temperature_high_TextRotate[index].setProperty(hmUI.prop.SRC, 'pointer_3.png');
                      normal_temperature_high_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_temperature_high_TextRotate_dot_width;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                  normal_temperature_high_TextRotate_unit.setProperty(hmUI.prop.POS_X, 312 + img_offset);
                  normal_temperature_high_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite
                else {
                  normal_temperature_high_TextRotate[0].setProperty(hmUI.prop.POS_X, 312 - normal_temperature_high_TextRotate_error_img_width / 2);
                  normal_temperature_high_TextRotate[0].setProperty(hmUI.prop.SRC, 'dot.png');
                  normal_temperature_high_TextRotate[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };
              let temperature_low_temp = -100;
              if (forecastData.count > 0) {
                temperature_low_temp = forecastData.data[0].low;
              }; // end forecastData;

              console.log('update text rotate temperature_low_forecastData');
              let temperatureLow = undefined;
              let normal_temperature_low_rotate_string = undefined;
              if (temperature_low_temp > -100) {
                temperatureLow = 0;
                normal_temperature_low_rotate_string = String(temperature_low_temp)
              };

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 4; i++) {  // hide all symbols
                  normal_temperature_low_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_temperature_low_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
                if (temperatureLow != null && temperatureLow != undefined && isFinite(temperatureLow) && normal_temperature_low_rotate_string.length > 0 && normal_temperature_low_rotate_string.length <= 4) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let normal_temperature_low_TextRotate_posOffset = normal_temperature_low_TextRotate_img_width * normal_temperature_low_rotate_string.length;
                  img_offset -= normal_temperature_low_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_temperature_low_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 4) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_temperature_low_TextRotate[index].setProperty(hmUI.prop.POS_X, 228 + img_offset);
                      normal_temperature_low_TextRotate[index].setProperty(hmUI.prop.SRC, normal_temperature_low_TextRotate_ASCIIARRAY[charCode]);
                      normal_temperature_low_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_temperature_low_TextRotate_img_width;
                      index++;
                    }  // end if digit
                    else { 
                      normal_temperature_low_TextRotate[index].setProperty(hmUI.prop.POS_X, 228 + img_offset);
                      normal_temperature_low_TextRotate[index].setProperty(hmUI.prop.SRC, 'pointer_3.png');
                      normal_temperature_low_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_temperature_low_TextRotate_dot_width;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                  normal_temperature_low_TextRotate_unit.setProperty(hmUI.prop.POS_X, 228 + img_offset);
                  normal_temperature_low_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite
                else {
                  normal_temperature_low_TextRotate[0].setProperty(hmUI.prop.POS_X, 228 - normal_temperature_low_TextRotate_error_img_width / 2);
                  normal_temperature_low_TextRotate[0].setProperty(hmUI.prop.SRC, 'dot.png');
                  normal_temperature_low_TextRotate[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };
              let temperature_current_temp = -100;
              if (weatherSensor.current != undefined && weatherSensor.current != 'undefined') {
                temperature_current_temp = weatherSensor.current;
              }; // end currentWeather;

              console.log('update text rotate temperature_current_currentWeather');
              let temperatureCurrent = undefined;
              let normal_temperature_current_rotate_string = undefined;
              if (temperature_current_temp > -100) {
                temperatureCurrent = 0;
                normal_temperature_current_rotate_string = String(temperature_current_temp)
              };

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 4; i++) {  // hide all symbols
                  normal_temperature_current_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_temperature_current_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
                if (temperatureCurrent != null && temperatureCurrent != undefined && isFinite(temperatureCurrent) && normal_temperature_current_rotate_string.length > 0 && normal_temperature_current_rotate_string.length <= 4) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let normal_temperature_current_TextRotate_posOffset = normal_temperature_current_TextRotate_img_width * normal_temperature_current_rotate_string.length;
                  img_offset -= normal_temperature_current_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_temperature_current_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 4) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_temperature_current_TextRotate[index].setProperty(hmUI.prop.POS_X, 140 + img_offset);
                      normal_temperature_current_TextRotate[index].setProperty(hmUI.prop.SRC, normal_temperature_current_TextRotate_ASCIIARRAY[charCode]);
                      normal_temperature_current_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_temperature_current_TextRotate_img_width;
                      index++;
                    }  // end if digit
                    else { 
                      normal_temperature_current_TextRotate[index].setProperty(hmUI.prop.POS_X, 140 + img_offset);
                      normal_temperature_current_TextRotate[index].setProperty(hmUI.prop.SRC, 'pointer_3.png');
                      normal_temperature_current_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_temperature_current_TextRotate_dot_width;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                  normal_temperature_current_TextRotate_unit.setProperty(hmUI.prop.POS_X, 140 + img_offset);
                  normal_temperature_current_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite
                else {
                  normal_temperature_current_TextRotate[0].setProperty(hmUI.prop.POS_X, 140 - normal_temperature_current_TextRotate_error_img_width / 2);
                  normal_temperature_current_TextRotate[0].setProperty(hmUI.prop.SRC, 'dot.png');
                  normal_temperature_current_TextRotate[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

              console.log('update text rotate day_TIME');
              let valueDay = timeSensor.day;
              let normal_day_rotate_string = parseInt(valueDay).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_day_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueDay != null && valueDay != undefined && isFinite(valueDay) && normal_day_rotate_string.length > 0 && normal_day_rotate_string.length <= 2) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let normal_day_TextRotate_posOffset = normal_day_TextRotate_img_width * normal_day_rotate_string.length;
                  img_offset -= normal_day_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_day_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_day_TextRotate[index].setProperty(hmUI.prop.POS_X, 414 + img_offset);
                      normal_day_TextRotate[index].setProperty(hmUI.prop.SRC, normal_day_TextRotate_ASCIIARRAY[charCode]);
                      normal_day_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_day_TextRotate_img_width;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite
                else {
                  normal_day_TextRotate[0].setProperty(hmUI.prop.POS_X, 414 - normal_day_TextRotate_error_img_width / 2);
                  normal_day_TextRotate[0].setProperty(hmUI.prop.SRC, 'dot.png');
                  normal_day_TextRotate[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

              console.log('update text rotate hour_TIME');
              let valueHour = timeSensor.format_hour;
              let normal_hour_rotate_string = parseInt(valueHour).toString();
              normal_hour_rotate_string = normal_hour_rotate_string.padStart(2, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_hour_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_hour_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
                if (valueHour != null && valueHour != undefined && isFinite(valueHour) && normal_hour_rotate_string.length > 0 && normal_hour_rotate_string.length <= 2) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of normal_hour_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_hour_TextRotate[index].setProperty(hmUI.prop.POS_X, 48 + img_offset);
                      normal_hour_TextRotate[index].setProperty(hmUI.prop.SRC, normal_hour_TextRotate_ASCIIARRAY[charCode]);
                      normal_hour_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_hour_TextRotate_img_width + 2;
                      index++;
                    };  // end if digit
                  };  // end char of string
                  normal_hour_TextRotate_unit.setProperty(hmUI.prop.POS_X, 48 + img_offset);
                  normal_hour_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite
                else {
                  normal_hour_TextRotate[0].setProperty(hmUI.prop.POS_X, 48);
                  normal_hour_TextRotate[0].setProperty(hmUI.prop.SRC, 'dot.png');
                  normal_hour_TextRotate[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

              console.log('update text rotate minute_TIME');
              let valueMinute = timeSensor.minute;
              let normal_minute_rotate_string = parseInt(valueMinute).toString();
              normal_minute_rotate_string = normal_minute_rotate_string.padStart(2, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_minute_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_minute_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
                if (valueMinute != null && valueMinute != undefined && isFinite(valueMinute) && normal_minute_rotate_string.length > 0 && normal_minute_rotate_string.length <= 2) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of normal_minute_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_minute_TextRotate[index].setProperty(hmUI.prop.POS_X, 144 + img_offset);
                      normal_minute_TextRotate[index].setProperty(hmUI.prop.SRC, normal_minute_TextRotate_ASCIIARRAY[charCode]);
                      normal_minute_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_minute_TextRotate_img_width + 2;
                      index++;
                    };  // end if digit
                  };  // end char of string
                  normal_minute_TextRotate_unit.setProperty(hmUI.prop.POS_X, 144 + img_offset);
                  normal_minute_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite
                else {
                  normal_minute_TextRotate[0].setProperty(hmUI.prop.POS_X, 144);
                  normal_minute_TextRotate[0].setProperty(hmUI.prop.SRC, 'dot.png');
                  normal_minute_TextRotate[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

              console.log('update text rotate second_TIME');
              let valueSecond = timeSensor.second;
              let normal_second_rotate_string = parseInt(valueSecond).toString();
              normal_second_rotate_string = normal_second_rotate_string.padStart(2, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_second_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueSecond != null && valueSecond != undefined && isFinite(valueSecond) && normal_second_rotate_string.length > 0 && normal_second_rotate_string.length <= 2) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of normal_second_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_second_TextRotate[index].setProperty(hmUI.prop.POS_X, 240 + img_offset);
                      normal_second_TextRotate[index].setProperty(hmUI.prop.SRC, normal_second_TextRotate_ASCIIARRAY[charCode]);
                      normal_second_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_second_TextRotate_img_width + 2;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite
                else {
                  normal_second_TextRotate[0].setProperty(hmUI.prop.POS_X, 240);
                  normal_second_TextRotate[0].setProperty(hmUI.prop.SRC, 'dot.png');
                  normal_second_TextRotate[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

              console.log('update text rotate sunrise_tideData');
              let idle_sunrise_rotate_string = undefined;
              if (sunrise_hour >= 0 && sunrise_minute >= 0) {
                sunriseTime = 0;
                idle_sunrise_rotate_string = String(sunrise_hour).padStart(2, '0') + '.' + String(sunrise_minute).padStart(2, '0');
              };

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  idle_sunrise_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (sunriseTime != null && sunriseTime != undefined && isFinite(sunriseTime) && idle_sunrise_rotate_string.length > 0 && idle_sunrise_rotate_string.length <= 5) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let idle_sunrise_TextRotate_posOffset = idle_sunrise_TextRotate_img_width * idle_sunrise_rotate_string.length;
                  img_offset -= idle_sunrise_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of idle_sunrise_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_sunrise_TextRotate[index].setProperty(hmUI.prop.POS_X, 152 + img_offset);
                      idle_sunrise_TextRotate[index].setProperty(hmUI.prop.SRC, idle_sunrise_TextRotate_ASCIIARRAY[charCode]);
                      idle_sunrise_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_sunrise_TextRotate_img_width;
                      index++;
                    }  // end if digit
                    else { 
                      idle_sunrise_TextRotate[index].setProperty(hmUI.prop.POS_X, 152 + img_offset);
                      idle_sunrise_TextRotate[index].setProperty(hmUI.prop.SRC, 'pointer_1.png');
                      idle_sunrise_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_sunrise_TextRotate_dot_width;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                }  // end isFinite
                else {
                  idle_sunrise_TextRotate[0].setProperty(hmUI.prop.POS_X, 152 - idle_sunrise_TextRotate_error_img_width / 2);
                  idle_sunrise_TextRotate[0].setProperty(hmUI.prop.SRC, 'dot.png');
                  idle_sunrise_TextRotate[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

              console.log('update text rotate sunset_tideData');
              let idle_sunset_rotate_string = undefined;
              if (sunset_hour >= 0 && sunset_minute >= 0) {
                sunsetTime = 0;
                idle_sunset_rotate_string = String(sunset_hour).padStart(2, '0') + '.' + String(sunset_minute).padStart(2, '0');
              };

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  idle_sunset_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (sunsetTime != null && sunsetTime != undefined && isFinite(sunsetTime) && idle_sunset_rotate_string.length > 0 && idle_sunset_rotate_string.length <= 5) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let idle_sunset_TextRotate_posOffset = idle_sunset_TextRotate_img_width * idle_sunset_rotate_string.length;
                  img_offset -= idle_sunset_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of idle_sunset_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_sunset_TextRotate[index].setProperty(hmUI.prop.POS_X, 255 + img_offset);
                      idle_sunset_TextRotate[index].setProperty(hmUI.prop.SRC, idle_sunset_TextRotate_ASCIIARRAY[charCode]);
                      idle_sunset_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_sunset_TextRotate_img_width;
                      index++;
                    }  // end if digit
                    else { 
                      idle_sunset_TextRotate[index].setProperty(hmUI.prop.POS_X, 255 + img_offset);
                      idle_sunset_TextRotate[index].setProperty(hmUI.prop.SRC, 'pointer_1.png');
                      idle_sunset_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_sunset_TextRotate_dot_width;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                }  // end isFinite
                else {
                  idle_sunset_TextRotate[0].setProperty(hmUI.prop.POS_X, 255 - idle_sunset_TextRotate_error_img_width / 2);
                  idle_sunset_TextRotate[0].setProperty(hmUI.prop.SRC, 'dot.png');
                  idle_sunset_TextRotate[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

              console.log('update text rotate temperature_high_forecastData');
              let idle_temperature_high_rotate_string = undefined;
              if (temperature_high_temp > -100) {
                temperatureHigh = 0;
                idle_temperature_high_rotate_string = String(temperature_high_temp)
              };

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 4; i++) {  // hide all symbols
                  idle_temperature_high_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                idle_temperature_high_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
                if (temperatureHigh != null && temperatureHigh != undefined && isFinite(temperatureHigh) && idle_temperature_high_rotate_string.length > 0 && idle_temperature_high_rotate_string.length <= 4) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let idle_temperature_high_TextRotate_posOffset = idle_temperature_high_TextRotate_img_width * idle_temperature_high_rotate_string.length;
                  img_offset -= idle_temperature_high_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of idle_temperature_high_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 4) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_temperature_high_TextRotate[index].setProperty(hmUI.prop.POS_X, 312 + img_offset);
                      idle_temperature_high_TextRotate[index].setProperty(hmUI.prop.SRC, idle_temperature_high_TextRotate_ASCIIARRAY[charCode]);
                      idle_temperature_high_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_temperature_high_TextRotate_img_width;
                      index++;
                    }  // end if digit
                    else { 
                      idle_temperature_high_TextRotate[index].setProperty(hmUI.prop.POS_X, 312 + img_offset);
                      idle_temperature_high_TextRotate[index].setProperty(hmUI.prop.SRC, 'pointer_3.png');
                      idle_temperature_high_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_temperature_high_TextRotate_dot_width;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                  idle_temperature_high_TextRotate_unit.setProperty(hmUI.prop.POS_X, 312 + img_offset);
                  idle_temperature_high_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite
                else {
                  idle_temperature_high_TextRotate[0].setProperty(hmUI.prop.POS_X, 312 - idle_temperature_high_TextRotate_error_img_width / 2);
                  idle_temperature_high_TextRotate[0].setProperty(hmUI.prop.SRC, 'dot.png');
                  idle_temperature_high_TextRotate[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

              console.log('update text rotate temperature_low_forecastData');
              let idle_temperature_low_rotate_string = undefined;
              if (temperature_low_temp > -100) {
                temperatureLow = 0;
                idle_temperature_low_rotate_string = String(temperature_low_temp)
              };

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 4; i++) {  // hide all symbols
                  idle_temperature_low_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                idle_temperature_low_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
                if (temperatureLow != null && temperatureLow != undefined && isFinite(temperatureLow) && idle_temperature_low_rotate_string.length > 0 && idle_temperature_low_rotate_string.length <= 4) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let idle_temperature_low_TextRotate_posOffset = idle_temperature_low_TextRotate_img_width * idle_temperature_low_rotate_string.length;
                  img_offset -= idle_temperature_low_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of idle_temperature_low_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 4) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_temperature_low_TextRotate[index].setProperty(hmUI.prop.POS_X, 228 + img_offset);
                      idle_temperature_low_TextRotate[index].setProperty(hmUI.prop.SRC, idle_temperature_low_TextRotate_ASCIIARRAY[charCode]);
                      idle_temperature_low_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_temperature_low_TextRotate_img_width;
                      index++;
                    }  // end if digit
                    else { 
                      idle_temperature_low_TextRotate[index].setProperty(hmUI.prop.POS_X, 228 + img_offset);
                      idle_temperature_low_TextRotate[index].setProperty(hmUI.prop.SRC, 'pointer_3.png');
                      idle_temperature_low_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_temperature_low_TextRotate_dot_width;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                  idle_temperature_low_TextRotate_unit.setProperty(hmUI.prop.POS_X, 228 + img_offset);
                  idle_temperature_low_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite
                else {
                  idle_temperature_low_TextRotate[0].setProperty(hmUI.prop.POS_X, 228 - idle_temperature_low_TextRotate_error_img_width / 2);
                  idle_temperature_low_TextRotate[0].setProperty(hmUI.prop.SRC, 'dot.png');
                  idle_temperature_low_TextRotate[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

              console.log('update text rotate temperature_current_currentWeather');
              let idle_temperature_current_rotate_string = undefined;
              if (temperature_current_temp > -100) {
                temperatureCurrent = 0;
                idle_temperature_current_rotate_string = String(temperature_current_temp)
              };

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 4; i++) {  // hide all symbols
                  idle_temperature_current_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                idle_temperature_current_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
                if (temperatureCurrent != null && temperatureCurrent != undefined && isFinite(temperatureCurrent) && idle_temperature_current_rotate_string.length > 0 && idle_temperature_current_rotate_string.length <= 4) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let idle_temperature_current_TextRotate_posOffset = idle_temperature_current_TextRotate_img_width * idle_temperature_current_rotate_string.length;
                  img_offset -= idle_temperature_current_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of idle_temperature_current_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 4) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_temperature_current_TextRotate[index].setProperty(hmUI.prop.POS_X, 140 + img_offset);
                      idle_temperature_current_TextRotate[index].setProperty(hmUI.prop.SRC, idle_temperature_current_TextRotate_ASCIIARRAY[charCode]);
                      idle_temperature_current_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_temperature_current_TextRotate_img_width;
                      index++;
                    }  // end if digit
                    else { 
                      idle_temperature_current_TextRotate[index].setProperty(hmUI.prop.POS_X, 140 + img_offset);
                      idle_temperature_current_TextRotate[index].setProperty(hmUI.prop.SRC, 'pointer_3.png');
                      idle_temperature_current_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_temperature_current_TextRotate_dot_width;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                  idle_temperature_current_TextRotate_unit.setProperty(hmUI.prop.POS_X, 140 + img_offset);
                  idle_temperature_current_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite
                else {
                  idle_temperature_current_TextRotate[0].setProperty(hmUI.prop.POS_X, 140 - idle_temperature_current_TextRotate_error_img_width / 2);
                  idle_temperature_current_TextRotate[0].setProperty(hmUI.prop.SRC, 'dot.png');
                  idle_temperature_current_TextRotate[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

              console.log('update text rotate day_TIME');
              let idle_day_rotate_string = parseInt(valueDay).toString();

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  idle_day_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueDay != null && valueDay != undefined && isFinite(valueDay) && idle_day_rotate_string.length > 0 && idle_day_rotate_string.length <= 2) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let idle_day_TextRotate_posOffset = idle_day_TextRotate_img_width * idle_day_rotate_string.length;
                  img_offset -= idle_day_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of idle_day_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_day_TextRotate[index].setProperty(hmUI.prop.POS_X, 414 + img_offset);
                      idle_day_TextRotate[index].setProperty(hmUI.prop.SRC, idle_day_TextRotate_ASCIIARRAY[charCode]);
                      idle_day_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_day_TextRotate_img_width;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite
                else {
                  idle_day_TextRotate[0].setProperty(hmUI.prop.POS_X, 414 - idle_day_TextRotate_error_img_width / 2);
                  idle_day_TextRotate[0].setProperty(hmUI.prop.SRC, 'dot.png');
                  idle_day_TextRotate[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

              console.log('update text rotate hour_TIME');
              let idle_hour_rotate_string = parseInt(valueHour).toString();
              idle_hour_rotate_string = idle_hour_rotate_string.padStart(2, '0');

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  idle_hour_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                idle_hour_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
                if (valueHour != null && valueHour != undefined && isFinite(valueHour) && idle_hour_rotate_string.length > 0 && idle_hour_rotate_string.length <= 2) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of idle_hour_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_hour_TextRotate[index].setProperty(hmUI.prop.POS_X, 48 + img_offset);
                      idle_hour_TextRotate[index].setProperty(hmUI.prop.SRC, idle_hour_TextRotate_ASCIIARRAY[charCode]);
                      idle_hour_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_hour_TextRotate_img_width + 2;
                      index++;
                    };  // end if digit
                  };  // end char of string
                  idle_hour_TextRotate_unit.setProperty(hmUI.prop.POS_X, 48 + img_offset);
                  idle_hour_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite
                else {
                  idle_hour_TextRotate[0].setProperty(hmUI.prop.POS_X, 48);
                  idle_hour_TextRotate[0].setProperty(hmUI.prop.SRC, 'dot.png');
                  idle_hour_TextRotate[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

              console.log('update text rotate minute_TIME');
              let idle_minute_rotate_string = parseInt(valueMinute).toString();
              idle_minute_rotate_string = idle_minute_rotate_string.padStart(2, '0');

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  idle_minute_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                idle_minute_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
                if (valueMinute != null && valueMinute != undefined && isFinite(valueMinute) && idle_minute_rotate_string.length > 0 && idle_minute_rotate_string.length <= 2) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of idle_minute_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_minute_TextRotate[index].setProperty(hmUI.prop.POS_X, 144 + img_offset);
                      idle_minute_TextRotate[index].setProperty(hmUI.prop.SRC, idle_minute_TextRotate_ASCIIARRAY[charCode]);
                      idle_minute_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_minute_TextRotate_img_width + 2;
                      index++;
                    };  // end if digit
                  };  // end char of string
                  idle_minute_TextRotate_unit.setProperty(hmUI.prop.POS_X, 144 + img_offset);
                  idle_minute_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite
                else {
                  idle_minute_TextRotate[0].setProperty(hmUI.prop.POS_X, 144);
                  idle_minute_TextRotate[0].setProperty(hmUI.prop.SRC, 'dot.png');
                  idle_minute_TextRotate[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

              console.log('update text rotate second_TIME');
              let idle_second_rotate_string = parseInt(valueSecond).toString();
              idle_second_rotate_string = idle_second_rotate_string.padStart(2, '0');

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  idle_second_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueSecond != null && valueSecond != undefined && isFinite(valueSecond) && idle_second_rotate_string.length > 0 && idle_second_rotate_string.length <= 2) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of idle_second_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_second_TextRotate[index].setProperty(hmUI.prop.POS_X, 240 + img_offset);
                      idle_second_TextRotate[index].setProperty(hmUI.prop.SRC, idle_second_TextRotate_ASCIIARRAY[charCode]);
                      idle_second_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_second_TextRotate_img_width + 2;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite
                else {
                  idle_second_TextRotate[0].setProperty(hmUI.prop.POS_X, 240);
                  idle_second_TextRotate[0].setProperty(hmUI.prop.SRC, 'dot.png');
                  idle_second_TextRotate[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

            };

            //end of ignored block
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                text_update();

                let nawAnimationTime = now.utc;;
                
                let delay_anim_rotate_1 = 0;
                let repeat_anim_rotate_1 = 15000;
                delay_anim_rotate_1 = repeat_anim_rotate_1 - (nawAnimationTime - normal_rotate_animation_lastTime_1);
                if(delay_anim_rotate_1 < 0) delay_anim_rotate_1 = 0; 
                if((nawAnimationTime - normal_rotate_animation_lastTime_1) > repeat_anim_rotate_1) {
                  normal_rotate_animation_count_1 = 0;
                  timer_anim_rotate_1_mirror = false;
                };

                if (!timer_anim_rotate_1) {
                  timer_anim_rotate_1 = timer.createTimer(delay_anim_rotate_1, repeat_anim_rotate_1, (function (option) {
                    anim_rotate_1_complete_call()
                  })); // end timer create
                };
                
                let delay_anim_rotate_2 = 0;
                let repeat_anim_rotate_2 = 15000;
                delay_anim_rotate_2 = repeat_anim_rotate_2 - (nawAnimationTime - normal_rotate_animation_lastTime_2);
                if(delay_anim_rotate_2 < 0) delay_anim_rotate_2 = 0; 
                if((nawAnimationTime - normal_rotate_animation_lastTime_2) > repeat_anim_rotate_2) {
                  normal_rotate_animation_count_2 = 0;
                  timer_anim_rotate_2_mirror = false;
                };

                if (!timer_anim_rotate_2) {
                  timer_anim_rotate_2 = timer.createTimer(delay_anim_rotate_2, repeat_anim_rotate_2, (function (option) {
                    anim_rotate_2_complete_call()
                  })); // end timer create
                };
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerTextUpdate) {
                    normal_timerTextUpdate = timer.createTimer(0, 1000, (function (option) {
                      text_update();
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.AOD) {
                  if (!idle_timerTextUpdate) {
                    idle_timerTextUpdate = timer.createTimer(0, 1000, (function (option) {
                      text_update();
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                console.log('pause_call()');
                stop_anim_rotate_1();
                stop_anim_rotate_2();
                if (normal_timerTextUpdate) {
                  timer.stopTimer(normal_timerTextUpdate);
                  normal_timerTextUpdate = undefined;
                }
                if (idle_timerTextUpdate) {
                  timer.stopTimer(idle_timerTextUpdate);
                  idle_timerTextUpdate = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
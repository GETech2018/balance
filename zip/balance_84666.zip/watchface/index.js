﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js
		// user_script_end START
		let cc = 0
		// user_script_end END
		
		// Hands START
		let handsnumber = 1
        let total_hands = 3

        function click_HANDS() {
            if(handsnumber==total_hands) {
            handsnumber=1;
                UpdatehandsOne();
                }
            else {
                handsnumber=handsnumber+1;
                if(handsnumber==2) {
                  UpdatehandsTwo();
                }
				if(handsnumber==3) {
                  UpdatehandsThree();
                }
            }
            if(handsnumber==1) hmUI.showToast({text: 'NORMAL SEC'});
            if(handsnumber==2) hmUI.showToast({text: 'SMOOTH SEC'});
			if(handsnumber==3) hmUI.showToast({text: 'NO SECOND'});
        }

        function UpdatehandsOne(){
                normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, true);
        }

        function UpdatehandsTwo(){
                normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.VISIBLE, true);
                normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, false);
        }
		
        function UpdatehandsThree(){
                normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, false);
        }
		// Hands END
		
		// Content START	
		let element1_index = 1;
        let element1_count = 3;
		
		function click_CONTENT() {
              element1_index++;
              if(element1_index > element1_count) element1_index = 1;
			  
			  normal_image_img.setProperty(hmUI.prop.VISIBLE, element1_index == 1);
			  normal_date_img_date_month_img.setProperty(hmUI.prop.VISIBLE, element1_index == 1);
			  normal_date_img_date_day.setProperty(hmUI.prop.VISIBLE, element1_index == 1);
			  normal_date_img_date_week_img.setProperty(hmUI.prop.VISIBLE, element1_index == 1);
			  normal_digital_clock_img_time.setProperty(hmUI.prop.VISIBLE, element1_index == 1);
			  Button_5.setProperty(hmUI.prop.VISIBLE, element1_index == 1);
			  Button_6.setProperty(hmUI.prop.VISIBLE, element1_index == 1);
			  Button_7.setProperty(hmUI.prop.VISIBLE, element1_index == 1);
			  
			  normal_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, element1_index == 2);
			  normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, element1_index == 2);
			  normal_temperature_high_text_img.setProperty(hmUI.prop.VISIBLE, element1_index == 2);
			  normal_temperature_low_text_img.setProperty(hmUI.prop.VISIBLE, element1_index == 2);
			  normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, element1_index == 2);
			  Button_8.setProperty(hmUI.prop.VISIBLE, element1_index == 2);
			  Button_9.setProperty(hmUI.prop.VISIBLE, element1_index == 2);
			  
			  normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, element1_index == 3);
			  normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, element1_index == 3);
			  normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, element1_index == 3);
			  normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, element1_index == 3);
			  Button_10.setProperty(hmUI.prop.VISIBLE, element1_index == 3);
			  Button_11.setProperty(hmUI.prop.VISIBLE, element1_index == 3);
			  Button_12.setProperty(hmUI.prop.VISIBLE, element1_index == 3);
			  
			  if (element1_index == 1) {
                hmUI.showToast({text: 'TIME/DATE'});
              };
              if (element1_index == 2) {
                hmUI.showToast({text: 'WEATHER'});
              };
              if (element1_index == 3) {
                hmUI.showToast({text: 'ACTIVITY'});
              };
        };
		// ontent END
        // end user_functions.js

        let normal_background_bg = ''
        let normal_battery_linear_scale = ''
        let normal_battery_icon_img = ''
        let normal_step_icon_img = ''
        let normal_step_current_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_temperature_icon_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_high_text_img = ''
        let normal_temperature_low_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_image_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_digital_clock_img_time = ''
        let normal_system_disconnect_img = ''
        let normal_spo2_icon_img = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_analog_clock_pro_second_pointer_img = ''
        let normal_timerUpdateSecSmooth = undefined;
        let lastTime = 0;
        let idle_background_bg = ''
        let idle_battery_linear_scale = ''
        let idle_battery_icon_img = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_system_disconnect_img = ''
        let idle_calorie_icon_img = ''
        let image_top_img = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let Button_7 = ''
        let Button_8 = ''
        let Button_9 = ''
        let Button_10 = ''
        let Button_11 = ''
        let Button_12 = ''
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFFC0C0C0',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            if (screenType != hmSetting.screen_type.AOD) {
              normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 192,
              // start_y: 172,
              // color: 0xFF4E5047,
              // lenght: 96,
              // line_width: 24,
              // line_cap: Flat,
              // vertical: False,
              // mirror: False,
              // inversion: True,
              // alpha: 255,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'main1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'sym_act.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 174,
              y: 319,
              font_array: ["big_00.png","big_01.png","big_02.png","big_03.png","big_04.png","big_05.png","big_06.png","big_07.png","big_08.png","big_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 265,
              y: 282,
              font_array: ["small_00.png","small_01.png","small_02.png","small_03.png","small_04.png","small_05.png","small_06.png","small_07.png","small_08.png","small_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 190,
              y: 282,
              font_array: ["small_00.png","small_01.png","small_02.png","small_03.png","small_04.png","small_05.png","small_06.png","small_07.png","small_08.png","small_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'sym_wea.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 172,
              y: 317,
              image_array: ["weatherd_00.png","weatherd_01.png","weatherd_02.png","weatherd_03.png","weatherd_04.png","weatherd_05.png","weatherd_06.png","weatherd_07.png","weatherd_08.png","weatherd_09.png","weatherd_10.png","weatherd_11.png","weatherd_12.png","weatherd_13.png","weatherd_14.png","weatherd_15.png","weatherd_16.png","weatherd_17.png","weatherd_18.png","weatherd_19.png","weatherd_20.png","weatherd_21.png","weatherd_22.png","weatherd_23.png","weatherd_24.png","weatherd_25.png","weatherd_26.png","weatherd_27.png","weatherd_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 186,
              y: 282,
              font_array: ["small_00.png","small_01.png","small_02.png","small_03.png","small_04.png","small_05.png","small_06.png","small_07.png","small_08.png","small_09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'small_11.png',
              unit_tc: 'small_11.png',
              unit_en: 'small_11.png',
              imperial_unit_sc: 'small_11.png',
              imperial_unit_tc: 'small_11.png',
              imperial_unit_en: 'small_11.png',
              negative_image: 'small_10.png',
              invalid_image: 'small_10.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const temperatureUnit = hmSetting.getTemperatureUnit();
            //start of ignored block
            if (temperatureUnit == 1) {
              normal_temperature_high_text_img.setProperty(hmUI.prop.MORE, {
                x: 186,
                y: 282,
                font_array: ["small_00.png","small_01.png","small_02.png","small_03.png","small_04.png","small_05.png","small_06.png","small_07.png","small_08.png","small_09.png"],
                padding: false,
                h_space: 0,
                unit_sc: 'small_11.png',
                unit_tc: 'small_11.png',
                unit_en: 'small_11.png',
                imperial_unit_sc: 'small_11.png',
                imperial_unit_tc: 'small_11.png',
                imperial_unit_en: 'small_11.png',
                negative_image: 'small_10.png',
                invalid_image: 'small_10.png',
                align_h: hmUI.align.CENTER_H,
                type: hmUI.data_type.WEATHER_HIGH,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
            };
            //end of ignored block

            normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 256,
              y: 282,
              font_array: ["small_00.png","small_01.png","small_02.png","small_03.png","small_04.png","small_05.png","small_06.png","small_07.png","small_08.png","small_09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'small_11.png',
              unit_tc: 'small_11.png',
              unit_en: 'small_11.png',
              imperial_unit_sc: 'small_11.png',
              imperial_unit_tc: 'small_11.png',
              imperial_unit_en: 'small_11.png',
              negative_image: 'small_10.png',
              invalid_image: 'small_10.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            //start of ignored block
            if (temperatureUnit == 1) {
              normal_temperature_low_text_img.setProperty(hmUI.prop.MORE, {
                x: 256,
                y: 282,
                font_array: ["small_00.png","small_01.png","small_02.png","small_03.png","small_04.png","small_05.png","small_06.png","small_07.png","small_08.png","small_09.png"],
                padding: false,
                h_space: 0,
                unit_sc: 'small_11.png',
                unit_tc: 'small_11.png',
                unit_en: 'small_11.png',
                imperial_unit_sc: 'small_11.png',
                imperial_unit_tc: 'small_11.png',
                imperial_unit_en: 'small_11.png',
                negative_image: 'small_10.png',
                invalid_image: 'small_10.png',
                align_h: hmUI.align.CENTER_H,
                type: hmUI.data_type.WEATHER_LOW,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
            };
            //end of ignored block

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 216,
              y: 319,
              font_array: ["big_00.png","big_01.png","big_02.png","big_03.png","big_04.png","big_05.png","big_06.png","big_07.png","big_08.png","big_09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'big_11.png',
              unit_tc: 'big_11.png',
              unit_en: 'big_11.png',
              imperial_unit_sc: 'big_11.png',
              imperial_unit_tc: 'big_11.png',
              imperial_unit_en: 'big_11.png',
              negative_image: 'big_10.png',
              invalid_image: 'big_10.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            //start of ignored block
            if (temperatureUnit == 1) {
              normal_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
                x: 216,
                y: 319,
                font_array: ["big_00.png","big_01.png","big_02.png","big_03.png","big_04.png","big_05.png","big_06.png","big_07.png","big_08.png","big_09.png"],
                padding: false,
                h_space: 0,
                unit_sc: 'big_11.png',
                unit_tc: 'big_11.png',
                unit_en: 'big_11.png',
                imperial_unit_sc: 'big_11.png',
                imperial_unit_tc: 'big_11.png',
                imperial_unit_en: 'big_11.png',
                negative_image: 'big_10.png',
                invalid_image: 'big_10.png',
                align_h: hmUI.align.CENTER_H,
                type: hmUI.data_type.WEATHER_CURRENT,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
            };
            //end of ignored block

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'sym_tim.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 262,
              month_startY: 282,
              month_sc_array: ["mo_01.png","mo_02.png","mo_03.png","mo_04.png","mo_05.png","mo_06.png","mo_07.png","mo_08.png","mo_09.png","mo_10.png","mo_11.png","mo_12.png"],
              month_tc_array: ["mo_01.png","mo_02.png","mo_03.png","mo_04.png","mo_05.png","mo_06.png","mo_07.png","mo_08.png","mo_09.png","mo_10.png","mo_11.png","mo_12.png"],
              month_en_array: ["mo_01.png","mo_02.png","mo_03.png","mo_04.png","mo_05.png","mo_06.png","mo_07.png","mo_08.png","mo_09.png","mo_10.png","mo_11.png","mo_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 226,
              day_startY: 282,
              day_sc_array: ["small_00.png","small_01.png","small_02.png","small_03.png","small_04.png","small_05.png","small_06.png","small_07.png","small_08.png","small_09.png"],
              day_tc_array: ["small_00.png","small_01.png","small_02.png","small_03.png","small_04.png","small_05.png","small_06.png","small_07.png","small_08.png","small_09.png"],
              day_en_array: ["small_00.png","small_01.png","small_02.png","small_03.png","small_04.png","small_05.png","small_06.png","small_07.png","small_08.png","small_09.png"],
              day_zero: 1,
              day_space: -1,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 170,
              y: 282,
              week_en: ["wd_01.png","wd_02.png","wd_03.png","wd_04.png","wd_05.png","wd_06.png","wd_07.png"],
              week_tc: ["wd_01.png","wd_02.png","wd_03.png","wd_04.png","wd_05.png","wd_06.png","wd_07.png"],
              week_sc: ["wd_01.png","wd_02.png","wd_03.png","wd_04.png","wd_05.png","wd_06.png","wd_07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 180,
              hour_startY: 319,
              hour_array: ["big_00.png","big_01.png","big_02.png","big_03.png","big_04.png","big_05.png","big_06.png","big_07.png","big_08.png","big_09.png"],
              hour_zero: 1,
              hour_space: 2,
              hour_angle: 0,
              hour_align: hmUI.align.RIGHT,

              minute_startX: 247,
              minute_startY: 319,
              minute_array: ["big_00.png","big_01.png","big_02.png","big_03.png","big_04.png","big_05.png","big_06.png","big_07.png","big_08.png","big_09.png"],
              minute_zero: 1,
              minute_space: 2,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 205,
              y: 52,
              src: 'bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'bezel.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hand_hour.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 240,
              hour_posY: 240,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'hand_min.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 240,
              minute_posY: 240,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'hand_sec.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 240,
              second_posY: 240,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const deviceInfo = hmSetting.getDeviceInfo();
            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'hand_sec.png',
              // center_x: 240,
              // center_y: 240,
              // x: 240,
              // y: 240,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 240,
              pos_y: 240 - 240,
              center_x: 240,
              center_y: 240,
              src: 'hand_sec.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            function startSecAnim(sec, animDuration) {
              const secAnim = {
                anim_steps: [{
                  anim_rate: 'linear',
                  anim_duration: animDuration,
                  anim_from: sec,
                  anim_to: sec + (360*(animDuration*6/1000))/360,
                  anim_key: 'angle',
                }],
                anim_fps: 15,
                anim_auto_start: 1,
                anim_repeat: 0,
                anim_auto_destroy: 1,
              }
              normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANIM, secAnim);
            }
            // normal_analog_clock_pro_smooth_second = hmUI.createWidget(hmUI.widget.SMOOTH_SECOND, {
              // type: 4,
              // fps: 15,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });



            console.log('Watch_Face.ScreenAOD');
            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFFC0C0C0',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            if (screenType == hmSetting.screen_type.AOD) {
              idle_battery_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // idle_battery_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 192,
              // start_y: 172,
              // color: 0xFF000000,
              // lenght: 96,
              // line_width: 24,
              // line_cap: Flat,
              // vertical: False,
              // mirror: False,
              // inversion: True,
              // alpha: 255,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'aod.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'aod_hour.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 240,
              hour_posY: 240,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'aod_min.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 240,
              minute_posY: 240,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 205,
              y: 52,
              src: 'bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'aod_top.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            image_top_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'hand_top.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 310,
              y: 275,
              w: 40,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                				click_CONTENT();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 210,
              y: 210,
              w: 60,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                				click_HANDS();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 210,
              y: 50,
              w: 60,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'FindPhoneScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 160,
              y: 159,
              w: 160,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PowerSaveHintScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 180,
              y: 271,
              w: 120,
              h: 45,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 180,
              y: 317,
              w: 59,
              h: 45,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'CountdownAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_7 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 241,
              y: 317,
              w: 59,
              h: 45,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'StopWatchScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_8 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 241,
              y: 317,
              w: 59,
              h: 45,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'WeatherScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_9 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 180,
              y: 317,
              w: 59,
              h: 45,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'BaroAltimeterScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_10 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 180,
              y: 317,
              w: 120,
              h: 45,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'activityAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_11 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 180,
              y: 271,
              w: 59,
              h: 45,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PAI_app_Screen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_12 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 241,
              y: 271,
              w: 59,
              h: 45,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'heart_app_Screen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            console.log('user_script_end.js');
            // start user_script_end.js
			if (cc ==0 ){
			  normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.VISIBLE, false);
			  
			  normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			  normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			  normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			  normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			  
			  normal_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			  normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
			  normal_temperature_high_text_img.setProperty(hmUI.prop.VISIBLE, false);
			  normal_temperature_low_text_img.setProperty(hmUI.prop.VISIBLE, false);
			  normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			  
			  Button_8.setProperty(hmUI.prop.VISIBLE, false);
			  Button_9.setProperty(hmUI.prop.VISIBLE, false);
			  Button_10.setProperty(hmUI.prop.VISIBLE, false);
			  Button_11.setProperty(hmUI.prop.VISIBLE, false);
			  Button_12.setProperty(hmUI.prop.VISIBLE, false);
			cc = 1;
			}
            // end user_script_end.js

            function scale_call() {
              console.log('scale_call()');

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_ls_normal_battery = 1 - progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_linear_scale
                  // initial parameters
                  let start_x_normal_battery = 288;
                  let start_y_normal_battery = 172;
                  let lenght_ls_normal_battery = -96;
                  let line_width_ls_normal_battery = 24;
                  let color_ls_normal_battery = 0xFF4E5047;
                  
                  // calculated parameters
                  let start_x_normal_battery_draw = start_x_normal_battery;
                  let start_y_normal_battery_draw = start_y_normal_battery;
                  lenght_ls_normal_battery = lenght_ls_normal_battery * progress_ls_normal_battery;
                  let lenght_ls_normal_battery_draw = lenght_ls_normal_battery;
                  let line_width_ls_normal_battery_draw = line_width_ls_normal_battery;
                  if (lenght_ls_normal_battery < 0){
                    lenght_ls_normal_battery_draw = -lenght_ls_normal_battery;
                    start_x_normal_battery_draw = start_x_normal_battery - lenght_ls_normal_battery_draw;
                  };
                  
                  normal_battery_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_battery_draw,
                    y: start_y_normal_battery_draw,
                    w: lenght_ls_normal_battery_draw,
                    h: line_width_ls_normal_battery_draw,
                    color: color_ls_normal_battery,
                  });
                };

                console.log('update scales BATTERY');
                let progress_ls_idle_battery = 1 - progressBattery;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_battery_linear_scale
                  // initial parameters
                  let start_x_idle_battery = 288;
                  let start_y_idle_battery = 172;
                  let lenght_ls_idle_battery = -96;
                  let line_width_ls_idle_battery = 24;
                  let color_ls_idle_battery = 0xFF000000;
                  
                  // calculated parameters
                  let start_x_idle_battery_draw = start_x_idle_battery;
                  let start_y_idle_battery_draw = start_y_idle_battery;
                  lenght_ls_idle_battery = lenght_ls_idle_battery * progress_ls_idle_battery;
                  let lenght_ls_idle_battery_draw = lenght_ls_idle_battery;
                  let line_width_ls_idle_battery_draw = line_width_ls_idle_battery;
                  if (lenght_ls_idle_battery < 0){
                    lenght_ls_idle_battery_draw = -lenght_ls_idle_battery;
                    start_x_idle_battery_draw = start_x_idle_battery - lenght_ls_idle_battery_draw;
                  };
                  
                  idle_battery_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_idle_battery_draw,
                    y: start_y_idle_battery_draw,
                    w: lenght_ls_idle_battery_draw,
                    h: line_width_ls_idle_battery_draw,
                    color: color_ls_idle_battery,
                  });
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                let secAngle = 0 + (360*6)*(timeSensor.second + ((timeSensor.utc % 1000) / 1000))/360;
                normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, secAngle);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSecSmooth) {
                    let duration = 0;
                    let animDuration = 5000;
                    if (timeSensor.second > 55) animDuration = 1000*(60.1 - (timeSensor.second - (timeSensor.utc % 1000) / 1000));
                    let diffTime = timeSensor.utc - lastTime;
                    if (diffTime < animDuration) duration = animDuration - diffTime;
                    normal_timerUpdateSecSmooth = timer.createTimer(duration, animDuration, (function (option) {
                      lastTime = timeSensor.utc;
                      secAngle = 0 + (360*6)*(timeSensor.second + ((timeSensor.utc % 1000) / 1000))/360;
                      startSecAnim(secAngle, animDuration);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerUpdateSecSmooth) {
                  timer.stopTimer(normal_timerUpdateSecSmooth);
                  normal_timerUpdateSecSmooth = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_battery_pointer_progress_img_pointer = ''
        let normal_battery_text_text_img = ''
        let normal_stress_icon_img = ''
        let normal_stress_text_text_img = ''
        let normal_stress_image_progress_img_level = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_calorie_icon_img = ''
        let normal_calorie_pointer_progress_img_pointer = ''
        let normal_calorie_current_text_img = ''
        let normal_step_icon_img = ''
        let normal_step_pointer_progress_img_pointer = ''
        let normal_step_current_text_img = ''
        let normal_digital_clock_img_time = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg_img = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_week_img = ''
        let idle_heart_rate_text_text_img = ''
        let idle_heart_rate_image_progress_img_level = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let normal_step_jumpable_img_click = ''
        let normal_cal_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
		let normal_stress_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_battery_jumpable_img_click = ''
        let normal_stand_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
		
		const { width: DEVICE_WIDTH, height: DEVICE_HEIGHT } = hmSetting.getDeviceInfo();
		
		let group1 = ''
		let group2 = ''
		let group3 = ''
		let group4 = ''
		
		let ac_switch_btn = ''
        let ac_state = 0
        let ac_state_txt = ''


        function click_ac_Switcher() {

        let ac_state_total = 2;

        ac_state = (ac_state + 1) % ac_state_total;

  switch (ac_state) {

      case 0:
        group1.setProperty(hmUI.prop.VISIBLE, true);
		group2.setProperty(hmUI.prop.VISIBLE, false);
        normal_cal_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_step_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
        ac_state_txt = 'Steps';
          break;

      case 1:
        group2.setProperty(hmUI.prop.VISIBLE, true);
		group1.setProperty(hmUI.prop.VISIBLE, false);
        normal_cal_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
        normal_step_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        ac_state_txt = 'Calorie';
      break;
    
      default:
          break;
  }

  hmUI.showToast({ text: ac_state_txt });
  
  
  
}


    let hs_switch_btn = ''
        let hs_state = 0
        let hs_state_txt = ''


        function click_hs_Switcher() {

        let hs_state_total = 2;

        hs_state = (hs_state + 1) % hs_state_total;

  switch (hs_state) {

      case 0:
        group3.setProperty(hmUI.prop.VISIBLE, true);
		group4.setProperty(hmUI.prop.VISIBLE, false);
        normal_stress_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_heart_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
        hs_state_txt = 'Pulse';
          break;

      case 1:
        group3.setProperty(hmUI.prop.VISIBLE, false);
		group4.setProperty(hmUI.prop.VISIBLE, true);
        normal_stress_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
        normal_heart_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        hs_state_txt = 'Stress';
      break;
    
      default:
          break;
  }

  hmUI.showToast({ text: hs_state_txt });
  
  
  
}




        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 69,
              month_startY: 143,
              month_sc_array: ["month_0.png","month_1.png","month_2.png","month_3.png","month_4.png","month_5.png","month_6.png","month_7.png","month_8.png","month_9.png","month_10.png","month_11.png"],
              month_tc_array: ["month_0.png","month_1.png","month_2.png","month_3.png","month_4.png","month_5.png","month_6.png","month_7.png","month_8.png","month_9.png","month_10.png","month_11.png"],
              month_en_array: ["month_0.png","month_1.png","month_2.png","month_3.png","month_4.png","month_5.png","month_6.png","month_7.png","month_8.png","month_9.png","month_10.png","month_11.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 115,
              day_startY: 137,
              day_sc_array: ["fonts_0.png","fonts_1.png","fonts_2.png","fonts_3.png","fonts_4.png","fonts_5.png","fonts_6.png","fonts_7.png","fonts_8.png","fonts_9.png"],
              day_tc_array: ["fonts_0.png","fonts_1.png","fonts_2.png","fonts_3.png","fonts_4.png","fonts_5.png","fonts_6.png","fonts_7.png","fonts_8.png","fonts_9.png"],
              day_en_array: ["fonts_0.png","fonts_1.png","fonts_2.png","fonts_3.png","fonts_4.png","fonts_5.png","fonts_6.png","fonts_7.png","fonts_8.png","fonts_9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 69,
              y: 328,
              week_en: ["week_0.png","week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png"],
              week_tc: ["week_0.png","week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png"],
              week_sc: ["week_0.png","week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'img_track_start.png',
              center_x: 239,
              center_y: 136,
              x: 10,
              y: 62,
              start_angle: -140,
              end_angle: 140,
              invalid_visible: false,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 208,
              y: 118,
              font_array: ["fs_0.png","fs_1.png","fs_2.png","fs_3.png","fs_4.png","fs_5.png","fs_6.png","fs_7.png","fs_8.png","fs_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			group4 = hmUI.createWidget(hmUI.widget.GROUP, {
	                  x: 0,
	                  y: 0,
	                  w: DEVICE_WIDTH,
	                  h: DEVICE_HEIGHT,
            });
			group4.setProperty(hmUI.prop.VISIBLE, false);

            normal_stress_icon_img = group4.createWidget(hmUI.widget.IMG, {
              x: 279,
              y: 179,
              src: 'stress.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_text_text_img = group4.createWidget(hmUI.widget.TEXT_IMG, {
              x: 309,
              y: 221,
              font_array: ["fs_0.png","fs_1.png","fs_2.png","fs_3.png","fs_4.png","fs_5.png","fs_6.png","fs_7.png","fs_8.png","fs_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STRESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_image_progress_img_level = group4.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 279,
              y: 179,
              image_array: ["s_1.png","s_2.png","s_3.png","s_4.png"],
              image_length: 4,
              type: hmUI.data_type.STRESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			group3 = hmUI.createWidget(hmUI.widget.GROUP, {
	                  x: 0,
	                  y: 0,
	                  w: DEVICE_WIDTH,
	                  h: DEVICE_HEIGHT,
            });

            normal_heart_rate_text_text_img = group3.createWidget(hmUI.widget.TEXT_IMG, {
              x: 309,
              y: 221,
              font_array: ["fs_0.png","fs_1.png","fs_2.png","fs_3.png","fs_4.png","fs_5.png","fs_6.png","fs_7.png","fs_8.png","fs_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = group3.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 280,
              y: 180,
              image_array: ["h_1.png","h_2.png","h_3.png","h_4.png","h_5.png","h_6.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			group2 = hmUI.createWidget(hmUI.widget.GROUP, {
	                  x: 0,
	                  y: 0,
	                  w: DEVICE_WIDTH,
	                  h: DEVICE_HEIGHT,
            });
			group2.setProperty(hmUI.prop.VISIBLE, false);

            normal_calorie_icon_img = group2.createWidget(hmUI.widget.IMG, {
              x: 177,
              y: 278,
              src: 'cal.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_pointer_progress_img_pointer = group2.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'img_track_start.png',
              center_x: 239,
              center_y: 340,
              x: 10,
              y: 62,
              start_angle: -140,
              end_angle: 140,
              invalid_visible: false,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = group2.createWidget(hmUI.widget.TEXT_IMG, {
              x: 201,
              y: 321,
              font_array: ["fs_0.png","fs_1.png","fs_2.png","fs_3.png","fs_4.png","fs_5.png","fs_6.png","fs_7.png","fs_8.png","fs_9.png"],
              padding: false,
              h_space: -1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			group1 = hmUI.createWidget(hmUI.widget.GROUP, {
	                  x: 0,
	                  y: 0,
	                  w: DEVICE_WIDTH,
	                  h: DEVICE_HEIGHT,
            });

            normal_step_icon_img = group1.createWidget(hmUI.widget.IMG, {
              x: 177,
              y: 278,
              src: 'step.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_pointer_progress_img_pointer = group1.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'img_track_start.png',
              center_x: 239,
              center_y: 340,
              x: 10,
              y: 62,
              start_angle: -141,
              end_angle: 139,
              invalid_visible: false,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = group1.createWidget(hmUI.widget.TEXT_IMG, {
              x: 202,
              y: 329,
              font_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 65,
              hour_startY: 167,
              hour_array: ["hour_0.png","hour_1.png","hour_2.png","hour_3.png","hour_4.png","hour_5.png","hour_6.png","hour_7.png","hour_8.png","hour_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 65,
              minute_startY: 247,
              minute_array: ["hour_0.png","hour_1.png","hour_2.png","hour_3.png","hour_4.png","hour_5.png","hour_6.png","hour_7.png","hour_8.png","hour_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hour.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 32,
              hour_posY: 239,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'minute.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 32,
              minute_posY: 240,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'second.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 32,
              second_posY: 240,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'aod.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 216,
              day_startY: 85,
              day_sc_array: ["fs_0.png","fs_1.png","fs_2.png","fs_3.png","fs_4.png","fs_5.png","fs_6.png","fs_7.png","fs_8.png","fs_9.png"],
              day_tc_array: ["fs_0.png","fs_1.png","fs_2.png","fs_3.png","fs_4.png","fs_5.png","fs_6.png","fs_7.png","fs_8.png","fs_9.png"],
              day_en_array: ["fs_0.png","fs_1.png","fs_2.png","fs_3.png","fs_4.png","fs_5.png","fs_6.png","fs_7.png","fs_8.png","fs_9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 202,
              y: 140,
              week_en: ["week_0.png","week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png"],
              week_tc: ["week_0.png","week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png"],
              week_sc: ["week_0.png","week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 208,
              y: 350,
              font_array: ["fs_0.png","fs_1.png","fs_2.png","fs_3.png","fs_4.png","fs_5.png","fs_6.png","fs_7.png","fs_8.png","fs_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 180,
              y: 309,
              image_array: ["h_1.png","h_2.png","h_3.png","h_4.png","h_5.png","h_6.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hour.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 32,
              hour_posY: 239,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'minute.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 32,
              minute_posY: 240,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 204,
              y: 310,
              w: 70,
              h: 50,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_cal_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 204,
              y: 310,
              w: 70,
              h: 50,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			 normal_cal_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 303,
              y: 195,
              w: 75,
              h: 60,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			normal_stress_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 303,
              y: 195,
              w: 75,
              h: 60,
              type: hmUI.data_type.STRESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_stress_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);

            hs_switch_btn = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 306,
              y: 266,
              text: '',
              w: 70,
              h: 50,
              normal_src: 'Empty.png',
              press_src: 'Empty.png',
              click_func: () => {
                click_hs_Switcher();
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            hs_switch_btn.setProperty(hmUI.prop.VISIBLE, true); 

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 202,
              y: 110,
              w: 75,
              h: 75,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            ac_switch_btn = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 204,
              y: 370,
              text: '',
              w: 70,
              h: 50,
              normal_src: 'Empty.png',
              press_src: 'Empty.png',
              click_func: () => {
                click_ac_Switcher();
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            ac_switch_btn.setProperty(hmUI.prop.VISIBLE, true); 

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 68,
              y: 260,
              w: 70,
              h: 50,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 68,
              y: 174,
              w: 75,
              h: 60,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 67,
              y: 325,
              w: 75,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 67,
              y: 120,
              w: 75,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'todoListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
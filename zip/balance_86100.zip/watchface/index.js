﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_battery_linear_scale = ''
        let normal_battery_text_text_img = ''
        let normal_battery_text_separator_img = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_text_separator_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let idle_battery_linear_scale = ''
        let idle_battery_text_text_img = ''
        let idle_battery_text_separator_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_day = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let normal_step_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_battery_jumpable_img_click = ''
        let normal_stand_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'WF.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 353,
              y: 64,
              image_array: ["weather_01.png","weather_02.png","weather_03.png","weather_04.png","weather_05.png","weather_06.png","weather_07.png","weather_08.png","weather_09.png","weather_10.png","weather_11.png","weather_12.png","weather_13.png","weather_14.png","weather_15.png","weather_16.png","weather_17.png","weather_18.png","weather_19.png","weather_20.png","weather_21.png","weather_22.png","weather_23.png","weather_24.png","weather_25.png","weather_26.png","weather_27.png","weather_28.png","weather_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 306,
              y: 295,
              font_array: ["Pastel_Orange_digit_01.png","Pastel_Orange_digit_02.png","Pastel_Orange_digit_03.png","Pastel_Orange_digit_04.png","Pastel_Orange_digit_05.png","Pastel_Orange_digit_06.png","Pastel_Orange_digit_07.png","Pastel_Orange_digit_08.png","Pastel_Orange_digit_09.png","Pastel_Orange_digit_10.png"],
              padding: false,
              h_space: -5,
              angle: -90,
              unit_sc: 'Weather_Degree.png',
              unit_tc: 'Weather_Degree.png',
              unit_en: 'Weather_Degree.png',
              imperial_unit_sc: 'Weather_Degree.png',
              imperial_unit_tc: 'Weather_Degree.png',
              imperial_unit_en: 'Weather_Degree.png',
              negative_image: 'Weather_min.png',
              invalid_image: 'Weather_err.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const temperatureUnit = hmSetting.getTemperatureUnit();
            //#region temperatureUnit
            if (temperatureUnit == 1) {
              normal_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
                x: 306,
                y: 295,
                font_array: ["Pastel_Orange_digit_01.png","Pastel_Orange_digit_02.png","Pastel_Orange_digit_03.png","Pastel_Orange_digit_04.png","Pastel_Orange_digit_05.png","Pastel_Orange_digit_06.png","Pastel_Orange_digit_07.png","Pastel_Orange_digit_08.png","Pastel_Orange_digit_09.png","Pastel_Orange_digit_10.png"],
                padding: false,
                h_space: -5,
                angle: -90,
                unit_sc: 'Weather_Degree.png',
                unit_tc: 'Weather_Degree.png',
                unit_en: 'Weather_Degree.png',
                imperial_unit_sc: 'Weather_Degree.png',
                imperial_unit_tc: 'Weather_Degree.png',
                imperial_unit_en: 'Weather_Degree.png',
                negative_image: 'Weather_min.png',
                invalid_image: 'Weather_err.png',
                align_h: hmUI.align.LEFT,
                type: hmUI.data_type.WEATHER_CURRENT,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
            };
            //#endregion

            let screenType = hmSetting.getScreenType();
            if (screenType != hmSetting.screen_type.AOD) {
              normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 261,
              // start_y: 264,
              // color: 0xFFFFFFFF,
              // lenght: 29,
              // line_width: 29,
              // line_cap: Flat,
              // vertical: True,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 254,
              y: 368,
              font_array: ["Pastel_Purple_digit_01.png","Pastel_Purple_digit_02.png","Pastel_Purple_digit_03.png","Pastel_Purple_digit_04.png","Pastel_Purple_digit_05.png","Pastel_Purple_digit_06.png","Pastel_Purple_digit_07.png","Pastel_Purple_digit_08.png","Pastel_Purple_digit_09.png","Pastel_Purple_digit_10.png"],
              padding: false,
              h_space: -5,
              angle: -90,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 249,
              y: 229,
              src: 'Battery.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 205,
              y: 438,
              font_array: ["Pastel_Green_digit_01.png","Pastel_Green_digit_02.png","Pastel_Green_digit_03.png","Pastel_Green_digit_04.png","Pastel_Green_digit_05.png","Pastel_Green_digit_06.png","Pastel_Green_digit_07.png","Pastel_Green_digit_08.png","Pastel_Green_digit_09.png","Pastel_Green_digit_10.png"],
              padding: false,
              h_space: -5,
              angle: -90,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 205,
              y: 221,
              src: 'STEPS.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 160,
              y: 364,
              font_array: ["Pastel_Red_digit_01.png","Pastel_Red_digit_02.png","Pastel_Red_digit_03.png","Pastel_Red_digit_04.png","Pastel_Red_digit_05.png","Pastel_Red_digit_06.png","Pastel_Red_digit_07.png","Pastel_Red_digit_08.png","Pastel_Red_digit_09.png","Pastel_Red_digit_10.png"],
              padding: false,
              h_space: -5,
              angle: -90,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 149,
              y: 240,
              src: 'Pulse.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 100,
              y: 108,
              week_en: ["day_01.png","day_02.png","day_03.png","day_04.png","day_05.png","day_06.png","day_07.png"],
              week_tc: ["day_01.png","day_02.png","day_03.png","day_04.png","day_05.png","day_06.png","day_07.png"],
              week_sc: ["day_01.png","day_02.png","day_03.png","day_04.png","day_05.png","day_06.png","day_07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 242,
              month_startY: 155,
              month_sc_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_tc_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_en_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 155,
              day_startY: 155,
              day_sc_array: ["Small_Blue_digit_01.png","Small_Blue_digit_02.png","Small_Blue_digit_03.png","Small_Blue_digit_04.png","Small_Blue_digit_05.png","Small_Blue_digit_06.png","Small_Blue_digit_07.png","Small_Blue_digit_08.png","Small_Blue_digit_09.png","Small_Blue_digit_10.png"],
              day_tc_array: ["Small_Blue_digit_01.png","Small_Blue_digit_02.png","Small_Blue_digit_03.png","Small_Blue_digit_04.png","Small_Blue_digit_05.png","Small_Blue_digit_06.png","Small_Blue_digit_07.png","Small_Blue_digit_08.png","Small_Blue_digit_09.png","Small_Blue_digit_10.png"],
              day_en_array: ["Small_Blue_digit_01.png","Small_Blue_digit_02.png","Small_Blue_digit_03.png","Small_Blue_digit_04.png","Small_Blue_digit_05.png","Small_Blue_digit_06.png","Small_Blue_digit_07.png","Small_Blue_digit_08.png","Small_Blue_digit_09.png","Small_Blue_digit_10.png"],
              day_zero: 1,
              day_space: -5,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 249,
              am_y: 26,
              am_sc_path: 'T_AM.png',
              am_en_path: 'T_AM.png',
              pm_x: 249,
              pm_y: 26,
              pm_sc_path: 'T_PM.png',
              pm_en_path: 'T_PM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 141,
              hour_startY: 67,
              hour_array: ["Big_Blue_digit_01.png","Big_Blue_digit_02.png","Big_Blue_digit_03.png","Big_Blue_digit_04.png","Big_Blue_digit_05.png","Big_Blue_digit_06.png","Big_Blue_digit_07.png","Big_Blue_digit_08.png","Big_Blue_digit_09.png","Big_Blue_digit_10.png"],
              hour_zero: 1,
              hour_space: -5,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 244,
              minute_startY: 67,
              minute_array: ["Big_Blue_digit_01.png","Big_Blue_digit_02.png","Big_Blue_digit_03.png","Big_Blue_digit_04.png","Big_Blue_digit_05.png","Big_Blue_digit_06.png","Big_Blue_digit_07.png","Big_Blue_digit_08.png","Big_Blue_digit_09.png","Big_Blue_digit_10.png"],
              minute_zero: 1,
              minute_space: -5,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 175,
              second_startY: 26,
              second_array: ["Pastel_White_digit_01.png","Pastel_White_digit_02.png","Pastel_White_digit_03.png","Pastel_White_digit_04.png","Pastel_White_digit_05.png","Pastel_White_digit_06.png","Pastel_White_digit_07.png","Pastel_White_digit_08.png","Pastel_White_digit_09.png","Pastel_White_digit_10.png"],
              second_zero: 0,
              second_space: -5,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 214,
              y: 67,
              src: 'Col.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');

            if (screenType == hmSetting.screen_type.AOD) {
              idle_battery_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // idle_battery_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 420,
              // start_y: 225,
              // color: 0xFFFFFFFF,
              // lenght: 29,
              // line_width: 29,
              // line_cap: Flat,
              // vertical: True,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 413,
              y: 331,
              font_array: ["Pastel_Purple_digit_01.png","Pastel_Purple_digit_02.png","Pastel_Purple_digit_03.png","Pastel_Purple_digit_04.png","Pastel_Purple_digit_05.png","Pastel_Purple_digit_06.png","Pastel_Purple_digit_07.png","Pastel_Purple_digit_08.png","Pastel_Purple_digit_09.png","Pastel_Purple_digit_10.png"],
              padding: false,
              h_space: -5,
              angle: -90,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 409,
              y: 191,
              src: 'Battery.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 60,
              y: 108,
              week_en: ["day_01.png","day_02.png","day_03.png","day_04.png","day_05.png","day_06.png","day_07.png"],
              week_tc: ["day_01.png","day_02.png","day_03.png","day_04.png","day_05.png","day_06.png","day_07.png"],
              week_sc: ["day_01.png","day_02.png","day_03.png","day_04.png","day_05.png","day_06.png","day_07.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 242,
              month_startY: 144,
              month_sc_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_tc_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_en_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 155,
              day_startY: 144,
              day_sc_array: ["Small_Blue_digit_01.png","Small_Blue_digit_02.png","Small_Blue_digit_03.png","Small_Blue_digit_04.png","Small_Blue_digit_05.png","Small_Blue_digit_06.png","Small_Blue_digit_07.png","Small_Blue_digit_08.png","Small_Blue_digit_09.png","Small_Blue_digit_10.png"],
              day_tc_array: ["Small_Blue_digit_01.png","Small_Blue_digit_02.png","Small_Blue_digit_03.png","Small_Blue_digit_04.png","Small_Blue_digit_05.png","Small_Blue_digit_06.png","Small_Blue_digit_07.png","Small_Blue_digit_08.png","Small_Blue_digit_09.png","Small_Blue_digit_10.png"],
              day_en_array: ["Small_Blue_digit_01.png","Small_Blue_digit_02.png","Small_Blue_digit_03.png","Small_Blue_digit_04.png","Small_Blue_digit_05.png","Small_Blue_digit_06.png","Small_Blue_digit_07.png","Small_Blue_digit_08.png","Small_Blue_digit_09.png","Small_Blue_digit_10.png"],
              day_zero: 1,
              day_space: -5,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 361,
              am_y: 235,
              am_sc_path: 'T_AM.png',
              am_en_path: 'T_AM.png',
              pm_x: 361,
              pm_y: 235,
              pm_sc_path: 'T_PM.png',
              pm_en_path: 'T_PM.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 125,
              hour_startY: 197,
              hour_array: ["Big_Blue_digit_01.png","Big_Blue_digit_02.png","Big_Blue_digit_03.png","Big_Blue_digit_04.png","Big_Blue_digit_05.png","Big_Blue_digit_06.png","Big_Blue_digit_07.png","Big_Blue_digit_08.png","Big_Blue_digit_09.png","Big_Blue_digit_10.png"],
              hour_zero: 1,
              hour_space: -5,
              hour_angle: 0,
              hour_unit_sc: 'Col.png',
              hour_unit_tc: 'Col.png',
              hour_unit_en: 'Col.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 261,
              minute_startY: 197,
              minute_array: ["Big_Blue_digit_01.png","Big_Blue_digit_02.png","Big_Blue_digit_03.png","Big_Blue_digit_04.png","Big_Blue_digit_05.png","Big_Blue_digit_06.png","Big_Blue_digit_07.png","Big_Blue_digit_08.png","Big_Blue_digit_09.png","Big_Blue_digit_10.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 203,
              y: 217,
              w: 46,
              h: 245,
              src: '0_Empty.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 156,
              y: 232,
              w: 46,
              h: 155,
              src: '0_Empty.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 251,
              y: 229,
              w: 46,
              h: 178,
              src: '0_Empty.png',
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 240,
              y: 0,
              w: 103,
              h: 72,
              src: '0_Empty.png',
              type: hmUI.data_type.STAND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 153,
              y: 153,
              w: 196,
              h: 57,
              text: '',
              color: 0xFFFF8C00,
              text_size: 26,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 355,
              y: 30,
              w: 52,
              h: 423,
              text: '',
              color: 0xFFFF8C00,
              text_size: 26,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'WeatherScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            function scale_call() {
              console.log('scale_call()');

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_ls_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_linear_scale
                  // initial parameters
                  let start_x_normal_battery = 261;
                  let start_y_normal_battery = 264;
                  let lenght_ls_normal_battery = 29;
                  let line_width_ls_normal_battery = 29;
                  let color_ls_normal_battery = 0xFFFFFFFF;
                  
                  // calculated parameters
                  let start_x_normal_battery_draw = start_x_normal_battery;
                  let start_y_normal_battery_draw = start_y_normal_battery;
                  lenght_ls_normal_battery = lenght_ls_normal_battery * progress_ls_normal_battery;
                  let lenght_ls_normal_battery_draw = line_width_ls_normal_battery;
                  let line_width_ls_normal_battery_draw = lenght_ls_normal_battery;
                  if (lenght_ls_normal_battery < 0){
                    line_width_ls_normal_battery_draw = -lenght_ls_normal_battery;
                    start_y_normal_battery_draw = start_y_normal_battery_draw - line_width_ls_normal_battery_draw;
                  };
                  
                  normal_battery_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_battery_draw,
                    y: start_y_normal_battery_draw,
                    w: lenght_ls_normal_battery_draw,
                    h: line_width_ls_normal_battery_draw,
                    color: color_ls_normal_battery,
                  });
                };

                console.log('update scales BATTERY');
                let progress_ls_idle_battery = progressBattery;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_battery_linear_scale
                  // initial parameters
                  let start_x_idle_battery = 420;
                  let start_y_idle_battery = 225;
                  let lenght_ls_idle_battery = 29;
                  let line_width_ls_idle_battery = 29;
                  let color_ls_idle_battery = 0xFFFFFFFF;
                  
                  // calculated parameters
                  let start_x_idle_battery_draw = start_x_idle_battery;
                  let start_y_idle_battery_draw = start_y_idle_battery;
                  lenght_ls_idle_battery = lenght_ls_idle_battery * progress_ls_idle_battery;
                  let lenght_ls_idle_battery_draw = line_width_ls_idle_battery;
                  let line_width_ls_idle_battery_draw = lenght_ls_idle_battery;
                  if (lenght_ls_idle_battery < 0){
                    line_width_ls_idle_battery_draw = -lenght_ls_idle_battery;
                    start_y_idle_battery_draw = start_y_idle_battery_draw - line_width_ls_idle_battery_draw;
                  };
                  
                  idle_battery_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_idle_battery_draw,
                    y: start_y_idle_battery_draw,
                    w: lenght_ls_idle_battery_draw,
                    h: line_width_ls_idle_battery_draw,
                    color: color_ls_idle_battery,
                  });
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
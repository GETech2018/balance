﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_humidity_text_text_img = ''
        let normal_humidity_text_separator_img = ''
        let normal_wind_direction_image_progress_img_level = ''
        let normal_wind_text_text_img = ''
        let normal_wind_text_separator_img = ''
        let normal_altitude_target_text_img = ''
        let normal_battery_linear_scale = ''
        let normal_battery_linear_scale_pointer_img = ''
        let normal_battery_text_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_calorie_current_separator_img = ''
        let normal_distance_text_text_img = ''
        let normal_distance_text_separator_img = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_day = ''
        let idle_digital_clock_img_time = ''
        let normal_altimeter_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
		
		let btn_zona1 = ''
        let zona1_num = 0
        let zona1_all = 2
		
		function click_zona1() {
		  zona1_num = (zona1_num + 1) % (zona1_all + 1);
          if (zona1_num == 0) {		
		    normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
            normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		    hmUI.showToast({
            });
          };
		  
		 if (zona1_num == 1) {
			normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		    hmUI.showToast({
            });
          };
		  
		  if (zona1_num == 2) {
			normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, true);
		    hmUI.showToast({
            });
          };
        }
		
		let btn_zona2 = ''
        let zona2_num = 0
        let zona2_all = 1
		
		function click_zona2() {
		  zona2_num = (zona2_num + 1) % (zona2_all + 1);
          if (zona2_num == 0) {
			
			
			
			normal_wind_direction_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);
            normal_wind_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_wind_text_separator_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_humidity_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_humidity_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		    hmUI.showToast({
            });
          };
		  
		 if (zona2_num == 1) {
			
			
			
			normal_wind_direction_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
            normal_wind_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_wind_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_humidity_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_humidity_text_separator_img.setProperty(hmUI.prop.VISIBLE, true);
		    hmUI.showToast({
            });
          };
        }


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 228,
              y: 5,
              src: '0090.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 272,
              y: 76,
              week_en: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              week_tc: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              week_sc: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 132,
              month_startY: 76,
              month_sc_array: ["m_1.png","m_2.png","m_3.png","m_4.png","m_5.png","m_6.png","m_7.png","m_8.png","m_9.png","m_10.png","m_11.png","m_12.png"],
              month_tc_array: ["m_1.png","m_2.png","m_3.png","m_4.png","m_5.png","m_6.png","m_7.png","m_8.png","m_9.png","m_10.png","m_11.png","m_12.png"],
              month_en_array: ["m_1.png","m_2.png","m_3.png","m_4.png","m_5.png","m_6.png","m_7.png","m_8.png","m_9.png","m_10.png","m_11.png","m_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 213,
              day_startY: 70,
              day_sc_array: ["date_0.png","date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png","date_8.png","date_9.png"],
              day_tc_array: ["date_0.png","date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png","date_8.png","date_9.png"],
              day_en_array: ["date_0.png","date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png","date_8.png","date_9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 108,
              y: 326,
              font_array: ["date_0.png","date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png","date_8.png","date_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 108,
              y: 299,
              src: 'humi.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_direction_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 163,
              y: 300,
              image_array: ["wind_1.png","wind_2.png","wind_3.png","wind_4.png","wind_5.png","wind_6.png","wind_7.png","wind_8.png"],
              image_length: 8,
              type: hmUI.data_type.WIND_DIRECTION,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 95,
              y: 326,
              font_array: ["date_0.png","date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png","date_8.png","date_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'winds.png',
              unit_tc: 'winds.png',
              unit_en: 'winds.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WIND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 95,
              y: 299,
              src: 'win.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altitude_target_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 205,
              y: 328,
              font_array: ["num_0.png","num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.ALTITUDE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            if (screenType != hmSetting.screen_type.AOD) {
              normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            normal_battery_linear_scale_pointer_img = hmUI.createWidget(hmUI.widget.IMG);
            // normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 166,
              // start_y: 407,
              // color: 0xFFFF8C00,
              // pointer: 'bat.png',
              // lenght: 151,
              // line_width: 17,
              // line_cap: Flat,
              // vertical: False,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 265,
              y: 372,
              font_array: ["num_0.png","num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 107,
              y: 136,
              font_array: ["date_0.png","date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png","date_8.png","date_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'grad.png',
              unit_tc: 'grad.png',
              unit_en: 'grad.png',
              negative_image: 'minus.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 307,
              y: 136,
              font_array: ["date_0.png","date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png","date_8.png","date_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 298,
              y: 326,
              font_array: ["date_0.png","date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png","date_8.png","date_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 315,
              y: 299,
              src: 'cal.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 294,
              y: 326,
              font_array: ["date_0.png","date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png","date_8.png","date_9.png"],
              padding: false,
              h_space: 0,
              dot_image: 'dot.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 318,
              y: 299,
              src: 'dist.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 289,
              y: 326,
              font_array: ["date_0.png","date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png","date_8.png","date_9.png"],
              padding: false,
              h_space: -2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 313,
              y: 299,
              src: 'steps.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 54,
              hour_startY: 190,
              hour_array: ["time_0.png","time_1.png","time_2.png","time_3.png","time_4.png","time_5.png","time_6.png","time_7.png","time_8.png","time_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_unit_sc: 'colon_time.png',
              hour_unit_tc: 'colon_time.png',
              hour_unit_en: 'colon_time.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 188,
              minute_startY: 190,
              minute_array: ["time_0.png","time_1.png","time_2.png","time_3.png","time_4.png","time_5.png","time_6.png","time_7.png","time_8.png","time_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_unit_sc: 'colon_sec.png',
              minute_unit_tc: 'colon_sec.png',
              minute_unit_en: 'colon_sec.png',
              minute_align: hmUI.align.LEFT,

              second_startX: 322,
              second_startY: 190,
              second_array: ["sec_0.png","sec_1.png","sec_2.png","sec_3.png","sec_4.png","sec_5.png","sec_6.png","sec_7.png","sec_8.png","sec_9.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 272,
              y: 76,
              week_en: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              week_tc: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              week_sc: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 132,
              month_startY: 76,
              month_sc_array: ["m_1.png","m_2.png","m_3.png","m_4.png","m_5.png","m_6.png","m_7.png","m_8.png","m_9.png","m_10.png","m_11.png","m_12.png"],
              month_tc_array: ["m_1.png","m_2.png","m_3.png","m_4.png","m_5.png","m_6.png","m_7.png","m_8.png","m_9.png","m_10.png","m_11.png","m_12.png"],
              month_en_array: ["m_1.png","m_2.png","m_3.png","m_4.png","m_5.png","m_6.png","m_7.png","m_8.png","m_9.png","m_10.png","m_11.png","m_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 213,
              day_startY: 70,
              day_sc_array: ["date_0.png","date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png","date_8.png","date_9.png"],
              day_tc_array: ["date_0.png","date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png","date_8.png","date_9.png"],
              day_en_array: ["date_0.png","date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png","date_8.png","date_9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 121,
              hour_startY: 190,
              hour_array: ["time_0.png","time_1.png","time_2.png","time_3.png","time_4.png","time_5.png","time_6.png","time_7.png","time_8.png","time_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_unit_sc: 'colon_time.png',
              hour_unit_tc: 'colon_time.png',
              hour_unit_en: 'colon_time.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 256,
              minute_startY: 190,
              minute_array: ["time_0.png","time_1.png","time_2.png","time_3.png","time_4.png","time_5.png","time_6.png","time_7.png","time_8.png","time_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_altimeter_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 218,
              y: 310,
              w: 50,
              h: 50,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 80,
              y: 115,
              w: 100,
              h: 60,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            btn_zona2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 100,
              y: 305,
              text: '',
              w: 100,
              h: 60,
              normal_src: 'Empty.png',
              press_src: 'Empty.png',
              click_func: () => {
				click_zona2();
                click_Vibrate();
             },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btn_zona2.setProperty(hmUI.prop.VISIBLE, true);
			normal_humidity_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_humidity_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);

            btn_zona1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 305,
              y: 304,
              text: '',
              w: 100,
              h: 60,
              normal_src: 'Empty.png',
              press_src: 'Empty.png',
              click_func: () => {
				click_zona1();
                click_Vibrate();
             },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btn_zona1.setProperty(hmUI.prop.VISIBLE, true);
			normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 305,
              y: 115,
              w: 100,
              h: 60,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            function scale_call() {
              console.log('scale_call()');

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_ls_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_linear_scale
                  // initial parameters
                  let start_x_normal_battery = 166;
                  let start_y_normal_battery = 407;
                  let lenght_ls_normal_battery = 151;
                  let line_width_ls_normal_battery = 17;
                  let color_ls_normal_battery = 0xFFFF8C00;
                  
                  // calculated parameters
                  let start_x_normal_battery_draw = start_x_normal_battery;
                  let start_y_normal_battery_draw = start_y_normal_battery;
                  lenght_ls_normal_battery = lenght_ls_normal_battery * progress_ls_normal_battery;
                  let lenght_ls_normal_battery_draw = lenght_ls_normal_battery;
                  let line_width_ls_normal_battery_draw = line_width_ls_normal_battery;
                  if (lenght_ls_normal_battery < 0){
                    lenght_ls_normal_battery_draw = -lenght_ls_normal_battery;
                    start_x_normal_battery_draw = start_x_normal_battery - lenght_ls_normal_battery_draw;
                  };
                  
                  normal_battery_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_battery_draw,
                    y: start_y_normal_battery_draw,
                    w: lenght_ls_normal_battery_draw,
                    h: line_width_ls_normal_battery_draw,
                    color: color_ls_normal_battery,
                  });
                  
                  // pointers parameters
                  let pointer_offset_x_ls_normal_battery = 2;
                  let pointer_offset_y_ls_normal_battery = 13;
                  normal_battery_linear_scale_pointer_img.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_battery + lenght_ls_normal_battery - pointer_offset_x_ls_normal_battery,
                    y: start_y_normal_battery_draw + line_width_ls_normal_battery / 2 - pointer_offset_y_ls_normal_battery,
                    src: 'bat.png',
                    show_level: hmUI.show_level.ONLY_NORMAL,
                  });
                };

            };
			
		let secondImg = hmUI.createWidget(hmUI.widget.IMG, {
          x: 224,
          y: 150,
          src: "colon1.png",
          show_level: hmUI.show_level.ONLY_NORMAL
        });

        let milli_value = 0
        let second_value = 0
        let min_value = 0
        let flag = true

        let constSecond = 0
        let constMin = 0

        let minPoint = null
        let hourPoint = null

        let createCount = 0;
        let bigNumObject = new Array(8)
        let smallNumObject = new Array(8)

        let bigNumArr = [
          "time_0.png",
          "time_1.png",
          "time_2.png",
          "time_3.png",
          "time_4.png",
          "time_5.png",
          "time_6.png",
          "time_7.png",
          "time_8.png",
          "time_9.png",
        ]
        let smallNumArr = [
          "smallNum_0.png",
          "smallNum_1.png",
          "smallNum_2.png",
          "smallNum_3.png",
          "smallNum_4.png",
          "smallNum_5.png",
          "smallNum_6.png",
          "smallNum_7.png",
          "smallNum_8.png",
          "smallNum_9.png",
        ]
        for (let i = 0; i < bigNumObject.length; i++) {
          //console.log(i+'uuuuu')
          if (i == 2 || i == 5) {
            bigNumObject[i] = hmUI.createWidget(hmUI.widget.IMG, {
              x: 63 + i * 47,
              y: 208,
              src: "colon_time.png",
              show_level: hmUI.show_level.ONLY_NORMAL
            });
          } else {
            bigNumObject[i] = hmUI.createWidget(hmUI.widget.IMG, {
              x: 50 + i * 47,
              y: 208,
              src: "time_0.png",
              show_level: hmUI.show_level.ONLY_NORMAL
            });
          }
          bigNumObject[i].setProperty(hmUI.prop.VISIBLE, false); //false隐藏 true显示
        }
        for (let j = 0; j < smallNumObject.length; j++) {
          if (j == 2 || j == 5) {
            smallNumObject[j] = hmUI.createWidget(hmUI.widget.IMG, {
              x: 185 + j * 14,
              y: 186,
              src: "smallNum_n.png",
              show_level: hmUI.show_level.ONLY_NORMAL
            });
          } else {
            smallNumObject[j] = hmUI.createWidget(hmUI.widget.IMG, {
              x: 180 + j * 14,
              y: 186,
              src: "smallNum_0.png",
              show_level: hmUI.show_level.ONLY_NORMAL
            });
          }
          smallNumObject[j].setProperty(hmUI.prop.VISIBLE, false); //false隐藏 true显示
        }
        let backBtn = hmUI.createWidget(hmUI.widget.IMG, {
          x: 430,
          y: 225,
          src: "back.png",
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        backBtn.setProperty(hmUI.prop.VISIBLE, false);
        let green_red_btn = hmUI.createWidget(hmUI.widget.IMG, {
          x: 10,
          y: 225,
          src: "lv.png",
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        green_red_btn.setProperty(hmUI.prop.VISIBLE, false);
        secondImg.addEventListener(hmUI.event.CLICK_UP, (function (info) {

          normal_digital_clock_img_time.setProperty(hmUI.prop.VISIBLE, false);

          secondImg.setProperty(hmUI.prop.VISIBLE, false);
          for (let n = 0; n < 8; n++) {
            bigNumObject[n].setProperty(hmUI.prop.VISIBLE, true); //false隐藏 true显示
            smallNumObject[n].setProperty(hmUI.prop.VISIBLE, true); //false隐藏 true显示  
            if (n == 0 || n == 1 || n == 3 || n == 4 || n == 6 || n == 7) {
              bigNumObject[n].setProperty(hmUI.prop.SRC, "time_0.png")
              smallNumObject[n].setProperty(hmUI.prop.SRC, "smallNum_0.png")
            }
          }
          milli_value = 0
          second_value = 0
          min_value = 0

          constSecond = 0
          constMin = 0
          backBtn.setProperty(hmUI.prop.VISIBLE, true);
          green_red_btn.setProperty(hmUI.prop.VISIBLE, true);
          flag = true
        }));
        backBtn.addEventListener(hmUI.event.CLICK_UP, (function (info) {
          timer.stopTimer(hsTimer)
          timer.stopTimer(sTimer)
          green_red_btn.setProperty(hmUI.prop.SRC, "lv.png"); //false隐藏 true显示 
          for (let n = 0; n < 8; n++) {
            bigNumObject[n].setProperty(hmUI.prop.VISIBLE, false); //false隐藏 true显示
            smallNumObject[n].setProperty(hmUI.prop.VISIBLE, false); //false隐藏 true显示
          }
          backBtn.setProperty(hmUI.prop.VISIBLE, false); //false隐藏 true显示
          green_red_btn.setProperty(hmUI.prop.VISIBLE, false); //false隐藏 true显示

          normal_digital_clock_img_time.setProperty(hmUI.prop.VISIBLE, true);

          secondImg.setProperty(hmUI.prop.VISIBLE, true);

        }));
        green_red_btn.addEventListener(hmUI.event.CLICK_UP, (function (info) {
          flag = !flag
          // minPoint.setProperty(hmUI.prop.ANGLE, 0)
          // hourPoint.setProperty(hmUI.prop.ANGLE, 0)
          if (flag) {
            green_red_btn.setProperty(hmUI.prop.SRC, "lv.png"); //false隐藏 true显示 
            timer.stopTimer(hsTimer)
            timer.stopTimer(sTimer)
            bigNumObject[0].setProperty(hmUI.prop.SRC, "time_0.png")
            bigNumObject[1].setProperty(hmUI.prop.SRC, "time_0.png")
            bigNumObject[3].setProperty(hmUI.prop.SRC, "time_0.png")
            bigNumObject[4].setProperty(hmUI.prop.SRC, "time_0.png")
            bigNumObject[6].setProperty(hmUI.prop.SRC, "time_0.png")
            bigNumObject[7].setProperty(hmUI.prop.SRC, "time_0.png")

            smallNumObject[0].setProperty(hmUI.prop.SRC, "smallNum_" + hmFS.SysProGetInt("t0") + ".png")
            smallNumObject[1].setProperty(hmUI.prop.SRC, "smallNum_" + hmFS.SysProGetInt("t1") + ".png")
            smallNumObject[3].setProperty(hmUI.prop.SRC, "smallNum_" + hmFS.SysProGetInt("t3") + ".png")
            smallNumObject[4].setProperty(hmUI.prop.SRC, "smallNum_" + hmFS.SysProGetInt("t4") + ".png")
            smallNumObject[6].setProperty(hmUI.prop.SRC, "smallNum_" + hmFS.SysProGetInt("t6") + ".png")
            smallNumObject[7].setProperty(hmUI.prop.SRC, "smallNum_" + hmFS.SysProGetInt("t7") + ".png")
          } else {
            green_red_btn.setProperty(hmUI.prop.SRC, "red.png"); //false隐藏 true显示 
            hmFS.SysProSetInt("t0", 0);
            hmFS.SysProSetInt("t1", 0);
            hmFS.SysProSetInt("t3", 0);
            hmFS.SysProSetInt("t4", 0);
            hmFS.SysProSetInt("t6", 0);
            hmFS.SysProSetInt("t7", 0);
            milli_value = 0
            second_value = 0
            min_value = 0

            constSecond = 0
            constMin = 0
            timerSample()

          }
        }));
        let hsTimer = null
        let sTimer = null
        function setHaomiao(t) {
          if (milli_value >= 99) {
            milli_value = -1
          }
          milli_value++
          bigNumObject[6].setProperty(hmUI.prop.SRC, "time_" + parseInt(milli_value / 10) + ".png")
          bigNumObject[7].setProperty(hmUI.prop.SRC, "time_" + parseInt(milli_value % 10) + ".png")

          hmFS.SysProSetInt("t6", parseInt(milli_value / 10));
          hmFS.SysProSetInt("t7", parseInt(milli_value % 10));

        }
        function setmiao(t) {
          if (second_value >= 59) {
            second_value = -1
          }
          second_value++
          constSecond++
          //setAngle(constSecond)
          if (second_value == 0) {
            min_value++
            setfen()
          }
          bigNumObject[3].setProperty(hmUI.prop.SRC, "time_" + parseInt(second_value / 10) + ".png")
          bigNumObject[4].setProperty(hmUI.prop.SRC, "time_" + parseInt(second_value % 10) + ".png")

          hmFS.SysProSetInt("t3", parseInt(second_value / 10));
          hmFS.SysProSetInt("t4", parseInt(second_value % 10));


        }
        function setfen(t) {
          if (min_value > 59) {
            min_value = 59
          }
          // console.log(parseInt(min_value / 10) + 'hhhhh')
          // console.log(parseInt(min_value % 10) + '%%%%%')
          bigNumObject[0].setProperty(hmUI.prop.SRC, "time_" + parseInt(min_value / 10) + ".png")
          bigNumObject[1].setProperty(hmUI.prop.SRC, "time_" + parseInt(min_value % 10) + ".png")

          hmFS.SysProSetInt("t0", parseInt(min_value / 10));
          hmFS.SysProSetInt("t1", parseInt(min_value % 10));
        }
        function timerSample() {
          //console.log('999999')
          hsTimer = timer.createTimer(
            10, 10, setHaomiao
            , {})
          sTimer = timer.createTimer(
            1000, 1000, setmiao
            , {})
        }
		
		const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
			   console.log('resume_call()');
                scale_call();
              }),
            });

            

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
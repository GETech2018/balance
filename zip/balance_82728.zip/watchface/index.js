﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg = ''
        let normal_frame_animation_1 = ''
        let normal_system_disconnect_img = ''
        let normal_battery_icon_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_pai_icon_img = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg = ''
        let idle_spo2_icon_img = ''
        let idle_battery_icon_img = ''
        let idle_battery_text_text_img = ''
        let idle_battery_image_progress_img_level = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_month = ''
        let idle_date_img_date_day = ''
        let idle_pai_icon_img = ''
        let idle_digital_clock_img_time = ''
        let normal_battery_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let Button_1 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_frame_animation_1 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
              x: 0,
              y: 0,
              anim_path: "animation",
              anim_ext: "png",
              anim_prefix: "first_anim",
              anim_fps: 20,
              anim_size: 24,
              repeat_count: 0,
              anim_repeat: true,
              anim_status:hmUI.anim_status.START,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 0,
              y: 0,
              src: 'top.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 194,
              y: 70,
              src: 'baty.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 209,
              y: 108,
              font_array: ["blue_0.png","blue_1.png","blue_2.png","blue_3.png","blue_4.png","blue_5.png","blue_6.png","blue_7.png","blue_8.png","blue_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: '%.png',
              unit_tc: '%.png',
              unit_en: '%.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 194,
              y: 70,
              image_array: ["batt_1.png","batt_2.png","batt_3.png","batt_4.png","batt_5.png","batt_6.png","batt_7.png","batt_8.png","batt_9.png","batt_10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 248,
              y: 316,
              week_en: ["0.png","1.png","2.png","3.png","4.png","5.png","6.png"],
              week_tc: ["0.png","1.png","2.png","3.png","4.png","5.png","6.png"],
              week_sc: ["0.png","1.png","2.png","3.png","4.png","5.png","6.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 192,
              month_startY: 310,
              month_sc_array: ["classic_stamp_num_0.png","classic_stamp_num_1.png","classic_stamp_num_2.png","classic_stamp_num_3.png","classic_stamp_num_4.png","classic_stamp_num_5.png","classic_stamp_num_6.png","classic_stamp_num_7.png","classic_stamp_num_8.png","classic_stamp_num_9.png"],
              month_tc_array: ["classic_stamp_num_0.png","classic_stamp_num_1.png","classic_stamp_num_2.png","classic_stamp_num_3.png","classic_stamp_num_4.png","classic_stamp_num_5.png","classic_stamp_num_6.png","classic_stamp_num_7.png","classic_stamp_num_8.png","classic_stamp_num_9.png"],
              month_en_array: ["classic_stamp_num_0.png","classic_stamp_num_1.png","classic_stamp_num_2.png","classic_stamp_num_3.png","classic_stamp_num_4.png","classic_stamp_num_5.png","classic_stamp_num_6.png","classic_stamp_num_7.png","classic_stamp_num_8.png","classic_stamp_num_9.png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 140,
              day_startY: 310,
              day_sc_array: ["classic_stamp_num_0.png","classic_stamp_num_1.png","classic_stamp_num_2.png","classic_stamp_num_3.png","classic_stamp_num_4.png","classic_stamp_num_5.png","classic_stamp_num_6.png","classic_stamp_num_7.png","classic_stamp_num_8.png","classic_stamp_num_9.png"],
              day_tc_array: ["classic_stamp_num_0.png","classic_stamp_num_1.png","classic_stamp_num_2.png","classic_stamp_num_3.png","classic_stamp_num_4.png","classic_stamp_num_5.png","classic_stamp_num_6.png","classic_stamp_num_7.png","classic_stamp_num_8.png","classic_stamp_num_9.png"],
              day_en_array: ["classic_stamp_num_0.png","classic_stamp_num_1.png","classic_stamp_num_2.png","classic_stamp_num_3.png","classic_stamp_num_4.png","classic_stamp_num_5.png","classic_stamp_num_6.png","classic_stamp_num_7.png","classic_stamp_num_8.png","classic_stamp_num_9.png"],
              day_zero: 1,
              day_space: 0,
              day_unit_sc: 'dot_1.png',
              day_unit_tc: 'dot_1.png',
              day_unit_en: 'dot_1.png',
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'shad.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 88,
              hour_startY: 166,
              hour_array: ["s_0.png","s_1.png","s_2.png","s_3.png","s_4.png","s_5.png","s_6.png","s_7.png","s_8.png","s_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_unit_sc: 'colons_4.png',
              hour_unit_tc: 'colons_4.png',
              hour_unit_en: 'colons_4.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 252,
              minute_startY: 166,
              minute_array: ["s_0.png","s_1.png","s_2.png","s_3.png","s_4.png","s_5.png","s_6.png","s_7.png","s_8.png","s_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_spo2_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'top.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 194,
              y: 70,
              src: 'baty.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 209,
              y: 108,
              font_array: ["blue_0.png","blue_1.png","blue_2.png","blue_3.png","blue_4.png","blue_5.png","blue_6.png","blue_7.png","blue_8.png","blue_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: '%.png',
              unit_tc: '%.png',
              unit_en: '%.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 194,
              y: 70,
              image_array: ["batt_1.png","batt_2.png","batt_3.png","batt_4.png","batt_5.png","batt_6.png","batt_7.png","batt_8.png","batt_9.png","batt_10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 248,
              y: 305,
              week_en: ["0.png","1.png","2.png","3.png","4.png","5.png","6.png"],
              week_tc: ["0.png","1.png","2.png","3.png","4.png","5.png","6.png"],
              week_sc: ["0.png","1.png","2.png","3.png","4.png","5.png","6.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 192,
              month_startY: 300,
              month_sc_array: ["classic_stamp_num_0.png","classic_stamp_num_1.png","classic_stamp_num_2.png","classic_stamp_num_3.png","classic_stamp_num_4.png","classic_stamp_num_5.png","classic_stamp_num_6.png","classic_stamp_num_7.png","classic_stamp_num_8.png","classic_stamp_num_9.png"],
              month_tc_array: ["classic_stamp_num_0.png","classic_stamp_num_1.png","classic_stamp_num_2.png","classic_stamp_num_3.png","classic_stamp_num_4.png","classic_stamp_num_5.png","classic_stamp_num_6.png","classic_stamp_num_7.png","classic_stamp_num_8.png","classic_stamp_num_9.png"],
              month_en_array: ["classic_stamp_num_0.png","classic_stamp_num_1.png","classic_stamp_num_2.png","classic_stamp_num_3.png","classic_stamp_num_4.png","classic_stamp_num_5.png","classic_stamp_num_6.png","classic_stamp_num_7.png","classic_stamp_num_8.png","classic_stamp_num_9.png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 140,
              day_startY: 300,
              day_sc_array: ["classic_stamp_num_0.png","classic_stamp_num_1.png","classic_stamp_num_2.png","classic_stamp_num_3.png","classic_stamp_num_4.png","classic_stamp_num_5.png","classic_stamp_num_6.png","classic_stamp_num_7.png","classic_stamp_num_8.png","classic_stamp_num_9.png"],
              day_tc_array: ["classic_stamp_num_0.png","classic_stamp_num_1.png","classic_stamp_num_2.png","classic_stamp_num_3.png","classic_stamp_num_4.png","classic_stamp_num_5.png","classic_stamp_num_6.png","classic_stamp_num_7.png","classic_stamp_num_8.png","classic_stamp_num_9.png"],
              day_en_array: ["classic_stamp_num_0.png","classic_stamp_num_1.png","classic_stamp_num_2.png","classic_stamp_num_3.png","classic_stamp_num_4.png","classic_stamp_num_5.png","classic_stamp_num_6.png","classic_stamp_num_7.png","classic_stamp_num_8.png","classic_stamp_num_9.png"],
              day_zero: 1,
              day_space: 0,
              day_unit_sc: 'dot_1.png',
              day_unit_tc: 'dot_1.png',
              day_unit_en: 'dot_1.png',
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_pai_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'shad.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 88,
              hour_startY: 166,
              hour_array: ["s_0.png","s_1.png","s_2.png","s_3.png","s_4.png","s_5.png","s_6.png","s_7.png","s_8.png","s_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_unit_sc: 'colons_4.png',
              hour_unit_tc: 'colons_4.png',
              hour_unit_en: 'colons_4.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 252,
              minute_startY: 166,
              minute_array: ["s_0.png","s_1.png","s_2.png","s_3.png","s_4.png","s_5.png","s_6.png","s_7.png","s_8.png","s_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 205,
              y: 85,
              w: 75,
              h: 75,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 284,
              y: 194,
              w: 80,
              h: 90,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 118,
              y: 194,
              w: 80,
              h: 90,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 185,
              y: 305,
              w: 120,
              h: 45,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              longpress_func: (button_widget) => {
                hmApp.startApp({url: 'todoListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);

              }),
              pause_call: (function () {
                console.log('pause_call()');
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
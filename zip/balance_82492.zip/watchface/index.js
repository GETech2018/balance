﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_frame_animation_1 = ''
        let normal_spo2_icon_img = ''
        let normal_uvi_text_text_img = ''
        let normal_aqi_text_text_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_week_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_pai_weekly_text_img = ''
        let normal_step_current_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_sun_high_text_img = ''
        let normal_sun_low_text_img = ''
        let normal_system_dnd_img = ''
        let normal_system_clock_img = ''
        let normal_system_disconnect_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_battery_text_text_img = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let normal_step_jumpable_img_click = ''
        let normal_cal_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_battery_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: '2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_frame_animation_1 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
              x: 0,
              y: 0,
              anim_path: "animation",
              anim_ext: "png",
              anim_prefix: "first_anim_ducjf",
              anim_fps: 25,
              anim_size: 48,
              repeat_count: 0,
              anim_repeat: true,
              anim_status:hmUI.anim_status.START,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: '2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_uvi_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 167,
              y: 218,
              font_array: ["3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png","12.png"],
              padding: false,
              h_space: 0,
              invalid_image: '13.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.UVI,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_aqi_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 54,
              y: 218,
              font_array: ["3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png","12.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.AQI,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 80,
              day_startY: 78,
              day_sc_array: ["3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png","12.png"],
              day_tc_array: ["3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png","12.png"],
              day_en_array: ["3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png","12.png"],
              day_zero: 1,
              day_space: 0,
              day_unit_sc: 'sl.png',
              day_unit_tc: 'sl.png',
              day_unit_en: 'sl.png',
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 117,
              month_startY: 78,
              month_sc_array: ["3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png","12.png"],
              month_tc_array: ["3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png","12.png"],
              month_en_array: ["3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png","12.png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 146,
              y: 79,
              week_en: ["24.png","25.png","26.png","27.png","28.png","29.png","30.png"],
              week_tc: ["24.png","25.png","26.png","27.png","28.png","29.png","30.png"],
              week_sc: ["24.png","25.png","26.png","27.png","28.png","29.png","30.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 70,
              y: 346,
              font_array: ["3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png","12.png"],
              padding: false,
              h_space: 0,
              invalid_image: '31.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 175,
              y: 271,
              font_array: ["3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png","12.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_weekly_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 171,
              y: 346,
              font_array: ["3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png","12.png"],
              padding: false,
              h_space: -1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 57,
              y: 271,
              font_array: ["3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png","12.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 116,
              y: 382,
              font_array: ["3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png","12.png"],
              padding: false,
              h_space: 0,
              dot_image: '32.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 195,
              y: 23,
              image_array: ["w_0.png","w_1.png","w_2.png","w_3.png","w_4.png","w_5.png","w_6.png","w_7.png","w_8.png","w_9.png","w_10.png","w_11.png","w_12.png","w_13.png","w_14.png","w_15.png","w_16.png","w_17.png","w_18.png","w_19.png","w_20.png","w_21.png","w_22.png","w_23.png","w_24.png","w_25.png","w_26.png","w_27.png","w_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 240,
              y: 32,
              font_array: ["62.png","63.png","64.png","65.png","66.png","67.png","68.png","69.png","70.png","71.png"],
              padding: false,
              h_space: 0,
              unit_sc: '74.png',
              unit_tc: '74.png',
              unit_en: '74.png',
              negative_image: '73.png',
              invalid_image: '72.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 300,
              y: 87,
              font_array: ["76.png","77.png","78.png","79.png","80.png","81.png","82.png","83.png","84.png","85.png"],
              padding: true,
              h_space: 0,
              invalid_image: '86.png',
              dot_image: '87.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 300,
              y: 385,
              font_array: ["76.png","77.png","78.png","79.png","80.png","81.png","82.png","83.png","84.png","85.png"],
              padding: true,
              h_space: 0,
              dot_image: '88.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 77,
              y: 165,
              src: '89.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 33,
              y: 164,
              src: '90.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 265,
              y: 165,
              src: 'bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 0,
              y: 394,
              image_array: ["91.png","92.png","93.png","94.png","95.png","96.png","97.png","98.png","99.png","100.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 238,
              y: 427,
              font_array: ["3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png","12.png"],
              padding: false,
              h_space: 0,
              unit_sc: '101.png',
              unit_tc: '101.png',
              unit_en: '101.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 48,
              hour_startY: 101,
              hour_array: ["102.png","103.png","104.png","105.png","106.png","107.png","108.png","109.png","110.png","111.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 159,
              minute_startY: 101,
              minute_array: ["102.png","103.png","104.png","105.png","106.png","107.png","108.png","109.png","110.png","111.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 197,
              second_startY: 170,
              second_array: ["112.png","113.png","114.png","115.png","116.png","117.png","118.png","119.png","120.png","121.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 123,
              am_y: 169,
              am_sc_path: '122.png',
              am_en_path: '122.png',
              pm_x: 123,
              pm_y: 169,
              pm_sc_path: '123.png',
              pm_en_path: '123.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 146,
              hour_startY: 211,
              hour_array: ["102.png","103.png","104.png","105.png","106.png","107.png","108.png","109.png","110.png","111.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_unit_sc: 'colon.png',
              hour_unit_tc: 'colon.png',
              hour_unit_en: 'colon.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 254,
              minute_startY: 211,
              minute_array: ["102.png","103.png","104.png","105.png","106.png","107.png","108.png","109.png","110.png","111.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 40,
              y: 262,
              w: 75,
              h: 60,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_cal_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 160,
              y: 262,
              w: 75,
              h: 60,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 60,
              y: 326,
              w: 70,
              h: 45,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 164,
              y: 326,
              w: 70,
              h: 45,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 195,
              y: 420,
              w: 100,
              h: 55,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 300,
              y: 75,
              w: 70,
              h: 50,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 45,
              y: 202,
              w: 70,
              h: 50,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 172,
              y: 102,
              w: 55,
              h: 55,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 190,
              y: 162,
              w: 50,
              h: 50,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 65,
              y: 102,
              w: 55,
              h: 55,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);

              }),
              pause_call: (function () {
                console.log('pause_call()');
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
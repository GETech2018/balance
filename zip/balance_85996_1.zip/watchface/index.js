﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_date_img_date_week_img = ''
        let normal_stand_circle_scale = ''
        let normal_stand_pointer_progress_img_pointer = ''
        let normal_stand_current_text_img = ''
        let normal_stand_current_separator_img = ''
        let normal_date_img_date_day = ''
        let normal_date_day_separator_img = ''
        let normal_date_img_date_month_img = ''
        let normal_heart_rate_circle_scale_2 = ''
        let normal_heart_rate_pointer_progress_img_pointer = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_text_separator_img = ''
        let normal_step_circle_scale = ''
        let normal_step_pointer_progress_img_pointer = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_battery_circle_scale = ''
        let normal_battery_pointer_progress_img_pointer = ''
        let normal_battery_text_text_img = ''
        let normal_battery_text_separator_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_hour_TextRotate = new Array(2);
        let normal_hour_TextRotate_ASCIIARRAY = new Array(10);
        let normal_hour_TextRotate_img_width = 187;
        let normal_timerTextUpdate = undefined;
        let normal_digital_clock_img_time = ''
        let normal_minute_TextRotate = new Array(2);
        let normal_minute_TextRotate_ASCIIARRAY = new Array(10);
        let normal_minute_TextRotate_img_width = 187;
        let idle_background_bg = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let normal_step_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_battery_jumpable_img_click = ''
        let normal_stand_jumpable_img_click = ''
        let Button_1 = ''
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'WF.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 152,
              y: 383,
              week_en: ["Italian_day_01.png","Italian_day_02.png","Italian_day_03.png","Italian_day_04.png","Italian_day_05.png","Italian_day_06.png","Italian_day_07.png"],
              week_tc: ["Italian_day_01.png","Italian_day_02.png","Italian_day_03.png","Italian_day_04.png","Italian_day_05.png","Italian_day_06.png","Italian_day_07.png"],
              week_sc: ["Italian_day_01.png","Italian_day_02.png","Italian_day_03.png","Italian_day_04.png","Italian_day_05.png","Italian_day_06.png","Italian_day_07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_stand_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 240,
              // center_y: 240,
              // start_angle: 13,
              // end_angle: 77,
              // radius: 212,
              // line_width: 12,
              // line_cap: Rounded,
              // color: 0xFFA6A6A6,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.STAND,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            let screenType = hmSetting.getScreenType();
            normal_stand_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 240,
              center_y: 240,
              start_angle: 13,
              end_angle: 77,
              radius: 206,
              line_width: 12,
              corner_flag: 0,
              color: 0xFFA6A6A6,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const stand = hmSensor.createSensor(hmSensor.id.STAND);
            stand.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_stand_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: '0_Pointer.png',
              center_x: 240,
              center_y: 240,
              x: 14,
              y: 219,
              start_angle: 13,
              end_angle: 77,
              invalid_visible: false,
              type: hmUI.data_type.STAND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 373,
              y: 139,
              font_array: ["digit_01.png","digit_02.png","digit_03.png","digit_04.png","digit_05.png","digit_06.png","digit_07.png","digit_08.png","digit_09.png","digit_10.png"],
              padding: true,
              h_space: -5,
              angle: 65,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STAND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 426,
              y: 199,
              src: 'Stand.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 199,
              day_startY: 57,
              day_sc_array: ["digit_01.png","digit_02.png","digit_03.png","digit_04.png","digit_05.png","digit_06.png","digit_07.png","digit_08.png","digit_09.png","digit_10.png"],
              day_tc_array: ["digit_01.png","digit_02.png","digit_03.png","digit_04.png","digit_05.png","digit_06.png","digit_07.png","digit_08.png","digit_09.png","digit_10.png"],
              day_en_array: ["digit_01.png","digit_02.png","digit_03.png","digit_04.png","digit_05.png","digit_06.png","digit_07.png","digit_08.png","digit_09.png","digit_10.png"],
              day_zero: 1,
              day_space: -5,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_day_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 160,
              y: 50,
              src: 'Cal_fill.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 244,
              month_startY: 50,
              month_sc_array: ["Italian_Month_01.png","Italian_Month_02.png","Italian_Month_03.png","Italian_Month_04.png","Italian_Month_05.png","Italian_Month_06.png","Italian_Month_07.png","Italian_Month_08.png","Italian_Month_09.png","Italian_Month_10.png","Italian_Month_11.png","Italian_Month_12.png"],
              month_tc_array: ["Italian_Month_01.png","Italian_Month_02.png","Italian_Month_03.png","Italian_Month_04.png","Italian_Month_05.png","Italian_Month_06.png","Italian_Month_07.png","Italian_Month_08.png","Italian_Month_09.png","Italian_Month_10.png","Italian_Month_11.png","Italian_Month_12.png"],
              month_en_array: ["Italian_Month_01.png","Italian_Month_02.png","Italian_Month_03.png","Italian_Month_04.png","Italian_Month_05.png","Italian_Month_06.png","Italian_Month_07.png","Italian_Month_08.png","Italian_Month_09.png","Italian_Month_10.png","Italian_Month_11.png","Italian_Month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_circle_scale_2 = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 240,
              center_y: 240,
              start_angle: 103,
              end_angle: 167,
              radius: 206,
              line_width: 12,
              corner_flag: 0,
              type: hmUI.data_type.HEART,
              color: 0xFFA6A6A6,
              // mirror: False,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: '0_Pointer.png',
              center_x: 240,
              center_y: 240,
              x: 14,
              y: 219,
              start_angle: 103,
              end_angle: 167,
              invalid_visible: false,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 363,
              y: 330,
              font_array: ["digit_01.png","digit_02.png","digit_03.png","digit_04.png","digit_05.png","digit_06.png","digit_07.png","digit_08.png","digit_09.png","digit_10.png"],
              padding: false,
              h_space: -5,
              angle: -60,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 423,
              y: 242,
              src: 'Heart.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 240,
              // center_y: 240,
              // start_angle: 257,
              // end_angle: 193,
              // radius: 212,
              // line_width: 12,
              // line_cap: Rounded,
              // color: 0xFFA6A6A6,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 240,
              center_y: 240,
              start_angle: 257,
              end_angle: 193,
              radius: 206,
              line_width: 12,
              corner_flag: 0,
              color: 0xFFA6A6A6,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_step_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: '0_Pointer.png',
              center_x: 240,
              center_y: 240,
              x: 14,
              y: 219,
              start_angle: 257,
              end_angle: 193,
              invalid_visible: false,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 49,
              y: 283,
              font_array: ["digit_01.png","digit_02.png","digit_03.png","digit_04.png","digit_05.png","digit_06.png","digit_07.png","digit_08.png","digit_09.png","digit_10.png"],
              padding: false,
              h_space: -5,
              angle: 55,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 21,
              y: 239,
              src: 'sneaker.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 240,
              // center_y: 240,
              // start_angle: -13,
              // end_angle: -77,
              // radius: 212,
              // line_width: 12,
              // line_cap: Rounded,
              // color: 0xFFA6A6A6,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 240,
              center_y: 240,
              start_angle: -13,
              end_angle: -77,
              radius: 206,
              line_width: 12,
              corner_flag: 0,
              color: 0xFFA6A6A6,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: '0_Pointer.png',
              center_x: 240,
              center_y: 240,
              x: 14,
              y: 219,
              start_angle: -13,
              end_angle: -77,
              invalid_visible: false,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 55,
              y: 164,
              font_array: ["digit_01.png","digit_02.png","digit_03.png","digit_04.png","digit_05.png","digit_06.png","digit_07.png","digit_08.png","digit_09.png","digit_10.png"],
              padding: false,
              h_space: -5,
              angle: -70,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 21,
              y: 200,
              src: 'Bat5.png',
              // alpha: 60,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_separator_img.setAlpha(60);

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 21,
              y: 198,
              image_array: ["Bat1.png","Bat2.png","Bat3.png","Bat4.png","Bat5.png"],
              image_length: 5,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 0,
              am_y: 0,
              am_sc_path: '10.png',
              am_en_path: '10.png',
              pm_x: 0,
              pm_y: 0,
              pm_sc_path: '10.png',
              pm_en_path: '10.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_hour_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 376,
              // y: 88,
              // font_array: ["Big_digit_01.png","Big_digit_02.png","Big_digit_03.png","Big_digit_04.png","Big_digit_05.png","Big_digit_06.png","Big_digit_07.png","Big_digit_08.png","Big_digit_09.png","Big_digit_10.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: 206,
              // angle: 0,
              // align_h: hmUI.align.RIGHT,
              // type: hmUI.data_type.HOUR,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_hour_TextRotate_ASCIIARRAY[0] = 'Big_digit_01.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[1] = 'Big_digit_02.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[2] = 'Big_digit_03.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[3] = 'Big_digit_04.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[4] = 'Big_digit_05.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[5] = 'Big_digit_06.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[6] = 'Big_digit_07.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[7] = 'Big_digit_08.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[8] = 'Big_digit_09.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[9] = 'Big_digit_10.png';  // set of images with numbers

            //#region TextRotate
            for (let i = 0; i < 2; i++) {
              normal_hour_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 376,
                center_y: 88,
                pos_x: 376,
                pos_y: 88,
                angle: 0,
                src: 'Big_digit_01.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_hour_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //#endregion

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 103,
              hour_startY: 88,
              hour_array: ["Big_digit_01.png","Big_digit_02.png","Big_digit_03.png","Big_digit_04.png","Big_digit_05.png","Big_digit_06.png","Big_digit_07.png","Big_digit_08.png","Big_digit_09.png","Big_digit_10.png"],
              hour_zero: 1,
              hour_space: 361,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 103,
              minute_startY: 221,
              minute_array: ["Big_digit_01.png","Big_digit_02.png","Big_digit_03.png","Big_digit_04.png","Big_digit_05.png","Big_digit_06.png","Big_digit_07.png","Big_digit_08.png","Big_digit_09.png","Big_digit_10.png"],
              minute_zero: 1,
              minute_space: 369,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_minute_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 376,
              // y: 221,
              // font_array: ["Big_digit_01.png","Big_digit_02.png","Big_digit_03.png","Big_digit_04.png","Big_digit_05.png","Big_digit_06.png","Big_digit_07.png","Big_digit_08.png","Big_digit_09.png","Big_digit_10.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: 258,
              // angle: 0,
              // align_h: hmUI.align.RIGHT,
              // type: hmUI.data_type.MINUTE,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_minute_TextRotate_ASCIIARRAY[0] = 'Big_digit_01.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[1] = 'Big_digit_02.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[2] = 'Big_digit_03.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[3] = 'Big_digit_04.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[4] = 'Big_digit_05.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[5] = 'Big_digit_06.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[6] = 'Big_digit_07.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[7] = 'Big_digit_08.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[8] = 'Big_digit_09.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[9] = 'Big_digit_10.png';  // set of images with numbers

            //#region TextRotate
            for (let i = 0; i < 2; i++) {
              normal_minute_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 376,
                center_y: 221,
                pos_x: 376,
                pos_y: 221,
                angle: 0,
                src: 'Big_digit_01.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_minute_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //#endregion


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 0,
              am_y: 0,
              am_sc_path: '10.png',
              am_en_path: '10.png',
              pm_x: 0,
              pm_y: 0,
              pm_sc_path: '10.png',
              pm_en_path: '10.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 85,
              hour_startY: 63,
              hour_array: ["AOD_digit_01.png","AOD_digit_02.png","AOD_digit_03.png","AOD_digit_04.png","AOD_digit_05.png","AOD_digit_06.png","AOD_digit_07.png","AOD_digit_08.png","AOD_digit_09.png","AOD_digit_10.png"],
              hour_zero: 1,
              hour_space: -115,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 85,
              minute_startY: 227,
              minute_array: ["AOD_digit_01.png","AOD_digit_02.png","AOD_digit_03.png","AOD_digit_04.png","AOD_digit_05.png","AOD_digit_06.png","AOD_digit_07.png","AOD_digit_08.png","AOD_digit_09.png","AOD_digit_10.png"],
              minute_zero: 1,
              minute_space: -115,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 2,
              y: 242,
              w: 103,
              h: 103,
              src: 'empty.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 374,
              y: 242,
              w: 103,
              h: 103,
              src: 'empty.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 2,
              y: 131,
              w: 103,
              h: 103,
              src: 'empty.png',
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 374,
              y: 131,
              w: 103,
              h: 103,
              src: 'empty.png',
              type: hmUI.data_type.STAND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 166,
              y: 56,
              w: 146,
              h: 41,
              text: '',
              color: 0xFFFF8C00,
              text_size: 26,
              press_src: 'empty.png',
              normal_src: 'empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            //#region text_update
            function text_update() {
              console.log('text_update()');

              console.log('update text rotate hour_TIME');
              let valueHour = timeSensor.format_hour;
              let normal_hour_rotate_string = parseInt(valueHour).toString();
              normal_hour_rotate_string = normal_hour_rotate_string.padStart(2, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_hour_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueHour != null && valueHour != undefined && isFinite(valueHour) && normal_hour_rotate_string.length > 0 && normal_hour_rotate_string.length <= 2) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = RIGHT
                  let normal_hour_TextRotate_posOffset = normal_hour_TextRotate_img_width * normal_hour_rotate_string.length;
                  normal_hour_TextRotate_posOffset = normal_hour_TextRotate_posOffset + 206 * (normal_hour_rotate_string.length - 1);
                  img_offset -= normal_hour_TextRotate_posOffset;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_hour_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_hour_TextRotate[index].setProperty(hmUI.prop.POS_X, 376 + img_offset);
                      normal_hour_TextRotate[index].setProperty(hmUI.prop.SRC, normal_hour_TextRotate_ASCIIARRAY[charCode]);
                      normal_hour_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_hour_TextRotate_img_width + 206;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate minute_TIME');
              let valueMinute = timeSensor.minute;
              let normal_minute_rotate_string = parseInt(valueMinute).toString();
              normal_minute_rotate_string = normal_minute_rotate_string.padStart(2, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_minute_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueMinute != null && valueMinute != undefined && isFinite(valueMinute) && normal_minute_rotate_string.length > 0 && normal_minute_rotate_string.length <= 2) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = RIGHT
                  let normal_minute_TextRotate_posOffset = normal_minute_TextRotate_img_width * normal_minute_rotate_string.length;
                  normal_minute_TextRotate_posOffset = normal_minute_TextRotate_posOffset + 258 * (normal_minute_rotate_string.length - 1);
                  img_offset -= normal_minute_TextRotate_posOffset;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_minute_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_minute_TextRotate[index].setProperty(hmUI.prop.POS_X, 376 + img_offset);
                      normal_minute_TextRotate[index].setProperty(hmUI.prop.SRC, normal_minute_TextRotate_ASCIIARRAY[charCode]);
                      normal_minute_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_minute_TextRotate_img_width + 258;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

            };

            //#endregion
            function scale_call() {
              console.log('scale_call()');

                console.log('update scales STAND');
                
                let valueStand = stand.current;
                let targetStand = stand.target;
                let progressStand = valueStand/targetStand;
                if (progressStand > 1) progressStand = 1;
                let progress_cs_normal_stand = progressStand;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_stand_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_stand * 100);
                  if (normal_stand_circle_scale) {
                    normal_stand_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 240,
                      center_y: 240,
                      start_angle: 13,
                      end_angle: 77,
                      radius: 206,
                      line_width: 12,
                      corner_flag: 0,
                      color: 0xFFA6A6A6,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_cs_normal_step = progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_step * 100);
                  if (normal_step_circle_scale) {
                    normal_step_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 240,
                      center_y: 240,
                      start_angle: 257,
                      end_angle: 193,
                      radius: 206,
                      line_width: 12,
                      corner_flag: 0,
                      color: 0xFFA6A6A6,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_cs_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_battery * 100);
                  if (normal_battery_circle_scale) {
                    normal_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 240,
                      center_y: 240,
                      start_angle: -13,
                      end_angle: -77,
                      radius: 206,
                      line_width: 12,
                      corner_flag: 0,
                      color: 0xFFA6A6A6,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                text_update();
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerTextUpdate) {
                    normal_timerTextUpdate = timer.createTimer(0, 1000, (function (option) {
                      text_update();
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerTextUpdate) {
                  timer.stopTimer(normal_timerTextUpdate);
                  normal_timerTextUpdate = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
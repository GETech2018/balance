const WEEKDAYS = ['DOM', 'SEG', 'TER', 'QUA', 'QUI', 'SEX', 'SÁB'];
const hours = Array.from({length: 10}, (_, digit) => 'hour-' + digit + '.png');
const minutes = Array.from({length: 10}, (_, digit) => 'minute-' + digit + '.png');
const metricDigits = Array.from({length: 10}, (_, digit) => 'metric-' + digit + '.png');
const altitudeDigits = Array.from({length: 10}, (_, digit) => 'alt-' + digit + '.png');

function create(kind, properties) {
  const normal = hmUI.show_level && (hmUI.show_level.ONLY_NORMAL || hmUI.show_level.ONAL_NORML);
  if (normal) properties.show_level = normal;
  return hmUI.createWidget(hmUI.widget[kind], properties);
}

function attempt(label, callback) {
  try {
    return callback();
  } catch (error) {
    console.log('Neon Balance ' + label + ': ' + error);
    return null;
  }
}

function text(x, y, w, h, size, color) {
  return create('TEXT', {
    x, y, w, h, color, text_size: size, text: '',
    align_h: hmUI.align.CENTER_H, align_v: hmUI.align.CENTER_V
  });
}

function nativeMetric(name, x, y, w, options = {}) {
  const type = hmUI.data_type && hmUI.data_type[name];
  if (typeof type !== 'number') {
    const missing = text(x, y, w, 24, 20, 0xe6ebf1);
    missing.setProperty(hmUI.prop.TEXT, '—');
    return;
  }
  create('TEXT_IMG', {
    x, y, w, h: 24, type, font_array: metricDigits,
    align_h: hmUI.align.CENTER_H, h_space: 0, ...options
  });
}

function manualMetric(x, y, w, unit, dot) {
  return create('TEXT_IMG', {
    x, y, w, h: 24, text: '0', font_array: metricDigits,
    align_h: hmUI.align.CENTER_H, h_space: 0, dot_image: dot,
    unit_en: unit, unit_sc: unit, unit_tc: unit,
    imperial_unit_en: unit, imperial_unit_sc: unit, imperial_unit_tc: unit,
    negative_image: 'metric-missing.png'
  });
}

function sensor(name) {
  try {
    return hmSensor.createSensor(hmSensor.id[name]);
  } catch (error) {
    console.log('Sensor unavailable: ' + name);
    return null;
  }
}

function sample(source, field) {
  try {
    const value = source && source[field];
    return Number.isFinite(value) && value >= 0 ? value : null;
  } catch (error) {
    return null;
  }
}

function update(widget, property, value) {
  widget.setProperty(property, value);
}

function stepsLabel(count) {
  if (count === null) return '-';
  if (count < 1000) return String(count);
  return (Math.floor(count / 100) / 10).toFixed(1);
}

function twoDigits(value) {
  return value < 10 ? '0' + value : String(value);
}

WatchFace({
  build() {
    create('IMG', { x: 0, y: 0, w: 480, h: 480, src: 'layout.png' });
    const chargeArc = create('IMG', { x: 76, y: 5, src: 'charge-0.png' });
    const nativeTime = attempt('IMG_TIME', () => create('IMG_TIME', {
      hour_zero: 1, hour_startX: 49, hour_startY: 162, hour_array: hours,
      hour_align: hmUI.align.LEFT, hour_space: 1,
      minute_zero: 1, minute_startX: 273, minute_startY: 162, minute_array: minutes,
      minute_align: hmUI.align.LEFT, minute_space: 1
    }));
    const fallbackTime = nativeTime ? null : text(51, 163, 347, 100, 76, 0x04e8ef);

    const chargeText = manualMetric(231, 31, 67, 'percent.png');
    const paiText = manualMetric(129, 104, 48);
    let stepText;
    let stepUsesThousands;
    const weekdayText = text(281, 247, 51, 30, 19, 0xffffff);
    const dateText = text(337, 247, 101, 30, 19, 0x00e9ef);

    const paiBars = create('IMG', { x: 105, y: 106, src: 'pai-0.png' });

    attempt('VO2MAX', () => nativeMetric('VO2MAX', 232, 104, 43));
    attempt('ALTITUDE', () => nativeMetric('ALTITUDE', 222, 307, 83, {
      h: 19, font_array: altitudeDigits, negative_image: 'minus.png',
      unit_en: 'm.png', unit_sc: 'm.png', unit_tc: 'm.png',
      imperial_unit_en: 'ft.png', imperial_unit_sc: 'ft.png', imperial_unit_tc: 'ft.png'
    }));
    attempt('TRAINING_LOAD', () => nativeMetric('TRAINING_LOAD', 326, 104, 65));
    attempt('WEATHER_CURRENT', () => nativeMetric('WEATHER_CURRENT', 89, 307, 78, {
      h: 19, font_array: altitudeDigits, negative_image: 'minus.png',
      unit_en: 'celsius.png', unit_sc: 'celsius.png', unit_tc: 'celsius.png',
      imperial_unit_en: 'fahrenheit.png', imperial_unit_sc: 'fahrenheit.png', imperial_unit_tc: 'fahrenheit.png'
    }));
    attempt('UVI', () => nativeMetric('UVI', 387, 307, 31, {
      h: 19, font_array: altitudeDigits
    }));
    attempt('CAL', () => nativeMetric('CAL', 118, 386, 67));
    attempt('HEART', () => nativeMetric('HEART', 340, 386, 56));

    const battery = sensor('BATTERY');
    const pai = sensor('PAI');
    const step = sensor('STEP');
    const clock = sensor('TIME');
    let lastCharge;
    let lastPai;
    let lastSteps;
    let lastDate;

    const refresh = () => {
      const charge = sample(battery, 'current');
      if (charge !== lastCharge) {
        lastCharge = charge;
        const percent = charge === null ? 0 : Math.min(100, Math.floor(charge));
        update(chargeArc, hmUI.prop.SRC, 'charge-' + percent + '.png');
        update(chargeText, hmUI.prop.TEXT, charge === null ? '-' : String(percent));
      }

      const score = sample(pai, 'totalpai');
      if (score !== lastPai) {
        lastPai = score;
        update(paiText, hmUI.prop.TEXT, score === null ? '-' : String(score));
        const level = score === null ? 0 : score < 50 ? 1 : score < 100 ? 2 : 3;
        update(paiBars, hmUI.prop.SRC, 'pai-' + level + '.png');
      }

      const stepCount = sample(step, 'current');
      const inThousands = stepCount !== null && stepCount >= 1000;
      const formatted = stepsLabel(stepCount);
      if (formatted !== lastSteps || inThousands !== stepUsesThousands) {
        if (!stepText || inThousands !== stepUsesThousands) {
          // This firmware appends a configured unit even without a unit tag.
          const replacement = manualMetric(212, 386, 81,
            inThousands ? 'kilo.png' : undefined, 'step-dot.png');
          if (stepText) hmUI.deleteWidget(stepText);
          stepText = replacement;
          stepUsesThousands = inThousands;
        }
        update(stepText, hmUI.prop.TEXT, formatted);
        lastSteps = formatted;
      }

      const now = new Date();
      if (fallbackTime) {
        const hour = sample(clock, 'hour');
        const minute = sample(clock, 'minute');
        update(fallbackTime, hmUI.prop.TEXT,
          twoDigits(hour === null ? now.getHours() : hour) + ':' +
          twoDigits(minute === null ? now.getMinutes() : minute));
      }
      const year = sample(clock, 'year') || now.getFullYear();
      const month = sample(clock, 'month') || now.getMonth() + 1;
      const day = sample(clock, 'day') || now.getDate();
      const date = twoDigits(day) + '/' + twoDigits(month) + '/' + twoDigits(year % 100);
      const weekday = new Date(Date.UTC(year, month - 1, day)).getUTCDay();
      if (date !== lastDate) {
        lastDate = date;
        update(weekdayText, hmUI.prop.TEXT, WEEKDAYS[weekday]);
        update(dateText, hmUI.prop.TEXT, date);
      }
    };

    const resume = () => {
      attempt('initial refresh', refresh);
      if (this.refreshTimer == null) this.refreshTimer = attempt('timer', () => timer.createTimer(2000, 2000, () => attempt('refresh', refresh), {}));
    };
    attempt('lifecycle', () => create('WIDGET_DELEGATE', {
      resume_call: resume, pause_call: () => this.stopRefresh()
    }));
    resume();
  },

  stopRefresh() {
    if (this.refreshTimer != null) {
      timer.stopTimer(this.refreshTimer);
      this.refreshTimer = null;
    }
  },

  onDestroy() {
    this.stopRefresh();
  }
});














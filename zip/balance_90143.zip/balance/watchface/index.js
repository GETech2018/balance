import * as hmUI from '@zos/ui'

const DIGITS = ['SKN000.png','SKN001.png','SKN002.png','SKN003.png','SKN004.png',
                'SKN005.png','SKN006.png','SKN007.png','SKN008.png','SKN009.png']
const WEEK = ['OskW11.png','OskW12.png','OskW13.png','OskW14.png','OskW15.png','OskW16.png','OskW17.png']

const NORMAL = hmUI.show_level.ONLY_NORMAL
const AOD = hmUI.show_level.ONAL_AOD
const BOTH = NORMAL | AOD

WatchFace({
  build() {
    // ---------- Fondo ----------
    hmUI.createWidget(hmUI.widget.IMG, {
      x: 0, y: 0, w: 480, h: 480,
      src: 'Skywalker-X-33.png',
      show_level: NORMAL
    })
    hmUI.createWidget(hmUI.widget.IMG, {
      x: 0, y: 0, w: 480, h: 480,
      src: 'Skywalker-X-33-AOD.png',
      show_level: AOD
    })

    // ---------- Fecha (normal y AOD) ----------
    hmUI.createWidget(hmUI.widget.IMG_WEEK, {
      x: 79, y: 211,
      week_en: WEEK, week_tc: WEEK, week_sc: WEEK,
      show_level: BOTH
    })

    hmUI.createWidget(hmUI.widget.IMG_DATE, {
      year_startX: 289, year_startY: 95,
      year_sc_array: DIGITS, year_tc_array: DIGITS, year_en_array: DIGITS,
      year_zero: 0, year_space: -22,
      year_align: hmUI.align.LEFT,
      year_is_character: false,
      show_level: BOTH
    })

    hmUI.createWidget(hmUI.widget.IMG_DATE, {
      month_startX: 180, month_startY: 95,
      month_sc_array: DIGITS, month_tc_array: DIGITS, month_en_array: DIGITS,
      month_zero: 0, month_space: -22,
      month_unit_sc: 'SKi002.png', month_unit_tc: 'SKi002.png', month_unit_en: 'SKi002.png',
      month_align: hmUI.align.LEFT,
      month_is_character: false,
      show_level: BOTH
    })

    hmUI.createWidget(hmUI.widget.IMG_DATE, {
      day_startX: 103, day_startY: 95,
      day_sc_array: DIGITS, day_tc_array: DIGITS, day_en_array: DIGITS,
      day_zero: 1, day_space: -22,
      day_unit_sc: 'SKi002.png', day_unit_tc: 'SKi002.png', day_unit_en: 'SKi002.png',
      day_align: hmUI.align.LEFT,
      day_is_character: false,
      show_level: BOTH
    })

    // ---------- Distancia: "KM" + valor (normal y AOD) ----------
    hmUI.createWidget(hmUI.widget.IMG, {
      x: 84, y: 330,
      src: 'SKi010.png',
      show_level: BOTH
    })
    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
      x: 230, y: 330, w: 170, h: 60,
      type: hmUI.data_type.DISTANCE,
      font_array: DIGITS,
      dot_image: 'SKdot.png',
      h_space: -22,
      align_h: hmUI.align.LEFT,
      show_level: BOTH
    })

    // ---------- Agujas ----------
    hmUI.createWidget(hmUI.widget.TIME_POINTER, {
      hour_path: 'SKY001.png', hour_centerX: 240, hour_centerY: 240, hour_posX: 37, hour_posY: 129,
      show_level: NORMAL
    })
    hmUI.createWidget(hmUI.widget.TIME_POINTER, {
      minute_path: 'SKY002.png', minute_centerX: 240, minute_centerY: 240, minute_posX: 61, minute_posY: 196,
      show_level: NORMAL
    })
    hmUI.createWidget(hmUI.widget.TIME_POINTER, {
      second_path: 'SKY003.png', second_centerX: 240, second_centerY: 240, second_posX: 15, second_posY: 197,
      show_level: NORMAL
    })

    // Agujas AOD (variantes -AOD del autor, sin segundero)
    hmUI.createWidget(hmUI.widget.TIME_POINTER, {
      hour_path: 'SKY001-AOD.png', hour_centerX: 240, hour_centerY: 240, hour_posX: 37, hour_posY: 129,
      show_level: AOD
    })
    hmUI.createWidget(hmUI.widget.TIME_POINTER, {
      minute_path: 'SKY002-AOD.png', minute_centerX: 240, minute_centerY: 240, minute_posX: 61, minute_posY: 196,
      show_level: AOD
    })
  }
})

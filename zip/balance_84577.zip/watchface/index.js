﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_battery_circle_scale = ''
        let normal_heart_rate_text_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_step_current_text_img = ''
        let normal_system_lock_img = ''
        let normal_system_dnd_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_step_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_battery_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_altitude_jumpable_img_click = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 507,
              h: 507,
              src: 'A100_003.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 240,
              // center_y: 240,
              // start_angle: 0,
              // end_angle: 300,
              // radius: 240,
              // line_width: 7,
              // line_cap: Rounded,
              // color: 0xFFE8FFE9,
              // mirror: False,
              // inversion: False,
              // alpha: 220,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            let screenType = hmSetting.getScreenType();
            normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 240,
              center_y: 240,
              start_angle: 0,
              end_angle: 300,
              radius: 237,
              line_width: 7,
              corner_flag: 0,
              color: 0xFFE8FFE9,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_circle_scale.setAlpha(220);
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 202,
              y: 402,
              font_array: ["A100_010.png","A100_011.png","A100_012.png","A100_013.png","A100_014.png","A100_015.png","A100_016.png","A100_017.png","A100_018.png","A100_019.png"],
              padding: false,
              h_space: 0,
              invalid_image: 't0017.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 221,
              y: 356,
              font_array: ["t0017.png","t0018.png","t0019.png","t0020.png","t0021.png","t0022.png","t0023.png","t0024.png","t0025.png","t0026.png"],
              padding: false,
              h_space: 0,
              unit_sc: 't0050.png',
              unit_tc: 't0050.png',
              unit_en: 't0050.png',
              negative_image: 't0048.png',
              invalid_image: 't0048.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 406,
              day_startY: 214,
              day_sc_array: ["A100_010.png","A100_011.png","A100_012.png","A100_013.png","A100_014.png","A100_015.png","A100_016.png","A100_017.png","A100_018.png","A100_019.png"],
              day_tc_array: ["A100_010.png","A100_011.png","A100_012.png","A100_013.png","A100_014.png","A100_015.png","A100_016.png","A100_017.png","A100_018.png","A100_019.png"],
              day_en_array: ["A100_010.png","A100_011.png","A100_012.png","A100_013.png","A100_014.png","A100_015.png","A100_016.png","A100_017.png","A100_018.png","A100_019.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 296,
              y: 215,
              week_en: ["A100_020.png","A100_021.png","A100_022.png","A100_023.png","A100_024.png","A100_025.png","A100_026.png"],
              week_tc: ["A100_020.png","A100_021.png","A100_022.png","A100_023.png","A100_024.png","A100_025.png","A100_026.png"],
              week_sc: ["A100_020.png","A100_021.png","A100_022.png","A100_023.png","A100_024.png","A100_025.png","A100_026.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 21,
              y: 214,
              font_array: ["A100_010.png","A100_011.png","A100_012.png","A100_013.png","A100_014.png","A100_015.png","A100_016.png","A100_017.png","A100_018.png","A100_019.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 20,
              y: 184,
              src: '026.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 18,
              y: 269,
              src: 'DND.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 427,
              y: 175,
              src: '00901.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 430,
              y: 270,
              src: '00904.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'A100_027.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 31,
              hour_posY: 241,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'A100_028.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 30,
              minute_posY: 240,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'A100_029.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 17,
              second_posY: 240,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 60,
              y: 190,
              w: 100,
              h: 100,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 190,
              y: 390,
              w: 100,
              h: 80,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 300,
              y: 190,
              w: 100,
              h: 100,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 190,
              y: 100,
              w: 100,
              h: 100,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 190,
              y: 290,
              w: 100,
              h: 100,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 0,
              y: 190,
              w: 60,
              h: 100,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 400,
              y: 190,
              w: 80,
              h: 100,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altitude_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 190,
              y: 0,
              w: 100,
              h: 100,
              type: hmUI.data_type.ALTITUDE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            function scale_call() {
              console.log('scale_call()');

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_cs_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_battery * 100);
                  if (normal_battery_circle_scale) {
                    normal_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 240,
                      center_y: 240,
                      start_angle: 0,
                      end_angle: 300,
                      radius: 237,
                      line_width: 7,
                      corner_flag: 0,
                      color: 0xFFE8FFE9,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
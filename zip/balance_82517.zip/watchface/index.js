﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js


let cc=0
 // Start change element
        let elementnumber_1 = 1
        let total_elemente = 4

        function click_elemente() {
            if(elementnumber_1==total_elemente) {
            elementnumber_1=1;
                UpdateElementeOne();
                }
            else {
                elementnumber_1=elementnumber_1+1;
                if(elementnumber_1==2) {
                  UpdateElementeTwo();
                }
                if(elementnumber_1==3) {
                  UpdateElementeThree();
                }
                if(elementnumber_1==4) {
                  UpdateElementeFour();
                }

            }
            if(elementnumber_1==1) hmUI.showToast({text: 'Weather'});
            if(elementnumber_1==2) hmUI.showToast({text: 'Heart Rate'});
            if(elementnumber_1==3) hmUI.showToast({text: 'Distance & Calories'});
            if(elementnumber_1==4) hmUI.showToast({text: 'Day Month Week'});
        }

        //Weather
        function UpdateElementeOne(){
        normal_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_city_name_text.setProperty(hmUI.prop.VISIBLE, true);
        normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);
        normal_temperature_low_text_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_temperature_high_text_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_temperature_high_separator_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_group_ForecastWeather.setProperty(hmUI.prop.VISIBLE, true);
        //normal_canvas1.setProperty(hmUI.prop.VISIBLE, true);
        //normal_canvas2.setProperty(hmUI.prop.VISIBLE, true);
 
        normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_heart_rate_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
        normal_frame_animation_1.setProperty(hmUI.prop.VISIBLE, false);

        normal_compass_icon_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_compass_direction_pointer_img.setProperty(hmUI.prop.VISIBLE, false);

        normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
     normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_calorie_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);

        normal_date_img_date_month_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_date_img_date_day.setProperty(hmUI.prop.VISIBLE, false);
        normal_date_img_date_week_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_moon_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);

        normal_heart_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
       normal_pai_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
      normal_sunrise_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_temperature_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
        normal_spo2_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);


        Button_2.setProperty(hmUI.prop.VISIBLE, false); // calendar


        }

        //Heart rate
        function UpdateElementeTwo(){

        normal_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_city_name_text.setProperty(hmUI.prop.VISIBLE, false);
        normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
        normal_temperature_low_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_temperature_high_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_temperature_high_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_group_ForecastWeather.setProperty(hmUI.prop.VISIBLE, false);
        //normal_canvas1.setProperty(hmUI.prop.VISIBLE, false);
        //normal_canvas2.setProperty(hmUI.prop.VISIBLE, false);
 
        normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_heart_rate_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);
        normal_frame_animation_1.setProperty(hmUI.prop.VISIBLE, true);

        normal_compass_icon_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_compass_direction_pointer_img.setProperty(hmUI.prop.VISIBLE, false);

        normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_calorie_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);

        normal_date_img_date_month_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_date_img_date_day.setProperty(hmUI.prop.VISIBLE, false);
        normal_date_img_date_week_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_moon_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);


        normal_heart_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
       normal_pai_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
      normal_sunrise_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_temperature_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_spo2_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
        Button_2.setProperty(hmUI.prop.VISIBLE, false); // calendar
        }

      //Dis & Cal
        function UpdateElementeThree(){

        normal_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_city_name_text.setProperty(hmUI.prop.VISIBLE, false);
        normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
        normal_temperature_low_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_temperature_high_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_temperature_high_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_group_ForecastWeather.setProperty(hmUI.prop.VISIBLE, false);
        //normal_canvas1.setProperty(hmUI.prop.VISIBLE, false);
        //normal_canvas2.setProperty(hmUI.prop.VISIBLE, false);
 
        normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_heart_rate_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
        normal_frame_animation_1.setProperty(hmUI.prop.VISIBLE, false);

        normal_compass_icon_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_compass_direction_pointer_img.setProperty(hmUI.prop.VISIBLE, true);

        normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
     normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_calorie_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);

        normal_date_img_date_month_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_date_img_date_day.setProperty(hmUI.prop.VISIBLE, false);
        normal_date_img_date_week_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_moon_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);


        normal_heart_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
       normal_pai_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
      normal_sunrise_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_temperature_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_spo2_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        Button_2.setProperty(hmUI.prop.VISIBLE, false); // calendar

        }

      //Day Month Week
        function UpdateElementeFour(){

        normal_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_city_name_text.setProperty(hmUI.prop.VISIBLE, false);
        normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
        normal_temperature_low_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_temperature_high_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_temperature_high_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_group_ForecastWeather.setProperty(hmUI.prop.VISIBLE, false);
        //normal_canvas1.setProperty(hmUI.prop.VISIBLE, false);
        //normal_canvas2.setProperty(hmUI.prop.VISIBLE, false);
 
        normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_heart_rate_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
        normal_frame_animation_1.setProperty(hmUI.prop.VISIBLE, false);

        normal_compass_icon_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_compass_direction_pointer_img.setProperty(hmUI.prop.VISIBLE, true);

        normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
     normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_calorie_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);

        normal_date_img_date_month_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_date_img_date_day.setProperty(hmUI.prop.VISIBLE, true);
        normal_date_img_date_week_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_moon_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);

        normal_heart_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
       normal_pai_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
      normal_sunrise_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
        normal_temperature_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_spo2_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        Button_2.setProperty(hmUI.prop.VISIBLE, true); // calendar
        }
        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_temperature_icon_img = ''
        let normal_city_name_text = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_low_text_img = ''
        let normal_temperature_high_text_img = ''
        let normal_temperature_high_separator_img = ''
        let normal_temperature_current_text_img = ''
        let normal_group_ForecastWeather = ''
        let normal_canvas1 = '';
        let normal_canvas2 = '';
        let normal_forecast_average_text_font = new Array(4);
        let normal_forecast_date_week_font = new Array(4);
        let normal_forecast_date_week_font_Array = ['Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa', 'Su'];
        let normal_forecast_image_progress_img_level = new Array(4);
        let normal_forecast_image_array = ['W_icon_small_01.png', 'W_icon_small_02.png', 'W_icon_small_03.png', 'W_icon_small_04.png', 'W_icon_small_05.png', 'W_icon_small_06.png', 'W_icon_small_07.png', 'W_icon_small_08.png', 'W_icon_small_09.png', 'W_icon_small_10.png', 'W_icon_small_11.png', 'W_icon_small_12.png', 'W_icon_small_13.png', 'W_icon_small_14.png', 'W_icon_small_15.png', 'W_icon_small_16.png', 'W_icon_small_17.png', 'W_icon_small_18.png', 'W_icon_small_19.png', 'W_icon_small_20.png', 'W_icon_small_21.png', 'W_icon_small_22.png', 'W_icon_small_23.png', 'W_icon_small_24.png', 'W_icon_small_25.png', 'W_icon_small_26.png', 'W_icon_small_27.png', 'W_icon_small_28.png', 'W_icon_small_29.png'];
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_text_separator_img = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_frame_animation_1 = ''
        let normal_frame_animation_2 = ''
        let normal_distance_text_text_img = ''
        let normal_distance_text_separator_img = ''
        let normal_calorie_current_text_img = ''
        let normal_calorie_current_separator_img = ''
        let normal_calorie_image_progress_img_level = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_compass_icon_img = ''
        let normal_compass_direction_pointer_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_step_current_text_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time_second = ''
        let normal_digital_clock_img_time_minute = ''
        let normal_digital_clock_img_time_hour = ''
        let idle_digital_clock_img_time_second = ''
        let idle_digital_clock_img_time_minute = ''
        let idle_digital_clock_minute_separator_img = ''
        let idle_digital_clock_img_time_hour = ''
        let idle_digital_clock_hour_separator_img = ''
        let idle_digital_clock_img_time_AmPm = ''
        let normal_step_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let timeSensor = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'main1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 59,
              y: 87,
              src: 'BG_WEATHER.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 339,
              y: 200,
              w: 138,
              h: 34,
              text_size: 23,
              char_space: 0,
              line_space: 0,
              color: 0xFF8C8F82,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.NONE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 253,
              y: 107,
              image_array: ["Weather_icon_01.png","Weather_icon_02.png","Weather_icon_03.png","Weather_icon_04.png","Weather_icon_05.png","Weather_icon_06.png","Weather_icon_07.png","Weather_icon_08.png","Weather_icon_09.png","Weather_icon_10.png","Weather_icon_11.png","Weather_icon_12.png","Weather_icon_13.png","Weather_icon_14.png","Weather_icon_15.png","Weather_icon_16.png","Weather_icon_17.png","Weather_icon_18.png","Weather_icon_19.png","Weather_icon_20.png","Weather_icon_21.png","Weather_icon_22.png","Weather_icon_23.png","Weather_icon_24.png","Weather_icon_25.png","Weather_icon_26.png","Weather_icon_27.png","Weather_icon_28.png","Weather_icon_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 314,
              y: 164,
              font_array: ["Act_small_0.png","Act_small_1.png","Act_small_2.png","Act_small_3.png","Act_small_4.png","Act_small_5.png","Act_small_6.png","Act_small_7.png","Act_small_8.png","Act_small_9.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'TempSmallSymbol1.png',
              unit_tc: 'TempSmallSymbol1.png',
              unit_en: 'TempSmallSymbol1.png',
              imperial_unit_sc: 'TempSmallSymbol1.png',
              imperial_unit_tc: 'TempSmallSymbol1.png',
              imperial_unit_en: 'TempSmallSymbol1.png',
              negative_image: 'TempSmallSymbol2.png',
              invalid_image: 'TempSmallSymbol2.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const temperatureUnit = hmSetting.getTemperatureUnit();
            //start of ignored block
            if (temperatureUnit == 1) {
              normal_temperature_low_text_img.setProperty(hmUI.prop.MORE, {
                x: 314,
                y: 164,
                font_array: ["Act_small_0.png","Act_small_1.png","Act_small_2.png","Act_small_3.png","Act_small_4.png","Act_small_5.png","Act_small_6.png","Act_small_7.png","Act_small_8.png","Act_small_9.png"],
                padding: false,
                h_space: 1,
                unit_sc: 'TempSmallSymbol1.png',
                unit_tc: 'TempSmallSymbol1.png',
                unit_en: 'TempSmallSymbol1.png',
                imperial_unit_sc: 'TempSmallSymbol1.png',
                imperial_unit_tc: 'TempSmallSymbol1.png',
                imperial_unit_en: 'TempSmallSymbol1.png',
                negative_image: 'TempSmallSymbol2.png',
                invalid_image: 'TempSmallSymbol2.png',
                align_h: hmUI.align.RIGHT,
                type: hmUI.data_type.WEATHER_LOW,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
            };
            //end of ignored block

            normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 314,
              y: 121,
              font_array: ["Act_small_0.png","Act_small_1.png","Act_small_2.png","Act_small_3.png","Act_small_4.png","Act_small_5.png","Act_small_6.png","Act_small_7.png","Act_small_8.png","Act_small_9.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'TempSmallSymbol1.png',
              unit_tc: 'TempSmallSymbol1.png',
              unit_en: 'TempSmallSymbol1.png',
              imperial_unit_sc: 'TempSmallSymbol1.png',
              imperial_unit_tc: 'TempSmallSymbol1.png',
              imperial_unit_en: 'TempSmallSymbol1.png',
              negative_image: 'TempSmallSymbol2.png',
              invalid_image: 'TempSmallSymbol2.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 402,
              y: 129,
              src: 'max_min.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            //start of ignored block
            if (temperatureUnit == 1) {
              normal_temperature_high_text_img.setProperty(hmUI.prop.MORE, {
                x: 314,
                y: 121,
                font_array: ["Act_small_0.png","Act_small_1.png","Act_small_2.png","Act_small_3.png","Act_small_4.png","Act_small_5.png","Act_small_6.png","Act_small_7.png","Act_small_8.png","Act_small_9.png"],
                padding: false,
                h_space: 1,
                unit_sc: 'TempSmallSymbol1.png',
                unit_tc: 'TempSmallSymbol1.png',
                unit_en: 'TempSmallSymbol1.png',
                imperial_unit_sc: 'TempSmallSymbol1.png',
                imperial_unit_tc: 'TempSmallSymbol1.png',
                imperial_unit_en: 'TempSmallSymbol1.png',
                negative_image: 'TempSmallSymbol2.png',
                invalid_image: 'TempSmallSymbol2.png',
                align_h: hmUI.align.RIGHT,
                type: hmUI.data_type.WEATHER_HIGH,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
            };
            //end of ignored block

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 224,
              y: 186,
              font_array: ["Ac_mid_0.png","Ac_mid_1.png","Ac_mid_2.png","Ac_mid_3.png","Ac_mid_4.png","Ac_mid_5.png","Ac_mid_6.png","Ac_mid_7.png","Ac_mid_8.png","Ac_mid_9.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'TempSymbol1.png',
              unit_tc: 'TempSymbol1.png',
              unit_en: 'TempSymbol1.png',
              imperial_unit_sc: 'TempSymbol1.png',
              imperial_unit_tc: 'TempSymbol1.png',
              imperial_unit_en: 'TempSymbol1.png',
              negative_image: 'TempSymbol2.png',
              invalid_image: 'TempSymbol2.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            //start of ignored block
            if (temperatureUnit == 1) {
              normal_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
                x: 224,
                y: 186,
                font_array: ["Ac_mid_0.png","Ac_mid_1.png","Ac_mid_2.png","Ac_mid_3.png","Ac_mid_4.png","Ac_mid_5.png","Ac_mid_6.png","Ac_mid_7.png","Ac_mid_8.png","Ac_mid_9.png"],
                padding: false,
                h_space: 1,
                unit_sc: 'TempSymbol1.png',
                unit_tc: 'TempSymbol1.png',
                unit_en: 'TempSymbol1.png',
                imperial_unit_sc: 'TempSymbol1.png',
                imperial_unit_tc: 'TempSymbol1.png',
                imperial_unit_en: 'TempSymbol1.png',
                negative_image: 'TempSymbol2.png',
                invalid_image: 'TempSymbol2.png',
                align_h: hmUI.align.CENTER_H,
                type: hmUI.data_type.WEATHER_CURRENT,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
            };
            //end of ignored block

            let screenType = hmSetting.getScreenType();            
            // normal_Weather_FewDays = hmUI.createWidget(hmUI.widget.FewDays, {
              // x: 0,
              // y: 0,
              // ColumnWidth: 31,
              // DaysCount: 4,
            // });
            
            normal_group_ForecastWeather = hmUI.createWidget(hmUI.widget.GROUP, {
              x: 0,
              y: 0,
              h: 0,
              w: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            //start of ignored block
            function drawLine(canvas1, canvas2, x1, y1, x2, y2, color, line_width) {
              if (x1 > x2) {
                let temp_x = x1;
                let temp_y = y1;
                x1 = x2;
                y1 = y2;
                x2 = temp_x;
                y2 = temp_y;
              };
              
              if (x1 < 215) {
                canvas1.setPaint({ color: color, line_width: line_width });
                canvas1.drawLine({ x1: x1, y1: y1, x2: x2, y2: y2 });
              };
              if (x2 >= 215) {
                canvas2.setPaint({ color: color, line_width: line_width });
                canvas2.drawLine({ x1: x1-215, y1: y1, x2: x2-215, y2: y2 });
              }
            };
            
            function drawRect(canvas1, canvas2, x1, y1, x2, y2, color) {
              if (x1 > x2) {
                let temp_x = x1;
                let temp_y = y1;
                x1 = x2;
                y1 = y2;
                x2 = temp_x;
                y2 = temp_y;
              };
              
              if (x1 < 215) {
                canvas1.drawRect({ x1: x1, y1: y1, x2: x2, y2: y2, color: color });
              };
              if (x2 >= 215) {
                canvas2.drawRect({ x1: x1-215, y1: y1, x2: x2-215, y2: y2, color: color });
              }
            };
            
            function drawCircle(canvas1, canvas2, center_x, center_y, color, radius) {
              if (center_x < 215+radius) {
                canvas1.drawCircle({ center_x: center_x, center_y: center_y, radius: radius, color: color });
              };
              if (center_x >= 215-radius) {
                canvas2.drawCircle({ center_x: center_x-215, center_y: center_y, radius: radius, color: color });
              }
            };
            
            function drawGraphPoint(canvas1, canvas2, x, y, color, pointSize, pointType) {
              switch (pointType) {
                case 1:
                  x -= pointSize/2;
                  y -= pointSize/2;
                  drawRect(canvas1, canvas2, x, y, x+pointSize, y+pointSize, color);
                  break;
                case 2:
                  let posX = x - pointSize/2;
                  let posY = y - pointSize/2;
                  drawRect(canvas1, canvas2, posX, posY, posX+pointSize, posY+pointSize, color );
                  posX = x - pointSize/4;
                  posY = y - pointSize/4;
                  drawRect(canvas1, canvas2, posX, posY, posX+pointSize/2, posY+pointSize/2, 0xffffff );
                  break;
                case 3:
                  drawCircle(canvas1, canvas2, x, y, color, pointSize/2 );
                  break;
                case 4:
                  drawCircle(canvas1, canvas2, x, y, color, pointSize/2 );
                  drawCircle(canvas1, canvas2, x, y, 0xffffff, pointSize/4 );
                  break;
              }
            };

            //end of ignored block
            

            //start of ignored block
            function graphScale(heightGraph, maxPointSize, minPointSize, forecastData, daysCount) {
              console.log(`function graphScale`);
              heightGraph -= (maxPointSize + minPointSize) / 2;
              let high = -300;
              let low = 300;
              for (let index = 0; index < daysCount; index++) {
                if (index < forecastData.length) {
                  let item = forecastData[index];
                  if (item.high > high) high = item.high;;
                  if (item.low < low) low = item.low; ;
                } // end if
              } // end for
              let delta = high - low;
              let scale = heightGraph / delta;
              console.log(`heightGraph: ${heightGraph}; high: ${high}; low : ${low}`);
              return {graphScale: scale, maximal_temp: high};
            };

            //end of ignored block

            //start of ignored block
            if (screenType == hmSetting.screen_type.WATCHFACE) {
              normal_canvas1 = normal_group_ForecastWeather.createWidget(hmUI.widget.CANVAS, {
                x: -5,
                y: 108,
                w: 215,
                h: 215,
              });

              normal_canvas2 = normal_group_ForecastWeather.createWidget(hmUI.widget.CANVAS, {
                x: 210,
                y: 108,
                w: 215,
                h: 215,
              });
            };
            //end of ignored block

            // normal_forecast_average_text_font = normal_group_ForecastWeather.createWidget(hmUI.widget.TEXT_Options, {
              // x: 84,
              // y: 142,
              // w: 119,
              // h: 21,
              // text_size: 14,
              // char_space: 0,
              // line_space: 0,
              // color: 0xFFFFFFFF,
              // color_2: 0xFFFF0000,
              // use_color_2: False,
              // align_h: hmUI.align.LEFT,
              // align_v: hmUI.align.TOP,
              // text_style: hmUI.text_style.ELLIPSIS,
              // type: hmUI.data_type.forecast_average_text_font,
              // unit_type: 1,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            //start of ignored block
            if (screenType == hmSetting.screen_type.WATCHFACE) {
              for (let i = 0; i < 4; i++) {
                normal_forecast_average_text_font[i] = normal_group_ForecastWeather.createWidget(hmUI.widget.TEXT, {
                  x: 84 + i*31,
                  y: 142,
                  w: 119,
                  h: 21,
                  text_size: 14,
                  char_space: 0,
                  line_space: 0,
                  color: 0xFFFFFFFF,
                  align_h: hmUI.align.LEFT,
                  align_v: hmUI.align.TOP,
                  text_style: hmUI.text_style.ELLIPSIS,
                  // unit_type: 1,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
              };
            };
            //end of ignored block

            // normal_forecast_date_week_font = normal_group_ForecastWeather.createWidget(hmUI.widget.TEXT_Options, {
              // x: 81,
              // y: 194,
              // w: 150,
              // h: 30,
              // text_size: 16,
              // char_space: 0,
              // line_space: 0,
              // color: 0xFFFFFFFF,
              // color_2: 0xFFFF0000,
              // use_color_2: False,
              // align_h: hmUI.align.LEFT,
              // align_v: hmUI.align.TOP,
              // text_style: hmUI.text_style.ELLIPSIS,
              // type: hmUI.data_type.forecast_date_week_img,
              // unit_string: Mo, Tu, We, Th, Fr, Sa, Su,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            //start of ignored block
            if (screenType == hmSetting.screen_type.WATCHFACE) {
              for (let i = 0; i < 4; i++) {
                normal_forecast_date_week_font[i] = normal_group_ForecastWeather.createWidget(hmUI.widget.TEXT, {
                  x: 81 + i*31,
                  y: 194,
                  w: 150,
                  h: 30,
                  text_size: 16,
                  char_space: 0,
                  line_space: 0,
                  color: 0xFFFFFFFF,
                  // color_2: 0xFFFF0000,
                  align_h: hmUI.align.LEFT,
                  align_v: hmUI.align.TOP,
                  text_style: hmUI.text_style.ELLIPSIS,
                  // unit_string: Mo, Tu, We, Th, Fr, Sa, Su,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
              };
            };
            //end of ignored block

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            // normal_forecast_image_progress_img_level = normal_group_ForecastWeather.createWidget(hmUI.widget.IMG_LEVEL_Options, {
              // x: 78,
              // y: 167,
              // image_array: ["W_icon_small_01.png","W_icon_small_02.png","W_icon_small_03.png","W_icon_small_04.png","W_icon_small_05.png","W_icon_small_06.png","W_icon_small_07.png","W_icon_small_08.png","W_icon_small_09.png","W_icon_small_10.png","W_icon_small_11.png","W_icon_small_12.png","W_icon_small_13.png","W_icon_small_14.png","W_icon_small_15.png","W_icon_small_16.png","W_icon_small_17.png","W_icon_small_18.png","W_icon_small_19.png","W_icon_small_20.png","W_icon_small_21.png","W_icon_small_22.png","W_icon_small_23.png","W_icon_small_24.png","W_icon_small_25.png","W_icon_small_26.png","W_icon_small_27.png","W_icon_small_28.png","W_icon_small_29.png"],
              // image_length: 29,
              // type: hmUI.data_type.forecast_image,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            //start of ignored block
            if (screenType == hmSetting.screen_type.WATCHFACE) {
              for (let i = 0; i < 4; i++) {
                normal_forecast_image_progress_img_level[i] = normal_group_ForecastWeather.createWidget(hmUI.widget.IMG, {
                  x: 78 + i*31,
                  y: 167,
                  src: normal_forecast_image_array[25],
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
              };
            };
            //end of ignored block

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 239,
              y: 176,
              src: 'BG_HEART.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 217,
              y: 109,
              font_array: ["Act_0.png","Act_1.png","Act_2.png","Act_3.png","Act_4.png","Act_5.png","Act_6.png","Act_7.png","Act_8.png","Act_9.png"],
              padding: false,
              h_space: 3,
              unit_sc: 'Heart_Unit.png',
              unit_tc: 'Heart_Unit.png',
              unit_en: 'Heart_Unit.png',
              invalid_image: 'Act_0.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 239,
              y: 217,
              src: 'Bg_pulse_bar.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 239,
              y: 176,
              image_array: ["Zone1.png","Zone2.png","Zone3.png","Zone4.png","Zone5.png","Zone6.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_frame_animation_1 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
              x: 57,
              y: 86,
              anim_path: "animation",
              anim_ext: "png",
              anim_prefix: "PU",
              anim_fps: 15,
              anim_size: 30,
              repeat_count: 0,
              anim_repeat: true,
              anim_status:hmUI.anim_status.START,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_frame_animation_2 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
              x: 186,
              y: 293,
              anim_path: "animation",
              anim_ext: "png",
              anim_prefix: "Cdot",
              anim_fps: 7,
              anim_size: 6,
              repeat_count: 0,
              anim_repeat: true,
              anim_status:hmUI.anim_status.START,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 237,
              y: 196,
              font_array: ["Ac_mid_0.png","Ac_mid_1.png","Ac_mid_2.png","Ac_mid_3.png","Ac_mid_4.png","Ac_mid_5.png","Ac_mid_6.png","Ac_mid_7.png","Ac_mid_8.png","Ac_mid_9.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'Dis_KM.png',
              unit_tc: 'Dis_KM.png',
              unit_en: 'Dis_KM.png',
              imperial_unit_sc: 'Dis_Mi.png',
              imperial_unit_tc: 'Dis_Mi.png',
              imperial_unit_en: 'Dis_Mi.png',
              dot_image: 'Dis_Dot.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 224,
              y: 164,
              src: 'CAL_DIS_icon.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 256,
              y: 133,
              font_array: ["Ac_mid_0.png","Ac_mid_1.png","Ac_mid_2.png","Ac_mid_3.png","Ac_mid_4.png","Ac_mid_5.png","Ac_mid_6.png","Ac_mid_7.png","Ac_mid_8.png","Ac_mid_9.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'Cal_Unit.png',
              unit_tc: 'Cal_Unit.png',
              unit_en: 'Cal_Unit.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 238,
              y: 104,
              src: 'BG_Cal.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 238,
              y: 104,
              image_array: ["Cal_Progress_01.png","Cal_Progress_02.png","Cal_Progress_03.png","Cal_Progress_04.png","Cal_Progress_05.png","Cal_Progress_06.png","Cal_Progress_07.png","Cal_Progress_08.png"],
              image_length: 8,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 245,
              day_startY: 187,
              day_sc_array: ["Ac_mid_0.png","Ac_mid_1.png","Ac_mid_2.png","Ac_mid_3.png","Ac_mid_4.png","Ac_mid_5.png","Ac_mid_6.png","Ac_mid_7.png","Ac_mid_8.png","Ac_mid_9.png"],
              day_tc_array: ["Ac_mid_0.png","Ac_mid_1.png","Ac_mid_2.png","Ac_mid_3.png","Ac_mid_4.png","Ac_mid_5.png","Ac_mid_6.png","Ac_mid_7.png","Ac_mid_8.png","Ac_mid_9.png"],
              day_en_array: ["Ac_mid_0.png","Ac_mid_1.png","Ac_mid_2.png","Ac_mid_3.png","Ac_mid_4.png","Ac_mid_5.png","Ac_mid_6.png","Ac_mid_7.png","Ac_mid_8.png","Ac_mid_9.png"],
              day_zero: 1,
              day_space: 2,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 304,
              y: 111,
              week_en: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              week_tc: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              week_sc: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 346,
              month_startY: 187,
              month_sc_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_tc_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_en_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 226,
              y: 103,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_compass_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 56,
              y: 85,
              src: 'compassCenter.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const deviceInfo = hmSetting.getDeviceInfo();
            
            // normal_compass_custom_pointer_img = hmUI.createWidget(hmUI.widget.CUSTOM_POINTER, {
              // src: 'Compass_Pointer.png',
              // center_x: 135,
              // center_y: 164,
              // x: 75,
              // y: 75,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.COMPASS,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            //start of ignored block
            normal_compass_direction_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 135 - 75,
              pos_y: 164 - 75,
              center_x: 135,
              center_y: 164,
              src: 'Compass_Pointer.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            //end of ignored block

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 146,
              y: 35,
              font_array: ["Ac_mid_0.png","Ac_mid_1.png","Ac_mid_2.png","Ac_mid_3.png","Ac_mid_4.png","Ac_mid_5.png","Ac_mid_6.png","Ac_mid_7.png","Ac_mid_8.png","Ac_mid_9.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 252,
              y: 56,
              image_array: ["Batt_progress_01.png","Batt_progress_02.png","Batt_progress_03.png","Batt_progress_04.png","Batt_progress_05.png"],
              image_length: 5,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 96,
              y: 383,
              font_array: ["Act_0.png","Act_1.png","Act_2.png","Act_3.png","Act_4.png","Act_5.png","Act_6.png","Act_7.png","Act_8.png","Act_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 286,
              y: 407,
              image_array: ["step_progress01.png","step_progress02.png","step_progress03.png","step_progress04.png","step_progress05.png"],
              image_length: 5,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 358,
              am_y: 267,
              am_sc_path: 'ClockAM.png',
              am_en_path: 'ClockAM.png',
              pm_x: 358,
              pm_y: 267,
              pm_sc_path: 'ClockPM.png',
              pm_en_path: 'ClockPM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_second = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              second_startX: 356,
              second_startY: 300,
              second_array: ["Time_S_0.png","Time_S_1.png","Time_S_2.png","Time_S_3.png","Time_S_4.png","Time_S_5.png","Time_S_6.png","Time_S_7.png","Time_S_8.png","Time_S_9.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 198,
              minute_startY: 268,
              minute_array: ["Time_0.png","Time_1.png","Time_2.png","Time_3.png","Time_4.png","Time_5.png","Time_6.png","Time_7.png","Time_8.png","Time_9.png"],
              minute_zero: 1,
              minute_space: 5,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 30,
              hour_startY: 268,
              hour_array: ["Time_0.png","Time_1.png","Time_2.png","Time_3.png","Time_4.png","Time_5.png","Time_6.png","Time_7.png","Time_8.png","Time_9.png"],
              hour_zero: 1,
              hour_space: 5,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');

            idle_digital_clock_img_time_second = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              second_startX: 361,
              second_startY: 218,
              second_array: ["Time_S_0.png","Time_S_1.png","Time_S_2.png","Time_S_3.png","Time_S_4.png","Time_S_5.png","Time_S_6.png","Time_S_7.png","Time_S_8.png","Time_S_9.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 191,
              minute_startY: 183,
              minute_array: ["Time_0.png","Time_1.png","Time_2.png","Time_3.png","Time_4.png","Time_5.png","Time_6.png","Time_7.png","Time_8.png","Time_9.png"],
              minute_zero: 1,
              minute_space: 5,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_minute_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 357,
              y: 185,
              src: 'Clock24.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 13,
              hour_startY: 183,
              hour_array: ["Time_0.png","Time_1.png","Time_2.png","Time_3.png","Time_4.png","Time_5.png","Time_6.png","Time_7.png","Time_8.png","Time_9.png"],
              hour_zero: 1,
              hour_space: 5,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 173,
              y: 208,
              src: 'Cdot_0.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 357,
              am_y: 184,
              am_sc_path: 'ClockAM.png',
              am_en_path: 'ClockAM.png',
              pm_x: 357,
              pm_y: 184,
              pm_sc_path: 'ClockPM.png',
              pm_en_path: 'ClockPM.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 104,
              y: 383,
              w: 177,
              h: 47,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 238,
              y: 118,
              w: 204,
              h: 96,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 229,
              y: 159,
              w: 240,
              h: 39,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 229,
              y: 106,
              w: 70,
              h: 63,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 258,
              y: 122,
              w: 163,
              h: 97,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 87,
              y: 116,
              w: 100,
              h: 100,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 362,
              y: 301,
              w: 85,
              h: 53,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 235,
              y: 284,
              w: 84,
              h: 59,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 174,
              y: 280,
              w: 30,
              h: 67,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 0,
              y: 181,
              w: 69,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                // switch activity
click_elemente() 
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 238,
              y: 185,
              w: 209,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
// calendar
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 197,
              y: 32,
              w: 187,
              h: 43,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PowerSaveHintScreen', native: true });
// battery
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 98,
              y: 21,
              w: 66,
              h: 58,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'CompassScreen', native: true });
//compass
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 291,
              y: 387,
              w: 94,
              h: 43,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'SportListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            console.log('user_script_end.js');
            // start user_script_end.js

if ( cc ==0 ) {
UpdateElementeOne()
cc =1
}
            // end user_script_end.js

            //start of ignored block
            function weather_few_days() {
              console.log('weather_few_days()');
              let weatherData = weatherSensor.getForecastWeather();
              let forecastData = weatherData.forecastData;
              let result = {graphScale: 1, maximal_temp: 0};
              let averageOldX = 0;

              if (screenType == hmSetting.screen_type.WATCHFACE) result = graphScale(40, 0, 0, forecastData.data, 4);
              let forecastGraphScale = result.graphScale;
              let maximal_temp = result.maximal_temp;
              console.log(`forecastGraphScale = ${forecastGraphScale}, maximal_temp = ${maximal_temp}`);

              if (screenType == hmSetting.screen_type.WATCHFACE) {
                normal_canvas2.clear({x: 0, y:0, w: 215, h: 215});
              };
              let normal_average_offsetX = 93;
              if (screenType == hmSetting.screen_type.WATCHFACE) averageOldX = normal_average_offsetX;
              let averageOldY = (maximal_temp - (forecastData.data[0].high + forecastData.data[0].low) / 2) * forecastGraphScale + 0;
              let endPointAverage = false;
              for (let i = 0; i < 4; i++) {
                // Graph
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (i < forecastData.count) {
                    let averageStartX = averageOldX;
                    let averageStartY = averageOldY;
                    averageOldX = normal_average_offsetX + i * 31;
                    averageOldY = (maximal_temp - (forecastData.data[i].high + forecastData.data[i].low) / 2) * forecastGraphScale + 0;
                    let averageEndX = averageOldX;
                    let averageEndY = averageOldY;
                    if (averageStartX != averageEndX) {
                      drawLine(normal_canvas1, normal_canvas2, averageStartX, averageStartY, averageEndX, averageEndY, 0xFF94978A, 3)
                      drawGraphPoint(normal_canvas1, normal_canvas2, averageStartX, averageStartY, 0xFF94978A, 9, 4)
                      endPointAverage = true;
                    };
                  
                  };
                };  // end screen_type
                
                // Number_Font_Average
                let averageTemperature = '-';
                if (i < forecastData.count) averageTemperature = parseInt((forecastData.data[i].high + forecastData.data[i].low)/2).toString();
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  normal_forecast_average_text_font[i].setProperty(hmUI.prop.TEXT, averageTemperature + '°');
                };
                
                // DayOfWeek font
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  let dowIndex = timeSensor.week - 1;
                  dowIndex += i;
                  while (dowIndex >= 7) {dowIndex -= 7;}
                  normal_forecast_date_week_font[i].setProperty(hmUI.prop.TEXT, normal_forecast_date_week_font_Array[dowIndex]);
                };
              
                // Images
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  let weatherIndex = 25
                  if (i < forecastData.count) weatherIndex = forecastData.data[i].index;
                  normal_forecast_image_progress_img_level[i].setProperty(hmUI.prop.SRC, normal_forecast_image_array[weatherIndex]);
                };
              
              };  // end for

              if (screenType == hmSetting.screen_type.WATCHFACE && endPointAverage) {
                drawGraphPoint(normal_canvas1, normal_canvas2, averageOldX, averageOldY, 0xFF94978A, 9, 4)
              };
            };
            //end of ignored block

            //start of ignored block
            console.log('compass_update()');
            if (screenType == hmSetting.screen_type.WATCHFACE){
              compass = hmSensor.createSensor(hmSensor.id.COMPASS);
              compass.start();

              if (compass.direction_angle && compass.direction  && compass.direction_angle != 'INVALID') { // initial data
                // Compass Pointer
                let compass_direction_angle = parseInt(compass.direction_angle);
                normal_compass_direction_pointer_img.setProperty(hmUI.prop.ANGLE, -compass_direction_angle);

              } else { // error data
                normal_compass_direction_pointer_img.setProperty(hmUI.prop.ANGLE, 0);

              }

              compass.addEventListener(hmSensor.event.CHANGE, function (compass_res) { // change values when changing direction

                if (compass_res.calibration_status) {
                  // Compass Pointer
                  let compass_direction_angle = parseInt(compass_res.direction_angle);
                  normal_compass_direction_pointer_img.setProperty(hmUI.prop.ANGLE, -compass_direction_angle);

                } else { // error data
                  normal_compass_direction_pointer_img.setProperty(hmUI.prop.ANGLE, 0);

                }

              }); // Listener end

            };
            //end of ignored block

            function scale_call() {
              console.log('scale_call()');

              console.log('Weather city name');
              let weatherData = weatherSensor.getForecastWeather();
              normal_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);
                normal_frame_animation_2.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);
                if (compass && screenType == hmSetting.screen_type.WATCHFACE) compass.start();

                weather_few_days();
              }),
              pause_call: (function () {
                console.log('pause_call()');
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);
                normal_frame_animation_2.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);
                if (compass) compass.stop();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
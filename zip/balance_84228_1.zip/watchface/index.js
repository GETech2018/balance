﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg = ''
        let idle_image_img = ''
        let idle_step_current_text_img = ''
        let idle_step_current_separator_img = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_week_img = ''
        let idle_battery_text_text_img = ''
        let idle_battery_image_progress_img_level = ''
        let idle_digital_clock_img_time = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 220,
              y: 400,
              font_array: ["r00.png","r01r.png","r02.png","r03.png","r04.png","r05.png","r06.png","r07.png","r08.png","r09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 183,
              y: 400,
              src: 'Footsteps-PNG-Clipart (1) (1).png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 271,
              month_startY: 315,
              month_sc_array: ["w001 gen.png","w002 feb.png","w003 mar.png","w004 apr.png","w005 mag.png","w006 giu.png","w007 lug.png","w008 ago.png","w009 set.png","w010 ott.png","w011 nov.png","w012 dic.png"],
              month_tc_array: ["w001 gen.png","w002 feb.png","w003 mar.png","w004 apr.png","w005 mag.png","w006 giu.png","w007 lug.png","w008 ago.png","w009 set.png","w010 ott.png","w011 nov.png","w012 dic.png"],
              month_en_array: ["w001 gen.png","w002 feb.png","w003 mar.png","w004 apr.png","w005 mag.png","w006 giu.png","w007 lug.png","w008 ago.png","w009 set.png","w010 ott.png","w011 nov.png","w012 dic.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 218,
              day_startY: 322,
              day_sc_array: ["r00.png","r01r.png","r02.png","r03.png","r04.png","r05.png","r06.png","r07.png","r08.png","r09.png"],
              day_tc_array: ["r00.png","r01r.png","r02.png","r03.png","r04.png","r05.png","r06.png","r07.png","r08.png","r09.png"],
              day_en_array: ["r00.png","r01r.png","r02.png","r03.png","r04.png","r05.png","r06.png","r07.png","r08.png","r09.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 128,
              y: 315,
              week_en: ["x1 lun.png","x2 mar.png","x3 mer.png","x4 gio.png","x5 ven.png","x6 sab.png","x7 dom.png"],
              week_tc: ["x1 lun.png","x2 mar.png","x3 mer.png","x4 gio.png","x5 ven.png","x6 sab.png","x7 dom.png"],
              week_sc: ["x1 lun.png","x2 mar.png","x3 mer.png","x4 gio.png","x5 ven.png","x6 sab.png","x7 dom.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 220,
              y: 80,
              font_array: ["r00.png","r01r.png","r02.png","r03.png","r04.png","r05.png","r06.png","r07.png","r08.png","r09.png"],
              padding: true,
              h_space: 0,
              unit_sc: 'perc.png',
              unit_tc: 'perc.png',
              unit_en: 'perc.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 178,
              y: 77,
              image_array: ["b00.png","b01.png","b02.png","b03.png","b04.png","b05.png","b06.png","b07.png","b08.png","b09.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 50,
              hour_startY: 190,
              hour_array: ["g00.png","g01r.png","g02.png","g03.png","g04.png","g05.png","g06.png","g07.png","g08.png","g09.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 257,
              minute_startY: 190,
              minute_array: ["g00.png","g01r.png","g02.png","g03.png","g04.png","g05.png","g06.png","g07.png","g08.png","g09.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 219,
              second_startY: 270,
              second_array: ["r00.png","r01r.png","r02.png","r03.png","r04.png","r05.png","r06.png","r07.png","r08.png","r09.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 230,
              y: 210,
              src: 'barra2.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 220,
              y: 400,
              font_array: ["r00.png","r01r.png","r02.png","r03.png","r04.png","r05.png","r06.png","r07.png","r08.png","r09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 183,
              y: 400,
              src: 'Footsteps-PNG-Clipart (1) (1).png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 271,
              month_startY: 315,
              month_sc_array: ["w001 gen.png","w002 feb.png","w003 mar.png","w004 apr.png","w005 mag.png","w006 giu.png","w007 lug.png","w008 ago.png","w009 set.png","w010 ott.png","w011 nov.png","w012 dic.png"],
              month_tc_array: ["w001 gen.png","w002 feb.png","w003 mar.png","w004 apr.png","w005 mag.png","w006 giu.png","w007 lug.png","w008 ago.png","w009 set.png","w010 ott.png","w011 nov.png","w012 dic.png"],
              month_en_array: ["w001 gen.png","w002 feb.png","w003 mar.png","w004 apr.png","w005 mag.png","w006 giu.png","w007 lug.png","w008 ago.png","w009 set.png","w010 ott.png","w011 nov.png","w012 dic.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 218,
              day_startY: 322,
              day_sc_array: ["r00.png","r01r.png","r02.png","r03.png","r04.png","r05.png","r06.png","r07.png","r08.png","r09.png"],
              day_tc_array: ["r00.png","r01r.png","r02.png","r03.png","r04.png","r05.png","r06.png","r07.png","r08.png","r09.png"],
              day_en_array: ["r00.png","r01r.png","r02.png","r03.png","r04.png","r05.png","r06.png","r07.png","r08.png","r09.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 128,
              y: 315,
              week_en: ["x1 lun.png","x2 mar.png","x3 mer.png","x4 gio.png","x5 ven.png","x6 sab.png","x7 dom.png"],
              week_tc: ["x1 lun.png","x2 mar.png","x3 mer.png","x4 gio.png","x5 ven.png","x6 sab.png","x7 dom.png"],
              week_sc: ["x1 lun.png","x2 mar.png","x3 mer.png","x4 gio.png","x5 ven.png","x6 sab.png","x7 dom.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 220,
              y: 80,
              font_array: ["r00.png","r01r.png","r02.png","r03.png","r04.png","r05.png","r06.png","r07.png","r08.png","r09.png"],
              padding: true,
              h_space: 0,
              unit_sc: 'perc.png',
              unit_tc: 'perc.png',
              unit_en: 'perc.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 178,
              y: 77,
              image_array: ["b00.png","b01.png","b02.png","b03.png","b04.png","b05.png","b06.png","b07.png","b08.png","b09.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 50,
              hour_startY: 190,
              hour_array: ["g00.png","g01r.png","g02.png","g03.png","g04.png","g05.png","g06.png","g07.png","g08.png","g09.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 257,
              minute_startY: 190,
              minute_array: ["g00.png","g01r.png","g02.png","g03.png","g04.png","g05.png","g06.png","g07.png","g08.png","g09.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
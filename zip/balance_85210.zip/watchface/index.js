﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg = ''
        let normal_image_img = ''
        let normal_sun_icon_img = ''
        let normal_pai_icon_img = ''
        let normal_pai_weekly_text_font = ''
        let normal_spo2_icon_img = ''
        let normal_spo2_current_text_font = ''
        let normal_calorie_icon_img = ''
        let normal_calorie_current_text_font = ''
        let normal_calorie_image_progress_img_progress = ''
        let normal_distance_icon_img = ''
        let normal_distance_current_text_font = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_step_icon_img = ''
        let normal_step_current_text_font = ''
        let normal_step_image_progress_img_progress = ''
        let normal_month_name_font = ''
        let normal_Month_Array = ['GEN', 'FEB', 'MAR', 'APR', 'MAG', 'GIU', 'LUG', 'AGO', 'SET', 'OTT', 'NOV', 'DIC', ];
        let normal_day_text_font = ''
        let normal_dow_text_font = ''
        let normal_DOW_Array = ['LUN', 'MAR', 'MER', 'GIO', 'VEN', 'SAB', 'DOM'];
        let normal_stress_icon_img = ''
        let normal_stress_current_text_font = ''
        let normal_stress_image_progress_img_level = ''
        let normal_heart_rate_text_font = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_battery_icon_img = ''
        let normal_battery_current_text_font = ''
        let normal_battery_image_progress_img_level = ''
        let normal_altimeter_icon_img = ''
        let normal_altimeter_current_text_font = ''
        let normal_humidity_icon_img = ''
        let normal_humidity_current_text_font = ''
        let normal_temperature_current_text_font = ''
        let normal_city_name_text = ''
        let normal_temperature_icon_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_digital_clock_img_time_second = ''
        let normal_digital_clock_img_time_minute = ''
        let normal_digital_clock_img_time_hour = ''
        let normal_digital_clock_hour_separator_img = ''
        let idle_background_bg = ''
        let idle_image_img = ''
        let idle_sun_icon_img = ''
        let idle_pai_icon_img = ''
        let idle_pai_weekly_text_font = ''
        let idle_spo2_icon_img = ''
        let idle_spo2_current_text_font = ''
        let idle_calorie_icon_img = ''
        let idle_calorie_current_text_font = ''
        let idle_calorie_image_progress_img_progress = ''
        let idle_distance_icon_img = ''
        let idle_distance_current_text_font = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_step_icon_img = ''
        let idle_step_current_text_font = ''
        let idle_step_image_progress_img_progress = ''
        let idle_month_name_font = ''
        let idle_Month_Array = ['GEN', 'FEB', 'MAR', 'APR', 'MAG', 'GIU', 'LUG', 'AGO', 'SET', 'OTT', 'NOV', 'DIC', ];
        let idle_day_text_font = ''
        let idle_dow_text_font = ''
        let idle_DOW_Array = ['LUN', 'MAR', 'MER', 'GIO', 'VEN', 'SAB', 'DOM'];
        let idle_stress_icon_img = ''
        let idle_stress_current_text_font = ''
        let idle_stress_image_progress_img_level = ''
        let idle_heart_rate_text_font = ''
        let idle_heart_rate_image_progress_img_level = ''
        let idle_battery_icon_img = ''
        let idle_battery_current_text_font = ''
        let idle_battery_image_progress_img_level = ''
        let idle_altimeter_icon_img = ''
        let idle_altimeter_current_text_font = ''
        let idle_humidity_icon_img = ''
        let idle_humidity_current_text_font = ''
        let idle_temperature_current_text_font = ''
        let idle_city_name_text = ''
        let idle_temperature_icon_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_digital_clock_img_time = ''
        let normal_step_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_altimeter_jumpable_img_click = ''
        let normal_stress_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_Switch_BG_Color = ''

        let bgColorIndex = 0;
        let bgColorList = [0xFFFFFFFF, 0xFFC0C0C0, 0xFF8A9597, 0xFFFFFF00, 0xFFD6A705, 0xFFFF8000, 0xFFFF0000, 0xFF00FF00, 0xFF00FFFF, 0xFF0080FF, 0xFF8000FF];
        let bgColorToastList = ['bianco', 'grigio', 'argento', 'giallo', 'oro', 'arancione', 'rosso', 'verde fluo', 'azzurro', 'blu', 'glicine'];
        const watchfaceId = hmApp.packageInfo().watchfaceId;
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            //start of ignored block
            console.log('SwitchBG_Color');
            function switchBG_Color() {
              bgColorIndex++;
              if (bgColorIndex >= bgColorList.length) bgColorIndex = 0;
              hmFS.SysProSetInt(`bgColorIndex_${watchfaceId}`, bgColorIndex);
              let toastText = bgColorToastList[bgColorIndex].replace('%s', `${bgColorIndex + 1}`);
              if (toastText.length > 0) hmUI.showToast({text: toastText});
              normal_background_bg.setProperty(hmUI.prop.COLOR, bgColorList[bgColorIndex]);
            };
            //end of ignored block

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFFFFFFFF',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: '1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 179,
              y: 389,
              src: '80.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 98,
              y: 402,
              src: 'PAI.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_weekly_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 84,
              y: 397,
              w: 150,
              h: 40,
              text_size: 30,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              padding: true,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 282,
              y: 367,
              src: 'spo2_(2).png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 265,
              y: 361,
              w: 150,
              h: 40,
              text_size: 30,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 413,
              y: 322,
              src: '0091.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 194,
              y: 314,
              w: 150,
              h: 40,
              text_size: 30,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.RIGHT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_image_progress_img_progress = hmUI.createWidget(hmUI.widget.IMG_PROGRESS, {
              x: [350],
              y: [328],
              image_array: ["0122.png"],
              image_length: 1,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 47,
              y: 362,
              src: 'distanza.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 42,
              y: 356,
              w: 150,
              h: 40,
              text_size: 30,
              char_space: -1,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 305,
              y: 409,
              src: '66.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 340,
              y: 410,
              src: 'alarme.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 32,
              y: 318,
              src: '0088.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 52,
              y: 314,
              w: 150,
              h: 40,
              text_size: 30,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_progress = hmUI.createWidget(hmUI.widget.IMG_PROGRESS, {
              x: [368],
              y: [375],
              image_array: ["sPO2_(3).png"],
              image_length: 1,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function() {
              time_update(true);
            });

            normal_month_name_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 371,
              y: 145,
              w: 150,
              h: 50,
              text_size: 36,
              char_space: 0,
              line_space: 0,
              color: 0xFF808080,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              // unit_string: GEN,FEB,MAR,APR,MAG,GIU,LUG,AGO,SET,OTT,NOV,DIC,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_day_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 245,
              y: 138,
              w: 150,
              h: 54,
              text_size: 45,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_dow_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 197,
              y: 145,
              w: 150,
              h: 51,
              text_size: 36,
              char_space: 2,
              line_space: 0,
              color: 0xFF808080,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              // unit_string: LUN,MAR,MER,GIO,VEN,SAB,DOM,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 156,
              y: 373,
              src: 'KM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 22,
              y: 261,
              w: 150,
              h: 40,
              text_size: 30,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.STRESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 43,
              y: 266,
              image_array: ["stress_1.png","stress_2.png","stress_3.png","stress_4.png","stress_5.png","stress_6.png"],
              image_length: 6,
              type: hmUI.data_type.STRESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: -7,
              y: 203,
              w: 150,
              h: 40,
              text_size: 30,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 69,
              y: 183,
              image_array: ["h_01.png","h_02.png","h_03.png","h_04.png","h_05.png","h_06.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 199,
              y: 325,
              src: 'A16.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 164,
              y: 338,
              w: 150,
              h: 40,
              text_size: 30,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 204,
              y: 328,
              image_array: ["0100.png","0101.png","0102.png","0103.png","0104.png","0105.png","0106.png","0107.png"],
              image_length: 8,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 404,
              y: 93,
              src: 'PRESSIONE.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 287,
              y: 85,
              w: 150,
              h: 40,
              text_size: 30,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.WRAP,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 308,
              y: 57,
              src: 'UMIDITA.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 202,
              y: 47,
              w: 150,
              h: 40,
              text_size: 30,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 67,
              y: 47,
              w: 150,
              h: 40,
              text_size: 30,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 25,
              y: 124,
              w: 159,
              h: 32,
              text_size: 23,
              char_space: 0,
              line_space: 0,
              color: 0xFFC0C0C0,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 88,
              y: 59,
              src: 'TERMOMETRO.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 165,
              y: 28,
              image_array: ["m0044.png","m0045.png","m0046.png","m0047.png","m0048.png","m0049.png","m0050.png","m0051.png","m0052.png","m0053.png","m0054.png","m0055.png","m0056.png","m0057.png","m0058.png","m0059.png","m0060.png","m0061.png","m0062.png","m0063.png","m0064.png","m0065.png","m0066.png","m0067.png","m0068.png","m0069.png","m0070.png","m0071.png","m0072.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_second = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              second_startX: 303,
              second_startY: 219,
              second_array: ["56.png","57.png","58.png","59.png","60.png","61.png","62.png","63.png","64.png","65.png"],
              second_zero: 1,
              second_space: 3,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 348,
              minute_startY: 214,
              minute_array: ["a0003.png","a0004.png","a0005.png","a0006.png","a0007.png","a0008.png","a0009.png","a0010.png","a0011.png","a0012.png"],
              minute_zero: 1,
              minute_space: 15,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 178,
              hour_startY: 214,
              hour_array: ["a0003.png","a0004.png","a0005.png","a0006.png","a0007.png","a0008.png","a0009.png","a0010.png","a0011.png","a0012.png"],
              hour_zero: 1,
              hour_space: 15,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 290,
              y: 247,
              src: '146.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: '1AOD.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_sun_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 185,
              y: 397,
              src: 'Compass2.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_pai_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 98,
              y: 402,
              src: 'PAI.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_pai_weekly_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 84,
              y: 397,
              w: 150,
              h: 40,
              text_size: 30,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              padding: true,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_spo2_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 282,
              y: 367,
              src: 'spo2_(2).png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_spo2_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 265,
              y: 361,
              w: 150,
              h: 40,
              text_size: 30,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 413,
              y: 322,
              src: '0091.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 194,
              y: 314,
              w: 150,
              h: 40,
              text_size: 30,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.RIGHT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_image_progress_img_progress = hmUI.createWidget(hmUI.widget.IMG_PROGRESS, {
              x: [350],
              y: [328],
              image_array: ["0122.png"],
              image_length: 1,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_distance_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 47,
              y: 362,
              src: 'distanza.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_distance_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 42,
              y: 356,
              w: 150,
              h: 40,
              text_size: 30,
              char_space: -1,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 305,
              y: 409,
              src: '66.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 340,
              y: 410,
              src: 'alarme.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 32,
              y: 318,
              src: '0088.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 52,
              y: 314,
              w: 150,
              h: 40,
              text_size: 30,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_image_progress_img_progress = hmUI.createWidget(hmUI.widget.IMG_PROGRESS, {
              x: [368],
              y: [375],
              image_array: ["sPO2_(3).png"],
              image_length: 1,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_month_name_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 371,
              y: 145,
              w: 150,
              h: 50,
              text_size: 36,
              char_space: 0,
              line_space: 0,
              color: 0xFF808080,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              // unit_string: GEN,FEB,MAR,APR,MAG,GIU,LUG,AGO,SET,OTT,NOV,DIC,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_day_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 245,
              y: 138,
              w: 150,
              h: 54,
              text_size: 45,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              // padding: true,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_dow_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 197,
              y: 145,
              w: 150,
              h: 51,
              text_size: 36,
              char_space: 2,
              line_space: 0,
              color: 0xFF808080,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              // unit_string: LUN,MAR,MER,GIO,VEN,SAB,DOM,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_stress_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 156,
              y: 373,
              src: 'KM.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_stress_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 22,
              y: 261,
              w: 150,
              h: 40,
              text_size: 30,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.STRESS,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_stress_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 43,
              y: 266,
              image_array: ["stress_1.png","stress_2.png","stress_3.png","stress_4.png","stress_5.png","stress_6.png"],
              image_length: 6,
              type: hmUI.data_type.STRESS,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: -7,
              y: 203,
              w: 150,
              h: 40,
              text_size: 30,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 69,
              y: 183,
              image_array: ["h_01.png","h_02.png","h_03.png","h_04.png","h_05.png","h_06.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 199,
              y: 325,
              src: 'A16.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 164,
              y: 338,
              w: 150,
              h: 40,
              text_size: 30,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 204,
              y: 328,
              image_array: ["0100.png","0101.png","0102.png","0103.png","0104.png","0105.png","0106.png","0107.png"],
              image_length: 8,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_altimeter_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 404,
              y: 93,
              src: 'PRESSIONE.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_altimeter_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 287,
              y: 85,
              w: 150,
              h: 40,
              text_size: 30,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.WRAP,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_humidity_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 308,
              y: 57,
              src: 'UMIDITA.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_humidity_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 202,
              y: 47,
              w: 150,
              h: 40,
              text_size: 30,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 67,
              y: 47,
              w: 150,
              h: 40,
              text_size: 30,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 25,
              y: 124,
              w: 159,
              h: 32,
              text_size: 23,
              char_space: 0,
              line_space: 0,
              color: 0xFFC0C0C0,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 88,
              y: 59,
              src: 'TERMOMETRO.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 165,
              y: 28,
              image_array: ["m0044.png","m0045.png","m0046.png","m0047.png","m0048.png","m0049.png","m0050.png","m0051.png","m0052.png","m0053.png","m0054.png","m0055.png","m0056.png","m0057.png","m0058.png","m0059.png","m0060.png","m0061.png","m0062.png","m0063.png","m0064.png","m0065.png","m0066.png","m0067.png","m0068.png","m0069.png","m0070.png","m0071.png","m0072.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 178,
              hour_startY: 214,
              hour_array: ["b0003.png","b0004.png","b0005.png","b0006.png","b0007.png","b0008.png","b0009.png","b0010.png","b0011.png","b0012.png"],
              hour_zero: 1,
              hour_space: 15,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 348,
              minute_startY: 214,
              minute_array: ["b0003.png","b0004.png","b0005.png","b0006.png","b0007.png","b0008.png","b0009.png","b0010.png","b0011.png","b0012.png"],
              minute_zero: 1,
              minute_space: 15,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 27,
              y: 315,
              w: 150,
              h: 80,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 39,
              y: 180,
              w: 100,
              h: 60,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 88,
              y: 404,
              w: 100,
              h: 40,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 148,
              y: 21,
              w: 100,
              h: 100,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 289,
              y: 366,
              w: 150,
              h: 40,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 340,
              y: 33,
              w: 100,
              h: 100,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 40,
              y: 247,
              w: 100,
              h: 60,
              type: hmUI.data_type.STRESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 359,
              y: 205,
              w: 100,
              h: 100,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 173,
              y: 204,
              w: 100,
              h: 100,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 307,
              y: 411,
              w: 80,
              h: 50,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 232,
              y: 151,
              w: 200,
              h: 42,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_empty.png',
              normal_src: '0_empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 195,
              y: 319,
              w: 90,
              h: 90,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_empty.png',
              normal_src: '0_empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'LowBatteryScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 293,
              y: 319,
              w: 150,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_empty.png',
              normal_src: '0_empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'oneKeyAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            console.log('Watch_Face.SwitchBG_Color');
            // Button_Switch_BG_Color = hmUI.createWidget(hmUI.widget.SwitchBG_Color, {
              // x: 193,
              // y: 420,
              // w: 100,
              // h: 60,
              // text: '',
              // color: 0xFFFF8C00,
              // text_size: 25,
              // press_src: '0_empty.png',
              // normal_src: '0_empty.png',
              // color_list: 0xFFFFFFFF|0xFFC0C0C0|0xFF8A9597|0xFFFFFF00|0xFFD6A705|0xFFFF8000|0xFFFF0000|0xFF00FF00|0xFF00FFFF|0xFF0080FF|0xFF8000FF,
              // toast_list: bianco|grigio|argento|giallo|oro|arancione|rosso|verde fluo|azzurro|blu|glicine,
              // use_crown: False,
              // use_in_AOD: False,
              // vibro: False,
            // });

            Button_Switch_BG_Color = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 193,
              y: 420,
              w: 100,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_empty.png',
              normal_src: '0_empty.png',
              click_func: (button_widget) => {
                switchBG_Color();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            let screenType = hmSetting.getScreenType();
            //start of ignored block
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              console.log('month font');
              if (updateHour) {
                let normal_Month_Str = normal_Month_Array[timeSensor.month-1];
                normal_month_name_font.setProperty(hmUI.prop.TEXT, normal_Month_Str );
              };

              console.log('day font');
              if (updateHour) {
                let normal_dayStr = timeSensor.day.toString();
                normal_dayStr = normal_dayStr.padStart(2, '0');
                normal_day_text_font.setProperty(hmUI.prop.TEXT, normal_dayStr );
              };

              console.log('day of week font');
              if (updateHour) {
                let normal_DOW_Str = normal_DOW_Array[timeSensor.week-1];
                normal_dow_text_font.setProperty(hmUI.prop.TEXT, normal_DOW_Str );
              };

              console.log('month font');
              if (updateHour) {
                let idle_Month_Str = idle_Month_Array[timeSensor.month-1];
                idle_month_name_font.setProperty(hmUI.prop.TEXT, idle_Month_Str );
              };

              console.log('day font');
              if (updateHour) {
                let idle_dayStr = timeSensor.day.toString();
                idle_dayStr = idle_dayStr.padStart(2, '0');
                idle_day_text_font.setProperty(hmUI.prop.TEXT, idle_dayStr );
              };

              console.log('day of week font');
              if (updateHour) {
                let idle_DOW_Str = idle_DOW_Array[timeSensor.week-1];
                idle_dow_text_font.setProperty(hmUI.prop.TEXT, idle_DOW_Str );
              };

            };

            //end of ignored block
            function scale_call() {
              console.log('scale_call()');

              console.log('Weather city name');
              let weatherData = weatherSensor.getForecastWeather();
              normal_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

              console.log('Weather city name');
              idle_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                time_update(true, true);

                //SwitchBgColor
                if (hmFS.SysProGetInt(`bgColorIndex_${watchfaceId}`) === undefined) {
                  bgColorIndex = 0;
                  hmFS.SysProSetInt(`bgColorIndex_${watchfaceId}`, bgColorIndex);
                } else {
                  bgColorIndex = hmFS.SysProGetInt(`bgColorIndex_${watchfaceId}`);
                };
                if (screenType == hmSetting.screen_type.WATCHFACE && normal_background_bg) normal_background_bg.setProperty(hmUI.prop.COLOR, bgColorList[bgColorIndex]);
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
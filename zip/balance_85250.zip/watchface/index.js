﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_month_img = ''
        let normal_step_current_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_temperature_high_text_img = ''
        let normal_temperature_low_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_battery_text_text_img = ''
        let normal_spo2_text_text_img = ''
        let normal_stress_text_text_img = ''
        let idle_background_bg_img = ''
        let idle_heart_rate_text_text_img = ''
        let idle_digital_clock_img_time = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_month_img = ''
        let idle_step_current_text_img = ''
        let idle_calorie_current_text_img = ''
        let idle_distance_text_text_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_temperature_current_text_img = ''
        let idle_temperature_high_text_img = ''
        let idle_temperature_low_text_img = ''
        let idle_battery_image_progress_img_level = ''
        let idle_battery_text_text_img = ''
        let idle_date_img_date_week_img = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_cal_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_stress_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let Button_1 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: '4.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 24,
              hour_startY: 186,
              hour_array: ["5.png","6.png","7.png","8.png","9.png","10.png","11.png","12.png","13.png","14.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_unit_sc: '15.png',
              hour_unit_tc: '15.png',
              hour_unit_en: '15.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 0,
              minute_startY: 0,
              minute_array: ["5.png","6.png","7.png","8.png","9.png","10.png","11.png","12.png","13.png","14.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 1,
              minute_align: hmUI.align.LEFT,

              second_startX: 393,
              second_startY: 248,
              second_array: ["16.png","17.png","18.png","19.png","20.png","21.png","22.png","23.png","24.png","25.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 384,
              am_y: 204,
              am_sc_path: '27.png',
              am_en_path: '27.png',
              pm_x: 384,
              pm_y: 204,
              pm_sc_path: '29.png',
              pm_en_path: '29.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 50,
              y: 126,
              week_en: ["30.png","31.png","32.png","33.png","34.png","35.png","36.png"],
              week_tc: ["30.png","31.png","32.png","33.png","34.png","35.png","36.png"],
              week_sc: ["30.png","31.png","32.png","33.png","34.png","35.png","36.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 392,
              day_startY: 139,
              day_sc_array: ["87.png","88.png","89.png","90.png","91.png","92.png","93.png","94.png","95.png","96.png"],
              day_tc_array: ["87.png","88.png","89.png","90.png","91.png","92.png","93.png","94.png","95.png","96.png"],
              day_en_array: ["87.png","88.png","89.png","90.png","91.png","92.png","93.png","94.png","95.png","96.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 284,
              month_startY: 138,
              month_sc_array: ["75.png","76.png","77.png","78.png","79.png","80.png","81.png","82.png","83.png","84.png","85.png","86.png"],
              month_tc_array: ["75.png","76.png","77.png","78.png","79.png","80.png","81.png","82.png","83.png","84.png","85.png","86.png"],
              month_en_array: ["75.png","76.png","77.png","78.png","79.png","80.png","81.png","82.png","83.png","84.png","85.png","86.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 212,
              y: 323,
              font_array: ["97.png","98.png","99.png","100.png","101.png","102.png","103.png","104.png","105.png","106.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 374,
              y: 323,
              font_array: ["97.png","98.png","99.png","100.png","101.png","102.png","103.png","104.png","105.png","106.png"],
              padding: false,
              h_space: 0,
              invalid_image: '107.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 76,
              y: 323,
              font_array: ["97.png","98.png","99.png","100.png","101.png","102.png","103.png","104.png","105.png","106.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 220,
              y: 358,
              font_array: ["108.png","109.png","110.png","111.png","112.png","113.png","114.png","115.png","116.png","117.png"],
              padding: false,
              h_space: 0,
              unit_sc: '119.png',
              unit_tc: '119.png',
              unit_en: '119.png',
              imperial_unit_sc: '120.png',
              imperial_unit_tc: '120.png',
              imperial_unit_en: '120.png',
              dot_image: '118.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 276,
              y: 52,
              image_array: ["121.png","122.png","123.png","124.png","125.png","126.png","127.png","128.png","129.png","130.png","131.png","132.png","133.png","134.png","135.png","136.png","137.png","138.png","139.png","140.png","141.png","142.png","143.png","144.png","145.png","146.png","147.png","148.png","149.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 343,
              y: 70,
              font_array: ["87.png","88.png","89.png","90.png","91.png","92.png","93.png","94.png","95.png","96.png"],
              padding: false,
              h_space: 0,
              unit_sc: '176.png',
              unit_tc: '176.png',
              unit_en: '176.png',
              negative_image: '175.png',
              invalid_image: '174.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 175,
              y: 70,
              font_array: ["177.png","178.png","179.png","180.png","181.png","182.png","183.png","184.png","185.png","186.png"],
              padding: false,
              h_space: 0,
              unit_sc: '189.png',
              unit_tc: '189.png',
              unit_en: '189.png',
              negative_image: '188.png',
              invalid_image: '187.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 101,
              y: 70,
              font_array: ["177.png","178.png","179.png","180.png","181.png","182.png","183.png","184.png","185.png","186.png"],
              padding: false,
              h_space: 0,
              unit_sc: '192.png',
              unit_tc: '192.png',
              unit_en: '192.png',
              negative_image: '191.png',
              invalid_image: '190.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 197,
              y: 22,
              image_array: ["150.png","151.png","152.png","153.png","154.png","155.png","156.png","157.png","158.png","159.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 245,
              y: 18,
              font_array: ["160.png","161.png","162.png","163.png","164.png","165.png","166.png","167.png","168.png","169.png"],
              padding: false,
              h_space: 0,
              unit_sc: '170.png',
              unit_tc: '170.png',
              unit_en: '170.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 151,
              y: 408,
              font_array: ["97.png","98.png","99.png","100.png","101.png","102.png","103.png","104.png","105.png","106.png"],
              padding: false,
              h_space: 0,
              unit_sc: '172.png',
              unit_tc: '172.png',
              unit_en: '172.png',
              invalid_image: '171.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 295,
              y: 409,
              font_array: ["97.png","98.png","99.png","100.png","101.png","102.png","103.png","104.png","105.png","106.png"],
              padding: false,
              h_space: 0,
              invalid_image: '173.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STRESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: '193.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 377,
              y: 324,
              font_array: ["194.png","195.png","196.png","197.png","198.png","199.png","200.png","201.png","202.png","203.png"],
              padding: false,
              h_space: 0,
              invalid_image: '204.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 67,
              hour_startY: 190,
              hour_array: ["205.png","206.png","207.png","208.png","209.png","210.png","211.png","212.png","213.png","214.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_unit_sc: '215.png',
              hour_unit_tc: '215.png',
              hour_unit_en: '215.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 249,
              minute_startY: 190,
              minute_array: ["5.png","6.png","7.png","8.png","9.png","10.png","11.png","12.png","13.png","14.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 392,
              day_startY: 139,
              day_sc_array: ["194.png","195.png","196.png","197.png","198.png","199.png","200.png","201.png","202.png","203.png"],
              day_tc_array: ["194.png","195.png","196.png","197.png","198.png","199.png","200.png","201.png","202.png","203.png"],
              day_en_array: ["194.png","195.png","196.png","197.png","198.png","199.png","200.png","201.png","202.png","203.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 290,
              month_startY: 138,
              month_sc_array: ["75.png","76.png","77.png","78.png","79.png","80.png","81.png","82.png","83.png","84.png","85.png","86.png"],
              month_tc_array: ["75.png","76.png","77.png","78.png","79.png","80.png","81.png","82.png","83.png","84.png","85.png","86.png"],
              month_en_array: ["75.png","76.png","77.png","78.png","79.png","80.png","81.png","82.png","83.png","84.png","85.png","86.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 212,
              y: 324,
              font_array: ["194.png","195.png","196.png","197.png","198.png","199.png","200.png","201.png","202.png","203.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 73,
              y: 324,
              font_array: ["194.png","195.png","196.png","197.png","198.png","199.png","200.png","201.png","202.png","203.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 195,
              y: 418,
              font_array: ["228.png","229.png","230.png","231.png","232.png","233.png","234.png","235.png","236.png","237.png"],
              padding: false,
              h_space: 0,
              unit_sc: '239.png',
              unit_tc: '239.png',
              unit_en: '239.png',
              imperial_unit_sc: '240.png',
              imperial_unit_tc: '240.png',
              imperial_unit_en: '240.png',
              dot_image: '238.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 275,
              y: 52,
              image_array: ["241.png","242.png","243.png","244.png","245.png","246.png","247.png","248.png","249.png","250.png","251.png","252.png","253.png","254.png","255.png","256.png","257.png","258.png","259.png","260.png","261.png","262.png","263.png","264.png","265.png","266.png","267.png","268.png","269.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 344,
              y: 71,
              font_array: ["194.png","195.png","196.png","197.png","198.png","199.png","200.png","201.png","202.png","203.png"],
              padding: false,
              h_space: 0,
              unit_sc: '272.png',
              unit_tc: '272.png',
              unit_en: '272.png',
              negative_image: '271.png',
              invalid_image: '270.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 178,
              y: 67,
              font_array: ["273.png","274.png","275.png","276.png","277.png","278.png","279.png","280.png","281.png","282.png"],
              padding: false,
              h_space: 0,
              unit_sc: '285.png',
              unit_tc: '285.png',
              unit_en: '285.png',
              negative_image: '284.png',
              invalid_image: '283.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 108,
              y: 67,
              font_array: ["273.png","274.png","275.png","276.png","277.png","278.png","279.png","280.png","281.png","282.png"],
              padding: false,
              h_space: 0,
              unit_sc: '288.png',
              unit_tc: '288.png',
              unit_en: '288.png',
              negative_image: '287.png',
              invalid_image: '286.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 197,
              y: 22,
              image_array: ["289.png","290.png","291.png","292.png","293.png","294.png","295.png","296.png","297.png","298.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 243,
              y: 18,
              font_array: ["299.png","300.png","301.png","302.png","303.png","304.png","305.png","306.png","307.png","308.png"],
              padding: false,
              h_space: 0,
              unit_sc: '309.png',
              unit_tc: '309.png',
              unit_en: '309.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 47,
              y: 126,
              week_en: ["310.png","311.png","312.png","313.png","314.png","315.png","316.png"],
              week_tc: ["310.png","311.png","312.png","313.png","314.png","315.png","316.png"],
              week_sc: ["310.png","311.png","312.png","313.png","314.png","315.png","316.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 245,
              y: 190,
              w: 115,
              h: 100,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 390,
              y: 190,
              w: 80,
              h: 100,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 60,
              y: 190,
              w: 115,
              h: 100,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 161,
              y: 312,
              w: 160,
              h: 80,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 330,
              y: 312,
              w: 125,
              h: 82,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_cal_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 22,
              y: 311,
              w: 130,
              h: 82,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 62,
              y: 399,
              w: 175,
              h: 79,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 245,
              y: 398,
              w: 155,
              h: 79,
              type: hmUI.data_type.STRESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 41,
              y: 53,
              w: 391,
              h: 62,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 300,
              y: 125,
              w: 130,
              h: 55,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              longpress_func: (button_widget) => {
                hmApp.startApp({url: 'todoListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
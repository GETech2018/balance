﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_moon_current_text_img = ''
        let normal_moon_pointer_progress_img_pointer = ''
        let normal_frame_animation_1 = ''
        let normal_sun_pointer_progress_img_pointer = ''
        let normal_sun_current_text_img = ''
        let icon_bg = ''
        let normal_battery_text_text_img = ''
		let normal_battery_text_text_img_1 = ''
        let normal_battery_text_separator_img = ''
		let normal_battery_text_separator_img_1 = ''
        let normal_heart_rate_text_text_img = ''
		let normal_heart_rate_text_text_img_1 = ''
        let normal_heart_rate_text_separator_img = ''
		let normal_heart_rate_text_separator_img_1 = ''
        let normal_calorie_current_text_img = ''
		let normal_calorie_current_text_img_1 = ''
        let normal_calorie_current_separator_img = ''
		let normal_calorie_current_separator_img_1 = ''
        let normal_distance_text_text_img = ''
		let normal_distance_text_text_img_1 = ''
        let normal_distance_text_separator_img = ''
		let normal_distance_text_separator_img_1 = ''
        let normal_step_current_text_img = ''
		let normal_step_current_text_img_1 = ''
        let normal_step_current_separator_img = ''
		let normal_step_current_separator_img_1 = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_digital_clock_img_time = ''
		let normal_sun_jumpable_img_click = ''
		let normal_moon_jumpable_img_click = ''
		
		
		let btn_zona1 = ''
        let zona1_num = 0
        let zona1_all = 4
		
		function click_zona1() {
		  zona1_num = (zona1_num + 1) % (zona1_all + 1);
          if (zona1_num == 0) {		
		    normal_step_current_text_img_1.setProperty(hmUI.prop.VISIBLE, true);
            normal_step_current_separator_img_1.setProperty(hmUI.prop.VISIBLE, true);
			normal_distance_text_text_img_1.setProperty(hmUI.prop.VISIBLE, false);
			normal_distance_text_separator_img_1.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_current_text_img_1.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_current_separator_img_1.setProperty(hmUI.prop.VISIBLE, false);
			normal_heart_rate_text_text_img_1.setProperty(hmUI.prop.VISIBLE, false);
			normal_heart_rate_text_separator_img_1.setProperty(hmUI.prop.VISIBLE, false);
			normal_battery_text_text_img_1.setProperty(hmUI.prop.VISIBLE, false);
			normal_battery_text_separator_img_1.setProperty(hmUI.prop.VISIBLE, false);
		    hmUI.showToast({
            });
          };
		  
		 if (zona1_num == 1) {
			normal_step_current_text_img_1.setProperty(hmUI.prop.VISIBLE, false);
            normal_step_current_separator_img_1.setProperty(hmUI.prop.VISIBLE, false);
			normal_distance_text_text_img_1.setProperty(hmUI.prop.VISIBLE, true);
			normal_distance_text_separator_img_1.setProperty(hmUI.prop.VISIBLE, true);
			normal_calorie_current_text_img_1.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_current_separator_img_1.setProperty(hmUI.prop.VISIBLE, false);
			normal_heart_rate_text_text_img_1.setProperty(hmUI.prop.VISIBLE, false);
			normal_heart_rate_text_separator_img_1.setProperty(hmUI.prop.VISIBLE, false);
			normal_battery_text_text_img_1.setProperty(hmUI.prop.VISIBLE, false);
			normal_battery_text_separator_img_1.setProperty(hmUI.prop.VISIBLE, false);
		    hmUI.showToast({
            });
          };
		  
		  if (zona1_num == 2) {
			normal_step_current_text_img_1.setProperty(hmUI.prop.VISIBLE, false);
            normal_step_current_separator_img_1.setProperty(hmUI.prop.VISIBLE, false);
			normal_distance_text_text_img_1.setProperty(hmUI.prop.VISIBLE, false);
			normal_distance_text_separator_img_1.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_current_text_img_1.setProperty(hmUI.prop.VISIBLE, true);
			normal_calorie_current_separator_img_1.setProperty(hmUI.prop.VISIBLE, true);
			normal_heart_rate_text_text_img_1.setProperty(hmUI.prop.VISIBLE, false);
			normal_heart_rate_text_separator_img_1.setProperty(hmUI.prop.VISIBLE, false);
			normal_battery_text_text_img_1.setProperty(hmUI.prop.VISIBLE, false);
			normal_battery_text_separator_img_1.setProperty(hmUI.prop.VISIBLE, false);
		    hmUI.showToast({
            });
          };
		  
		  if (zona1_num == 3) {
			normal_step_current_text_img_1.setProperty(hmUI.prop.VISIBLE, false);
            normal_step_current_separator_img_1.setProperty(hmUI.prop.VISIBLE, false);
			normal_distance_text_text_img_1.setProperty(hmUI.prop.VISIBLE, false);
			normal_distance_text_separator_img_1.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_current_text_img_1.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_current_separator_img_1.setProperty(hmUI.prop.VISIBLE, false);
			normal_heart_rate_text_text_img_1.setProperty(hmUI.prop.VISIBLE, true);
			normal_heart_rate_text_separator_img_1.setProperty(hmUI.prop.VISIBLE, true);
			normal_battery_text_text_img_1.setProperty(hmUI.prop.VISIBLE, false);
			normal_battery_text_separator_img_1.setProperty(hmUI.prop.VISIBLE, false);
		    hmUI.showToast({
            });
          };
		  
		  if (zona1_num == 4) {
			normal_step_current_text_img_1.setProperty(hmUI.prop.VISIBLE, false);
            normal_step_current_separator_img_1.setProperty(hmUI.prop.VISIBLE, false);
			normal_distance_text_text_img_1.setProperty(hmUI.prop.VISIBLE, false);
			normal_distance_text_separator_img_1.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_current_text_img_1.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_current_separator_img_1.setProperty(hmUI.prop.VISIBLE, false);
			normal_heart_rate_text_text_img_1.setProperty(hmUI.prop.VISIBLE, false);
			normal_heart_rate_text_separator_img_1.setProperty(hmUI.prop.VISIBLE, false);
			normal_battery_text_text_img_1.setProperty(hmUI.prop.VISIBLE, true);
			normal_battery_text_separator_img_1.setProperty(hmUI.prop.VISIBLE, true);
		    hmUI.showToast({
            });
          };
        }
		
		let btn_zona2 = ''
        let zona2_num = 0
        let zona2_all = 4
		
		function click_zona2() {
		  zona2_num = (zona2_num + 1) % (zona2_all + 1);
          if (zona2_num == 0) {		
		    normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
            normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_battery_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		    hmUI.showToast({
            });
          };
		  
		 if (zona2_num == 1) {
			normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_battery_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		    hmUI.showToast({
            });
          };
		  
		  if (zona2_num == 2) {
			normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_battery_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		    hmUI.showToast({
            });
          };
		  
		  if (zona2_num == 3) {
			normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_battery_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		    hmUI.showToast({
            });
          };
		  
		  if (zona2_num == 4) {
			normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_battery_text_separator_img.setProperty(hmUI.prop.VISIBLE, true);
		    hmUI.showToast({
            });
          };
        }
		
		const curTime = hmSensor.createSensor(hmSensor.id.TIME);
		const weather = hmSensor.createSensor(hmSensor.id.WEATHER);
		let weatherData = weather.getForecastWeather();
		let forecastData = weatherData.forecastData;
		let sunData = weatherData.tideData;
		let today = '';
		let sunriseMins = '';
		let sunsetMins = '';
		let sunriseMins_def = 8 * 60;			
		let sunsetMins_def = 20 * 60;

		let curMins = '';
		
		let isDayBg = true;
		
		function autoToggleBg() {

			weatherData = weather.getForecastWeather();
			sunData = weatherData.tideData;
			if (sunData.count > 0){
				today = sunData.data[0];
				sunriseMins = today.sunrise.hour * 60 + today.sunrise.minute;
				sunsetMins = today.sunset.hour * 60 + today.sunset.minute;
			} else {
				sunriseMins = sunriseMins_def;
				sunsetMins = sunsetMins_def;
			}

			curMins = curTime.hour * 60 + curTime.minute;
			let isDayNow = (curMins >= sunriseMins) && (curMins < sunsetMins);
			
			if(isDayNow){
				if(!isDayBg){
					icon_bg.setProperty(hmUI.prop.SRC, "day.png");
					isDayBg = true;
				}
			} else {
				if(isDayBg){
					icon_bg.setProperty(hmUI.prop.SRC, "night.png");
					isDayBg = false;
				}
			}
		}


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 99,
              y: 17,
              src: 'bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 109,
              y: 64,
              src: 'alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 203,
              y: 152,
              font_array: ["num_0.png","num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png"],
              padding: false,
              h_space: 0,
              dot_image: 'dots.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.MOON_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'moon10.png',
              center_x: 240,
              center_y: 240,
              x: 41,
              y: 229,
              start_angle: 294,
              end_angle: 428,
              invalid_visible: false,
              type: hmUI.data_type.MOON_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_frame_animation_1 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
              x: -1,
              y: 103,
              anim_path: "animation",
              anim_ext: "png",
              anim_prefix: "test_anim",
              anim_fps: 15,
              anim_size: 21,
              repeat_count: 0,
              anim_repeat: true,
              anim_status:hmUI.anim_status.START,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'first_anim_kvsha_20.png',
              center_x: 240,
              center_y: 499,
              x: 25,
              y: 206,
              start_angle: -60,
              end_angle: 60,
              invalid_visible: false,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 203,
              y: 307,
              font_array: ["num_0.png","num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png"],
              padding: false,
              h_space: 0,
              dot_image: 'dots.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            icon_bg = hmUI.createWidget(hmUI.widget.IMG, {
              x: 170,
              y: 170,
			  src: 'day.png',
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});
			
			autoToggleBg();

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 350,
              y: 218,
              font_array: ["A100_006.png","A100_007.png","A100_008.png","A100_009.png","A100_010.png","A100_011.png","A100_012.png","A100_013.png","A100_014.png","A100_015.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'A100_016.png',
              unit_tc: 'A100_016.png',
              unit_en: 'A100_016.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 348,
              y: 247,
              src: 'power.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			normal_battery_text_text_img_1 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 28,
              y: 218,
              font_array: ["A100_006.png","A100_007.png","A100_008.png","A100_009.png","A100_010.png","A100_011.png","A100_012.png","A100_013.png","A100_014.png","A100_015.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'A100_016.png',
              unit_tc: 'A100_016.png',
              unit_en: 'A100_016.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_separator_img_1 = hmUI.createWidget(hmUI.widget.IMG, {
              x: 28,
              y: 247,
              src: 'power.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 375,
              y: 218,
              font_array: ["A100_006.png","A100_007.png","A100_008.png","A100_009.png","A100_010.png","A100_011.png","A100_012.png","A100_013.png","A100_014.png","A100_015.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 352,
              y: 247,
              src: 'bpm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			normal_heart_rate_text_text_img_1 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 28,
              y: 218,
              font_array: ["A100_006.png","A100_007.png","A100_008.png","A100_009.png","A100_010.png","A100_011.png","A100_012.png","A100_013.png","A100_014.png","A100_015.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_separator_img_1 = hmUI.createWidget(hmUI.widget.IMG, {
              x: 22,
              y: 247,
              src: 'bpm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 356,
              y: 218,
              font_array: ["A100_006.png","A100_007.png","A100_008.png","A100_009.png","A100_010.png","A100_011.png","A100_012.png","A100_013.png","A100_014.png","A100_015.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 376,
              y: 247,
              src: 'kcal.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			normal_calorie_current_text_img_1 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 28,
              y: 218,
              font_array: ["A100_006.png","A100_007.png","A100_008.png","A100_009.png","A100_010.png","A100_011.png","A100_012.png","A100_013.png","A100_014.png","A100_015.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_separator_img_1 = hmUI.createWidget(hmUI.widget.IMG, {
              x: 29,
              y: 247,
              src: 'kcal.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 353,
              y: 218,
              font_array: ["A100_006.png","A100_007.png","A100_008.png","A100_009.png","A100_010.png","A100_011.png","A100_012.png","A100_013.png","A100_014.png","A100_015.png"],
              padding: false,
              h_space: 0,
              dot_image: 'dy.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 384,
              y: 247,
              src: 'dist.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			normal_distance_text_text_img_1 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 28,
              y: 218,
              font_array: ["A100_006.png","A100_007.png","A100_008.png","A100_009.png","A100_010.png","A100_011.png","A100_012.png","A100_013.png","A100_014.png","A100_015.png"],
              padding: false,
              h_space: 0,
              dot_image: 'dy.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_separator_img_1 = hmUI.createWidget(hmUI.widget.IMG, {
              x: 25,
              y: 247,
              src: 'dist.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 340,
              y: 218,
              font_array: ["A100_006.png","A100_007.png","A100_008.png","A100_009.png","A100_010.png","A100_011.png","A100_012.png","A100_013.png","A100_014.png","A100_015.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 384,
              y: 247,
              src: 'step.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			normal_step_current_text_img_1 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 28,
              y: 218,
              font_array: ["A100_006.png","A100_007.png","A100_008.png","A100_009.png","A100_010.png","A100_011.png","A100_012.png","A100_013.png","A100_014.png","A100_015.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img_1 = hmUI.createWidget(hmUI.widget.IMG, {
              x: 29,
              y: 247,
              src: 'step.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 63,
              y: 332,
              week_en: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              week_tc: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              week_sc: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 247,
              month_startY: 110,
              month_sc_array: ["43.png","44.png","45.png","46.png","47.png","48.png","49.png","50.png","51.png","52.png"],
              month_tc_array: ["43.png","44.png","45.png","46.png","47.png","48.png","49.png","50.png","51.png","52.png"],
              month_en_array: ["43.png","44.png","45.png","46.png","47.png","48.png","49.png","50.png","51.png","52.png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 187,
              day_startY: 110,
              day_sc_array: ["43.png","44.png","45.png","46.png","47.png","48.png","49.png","50.png","51.png","52.png"],
              day_tc_array: ["43.png","44.png","45.png","46.png","47.png","48.png","49.png","50.png","51.png","52.png"],
              day_en_array: ["43.png","44.png","45.png","46.png","47.png","48.png","49.png","50.png","51.png","52.png"],
              day_zero: 1,
              day_space: 0,
              day_unit_sc: 'dot.png',
              day_unit_tc: 'dot.png',
              day_unit_en: 'dot.png',
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 152,
              hour_startY: 35,
              hour_array: ["informative_analog_digital_time_num_0.png","informative_analog_digital_time_num_1.png","informative_analog_digital_time_num_2.png","informative_analog_digital_time_num_3.png","informative_analog_digital_time_num_4.png","informative_analog_digital_time_num_5.png","informative_analog_digital_time_num_6.png","informative_analog_digital_time_num_7.png","informative_analog_digital_time_num_8.png","informative_analog_digital_time_num_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_unit_sc: 'colon.png',
              hour_unit_tc: 'colon.png',
              hour_unit_en: 'colon.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 256,
              minute_startY: 35,
              minute_array: ["informative_analog_digital_time_num_0.png","informative_analog_digital_time_num_1.png","informative_analog_digital_time_num_2.png","informative_analog_digital_time_num_3.png","informative_analog_digital_time_num_4.png","informative_analog_digital_time_num_5.png","informative_analog_digital_time_num_6.png","informative_analog_digital_time_num_7.png","informative_analog_digital_time_num_8.png","informative_analog_digital_time_num_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			btn_zona1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 20,
              y: 215,
              text: '',
              w: 100,
              h: 70,
              normal_src: 'Empty.png',
              press_src: 'Empty.png',
              click_func: () => {
				click_zona1();
                click_Vibrate();
             },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btn_zona1.setProperty(hmUI.prop.VISIBLE, true);
			normal_distance_text_text_img_1.setProperty(hmUI.prop.VISIBLE, false);
			normal_distance_text_separator_img_1.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_current_text_img_1.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_current_separator_img_1.setProperty(hmUI.prop.VISIBLE, false);
			normal_heart_rate_text_text_img_1.setProperty(hmUI.prop.VISIBLE, false);
			normal_heart_rate_text_separator_img_1.setProperty(hmUI.prop.VISIBLE, false);
			normal_battery_text_text_img_1.setProperty(hmUI.prop.VISIBLE, false);
			normal_battery_text_separator_img_1.setProperty(hmUI.prop.VISIBLE, false);
			
			btn_zona2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 358,
              y: 215,
              text: '',
              w: 100,
              h: 70,
              normal_src: 'Empty.png',
              press_src: 'Empty.png',
              click_func: () => {
				click_zona2();
                click_Vibrate();
             },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btn_zona2.setProperty(hmUI.prop.VISIBLE, true);
			normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_battery_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			
			hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 190,
              y: 365, 
              text: '',
              w: 100, 
              h: 100, 
              normal_src: 'Empty.png',
              press_src: 'Empty.png',
               click_func: () => {
              hmApp.startApp({ url: 'ScheduleCalScreen', native: true });
              },
               longpress_func: () => {
              hmApp.startApp({ url: 'todoListScreen', native: true });
              },
                show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			normal_sun_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 202,
              y: 295,
              w: 75,
              h: 50,
              src: 'Empty.png',
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			normal_moon_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 202,
              y: 140,
              w: 75,
              h: 50,
              src: 'Empty.png',
              type: hmUI.data_type.MOON_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                autoToggleBg();
				normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);

              }),
              pause_call: (function () {
                console.log('pause_call()');
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
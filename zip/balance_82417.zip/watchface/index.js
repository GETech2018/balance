﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_pai_icon_img = ''
        let normal_analog_clock_pro_hour_pointer_img = ''
        let normal_battery_icon_img = ''
        let normal_battery_text_text_img = ''
        let normal_distance_icon_img = ''
        let normal_distance_text_text_img = ''
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_calorie_icon_img = ''
        let normal_calorie_current_text_img = ''
        let normal_step_icon_img = ''
        let normal_step_current_text_img = ''
        let normal_step_jumpable_img_click = ''
        let timeSensor = ''
		
		let btn_zona1 = ''
        let zona1_num = 0
        let zona1_all = 4
		
		function click_zona1() {
		  zona1_num = (zona1_num + 1) % (zona1_all + 1);
          if (zona1_num == 0) {		
		    normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, true);
            normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_distance_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_battery_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
		    hmUI.showToast({
            });
          };
		  
		 if (zona1_num == 1) {
			normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_distance_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_battery_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
		    hmUI.showToast({
            });
          };
		  
		  if (zona1_num == 2) {
			normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_distance_icon_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_battery_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
		    hmUI.showToast({
            });
          };
		  
		  if (zona1_num == 3) {
			normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_distance_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_battery_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
		    hmUI.showToast({
            });
          };
		  
		  if (zona1_num == 4) {
			normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_distance_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_battery_icon_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
		    hmUI.showToast({
            });
          };
        }


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'mask.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'min.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 240,
              minute_posY: 240,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'secon.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 240,
              second_posY: 240,
              second_cover_path: 'sec.png',
              second_cover_x: 0,
              second_cover_y: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'bg1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'pwr.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 207,
              y: 223,
              font_array: ["wfs_informative_analog_ic_date_00_4b0fe879_91a9_4aa4_b4bc_eb2c040eeb4a.png","wfs_informative_analog_ic_date_01_3f0ce218_3ae9_4ced_ad17_0584fa7893e5.png","wfs_informative_analog_ic_date_02_a5ddad1a_8a1c_4d8a_84bc_3e30282a30b9.png","wfs_informative_analog_ic_date_03_e13799f1_1ec3_46fa_b7b1_ceda34e93e6f.png","wfs_informative_analog_ic_date_04_59266dd1_5cb4_4136_b83c_5742157561d0.png","wfs_informative_analog_ic_date_05_a5e26e9b_eb33_4149_a2c8_b67461f6c292.png","wfs_informative_analog_ic_date_06_27ba7c90_c71e_4743_9c55_2ce532fc5b82.png","wfs_informative_analog_ic_date_07_1fcd7ad6_1a33_4c98_8c38_cf0ded76e596.png","wfs_informative_analog_ic_date_08_093f1819_9124_4df2_a763_3ced8b062e78.png","wfs_informative_analog_ic_date_09_058756ad_5cd1_4560_bbdc_bb424cb394fd.png"],
              padding: false,
              h_space: 5,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'dist.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 186,
              y: 223,
              font_array: ["wfs_informative_analog_ic_date_00_4b0fe879_91a9_4aa4_b4bc_eb2c040eeb4a.png","wfs_informative_analog_ic_date_01_3f0ce218_3ae9_4ced_ad17_0584fa7893e5.png","wfs_informative_analog_ic_date_02_a5ddad1a_8a1c_4d8a_84bc_3e30282a30b9.png","wfs_informative_analog_ic_date_03_e13799f1_1ec3_46fa_b7b1_ceda34e93e6f.png","wfs_informative_analog_ic_date_04_59266dd1_5cb4_4136_b83c_5742157561d0.png","wfs_informative_analog_ic_date_05_a5e26e9b_eb33_4149_a2c8_b67461f6c292.png","wfs_informative_analog_ic_date_06_27ba7c90_c71e_4743_9c55_2ce532fc5b82.png","wfs_informative_analog_ic_date_07_1fcd7ad6_1a33_4c98_8c38_cf0ded76e596.png","wfs_informative_analog_ic_date_08_093f1819_9124_4df2_a763_3ced8b062e78.png","wfs_informative_analog_ic_date_09_058756ad_5cd1_4560_bbdc_bb424cb394fd.png"],
              padding: false,
              h_space: 5,
              dot_image: 'dot.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'bpm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 204,
              y: 223,
              font_array: ["wfs_informative_analog_ic_date_00_4b0fe879_91a9_4aa4_b4bc_eb2c040eeb4a.png","wfs_informative_analog_ic_date_01_3f0ce218_3ae9_4ced_ad17_0584fa7893e5.png","wfs_informative_analog_ic_date_02_a5ddad1a_8a1c_4d8a_84bc_3e30282a30b9.png","wfs_informative_analog_ic_date_03_e13799f1_1ec3_46fa_b7b1_ceda34e93e6f.png","wfs_informative_analog_ic_date_04_59266dd1_5cb4_4136_b83c_5742157561d0.png","wfs_informative_analog_ic_date_05_a5e26e9b_eb33_4149_a2c8_b67461f6c292.png","wfs_informative_analog_ic_date_06_27ba7c90_c71e_4743_9c55_2ce532fc5b82.png","wfs_informative_analog_ic_date_07_1fcd7ad6_1a33_4c98_8c38_cf0ded76e596.png","wfs_informative_analog_ic_date_08_093f1819_9124_4df2_a763_3ced8b062e78.png","wfs_informative_analog_ic_date_09_058756ad_5cd1_4560_bbdc_bb424cb394fd.png"],
              padding: false,
              h_space: 5,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'cal.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 195,
              y: 223,
              font_array: ["wfs_informative_analog_ic_date_00_4b0fe879_91a9_4aa4_b4bc_eb2c040eeb4a.png","wfs_informative_analog_ic_date_01_3f0ce218_3ae9_4ced_ad17_0584fa7893e5.png","wfs_informative_analog_ic_date_02_a5ddad1a_8a1c_4d8a_84bc_3e30282a30b9.png","wfs_informative_analog_ic_date_03_e13799f1_1ec3_46fa_b7b1_ceda34e93e6f.png","wfs_informative_analog_ic_date_04_59266dd1_5cb4_4136_b83c_5742157561d0.png","wfs_informative_analog_ic_date_05_a5e26e9b_eb33_4149_a2c8_b67461f6c292.png","wfs_informative_analog_ic_date_06_27ba7c90_c71e_4743_9c55_2ce532fc5b82.png","wfs_informative_analog_ic_date_07_1fcd7ad6_1a33_4c98_8c38_cf0ded76e596.png","wfs_informative_analog_ic_date_08_093f1819_9124_4df2_a763_3ced8b062e78.png","wfs_informative_analog_ic_date_09_058756ad_5cd1_4560_bbdc_bb424cb394fd.png"],
              padding: false,
              h_space: 5,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'step.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 178,
              y: 223,
              font_array: ["wfs_informative_analog_ic_date_00_4b0fe879_91a9_4aa4_b4bc_eb2c040eeb4a.png","wfs_informative_analog_ic_date_01_3f0ce218_3ae9_4ced_ad17_0584fa7893e5.png","wfs_informative_analog_ic_date_02_a5ddad1a_8a1c_4d8a_84bc_3e30282a30b9.png","wfs_informative_analog_ic_date_03_e13799f1_1ec3_46fa_b7b1_ceda34e93e6f.png","wfs_informative_analog_ic_date_04_59266dd1_5cb4_4136_b83c_5742157561d0.png","wfs_informative_analog_ic_date_05_a5e26e9b_eb33_4149_a2c8_b67461f6c292.png","wfs_informative_analog_ic_date_06_27ba7c90_c71e_4743_9c55_2ce532fc5b82.png","wfs_informative_analog_ic_date_07_1fcd7ad6_1a33_4c98_8c38_cf0ded76e596.png","wfs_informative_analog_ic_date_08_093f1819_9124_4df2_a763_3ced8b062e78.png","wfs_informative_analog_ic_date_09_058756ad_5cd1_4560_bbdc_bb424cb394fd.png"],
              padding: false,
              h_space: 5,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			const deviceInfo = hmSetting.getDeviceInfo();
            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.MINUTEEND, function() {
              let updateHour = timeSensor.minute == 0;

              time_update(updateHour, true);
            });

            // normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'hr1.png',
              // center_x: 240,
              // center_y: 240,
              // x: 240,
              // y: 240,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.hour,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 240,
              pos_y: 240 - 240,
              center_x: 240,
              center_y: 240,
              src: 'hr1.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.Shortcuts');

            btn_zona1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 194,
              y: 231,
              text: '',
              w: 100,
              h: 100,
              normal_src: 'Empty.png',
              press_src: 'Empty.png',
              click_func: () => {
				click_zona1();
             },
			  longpress_func: () => {
             hmApp.startApp({ url: "activityAppScreen", native: true });
             },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btn_zona1.setProperty(hmUI.prop.VISIBLE, true);
			normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_distance_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_battery_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, false);

            let screenType = hmSetting.getScreenType();
            //start of ignored block
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              if (updateHour) {
                let normal_hour = hour;
                let normal_fullAngle_hour = 360;
                if (normal_hour > 11) normal_hour -= 12;
                let normal_angle_hour = 0 + normal_fullAngle_hour*normal_hour/12 + (normal_fullAngle_hour/12)*minute/60;
                if (normal_analog_clock_pro_hour_pointer_img) normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_hour);
              };

            };

            //end of ignored block
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                time_update(true, true);
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
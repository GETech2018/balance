﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_step_TextCircle = new Array(5);
        let normal_step_TextCircle_ASCIIARRAY = new Array(10);
        let normal_step_TextCircle_img_width = 60;
        let normal_step_TextCircle_img_height = 60;
        let normal_image_img = ''
        let normal_month_name_font = ''
        let normal_Month_Array = ['ЯНВ', 'ФЕВ', 'МРТ', 'АПР', 'МАЙ', 'ИЮН', 'ИЮЛ', 'АВГ', 'СЕН', 'ОКТ', 'НОЯ', 'ДЕК', ];
        let normal_dow_text_font = ''
        let normal_DOW_Array = ['ПОН', 'ВТР', 'СРД', 'ЧТВ', 'ПТН', 'СБТ', 'ВСК'];
        let normal_date_img_date_day = ''
        let normal_hour_TextCircle = new Array(2);
        let normal_hour_TextCircle_ASCIIARRAY = new Array(10);
        let normal_hour_TextCircle_img_width = 60;
        let normal_hour_TextCircle_img_height = 60;
        let normal_hour_TextCircle_unit = null;
        let normal_hour_TextCircle_unit_width = 40;
        let normal_timerTextUpdate = undefined;
        let normal_minute_TextCircle = new Array(2);
        let normal_minute_TextCircle_ASCIIARRAY = new Array(10);
        let normal_minute_TextCircle_img_width = 60;
        let normal_minute_TextCircle_img_height = 60;
        let normal_analog_clock_pro_minute_pointer_img = ''
        let normal_timerUpdateSec = undefined;
        let normal_analog_clock_pro_hour_pointer_img = ''
        let normal_analog_clock_pro_second_pointer_img = ''
        let normal_timerUpdateSecSmooth = undefined;
        let lastTime = 0;
        let normal_battery_current_text_font = ''
        let idle_hour_TextCircle = new Array(2);
        let idle_hour_TextCircle_ASCIIARRAY = new Array(10);
        let idle_hour_TextCircle_img_width = 60;
        let idle_hour_TextCircle_img_height = 60;
        let idle_hour_TextCircle_unit = null;
        let idle_hour_TextCircle_unit_width = 40;
        let idle_timerTextUpdate = undefined;
        let idle_minute_TextCircle = new Array(2);
        let idle_minute_TextCircle_ASCIIARRAY = new Array(10);
        let idle_minute_TextCircle_img_width = 60;
        let idle_minute_TextCircle_img_height = 60;
        let idle_analog_clock_pro_minute_pointer_img = ''
        let idle_analog_clock_pro_hour_pointer_img = ''
        let image_top_img = ''
        let normal_step_jumpable_img_click = ''
        let normal_battery_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_sleep_jumpable_img_click = ''
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: '2_480.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 100,
              y: -2,
              src: '6.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 435,
              y: 188,
              src: 'stat_H_onpng.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_step_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 239,
              // circle_center_Y: 239,
              // font_array: ["120.png","121.png","122.png","123.png","124.png","125.png","126.png","127.png","128.png","129.png"],
              // radius: 173,
              // angle: 42,
              // char_space_angle: -9,
              // zero: false,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_step_TextCircle_ASCIIARRAY[0] = '120.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[1] = '121.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[2] = '122.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[3] = '123.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[4] = '124.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[5] = '125.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[6] = '126.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[7] = '127.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[8] = '128.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[9] = '129.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              normal_step_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 239,
                center_y: 239,
                pos_x: 239 - normal_step_TextCircle_img_width / 2,
                pos_y: 239 - 233,
                src: '120.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_step_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });
            
            function toDegree (radian) {
              return radian * (180 / Math.PI);
            };

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 388,
              y: 218,
              src: '3_3.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function() {
              time_update(true);
            });

            normal_month_name_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 299,
              y: 231,
              w: 81,
              h: 45,
              text_size: 24,
              char_space: 1,
              line_space: 0,
              color: 0xFFFF8C00,
              align_h: hmUI.align.RIGHT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              // unit_string: ЯНВ, ФЕВ, МРТ, АПР, МАЙ, ИЮН, ИЮЛ, АВГ, СЕН, ОКТ, НОЯ, ДЕК,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_dow_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 309,
              y: 206,
              w: 72,
              h: 36,
              text_size: 24,
              char_space: 2,
              line_space: 0,
              color: 0xFFC0C0C0,
              align_h: hmUI.align.RIGHT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              // unit_string: ПОН, ВТР, СРД, ЧТВ, ПТН, СБТ, ВСК,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 398,
              day_startY: 224,
              day_sc_array: ["57.png","58.png","59.png","60.png","61.png","62.png","63.png","64.png","65.png","66.png"],
              day_tc_array: ["57.png","58.png","59.png","60.png","61.png","62.png","63.png","64.png","65.png","66.png"],
              day_en_array: ["57.png","58.png","59.png","60.png","61.png","62.png","63.png","64.png","65.png","66.png"],
              day_zero: 0,
              day_space: 2,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_hour_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 239,
              // circle_center_Y: 239,
              // font_array: ["120.png","121.png","122.png","123.png","124.png","125.png","126.png","127.png","128.png","129.png"],
              // radius: -235,
              // angle: 42,
              // char_space_angle: 4,
              // unit: 'd_b2.png',
              // zero: true,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: RIGHT,
              // type: hmUI.data_type.HOUR,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_hour_TextCircle_ASCIIARRAY[0] = '120.png';  // set of images with numbers
            normal_hour_TextCircle_ASCIIARRAY[1] = '121.png';  // set of images with numbers
            normal_hour_TextCircle_ASCIIARRAY[2] = '122.png';  // set of images with numbers
            normal_hour_TextCircle_ASCIIARRAY[3] = '123.png';  // set of images with numbers
            normal_hour_TextCircle_ASCIIARRAY[4] = '124.png';  // set of images with numbers
            normal_hour_TextCircle_ASCIIARRAY[5] = '125.png';  // set of images with numbers
            normal_hour_TextCircle_ASCIIARRAY[6] = '126.png';  // set of images with numbers
            normal_hour_TextCircle_ASCIIARRAY[7] = '127.png';  // set of images with numbers
            normal_hour_TextCircle_ASCIIARRAY[8] = '128.png';  // set of images with numbers
            normal_hour_TextCircle_ASCIIARRAY[9] = '129.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              normal_hour_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 239,
                center_y: 239,
                pos_x: 239 - normal_hour_TextCircle_img_width / 2,
                pos_y: 239 + 175,
                src: '120.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_hour_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_hour_TextCircle_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              center_x: 239,
              center_y: 239,
              pos_x: 239 - normal_hour_TextCircle_unit_width / 2,
              pos_y: 239 + 175,
              src: 'd_b2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_hour_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block

            let screenType = hmSetting.getScreenType();
            // normal_minute_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 239,
              // circle_center_Y: 239,
              // font_array: ["130.png","131.png","132.png","133.png","134.png","135.png","136.png","137.png","138.png","139.png"],
              // radius: -235,
              // angle: 33,
              // char_space_angle: 4,
              // zero: true,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: LEFT,
              // type: hmUI.data_type.MINUTE,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_minute_TextCircle_ASCIIARRAY[0] = '130.png';  // set of images with numbers
            normal_minute_TextCircle_ASCIIARRAY[1] = '131.png';  // set of images with numbers
            normal_minute_TextCircle_ASCIIARRAY[2] = '132.png';  // set of images with numbers
            normal_minute_TextCircle_ASCIIARRAY[3] = '133.png';  // set of images with numbers
            normal_minute_TextCircle_ASCIIARRAY[4] = '134.png';  // set of images with numbers
            normal_minute_TextCircle_ASCIIARRAY[5] = '135.png';  // set of images with numbers
            normal_minute_TextCircle_ASCIIARRAY[6] = '136.png';  // set of images with numbers
            normal_minute_TextCircle_ASCIIARRAY[7] = '137.png';  // set of images with numbers
            normal_minute_TextCircle_ASCIIARRAY[8] = '138.png';  // set of images with numbers
            normal_minute_TextCircle_ASCIIARRAY[9] = '139.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              normal_minute_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 239,
                center_y: 239,
                pos_x: 239 - normal_minute_TextCircle_img_width / 2,
                pos_y: 239 + 175,
                src: '130.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_minute_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            const deviceInfo = hmSetting.getDeviceInfo();
            // normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: '115.png',
              // center_x: 239,
              // center_y: 239,
              // x: 38,
              // y: 219,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.minute,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 239 - 38,
              pos_y: 239 - 219,
              center_x: 239,
              center_y: 239,
              src: '115.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            timeSensor.addEventListener(timeSensor.event.MINUTEEND, function() {
              let updateHour = timeSensor.minute == 0;

              time_update(updateHour, true);
            });

            // normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: '116.png',
              // center_x: 241,
              // center_y: 240,
              // x: 78,
              // y: 149,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.hour,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 241 - 78,
              pos_y: 240 - 149,
              center_x: 241,
              center_y: 240,
              src: '116.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: '118.png',
              // center_x: 239,
              // center_y: 239,
              // x: 5,
              // y: 71,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 239 - 5,
              pos_y: 239 - 71,
              center_x: 239,
              center_y: 239,
              src: '118.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            function startSecAnim(sec, animDuration) {
              const secAnim = {
                anim_steps: [{
                  anim_rate: 'linear',
                  anim_duration: animDuration,
                  anim_from: sec,
                  anim_to: sec + (360*(animDuration*6/1000))/360,
                  anim_key: 'angle',
                }],
                anim_fps: 12,
                anim_auto_start: 1,
                anim_repeat: 0,
                anim_auto_destroy: 1,
              }
              normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANIM, secAnim);
            }
            // normal_analog_clock_pro_smooth_second = hmUI.createWidget(hmUI.widget.SMOOTH_SECOND, {
              // type: 4,
              // fps: 12,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 202,
              y: 211,
              w: 81,
              h: 51,
              text_size: 34,
              char_space: 0,
              line_space: 0,
              color: 0xFF000000,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');

            // idle_hour_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 239,
              // circle_center_Y: 239,
              // font_array: ["120.png","121.png","122.png","123.png","124.png","125.png","126.png","127.png","128.png","129.png"],
              // radius: -235,
              // angle: 42,
              // char_space_angle: 4,
              // unit: 'd_b2.png',
              // zero: true,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: RIGHT,
              // type: hmUI.data_type.HOUR,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_hour_TextCircle_ASCIIARRAY[0] = '120.png';  // set of images with numbers
            idle_hour_TextCircle_ASCIIARRAY[1] = '121.png';  // set of images with numbers
            idle_hour_TextCircle_ASCIIARRAY[2] = '122.png';  // set of images with numbers
            idle_hour_TextCircle_ASCIIARRAY[3] = '123.png';  // set of images with numbers
            idle_hour_TextCircle_ASCIIARRAY[4] = '124.png';  // set of images with numbers
            idle_hour_TextCircle_ASCIIARRAY[5] = '125.png';  // set of images with numbers
            idle_hour_TextCircle_ASCIIARRAY[6] = '126.png';  // set of images with numbers
            idle_hour_TextCircle_ASCIIARRAY[7] = '127.png';  // set of images with numbers
            idle_hour_TextCircle_ASCIIARRAY[8] = '128.png';  // set of images with numbers
            idle_hour_TextCircle_ASCIIARRAY[9] = '129.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              idle_hour_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 239,
                center_y: 239,
                pos_x: 239 - idle_hour_TextCircle_img_width / 2,
                pos_y: 239 + 175,
                src: '120.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_hour_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            idle_hour_TextCircle_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              center_x: 239,
              center_y: 239,
              pos_x: 239 - idle_hour_TextCircle_unit_width / 2,
              pos_y: 239 + 175,
              src: 'd_b2.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            idle_hour_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block

            // idle_minute_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 239,
              // circle_center_Y: 239,
              // font_array: ["130.png","131.png","132.png","133.png","134.png","135.png","136.png","137.png","138.png","139.png"],
              // radius: -235,
              // angle: 33,
              // char_space_angle: 4,
              // zero: true,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: LEFT,
              // type: hmUI.data_type.MINUTE,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_minute_TextCircle_ASCIIARRAY[0] = '130.png';  // set of images with numbers
            idle_minute_TextCircle_ASCIIARRAY[1] = '131.png';  // set of images with numbers
            idle_minute_TextCircle_ASCIIARRAY[2] = '132.png';  // set of images with numbers
            idle_minute_TextCircle_ASCIIARRAY[3] = '133.png';  // set of images with numbers
            idle_minute_TextCircle_ASCIIARRAY[4] = '134.png';  // set of images with numbers
            idle_minute_TextCircle_ASCIIARRAY[5] = '135.png';  // set of images with numbers
            idle_minute_TextCircle_ASCIIARRAY[6] = '136.png';  // set of images with numbers
            idle_minute_TextCircle_ASCIIARRAY[7] = '137.png';  // set of images with numbers
            idle_minute_TextCircle_ASCIIARRAY[8] = '138.png';  // set of images with numbers
            idle_minute_TextCircle_ASCIIARRAY[9] = '139.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              idle_minute_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 239,
                center_y: 239,
                pos_x: 239 - idle_minute_TextCircle_img_width / 2,
                pos_y: 239 + 175,
                src: '130.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_minute_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            // idle_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: '115.png',
              // center_x: 239,
              // center_y: 239,
              // x: 38,
              // y: 219,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.minute,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });


            idle_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 239 - 38,
              pos_y: 239 - 219,
              center_x: 239,
              center_y: 239,
              src: '115.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: '116.png',
              // center_x: 241,
              // center_y: 240,
              // x: 78,
              // y: 149,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.hour,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });


            idle_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 241 - 78,
              pos_y: 240 - 149,
              center_x: 241,
              center_y: 240,
              src: '116.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 9,
              // conneсnt_vibrate_type: 0,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              console.log('checkConnection()');
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  vibro(9);
                }
                if(status) {
                  vibro(0);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              if (scene != 1) timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function

            image_top_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: '119_480.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 306,
              y: 66,
              w: 80,
              h: 80,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 203,
              y: 203,
              w: 70,
              h: 70,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 20,
              y: 200,
              w: 70,
              h: 70,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 111,
              y: 369,
              w: 70,
              h: 70,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 395,
              y: 184,
              w: 70,
              h: 70,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sleep_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 212,
              y: 9,
              w: 60,
              h: 60,
              type: hmUI.data_type.SLEEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            //start of ignored block
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              console.log('month font');
              if (updateHour) {
                let normal_Month_Str = normal_Month_Array[timeSensor.month-1];
                normal_month_name_font.setProperty(hmUI.prop.TEXT, normal_Month_Str );
              };

              console.log('day of week font');
              if (updateHour) {
                let normal_DOW_Str = normal_DOW_Array[timeSensor.week-1];
                normal_dow_text_font.setProperty(hmUI.prop.TEXT, normal_DOW_Str );
              };

                let normal_fullAngle_minute = 360;
                let normal_angle_minute = 0 + normal_fullAngle_minute*(minute + second/60)/60;
                if (normal_analog_clock_pro_minute_pointer_img) normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_minute);
              if (updateMinute) {
                let normal_hour = hour;
                let normal_fullAngle_hour = 360;
                if (normal_hour > 11) normal_hour -= 12;
                let normal_angle_hour = 0 + normal_fullAngle_hour*normal_hour/12 + (normal_fullAngle_hour/12)*minute/60;
                if (normal_analog_clock_pro_hour_pointer_img) normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_hour);
              };

              if (updateMinute) {
                let idle_fullAngle_minute = 360;
                let idle_angle_minute = 0 + idle_fullAngle_minute*minute/60;
                if (idle_analog_clock_pro_minute_pointer_img) idle_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.ANGLE, idle_angle_minute);
              };

              if (updateMinute) {
                let idle_hour = hour;
                let idle_fullAngle_hour = 360;
                if (idle_hour > 11) idle_hour -= 12;
                let idle_angle_hour = 0 + idle_fullAngle_hour*idle_hour/12 + (idle_fullAngle_hour/12)*minute/60;
                if (idle_analog_clock_pro_hour_pointer_img) idle_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.ANGLE, idle_angle_hour);
              };

            };

            //end of ignored block
            //start of ignored block
            function text_update() {
              console.log('text_update()');

              console.log('update text circle step_STEP');
              let valueStep = step.current;
              let normal_step_circle_string = parseInt(valueStep).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  normal_step_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = 42;
                if (valueStep != null && valueStep != undefined && isFinite(valueStep) && normal_step_circle_string.length > 0 && normal_step_circle_string.length <= 5) {  // display data if it was possible to get it
                  let normal_step_TextCircle_img_angle = 0;
                  let normal_step_TextCircle_dot_img_angle = 0;
                  normal_step_TextCircle_img_angle = toDegree(Math.atan2(normal_step_TextCircle_img_width/2, 173));
                  // alignment = CENTER_H
                  let normal_step_TextCircle_angleOffset = normal_step_TextCircle_img_angle * (normal_step_circle_string.length - 1);
                  normal_step_TextCircle_angleOffset = normal_step_TextCircle_angleOffset + -9 * (normal_step_circle_string.length - 1) / 2;
                  char_Angle -= normal_step_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_step_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += normal_step_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_step_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_step_TextCircle[index].setProperty(hmUI.prop.POS_X, 239 - normal_step_TextCircle_img_width / 2);
                      normal_step_TextCircle[index].setProperty(hmUI.prop.SRC, normal_step_TextCircle_ASCIIARRAY[charCode]);
                      normal_step_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_step_TextCircle_img_angle + -9;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text circle hour_TIME');
              let valueHour = timeSensor.format_hour;
              let normal_hour_circle_string = parseInt(valueHour).toString();
              normal_hour_circle_string = normal_hour_circle_string.padStart(2, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_hour_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_hour_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
                let char_Angle = 42;
                if (valueHour != null && valueHour != undefined && isFinite(valueHour) && normal_hour_circle_string.length > 0 && normal_hour_circle_string.length <= 2) {  // display data if it was possible to get it
                  let normal_hour_TextCircle_img_angle = 0;
                  let normal_hour_TextCircle_dot_img_angle = 0;
                  let normal_hour_TextCircle_unit_angle = 0;
                  normal_hour_TextCircle_img_angle = toDegree(Math.atan2(normal_hour_TextCircle_img_width/2, -235));
                  normal_hour_TextCircle_unit_angle = toDegree(Math.atan2(normal_hour_TextCircle_unit_width/2, -235));
                  // alignment = RIGHT
                  let normal_hour_TextCircle_angleOffset = normal_hour_TextCircle_img_angle * (normal_hour_circle_string.length - 1);
                  normal_hour_TextCircle_angleOffset = normal_hour_TextCircle_angleOffset + 4 * (normal_hour_circle_string.length - 1) / 2;
                  normal_hour_TextCircle_angleOffset = normal_hour_TextCircle_angleOffset + (normal_hour_TextCircle_img_angle + normal_hour_TextCircle_unit_angle + 4) / 2;
                  char_Angle -= 2 * normal_hour_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_hour_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += normal_hour_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_hour_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_hour_TextCircle[index].setProperty(hmUI.prop.POS_X, 239 - normal_hour_TextCircle_img_width / 2);
                      normal_hour_TextCircle[index].setProperty(hmUI.prop.SRC, normal_hour_TextCircle_ASCIIARRAY[charCode]);
                      normal_hour_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_hour_TextCircle_img_angle + 4;
                      index++;
                    };  // end if digit
                  };  // end char of string
                  char_Angle += normal_hour_TextCircle_unit_angle;
                  normal_hour_TextCircle_unit.setProperty(hmUI.prop.ANGLE, char_Angle);
                  normal_hour_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite

              };

              console.log('update text circle minute_TIME');
              let valueMinute = timeSensor.minute;
              let normal_minute_circle_string = parseInt(valueMinute).toString();
              normal_minute_circle_string = normal_minute_circle_string.padStart(2, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_minute_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = 33;
                if (valueMinute != null && valueMinute != undefined && isFinite(valueMinute) && normal_minute_circle_string.length > 0 && normal_minute_circle_string.length <= 2) {  // display data if it was possible to get it
                  let normal_minute_TextCircle_img_angle = 0;
                  let normal_minute_TextCircle_dot_img_angle = 0;
                  normal_minute_TextCircle_img_angle = toDegree(Math.atan2(normal_minute_TextCircle_img_width/2, -235));
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_minute_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += normal_minute_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_minute_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_minute_TextCircle[index].setProperty(hmUI.prop.POS_X, 239 - normal_minute_TextCircle_img_width / 2);
                      normal_minute_TextCircle[index].setProperty(hmUI.prop.SRC, normal_minute_TextCircle_ASCIIARRAY[charCode]);
                      normal_minute_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_minute_TextCircle_img_angle + 4;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text circle hour_TIME');
              let idle_hour_circle_string = parseInt(valueHour).toString();
              idle_hour_circle_string = idle_hour_circle_string.padStart(2, '0');

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  idle_hour_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                idle_hour_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
                let char_Angle = 42;
                if (valueHour != null && valueHour != undefined && isFinite(valueHour) && idle_hour_circle_string.length > 0 && idle_hour_circle_string.length <= 2) {  // display data if it was possible to get it
                  let idle_hour_TextCircle_img_angle = 0;
                  let idle_hour_TextCircle_dot_img_angle = 0;
                  let idle_hour_TextCircle_unit_angle = 0;
                  idle_hour_TextCircle_img_angle = toDegree(Math.atan2(idle_hour_TextCircle_img_width/2, -235));
                  idle_hour_TextCircle_unit_angle = toDegree(Math.atan2(idle_hour_TextCircle_unit_width/2, -235));
                  // alignment = RIGHT
                  let idle_hour_TextCircle_angleOffset = idle_hour_TextCircle_img_angle * (idle_hour_circle_string.length - 1);
                  idle_hour_TextCircle_angleOffset = idle_hour_TextCircle_angleOffset + 4 * (idle_hour_circle_string.length - 1) / 2;
                  idle_hour_TextCircle_angleOffset = idle_hour_TextCircle_angleOffset + (idle_hour_TextCircle_img_angle + idle_hour_TextCircle_unit_angle + 4) / 2;
                  char_Angle -= 2 * idle_hour_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of idle_hour_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += idle_hour_TextCircle_img_angle;
                      firstSymbol = false;
                      idle_hour_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      idle_hour_TextCircle[index].setProperty(hmUI.prop.POS_X, 239 - idle_hour_TextCircle_img_width / 2);
                      idle_hour_TextCircle[index].setProperty(hmUI.prop.SRC, idle_hour_TextCircle_ASCIIARRAY[charCode]);
                      idle_hour_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += idle_hour_TextCircle_img_angle + 4;
                      index++;
                    };  // end if digit
                  };  // end char of string
                  char_Angle += idle_hour_TextCircle_unit_angle;
                  idle_hour_TextCircle_unit.setProperty(hmUI.prop.ANGLE, char_Angle);
                  idle_hour_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite

              };

              console.log('update text circle minute_TIME');
              let idle_minute_circle_string = parseInt(valueMinute).toString();
              idle_minute_circle_string = idle_minute_circle_string.padStart(2, '0');

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  idle_minute_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = 33;
                if (valueMinute != null && valueMinute != undefined && isFinite(valueMinute) && idle_minute_circle_string.length > 0 && idle_minute_circle_string.length <= 2) {  // display data if it was possible to get it
                  let idle_minute_TextCircle_img_angle = 0;
                  let idle_minute_TextCircle_dot_img_angle = 0;
                  idle_minute_TextCircle_img_angle = toDegree(Math.atan2(idle_minute_TextCircle_img_width/2, -235));
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of idle_minute_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += idle_minute_TextCircle_img_angle;
                      firstSymbol = false;
                      idle_minute_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      idle_minute_TextCircle[index].setProperty(hmUI.prop.POS_X, 239 - idle_minute_TextCircle_img_width / 2);
                      idle_minute_TextCircle[index].setProperty(hmUI.prop.SRC, idle_minute_TextCircle_ASCIIARRAY[charCode]);
                      idle_minute_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += idle_minute_TextCircle_img_angle + 4;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

            };

            //end of ignored block
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                time_update(true, true);
                text_update();
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerTextUpdate) {
                    normal_timerTextUpdate = timer.createTimer(0, 1000, (function (option) {
                      text_update();
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSec) {
                    let animDelay = timeSensor.utc % 1000;
                    let animRepeat = 1000;
                    normal_timerUpdateSec = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, true);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                let secAngle = 0 + (360*6)*(timeSensor.second + ((timeSensor.utc % 1000) / 1000))/360;
                normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, secAngle);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSecSmooth) {
                    let duration = 0;
                    let animDuration = 5000;
                    if (timeSensor.second > 55) animDuration = 1000*(60.1 - (timeSensor.second - (timeSensor.utc % 1000) / 1000));
                    let diffTime = timeSensor.utc - lastTime;
                    if (diffTime < animDuration) duration = animDuration - diffTime;
                    normal_timerUpdateSecSmooth = timer.createTimer(duration, animDuration, (function (option) {
                      lastTime = timeSensor.utc;
                      secAngle = 0 + (360*6)*(timeSensor.second + ((timeSensor.utc % 1000) / 1000))/360;
                      startSecAnim(secAngle, animDuration);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.AOD) {
                  if (!idle_timerTextUpdate) {
                    idle_timerTextUpdate = timer.createTimer(0, 1000, (function (option) {
                      text_update();
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                checkConnection();
                stopVibro();

              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerTextUpdate) {
                  timer.stopTimer(normal_timerTextUpdate);
                  normal_timerTextUpdate = undefined;
                }
                if (normal_timerUpdateSec) {
                  timer.stopTimer(normal_timerUpdateSec);
                  normal_timerUpdateSec = undefined;
                }
                if (normal_timerUpdateSecSmooth) {
                  timer.stopTimer(normal_timerUpdateSecSmooth);
                  normal_timerUpdateSecSmooth = undefined;
                }
                if (idle_timerTextUpdate) {
                  timer.stopTimer(idle_timerTextUpdate);
                  idle_timerTextUpdate = undefined;
                }
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
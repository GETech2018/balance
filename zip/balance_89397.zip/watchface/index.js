﻿    /*
    ** Watch_Face_Editor tool v 18.0
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_city_name_text = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_distance_text_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_date_img_date_week_img = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg_img = ''
        let idle_battery_text_text_img = ''
        let idle_battery_image_progress_img_level = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_week_img = ''
        let idle_digital_clock_img_time = ''
        let idle_analog_clock_pro_second_pointer_img = ''
        let idle_timerUpdateSec = undefined;
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'MAIN.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 212,
              y: 0,
              src: 'bluetooth.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 184,
              y: 366,
              src: '0100.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 214,
              month_startY: 61,
              month_sc_array: ["0117.png","0118.png","0119.png","0120.png","0121.png","0122.png","0123.png","0124.png","0125.png","0126.png","0127.png","0128.png"],
              month_tc_array: ["0117.png","0118.png","0119.png","0120.png","0121.png","0122.png","0123.png","0124.png","0125.png","0126.png","0127.png","0128.png"],
              month_en_array: ["0117.png","0118.png","0119.png","0120.png","0121.png","0122.png","0123.png","0124.png","0125.png","0126.png","0127.png","0128.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 168,
              day_startY: 55,
              day_sc_array: ["Numbers_month_00.png","Numbers_month_01.png","Numbers_month_02.png","Numbers_month_03.png","Numbers_month_04.png","Numbers_month_05.png","Numbers_month_06.png","Numbers_month_07.png","Numbers_month_08.png","Numbers_month_09.png"],
              day_tc_array: ["Numbers_month_00.png","Numbers_month_01.png","Numbers_month_02.png","Numbers_month_03.png","Numbers_month_04.png","Numbers_month_05.png","Numbers_month_06.png","Numbers_month_07.png","Numbers_month_08.png","Numbers_month_09.png"],
              day_en_array: ["Numbers_month_00.png","Numbers_month_01.png","Numbers_month_02.png","Numbers_month_03.png","Numbers_month_04.png","Numbers_month_05.png","Numbers_month_06.png","Numbers_month_07.png","Numbers_month_08.png","Numbers_month_09.png"],
              day_zero: 0,
              day_space: 2,
              day_align: hmUI.align.RIGHT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 40,
              y: 271,
              w: 220,
              h: 38,
              text_size: 26,
              char_space: 0,
              color: 0xFFC0C0C0,
              line_space: 0,
              align_v: hmUI.align.BOTTOM,
              text_style: hmUI.text_style.NONE,
              align_h: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 400,
              y: 158,
              font_array: ["numbers_weather_00.png","numbers_weather_01.png","numbers_weather_02.png","numbers_weather_03.png","numbers_weather_04.png","numbers_weather_05.png","numbers_weather_06.png","numbers_weather_07.png","numbers_weather_08.png","numbers_weather_09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'numbers_weather_C.png',
              unit_tc: 'numbers_weather_C.png',
              unit_en: 'numbers_weather_C.png',
              negative_image: 'numbers_weather_minus.png',
              invalid_image: 'numbers_weather_minus.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 352,
              y: 148,
              image_array: ["1.png","2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png","12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png","22.png","23.png","24.png","25.png","26.png","27.png","28.png","29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 354,
              y: 306,
              font_array: ["Distance_00.png","Distance_01.png","Distance_02.png","Distance_03.png","Distance_04.png","Distance_05.png","Distance_06.png","Distance_07.png","Distance_08.png","Distance_09.png"],
              padding: false,
              h_space: 0,
              dot_image: 'Distance_dote.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 182,
              y: 392,
              font_array: ["BPM_00.png","BPM_01.png","BPM_02.png","BPM_03.png","BPM_04.png","BPM_05.png","BPM_06.png","BPM_07.png","BPM_08.png","BPM_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 345,
              y: 270,
              font_array: ["Numbers_steps_00.png","Numbers_steps_01.png","Numbers_steps_02.png","Numbers_steps_03.png","Numbers_steps_04.png","Numbers_steps_05.png","Numbers_steps_06.png","Numbers_steps_07.png","Numbers_steps_08.png","Numbers_steps_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 281,
              y: 176,
              image_array: ["steps_goal_00.png","steps_goal_01.png","steps_goal_02.png","steps_goal_03.png","steps_goal_04.png","steps_goal_05.png","steps_goal_06.png","steps_goal_07.png","steps_goal_08.png","steps_goal_09.png","steps_goal_9.png","steps_goal_10.png","steps_goal_11.png"],
              image_length: 13,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 280,
              y: 322,
              font_array: ["Battery_numbers_00.png","Battery_numbers_01.png","Battery_numbers_02.png","Battery_numbers_03.png","Battery_numbers_04.png","Battery_numbers_05.png","Battery_numbers_06.png","Battery_numbers_07.png","Battery_numbers_08.png","Battery_numbers_09.png"],
              padding: false,
              h_space: -2,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 64,
              y: 301,
              image_array: ["Battery_00.png","Battery_01.png","Battery_02.png","Battery_03.png","Battery_04.png","Battery_05.png","Battery_06.png","Battery_07.png"],
              image_length: 8,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 2,
              y: 33,
              week_en: ["Week_day_01.png","Week_day_02.png","Week_day_03.png","Week_day_04.png","Week_day_05.png","Week_day_06.png","Week_day_07.png"],
              week_tc: ["Week_day_01.png","Week_day_02.png","Week_day_03.png","Week_day_04.png","Week_day_05.png","Week_day_06.png","Week_day_07.png"],
              week_sc: ["Week_day_01.png","Week_day_02.png","Week_day_03.png","Week_day_04.png","Week_day_05.png","Week_day_06.png","Week_day_07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 18,
              hour_startY: 175,
              hour_array: ["Numbers_HnM_00.png","Numbers_HnM_01.png","Numbers_HnM_02.png","Numbers_HnM_03.png","Numbers_HnM_04.png","Numbers_HnM_05.png","Numbers_HnM_06.png","Numbers_HnM_07.png","Numbers_HnM_08.png","Numbers_HnM_09.png"],
              hour_zero: 1,
              hour_space: 5,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 155,
              minute_startY: 175,
              minute_array: ["Numbers_HnM_00.png","Numbers_HnM_01.png","Numbers_HnM_02.png","Numbers_HnM_03.png","Numbers_HnM_04.png","Numbers_HnM_05.png","Numbers_HnM_06.png","Numbers_HnM_07.png","Numbers_HnM_08.png","Numbers_HnM_09.png"],
              minute_zero: 1,
              minute_space: 5,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 272,
              second_startY: 164,
              second_array: ["Numbers_S_00.png","Numbers_S_01.png","Numbers_S_02.png","Numbers_S_03.png","Numbers_S_04.png","Numbers_S_05.png","Numbers_S_06.png","Numbers_S_07.png","Numbers_S_08.png","Numbers_S_09.png"],
              second_zero: 1,
              second_space: 2,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 133,
              y: 183,
              src: 'anim_column_0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'Hand_Second_2.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 110,
              second_posY: 239,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'MAIN_AOD.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 336,
              y: 322,
              font_array: ["Battery_numbers_00.png","Battery_numbers_01.png","Battery_numbers_02.png","Battery_numbers_03.png","Battery_numbers_04.png","Battery_numbers_05.png","Battery_numbers_06.png","Battery_numbers_07.png","Battery_numbers_08.png","Battery_numbers_09.png"],
              padding: false,
              h_space: -2,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 120,
              y: 301,
              image_array: ["Battery_00.png","Battery_01.png","Battery_02.png","Battery_03.png","Battery_04.png","Battery_05.png","Battery_06.png","Battery_07.png"],
              image_length: 8,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 214,
              month_startY: 61,
              month_sc_array: ["0117.png","0118.png","0119.png","0120.png","0121.png","0122.png","0123.png","0124.png","0125.png","0126.png","0127.png","0128.png"],
              month_tc_array: ["0117.png","0118.png","0119.png","0120.png","0121.png","0122.png","0123.png","0124.png","0125.png","0126.png","0127.png","0128.png"],
              month_en_array: ["0117.png","0118.png","0119.png","0120.png","0121.png","0122.png","0123.png","0124.png","0125.png","0126.png","0127.png","0128.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 168,
              day_startY: 55,
              day_sc_array: ["Numbers_month_00.png","Numbers_month_01.png","Numbers_month_02.png","Numbers_month_03.png","Numbers_month_04.png","Numbers_month_05.png","Numbers_month_06.png","Numbers_month_07.png","Numbers_month_08.png","Numbers_month_09.png"],
              day_tc_array: ["Numbers_month_00.png","Numbers_month_01.png","Numbers_month_02.png","Numbers_month_03.png","Numbers_month_04.png","Numbers_month_05.png","Numbers_month_06.png","Numbers_month_07.png","Numbers_month_08.png","Numbers_month_09.png"],
              day_en_array: ["Numbers_month_00.png","Numbers_month_01.png","Numbers_month_02.png","Numbers_month_03.png","Numbers_month_04.png","Numbers_month_05.png","Numbers_month_06.png","Numbers_month_07.png","Numbers_month_08.png","Numbers_month_09.png"],
              day_zero: 0,
              day_space: 2,
              day_align: hmUI.align.RIGHT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 2,
              y: 33,
              week_en: ["Week_day_01.png","Week_day_02.png","Week_day_03.png","Week_day_04.png","Week_day_05.png","Week_day_06.png","Week_day_07.png"],
              week_tc: ["Week_day_01.png","Week_day_02.png","Week_day_03.png","Week_day_04.png","Week_day_05.png","Week_day_06.png","Week_day_07.png"],
              week_sc: ["Week_day_01.png","Week_day_02.png","Week_day_03.png","Week_day_04.png","Week_day_05.png","Week_day_06.png","Week_day_07.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 106,
              hour_startY: 202,
              hour_array: ["Numbers_HnMAOD_00.png","Numbers_HnMAOD_01.png","Numbers_HnMAOD_02.png","Numbers_HnMAOD_03.png","Numbers_HnMAOD_04.png","Numbers_HnMAOD_05.png","Numbers_HnMAOD_06.png","Numbers_HnMAOD_07.png","Numbers_HnMAOD_08.png","Numbers_HnMAOD_09.png"],
              hour_zero: 1,
              hour_space: 10,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 266,
              minute_startY: 202,
              minute_array: ["Numbers_HnMAOD_00.png","Numbers_HnMAOD_01.png","Numbers_HnMAOD_02.png","Numbers_HnMAOD_03.png","Numbers_HnMAOD_04.png","Numbers_HnMAOD_05.png","Numbers_HnMAOD_06.png","Numbers_HnMAOD_07.png","Numbers_HnMAOD_08.png","Numbers_HnMAOD_09.png"],
              minute_zero: 1,
              minute_space: 10,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            const deviceInfo = hmSetting.getDeviceInfo();
            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            // idle_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'Hand_Second_2.png',
              // center_x: 240,
              // center_y: 240,
              // x: 110,
              // y: 235,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });


            idle_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 110,
              pos_y: 240 - 235,
              center_x: 240,
              center_y: 240,
              src: 'Hand_Second_2.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            let screenType = hmSetting.getScreenType();
            //#region time_update
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              // Second Pointer
              let idle_fullAngle_second = 360;
              let idle_angle_second = 0 + idle_fullAngle_second*second/60;
              if (idle_analog_clock_pro_second_pointer_img) idle_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, idle_angle_second);

            };

            //#endregion
            function scale_call() {
              console.log('scale_call()');

              console.log('Weather city name');
              let weatherData = weatherSensor.getForecastWeather();
              let normal_cityNameStr = weatherData.cityName;
              normal_city_name_text.setProperty(hmUI.prop.TEXT, normal_cityNameStr);

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                time_update(true, true);
                if (screenType == hmSetting.screen_type.AOD) {
                  if (!idle_timerUpdateSec) {
                    let animDelay = timeSensor.utc % 1000;
                    let animRepeat = 1000;
                    idle_timerUpdateSec = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, false);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (idle_timerUpdateSec) {
                  timer.stopTimer(idle_timerUpdateSec);
                  idle_timerUpdateSec = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
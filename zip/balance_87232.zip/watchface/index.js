﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_image_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_sun_high_text_img = ''
        let normal_sun_low_text_img = ''
        let normal_step_TextRotate = new Array(5);
        let normal_step_TextRotate_ASCIIARRAY = new Array(10);
        let normal_step_TextRotate_img_width = 20;
        let normal_heart_rate_TextRotate = new Array(3);
        let normal_heart_rate_TextRotate_ASCIIARRAY = new Array(10);
        let normal_heart_rate_TextRotate_img_width = 20;
        let normal_date_img_date_month_img = ''
        let normal_day_TextRotate = new Array(2);
        let normal_day_TextRotate_ASCIIARRAY = new Array(10);
        let normal_day_TextRotate_img_width = 61;
        let normal_timerTextUpdate = undefined;
        let normal_date_img_date_week_img = ''
        let normal_battery_text_text_img = ''
        let normal_digital_clock_img_time = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_date_img_date_month_img = ''
        let idle_day_TextRotate = new Array(2);
        let idle_day_TextRotate_ASCIIARRAY = new Array(10);
        let idle_day_TextRotate_img_width = 61;
        let idle_timerTextUpdate = undefined;
        let idle_date_img_date_week_img = ''
        let idle_digital_clock_img_time = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let Button_7 = ''
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: '1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'com.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 294,
              y: 432,
              src: 'BT.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 150,
              y: 430,
              src: 'can.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 107,
              y: 368,
              image_array: ["W_weather_01.png","W_weather_02.png","W_weather_03.png","W_weather_04.png","W_weather_05.png","W_weather_06.png","W_weather_07.png","W_weather_08.png","W_weather_09.png","W_weather_10.png","W_weather_11.png","W_weather_12.png","W_weather_13.png","W_weather_14.png","W_weather_15.png","W_weather_16.png","W_weather_17.png","W_weather_18.png","W_weather_19.png","W_weather_20.png","W_weather_21.png","W_weather_22.png","W_weather_23.png","W_weather_24.png","W_weather_25.png","W_weather_26.png","W_weather_27.png","W_weather_28.png","W_weather_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 185,
              y: 400,
              font_array: ["B_digit_01.png","B_digit_02.png","B_digit_03.png","B_digit_04.png","B_digit_05.png","B_digit_06.png","B_digit_07.png","B_digit_08.png","B_digit_09.png","B_digit_10.png"],
              padding: false,
              h_space: -41,
              unit_sc: 'B_special_13.png',
              unit_tc: 'B_special_13.png',
              unit_en: 'B_special_13.png',
              negative_image: 'B_special_11.png',
              invalid_image: 'B_special_16.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 131,
              y: 12,
              font_array: ["A_digit_01.png","A_digit_02.png","A_digit_03.png","A_digit_04.png","A_digit_05.png","A_digit_06.png","A_digit_07.png","A_digit_08.png","A_digit_09.png","A_digit_10.png"],
              padding: false,
              h_space: -4,
              dot_image: 'A_special_01.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 255,
              y: 12,
              font_array: ["A_digit_01.png","A_digit_02.png","A_digit_03.png","A_digit_04.png","A_digit_05.png","A_digit_06.png","A_digit_07.png","A_digit_08.png","A_digit_09.png","A_digit_10.png"],
              padding: false,
              h_space: -4,
              dot_image: 'A_special_01.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_step_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 110,
              // y: 293,
              // font_array: ["A_digit_01.png","A_digit_02.png","A_digit_03.png","A_digit_04.png","A_digit_05.png","A_digit_06.png","A_digit_07.png","A_digit_08.png","A_digit_09.png","A_digit_10.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: -2,
              // angle: 90,
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_step_TextRotate_ASCIIARRAY[0] = 'A_digit_01.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[1] = 'A_digit_02.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[2] = 'A_digit_03.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[3] = 'A_digit_04.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[4] = 'A_digit_05.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[5] = 'A_digit_06.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[6] = 'A_digit_07.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[7] = 'A_digit_08.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[8] = 'A_digit_09.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[9] = 'A_digit_10.png';  // set of images with numbers

            //#region TextRotate
            for (let i = 0; i < 5; i++) {
              normal_step_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 110,
                center_y: 293,
                pos_x: 110,
                pos_y: 293,
                angle: 90,
                src: 'A_digit_01.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_step_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //#endregion
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            // normal_heart_rate_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 110,
              // y: 188,
              // font_array: ["A_digit_01.png","A_digit_02.png","A_digit_03.png","A_digit_04.png","A_digit_05.png","A_digit_06.png","A_digit_07.png","A_digit_08.png","A_digit_09.png","A_digit_10.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: -2,
              // angle: 90,
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_heart_rate_TextRotate_ASCIIARRAY[0] = 'A_digit_01.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[1] = 'A_digit_02.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[2] = 'A_digit_03.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[3] = 'A_digit_04.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[4] = 'A_digit_05.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[5] = 'A_digit_06.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[6] = 'A_digit_07.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[7] = 'A_digit_08.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[8] = 'A_digit_09.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[9] = 'A_digit_10.png';  // set of images with numbers

            //#region TextRotate
            for (let i = 0; i < 3; i++) {
              normal_heart_rate_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 110,
                center_y: 188,
                pos_x: 110,
                pos_y: 188,
                angle: 90,
                src: 'A_digit_01.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_heart_rate_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //#endregion
            
            const heart_rate = hmSensor.createSensor(hmSensor.id.HEART);
            heart_rate.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 400,
              month_startY: 172,
              month_sc_array: ["K_month_01.png","K_month_02.png","K_month_03.png","K_month_04.png","K_month_05.png","K_month_06.png","K_month_07.png","K_month_08.png","K_month_09.png","K_month_10.png","K_month_11.png","K_month_12.png"],
              month_tc_array: ["K_month_01.png","K_month_02.png","K_month_03.png","K_month_04.png","K_month_05.png","K_month_06.png","K_month_07.png","K_month_08.png","K_month_09.png","K_month_10.png","K_month_11.png","K_month_12.png"],
              month_en_array: ["K_month_01.png","K_month_02.png","K_month_03.png","K_month_04.png","K_month_05.png","K_month_06.png","K_month_07.png","K_month_08.png","K_month_09.png","K_month_10.png","K_month_11.png","K_month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_day_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 399,
              // y: 273,
              // font_array: ["B_digit_01.png","B_digit_02.png","B_digit_03.png","B_digit_04.png","B_digit_05.png","B_digit_06.png","B_digit_07.png","B_digit_08.png","B_digit_09.png","B_digit_10.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: -35,
              // angle: -90,
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.DAY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_day_TextRotate_ASCIIARRAY[0] = 'B_digit_01.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[1] = 'B_digit_02.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[2] = 'B_digit_03.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[3] = 'B_digit_04.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[4] = 'B_digit_05.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[5] = 'B_digit_06.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[6] = 'B_digit_07.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[7] = 'B_digit_08.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[8] = 'B_digit_09.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[9] = 'B_digit_10.png';  // set of images with numbers

            //#region TextRotate
            for (let i = 0; i < 2; i++) {
              normal_day_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 399,
                center_y: 273,
                pos_x: 399,
                pos_y: 273,
                angle: -90,
                src: 'B_digit_01.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_day_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //#endregion

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            let screenType = hmSetting.getScreenType();
            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 370,
              y: 141,
              week_en: ["D_day_01.png","D_day_02.png","D_day_03.png","D_day_04.png","D_day_05.png","D_day_06.png","D_day_07.png"],
              week_tc: ["D_day_01.png","D_day_02.png","D_day_03.png","D_day_04.png","D_day_05.png","D_day_06.png","D_day_07.png"],
              week_sc: ["D_day_01.png","D_day_02.png","D_day_03.png","D_day_04.png","D_day_05.png","D_day_06.png","D_day_07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: -7,
              y: 188,
              font_array: ["D_digit_01.png","D_digit_02.png","D_digit_03.png","D_digit_04.png","D_digit_05.png","D_digit_06.png","D_digit_07.png","D_digit_08.png","D_digit_09.png","D_digit_10.png"],
              padding: true,
              h_space: 0,
              angle: 91,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 103,
              hour_startY: 83,
              hour_array: ["H_digit_01.png","H_digit_02.png","H_digit_03.png","H_digit_04.png","H_digit_05.png","H_digit_06.png","H_digit_07.png","H_digit_08.png","H_digit_09.png","H_digit_10.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 103,
              minute_startY: 237,
              minute_array: ["M_digit_01.png","M_digit_02.png","M_digit_03.png","M_digit_04.png","M_digit_05.png","M_digit_06.png","M_digit_07.png","M_digit_08.png","M_digit_09.png","M_digit_10.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 294,
              y: 418,
              src: 'BT.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 150,
              y: 414,
              src: 'can.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 400,
              month_startY: 172,
              month_sc_array: ["K_month_01.png","K_month_02.png","K_month_03.png","K_month_04.png","K_month_05.png","K_month_06.png","K_month_07.png","K_month_08.png","K_month_09.png","K_month_10.png","K_month_11.png","K_month_12.png"],
              month_tc_array: ["K_month_01.png","K_month_02.png","K_month_03.png","K_month_04.png","K_month_05.png","K_month_06.png","K_month_07.png","K_month_08.png","K_month_09.png","K_month_10.png","K_month_11.png","K_month_12.png"],
              month_en_array: ["K_month_01.png","K_month_02.png","K_month_03.png","K_month_04.png","K_month_05.png","K_month_06.png","K_month_07.png","K_month_08.png","K_month_09.png","K_month_10.png","K_month_11.png","K_month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_day_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 399,
              // y: 273,
              // font_array: ["B_digit_01.png","B_digit_02.png","B_digit_03.png","B_digit_04.png","B_digit_05.png","B_digit_06.png","B_digit_07.png","B_digit_08.png","B_digit_09.png","B_digit_10.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: -35,
              // angle: -90,
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.DAY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_day_TextRotate_ASCIIARRAY[0] = 'B_digit_01.png';  // set of images with numbers
            idle_day_TextRotate_ASCIIARRAY[1] = 'B_digit_02.png';  // set of images with numbers
            idle_day_TextRotate_ASCIIARRAY[2] = 'B_digit_03.png';  // set of images with numbers
            idle_day_TextRotate_ASCIIARRAY[3] = 'B_digit_04.png';  // set of images with numbers
            idle_day_TextRotate_ASCIIARRAY[4] = 'B_digit_05.png';  // set of images with numbers
            idle_day_TextRotate_ASCIIARRAY[5] = 'B_digit_06.png';  // set of images with numbers
            idle_day_TextRotate_ASCIIARRAY[6] = 'B_digit_07.png';  // set of images with numbers
            idle_day_TextRotate_ASCIIARRAY[7] = 'B_digit_08.png';  // set of images with numbers
            idle_day_TextRotate_ASCIIARRAY[8] = 'B_digit_09.png';  // set of images with numbers
            idle_day_TextRotate_ASCIIARRAY[9] = 'B_digit_10.png';  // set of images with numbers

            //#region TextRotate
            for (let i = 0; i < 2; i++) {
              idle_day_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 399,
                center_y: 273,
                pos_x: 399,
                pos_y: 273,
                angle: -90,
                src: 'B_digit_01.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_day_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //#endregion

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 370,
              y: 141,
              week_en: ["D_day_01.png","D_day_02.png","D_day_03.png","D_day_04.png","D_day_05.png","D_day_06.png","D_day_07.png"],
              week_tc: ["D_day_01.png","D_day_02.png","D_day_03.png","D_day_04.png","D_day_05.png","D_day_06.png","D_day_07.png"],
              week_sc: ["D_day_01.png","D_day_02.png","D_day_03.png","D_day_04.png","D_day_05.png","D_day_06.png","D_day_07.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 103,
              hour_startY: 83,
              hour_array: ["H_digit_01.png","H_digit_02.png","H_digit_03.png","H_digit_04.png","H_digit_05.png","H_digit_06.png","H_digit_07.png","H_digit_08.png","H_digit_09.png","H_digit_10.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 103,
              minute_startY: 237,
              minute_array: ["M_digit_01.png","M_digit_02.png","M_digit_03.png","M_digit_04.png","M_digit_05.png","M_digit_06.png","M_digit_07.png","M_digit_08.png","M_digit_09.png","M_digit_10.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 0,
              // disconneсnt_toast_text: RUSH OFF,
              // conneсnt_vibrate_type: 0,
              // conneсnt_toast_text: RUSH ON,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              console.log('checkConnection()');
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  hmUI.showToast({text: "RUSH OFF"});
                  vibro(0);
                }
                if(status) {
                  hmUI.showToast({text: "RUSH ON"});
                  vibro(0);
                }
              });
            }

            // end vibration when connecting or disconnecting
            //#region vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              if (scene != 1) timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            //#endregion

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 114,
              y: 20,
              w: 250,
              h: 55,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'transparent.png',
              normal_src: 'transparent.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'TideScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 114,
              y: 364,
              w: 250,
              h: 55,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'transparent.png',
              normal_src: 'transparent.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'WeatherScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 390,
              y: 122,
              w: 74,
              h: 250,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'transparent.png',
              normal_src: 'transparent.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: -34,
              y: 122,
              w: 74,
              h: 250,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'transparent.png',
              normal_src: 'transparent.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'Settings_batteryManagerScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 49,
              y: 108,
              w: 74,
              h: 128,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'transparent.png',
              normal_src: 'transparent.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'heart_app_Screen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 49,
              y: 251,
              w: 60,
              h: 128,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'transparent.png',
              normal_src: 'transparent.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'activityAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_7 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 129,
              y: 425,
              w: 60,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'transparent.png',
              normal_src: 'transparent.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'AlarmInfoScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            //#region text_update
            function text_update() {
              console.log('text_update()');

              console.log('update text rotate step_STEP');
              let valueStep = step.current;
              let normal_step_rotate_string = parseInt(valueStep).toString();
              normal_step_rotate_string = normal_step_rotate_string.padStart(5, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  normal_step_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueStep != null && valueStep != undefined && isFinite(valueStep) && normal_step_rotate_string.length > 0 && normal_step_rotate_string.length <= 5) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let normal_step_TextRotate_posOffset = normal_step_TextRotate_img_width * normal_step_rotate_string.length;
                  normal_step_TextRotate_posOffset = normal_step_TextRotate_posOffset + -2 * (normal_step_rotate_string.length - 1);
                  img_offset -= normal_step_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_step_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_step_TextRotate[index].setProperty(hmUI.prop.POS_X, 110 + img_offset);
                      normal_step_TextRotate[index].setProperty(hmUI.prop.SRC, normal_step_TextRotate_ASCIIARRAY[charCode]);
                      normal_step_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_step_TextRotate_img_width + -2;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate heart_rate_HEART');
              let valueHeartRate = heart_rate.last;
              let normal_heart_rate_rotate_string = parseInt(valueHeartRate).toString();
              normal_heart_rate_rotate_string = normal_heart_rate_rotate_string.padStart(3, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  normal_heart_rate_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueHeartRate != null && valueHeartRate != undefined && isFinite(valueHeartRate) && normal_heart_rate_rotate_string.length > 0 && normal_heart_rate_rotate_string.length <= 3) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let normal_heart_rate_TextRotate_posOffset = normal_heart_rate_TextRotate_img_width * normal_heart_rate_rotate_string.length;
                  normal_heart_rate_TextRotate_posOffset = normal_heart_rate_TextRotate_posOffset + -2 * (normal_heart_rate_rotate_string.length - 1);
                  img_offset -= normal_heart_rate_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_heart_rate_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_heart_rate_TextRotate[index].setProperty(hmUI.prop.POS_X, 110 + img_offset);
                      normal_heart_rate_TextRotate[index].setProperty(hmUI.prop.SRC, normal_heart_rate_TextRotate_ASCIIARRAY[charCode]);
                      normal_heart_rate_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_heart_rate_TextRotate_img_width + -2;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate day_TIME');
              let valueDay = timeSensor.day;
              let normal_day_rotate_string = parseInt(valueDay).toString();
              normal_day_rotate_string = normal_day_rotate_string.padStart(2, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_day_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueDay != null && valueDay != undefined && isFinite(valueDay) && normal_day_rotate_string.length > 0 && normal_day_rotate_string.length <= 2) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let normal_day_TextRotate_posOffset = normal_day_TextRotate_img_width * normal_day_rotate_string.length;
                  normal_day_TextRotate_posOffset = normal_day_TextRotate_posOffset + -35 * (normal_day_rotate_string.length - 1);
                  img_offset -= normal_day_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_day_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_day_TextRotate[index].setProperty(hmUI.prop.POS_X, 399 + img_offset);
                      normal_day_TextRotate[index].setProperty(hmUI.prop.SRC, normal_day_TextRotate_ASCIIARRAY[charCode]);
                      normal_day_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_day_TextRotate_img_width + -35;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate day_TIME');
              let idle_day_rotate_string = parseInt(valueDay).toString();
              idle_day_rotate_string = idle_day_rotate_string.padStart(2, '0');

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  idle_day_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueDay != null && valueDay != undefined && isFinite(valueDay) && idle_day_rotate_string.length > 0 && idle_day_rotate_string.length <= 2) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let idle_day_TextRotate_posOffset = idle_day_TextRotate_img_width * idle_day_rotate_string.length;
                  idle_day_TextRotate_posOffset = idle_day_TextRotate_posOffset + -35 * (idle_day_rotate_string.length - 1);
                  img_offset -= idle_day_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of idle_day_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_day_TextRotate[index].setProperty(hmUI.prop.POS_X, 399 + img_offset);
                      idle_day_TextRotate[index].setProperty(hmUI.prop.SRC, idle_day_TextRotate_ASCIIARRAY[charCode]);
                      idle_day_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_day_TextRotate_img_width + -35;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

            };

            //#endregion
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                text_update();
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerTextUpdate) {
                    normal_timerTextUpdate = timer.createTimer(0, 1000, (function (option) {
                      text_update();
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.AOD) {
                  if (!idle_timerTextUpdate) {
                    idle_timerTextUpdate = timer.createTimer(0, 1000, (function (option) {
                      text_update();
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                checkConnection();
                stopVibro();

              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerTextUpdate) {
                  timer.stopTimer(normal_timerTextUpdate);
                  normal_timerTextUpdate = undefined;
                }
                if (idle_timerTextUpdate) {
                  timer.stopTimer(idle_timerTextUpdate);
                  idle_timerTextUpdate = undefined;
                }
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                heart_rate.removeEventListener(heart.event.CURRENT, hrCurrListener);
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_battery_text_text_img = ''
        let normal_digital_clock_img_time = ''
        let normal_image_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_year = ''
        let normal_date_img_date_month_img = ''
        let idle_digital_clock_img_time = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: '2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 199,
              y: 437,
              font_array: ["A00.png","A01.png","A02.png","A03.png","A04.png","A05.png","A06.png","A07.png","A08.png","A09.png"],
              padding: false,
              h_space: -7,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 41,
              hour_startY: 206,
              hour_array: ["H00.png","H01.png","H02.png","H03.png","H04.png","H05.png","H06.png","H07.png","H08.png","H09.png"],
              hour_zero: 1,
              hour_space: -32,
              hour_angle: 0,
              hour_unit_sc: 'M10.png',
              hour_unit_tc: 'M10.png',
              hour_unit_en: 'M10.png',
              hour_align: hmUI.align.RIGHT,

              minute_startX: 247,
              minute_startY: 206,
              minute_array: ["M00.png","M01.png","M02.png","M03.png","M04.png","M05.png","M06.png","M07.png","M08.png","M09.png"],
              minute_zero: 1,
              minute_space: -32,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 207,
              second_startY: 332,
              second_array: ["X00.png","X01.png","X02.png","X03.png","X04.png","X05.png","X06.png","X07.png","X08.png","X09.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: -1,
              y: 0,
              src: 'DEVANT2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 86,
              y: 115,
              week_en: ["J01.png","J02.png","J03.png","J04.png","J05.png","J06.png","J07.png"],
              week_tc: ["J01.png","J02.png","J03.png","J04.png","J05.png","J06.png","J07.png"],
              week_sc: ["J01.png","J02.png","J03.png","J04.png","J05.png","J06.png","J07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 81,
              day_startY: 145,
              day_sc_array: ["V00.png","V01.png","V02.png","V03.png","V04.png","V05.png","V06.png","V07.png","V08.png","V09.png"],
              day_tc_array: ["V00.png","V01.png","V02.png","V03.png","V04.png","V05.png","V06.png","V07.png","V08.png","V09.png"],
              day_en_array: ["V00.png","V01.png","V02.png","V03.png","V04.png","V05.png","V06.png","V07.png","V08.png","V09.png"],
              day_zero: 1,
              day_space: -15,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 144,
              year_startY: 178,
              year_sc_array: ["X00.png","X01.png","X02.png","X03.png","X04.png","X05.png","X06.png","X07.png","X08.png","X09.png"],
              year_tc_array: ["X00.png","X01.png","X02.png","X03.png","X04.png","X05.png","X06.png","X07.png","X08.png","X09.png"],
              year_en_array: ["X00.png","X01.png","X02.png","X03.png","X04.png","X05.png","X06.png","X07.png","X08.png","X09.png"],
              year_zero: 1,
              year_space: -5,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 148,
              month_startY: 146,
              month_sc_array: ["W01.png","W02.png","W03.png","W04.png","W05.png","W06.png","W07.png","W08.png","W09.png","W10.png","W11.png","W12.png"],
              month_tc_array: ["W01.png","W02.png","W03.png","W04.png","W05.png","W06.png","W07.png","W08.png","W09.png","W10.png","W11.png","W12.png"],
              month_en_array: ["W01.png","W02.png","W03.png","W04.png","W05.png","W06.png","W07.png","W08.png","W09.png","W10.png","W11.png","W12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 41,
              hour_startY: 206,
              hour_array: ["Q00.png","Q01.png","Q02.png","Q03.png","Q04.png","Q05.png","Q06.png","Q07.png","Q08.png","Q09.png"],
              hour_zero: 1,
              hour_space: -32,
              hour_angle: 0,
              hour_unit_sc: 'M10.png',
              hour_unit_tc: 'M10.png',
              hour_unit_en: 'M10.png',
              hour_align: hmUI.align.RIGHT,

              minute_startX: 251,
              minute_startY: 206,
              minute_array: ["M00.png","M01.png","M02.png","M03.png","M04.png","M05.png","M06.png","M07.png","M08.png","M09.png"],
              minute_zero: 1,
              minute_space: -32,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 9,
              // disconneсnt_toast_text: BT OFF,
              // conneсnt_vibrate_type: 9,
              // conneсnt_toast_text: BT ON,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              console.log('checkConnection()');
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  hmUI.showToast({text: "BT OFF"});
                  vibro(9);
                }
                if(status) {
                  hmUI.showToast({text: "BT ON"});
                  vibro(9);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              if (scene != 1) timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                checkConnection();
                stopVibro();

              }),
              pause_call: (function () {
                console.log('pause_call()');
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}

WatchFace({
  build() {
    const stepSensor = hmSensor.createSensor(hmSensor.id.STEP)
    const batterySensor = hmSensor.createSensor(hmSensor.id.BATTERY)
    const hrSensor = hmSensor.createSensor(hmSensor.id.HEART)

    let currentSlots = [0, 1, 2]
    
    // Simple state persistence for mode
    let displayMode = 'analog'
    try {
      const modeFile = hmFS.open('mode.txt', hmFS.O_RDONLY)
      if (modeFile) {
        const buf = new ArrayBuffer(10)
        hmFS.read(modeFile, buf, 0, 10)
        displayMode = String.fromCharCode.apply(null, new Uint8Array(buf)).trim() || 'analog'
        hmFS.close(modeFile)
      }
    } catch (e) {}

    // BACKGROUNDS
    hmUI.createWidget(hmUI.widget.IMG, {
      x: 0, y: 0,
      src: '0003.png',
      show_level: hmUI.show_level.ONLY_NORMAL
    })

    hmUI.createWidget(hmUI.widget.IMG, {
      x: 0, y: 0,
      src: '0003_1.png',
      show_level: hmUI.show_level.ONLY_AOD
    })

    const createWidgetUI = (x, y, slotIdx) => {
      const group = hmUI.createWidget(hmUI.widget.GROUP, {
        x: x - 44, y: y - 44, w: 88, h: 88,
        show_level: hmUI.show_level.ONLY_NORMAL
      })

      group.createWidget(hmUI.widget.FILL_RECT, {
        x: 0, y: 0, w: 88, h: 88,
        radius: 44, color: 0x1a1a1a, opacity: 180
      })

      // Progress Arc
      const arc = group.createWidget(hmUI.widget.ARC, {
        x: 2, y: 2, w: 84, h: 84,
        start_angle: -90, end_angle: -90,
        color: 0x2ecc71, line_width: 4,
        show_level: hmUI.show_level.ONLY_NORMAL
      })

      const iconText = group.createWidget(hmUI.widget.TEXT, {
        x: 0, y: 13, w: 88, h: 30,
        color: 0xffffff, text_size: 24, align_h: hmUI.align.CENTER_H,
        text: ''
      })

      const valText = group.createWidget(hmUI.widget.TEXT, {
        x: 0, y: 42, w: 88, h: 22,
        color: 0xffffff, text_size: 19, align_h: hmUI.align.CENTER_H,
        text: '--'
      })

      group.createWidget(hmUI.widget.BUTTON, {
        x: 0, y: 0, w: 88, h: 88,
        press_src: '', normal_src: '',
        click_func: () => {
          currentSlots[slotIdx] = (currentSlots[slotIdx] + 1) % 3
          update()
        }
      })
      return { valText, arc, iconText }
    }

    const { valText: w1, arc: arc1, iconText: i1 } = createWidgetUI(160, 290, 0)
    const { valText: w2, arc: arc2, iconText: i2 } = createWidgetUI(240, 290, 1)
    const { valText: w3, arc: arc3, iconText: i3 } = createWidgetUI(320, 290, 2)

      const update = () => {
        const vals = [
          stepSensor.getCurrent().toString(),
          batterySensor.getCurrent().toString() + '%',
          hrSensor.getLast().toString()
        ]
        const icons = ['👟', '⚡', '❤️']
        const progressVals = [
          Math.min(stepSensor.getCurrent() / 10000, 1),
          batterySensor.getCurrent() / 100,
          Math.min(hrSensor.getLast() / 200, 1)
        ]
        const colors = [0x2ecc71, 0xf1c40f, 0xe74c3c]

        const updateSlot = (w, arc, icon, idx) => {
          const sIdx = currentSlots[idx]
          w.setProperty(hmUI.prop.TEXT, vals[sIdx])
          
          // Only show progress for steps, battery, heart (indices 0, 1, 2)
          if (sIdx < 3) { 
            icon.setProperty(hmUI.prop.TEXT, icons[sIdx])
            arc.setProperty(hmUI.prop.VISIBLE, true)
            arc.setProperty(hmUI.prop.COLOR, colors[sIdx])
            arc.setProperty(hmUI.prop.END_ANGLE, -90 + (progressVals[sIdx] * 360))
          } else {
            arc.setProperty(hmUI.prop.VISIBLE, false)
          }
        }

        updateSlot(w1, arc1, i1, 0)
        updateSlot(w2, arc2, i2, 1)
        updateSlot(w3, arc3, i3, 2)
      }
    timer.createTimer(0, 1000, update)

    if (displayMode === 'digital') {
      const timeText = hmUI.createWidget(hmUI.widget.TEXT, {
        x: 0, y: 140, w: 480, h: 100,
        color: 0xffffff, text_size: 80, align_h: hmUI.align.CENTER_H, align_v: hmUI.align.CENTER_V,
        text: '00:00',
        show_level: hmUI.show_level.ONLY_NORMAL
      })

      const timeTextAOD = hmUI.createWidget(hmUI.widget.TEXT, {
        x: 0, y: 140, w: 480, h: 100,
        color: 0x666666, text_size: 80, align_h: hmUI.align.CENTER_H, align_v: hmUI.align.CENTER_V,
        text: '00:00',
        show_level: hmUI.show_level.ONLY_AOD
      })

      timer.createTimer(0, 1000, () => {
        const date = new Date()
        const h = date.getHours().toString().padStart(2, '0')
        const m = date.getMinutes().toString().padStart(2, '0')
        const t = h + ':' + m
        timeText.setProperty(hmUI.prop.TEXT, t)
        timeTextAOD.setProperty(hmUI.prop.TEXT, t)
      })

      // Center Toggle Button (Digital)
      hmUI.createWidget(hmUI.widget.BUTTON, {
        x: 140, y: 140, w: 200, h: 100,
        press_src: '', normal_src: '',
        click_func: () => {
          const f = hmFS.open('mode.txt', hmFS.O_WRONLY | hmFS.O_CREAT | hmFS.O_TRUNC)
          const buf = new Uint8Array(6)
          const str = 'analog'
          for(let i=0; i<6; i++) buf[i] = str.charCodeAt(i)
          hmFS.write(f, buf.buffer, 0, 6)
          hmFS.close(f)
          hmApp.reload()
        }
      })

    } else {
      const date = new Date()
      const day = date.toLocaleDateString('en-US', { weekday: 'short' }).toUpperCase()
      const dayNum = date.getDate()

      const dateContainer = hmUI.createWidget(hmUI.widget.GROUP, {
        x: 370, y: 215, w: 65, h: 50,
        show_level: hmUI.show_level.ONLY_NORMAL
      })

      dateContainer.createWidget(hmUI.widget.FILL_RECT, {
        x: 0, y: 0, w: 65, h: 50,
        radius: 4, color: 0xe5e5e5
      })

      dateContainer.createWidget(hmUI.widget.TEXT, {
        x: 0, y: 5, w: 65, h: 15,
        color: 0x333333, text_size: 12, align_h: hmUI.align.CENTER_H,
        text: day
      })

      dateContainer.createWidget(hmUI.widget.TEXT, {
        x: 0, y: 20, w: 65, h: 25,
        color: 0x000000, text_size: 20, align_h: hmUI.align.CENTER_H,
        text: dayNum.toString()
      })

      hmUI.createWidget(hmUI.widget.TIME_POINTER, {
        hour_path: 'h.png', hour_centerX: 240, hour_centerY: 240,
        show_level: hmUI.show_level.COMMON
      })

      hmUI.createWidget(hmUI.widget.TIME_POINTER, {
        minute_path: 'm.png', minute_centerX: 240, minute_centerY: 240,
        show_level: hmUI.show_level.COMMON
      })

      hmUI.createWidget(hmUI.widget.TIME_POINTER, {
        second_path: 's.png', second_centerX: 240, second_centerY: 240,
        show_level: hmUI.show_level.ONLY_NORMAL
      })

      // Center Toggle Button (Analog)
      hmUI.createWidget(hmUI.widget.BUTTON, {
        x: 210, y: 210, w: 60, h: 60,
        press_src: '', normal_src: '',
        click_func: () => {
          const f = hmFS.open('mode.txt', hmFS.O_WRONLY | hmFS.O_CREAT | hmFS.O_TRUNC)
          const buf = new Uint8Array(7)
          const str = 'digital'
          for(let i=0; i<7; i++) buf[i] = str.charCodeAt(i)
          hmFS.write(f, buf.buffer, 0, 7)
          hmFS.close(f)
          hmApp.reload()
        }
      })
    }
  }
})
    
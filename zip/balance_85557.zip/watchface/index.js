﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_clock_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_step_current_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_digital_clock_img_time = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'circular_bg_solid_480x480_1752416849291.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 265,
              y: 413,
              src: 'ACon.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 235,
              y: 305,
              image_array: ["B01.png","B02.png","B03.png","B04.png","B05.png","B06.png","B07.png","B08.png","B09.png","B10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 264,
              y: 332,
              font_array: ["DN0.png","DN1.png","DN2.png","DN3.png","DN4.png","DN5.png","DN6.png","DN7.png","DN8.png","DN9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 219,
              y: 110,
              font_array: ["DN0.png","DN1.png","DN2.png","DN3.png","DN4.png","DN5.png","DN6.png","DN7.png","DN8.png","DN9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'C.png',
              unit_tc: 'C.png',
              unit_en: 'C.png',
              negative_image: '-.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 163,
              y: 371,
              week_en: ["D1.png","D2.png","D3.png","D4.png","D5.png","D6.png","D7.png"],
              week_tc: ["D1.png","D2.png","D3.png","D4.png","D5.png","D6.png","D7.png"],
              week_sc: ["D1.png","D2.png","D3.png","D4.png","D5.png","D6.png","D7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 126,
              month_startY: 329,
              month_sc_array: ["M01.png","M02.png","M03.png","M04.png","M05.png","M06.png","M07.png","M08.png","M09.png","M10.png","M11.png","M12.png"],
              month_tc_array: ["M01.png","M02.png","M03.png","M04.png","M05.png","M06.png","M07.png","M08.png","M09.png","M10.png","M11.png","M12.png"],
              month_en_array: ["M01.png","M02.png","M03.png","M04.png","M05.png","M06.png","M07.png","M08.png","M09.png","M10.png","M11.png","M12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 182,
              day_startY: 332,
              day_sc_array: ["DN0.png","DN1.png","DN2.png","DN3.png","DN4.png","DN5.png","DN6.png","DN7.png","DN8.png","DN9.png"],
              day_tc_array: ["DN0.png","DN1.png","DN2.png","DN3.png","DN4.png","DN5.png","DN6.png","DN7.png","DN8.png","DN9.png"],
              day_en_array: ["DN0.png","DN1.png","DN2.png","DN3.png","DN4.png","DN5.png","DN6.png","DN7.png","DN8.png","DN9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 105,
              hour_startY: 200,
              hour_array: ["H0.png","H1.png","H2.png","H3.png","H4.png","H5.png","H6.png","H7.png","H8.png","H9.png"],
              hour_zero: 1,
              hour_space: 3,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 270,
              minute_startY: 200,
              minute_array: ["H0.png","H1.png","H2.png","H3.png","H4.png","H5.png","H6.png","H7.png","H8.png","H9.png"],
              minute_zero: 1,
              minute_space: 3,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });




                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
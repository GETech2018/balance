/*
** Facemaker bundle tool v0.0.3
* *huamiOS watchface js version v4.4.0.1
* *Copyright © Huami. All Rights Reserved
*/


try {
	(() => {
		var __$$app$$__ = __$$hmAppManager$$__.currentApp;
		var __$$module$$__ = __$$app$$__.current;

		//drink is a name,can modify
		var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

		'use strict';

		//dynamic modify start
		let normal_img0 = '';
		let normal_img1 = '';
		let normal_img2 = '';
		let normal_random_bg3 = '';
		let normal_random_bg3_array = ['0005.png','0006.png','0007.png','0008.png','0009.png'];
		let normal_img4 = '';
		let normal_img5 = '';
		let normal_img6 = '';
		let normal_weather_imageset8 = '';
		let normal_temperature_current_imagecombo9 = '';
		let normal_week_imageset11 = '';
		let normal_month_imageset12 = '';
		let normal_date_imagecombo13 = '';
		let normal_steps_imagecombo15 = '';
		let normal_heart_current_imagecombo17 = '';
		let normal_battery_imagecombo19 = '';
		let normal_hour_imagecombo21 = '';
		let normal_minute_imagecombo22 = '';
		let normal_img23 = '';
		let normal_hour_rotary25 = '';
		let timeInterval;
		let normal_hour_rotary26 = '';
		let normal_minute_rotary27 = '';
		let normal_minute_rotary28 = '';
		let normal_second_rotary29 = '';
		let normal_second_rotary30 = '';
		let normal_random_bg_trigger33 = '';
		let normal_weather_shortcut34 = '';
		let normal_alarm_shortcut35 = '';
		let normal_calendar_shortcut36 = '';
		let normal_heart_shortcut37 = '';
		let normal_steps_shortcut38 = '';
		let idle_img40 = '';
		let idle_img41 = '';
		let idle_hour_rotary43 = '';
		let idle_minute_rotary44 = '';
		let idle_week_imageset46 = '';
		let idle_month_imageset47 = '';
		let idle_date_imagecombo48 = '';
		//dynamic modify end

		//not required
		const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

		__$$module$$__.module = DeviceRuntimeCore.WatchFace({
			init_view() {

				const timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
				let screenType = hmSetting.getScreenType();

				normal_img0 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					src: '0002.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img1 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					src: '0003.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img2 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					src: '0004.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_random_bg3 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					src: '0005.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img4 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 288,
					y: 242,
					w: 104,
					h: 29,
					src: '0010.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img5 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 150,
					y: 308,
					w: 19,
					h: 30,
					src: '0011.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img6 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 267,
					y: 312,
					w: 24,
					h: 24,
					src: '0012.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_weather_imageset8 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
					x: 192,
					y: 86,
					image_array: ["0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png","0023.png","0024.png","0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png","0033.png","0034.png","0035.png","0036.png","0037.png","0038.png","0013.png","0014.png","0016.png"],
					image_length: 29,
					type: hmUI.data_type.WEATHER_CURRENT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_temperature_current_imagecombo9 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 199,
					y: 173,
					font_array: ["0039.png","0040.png","0041.png","0042.png","0043.png","0044.png","0045.png","0046.png","0047.png","0048.png"],
					padding: false,
					h_space: -17,
					unit_sc: ["0050.png"],
					unit_tc: ["0050.png"],
					unit_en: ["0050.png"],
					negative_image: ["0049.png"],
					invalid_image: ["0049.png"],
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.WEATHER_CURRENT,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_week_imageset11 = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
					x: 84,
					y: 241,
					week_en: ["0051.png","0052.png","0053.png","0054.png","0055.png","0056.png","0057.png"],
					week_tc: ["0051.png","0052.png","0053.png","0054.png","0055.png","0056.png","0057.png"],
					week_sc: ["0051.png","0052.png","0053.png","0054.png","0055.png","0056.png","0057.png"],
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_month_imageset12 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
					month_startX: 141,
					month_startY: 214,
					month_sc_array: ["0058.png","0059.png","0060.png","0061.png","0062.png","0063.png","0064.png","0065.png","0066.png","0067.png","0068.png","0069.png"],
					month_tc_array: ["0058.png","0059.png","0060.png","0061.png","0062.png","0063.png","0064.png","0065.png","0066.png","0067.png","0068.png","0069.png"],
					month_en_array: ["0058.png","0059.png","0060.png","0061.png","0062.png","0063.png","0064.png","0065.png","0066.png","0067.png","0068.png","0069.png"],
					month_is_character: true,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_date_imagecombo13 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
					day_startX: 102,
					day_startY: 211,
					day_sc_array: ["0070.png","0071.png","0072.png","0073.png","0074.png","0075.png","0076.png","0077.png","0078.png","0079.png"],
					day_tc_array: ["0070.png","0071.png","0072.png","0073.png","0074.png","0075.png","0076.png","0077.png","0078.png","0079.png"],
					day_en_array: ["0070.png","0071.png","0072.png","0073.png","0074.png","0075.png","0076.png","0077.png","0078.png","0079.png"],
					day_zero: true,
					day_space: -12,
					day_align: hmUI.align.CENTER_H,
					day_is_character: false,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_steps_imagecombo15 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 172,
					y: 311,
					font_array: ["0080.png","0081.png","0082.png","0083.png","0084.png","0085.png","0086.png","0087.png","0088.png","0089.png"],
					padding: false,
					h_space: -5,
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.STEP,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_heart_current_imagecombo17 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 294,
					y: 311,
					font_array: ["0090.png","0091.png","0092.png","0093.png","0094.png","0095.png","0096.png","0097.png","0098.png","0099.png"],
					padding: false,
					h_space: -5,
					invalid_image: '0100.png',
					align_h: hmUI.align.LEFT,
					type: hmUI.data_type.HEART,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_battery_imagecombo19 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 207,
					y: 355,
					font_array: ["0101.png","0102.png","0103.png","0104.png","0105.png","0106.png","0107.png","0108.png","0109.png","0110.png"],
					padding: false,
					h_space: -5,
					unit_sc: '0111.png',
					unit_tc: '0111.png',
					unit_en: '0111.png',
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.BATTERY,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_hour_imagecombo21 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					hour_startX: 299,
					hour_startY: 215,
					hour_array: ["0112.png","0113.png","0114.png","0115.png","0116.png","0117.png","0118.png","0119.png","0120.png","0121.png"],
					hour_zero: true,
					hour_space: -6,
					hour_align: hmUI.align.CENTER_H,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_minute_imagecombo22 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					minute_startX: 344,
					minute_startY: 215,
					minute_array: ["0112.png","0113.png","0114.png","0115.png","0116.png","0117.png","0118.png","0119.png","0120.png","0121.png"],
					minute_zero: true,
					minute_space: -6,
					minute_align: hmUI.align.LEFT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img23 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 331,
					y: 209,
					w: 19,
					h: 40,
					src: '0122.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_hour_rotary25 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					center_x: 240,
					center_y: 239,
					pos_x: 0,
					pos_y: 0,
					src: '0123.png',
					enable: false,
					angle: 0,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_hour_rotary26 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					center_x: 240,
					center_y: 238,
					pos_x: 0,
					pos_y: 0,
					src: '0124.png',
					enable: false,
					angle: 0,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_minute_rotary27 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					center_x: 240,
					center_y: 240,
					pos_x: 0,
					pos_y: 0,
					src: '0125.png',
					enable: false,
					angle: 0,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_minute_rotary28 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					center_x: 240,
					center_y: 239,
					pos_x: 0,
					pos_y: 0,
					src: '0126.png',
					enable: false,
					angle: 0,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_second_rotary29 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					center_x: 240,
					center_y: 240,
					pos_x: 0,
					pos_y: 0,
					src: '0127.png',
					enable: false,
					angle: 0,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_second_rotary30 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					center_x: 240,
					center_y: 238,
					pos_x: 229,
					pos_y: 41,
					src: '0128.png',
					enable: false,
					angle: 0,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_random_bg_trigger33 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					src: '0129.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_random_bg_trigger33.addEventListener(hmUI.event.CLICK_DOWN, function() {
					normal_random_bg3.setProperty(hmUI.prop.SRC, normal_random_bg3_array[Math.floor(Math.random() * normal_random_bg3_array.length)]);
				});

				normal_weather_shortcut34 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 193,
					y: 109,
					w: 100,
					h: 100,
					src: '0129.png',
					type: hmUI.data_type.WEATHER_CURRENT,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_alarm_shortcut35 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 301,
					y: 190,
					w: 100,
					h: 100,
					src: '',
					type: hmUI.data_type.ALARM_CLOCK,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_calendar_shortcut36 = hmUI.createWidget(hmUI.widget.BUTTON, {
					x: 97,
					y: 193,
					w: 100,
					h: 100,
					text: '',
					normal_src: '',
					press_src: '',
					click_func: () => {
						hmApp.startApp({ url: 'ScheduleCalScreen', native: true });
					},
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_heart_shortcut37 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 277,
					y: 301,
					w: 100,
					h: 100,
					src: '',
					type: hmUI.data_type.HEART,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_steps_shortcut38 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 85,
					y: 217,
					w: 100,
					h: 100,
					src: '',
					type: hmUI.data_type.STEP,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				idle_img40 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					src: '0130.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_img41 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 269,
					y: 225,
					w: 129,
					h: 36,
					src: '0131.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_hour_rotary43 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					center_x: 240,
					center_y: 238,
					pos_x: 0,
					pos_y: 0,
					src: '0132.png',
					enable: false,
					angle: 0,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_minute_rotary44 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					center_x: 240,
					center_y: 239,
					pos_x: 0,
					pos_y: 0,
					src: '0133.png',
					enable: false,
					angle: 0,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_week_imageset46 = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
					x: 84,
					y: 241,
					week_en: ["0134.png","0135.png","0136.png","0137.png","0138.png","0139.png","0140.png"],
					week_tc: ["0134.png","0135.png","0136.png","0137.png","0138.png","0139.png","0140.png"],
					week_sc: ["0134.png","0135.png","0136.png","0137.png","0138.png","0139.png","0140.png"],
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_month_imageset47 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
					month_startX: 141,
					month_startY: 214,
					month_sc_array: ["0141.png","0142.png","0143.png","0144.png","0145.png","0146.png","0147.png","0148.png","0149.png","0150.png","0151.png","0152.png"],
					month_tc_array: ["0141.png","0142.png","0143.png","0144.png","0145.png","0146.png","0147.png","0148.png","0149.png","0150.png","0151.png","0152.png"],
					month_en_array: ["0141.png","0142.png","0143.png","0144.png","0145.png","0146.png","0147.png","0148.png","0149.png","0150.png","0151.png","0152.png"],
					month_is_character: true,
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_date_imagecombo48 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
					day_startX: 102,
					day_startY: 211,
					day_sc_array: ["0153.png","0154.png","0155.png","0156.png","0157.png","0158.png","0159.png","0160.png","0161.png","0162.png"],
					day_tc_array: ["0153.png","0154.png","0155.png","0156.png","0157.png","0158.png","0159.png","0160.png","0161.png","0162.png"],
					day_en_array: ["0153.png","0154.png","0155.png","0156.png","0157.png","0158.png","0159.png","0160.png","0161.png","0162.png"],
					day_zero: true,
					day_space: -12,
					day_align: hmUI.align.CENTER_H,
					day_is_character: false,
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				function updateTime() {
					if (normal_hour_rotary25) {
						normal_hour_rotary25.setProperty(hmUI.prop.ANGLE, (0 + parseInt((timeSensor.hour % 12) || 12) * (30 * 1) + (timeSensor.minute / 60) * (30 * 1)));
					}
					if (normal_hour_rotary26) {
						normal_hour_rotary26.setProperty(hmUI.prop.ANGLE, (0 + parseInt((timeSensor.hour % 12) || 12) * (30 * 1) + (timeSensor.minute / 60) * (30 * 1)));
					}
					if (normal_minute_rotary27) {
						normal_minute_rotary27.setProperty(hmUI.prop.ANGLE, (0 + (timeSensor.minute * (6 * 1))));
					}
					if (normal_minute_rotary28) {
						normal_minute_rotary28.setProperty(hmUI.prop.ANGLE, (0 + (timeSensor.minute * (6 * 1))));
					}
					if (normal_second_rotary29) {
						normal_second_rotary29.setProperty(hmUI.prop.ANGLE, (0 + (timeSensor.second * (6 * 1))));
					}
					if (normal_second_rotary30) {
						normal_second_rotary30.setProperty(hmUI.prop.ANGLE, (0 + (timeSensor.second * (6 * 1))));
					}
					if (idle_hour_rotary43) {
						idle_hour_rotary43.setProperty(hmUI.prop.ANGLE, (0 + parseInt((timeSensor.hour % 12) || 12) * (30 * 1) + (timeSensor.minute / 60) * (30 * 1)));
					}
					if (idle_minute_rotary44) {
						idle_minute_rotary44.setProperty(hmUI.prop.ANGLE, (0 + (timeSensor.minute * (6 * 1))));
					}
				}

				timeSensor.addEventListener(hmSensor.event.CHANGE, function() {
					updateTime();
				});

				const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
					resume_call: (function () {
						updateTime();
						timeInterval = setInterval(updateTime, 1000);
					}),
					pause_call: (function () {
						clearInterval(timeInterval);
					}),
				})
			},

		onInit() {
			console.log('index page.js on init invoke')
			this.init_view()
		},
		onReady() {
			console.log('index page.js on ready invoke')
		},
		onShow() {
			console.log('index page.js on show invoke')
		},
		onHide() {
			console.log('index page.js on hide invoke')
		},
		onDestroy() {
			console.log('index page.js on destroy invoke')
		},
	});	})()
} catch (e) {
	console.log(e)
}
﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

let normal_image_img_hour = ''
        let normal_image_img_minute = ''
        let normal_image_img_second = ''
        let normal_image1 = ''
        let normal_timerTimeUpdate = undefined;
  
      // activate on
        let btn_element_1 = ''
        let elementnumber_1 = 1
        let total_elemente = 2
        let cc = 0

        function click_elemente() {
            if(elementnumber_1==total_elemente) {
            elementnumber_1=1;
                UpdateElementeOne();
                }
            else {
                elementnumber_1=elementnumber_1+1;
                if(elementnumber_1==2) {
                  UpdateElementeTwo();
                }

            }
            if(elementnumber_1==1) hmUI.showToast({text: 'Activity ON'});
            if(elementnumber_1==2) hmUI.showToast({text: 'Activity OFF'});
        }

        //Activity on
        function UpdateElementeOne(){
        normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_digital_clock_img_time_AmPm.setProperty(hmUI.prop.VISIBLE, true);
        normal_digital_clock_img_time.setProperty(hmUI.prop.VISIBLE, true);
        normal_digital_clock_hour_separator_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_frame_animation_1.setProperty(hmUI.prop.VISIBLE, true);
        normal_stopwatch_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
        normal_countdown_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);

        normal_sunrise_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_temperature_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);

        }

        //Activity off
        function UpdateElementeTwo(){
        normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital_clock_img_time_AmPm.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital_clock_img_time.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital_clock_hour_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_frame_animation_1.setProperty(hmUI.prop.VISIBLE, false);
        normal_stopwatch_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_countdown_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);


        normal_sunrise_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
        normal_temperature_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);

        }

        // Weather on off
        let btn_element_2 = ''
        let elementnumber_2 = 1
        let total_elemente2 = 2

        function click_elemente2() {
            if(elementnumber_2==total_elemente2) {
            elementnumber_2=1;
                UpdateElemente2One();
                }
            else {
                elementnumber_2=elementnumber_2+1;
                if(elementnumber_2==2) {
                  UpdateElemente2Two();
                }

            }
            if(elementnumber_2==1) hmUI.showToast({text: 'Weather ON'});
            if(elementnumber_2==2) hmUI.showToast({text: 'Weahter OFF'});
        }

        //weahter on
        function UpdateElemente2One(){
        normal_date_img_date_day.setProperty(hmUI.prop.VISIBLE, true);
        normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);
        normal_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_date_img_date_week_img.setProperty(hmUI.prop.VISIBLE, true);


        }

        //weather off
        function UpdateElemente2Two(){
        normal_date_img_date_day.setProperty(hmUI.prop.VISIBLE, false);
        normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
        normal_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_date_img_date_week_img.setProperty(hmUI.prop.VISIBLE, false);


        }


        // activity color
        let btn_element_3= ''
        let elementnumber_3= 1
        let total_elemente3 = 4

        function click_elemente3() {

              if(elementnumber_1==1){
            if(elementnumber_3==total_elemente3) {
            elementnumber_3=1;
                UpdateElemente3One();
                }
            else {
                elementnumber_3=elementnumber_3+1;
                if(elementnumber_3==2) {
                  UpdateElemente3Two();
                }

               if(elementnumber_3==3) {
                  UpdateElemente3Three();
                }

               if(elementnumber_3==4) {
                  UpdateElemente3Four();
                }

            }
            if(elementnumber_3==1) hmUI.showToast({text: 'Blue'});
            if(elementnumber_3==2) hmUI.showToast({text: 'Orange'});
            if(elementnumber_3==3) hmUI.showToast({text: 'Pink'});
           if(elementnumber_3==4) hmUI.showToast({text: 'Yellow'});
        }
}

        //changecolor activity
        function UpdateElemente3One(){
        normal_step_icon_img.setProperty(hmUI.prop.SRC, "ActivityDesk.png");


        }

        //changecolor activity
        function UpdateElemente3Two(){
       normal_step_icon_img.setProperty(hmUI.prop.SRC, "ActivityDesk2.png");
        }


        //changecolor activity
        function UpdateElemente3Three(){
       normal_step_icon_img.setProperty(hmUI.prop.SRC, "ActivityDesk3.png");
        }

        //changecolor activity
        function UpdateElemente3Four(){
       normal_step_icon_img.setProperty(hmUI.prop.SRC, "ActivityDesk4.png");
        }
 
        //dynamic modify end


    // color weather
        let btn_element_4= ''
        let elementnumber_4= 1
        let total_elemente4 = 4

        function click_elemente4() {

 if(elementnumber_2==1){
            if(elementnumber_4==total_elemente4) {
            elementnumber_4=1;
                UpdateElemente4One();
                }
            else {
                elementnumber_4=elementnumber_4+1;
                if(elementnumber_4==2) {
                  UpdateElemente4Two();
                }
               if(elementnumber_4==3) {
                  UpdateElemente4Three();
                }

               if(elementnumber_4==4) {
                  UpdateElemente4Four();
                }

            }
            if(elementnumber_4==1) hmUI.showToast({text: 'Blue'});
            if(elementnumber_4==2) hmUI.showToast({text: 'Orange'});
            if(elementnumber_4==3) hmUI.showToast({text: 'Pink'});
           if(elementnumber_4==4) hmUI.showToast({text: 'Yellow'});
        }
 }

        //color weather
        function UpdateElemente4One(){
	normal_temperature_icon_img.setProperty(hmUI.prop.SRC, "weather_desk.png");


        }

        //hand weather
        function UpdateElemente4Two(){
	normal_temperature_icon_img.setProperty(hmUI.prop.SRC, "weather_desk2.png");
         }


        //hand weather
        function UpdateElemente4Three(){
	normal_temperature_icon_img.setProperty(hmUI.prop.SRC, "weather_desk3.png");
        }
        //hand weather
        function UpdateElemente4Four(){
	normal_temperature_icon_img.setProperty(hmUI.prop.SRC, "weather_desk4.png");
        }



       // chang color  activity & weather
        let btn_element_5 = ''
        let elementnumber_5 = 1
        let total_elemente5 = 4

        function click_elemente5() {
    if(elementnumber_1==1 && elementnumber_2==1){
            if(elementnumber_5 ==total_elemente5) {
            elementnumber_5 =1;
                UpdateElemente5One();
                }
            else {
                elementnumber_5 =elementnumber_5 +1;
                if(elementnumber_5 ==2) {
                  UpdateElemente5Two();
                }

              if(elementnumber_5==3) {
                  UpdateElemente5Three();
                }

               if(elementnumber_5==4) {
                  UpdateElemente5Four();
                }

            }
            if(elementnumber_5==1) hmUI.showToast({text: 'Blue'});
            if(elementnumber_5==2) hmUI.showToast({text: 'Orange'});
            if(elementnumber_5==3) hmUI.showToast({text: 'Pink'});
           if(elementnumber_5==4) hmUI.showToast({text: 'Yellow'});
        }
 }

        //color 1
        function UpdateElemente5One(){
	normal_temperature_icon_img.setProperty(hmUI.prop.SRC, "weather_desk.png");
            normal_step_icon_img.setProperty(hmUI.prop.SRC, "ActivityDesk.png");

        }

        //color 2
        function UpdateElemente5Two(){
	normal_temperature_icon_img.setProperty(hmUI.prop.SRC, "weather_desk2.png");
            normal_step_icon_img.setProperty(hmUI.prop.SRC, "ActivityDesk2.png");
        }


        //color 3
        function UpdateElemente5Three(){
	normal_temperature_icon_img.setProperty(hmUI.prop.SRC, "weather_desk3.png");
            normal_step_icon_img.setProperty(hmUI.prop.SRC, "ActivityDesk3.png");
        }

        //color4
        function UpdateElemente5Four(){
	normal_temperature_icon_img.setProperty(hmUI.prop.SRC, "weather_desk4.png");
            normal_step_icon_img.setProperty(hmUI.prop.SRC, "ActivityDesk4.png");
        }
        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_icon_img = ''
        let normal_temperature_current_text_img = ''
        let normal_date_img_date_week_img = ''
        let normal_step_icon_img = ''
        let normal_step_current_text_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_calorie_image_progress_img_level = ''
        let normal_battery_image_progress_img_level = ''
        let normal_battery_icon_img = ''
        let normal_distance_text_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_frame_animation_1 = ''
        let idle_background_bg_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_step_icon_img = ''
        let idle_step_current_text_img = ''
        let idle_step_image_progress_img_level = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''
        let idle_calorie_image_progress_img_level = ''
        let idle_battery_image_progress_img_level = ''
        let idle_battery_icon_img = ''
        let idle_distance_text_text_img = ''
        let idle_heart_rate_icon_img = ''
        let idle_heart_rate_text_text_img = ''
        let idle_heart_rate_image_progress_img_level = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'sector13.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('user_script.js');
            // start user_script.js
let screenType = hmSetting.getScreenType();

           normal_image_img_hour = hmUI.createWidget(hmUI.widget.IMG, {
              x: 147,
              y: 88,
              src: 'h_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,

            });

           normal_image_img_minute = hmUI.createWidget(hmUI.widget.IMG, {
              x: 198,
              y: 15,
              src: 'ACT_Black_Font_0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,

            });


           normal_image_img_second = hmUI.createWidget(hmUI.widget.IMG, {
              x: 198,
              y: 15,
              src: 's0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,

            });
            

          const time = hmSensor.createSensor(hmSensor.id.TIME);

            function time_image_call() {

                console.log('update scales TIME');
                
               if (screenType != hmSetting.screen_type.AOD) {


          let image_second = "s_"+ time.second +".png"
          let bbb= time.second * 20
                  normal_image_img_second.setProperty(hmUI.prop.MORE, {
              x: 198,
              y: 15,
              src: image_second,
              show_level: hmUI.show_level.ONLY_NORMAL,
                });       

          let image_minute = "m_" + time.minute +".png"
                  normal_image_img_minute.setProperty(hmUI.prop.MORE, {
              x: 198,
              y: 15,
              src: image_minute,
              show_level: hmUI.show_level.ONLY_NORMAL,
                });  


          
          let image_hour = "h_"+ time.hour +".png"

           if ( time.hour == 0 ) { image_hour = "h_12.png"};
 
                  normal_image_img_hour.setProperty(hmUI.prop.MORE, {
              x: 147,
              y: 88,
              src: image_hour,
              show_level: hmUI.show_level.ONLY_NORMAL,
                });  


 //hmUI.showToast({text: time.hour + ":" + time.minute +":" + time.second});
                  };
                };


                normal_image1 = hmUI.createWidget(hmUI.widget.IMG, {
              x: 233,
              y: 55,
              src: 'linestep.png',
              show_level: hmUI.show_level.ONLY_NORMAL,

            });
            // end user_script.js

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 273,
              y: 428,
              src: 'System_BT_OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 455,
              y: 237,
              src: 'System_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 112,
              month_startY: 139,
              month_sc_array: ["month_icon_01.png","month_icon_02.png","month_icon_03.png","month_icon_04.png","month_icon_05.png","month_icon_06.png","month_icon_07.png","month_icon_08.png","month_icon_09.png","month_icon_10.png","month_icon_11.png","month_icon_12.png"],
              month_tc_array: ["month_icon_01.png","month_icon_02.png","month_icon_03.png","month_icon_04.png","month_icon_05.png","month_icon_06.png","month_icon_07.png","month_icon_08.png","month_icon_09.png","month_icon_10.png","month_icon_11.png","month_icon_12.png"],
              month_en_array: ["month_icon_01.png","month_icon_02.png","month_icon_03.png","month_icon_04.png","month_icon_05.png","month_icon_06.png","month_icon_07.png","month_icon_08.png","month_icon_09.png","month_icon_10.png","month_icon_11.png","month_icon_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 54,
              day_startY: 176,
              day_sc_array: ["Act_font_0.png","Act_font_1.png","Act_font_2.png","Act_font_3.png","Act_font_4.png","Act_font_5.png","Act_font_6.png","Act_font_7.png","Act_font_8.png","Act_font_9.png"],
              day_tc_array: ["Act_font_0.png","Act_font_1.png","Act_font_2.png","Act_font_3.png","Act_font_4.png","Act_font_5.png","Act_font_6.png","Act_font_7.png","Act_font_8.png","Act_font_9.png"],
              day_en_array: ["Act_font_0.png","Act_font_1.png","Act_font_2.png","Act_font_3.png","Act_font_4.png","Act_font_5.png","Act_font_6.png","Act_font_7.png","Act_font_8.png","Act_font_9.png"],
              day_zero: 0,
              day_space: 5,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 53,
              y: 284,
              image_array: ["weather_icon_01.png","weather_icon_02.png","weather_icon_03.png","weather_icon_04.png","weather_icon_05.png","weather_icon_06.png","weather_icon_07.png","weather_icon_08.png","weather_icon_09.png","weather_icon_10.png","weather_icon_11.png","weather_icon_12.png","weather_icon_13.png","weather_icon_14.png","weather_icon_15.png","weather_icon_16.png","weather_icon_17.png","weather_icon_18.png","weather_icon_19.png","weather_icon_20.png","weather_icon_21.png","weather_icon_22.png","weather_icon_23.png","weather_icon_24.png","weather_icon_25.png","weather_icon_26.png","weather_icon_27.png","weather_icon_28.png","weather_icon_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 7,
              y: 93,
              src: 'weather_desk.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 33,
              y: 251,
              font_array: ["Act_small_font_0.png","Act_small_font_1.png","Act_small_font_2.png","Act_small_font_3.png","Act_small_font_4.png","Act_small_font_5.png","Act_small_font_6.png","Act_small_font_7.png","Act_small_font_8.png","Act_small_font_9.png"],
              padding: false,
              h_space: 5,
              unit_sc: 'Weather_symbo1.png',
              unit_tc: 'Weather_symbo1.png',
              unit_en: 'Weather_symbo1.png',
              negative_image: 'Weather_symbo2.png',
              invalid_image: 'Weather_symbo2.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 73,
              y: 142,
              week_en: ["week1.png","week2.png","week3.png","week4.png","week5.png","week6.png","week7.png"],
              week_tc: ["week1.png","week2.png","week3.png","week4.png","week5.png","week6.png","week7.png"],
              week_sc: ["week1.png","week2.png","week3.png","week4.png","week5.png","week6.png","week7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 47,
              y: 39,
              src: 'ActivityDesk.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 105,
              y: 193,
              font_array: ["Act_font_0.png","Act_font_1.png","Act_font_2.png","Act_font_3.png","Act_font_4.png","Act_font_5.png","Act_font_6.png","Act_font_7.png","Act_font_8.png","Act_font_9.png"],
              padding: false,
              h_space: 7,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 304,
              y: 76,
              image_array: ["step01.png","step02.png","step03.png","step04.png","step05.png","step06.png","step07.png","step08.png","step09.png","step10.png","step11.png","step12.png","step13.png","step14.png","step15.png","step16.png","step17.png","step18.png","step19.png"],
              image_length: 19,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 339,
              am_y: 250,
              am_sc_path: 'Clock_AM.png',
              am_en_path: 'Clock_AM.png',
              pm_x: 339,
              pm_y: 250,
              pm_sc_path: 'Clock_PM.png',
              pm_en_path: 'Clock_PM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 103,
              hour_startY: 260,
              hour_array: ["Time_font_0.png","Time_font_1.png","Time_font_2.png","Time_font_3.png","Time_font_4.png","Time_font_5.png","Time_font_6.png","Time_font_7.png","Time_font_8.png","Time_font_9.png"],
              hour_zero: 1,
              hour_space: 7,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 231,
              minute_startY: 260,
              minute_array: ["Time_font_0.png","Time_font_1.png","Time_font_2.png","Time_font_3.png","Time_font_4.png","Time_font_5.png","Time_font_6.png","Time_font_7.png","Time_font_8.png","Time_font_9.png"],
              minute_zero: 1,
              minute_space: 7,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 208,
              y: 260,
              src: 'Time_symbo.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 380,
              y: 298,
              image_array: ["cal01.png","cal02.png","cal03.png","cal04.png","cal05.png","cal06.png","cal07.png","cal08.png","cal09.png","cal10.png"],
              image_length: 10,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 299,
              y: 242,
              image_array: ["batt01.png","batt02.png","batt03.png","batt04.png","batt05.png","batt06.png","batt07.png","batt08.png","batt09.png","batt10.png","batt11.png","batt12.png","batt13.png","batt14.png","batt15.png","batt16.png","batt17.png","batt18.png","batt19.png","batt20.png"],
              image_length: 20,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 292,
              y: 239,
              src: 'line_Batt.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 123,
              y: 126,
              font_array: ["Act_small_font_0.png","Act_small_font_1.png","Act_small_font_2.png","Act_small_font_3.png","Act_small_font_4.png","Act_small_font_5.png","Act_small_font_6.png","Act_small_font_7.png","Act_small_font_8.png","Act_small_font_9.png"],
              padding: false,
              h_space: 3,
              unit_sc: 'Act_small_KM.png',
              unit_tc: 'Act_small_KM.png',
              unit_en: 'Act_small_KM.png',
              imperial_unit_sc: 'Act_small_Mi.png',
              imperial_unit_tc: 'Act_small_Mi.png',
              imperial_unit_en: 'Act_small_Mi.png',
              dot_image: 'act_small_dot.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 191,
              y: 335,
              font_array: ["Act_small_font_0.png","Act_small_font_1.png","Act_small_font_2.png","Act_small_font_3.png","Act_small_font_4.png","Act_small_font_5.png","Act_small_font_6.png","Act_small_font_7.png","Act_small_font_8.png","Act_small_font_9.png"],
              padding: false,
              h_space: 9,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 380,
              y: 84,
              image_array: ["zone1.png","zone2.png","zone3.png","zone4.png","zone5.png","zone6.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_frame_animation_1 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
              x: 140,
              y: 334,
              anim_path: "animation",
              anim_ext: "png",
              anim_prefix: "heart",
              anim_fps: 5,
              anim_size: 4,
              repeat_count: 0,
              anim_repeat: true,
              anim_status:hmUI.anim_status.START,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'sector13.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 273,
              y: 428,
              src: 'System_BT_OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 455,
              y: 237,
              src: 'System_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 47,
              y: 39,
              src: 'ActivityDesk.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 105,
              y: 193,
              font_array: ["Act_font_0.png","Act_font_1.png","Act_font_2.png","Act_font_3.png","Act_font_4.png","Act_font_5.png","Act_font_6.png","Act_font_7.png","Act_font_8.png","Act_font_9.png"],
              padding: false,
              h_space: 7,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 304,
              y: 76,
              image_array: ["step01.png","step02.png","step03.png","step04.png","step05.png","step06.png","step07.png","step08.png","step09.png","step10.png","step11.png","step12.png","step13.png","step14.png","step15.png","step16.png","step17.png","step18.png","step19.png"],
              image_length: 19,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 339,
              am_y: 250,
              am_sc_path: 'Clock_AM.png',
              am_en_path: 'Clock_AM.png',
              pm_x: 339,
              pm_y: 250,
              pm_sc_path: 'Clock_PM.png',
              pm_en_path: 'Clock_PM.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 103,
              hour_startY: 260,
              hour_array: ["Time_font_0.png","Time_font_1.png","Time_font_2.png","Time_font_3.png","Time_font_4.png","Time_font_5.png","Time_font_6.png","Time_font_7.png","Time_font_8.png","Time_font_9.png"],
              hour_zero: 1,
              hour_space: 7,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 231,
              minute_startY: 260,
              minute_array: ["Time_font_0.png","Time_font_1.png","Time_font_2.png","Time_font_3.png","Time_font_4.png","Time_font_5.png","Time_font_6.png","Time_font_7.png","Time_font_8.png","Time_font_9.png"],
              minute_zero: 1,
              minute_space: 7,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 208,
              y: 260,
              src: 'Time_symbo.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 380,
              y: 298,
              image_array: ["cal01.png","cal02.png","cal03.png","cal04.png","cal05.png","cal06.png","cal07.png","cal08.png","cal09.png","cal10.png"],
              image_length: 10,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 299,
              y: 242,
              image_array: ["batt01.png","batt02.png","batt03.png","batt04.png","batt05.png","batt06.png","batt07.png","batt08.png","batt09.png","batt10.png","batt11.png","batt12.png","batt13.png","batt14.png","batt15.png","batt16.png","batt17.png","batt18.png","batt19.png","batt20.png"],
              image_length: 20,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 292,
              y: 239,
              src: 'line_Batt.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 123,
              y: 126,
              font_array: ["Act_small_font_0.png","Act_small_font_1.png","Act_small_font_2.png","Act_small_font_3.png","Act_small_font_4.png","Act_small_font_5.png","Act_small_font_6.png","Act_small_font_7.png","Act_small_font_8.png","Act_small_font_9.png"],
              padding: false,
              h_space: 3,
              unit_sc: 'Act_small_KM.png',
              unit_tc: 'Act_small_KM.png',
              unit_en: 'Act_small_KM.png',
              imperial_unit_sc: 'Act_small_Mi.png',
              imperial_unit_tc: 'Act_small_Mi.png',
              imperial_unit_en: 'Act_small_Mi.png',
              dot_image: 'act_small_dot.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 140,
              y: 334,
              src: 'icon_heart.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 191,
              y: 335,
              font_array: ["Act_small_font_0.png","Act_small_font_1.png","Act_small_font_2.png","Act_small_font_3.png","Act_small_font_4.png","Act_small_font_5.png","Act_small_font_6.png","Act_small_font_7.png","Act_small_font_8.png","Act_small_font_9.png"],
              padding: false,
              h_space: 9,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 380,
              y: 84,
              image_array: ["zone1.png","zone2.png","zone3.png","zone4.png","zone5.png","zone6.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 157,
              y: 266,
              w: 52,
              h: 34,
              src: '0_Empty.png',
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 251,
              y: 264,
              w: 54,
              h: 36,
              src: '0_Empty.png',
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 436,
              y: 230,
              w: 40,
              h: 45,
              src: '0_Empty.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 52,
              y: 302,
              w: 76,
              h: 63,
              src: '0_Empty.png',
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 42,
              y: 243,
              w: 79,
              h: 44,
              src: '0_Empty.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 368,
              y: 376,
              w: 48,
              h: 47,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 425,
              y: 128,
              w: 47,
              h: 38,
              src: '0_Empty.png',
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 426,
              y: 170,
              w: 50,
              h: 35,
              src: '0_Empty.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 295,
              y: 40,
              w: 59,
              h: 44,
              src: '0_Empty.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('user_script_end.js');
            // start user_script_end.js

/////////////////Show element at the first time //////////

if (cc==0) {
  cc = 1

        normal_sunrise_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_temperature_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
 
}



           //  Activity on / off
            btn_element_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 157,
              y: 439,
              text: '',
              w: 159,
              h: 53,
              normal_src: '0_Empty.png',
              press_src: '0_Empty.png',
              click_func: () => {
               click_elemente();
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btn_element_1.setProperty(hmUI.prop.VISIBLE, true);
            // Change background shortcut end

///////////////////////////////

           // Weather on/off
            btn_element_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 5,
              y: 145,
              text: '',
              w: 53,
              h: 159,
              normal_src: '0_Empty.png',
              press_src: '0_Empty.png',
              click_func: () => {
               click_elemente2();
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btn_element_2.setProperty(hmUI.prop.VISIBLE, true);
            // Change background shortcut end

//////////////////////////////

           // Change color Activity

            btn_element_3= hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 146,
              y: 10,
             text: '',
              w: 53,
              h: 53,
              normal_src: '0_Empty.png',
              press_src: '0_Empty.png',
              click_func: () => {
               click_elemente3();
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btn_element_2.setProperty(hmUI.prop.VISIBLE, true);

            // Change background shortcut end


///////////////////////////////

           //change color weather
            btn_element_4= hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 58,
              y: 49,
              text: '',
              w: 53,
              h: 53,
              normal_src: '0_Empty.png',
              press_src: '0_Empty.png',
              click_func: () => {
               click_elemente4();
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btn_element_2.setProperty(hmUI.prop.VISIBLE, true);
            // end



           // Change color  Activity & Weahter
            btn_element_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 217,
              y: 11,
              text: '',
              w: 53,
              h: 63,
              normal_src: '0_Empty.png',
              press_src: '0_Empty.png',
              click_func: () => {
               click_elemente5();
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btn_element_2.setProperty(hmUI.prop.VISIBLE, true);
            //  end
            // end user_script_end.js

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);

                console.log('resume_call.js');
                // start resume_call.js

             time_image_call();
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerTimeUpdate) {
                    normal_timerTimeUpdate = timer.createTimer(0, 1000, (function (option) {  // perhaps you may need to reduce the timer
                      time_image_call();
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType
                // end resume_call.js

              }),
              pause_call: (function () {
                console.log('pause_call()');
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);

                console.log('pause_call.js');
                // start pause_call.js

                if (normal_timerTimeUpdate) {
                  timer.stopTimer(normal_timerTimeUpdate);
                  normal_timerTimeUpdate = undefined;
                }

                // end pause_call.js

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
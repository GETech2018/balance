﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

// Start color change
        let colornumber_main = 1
        let totalcolors_main = 4
        let namecolor_main = ''
        let deviceInfo = hmSetting.getDeviceInfo();
        let Folder = ''

        function click_Color() {
            if(colornumber_main>=totalcolors_main) {
            colornumber_main=1;
                }
            else {
                colornumber_main=colornumber_main+1;
            }

if ( colornumber_main == 1) { namecolor_main = "Style 1"
Folder = ""
}
if ( colornumber_main == 2) { namecolor_main = "Style 2"
Folder = "Style2/"
}
if ( colornumber_main == 3) { namecolor_main = "Style 3"
Folder = "Style3/"
}
if ( colornumber_main == 4) { namecolor_main = "Style 4"
Folder = "Style4/"
}

hmUI.showToast({text: namecolor_main });


             normal_background_bg_img.setProperty(hmUI.prop.SRC, Folder+"main1.png");
                           
  

            normal_digital_clock_img_time_minute.setProperty(hmUI.prop.MORE, {
              minute_startX: deviceInfo.width / 480 * 155,
              minute_startY: deviceInfo.height / 480 * 243,
              minute_array: [Folder+"T_Min0.png",Folder+"T_Min1.png",Folder+"T_Min2.png",Folder+"T_Min3.png",Folder+"T_Min4.png",Folder+"T_Min5.png",Folder+"T_Min6.png",Folder+"T_Min7.png",Folder+"T_Min8.png",Folder+"T_Min9.png"],
              minute_zero: 1,
              minute_space: 5,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            normal_date_img_date_day.setProperty(hmUI.prop.MORE, {
              day_startX: deviceInfo.width / 480 * 209,
              day_startY: deviceInfo.height / 480 * 424,
              day_sc_array: [Folder+"Day0.png",Folder+"Day1.png",Folder+"Day2.png",Folder+"Day3.png",Folder+"Day4.png",Folder+"Day5.png",Folder+"Day6.png",Folder+"Day7.png",Folder+"Day8.png",Folder+"Day9.png"],
              day_tc_array:  [Folder+"Day0.png",Folder+"Day1.png",Folder+"Day2.png",Folder+"Day3.png",Folder+"Day4.png",Folder+"Day5.png",Folder+"Day6.png",Folder+"Day7.png",Folder+"Day8.png",Folder+"Day9.png"],
              day_en_array: [Folder+"Day0.png",Folder+"Day1.png",Folder+"Day2.png",Folder+"Day3.png",Folder+"Day4.png",Folder+"Day5.png",Folder+"Day6.png",Folder+"Day7.png",Folder+"Day8.png",Folder+"Day9.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });




           normal_heart_rate_image_progress_img_level.setProperty(hmUI.prop.MORE, {
              x: 0,
              y: 0,
              image_array: [Folder+"Zone1.png",Folder+"Zone2.png",Folder+"Zone3.png",Folder+"Zone4.png",Folder+"Zone5.png",Folder+"Zone6.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level.setProperty(hmUI.prop.MORE, {
              x: 0,
              y: 0,
              image_array: [Folder+"P_step1.png",Folder+"P_step2.png",Folder+"P_step3.png",Folder+"P_step4.png",Folder+"P_step5.png",Folder+"P_step6.png",Folder+"P_step7.png"],
              image_length: 7,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

const result = hmSetting.setScreenOff()

      }
        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_image_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_text_separator_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_calorie_current_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_step_current_text_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_week_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time_minute = ''
        let normal_digital_clock_img_time_hour = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_digital_clock_img_time_second = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_week_img = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time_minute = ''
        let idle_digital_clock_img_time_hour = ''
        let idle_digital_clock_hour_separator_img = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'main1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 413,
              y: 156,
              src: 'System_BT_OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 55,
              y: 159,
              src: 'System_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'heart_Batt_BG.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 86,
              y: 366,
              font_array: ["Act0.png","Act1.png","Act2.png","Act3.png","Act4.png","Act5.png","Act6.png","Act7.png","Act8.png","Act9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Batt_unit.png',
              unit_tc: 'Batt_unit.png',
              unit_en: 'Batt_unit.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 80,
              y: 344,
              src: 'icon_Battery.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 83,
              y: 88,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 350,
              y: 142,
              font_array: ["Act0.png","Act1.png","Act2.png","Act3.png","Act4.png","Act5.png","Act6.png","Act7.png","Act8.png","Act9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Weather_symbo1.png',
              unit_tc: 'Weather_symbo1.png',
              unit_en: 'Weather_symbo1.png',
              negative_image: 'Weather_symbo2.png',
              invalid_image: 'Weather_symbo2.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 351,
              y: 88,
              image_array: ["Weather01.png","Weather02.png","Weather03.png","Weather04.png","Weather05.png","Weather06.png","Weather07.png","Weather08.png","Weather09.png","Weather10.png","Weather11.png","Weather12.png","Weather13.png","Weather14.png","Weather15.png","Weather16.png","Weather17.png","Weather18.png","Weather19.png","Weather20.png","Weather21.png","Weather22.png","Weather23.png","Weather24.png","Weather25.png","Weather26.png","Weather27.png","Weather28.png","Weather29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 40,
              y: 299,
              font_array: ["Act0.png","Act1.png","Act2.png","Act3.png","Act4.png","Act5.png","Act6.png","Act7.png","Act8.png","Act9.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'Cal_unit.png',
              unit_tc: 'Cal_unit.png',
              unit_en: 'Cal_unit.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 30,
              y: 266,
              font_array: ["Act0.png","Act1.png","Act2.png","Act3.png","Act4.png","Act5.png","Act6.png","Act7.png","Act8.png","Act9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Dis_KM.png',
              unit_tc: 'Dis_KM.png',
              unit_en: 'Dis_KM.png',
              imperial_unit_sc: 'Dis_Mi.png',
              imperial_unit_tc: 'Dis_Mi.png',
              imperial_unit_en: 'Dis_Mi.png',
              dot_image: 'Dis_dot.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 384,
              y: 235,
              font_array: ["Act0.png","Act1.png","Act2.png","Act3.png","Act4.png","Act5.png","Act6.png","Act7.png","Act8.png","Act9.png"],
              padding: false,
              h_space: 2,
              invalid_image: 'Act0.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 0,
              y: 0,
              image_array: ["Zone1.png","Zone2.png","Zone3.png","Zone4.png","Zone5.png","Zone6.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 30,
              y: 235,
              font_array: ["Act0.png","Act1.png","Act2.png","Act3.png","Act4.png","Act5.png","Act6.png","Act7.png","Act8.png","Act9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 0,
              y: 0,
              image_array: ["P_step1.png","P_step2.png","P_step3.png","P_step4.png","P_step5.png","P_step6.png","P_step7.png"],
              image_length: 7,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 209,
              day_startY: 424,
              day_sc_array: ["Day0.png","Day1.png","Day2.png","Day3.png","Day4.png","Day5.png","Day6.png","Day7.png","Day8.png","Day9.png"],
              day_tc_array: ["Day0.png","Day1.png","Day2.png","Day3.png","Day4.png","Day5.png","Day6.png","Day7.png","Day8.png","Day9.png"],
              day_en_array: ["Day0.png","Day1.png","Day2.png","Day3.png","Day4.png","Day5.png","Day6.png","Day7.png","Day8.png","Day9.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 169,
              month_startY: 389,
              month_sc_array: ["Month01.png","Month02.png","Month03.png","Month04.png","Month05.png","Month06.png","Month07.png","Month08.png","Month09.png","Month10.png","Month11.png","Month12.png"],
              month_tc_array: ["Month01.png","Month02.png","Month03.png","Month04.png","Month05.png","Month06.png","Month07.png","Month08.png","Month09.png","Month10.png","Month11.png","Month12.png"],
              month_en_array: ["Month01.png","Month02.png","Month03.png","Month04.png","Month05.png","Month06.png","Month07.png","Month08.png","Month09.png","Month10.png","Month11.png","Month12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 165,
              y: 63,
              week_en: ["Week1.png","Week2.png","Week3.png","Week4.png","Week5.png","Week6.png","Week7.png"],
              week_tc: ["Week1.png","Week2.png","Week3.png","Week4.png","Week5.png","Week6.png","Week7.png"],
              week_sc: ["Week1.png","Week2.png","Week3.png","Week4.png","Week5.png","Week6.png","Week7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 92,
              am_y: 158,
              am_sc_path: 'Clock_AM.png',
              am_en_path: 'Clock_AM.png',
              pm_x: 92,
              pm_y: 158,
              pm_sc_path: 'Clock_PM.png',
              pm_en_path: 'Clock_PM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 155,
              minute_startY: 243,
              minute_array: ["T_Min0.png","T_Min1.png","T_Min2.png","T_Min3.png","T_Min4.png","T_Min5.png","T_Min6.png","T_Min7.png","T_Min8.png","T_Min9.png"],
              minute_zero: 1,
              minute_space: 5,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 155,
              hour_startY: 108,
              hour_array: ["T_Hour0.png","T_Hour1.png","T_Hour2.png","T_Hour3.png","T_Hour4.png","T_Hour5.png","T_Hour6.png","T_Hour7.png","T_Hour8.png","T_Hour9.png"],
              hour_zero: 1,
              hour_space: 5,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 199,
              y: 25,
              src: 'Logo.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_second = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              second_startX: 345,
              second_startY: 311,
              second_array: ["T_sec0.png","T_sec1.png","T_sec2.png","T_sec3.png","T_sec4.png","T_sec5.png","T_sec6.png","T_sec7.png","T_sec8.png","T_sec9.png"],
              second_zero: 1,
              second_space: 3,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 209,
              day_startY: 421,
              day_sc_array: ["T_sec0.png","T_sec1.png","T_sec2.png","T_sec3.png","T_sec4.png","T_sec5.png","T_sec6.png","T_sec7.png","T_sec8.png","T_sec9.png"],
              day_tc_array: ["T_sec0.png","T_sec1.png","T_sec2.png","T_sec3.png","T_sec4.png","T_sec5.png","T_sec6.png","T_sec7.png","T_sec8.png","T_sec9.png"],
              day_en_array: ["T_sec0.png","T_sec1.png","T_sec2.png","T_sec3.png","T_sec4.png","T_sec5.png","T_sec6.png","T_sec7.png","T_sec8.png","T_sec9.png"],
              day_zero: 0,
              day_space: 3,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 169,
              month_startY: 389,
              month_sc_array: ["Month01.png","Month02.png","Month03.png","Month04.png","Month05.png","Month06.png","Month07.png","Month08.png","Month09.png","Month10.png","Month11.png","Month12.png"],
              month_tc_array: ["Month01.png","Month02.png","Month03.png","Month04.png","Month05.png","Month06.png","Month07.png","Month08.png","Month09.png","Month10.png","Month11.png","Month12.png"],
              month_en_array: ["Month01.png","Month02.png","Month03.png","Month04.png","Month05.png","Month06.png","Month07.png","Month08.png","Month09.png","Month10.png","Month11.png","Month12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 165,
              y: 63,
              week_en: ["Week1.png","Week2.png","Week3.png","Week4.png","Week5.png","Week6.png","Week7.png"],
              week_tc: ["Week1.png","Week2.png","Week3.png","Week4.png","Week5.png","Week6.png","Week7.png"],
              week_sc: ["Week1.png","Week2.png","Week3.png","Week4.png","Week5.png","Week6.png","Week7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 114,
              am_y: 116,
              am_sc_path: 'Clock_AM.png',
              am_en_path: 'Clock_AM.png',
              pm_x: 114,
              pm_y: 116,
              pm_sc_path: 'Clock_PM.png',
              pm_en_path: 'Clock_PM.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 155,
              minute_startY: 243,
              minute_array: ["T_Hour0.png","T_Hour1.png","T_Hour2.png","T_Hour3.png","T_Hour4.png","T_Hour5.png","T_Hour6.png","T_Hour7.png","T_Hour8.png","T_Hour9.png"],
              minute_zero: 1,
              minute_space: 5,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 155,
              hour_startY: 108,
              hour_array: ["T_Hour0.png","T_Hour1.png","T_Hour2.png","T_Hour3.png","T_Hour4.png","T_Hour5.png","T_Hour6.png","T_Hour7.png","T_Hour8.png","T_Hour9.png"],
              hour_zero: 1,
              hour_space: 5,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 199,
              y: 25,
              src: 'Logo.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 9,
              // disconneсnt_toast_text: BT Connection Lost,
              // conneсnt_vibrate_type: 9,
              // conneсnt_toast_text: BT Connected,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              console.log('checkConnection()');
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  hmUI.showToast({text: "BT Connection Lost"});
                  vibro(9);
                }
                if(status) {
                  hmUI.showToast({text: "BT Connected"});
                  vibro(9);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              if (scene != 1) timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function
            console.log('Watch_Face.Shortcuts');

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 42,
              y: 142,
              w: 36,
              h: 36,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 381,
              y: 233,
              w: 55,
              h: 36,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 30,
              y: 199,
              w: 77,
              h: 28,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 203,
              y: 265,
              w: 72,
              h: 72,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 345,
              y: 312,
              w: 67,
              h: 45,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 87,
              y: 89,
              w: 52,
              h: 48,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 347,
              y: 90,
              w: 48,
              h: 74,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 34,
              y: 293,
              w: 86,
              h: 30,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 379,
              y: 192,
              w: 57,
              h: 35,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 85,
              y: 348,
              w: 59,
              h: 36,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PowerSaveHintScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 197,
              y: 24,
              w: 95,
              h: 61,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                click_Color();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 207,
              y: 392,
              w: 71,
              h: 70,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                checkConnection();
                stopVibro();

              }),
              pause_call: (function () {
                console.log('pause_call()');
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
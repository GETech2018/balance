try {
    ((() => {
        const {beforeModuleCreate = () => {
            }, afterModuleCreate = () => {
            }} = DeviceRuntimeCore.LifeCycle;
        beforeModuleCreate();
        const {beforePageCreate = () => {
            }, afterPageCreate = () => {
            }} = DeviceRuntimeCore.LifeCycle;
        beforePageCreate();
        const __$$G$$__ = __$$hmAppManager$$__.currentApp.current.__globals__.__$$G$$__;
        !function (context) {
            with (context) {
                const __$$RQR$$__ = __$$R$$__;
                const ui = __$$RQR$$__('@zos/ui');
                const app = __$$RQR$$__('@zos/app');
                const _interopDefaultCompat = e => e && typeof e === 'object' && 'default' in e ? e : { default: e };
                const ui__default = _interopDefaultCompat(ui);
                const ASSET_ROOT = 'images/';
                const asset = path => `${ ASSET_ROOT }${ path }`;
                const numberArray = folder => Array.from({ length: 10 }, (_, index) => asset(`${ folder }/${ index }.png`));
                const weekArray = [
                    asset('week/1.png'),
                    asset('week/2.png'),
                    asset('week/3.png'),
                    asset('week/4.png'),
                    asset('week/5.png'),
                    asset('week/6.png'),
                    asset('week/7.png')
                ];
                const monthArray = Array.from({ length: 12 }, (_, index) => asset(`month/${ index + 1 }.png`));
                function drawTime(aod) {
                    const folder = aod ? 'time_aod' : 'time';
                    const digits = numberArray(folder);
                    const top = aod ? 185 : 145;
                    const left = aod ? 112 : 108;
                    ui__default.default.createWidget(ui__default.default.widget.IMG_TIME, {
                        hour_zero: 1,
                        hour_startX: px(left),
                        hour_startY: px(top),
                        hour_array: digits,
                        hour_space: 2,
                        hour_unit_sc: asset(`${ folder }/colon.png`),
                        hour_unit_tc: asset(`${ folder }/colon.png`),
                        hour_unit_en: asset(`${ folder }/colon.png`),
                        hour_align: ui__default.default.align.LEFT,
                        minute_follow: 1,
                        minute_array: digits,
                        minute_space: 2
                    });
                }
                function drawDate(aod) {
                    const y = aod ? 280 : 250;
                    const dateDigits = numberArray(aod ? 'date_aod' : 'date');
                    const weeks = aod ? weekArray.map(path => path.replace('/week/', '/week_aod/')) : weekArray;
                    const months = aod ? monthArray.map(path => path.replace('/month/', '/month_aod/')) : monthArray;
                    ui__default.default.createWidget(ui__default.default.widget.IMG_WEEK, {
                        x: 165,
                        y: px(y),
                        week_en: weeks,
                        week_sc: weeks,
                        week_tc: weeks
                    });
                    ui__default.default.createWidget(ui__default.default.widget.IMG_DATE, {
                        day_startX: 221,
                        day_startY: px(y),
                        day_align: ui__default.default.align.LEFT,
                        day_space: 1,
                        day_zero: 1,
                        day_follow: 0,
                        day_en_array: dateDigits,
                        day_sc_array: dateDigits,
                        day_tc_array: dateDigits,
                        month_startX: 267,
                        month_startY: px(y),
                        month_align: ui__default.default.align.LEFT,
                        month_space: 0,
                        month_zero: 0,
                        month_follow: 0,
                        month_is_character: true,
                        month_en_array: months,
                        month_sc_array: months,
                        month_tc_array: months
                    });
                }
                function drawMetric(type, x, width = 68) {
                    ui__default.default.createWidget(ui__default.default.widget.TEXT_IMG, {
                        x: px(x),
                        y: 382,
                        w: px(width),
                        h: 28,
                        font_array: numberArray('metric'),
                        type,
                        h_space: 1,
                        align_h: ui__default.default.align.CENTER_H
                    });
                }
                function drawMetrics() {
                    drawMetric(ui__default.default.data_type.CAL, 54);
                    drawMetric(ui__default.default.data_type.STEP, 127, 78);
                    drawMetric(ui__default.default.data_type.PAI_DAILY, 206);
                    drawMetric(ui__default.default.data_type.TRAINING_LOAD, 281);
                    drawMetric(ui__default.default.data_type.FAT_BURNING, 358);
                }
                __$$module$$__.module = WatchFace({
                    build() {
                        const aod = app.getScene() === app.SCENE_AOD;
                        ui__default.default.createWidget(ui__default.default.widget.FILL_RECT, {
                            x: 0,
                            y: 0,
                            w: 480,
                            h: 480,
                            color: 0
                        });
                        if (!aod) {
                            ui__default.default.createWidget(ui__default.default.widget.IMG, {
                                x: 0,
                                y: 0,
                                w: 480,
                                h: 480,
                                src: asset('background.png')
                            });
                        }
                        drawTime(aod);
                        drawDate(aod);
                        if (!aod) {
                            drawMetrics();
                        }
                    }
                });
                ;
            }
        }.bind(__$$G$$__)(__$$G$$__);
        afterPageCreate();
        afterModuleCreate();
        ;
    })());
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
try {
	(() => {

		var __$$app$$__ = __$$hmAppManager$$__.currentApp;

		/*
		* Watch_Face_Editor tool v1.x
		* Copyright © Huami. All Rights Reserved
		*/
		'use strict';

		function getGlobal() {
			if (typeof self !== 'undefined') return self;
			if (typeof window !== 'undefined') return window;
			if (typeof global !== 'undefined') return global;
			if (typeof globalThis !== 'undefined') return globalThis;
			throw new Error('unable to locate global object');
		}

		let globalNS = getGlobal();
		if (typeof setTimeout === 'undefined' && typeof timer !== 'undefined') {
			globalNS.clearTimeout = function clearTimeout(timerRef) {
				timerRef && timer.stopTimer(timerRef);
			};
			globalNS.setTimeout = function setTimeout(func, ns) {
				const timerRef = timer.createTimer(ns || 1, Number.MAX_SAFE_INTEGER, function () {
					globalNS.clearTimeout(timerRef);
					func && func();
				}, {});
				return timerRef;
			};
			globalNS.clearInterval = function clearInterval(timerRef) {
				timerRef && timer.stopTimer(timerRef);
			};
			globalNS.setInterval = function setInterval(func, ms) {
				return timer.createTimer(1, ms, function () {
					func && func();
				}, {});
			};
		}

		__$$app$$__.app = DeviceRuntimeCore.App({
			globalData: {},
			onCreate(options) {
			},
			onShow(options) {
			},
			onHide(options) {
			},
			onDestroy(options) {
			},
			onError(error) {
			},
			onPageNotFound(obj) {
			},
			onUnhandledRejection(obj) {
			}
		});
		/*
		* end js
		*/

	})()
} catch(e) {
	console.log(e)
	/* todo */
}
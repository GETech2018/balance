﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_stand_current_text_img = ''
        let normal_stand_current_separator_img = ''
        let normal_heart_rate_circle_scale_2 = ''
        let normal_heart_rate_pointer_progress_img_pointer = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_text_separator_img = ''
        let normal_battery_circle_scale = ''
        let normal_battery_pointer_progress_img_pointer = ''
        let normal_battery_text_text_img = ''
        let normal_battery_text_separator_img = ''
        let normal_step_icon_img = ''
        let normal_step_circle_scale = ''
        let normal_step_pointer_progress_img_pointer = ''
        let normal_step_TextRotate = new Array(5);
        let normal_step_TextRotate_ASCIIARRAY = new Array(10);
        let normal_step_TextRotate_img_width = 28;
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_digital_clock_minute_separator_img = ''
        let idle_background_bg_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_stand_current_text_img = ''
        let idle_stand_current_separator_img = ''
        let idle_heart_rate_circle_scale_2 = ''
        let idle_heart_rate_pointer_progress_img_pointer = ''
        let idle_heart_rate_text_text_img = ''
        let idle_heart_rate_text_separator_img = ''
        let idle_battery_circle_scale = ''
        let idle_battery_pointer_progress_img_pointer = ''
        let idle_battery_text_text_img = ''
        let idle_battery_text_separator_img = ''
        let idle_step_icon_img = ''
        let idle_step_circle_scale = ''
        let idle_step_pointer_progress_img_pointer = ''
        let idle_step_TextRotate = new Array(5);
        let idle_step_TextRotate_ASCIIARRAY = new Array(10);
        let idle_step_TextRotate_img_width = 28;
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_day = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''
        let idle_digital_clock_minute_separator_img = ''
        let normal_step_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_battery_jumpable_img_click = ''
        let normal_stand_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'WF.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 93,
              y: 343,
              image_array: ["weather_01.png","weather_02.png","weather_03.png","weather_04.png","weather_05.png","weather_06.png","weather_07.png","weather_08.png","weather_09.png","weather_10.png","weather_11.png","weather_12.png","weather_13.png","weather_14.png","weather_15.png","weather_16.png","weather_17.png","weather_18.png","weather_19.png","weather_20.png","weather_21.png","weather_22.png","weather_23.png","weather_24.png","weather_25.png","weather_26.png","weather_27.png","weather_28.png","weather_29.png"],
              image_length: 29,
              shortcut: true,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 249,
              y: 313,
              font_array: ["STAND_digit_01.png","STAND_digit_02.png","STAND_digit_03.png","STAND_digit_04.png","STAND_digit_05.png","STAND_digit_06.png","STAND_digit_07.png","STAND_digit_08.png","STAND_digit_09.png","STAND_digit_10.png"],
              padding: true,
              h_space: -7,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STAND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 197,
              y: 313,
              src: 'stand.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_circle_scale_2 = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 240,
              center_y: 258,
              start_angle: 211,
              end_angle: 149,
              radius: 194,
              line_width: 24,
              corner_flag: 0,
              type: hmUI.data_type.HEART,
              color: 0xFFC0C0C0,
              // mirror: False,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'Point.png',
              center_x: 240,
              center_y: 258,
              x: 5,
              y: 206,
              start_angle: 211,
              end_angle: 149,
              invalid_visible: false,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 206,
              y: 395,
              font_array: ["Small_digit_01.png","Small_digit_02.png","Small_digit_03.png","Small_digit_04.png","Small_digit_05.png","Small_digit_06.png","Small_digit_07.png","Small_digit_08.png","Small_digit_09.png","Small_digit_10.png"],
              padding: false,
              h_space: -7,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 333,
              y: 395,
              src: 'Heart.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 240,
              // center_y: 222,
              // start_angle: -31,
              // end_angle: 31,
              // radius: 206,
              // line_width: 24,
              // line_cap: Rounded,
              // color: 0xFFC0C0C0,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            let screenType = hmSetting.getScreenType();
            normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 240,
              center_y: 222,
              start_angle: -31,
              end_angle: 31,
              radius: 194,
              line_width: 24,
              corner_flag: 0,
              color: 0xFFC0C0C0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'Point.png',
              center_x: 240,
              center_y: 222,
              x: 15,
              y: 206,
              start_angle: -31,
              end_angle: 31,
              invalid_visible: false,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 205,
              y: 52,
              font_array: ["Small_digit_01.png","Small_digit_02.png","Small_digit_03.png","Small_digit_04.png","Small_digit_05.png","Small_digit_06.png","Small_digit_07.png","Small_digit_08.png","Small_digit_09.png","Small_digit_10.png"],
              padding: false,
              h_space: -7,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 102,
              y: 49,
              src: 'Bolt_white.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 47,
              y: 334,
              src: 'Steps.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 221,
              // center_y: 240,
              // start_angle: 239,
              // end_angle: 301,
              // radius: 206,
              // line_width: 24,
              // line_cap: Rounded,
              // color: 0xFFC0C0C0,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 221,
              center_y: 240,
              start_angle: 239,
              end_angle: 301,
              radius: 194,
              line_width: 24,
              corner_flag: 0,
              color: 0xFFC0C0C0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
              scale_call();
            });

            normal_step_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'Point.png',
              center_x: 221,
              center_y: 240,
              x: 15,
              y: 206,
              start_angle: 239,
              end_angle: 301,
              invalid_visible: false,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_step_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 83,
              // y: 239,
              // font_array: ["Small_digit_01.png","Small_digit_02.png","Small_digit_03.png","Small_digit_04.png","Small_digit_05.png","Small_digit_06.png","Small_digit_07.png","Small_digit_08.png","Small_digit_09.png","Small_digit_10.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: -7,
              // angle: 90,
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_step_TextRotate_ASCIIARRAY[0] = 'Small_digit_01.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[1] = 'Small_digit_02.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[2] = 'Small_digit_03.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[3] = 'Small_digit_04.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[4] = 'Small_digit_05.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[5] = 'Small_digit_06.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[6] = 'Small_digit_07.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[7] = 'Small_digit_08.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[8] = 'Small_digit_09.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[9] = 'Small_digit_10.png';  // set of images with numbers

            //#region TextRotate
            for (let i = 0; i < 5; i++) {
              normal_step_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 83,
                center_y: 239,
                pos_x: 83,
                pos_y: 239,
                angle: 90,
                src: 'Small_digit_01.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_step_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //#endregion

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 301,
              y: 124,
              week_en: ["day_01.png","day_02.png","day_03.png","day_04.png","day_05.png","day_06.png","day_07.png"],
              week_tc: ["day_01.png","day_02.png","day_03.png","day_04.png","day_05.png","day_06.png","day_07.png"],
              week_sc: ["day_01.png","day_02.png","day_03.png","day_04.png","day_05.png","day_06.png","day_07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 380,
              day_startY: 124,
              day_sc_array: ["Small_digit_01.png","Small_digit_02.png","Small_digit_03.png","Small_digit_04.png","Small_digit_05.png","Small_digit_06.png","Small_digit_07.png","Small_digit_08.png","Small_digit_09.png","Small_digit_10.png"],
              day_tc_array: ["Small_digit_01.png","Small_digit_02.png","Small_digit_03.png","Small_digit_04.png","Small_digit_05.png","Small_digit_06.png","Small_digit_07.png","Small_digit_08.png","Small_digit_09.png","Small_digit_10.png"],
              day_en_array: ["Small_digit_01.png","Small_digit_02.png","Small_digit_03.png","Small_digit_04.png","Small_digit_05.png","Small_digit_06.png","Small_digit_07.png","Small_digit_08.png","Small_digit_09.png","Small_digit_10.png"],
              day_zero: 1,
              day_space: -7,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 337,
              am_y: 273,
              am_sc_path: 'AM.png',
              am_en_path: 'AM.png',
              pm_x: 339,
              pm_y: 273,
              pm_sc_path: 'PM.png',
              pm_en_path: 'PM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 142,
              hour_startY: 180,
              hour_array: ["Big_digit_01.png","Big_digit_02.png","Big_digit_03.png","Big_digit_04.png","Big_digit_05.png","Big_digit_06.png","Big_digit_07.png","Big_digit_08.png","Big_digit_09.png","Big_digit_10.png"],
              hour_zero: 1,
              hour_space: -5,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 327,
              minute_startY: 165,
              minute_array: ["Minutes_digit_01.png","Minutes_digit_02.png","Minutes_digit_03.png","Minutes_digit_04.png","Minutes_digit_05.png","Minutes_digit_06.png","Minutes_digit_07.png","Minutes_digit_08.png","Minutes_digit_09.png","Minutes_digit_10.png"],
              minute_zero: 1,
              minute_space: -6,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 398,
              second_startY: 191,
              second_array: ["STAND_digit_01.png","STAND_digit_02.png","STAND_digit_03.png","STAND_digit_04.png","STAND_digit_05.png","STAND_digit_06.png","STAND_digit_07.png","STAND_digit_08.png","STAND_digit_09.png","STAND_digit_10.png"],
              second_zero: 1,
              second_space: -6,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 132,
              y: 165,
              src: 'Overlap (Custom).png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_minute_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 322,
              y: 165,
              src: 'Overlap.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'AOD.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 93,
              y: 343,
              image_array: ["weather_01.png","weather_02.png","weather_03.png","weather_04.png","weather_05.png","weather_06.png","weather_07.png","weather_08.png","weather_09.png","weather_10.png","weather_11.png","weather_12.png","weather_13.png","weather_14.png","weather_15.png","weather_16.png","weather_17.png","weather_18.png","weather_19.png","weather_20.png","weather_21.png","weather_22.png","weather_23.png","weather_24.png","weather_25.png","weather_26.png","weather_27.png","weather_28.png","weather_29.png"],
              image_length: 29,
              shortcut: true,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_stand_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 249,
              y: 313,
              font_array: ["STAND_digit_01.png","STAND_digit_02.png","STAND_digit_03.png","STAND_digit_04.png","STAND_digit_05.png","STAND_digit_06.png","STAND_digit_07.png","STAND_digit_08.png","STAND_digit_09.png","STAND_digit_10.png"],
              padding: true,
              h_space: -7,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STAND,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_stand_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 197,
              y: 313,
              src: 'stand.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_circle_scale_2 = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 240,
              center_y: 258,
              start_angle: 211,
              end_angle: 149,
              radius: 194,
              line_width: 24,
              corner_flag: 0,
              type: hmUI.data_type.HEART,
              color: 0xFFC0C0C0,
              // mirror: False,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'Point.png',
              center_x: 240,
              center_y: 258,
              x: 5,
              y: 206,
              start_angle: 211,
              end_angle: 149,
              invalid_visible: false,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 206,
              y: 395,
              font_array: ["Small_digit_01.png","Small_digit_02.png","Small_digit_03.png","Small_digit_04.png","Small_digit_05.png","Small_digit_06.png","Small_digit_07.png","Small_digit_08.png","Small_digit_09.png","Small_digit_10.png"],
              padding: false,
              h_space: -7,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 333,
              y: 395,
              src: 'Heart.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 240,
              // center_y: 222,
              // start_angle: -31,
              // end_angle: 31,
              // radius: 206,
              // line_width: 24,
              // line_cap: Rounded,
              // color: 0xFFC0C0C0,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 240,
              center_y: 222,
              start_angle: -31,
              end_angle: 31,
              radius: 194,
              line_width: 24,
              corner_flag: 0,
              color: 0xFFC0C0C0,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'Point.png',
              center_x: 240,
              center_y: 222,
              x: 15,
              y: 206,
              start_angle: -31,
              end_angle: 31,
              invalid_visible: false,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 205,
              y: 52,
              font_array: ["Small_digit_01.png","Small_digit_02.png","Small_digit_03.png","Small_digit_04.png","Small_digit_05.png","Small_digit_06.png","Small_digit_07.png","Small_digit_08.png","Small_digit_09.png","Small_digit_10.png"],
              padding: false,
              h_space: -7,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 102,
              y: 49,
              src: 'Bolt_white.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 47,
              y: 334,
              src: 'Steps.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 221,
              // center_y: 240,
              // start_angle: 239,
              // end_angle: 301,
              // radius: 206,
              // line_width: 24,
              // line_cap: Rounded,
              // color: 0xFFC0C0C0,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 221,
              center_y: 240,
              start_angle: 239,
              end_angle: 301,
              radius: 194,
              line_width: 24,
              corner_flag: 0,
              color: 0xFFC0C0C0,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'Point.png',
              center_x: 221,
              center_y: 240,
              x: 15,
              y: 206,
              start_angle: 239,
              end_angle: 301,
              invalid_visible: false,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_step_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 83,
              // y: 239,
              // font_array: ["Small_digit_01.png","Small_digit_02.png","Small_digit_03.png","Small_digit_04.png","Small_digit_05.png","Small_digit_06.png","Small_digit_07.png","Small_digit_08.png","Small_digit_09.png","Small_digit_10.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: -7,
              // angle: 90,
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_step_TextRotate_ASCIIARRAY[0] = 'Small_digit_01.png';  // set of images with numbers
            idle_step_TextRotate_ASCIIARRAY[1] = 'Small_digit_02.png';  // set of images with numbers
            idle_step_TextRotate_ASCIIARRAY[2] = 'Small_digit_03.png';  // set of images with numbers
            idle_step_TextRotate_ASCIIARRAY[3] = 'Small_digit_04.png';  // set of images with numbers
            idle_step_TextRotate_ASCIIARRAY[4] = 'Small_digit_05.png';  // set of images with numbers
            idle_step_TextRotate_ASCIIARRAY[5] = 'Small_digit_06.png';  // set of images with numbers
            idle_step_TextRotate_ASCIIARRAY[6] = 'Small_digit_07.png';  // set of images with numbers
            idle_step_TextRotate_ASCIIARRAY[7] = 'Small_digit_08.png';  // set of images with numbers
            idle_step_TextRotate_ASCIIARRAY[8] = 'Small_digit_09.png';  // set of images with numbers
            idle_step_TextRotate_ASCIIARRAY[9] = 'Small_digit_10.png';  // set of images with numbers

            //#region TextRotate
            for (let i = 0; i < 5; i++) {
              idle_step_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 83,
                center_y: 239,
                pos_x: 83,
                pos_y: 239,
                angle: 90,
                src: 'Small_digit_01.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_step_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //#endregion

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 301,
              y: 124,
              week_en: ["day_01.png","day_02.png","day_03.png","day_04.png","day_05.png","day_06.png","day_07.png"],
              week_tc: ["day_01.png","day_02.png","day_03.png","day_04.png","day_05.png","day_06.png","day_07.png"],
              week_sc: ["day_01.png","day_02.png","day_03.png","day_04.png","day_05.png","day_06.png","day_07.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 380,
              day_startY: 124,
              day_sc_array: ["Small_digit_01.png","Small_digit_02.png","Small_digit_03.png","Small_digit_04.png","Small_digit_05.png","Small_digit_06.png","Small_digit_07.png","Small_digit_08.png","Small_digit_09.png","Small_digit_10.png"],
              day_tc_array: ["Small_digit_01.png","Small_digit_02.png","Small_digit_03.png","Small_digit_04.png","Small_digit_05.png","Small_digit_06.png","Small_digit_07.png","Small_digit_08.png","Small_digit_09.png","Small_digit_10.png"],
              day_en_array: ["Small_digit_01.png","Small_digit_02.png","Small_digit_03.png","Small_digit_04.png","Small_digit_05.png","Small_digit_06.png","Small_digit_07.png","Small_digit_08.png","Small_digit_09.png","Small_digit_10.png"],
              day_zero: 1,
              day_space: -7,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 337,
              am_y: 273,
              am_sc_path: 'AM.png',
              am_en_path: 'AM.png',
              pm_x: 339,
              pm_y: 273,
              pm_sc_path: 'PM.png',
              pm_en_path: 'PM.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 142,
              hour_startY: 180,
              hour_array: ["Big_digit_01.png","Big_digit_02.png","Big_digit_03.png","Big_digit_04.png","Big_digit_05.png","Big_digit_06.png","Big_digit_07.png","Big_digit_08.png","Big_digit_09.png","Big_digit_10.png"],
              hour_zero: 1,
              hour_space: -5,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 327,
              minute_startY: 165,
              minute_array: ["Minutes_digit_01.png","Minutes_digit_02.png","Minutes_digit_03.png","Minutes_digit_04.png","Minutes_digit_05.png","Minutes_digit_06.png","Minutes_digit_07.png","Minutes_digit_08.png","Minutes_digit_09.png","Minutes_digit_10.png"],
              minute_zero: 1,
              minute_space: -6,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 132,
              y: 165,
              src: 'Overlap (Custom).png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_minute_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 322,
              y: 165,
              src: 'Overlap.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 7,
              y: 147,
              w: 103,
              h: 186,
              src: 'transparent.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 147,
              y: 377,
              w: 186,
              h: 103,
              src: 'transparent.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 161,
              y: 7,
              w: 159,
              h: 103,
              src: 'transparent.png',
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 196,
              y: 274,
              w: 93,
              h: 62,
              src: 'transparent.png',
              type: hmUI.data_type.STAND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 302,
              y: 123,
              w: 125,
              h: 41,
              text: '',
              color: 0xFFFF8C00,
              text_size: 26,
              press_src: 'transparent.png',
              normal_src: 'transparent.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 100,
              y: 340,
              w: 296,
              h: 31,
              text: '',
              color: 0xFFFF8C00,
              text_size: 26,
              press_src: 'transparent.png',
              normal_src: 'transparent.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'WeatherScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            //#region text_update
            function text_update() {
              console.log('text_update()');

              console.log('update text rotate step_STEP');
              let valueStep = step.current;
              let normal_step_rotate_string = parseInt(valueStep).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  normal_step_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueStep != null && valueStep != undefined && isFinite(valueStep) && normal_step_rotate_string.length > 0 && normal_step_rotate_string.length <= 5) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let normal_step_TextRotate_posOffset = normal_step_TextRotate_img_width * normal_step_rotate_string.length;
                  normal_step_TextRotate_posOffset = normal_step_TextRotate_posOffset + -7 * (normal_step_rotate_string.length - 1);
                  img_offset -= normal_step_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_step_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_step_TextRotate[index].setProperty(hmUI.prop.POS_X, 83 + img_offset);
                      normal_step_TextRotate[index].setProperty(hmUI.prop.SRC, normal_step_TextRotate_ASCIIARRAY[charCode]);
                      normal_step_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_step_TextRotate_img_width + -7;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate step_STEP');
              let idle_step_rotate_string = parseInt(valueStep).toString();

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  idle_step_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueStep != null && valueStep != undefined && isFinite(valueStep) && idle_step_rotate_string.length > 0 && idle_step_rotate_string.length <= 5) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let idle_step_TextRotate_posOffset = idle_step_TextRotate_img_width * idle_step_rotate_string.length;
                  idle_step_TextRotate_posOffset = idle_step_TextRotate_posOffset + -7 * (idle_step_rotate_string.length - 1);
                  img_offset -= idle_step_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of idle_step_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_step_TextRotate[index].setProperty(hmUI.prop.POS_X, 83 + img_offset);
                      idle_step_TextRotate[index].setProperty(hmUI.prop.SRC, idle_step_TextRotate_ASCIIARRAY[charCode]);
                      idle_step_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_step_TextRotate_img_width + -7;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

            };

            //#endregion
            function scale_call() {
              console.log('scale_call()');

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_cs_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_battery * 100);
                  if (normal_battery_circle_scale) {
                    normal_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 240,
                      center_y: 222,
                      start_angle: -31,
                      end_angle: 31,
                      radius: 194,
                      line_width: 24,
                      corner_flag: 0,
                      color: 0xFFC0C0C0,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_cs_normal_step = progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_step * 100);
                  if (normal_step_circle_scale) {
                    normal_step_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 221,
                      center_y: 240,
                      start_angle: 239,
                      end_angle: 301,
                      radius: 194,
                      line_width: 24,
                      corner_flag: 0,
                      color: 0xFFC0C0C0,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales BATTERY');
                let progress_cs_idle_battery = progressBattery;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_battery_circle_scale_circle_scale
                  let level = Math.round(progress_cs_idle_battery * 100);
                  if (idle_battery_circle_scale) {
                    idle_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 240,
                      center_y: 222,
                      start_angle: -31,
                      end_angle: 31,
                      radius: 194,
                      line_width: 24,
                      corner_flag: 0,
                      color: 0xFFC0C0C0,
                      show_level: hmUI.show_level.ONLY_AOD,
                      level: level,
                    });
                  };
                };

                console.log('update scales STEP');
                let progress_cs_idle_step = progressStep;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_step_circle_scale_circle_scale
                  let level = Math.round(progress_cs_idle_step * 100);
                  if (idle_step_circle_scale) {
                    idle_step_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 221,
                      center_y: 240,
                      start_angle: 239,
                      end_angle: 301,
                      radius: 194,
                      line_width: 24,
                      corner_flag: 0,
                      color: 0xFFC0C0C0,
                      show_level: hmUI.show_level.ONLY_AOD,
                      level: level,
                    });
                  };
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                text_update();
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
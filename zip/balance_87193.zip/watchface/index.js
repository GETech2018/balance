﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_distance_current_text_font = ''
        let normal_heart_rate_text_font = ''
        let normal_step_current_text_font = ''
        let normal_sun_high_text_font = ''
        let normal_sun_low_text_font = ''
        let normal_date_img_date_month_img = ''
        let normal_day_TextRotate = new Array(2);
        let normal_day_TextRotate_ASCIIARRAY = new Array(10);
        let normal_day_TextRotate_img_width = 49;
        let normal_timerTextUpdate = undefined;
        let normal_date_img_date_week_img = ''
        let normal_image_img = ''
        let normal_time_hour_text_font = ''
        let normal_timerTimeUpdate = undefined;
        let normal_time_minute_text_font = ''
        let normal_battery_icon_img = ''
        let normal_battery_current_text_font = ''
        let normal_temperature_icon_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_font = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_date_img_date_month_img = ''
        let idle_day_TextRotate = new Array(2);
        let idle_day_TextRotate_ASCIIARRAY = new Array(10);
        let idle_day_TextRotate_img_width = 49;
        let idle_timerTextUpdate = undefined;
        let idle_date_img_date_week_img = ''
        let idle_image_img = ''
        let idle_time_hour_text_font = ''
        let idle_timerTimeUpdate = undefined;
        let idle_time_minute_text_font = ''
        let idle_battery_icon_img = ''
        let idle_battery_current_text_font = ''
        let idle_temperature_icon_img = ''
        let idle_temperature_current_text_font = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let Button_7 = ''
        let Button_8 = ''
        let Button_9 = ''
        let Button_10 = ''
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            // FontName: 1Eurostile Bold.ttf; FontSize: 30
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 501,
              h: 38,
              text_size: 30,
              char_space: 2,
              line_space: 0,
              font: 'fonts/1Eurostile Bold.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: CreatoDisplay_BoldItalic.ttf; FontSize: 130
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 1790,
              h: 186,
              text_size: 130,
              char_space: 1,
              line_space: 0,
              font: 'fonts/CreatoDisplay_BoldItalic.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: Antonio-Bold.ttf; FontSize: 40
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 555,
              h: 54,
              text_size: 40,
              char_space: 2,
              line_space: 0,
              font: 'fonts/Antonio-Bold.ttf',
              color: 0xFF000000,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: Antonio-Bold.ttf; FontSize: 47
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 638,
              h: 63,
              text_size: 47,
              char_space: 2,
              line_space: 0,
              font: 'fonts/Antonio-Bold.ttf',
              color: 0xFF000000,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.BOTTOM,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: '1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 142,
              y: 431,
              src: 'BT.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 136,
              y: 23,
              src: 'alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 59,
              y: 132,
              w: 150,
              h: 40,
              text_size: 30,
              char_space: 2,
              font: 'fonts/1Eurostile Bold.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 60,
              y: 313,
              w: 150,
              h: 40,
              text_size: 30,
              char_space: 2,
              font: 'fonts/1Eurostile Bold.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.BOTTOM,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              padding: true,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 59,
              y: 226,
              w: 150,
              h: 40,
              text_size: 30,
              char_space: 2,
              font: 'fonts/1Eurostile Bold.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              padding: true,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 80,
              y: 52,
              w: 150,
              h: 35,
              text_size: 28,
              char_space: 1,
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 80,
              y: 382,
              w: 150,
              h: 35,
              text_size: 28,
              char_space: 1,
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.BOTTOM,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 200,
              month_startY: 12,
              month_sc_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_tc_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_en_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_day_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 200,
              // y: 242,
              // font_array: ["digit_01.png","digit_02.png","digit_03.png","digit_04.png","digit_05.png","digit_06.png","digit_07.png","digit_08.png","digit_09.png","digit_10.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: -90,
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.DAY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_day_TextRotate_ASCIIARRAY[0] = 'digit_01.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[1] = 'digit_02.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[2] = 'digit_03.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[3] = 'digit_04.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[4] = 'digit_05.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[5] = 'digit_06.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[6] = 'digit_07.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[7] = 'digit_08.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[8] = 'digit_09.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[9] = 'digit_10.png';  // set of images with numbers

            //#region TextRotate
            for (let i = 0; i < 2; i++) {
              normal_day_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 200,
                center_y: 242,
                pos_x: 200,
                pos_y: 242,
                angle: -90,
                src: 'digit_01.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_day_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //#endregion

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            let screenType = hmSetting.getScreenType();
            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 200,
              y: 302,
              week_en: ["day_01.png","day_02.png","day_03.png","day_04.png","day_05.png","day_06.png","day_07.png"],
              week_tc: ["day_01.png","day_02.png","day_03.png","day_04.png","day_05.png","day_06.png","day_07.png"],
              week_sc: ["day_01.png","day_02.png","day_03.png","day_04.png","day_05.png","day_06.png","day_07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 200,
              y: -6,
              src: '922.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_time_hour_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 278,
              y: 111,
              w: 170,
              h: 140,
              text_size: 130,
              char_space: 1,
              font: 'fonts/CreatoDisplay_BoldItalic.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_time_minute_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 278,
              y: 229,
              w: 170,
              h: 140,
              text_size: 130,
              char_space: 1,
              font: 'fonts/CreatoDisplay_BoldItalic.ttf',
              color: 0xFF02D1FF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 282,
              y: 117,
              src: '922(1).png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 275,
              y: 57,
              w: 150,
              h: 50,
              text_size: 40,
              char_space: 2,
              font: 'fonts/Antonio-Bold.ttf',
              color: 0xFF000000,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              padding: true,
              unit_type: 1,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 266,
              y: 273,
              src: '922(1)(1).png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 17,
              y: 210,
              image_array: ["wea_00.png","wea_01.png","wea_02.png","wea_03.png","wea_04.png","wea_05.png","wea_06.png","wea_07.png","wea_08.png","wea_09.png","wea_10.png","wea_11.png","wea_12.png","wea_13.png","wea_14.png","wea_15.png","wea_16.png","wea_17.png","wea_18.png","wea_19.png","wea_20.png","wea_21.png","wea_22.png","wea_23.png","wea_24.png","wea_25.png","wea_26.png","wea_27.png","wea_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 265,
              y: 378,
              w: 150,
              h: 60,
              text_size: 47,
              char_space: 2,
              font: 'fonts/Antonio-Bold.ttf',
              color: 0xFF000000,
              line_space: 0,
              align_v: hmUI.align.BOTTOM,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              unit_type: 1,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 142,
              y: 431,
              src: 'BT.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 136,
              y: 23,
              src: 'alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 200,
              month_startY: 12,
              month_sc_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_tc_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_en_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_day_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 200,
              // y: 242,
              // font_array: ["digit_01.png","digit_02.png","digit_03.png","digit_04.png","digit_05.png","digit_06.png","digit_07.png","digit_08.png","digit_09.png","digit_10.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: -90,
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.DAY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_day_TextRotate_ASCIIARRAY[0] = 'digit_01.png';  // set of images with numbers
            idle_day_TextRotate_ASCIIARRAY[1] = 'digit_02.png';  // set of images with numbers
            idle_day_TextRotate_ASCIIARRAY[2] = 'digit_03.png';  // set of images with numbers
            idle_day_TextRotate_ASCIIARRAY[3] = 'digit_04.png';  // set of images with numbers
            idle_day_TextRotate_ASCIIARRAY[4] = 'digit_05.png';  // set of images with numbers
            idle_day_TextRotate_ASCIIARRAY[5] = 'digit_06.png';  // set of images with numbers
            idle_day_TextRotate_ASCIIARRAY[6] = 'digit_07.png';  // set of images with numbers
            idle_day_TextRotate_ASCIIARRAY[7] = 'digit_08.png';  // set of images with numbers
            idle_day_TextRotate_ASCIIARRAY[8] = 'digit_09.png';  // set of images with numbers
            idle_day_TextRotate_ASCIIARRAY[9] = 'digit_10.png';  // set of images with numbers

            //#region TextRotate
            for (let i = 0; i < 2; i++) {
              idle_day_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 200,
                center_y: 242,
                pos_x: 200,
                pos_y: 242,
                angle: -90,
                src: 'digit_01.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_day_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //#endregion

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 200,
              y: 302,
              week_en: ["day_01.png","day_02.png","day_03.png","day_04.png","day_05.png","day_06.png","day_07.png"],
              week_tc: ["day_01.png","day_02.png","day_03.png","day_04.png","day_05.png","day_06.png","day_07.png"],
              week_sc: ["day_01.png","day_02.png","day_03.png","day_04.png","day_05.png","day_06.png","day_07.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 200,
              y: -6,
              src: '922.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_time_hour_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 278,
              y: 111,
              w: 170,
              h: 140,
              text_size: 130,
              char_space: 1,
              font: 'fonts/CreatoDisplay_BoldItalic.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // padding: true,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_time_minute_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 278,
              y: 229,
              w: 170,
              h: 140,
              text_size: 130,
              char_space: 1,
              font: 'fonts/CreatoDisplay_BoldItalic.ttf',
              color: 0xFF02D1FF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // padding: true,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 282,
              y: 117,
              src: '922(1).png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 275,
              y: 57,
              w: 150,
              h: 50,
              text_size: 40,
              char_space: 2,
              font: 'fonts/Antonio-Bold.ttf',
              color: 0xFF000000,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              padding: true,
              unit_type: 1,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 266,
              y: 273,
              src: '922(1)(1).png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 265,
              y: 378,
              w: 150,
              h: 60,
              text_size: 47,
              char_space: 2,
              font: 'fonts/Antonio-Bold.ttf',
              color: 0xFF000000,
              line_space: 0,
              align_v: hmUI.align.BOTTOM,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              unit_type: 1,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 0,
              // disconneсnt_toast_text: RUSH OFF,
              // conneсnt_vibrate_type: 0,
              // conneсnt_toast_text: RUSH ON,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              console.log('checkConnection()');
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  hmUI.showToast({text: "RUSH OFF"});
                  vibro(0);
                }
                if(status) {
                  hmUI.showToast({text: "RUSH ON"});
                  vibro(0);
                }
              });
            }

            // end vibration when connecting or disconnecting
            //#region vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              if (scene != 1) timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            //#endregion
            console.log('Watch_Face.Shortcuts');

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 206,
              y: 0,
              w: 50,
              h: 480,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'transparent.png',
              normal_src: 'transparent.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 120,
              y: 14,
              w: 60,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'transparent.png',
              normal_src: 'transparent.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'AlarmInfoScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 120,
              y: 60,
              w: 60,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'transparent.png',
              normal_src: 'transparent.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'TideScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 96,
              y: 129,
              w: 84,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'transparent.png',
              normal_src: 'transparent.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PAI_app_Screen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 96,
              y: 223,
              w: 84,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'transparent.png',
              normal_src: 'transparent.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'activityAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 96,
              y: 316,
              w: 84,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'transparent.png',
              normal_src: 'transparent.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'heart_app_Screen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_7 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 96,
              y: 376,
              w: 84,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'transparent.png',
              normal_src: 'transparent.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'TideScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_8 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 299,
              y: 376,
              w: 90,
              h: 90,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'transparent.png',
              normal_src: 'transparent.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'AppListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_9 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 299,
              y: 23,
              w: 90,
              h: 90,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'transparent.png',
              normal_src: 'transparent.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'Settings_batteryManagerScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_10 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: -7,
              y: 223,
              w: 84,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'transparent.png',
              normal_src: 'transparent.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'WeatherScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            //#region time_update
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              console.log('hour font');
              if (updateHour) {
                let normal_hourStr = format_hour.toString();
                normal_hourStr = normal_hourStr.padStart(2, '0');
                normal_time_hour_text_font.setProperty(hmUI.prop.TEXT, normal_hourStr );
              };

              console.log('minute font');
              if (updateMinute) {
                let normal_minuteStr = minute.toString();
                normal_minuteStr = normal_minuteStr.padStart(2, '0');
                normal_time_minute_text_font.setProperty(hmUI.prop.TEXT, normal_minuteStr );
              };

              console.log('hour font');
              if (updateHour) {
                let idle_hourStr = format_hour.toString();
                idle_hourStr = idle_hourStr.padStart(2, '0');
                idle_time_hour_text_font.setProperty(hmUI.prop.TEXT, idle_hourStr );
              };

              console.log('minute font');
              if (updateMinute) {
                let idle_minuteStr = minute.toString();
                idle_minuteStr = idle_minuteStr.padStart(2, '0');
                idle_time_minute_text_font.setProperty(hmUI.prop.TEXT, idle_minuteStr );
              };

            };

            //#endregion
            //#region text_update
            function text_update() {
              console.log('text_update()');

              console.log('update text rotate day_TIME');
              let valueDay = timeSensor.day;
              let normal_day_rotate_string = parseInt(valueDay).toString();
              normal_day_rotate_string = normal_day_rotate_string.padStart(2, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_day_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueDay != null && valueDay != undefined && isFinite(valueDay) && normal_day_rotate_string.length > 0 && normal_day_rotate_string.length <= 2) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let normal_day_TextRotate_posOffset = normal_day_TextRotate_img_width * normal_day_rotate_string.length;
                  img_offset -= normal_day_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_day_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_day_TextRotate[index].setProperty(hmUI.prop.POS_X, 200 + img_offset);
                      normal_day_TextRotate[index].setProperty(hmUI.prop.SRC, normal_day_TextRotate_ASCIIARRAY[charCode]);
                      normal_day_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_day_TextRotate_img_width;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate day_TIME');
              let idle_day_rotate_string = parseInt(valueDay).toString();
              idle_day_rotate_string = idle_day_rotate_string.padStart(2, '0');

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  idle_day_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueDay != null && valueDay != undefined && isFinite(valueDay) && idle_day_rotate_string.length > 0 && idle_day_rotate_string.length <= 2) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let idle_day_TextRotate_posOffset = idle_day_TextRotate_img_width * idle_day_rotate_string.length;
                  img_offset -= idle_day_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of idle_day_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_day_TextRotate[index].setProperty(hmUI.prop.POS_X, 200 + img_offset);
                      idle_day_TextRotate[index].setProperty(hmUI.prop.SRC, idle_day_TextRotate_ASCIIARRAY[charCode]);
                      idle_day_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_day_TextRotate_img_width;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

            };

            //#endregion
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                time_update(true, true);
                text_update();
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerTextUpdate) {
                    normal_timerTextUpdate = timer.createTimer(0, 1000, (function (option) {
                      text_update();
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerTimeUpdate) {
                    normal_timerTimeUpdate = timer.createTimer(0, 1000, (function (option) {
                      let updateHour = timeSensor.minute == 0 && timeSensor.second < 2;
                      let updateMinute = timeSensor.second < 2;
                      time_update(updateHour, updateMinute);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.AOD) {
                  if (!idle_timerTextUpdate) {
                    idle_timerTextUpdate = timer.createTimer(0, 1000, (function (option) {
                      text_update();
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.AOD) {
                  if (!idle_timerTimeUpdate) {
                    idle_timerTimeUpdate = timer.createTimer(0, 1000, (function (option) {
                      let updateHour = timeSensor.minute == 0 && timeSensor.second < 2;
                      let updateMinute = timeSensor.second < 2;
                      time_update(updateHour, updateMinute);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                checkConnection();
                stopVibro();

              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerTextUpdate) {
                  timer.stopTimer(normal_timerTextUpdate);
                  normal_timerTextUpdate = undefined;
                }
                if (normal_timerTimeUpdate) {
                  timer.stopTimer(normal_timerTimeUpdate);
                  normal_timerTimeUpdate = undefined;
                }
                if (idle_timerTextUpdate) {
                  timer.stopTimer(idle_timerTextUpdate);
                  idle_timerTextUpdate = undefined;
                }
                if (idle_timerTimeUpdate) {
                  timer.stopTimer(idle_timerTimeUpdate);
                  idle_timerTimeUpdate = undefined;
                }
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
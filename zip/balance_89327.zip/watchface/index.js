﻿    /*
    ** Watch_Face_Editor tool v 18.0
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_heart_rate_TextRotate = new Array(3);
        let normal_heart_rate_TextRotate_ASCIIARRAY = new Array(10);
        let normal_heart_rate_TextRotate_img_width = 20;
        let normal_step_TextRotate = new Array(5);
        let normal_step_TextRotate_ASCIIARRAY = new Array(10);
        let normal_step_TextRotate_img_width = 20;
        let normal_system_lock_img = ''
        let normal_system_dnd_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg_img = ''
        let idle_heart_rate_TextRotate = new Array(3);
        let idle_heart_rate_TextRotate_ASCIIARRAY = new Array(10);
        let idle_heart_rate_TextRotate_img_width = 20;
        let idle_step_TextRotate = new Array(5);
        let idle_step_TextRotate_ASCIIARRAY = new Array(10);
        let idle_step_TextRotate_img_width = 20;
        let idle_system_lock_img = ''
        let idle_system_dnd_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_battery_image_progress_img_level = ''
        let idle_date_img_date_month = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_week_img = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let idle_second_TextRotate = new Array(2);
        let idle_second_TextRotate_ASCIIARRAY = new Array(10);
        let idle_second_TextRotate_img_width = 28;
        let idle_timerTextUpdate = undefined;
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_analog_clock_pro_second_pointer_img = ''
        let idle_timerUpdateSec = undefined;
        let idle_image_img = ''
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg0010.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_heart_rate_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 429,
              // y: 240,
              // font_array: ["3_data0.png","3_data1.png","3_data2.png","3_data3.png","3_data4.png","3_data5.png","3_data6.png","3_data7.png","3_data8.png","3_data9.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 4,
              // angle: -90,
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_heart_rate_TextRotate_ASCIIARRAY[0] = '3_data0.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[1] = '3_data1.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[2] = '3_data2.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[3] = '3_data3.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[4] = '3_data4.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[5] = '3_data5.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[6] = '3_data6.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[7] = '3_data7.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[8] = '3_data8.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[9] = '3_data9.png';  // set of images with numbers

            //#region TextRotate
            for (let i = 0; i < 3; i++) {
              normal_heart_rate_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 429,
                center_y: 240,
                pos_x: 429,
                pos_y: 240,
                angle: -90,
                src: '3_data0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_heart_rate_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //#endregion
            
            const heart_rate = hmSensor.createSensor(hmSensor.id.HEART);
            heart_rate.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            // normal_step_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 52,
              // y: 240,
              // font_array: ["3_data0.png","3_data1.png","3_data2.png","3_data3.png","3_data4.png","3_data5.png","3_data6.png","3_data7.png","3_data8.png","3_data9.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 2,
              // angle: 90,
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_step_TextRotate_ASCIIARRAY[0] = '3_data0.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[1] = '3_data1.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[2] = '3_data2.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[3] = '3_data3.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[4] = '3_data4.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[5] = '3_data5.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[6] = '3_data6.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[7] = '3_data7.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[8] = '3_data8.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[9] = '3_data9.png';  // set of images with numbers

            //#region TextRotate
            for (let i = 0; i < 5; i++) {
              normal_step_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 52,
                center_y: 240,
                pos_x: 52,
                pos_y: 240,
                angle: 90,
                src: '3_data0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_step_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //#endregion
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 320,
              y: 382,
              src: '9_lock_on.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 254,
              y: 382,
              src: '9_mute_on.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 120,
              y: 382,
              src: '8_blue_off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 187,
              y: 382,
              src: '9_alarm_on.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 289,
              y: 85,
              image_array: ["5_batt01.png","5_batt02.png","5_batt03.png","5_batt04.png","5_batt05.png","5_batt06.png","5_batt07.png","5_batt08.png","5_batt09.png","5_batt10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 340,
              month_startY: 251,
              month_sc_array: ["3_data0.png","3_data1.png","3_data2.png","3_data3.png","3_data4.png","3_data5.png","3_data6.png","3_data7.png","3_data8.png","3_data9.png"],
              month_tc_array: ["3_data0.png","3_data1.png","3_data2.png","3_data3.png","3_data4.png","3_data5.png","3_data6.png","3_data7.png","3_data8.png","3_data9.png"],
              month_en_array: ["3_data0.png","3_data1.png","3_data2.png","3_data3.png","3_data4.png","3_data5.png","3_data6.png","3_data7.png","3_data8.png","3_data9.png"],
              month_zero: 1,
              month_space: 2,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 284,
              day_startY: 251,
              day_sc_array: ["3_data0.png","3_data1.png","3_data2.png","3_data3.png","3_data4.png","3_data5.png","3_data6.png","3_data7.png","3_data8.png","3_data9.png"],
              day_tc_array: ["3_data0.png","3_data1.png","3_data2.png","3_data3.png","3_data4.png","3_data5.png","3_data6.png","3_data7.png","3_data8.png","3_data9.png"],
              day_en_array: ["3_data0.png","3_data1.png","3_data2.png","3_data3.png","3_data4.png","3_data5.png","3_data6.png","3_data7.png","3_data8.png","3_data9.png"],
              day_zero: 1,
              day_space: 2,
              day_align: hmUI.align.RIGHT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 301,
              y: 204,
              week_en: ["da1.png","da2.png","da3.png","da4.png","da5.png","da6.png","da7.png"],
              week_tc: ["da1.png","da2.png","da3.png","da4.png","da5.png","da6.png","da7.png"],
              week_sc: ["da1.png","da2.png","da3.png","da4.png","da5.png","da6.png","da7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 107,
              am_y: 312,
              am_sc_path: '6_am.png',
              am_en_path: '6_am.png',
              pm_x: 107,
              pm_y: 312,
              pm_sc_path: '7_pm.png',
              pm_en_path: '7_pm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 136,
              hour_startY: 312,
              hour_array: ["1_hrs0.png","1_hrs1.png","1_hrs2.png","1_hrs3.png","1_hrs4.png","1_hrs5.png","1_hrs6.png","1_hrs7.png","1_hrs8.png","1_hrs9.png"],
              hour_zero: 1,
              hour_space: 2,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 236,
              minute_startY: 312,
              minute_array: ["1_hrs0.png","1_hrs1.png","1_hrs2.png","1_hrs3.png","1_hrs4.png","1_hrs5.png","1_hrs6.png","1_hrs7.png","1_hrs8.png","1_hrs9.png"],
              minute_zero: 1,
              minute_space: 2,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 316,
              second_startY: 330,
              second_array: ["2_sec0.png","2_sec1.png","2_sec2.png","2_sec3.png","2_sec4.png","2_sec5.png","2_sec6.png","2_sec7.png","2_sec8.png","2_sec9.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: '10_pointer_hs.png',
              hour_centerX: 179,
              hour_centerY: 168,
              hour_posX: 3,
              hour_posY: 82,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: '10_pointer_min.png',
              minute_centerX: 179,
              minute_centerY: 168,
              minute_posX: 3,
              minute_posY: 82,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: '10_pointer_sec.png',
              second_centerX: 179,
              second_centerY: 168,
              second_posX: 3,
              second_posY: 82,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg0010.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_heart_rate_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 429,
              // y: 240,
              // font_array: ["3_data0.png","3_data1.png","3_data2.png","3_data3.png","3_data4.png","3_data5.png","3_data6.png","3_data7.png","3_data8.png","3_data9.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 4,
              // angle: -90,
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_heart_rate_TextRotate_ASCIIARRAY[0] = '3_data0.png';  // set of images with numbers
            idle_heart_rate_TextRotate_ASCIIARRAY[1] = '3_data1.png';  // set of images with numbers
            idle_heart_rate_TextRotate_ASCIIARRAY[2] = '3_data2.png';  // set of images with numbers
            idle_heart_rate_TextRotate_ASCIIARRAY[3] = '3_data3.png';  // set of images with numbers
            idle_heart_rate_TextRotate_ASCIIARRAY[4] = '3_data4.png';  // set of images with numbers
            idle_heart_rate_TextRotate_ASCIIARRAY[5] = '3_data5.png';  // set of images with numbers
            idle_heart_rate_TextRotate_ASCIIARRAY[6] = '3_data6.png';  // set of images with numbers
            idle_heart_rate_TextRotate_ASCIIARRAY[7] = '3_data7.png';  // set of images with numbers
            idle_heart_rate_TextRotate_ASCIIARRAY[8] = '3_data8.png';  // set of images with numbers
            idle_heart_rate_TextRotate_ASCIIARRAY[9] = '3_data9.png';  // set of images with numbers

            //#region TextRotate
            for (let i = 0; i < 3; i++) {
              idle_heart_rate_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 429,
                center_y: 240,
                pos_x: 429,
                pos_y: 240,
                angle: -90,
                src: '3_data0.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_heart_rate_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //#endregion

            // idle_step_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 52,
              // y: 240,
              // font_array: ["3_data0.png","3_data1.png","3_data2.png","3_data3.png","3_data4.png","3_data5.png","3_data6.png","3_data7.png","3_data8.png","3_data9.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 2,
              // angle: 90,
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_step_TextRotate_ASCIIARRAY[0] = '3_data0.png';  // set of images with numbers
            idle_step_TextRotate_ASCIIARRAY[1] = '3_data1.png';  // set of images with numbers
            idle_step_TextRotate_ASCIIARRAY[2] = '3_data2.png';  // set of images with numbers
            idle_step_TextRotate_ASCIIARRAY[3] = '3_data3.png';  // set of images with numbers
            idle_step_TextRotate_ASCIIARRAY[4] = '3_data4.png';  // set of images with numbers
            idle_step_TextRotate_ASCIIARRAY[5] = '3_data5.png';  // set of images with numbers
            idle_step_TextRotate_ASCIIARRAY[6] = '3_data6.png';  // set of images with numbers
            idle_step_TextRotate_ASCIIARRAY[7] = '3_data7.png';  // set of images with numbers
            idle_step_TextRotate_ASCIIARRAY[8] = '3_data8.png';  // set of images with numbers
            idle_step_TextRotate_ASCIIARRAY[9] = '3_data9.png';  // set of images with numbers

            //#region TextRotate
            for (let i = 0; i < 5; i++) {
              idle_step_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 52,
                center_y: 240,
                pos_x: 52,
                pos_y: 240,
                angle: 90,
                src: '3_data0.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_step_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //#endregion

            idle_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 320,
              y: 382,
              src: '9_lock_on.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 254,
              y: 382,
              src: '9_mute_on.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 120,
              y: 382,
              src: '8_blue_off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 187,
              y: 382,
              src: '9_alarm_on.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 289,
              y: 85,
              image_array: ["5_batt01.png","5_batt02.png","5_batt03.png","5_batt04.png","5_batt05.png","5_batt06.png","5_batt07.png","5_batt08.png","5_batt09.png","5_batt10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 340,
              month_startY: 251,
              month_sc_array: ["3_data0.png","3_data1.png","3_data2.png","3_data3.png","3_data4.png","3_data5.png","3_data6.png","3_data7.png","3_data8.png","3_data9.png"],
              month_tc_array: ["3_data0.png","3_data1.png","3_data2.png","3_data3.png","3_data4.png","3_data5.png","3_data6.png","3_data7.png","3_data8.png","3_data9.png"],
              month_en_array: ["3_data0.png","3_data1.png","3_data2.png","3_data3.png","3_data4.png","3_data5.png","3_data6.png","3_data7.png","3_data8.png","3_data9.png"],
              month_zero: 1,
              month_space: 2,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 284,
              day_startY: 251,
              day_sc_array: ["3_data0.png","3_data1.png","3_data2.png","3_data3.png","3_data4.png","3_data5.png","3_data6.png","3_data7.png","3_data8.png","3_data9.png"],
              day_tc_array: ["3_data0.png","3_data1.png","3_data2.png","3_data3.png","3_data4.png","3_data5.png","3_data6.png","3_data7.png","3_data8.png","3_data9.png"],
              day_en_array: ["3_data0.png","3_data1.png","3_data2.png","3_data3.png","3_data4.png","3_data5.png","3_data6.png","3_data7.png","3_data8.png","3_data9.png"],
              day_zero: 1,
              day_space: 2,
              day_align: hmUI.align.RIGHT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 301,
              y: 204,
              week_en: ["da1.png","da2.png","da3.png","da4.png","da5.png","da6.png","da7.png"],
              week_tc: ["da1.png","da2.png","da3.png","da4.png","da5.png","da6.png","da7.png"],
              week_sc: ["da1.png","da2.png","da3.png","da4.png","da5.png","da6.png","da7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 107,
              am_y: 312,
              am_sc_path: '6_am.png',
              am_en_path: '6_am.png',
              pm_x: 107,
              pm_y: 312,
              pm_sc_path: '7_pm.png',
              pm_en_path: '7_pm.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 136,
              hour_startY: 312,
              hour_array: ["1_hrs0.png","1_hrs1.png","1_hrs2.png","1_hrs3.png","1_hrs4.png","1_hrs5.png","1_hrs6.png","1_hrs7.png","1_hrs8.png","1_hrs9.png"],
              hour_zero: 1,
              hour_space: 2,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 236,
              minute_startY: 312,
              minute_array: ["1_hrs0.png","1_hrs1.png","1_hrs2.png","1_hrs3.png","1_hrs4.png","1_hrs5.png","1_hrs6.png","1_hrs7.png","1_hrs8.png","1_hrs9.png"],
              minute_zero: 1,
              minute_space: 2,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_second_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 316,
              // y: 330,
              // font_array: ["2_sec0.png","2_sec1.png","2_sec2.png","2_sec3.png","2_sec4.png","2_sec5.png","2_sec6.png","2_sec7.png","2_sec8.png","2_sec9.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: 0,
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.SECOND,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_second_TextRotate_ASCIIARRAY[0] = '2_sec0.png';  // set of images with numbers
            idle_second_TextRotate_ASCIIARRAY[1] = '2_sec1.png';  // set of images with numbers
            idle_second_TextRotate_ASCIIARRAY[2] = '2_sec2.png';  // set of images with numbers
            idle_second_TextRotate_ASCIIARRAY[3] = '2_sec3.png';  // set of images with numbers
            idle_second_TextRotate_ASCIIARRAY[4] = '2_sec4.png';  // set of images with numbers
            idle_second_TextRotate_ASCIIARRAY[5] = '2_sec5.png';  // set of images with numbers
            idle_second_TextRotate_ASCIIARRAY[6] = '2_sec6.png';  // set of images with numbers
            idle_second_TextRotate_ASCIIARRAY[7] = '2_sec7.png';  // set of images with numbers
            idle_second_TextRotate_ASCIIARRAY[8] = '2_sec8.png';  // set of images with numbers
            idle_second_TextRotate_ASCIIARRAY[9] = '2_sec9.png';  // set of images with numbers

            //#region TextRotate
            for (let i = 0; i < 2; i++) {
              idle_second_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 316,
                center_y: 330,
                pos_x: 316,
                pos_y: 330,
                angle: 0,
                src: '2_sec0.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_second_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //#endregion

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            let screenType = hmSetting.getScreenType();
            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: '10_pointer_hs.png',
              hour_centerX: 179,
              hour_centerY: 168,
              hour_posX: 3,
              hour_posY: 82,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: '10_pointer_min.png',
              minute_centerX: 179,
              minute_centerY: 168,
              minute_posX: 3,
              minute_posY: 82,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            const deviceInfo = hmSetting.getDeviceInfo();
            // idle_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: '10_pointer_sec.png',
              // center_x: 179,
              // center_y: 168,
              // x: 3,
              // y: 82,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });


            idle_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 179 - 3,
              pos_y: 168 - 82,
              center_x: 179,
              center_y: 168,
              src: '10_pointer_sec.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'bg_fill_20.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            //#region time_update
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              // Second Pointer
              let idle_fullAngle_second = 360;
              let idle_angle_second = 0 + idle_fullAngle_second*second/60;
              if (idle_analog_clock_pro_second_pointer_img) idle_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, idle_angle_second);

            };

            //#endregion
            //#region text_update
            function text_update() {
              console.log('text_update()');

              console.log('update text rotate heart_rate_HEART');
              let valueHeartRate = heart_rate.last;
              let normal_heart_rate_rotate_string = parseInt(valueHeartRate).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  normal_heart_rate_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueHeartRate != null && valueHeartRate != undefined && isFinite(valueHeartRate) && normal_heart_rate_rotate_string.length > 0 && normal_heart_rate_rotate_string.length <= 3) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let normal_heart_rate_TextRotate_posOffset = normal_heart_rate_TextRotate_img_width * normal_heart_rate_rotate_string.length;
                  normal_heart_rate_TextRotate_posOffset = normal_heart_rate_TextRotate_posOffset + 4 * (normal_heart_rate_rotate_string.length - 1);
                  img_offset -= normal_heart_rate_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_heart_rate_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_heart_rate_TextRotate[index].setProperty(hmUI.prop.POS_X, 429 + img_offset);
                      normal_heart_rate_TextRotate[index].setProperty(hmUI.prop.SRC, normal_heart_rate_TextRotate_ASCIIARRAY[charCode]);
                      normal_heart_rate_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_heart_rate_TextRotate_img_width + 4;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate step_STEP');
              let valueStep = step.current;
              let normal_step_rotate_string = parseInt(valueStep).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  normal_step_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueStep != null && valueStep != undefined && isFinite(valueStep) && normal_step_rotate_string.length > 0 && normal_step_rotate_string.length <= 5) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let normal_step_TextRotate_posOffset = normal_step_TextRotate_img_width * normal_step_rotate_string.length;
                  normal_step_TextRotate_posOffset = normal_step_TextRotate_posOffset + 2 * (normal_step_rotate_string.length - 1);
                  img_offset -= normal_step_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_step_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_step_TextRotate[index].setProperty(hmUI.prop.POS_X, 52 + img_offset);
                      normal_step_TextRotate[index].setProperty(hmUI.prop.SRC, normal_step_TextRotate_ASCIIARRAY[charCode]);
                      normal_step_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_step_TextRotate_img_width + 2;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate heart_rate_HEART');
              let idle_heart_rate_rotate_string = parseInt(valueHeartRate).toString();

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  idle_heart_rate_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueHeartRate != null && valueHeartRate != undefined && isFinite(valueHeartRate) && idle_heart_rate_rotate_string.length > 0 && idle_heart_rate_rotate_string.length <= 3) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let idle_heart_rate_TextRotate_posOffset = idle_heart_rate_TextRotate_img_width * idle_heart_rate_rotate_string.length;
                  idle_heart_rate_TextRotate_posOffset = idle_heart_rate_TextRotate_posOffset + 4 * (idle_heart_rate_rotate_string.length - 1);
                  img_offset -= idle_heart_rate_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of idle_heart_rate_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_heart_rate_TextRotate[index].setProperty(hmUI.prop.POS_X, 429 + img_offset);
                      idle_heart_rate_TextRotate[index].setProperty(hmUI.prop.SRC, idle_heart_rate_TextRotate_ASCIIARRAY[charCode]);
                      idle_heart_rate_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_heart_rate_TextRotate_img_width + 4;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate step_STEP');
              let idle_step_rotate_string = parseInt(valueStep).toString();

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  idle_step_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueStep != null && valueStep != undefined && isFinite(valueStep) && idle_step_rotate_string.length > 0 && idle_step_rotate_string.length <= 5) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let idle_step_TextRotate_posOffset = idle_step_TextRotate_img_width * idle_step_rotate_string.length;
                  idle_step_TextRotate_posOffset = idle_step_TextRotate_posOffset + 2 * (idle_step_rotate_string.length - 1);
                  img_offset -= idle_step_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of idle_step_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_step_TextRotate[index].setProperty(hmUI.prop.POS_X, 52 + img_offset);
                      idle_step_TextRotate[index].setProperty(hmUI.prop.SRC, idle_step_TextRotate_ASCIIARRAY[charCode]);
                      idle_step_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_step_TextRotate_img_width + 2;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate second_TIME');
              let valueSecond = timeSensor.second;
              let idle_second_rotate_string = parseInt(valueSecond).toString();
              idle_second_rotate_string = idle_second_rotate_string.padStart(2, '0');

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  idle_second_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueSecond != null && valueSecond != undefined && isFinite(valueSecond) && idle_second_rotate_string.length > 0 && idle_second_rotate_string.length <= 2) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of idle_second_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_second_TextRotate[index].setProperty(hmUI.prop.POS_X, 316 + img_offset);
                      idle_second_TextRotate[index].setProperty(hmUI.prop.SRC, idle_second_TextRotate_ASCIIARRAY[charCode]);
                      idle_second_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_second_TextRotate_img_width;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

            };

            //#endregion
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                time_update(true, true);
                text_update();
                if (screenType == hmSetting.screen_type.AOD) {
                  if (!idle_timerTextUpdate) {
                    idle_timerTextUpdate = timer.createTimer(0, 1000, (function (option) {
                      text_update();
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.AOD) {
                  if (!idle_timerUpdateSec) {
                    let animDelay = timeSensor.utc % 1000;
                    let animRepeat = 1000;
                    idle_timerUpdateSec = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, false);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (idle_timerTextUpdate) {
                  timer.stopTimer(idle_timerTextUpdate);
                  idle_timerTextUpdate = undefined;
                }
                if (idle_timerUpdateSec) {
                  timer.stopTimer(idle_timerUpdateSec);
                  idle_timerUpdateSec = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                heart_rate.removeEventListener(heart.event.CURRENT, hrCurrListener);
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
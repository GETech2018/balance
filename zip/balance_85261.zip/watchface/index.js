﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js
     let strNum = 0//номер стрелки
     let strAll = 5//всего срелок

     function click_str() {
      strNum = (strNum + 1) % strAll;//по клику прибавляем к strNum 1 если strNum>6 то strNum = 0 
		 
//меняем картинки через prop.SRC по номеру strNum;
		 
      normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.SRC, 'str_H_' + strNum + '.png');
      normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.SRC, 'str_M_' + strNum + '.png');
		 
//оригинальные имена str_H_0.png str_M_0.png str_S_0.png 		 
		 
     }
		
        //vibrate (add destroy at end)
        const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE)
        function click_Vibrate() {
           vibrate.stop()
           vibrate.scene = 25
           vibrate.start()
        }

// В конце меняем 
//            onDestroy() {
//                logger.log('index page.js on destroy invoke');
//          },		

//на 		

// В конце меняем 
//            onDestroy() {
//                logger.log('index page.js on destroy invoke');
//		        vibrate && vibrate.stop();
//          },		
	



        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_date_img_date_week_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_stand_target_text_img = ''
        let normal_stand_current_text_img = ''
        let normal_stand_pointer_progress_img_pointer = ''
        let normal_calorie_current_text_img = ''
        let normal_calorie_pointer_progress_img_pointer = ''
        let normal_battery_text_text_img = ''
        let normal_battery_text_separator_img = ''
        let normal_battery_pointer_progress_img_pointer = ''
        let normal_battery_icon_img = ''
        let normal_date_img_date_day = ''
        let normal_heart_rate_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_digital_clock_img_time = ''
        let normal_analog_clock_pro_hour_pointer_img = ''
        let normal_analog_clock_pro_hour_cover_pointer_img = ''
        let normal_analog_clock_pro_minute_pointer_img = ''
        let normal_analog_clock_pro_minute_cover_pointer_img = ''
        let normal_analog_clock_pro_second_pointer_img = ''
        let normal_timerUpdateSec = undefined;
        let idle_background_bg_img = ''
        let idle_stand_target_text_img = ''
        let idle_stand_current_text_img = ''
        let idle_stand_pointer_progress_img_pointer = ''
        let idle_calorie_current_text_img = ''
        let idle_calorie_pointer_progress_img_pointer = ''
        let idle_battery_text_text_img = ''
        let idle_battery_text_separator_img = ''
        let idle_battery_pointer_progress_img_pointer = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_week_img = ''
        let idle_heart_rate_text_text_img = ''
        let idle_step_current_text_img = ''
        let idle_digital_clock_img_time = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_system_disconnect_img = ''
        let normal_step_jumpable_img_click = ''
        let normal_cal_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_battery_jumpable_img_click = ''
        let normal_stand_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 358,
              y: 329,
              week_en: ["A100_058.png","A100_059.png","A100_060.png","A100_061.png","A100_062.png","A100_063.png","A100_064.png"],
              week_tc: ["A100_058.png","A100_059.png","A100_060.png","A100_061.png","A100_062.png","A100_063.png","A100_064.png"],
              week_sc: ["A100_058.png","A100_059.png","A100_060.png","A100_061.png","A100_062.png","A100_063.png","A100_064.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 154,
              y: 413,
              src: 'bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 150,
              y: 40,
              src: 'alarms.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_target_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 142,
              y: 342,
              font_array: ["A100_032.png","A100_033.png","A100_034.png","A100_035.png","A100_036.png","A100_037.png","A100_038.png","A100_039.png","A100_040.png","A100_041.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STAND_TARGET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 40,
              y: 342,
              font_array: ["A100_032.png","A100_033.png","A100_034.png","A100_035.png","A100_036.png","A100_037.png","A100_038.png","A100_039.png","A100_040.png","A100_041.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'A100_043.png',
              unit_tc: 'A100_043.png',
              unit_en: 'A100_043.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STAND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'A100_018.png',
              center_x: 141,
              center_y: 318,
              x: 20,
              y: 78,
              start_angle: -148,
              end_angle: 150,
              invalid_visible: false,
              type: hmUI.data_type.STAND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 126,
              y: 182,
              font_array: ["A100_032.png","A100_033.png","A100_034.png","A100_035.png","A100_036.png","A100_037.png","A100_038.png","A100_039.png","A100_040.png","A100_041.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'A100_018.png',
              center_x: 175,
              center_y: 155,
              x: 20,
              y: 78,
              start_angle: -148,
              end_angle: 150,
              invalid_visible: false,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 44,
              y: 217,
              font_array: ["A100_032.png","A100_033.png","A100_034.png","A100_035.png","A100_036.png","A100_037.png","A100_038.png","A100_039.png","A100_040.png","A100_041.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 69,
              y: 184,
              src: 'batt.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'A100_140.png',
              center_x: 104,
              center_y: 226,
              x: 14,
              y: 77,
              start_angle: -137,
              end_angle: -9,
              invalid_visible: false,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 69,
              y: 183,
              src: 'batt.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 355,
              day_startY: 356,
              day_sc_array: ["A100_045.png","A100_046.png","A100_047.png","A100_048.png","A100_049.png","A100_050.png","A100_051.png","A100_052.png","A100_053.png","A100_054.png"],
              day_tc_array: ["A100_045.png","A100_046.png","A100_047.png","A100_048.png","A100_049.png","A100_050.png","A100_051.png","A100_052.png","A100_053.png","A100_054.png"],
              day_en_array: ["A100_045.png","A100_046.png","A100_047.png","A100_048.png","A100_049.png","A100_050.png","A100_051.png","A100_052.png","A100_053.png","A100_054.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 295,
              y: 108,
              font_array: ["A100_019.png","A100_020.png","A100_021.png","A100_022.png","A100_023.png","A100_024.png","A100_025.png","A100_026.png","A100_027.png","A100_028.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 287,
              y: 220,
              font_array: ["A100_019.png","A100_020.png","A100_021.png","A100_022.png","A100_023.png","A100_024.png","A100_025.png","A100_026.png","A100_027.png","A100_028.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 240,
              hour_startY: 300,
              hour_array: ["A100_067.png","A100_068.png","A100_069.png","A100_070.png","A100_071.png","A100_072.png","A100_073.png","A100_074.png","A100_075.png","A100_076.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 226,
              minute_startY: 353,
              minute_array: ["A100_067.png","A100_068.png","A100_069.png","A100_070.png","A100_071.png","A100_072.png","A100_073.png","A100_074.png","A100_075.png","A100_076.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const deviceInfo = hmSetting.getDeviceInfo();
            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.MINUTEEND, function() {
              let updateHour = timeSensor.minute == 0;

              time_update(updateHour, true);
            });

            // normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'str_H_0.png',
              // center_x: 240,
              // center_y: 240,
              // x: 30,
              // y: 238,
              // start_angle: 0,
              // end_angle: 360,
              // cover_path: 'A100_006.png',
              // cover_x: 215,
              // cover_y: 216,
              // type: hmUI.data_type.hour,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 30,
              pos_y: 240 - 238,
              center_x: 240,
              center_y: 240,
              src: 'str_H_0.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_pro_hour_cover_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 215,
              y: 216,
              src: 'A100_006.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'str_M_0.png',
              // center_x: 240,
              // center_y: 240,
              // x: 30,
              // y: 234,
              // start_angle: 0,
              // end_angle: 360,
              // cover_path: 'A100_009.png',
              // cover_x: 225,
              // cover_y: 226,
              // type: hmUI.data_type.minute,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 30,
              pos_y: 240 - 234,
              center_x: 240,
              center_y: 240,
              src: 'str_M_0.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_pro_minute_cover_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 225,
              y: 226,
              src: 'A100_009.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'str_S_0.png',
              // center_x: 240,
              // center_y: 240,
              // x: 22,
              // y: 232,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 22,
              pos_y: 240 - 232,
              center_x: 240,
              center_y: 240,
              src: 'str_S_0.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();

            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'A100_003.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_stand_target_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 142,
              y: 342,
              font_array: ["A100_032.png","A100_033.png","A100_034.png","A100_035.png","A100_036.png","A100_037.png","A100_038.png","A100_039.png","A100_040.png","A100_041.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STAND_TARGET,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_stand_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 40,
              y: 342,
              font_array: ["A100_032.png","A100_033.png","A100_034.png","A100_035.png","A100_036.png","A100_037.png","A100_038.png","A100_039.png","A100_040.png","A100_041.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'A100_043.png',
              unit_tc: 'A100_043.png',
              unit_en: 'A100_043.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STAND,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_stand_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'A100_018.png',
              center_x: 141,
              center_y: 318,
              x: 20,
              y: 78,
              start_angle: -148,
              end_angle: 150,
              invalid_visible: false,
              type: hmUI.data_type.STAND,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 126,
              y: 182,
              font_array: ["A100_032.png","A100_033.png","A100_034.png","A100_035.png","A100_036.png","A100_037.png","A100_038.png","A100_039.png","A100_040.png","A100_041.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'A100_018.png',
              center_x: 175,
              center_y: 155,
              x: 20,
              y: 78,
              start_angle: -148,
              end_angle: 150,
              invalid_visible: false,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 44,
              y: 217,
              font_array: ["A100_032.png","A100_033.png","A100_034.png","A100_035.png","A100_036.png","A100_037.png","A100_038.png","A100_039.png","A100_040.png","A100_041.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 69,
              y: 184,
              src: 'batt.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'A100_141.png',
              center_x: 104,
              center_y: 226,
              x: 14,
              y: 74,
              start_angle: -137,
              end_angle: -9,
              invalid_visible: false,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 355,
              day_startY: 356,
              day_sc_array: ["A100_032.png","A100_033.png","A100_034.png","A100_035.png","A100_036.png","A100_037.png","A100_038.png","A100_039.png","A100_040.png","A100_041.png"],
              day_tc_array: ["A100_032.png","A100_033.png","A100_034.png","A100_035.png","A100_036.png","A100_037.png","A100_038.png","A100_039.png","A100_040.png","A100_041.png"],
              day_en_array: ["A100_032.png","A100_033.png","A100_034.png","A100_035.png","A100_036.png","A100_037.png","A100_038.png","A100_039.png","A100_040.png","A100_041.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 358,
              y: 329,
              week_en: ["A100_121.png","A100_122.png","A100_123.png","A100_124.png","A100_125.png","A100_126.png","A100_127.png"],
              week_tc: ["A100_121.png","A100_122.png","A100_123.png","A100_124.png","A100_125.png","A100_126.png","A100_127.png"],
              week_sc: ["A100_121.png","A100_122.png","A100_123.png","A100_124.png","A100_125.png","A100_126.png","A100_127.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 295,
              y: 108,
              font_array: ["A100_107.png","A100_108.png","A100_109.png","A100_110.png","A100_111.png","A100_112.png","A100_113.png","A100_114.png","A100_115.png","A100_116.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 287,
              y: 220,
              font_array: ["A100_107.png","A100_108.png","A100_109.png","A100_110.png","A100_111.png","A100_112.png","A100_113.png","A100_114.png","A100_115.png","A100_116.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 240,
              hour_startY: 300,
              hour_array: ["A100_130.png","A100_131.png","A100_132.png","A100_133.png","A100_134.png","A100_135.png","A100_136.png","A100_137.png","A100_138.png","A100_139.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 226,
              minute_startY: 353,
              minute_array: ["A100_130.png","A100_131.png","A100_132.png","A100_133.png","A100_134.png","A100_135.png","A100_136.png","A100_137.png","A100_138.png","A100_139.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'A100_004.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 30,
              hour_posY: 238,
              hour_cover_path: 'A100_006.png',
              hour_cover_x: 214,
              hour_cover_y: 214,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'A100_007.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 30,
              minute_posY: 234,
              minute_cover_path: 'A100_009.png',
              minute_cover_x: 224,
              minute_cover_y: 224,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 227,
              y: 227,
              src: 'bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 298,
              y: 176,
              w: 146,
              h: 70,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_cal_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 134,
              y: 115,
              w: 80,
              h: 80,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 307,
              y: 82,
              w: 100,
              h: 65,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 13,
              y: 150,
              w: 80,
              h: 104,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 92,
              y: 270,
              w: 100,
              h: 100,
              type: hmUI.data_type.STAND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 230,
              y: 360,
              w: 114,
              h: 55,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 241,
              y: 290,
              w: 104,
              h: 60,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 360,
              y: 320,
              w: 70,
              h: 57,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 202,
              y: 209,
              w: 84,
              h: 66,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                click_str();
click_Vibrate();

              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            //start of ignored block
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              if (updateMinute) {
                let normal_hour = hour;
                let normal_fullAngle_hour = 360;
                if (normal_hour > 11) normal_hour -= 12;
                let normal_angle_hour = 0 + normal_fullAngle_hour*normal_hour/12 + (normal_fullAngle_hour/12)*minute/60;
                if (normal_analog_clock_pro_hour_pointer_img) normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_hour);
              };

              if (updateMinute) {
                let normal_fullAngle_minute = 360;
                let normal_angle_minute = 0 + normal_fullAngle_minute*minute/60;
                if (normal_analog_clock_pro_minute_pointer_img) normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_minute);
              };

              let normal_fullAngle_second = 360;
              let normal_angle_second = 0 + normal_fullAngle_second*second/60;
              if (normal_analog_clock_pro_second_pointer_img) normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_second);

            };

            //end of ignored block
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                time_update(true, true);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSec) {
                    let animDelay = timeSensor.utc % 1000;
                    let animRepeat = 1000;
                    normal_timerUpdateSec = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, false);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerUpdateSec) {
                  timer.stopTimer(normal_timerUpdateSec);
                  normal_timerUpdateSec = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
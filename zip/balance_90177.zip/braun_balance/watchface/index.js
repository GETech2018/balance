import * as hmUI from '@zos/ui'

// Diseño original en 454 px, escalado x1,057 para los 480 px del Balance
const DIGITS = ['0005.png','0006.png','0007.png','0008.png','0009.png',
                '0010.png','0011.png','0012.png','0013.png','0014.png']

const NORMAL = hmUI.show_level.ONLY_NORMAL

// Centro del hub azul medido sobre el fondo
const CX = 239
const CY = 242

WatchFace({
  build() {
    // ---------- Fondo ----------
    hmUI.createWidget(hmUI.widget.IMG, {
      x: 0, y: 0, w: 480, h: 480,
      src: 'Braun-0.png',
      show_level: NORMAL
    })

    // ---------- Fecha: día dentro de la ventanilla (normal) ----------
    hmUI.createWidget(hmUI.widget.IMG_DATE, {
      day_startX: 227, day_startY: 384,
      day_sc_array: DIGITS, day_tc_array: DIGITS, day_en_array: DIGITS,
      day_zero: 0, day_space: -6,
      day_align: hmUI.align.LEFT,
      day_is_character: false,
      show_level: NORMAL
    })



    // ---------- Agujas ----------
    hmUI.createWidget(hmUI.widget.TIME_POINTER, {
      hour_path: 'Braun-Hora.png', hour_centerX: CX, hour_centerY: CY, hour_posX: 68, hour_posY: 245,
      show_level: NORMAL
    })
    hmUI.createWidget(hmUI.widget.TIME_POINTER, {
      minute_path: 'Braun-Min.png', minute_centerX: CX, minute_centerY: CY, minute_posX: 68, minute_posY: 245,
      show_level: NORMAL
    })
    hmUI.createWidget(hmUI.widget.TIME_POINTER, {
      second_path: 'Braun-Seg.png', second_centerX: CX, second_centerY: CY, second_posX: 68, second_posY: 245,
      show_level: NORMAL
    })
  }
})

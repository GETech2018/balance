﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_uvi_text_text_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_distance_text_text_img = ''
        let normal_battery_text_text_img = ''
        let normal_sun_high_text_img = ''
        let normal_sun_low_text_img = ''
        let normal_heart_rate_circle_scale = ''
        let normal_heart_rate_text_text_img = ''
        let normal_calorie_circle_scale = ''
        let normal_calorie_current_text_img = ''
        let normal_step_circle_scale = ''
        let normal_step_current_text_img = ''
        let normal_date_img_date_month_img = ''
        let normal_day_text_font = ''
        let normal_date_img_date_week_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_city_name_text = ''
        let normal_digital_clock_img_time = ''
        let idle_digital_clock_img_time = ''
        let image_top_img = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            // FontName: Agency FB Bold.ttf; FontSize: 30
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 296,
              h: 43,
              text_size: 30,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Agency FB Bold.ttf',
              color: 0xFFFF0000,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: Agency FB Bold.ttf; FontSize: 24; Cache: full
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 28,
              h: 28,
              text_size: 24,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Agency FB Bold.ttf',
              color: 0xFFFF8C00,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: '0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_uvi_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 277,
              y: 384,
              font_array: ["N_0.png","N_1.png","N_2.png","N_3.png","N_4.png","N_5.png","N_6.png","N_7.png","N_8.png","N_9.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.UVI,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 336,
              y: 408,
              src: 'bt6.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 427,
              y: 281,
              src: 'alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 131,
              y: 380,
              font_array: ["0050.png","0051.png","0052.png","0053.png","0054.png","0055.png","0056.png","0057.png","0058.png","0059.png"],
              padding: false,
              h_space: -1,
              dot_image: 'Punt.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 212,
              y: 429,
              font_array: ["0038.png","0039.png","0040.png","0041.png","0042.png","0043.png","0044.png","0045.png","0046.png","0047.png"],
              padding: false,
              h_space: -2,
              unit_sc: '0048.png',
              unit_tc: '0048.png',
              unit_en: '0048.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 284,
              y: 236,
              font_array: ["R_0.png","R_1.png","R_2.png","R_3.png","R_4.png","R_5.png","R_6.png","R_7.png","R_8.png","R_9.png"],
              padding: false,
              h_space: 0,
              dot_image: 'Punt-.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 405,
              y: 236,
              font_array: ["R_0.png","R_1.png","R_2.png","R_3.png","R_4.png","R_5.png","R_6.png","R_7.png","R_8.png","R_9.png"],
              padding: false,
              h_space: -1,
              dot_image: 'Punt-.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_heart_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 369,
              // center_y: 342,
              // start_angle: -137,
              // end_angle: 135,
              // radius: 61,
              // line_width: 15,
              // line_cap: Flat,
              // color: 0xFFFF0000,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            let screenType = hmSetting.getScreenType();
            normal_heart_rate_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 369,
              center_y: 342,
              start_angle: -137,
              end_angle: 135,
              radius: 54,
              line_width: 15,
              corner_flag: 3,
              color: 0xFFFF0000,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const heart_rate = hmSensor.createSensor(hmSensor.id.HEART);
            heart_rate.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 336,
              y: 340,
              font_array: ["0062.png","0063.png","0064.png","0065.png","0066.png","0067.png","0068.png","0069.png","0070.png","0071.png"],
              padding: false,
              h_space: -2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_cal_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 264,
              // center_y: 350,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 16,
              // line_width: 15,
              // line_cap: Flat,
              // color: 0xFFFF8C00,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_calorie_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 264,
              center_y: 350,
              start_angle: 0,
              end_angle: 360,
              radius: 9,
              line_width: 15,
              corner_flag: 3,
              color: 0xFFFF8C00,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const calorie = hmSensor.createSensor(hmSensor.id.CALORIE);
            calorie.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 118,
              y: 332,
              font_array: ["0050.png","0051.png","0052.png","0053.png","0054.png","0055.png","0056.png","0057.png","0058.png","0059.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 265,
              // center_y: 302,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 16,
              // line_width: 15,
              // line_cap: Flat,
              // color: 0xFF0056AC,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 265,
              center_y: 302,
              start_angle: 0,
              end_angle: 360,
              radius: 9,
              line_width: 15,
              corner_flag: 3,
              color: 0xFF0056AC,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 103,
              y: 280,
              font_array: ["0050.png","0051.png","0052.png","0053.png","0054.png","0055.png","0056.png","0057.png","0058.png","0059.png"],
              padding: false,
              h_space: -3,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 387,
              month_startY: 192,
              month_sc_array: ["month_0.png","month_1.png","month_2.png","month_3.png","month_4.png","month_5.png","month_6.png","month_7.png","month_8.png","month_9.png","month_10.png","month_11.png"],
              month_tc_array: ["month_0.png","month_1.png","month_2.png","month_3.png","month_4.png","month_5.png","month_6.png","month_7.png","month_8.png","month_9.png","month_10.png","month_11.png"],
              month_en_array: ["month_0.png","month_1.png","month_2.png","month_3.png","month_4.png","month_5.png","month_6.png","month_7.png","month_8.png","month_9.png","month_10.png","month_11.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function() {
              time_update(true);
            });

            normal_day_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 284,
              y: 186,
              w: 150,
              h: 30,
              text_size: 30,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Agency FB Bold.ttf',
              color: 0xFFFF0000,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 259,
              y: 192,
              week_en: ["week_0.png","week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png"],
              week_tc: ["week_0.png","week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png"],
              week_sc: ["week_0.png","week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 27,
              y: 184,
              image_array: ["weather_01.png","weather_02.png","weather_03.png","weather_04.png","weather_05.png","weather_06.png","weather_07.png","weather_08.png","weather_09.png","weather_10.png","weather_11.png","weather_12.png","weather_13.png","weather_14.png","weather_15.png","weather_16.png","weather_17.png","weather_18.png","weather_19.png","weather_20.png","weather_21.png","weather_22.png","weather_23.png","weather_24.png","weather_25.png","weather_26.png","weather_27.png","weather_28.png","weather_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 109,
              y: 232,
              font_array: ["N_0.png","N_1.png","N_2.png","N_3.png","N_4.png","N_5.png","N_6.png","N_7.png","N_8.png","N_9.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'GRAD-1.png',
              unit_tc: 'GRAD-1.png',
              unit_en: 'GRAD-1.png',
              negative_image: 'nega11.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 140,
              y: 188,
              w: 150,
              h: 30,
              text_size: 24,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Agency FB Bold.ttf',
              color: 0xFFFF8C00,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 115,
              hour_startY: 56,
              hour_array: ["0002.png","0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_unit_sc: '0012.png',
              hour_unit_tc: '0012.png',
              hour_unit_en: '0012.png',
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 255,
              minute_startY: 56,
              minute_array: ["0002.png","0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 213,
              second_startY: 5,
              second_array: ["0038.png","0039.png","0040.png","0041.png","0042.png","0043.png","0044.png","0045.png","0046.png","0047.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 111,
              hour_startY: 92,
              hour_array: ["0165.png","0166.png","0167.png","0168.png","0169.png","0170.png","0171.png","0172.png","0173.png","0174.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 226,
              minute_startY: 92,
              minute_array: ["0165.png","0166.png","0167.png","0168.png","0169.png","0170.png","0171.png","0172.png","0173.png","0174.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 324,
              second_startY: 119,
              second_array: ["0038.png","0039.png","0040.png","0041.png","0042.png","0043.png","0044.png","0045.png","0046.png","0047.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 9,
              // disconneсnt_toast_text: BT OFF,
              // conneсnt_vibrate_type: 0,
              // conneсnt_toast_text: BT ON,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              console.log('checkConnection()');
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  hmUI.showToast({text: "BT OFF"});
                  vibro(9);
                }
                if(status) {
                  hmUI.showToast({text: "BT ON"});
                  vibro(0);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              if (scene != 1) timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function

            image_top_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'can9.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 260,
              y: 378,
              w: 48,
              h: 46,
              text: '',
              color: 0xFFFF8C00,
              text_size: 26,
              press_src: 'transparent.png',
              normal_src: 'transparent.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PhoneHomeScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 177,
              y: 430,
              w: 129,
              h: 46,
              text: '',
              color: 0xFFFF8C00,
              text_size: 26,
              press_src: 'transparent.png',
              normal_src: 'transparent.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PowerSaveHintScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 117,
              y: 37,
              w: 242,
              h: 46,
              text: '',
              color: 0xFFFF8C00,
              text_size: 26,
              press_src: 'transparent.png',
              normal_src: 'transparent.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 10,
              y: 198,
              w: 100,
              h: 62,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'transparent.png',
              normal_src: 'transparent.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'WeatherScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 54,
              y: 102,
              w: 100,
              h: 62,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'transparent.png',
              normal_src: 'transparent.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'Settings_homeScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            //start of ignored block
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              console.log('day font');
              if (updateHour) {
                let normal_dayStr = timeSensor.day.toString();
                normal_dayStr = normal_dayStr.padStart(2, '0');
                normal_day_text_font.setProperty(hmUI.prop.TEXT, normal_dayStr );
              };

            };

            //end of ignored block
            function scale_call() {
              console.log('scale_call()');

                console.log('update scales HEART');
                
                let valueHeartRate = heart_rate.last;
                let targetHeartRate = 179;
                let progressHeartRate = (valueHeartRate - 71)/(targetHeartRate - 71);
                if (progressHeartRate < 0) progressHeartRate = 0;
                if (progressHeartRate > 1) progressHeartRate = 1;
                let progress_cs_normal_heart_rate = progressHeartRate;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_heart_rate_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_heart_rate * 100);
                  if (normal_heart_rate_circle_scale) {
                    normal_heart_rate_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 369,
                      center_y: 342,
                      start_angle: -137,
                      end_angle: 135,
                      radius: 54,
                      line_width: 15,
                      corner_flag: 3,
                      color: 0xFFFF0000,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales CALORIE');
                
                let valueCalories = calorie.current;
                let targetCalories = calorie.target;
                let progressCalories = valueCalories/targetCalories;
                if (progressCalories > 1) progressCalories = 1;
                let progress_cs_normal_calorie = progressCalories;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_calorie_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_calorie * 100);
                  if (normal_calorie_circle_scale) {
                    normal_calorie_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 264,
                      center_y: 350,
                      start_angle: 0,
                      end_angle: 360,
                      radius: 9,
                      line_width: 15,
                      corner_flag: 3,
                      color: 0xFFFF8C00,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_cs_normal_step = progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_step * 100);
                  if (normal_step_circle_scale) {
                    normal_step_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 265,
                      center_y: 302,
                      start_angle: 0,
                      end_angle: 360,
                      radius: 9,
                      line_width: 15,
                      corner_flag: 3,
                      color: 0xFF0056AC,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

              console.log('Weather city name');
              let weatherData = weatherSensor.getForecastWeather();
              normal_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                time_update(true, true);
                checkConnection();
                stopVibro();

              }),
              pause_call: (function () {
                console.log('pause_call()');
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
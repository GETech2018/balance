/*
** Facemaker bundle tool v0.0.3
* *huamiOS watchface js version v4.4.0.1
* *Copyright © Huami. All Rights Reserved
*/


try {
	(() => {
		var __$$app$$__ = __$$hmAppManager$$__.currentApp;
		var __$$module$$__ = __$$app$$__.current;

		//drink is a name,can modify
		var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

		'use strict';

		//dynamic modify start
		let normal_random_bg0 = '';
		let normal_random_bg0_array = ['0002.png','0003.png','0004.png','0005.png','0006.png'];
		let normal_img1 = '';
		let normal_img2 = '';
		let normal_img3 = '';
		let normal_img4 = '';
		let normal_img5 = '';
		let normal_img6 = '';
		let normal_steps_imagecombo8 = '';
		let normal_distance_imagecombo10 = '';
		let normal_heart_current_imagecombo12 = '';
		let normal_stress_imagecombo14 = '';
		let normal_weather_imageset16 = '';
		let normal_temperature_current_imagecombo17 = '';
		let normal_battery_progress19 = '';
		let normal_battery_imagecombo20 = '';
		let normal_img21 = '';
		let normal_sunrise_text23 = '';
		let normal_sunset_text24 = '';
		let normal_img25 = '';
		let normal_week_imageset27 = '';
		let normal_date_imagecombo28 = '';
		let normal_month_imageset29 = '';
		let normal_hour_imagecombo31 = '';
		let normal_minute_imagecombo32 = '';
		let normal_bt_status34 = '';
		let normal_random_bg_trigger37 = '';
		let normal_alarm_shortcut38 = '';
		let normal_countdown_shortcut39 = '';
		let normal_calendar_shortcut40 = '';
		let normal_steps_shortcut41 = '';
		let normal_heart_shortcut42 = '';
		let normal_stress_shortcut43 = '';
		let normal_weather_shortcut44 = '';
		let normal_sun_shortcut45 = '';
		let normal_battery_shortcut46 = '';
		let idle_hour_imagecombo48 = '';
		let idle_minute_imagecombo49 = '';
		let idle_week_imageset51 = '';
		let idle_date_imagecombo52 = '';
		let idle_month_imageset53 = '';
		//dynamic modify end

		//not required
		const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

		__$$module$$__.module = DeviceRuntimeCore.WatchFace({
			init_view() {

				const batterySensor = hmSensor.createSensor(hmSensor.id.BATTERY);
				const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);
				let screenType = hmSetting.getScreenType();

				normal_random_bg0 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 169,
					y: 1,
					w: 230,
					h: 480,
					src: '0002.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img1 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					src: '0007.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img2 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					src: '0008.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img3 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 157,
					y: 311,
					w: 32,
					h: 32,
					src: '0009.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img4 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 157,
					y: 345,
					w: 29,
					h: 33,
					src: '0010.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img5 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 155,
					y: 378,
					w: 40,
					h: 30,
					src: '0011.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img6 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 159,
					y: 408,
					w: 38,
					h: 38,
					src: '0012.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_steps_imagecombo8 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 61,
					y: 313,
					font_array: ["0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png"],
					padding: false,
					h_space: -2,
					align_h: hmUI.align.RIGHT,
					type: hmUI.data_type.STEP,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_distance_imagecombo10 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 80,
					y: 346,
					font_array: ["0023.png","0024.png","0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png"],
					padding: false,
					h_space: -2,
					dot_image: '0033.png',
					align_h: hmUI.align.RIGHT,
					type: hmUI.data_type.DISTANCE,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_heart_current_imagecombo12 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 98,
					y: 379,
					font_array: ["0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png","0043.png"],
					padding: false,
					h_space: -2,
					invalid_image: '0044.png',
					align_h: hmUI.align.RIGHT,
					type: hmUI.data_type.HEART,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_stress_imagecombo14 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 99,
					y: 413,
					font_array: ["0045.png","0046.png","0047.png","0048.png","0049.png","0050.png","0051.png","0052.png","0053.png","0054.png"],
					padding: false,
					h_space: -2,
					align_h: hmUI.align.RIGHT,
					type: hmUI.data_type.STRESS,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_weather_imageset16 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
					x: 397,
					y: 107,
					image_array: ["0055.png","0056.png","0057.png","0058.png","0059.png","0060.png","0061.png","0062.png","0063.png","0064.png","0065.png","0066.png","0067.png","0068.png","0069.png","0070.png","0071.png","0072.png","0073.png","0074.png","0075.png","0076.png","0077.png","0078.png","0079.png","0080.png","0081.png","0082.png","0083.png"],
					image_length: 29,
					type: hmUI.data_type.WEATHER_CURRENT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_temperature_current_imagecombo17 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 387,
					y: 159,
					font_array: ["0023.png","0024.png","0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png"],
					padding: false,
					h_space: -2,
					unit_sc: ["0085.png"],
					unit_tc: ["0085.png"],
					unit_en: ["0085.png"],
					negative_image: ["0084.png"],
					invalid_image: ["0084.png"],
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.WEATHER_CURRENT,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_battery_progress19 = hmUI.createWidget(hmUI.widget.ARC, {
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});
				normal_battery_imagecombo20 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 404,
					y: 235,
					font_array: ["0086.png","0087.png","0088.png","0089.png","0090.png","0091.png","0092.png","0093.png","0094.png","0095.png"],
					padding: false,
					h_space: -4,
					unit_sc: '0096.png',
					unit_tc: '0096.png',
					unit_en: '0096.png',
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.BATTERY,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img21 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 409,
					y: 201,
					w: 36,
					h: 36,
					src: '0097.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_sunrise_text23 = hmUI.createWidget(hmUI.widget.TEXT, {
					x: 369,
					y: 287,
					w: 100,
					h: 24,
					color: 0xE2A073,
					text_size: 24,
					align_h: hmUI.align.CENTER_H,
					align_v: hmUI.align.CENTER_V,
					text_style: hmUI.text_style.NONE,
					font: 'fonts/Roboto-Medium.ttf',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_sunset_text24 = hmUI.createWidget(hmUI.widget.TEXT, {
					x: 369,
					y: 332,
					w: 100,
					h: 24,
					color: 0x73ACE2,
					text_size: 24,
					align_h: hmUI.align.CENTER_H,
					align_v: hmUI.align.CENTER_V,
					text_style: hmUI.text_style.NONE,
					font: 'fonts/Roboto-Medium.ttf',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img25 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 397,
					y: 306,
					w: 38,
					h: 27,
					src: '0098.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_week_imageset27 = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
					x: 139,
					y: 110,
					week_en: ["0099.png","0100.png","0101.png","0102.png","0103.png","0104.png","0105.png"],
					week_tc: ["0099.png","0100.png","0101.png","0102.png","0103.png","0104.png","0105.png"],
					week_sc: ["0099.png","0100.png","0101.png","0102.png","0103.png","0104.png","0105.png"],
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_date_imagecombo28 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
					day_startX: 84,
					day_startY: 72,
					day_sc_array: ["0106.png","0107.png","0108.png","0109.png","0110.png","0111.png","0112.png","0113.png","0114.png","0115.png"],
					day_tc_array: ["0106.png","0107.png","0108.png","0109.png","0110.png","0111.png","0112.png","0113.png","0114.png","0115.png"],
					day_en_array: ["0106.png","0107.png","0108.png","0109.png","0110.png","0111.png","0112.png","0113.png","0114.png","0115.png"],
					day_zero: true,
					day_space: 0,
					day_align: hmUI.align.CENTER_H,
					day_is_character: false,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_month_imageset29 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
					month_startX: 126,
					month_startY: 60,
					month_sc_array: ["0116.png","0117.png","0118.png","0119.png","0120.png","0121.png","0122.png","0123.png","0124.png","0125.png","0126.png","0127.png"],
					month_tc_array: ["0116.png","0117.png","0118.png","0119.png","0120.png","0121.png","0122.png","0123.png","0124.png","0125.png","0126.png","0127.png"],
					month_en_array: ["0116.png","0117.png","0118.png","0119.png","0120.png","0121.png","0122.png","0123.png","0124.png","0125.png","0126.png","0127.png"],
					month_is_character: true,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_hour_imagecombo31 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					hour_startX: 5,
					hour_startY: 97,
					hour_array: ["0128.png","0129.png","0130.png","0131.png","0132.png","0133.png","0134.png","0135.png","0136.png","0137.png"],
					hour_zero: true,
					hour_space: -59,
					hour_align: hmUI.align.CENTER_H,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_minute_imagecombo32 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					minute_startX: 5,
					minute_startY: 193,
					minute_array: ["0128.png","0129.png","0130.png","0131.png","0132.png","0133.png","0134.png","0135.png","0136.png","0137.png"],
					minute_zero: true,
					minute_space: -59,
					minute_align: hmUI.align.CENTER_H,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_bt_status34 = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
					x: 143,
					y: 25,
					w: 41,
					h: 41,
					type: hmUI.system_status.DISCONNECT,
					src: '0138.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_random_bg_trigger37 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					src: '0139.png',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_random_bg_trigger37.addEventListener(hmUI.event.CLICK_DOWN, function() {
					normal_random_bg0.setProperty(hmUI.prop.SRC, normal_random_bg0_array[Math.floor(Math.random() * normal_random_bg0_array.length)]);
				});

				normal_alarm_shortcut38 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 49,
					y: 121,
					w: 100,
					h: 86,
					src: '0139.png',
					type: hmUI.data_type.ALARM_CLOCK,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_countdown_shortcut39 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 37,
					y: 217,
					w: 100,
					h: 85,
					src: '',
					type: hmUI.data_type.COUNT_DOWN,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_calendar_shortcut40 = hmUI.createWidget(hmUI.widget.BUTTON, {
					x: 89,
					y: 37,
					w: 100,
					h: 69,
					text: '',
					normal_src: '',
					press_src: '',
					click_func: () => {
						hmApp.startApp({ url: 'ScheduleCalScreen', native: true });
					},
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_steps_shortcut41 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 73,
					y: 313,
					w: 105,
					h: 56,
					src: '',
					type: hmUI.data_type.STEP,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_heart_shortcut42 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 87,
					y: 378,
					w: 100,
					h: 29,
					src: '',
					type: hmUI.data_type.HEART,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_stress_shortcut43 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 93,
					y: 415,
					w: 100,
					h: 30,
					src: '',
					type: hmUI.data_type.STRESS,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_weather_shortcut44 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 380,
					y: 97,
					w: 100,
					h: 100,
					src: '',
					type: hmUI.data_type.WEATHER_CURRENT,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_sun_shortcut45 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 380,
					y: 289,
					w: 100,
					h: 100,
					src: '',
					type: hmUI.data_type.SUN_CURRENT,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_battery_shortcut46 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 380,
					y: 199,
					w: 100,
					h: 81,
					src: '',
					type: hmUI.data_type.BATTERY,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				idle_hour_imagecombo48 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					hour_startX: 5,
					hour_startY: 97,
					hour_array: ["0128.png","0129.png","0130.png","0131.png","0132.png","0133.png","0134.png","0135.png","0136.png","0137.png"],
					hour_zero: true,
					hour_space: -59,
					hour_align: hmUI.align.CENTER_H,
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_minute_imagecombo49 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					minute_startX: 5,
					minute_startY: 193,
					minute_array: ["0128.png","0129.png","0130.png","0131.png","0132.png","0133.png","0134.png","0135.png","0136.png","0137.png"],
					minute_zero: true,
					minute_space: -59,
					minute_align: hmUI.align.CENTER_H,
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_week_imageset51 = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
					x: 139,
					y: 110,
					week_en: ["0099.png","0100.png","0101.png","0102.png","0103.png","0104.png","0105.png"],
					week_tc: ["0099.png","0100.png","0101.png","0102.png","0103.png","0104.png","0105.png"],
					week_sc: ["0099.png","0100.png","0101.png","0102.png","0103.png","0104.png","0105.png"],
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_date_imagecombo52 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
					day_startX: 84,
					day_startY: 72,
					day_sc_array: ["0106.png","0107.png","0108.png","0109.png","0110.png","0111.png","0112.png","0113.png","0114.png","0115.png"],
					day_tc_array: ["0106.png","0107.png","0108.png","0109.png","0110.png","0111.png","0112.png","0113.png","0114.png","0115.png"],
					day_en_array: ["0106.png","0107.png","0108.png","0109.png","0110.png","0111.png","0112.png","0113.png","0114.png","0115.png"],
					day_zero: true,
					day_space: 0,
					day_align: hmUI.align.CENTER_H,
					day_is_character: false,
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_month_imageset53 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
					month_startX: 126,
					month_startY: 60,
					month_sc_array: ["0140.png","0141.png","0142.png","0143.png","0144.png","0145.png","0146.png","0147.png","0148.png","0149.png","0150.png","0151.png"],
					month_tc_array: ["0140.png","0141.png","0142.png","0143.png","0144.png","0145.png","0146.png","0147.png","0148.png","0149.png","0150.png","0151.png"],
					month_en_array: ["0140.png","0141.png","0142.png","0143.png","0144.png","0145.png","0146.png","0147.png","0148.png","0149.png","0150.png","0151.png"],
					month_is_character: true,
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				function updateBattery() {
					var current_normal_battery_progress19 = batterySensor.current;
					var target_normal_battery_progress19 = 100;
					var progress_normal_battery_progress19 = current_normal_battery_progress19 / target_normal_battery_progress19;

					if (progress_normal_battery_progress19 > 1) {
						progress_normal_battery_progress19 = 1;
					}

					var pcs_normal_battery_progress19 = progress_normal_battery_progress19;

					if (screenType != hmSetting.screen_type.AOD) {
						// initial parameters
						var sa_normal_battery_progress19 = -90;
						var ea_normal_battery_progress19 = 270;
						var cx_normal_battery_progress19 = 431;
						var cy_normal_battery_progress19 = 238;
						var r_normal_battery_progress19 = 41;
						var lw_normal_battery_progress19 = 6;
						var c_normal_battery_progress19 = 0xFF6EB2E2;

						// calculated parameters
						var ax_normal_battery_progress19 = cx_normal_battery_progress19 - r_normal_battery_progress19;
						var ay_normal_battery_progress19 = cy_normal_battery_progress19 - r_normal_battery_progress19;
						var cw_normal_battery_progress19 = 2 * r_normal_battery_progress19;
						var ao_normal_battery_progress19 = ea_normal_battery_progress19 - sa_normal_battery_progress19;
						ao_normal_battery_progress19 = ao_normal_battery_progress19 * pcs_normal_battery_progress19;
						var ea_normal_battery_progress19_draw = sa_normal_battery_progress19 + ao_normal_battery_progress19;

						normal_battery_progress19.setProperty(hmUI.prop.MORE, {
							x: ax_normal_battery_progress19,
							y: ay_normal_battery_progress19,
							w: cw_normal_battery_progress19,
							h: cw_normal_battery_progress19,
							start_angle: sa_normal_battery_progress19,
							end_angle: ea_normal_battery_progress19_draw,
							color: c_normal_battery_progress19,
							line_width: lw_normal_battery_progress19,
						});
					};

				}

				function updateWeather() {
					let tideData = weatherSensor.getForecastWeather().tideData;
					normal_sunrise_text23.setProperty(hmUI.prop.TEXT, tideData.data[0].sunrise.hour.toString().padStart(2, '0') + ':' + tideData.data[0].sunrise.minute.toString().padStart(2, '0'));
					normal_sunset_text24.setProperty(hmUI.prop.TEXT, tideData.data[0].sunset.hour.toString().padStart(2, '0') + ':' + tideData.data[0].sunset.minute.toString().padStart(2, '0'));
				}

				batterySensor.addEventListener(hmSensor.event.CHANGE, function() {
					updateBattery();
				});

				weatherSensor.addEventListener(hmSensor.event.CHANGE, function() {
					updateWeather();
				});

				const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
					resume_call: (function () {
						updateBattery();
						updateWeather();
					}),
					pause_call: (function () {
					}),
				})
			},

		onInit() {
			console.log('index page.js on init invoke')
			this.init_view()
		},
		onReady() {
			console.log('index page.js on ready invoke')
		},
		onShow() {
			console.log('index page.js on show invoke')
		},
		onHide() {
			console.log('index page.js on hide invoke')
		},
		onDestroy() {
			console.log('index page.js on destroy invoke')
		},
	});	})()
} catch (e) {
	console.log(e)
}
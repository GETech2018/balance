﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_year = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_heart_rate_text_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_battery_icon_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_digital_clock_img_time = ''
        let idle_time_second_text_font = ''
        let idle_timerTimeUpdate = undefined;
        let image_top_img = ''
        let normal_step_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_fatBurning_jumpable_img_click = ''
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'FOND01.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 251,
              y: 248,
              src: 'BT.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 168,
              y: 249,
              src: 'ALARME.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 164,
              y: 6,
              image_array: ["Meteo-02.png","Meteo-03.png","Meteo-04.png","Meteo-05.png","Meteo-06.png","Meteo-07.png","Meteo-08.png","Meteo-09.png","Meteo-10.png","Meteo-11.png","Meteo-12.png","Meteo-13.png","Meteo-14.png","Meteo-15.png","Meteo-16.png","Meteo-17.png","Meteo-18.png","Meteo-19.png","Meteo-20.png","Meteo-21.png","Meteo-22.png","Meteo-23.png","Meteo-24.png","Meteo-25.png","Meteo-26.png","Meteo-27.png","Meteo-28.png","Meteo-29.png","MI-00.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 328,
              y: 78,
              font_array: ["MINI-00.png","MINI-01.png","MINI-02.png","MINI-03.png","MINI-04.png","MINI-05.png","MINI-06.png","MINI-07.png","MINI-08.png","MINI-09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'DEGRE.png',
              unit_tc: 'DEGRE.png',
              unit_en: 'DEGRE.png',
              negative_image: 'MINI-11.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 84,
              y: 301,
              week_en: ["SEM-01.png","SEM-02.png","SEM-03.png","SEM-04.png","SEM-05.png","SEM-06.png","SEM-07.png"],
              week_tc: ["SEM-01.png","SEM-02.png","SEM-03.png","SEM-04.png","SEM-05.png","SEM-06.png","SEM-07.png"],
              week_sc: ["SEM-01.png","SEM-02.png","SEM-03.png","SEM-04.png","SEM-05.png","SEM-06.png","SEM-07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 324,
              year_startY: 311,
              year_sc_array: ["MINI-00.png","MINI-01.png","MINI-02.png","MINI-03.png","MINI-04.png","MINI-05.png","MINI-06.png","MINI-07.png","MINI-08.png","MINI-09.png"],
              year_tc_array: ["MINI-00.png","MINI-01.png","MINI-02.png","MINI-03.png","MINI-04.png","MINI-05.png","MINI-06.png","MINI-07.png","MINI-08.png","MINI-09.png"],
              year_en_array: ["MINI-00.png","MINI-01.png","MINI-02.png","MINI-03.png","MINI-04.png","MINI-05.png","MINI-06.png","MINI-07.png","MINI-08.png","MINI-09.png"],
              year_zero: 1,
              year_space: 0,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 282,
              month_startY: 311,
              month_sc_array: ["MINI-00.png","MINI-01.png","MINI-02.png","MINI-03.png","MINI-04.png","MINI-05.png","MINI-06.png","MINI-07.png","MINI-08.png","MINI-09.png"],
              month_tc_array: ["MINI-00.png","MINI-01.png","MINI-02.png","MINI-03.png","MINI-04.png","MINI-05.png","MINI-06.png","MINI-07.png","MINI-08.png","MINI-09.png"],
              month_en_array: ["MINI-00.png","MINI-01.png","MINI-02.png","MINI-03.png","MINI-04.png","MINI-05.png","MINI-06.png","MINI-07.png","MINI-08.png","MINI-09.png"],
              month_zero: 1,
              month_space: 0,
              month_unit_sc: 'POINT.png',
              month_unit_tc: 'POINT.png',
              month_unit_en: 'POINT.png',
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 240,
              day_startY: 311,
              day_sc_array: ["MINI-00.png","MINI-01.png","MINI-02.png","MINI-03.png","MINI-04.png","MINI-05.png","MINI-06.png","MINI-07.png","MINI-08.png","MINI-09.png"],
              day_tc_array: ["MINI-00.png","MINI-01.png","MINI-02.png","MINI-03.png","MINI-04.png","MINI-05.png","MINI-06.png","MINI-07.png","MINI-08.png","MINI-09.png"],
              day_en_array: ["MINI-00.png","MINI-01.png","MINI-02.png","MINI-03.png","MINI-04.png","MINI-05.png","MINI-06.png","MINI-07.png","MINI-08.png","MINI-09.png"],
              day_zero: 1,
              day_space: 0,
              day_unit_sc: 'POINT.png',
              day_unit_tc: 'POINT.png',
              day_unit_en: 'POINT.png',
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 116,
              y: 355,
              font_array: ["MI-00.png","MI-01.png","MI-02.png","MI-03.png","MI-04.png","MI-05.png","MI-06.png","MI-07.png","MI-08.png","MI-09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 314,
              y: 355,
              font_array: ["MI-00.png","MI-01.png","MI-02.png","MI-03.png","MI-04.png","MI-05.png","MI-06.png","MI-07.png","MI-08.png","MI-09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 220,
              y: 354,
              font_array: ["MI-00.png","MI-01.png","MI-02.png","MI-03.png","MI-04.png","MI-05.png","MI-06.png","MI-07.png","MI-08.png","MI-09.png"],
              padding: false,
              h_space: 0,
              dot_image: 'MINI-10.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 218,
              y: 383,
              font_array: ["MI-00.png","MI-01.png","MI-02.png","MI-03.png","MI-04.png","MI-05.png","MI-06.png","MI-07.png","MI-08.png","MI-09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 222,
              y: 435,
              src: 'ENER-00.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 220,
              y: 416,
              font_array: ["MI-00.png","MI-01.png","MI-02.png","MI-03.png","MI-04.png","MI-05.png","MI-06.png","MI-07.png","MI-08.png","MI-09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'POURCENTAGE.png',
              unit_tc: 'POURCENTAGE.png',
              unit_en: 'POURCENTAGE.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 222,
              y: 435,
              image_array: ["ENER-01.png","ENER-02.png","ENER-03.png","ENER-04.png","ENER-05.png","ENER-06.png","ENER-07.png","ENER-08.png","ENER-09.png"],
              image_length: 9,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 66,
              hour_startY: 154,
              hour_array: ["H-00.png","H-01.png","H-02.png","H-03.png","H-04.png","H-05.png","H-06.png","H-07.png","H-08.png","H-09.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 247,
              minute_startY: 154,
              minute_array: ["H-00.png","H-01.png","H-02.png","H-03.png","H-04.png","H-05.png","H-06.png","H-07.png","H-08.png","H-09.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 412,
              second_startY: 165,
              second_array: ["SEC-00.png","SEC-01.png","SEC-02.png","SEC-03.png","SEC-04.png","SEC-05.png","SEC-06.png","SEC-07.png","SEC-08.png","SEC-09.png"],
              second_zero: 1,
              second_space: 1,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'AOD.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 251,
              y: 248,
              src: 'BT.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 168,
              y: 249,
              src: 'ALARME.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 66,
              hour_startY: 154,
              hour_array: ["G-00.png","G-01.png","G-02.png","G-03.png","G-04.png","G-05.png","G-06.png","G-07.png","G-08.png","G-09.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 247,
              minute_startY: 154,
              minute_array: ["G-00.png","G-01.png","G-02.png","G-03.png","G-04.png","G-05.png","G-06.png","G-07.png","G-08.png","G-09.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            let screenType = hmSetting.getScreenType();
            idle_time_second_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 219,
              y: 100,
              w: 200,
              h: 56,
              text_size: 39,
              char_space: 0,
              line_space: 0,
              color: 0xFFC0C0C0,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              // padding: true,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 9,
              // disconneсnt_toast_text: BT OFF,
              // conneсnt_vibrate_type: 9,
              // conneсnt_toast_text: BT ON,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              console.log('checkConnection()');
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  hmUI.showToast({text: "BT OFF"});
                  vibro(9);
                }
                if(status) {
                  hmUI.showToast({text: "BT ON"});
                  vibro(9);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              if (scene != 1) timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function

            image_top_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'VERRE.png',
              show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 177,
              y: 348,
              w: 123,
              h: 64,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 106,
              y: 346,
              w: 50,
              h: 60,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 320,
              y: 61,
              w: 76,
              h: 50,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 165,
              y: 253,
              w: 66,
              h: 50,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_fatBurning_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 310,
              y: 350,
              w: 50,
              h: 58,
              type: hmUI.data_type.FAT_BURNING,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            //start of ignored block
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              console.log('second font');
                let idle_secondStr = second.toString();
                idle_secondStr = idle_secondStr.padStart(2, '0');
                idle_time_second_text_font.setProperty(hmUI.prop.TEXT, idle_secondStr );
            };

            //end of ignored block
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                time_update(true, true);
                if (screenType == hmSetting.screen_type.AOD) {
                  if (!idle_timerTimeUpdate) {
                    idle_timerTimeUpdate = timer.createTimer(0, 1000, (function (option) {
                      let updateHour = timeSensor.minute == 0 && timeSensor.second < 2;
                      let updateMinute = timeSensor.second < 2;
                      time_update(updateHour, updateMinute);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                checkConnection();
                stopVibro();

              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (idle_timerTimeUpdate) {
                  timer.stopTimer(idle_timerTimeUpdate);
                  idle_timerTimeUpdate = undefined;
                }
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
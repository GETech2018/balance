﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_battery_pointer_progress_img_pointer = ''
        let normal_battery_text_text_img = ''
        let normal_fat_burning_current_text_img = ''
        let normal_fat_burning_image_progress_img_level = ''
        let normal_stand_current_text_img = ''
        let normal_stand_image_progress_img_level = ''
        let normal_heart_rate_pointer_progress_img_pointer = ''
        let normal_heart_rate_text_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_calorie_image_progress_img_level = ''
        let normal_step_pointer_progress_img_pointer = ''
        let normal_step_current_text_img = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_battery_pointer_progress_img_pointer = ''
        let idle_battery_text_text_img = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let normal_step_jumpable_img_click = ''
        let normal_cal_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_battery_jumpable_img_click = ''
        let normal_stand_jumpable_img_click = ''
        let normal_fatBurning_jumpable_img_click = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'A100_060.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 433,
              y: 229,
              src: 'bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 24,
              y: 228,
              src: 'alarms.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'img_track_start.png',
              center_x: 381,
              center_y: 164,
              x: 11,
              y: 59,
              start_angle: -135,
              end_angle: 135,
              invalid_visible: false,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 357,
              y: 143,
              font_array: ["A100_300.png","A100_301.png","A100_302.png","A100_303.png","A100_304.png","A100_305.png","A100_306.png","A100_307.png","A100_308.png","A100_309.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_fat_burning_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 106,
              y: 269,
              font_array: ["A100_124.png","A100_125.png","A100_126.png","A100_127.png","A100_128.png","A100_129.png","A100_130.png","A100_131.png","A100_132.png","A100_133.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.FAT_BURNING,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_fat_burning_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 0,
              y: 0,
              image_array: ["active_0.png","active_1.png","active_2.png","active_3.png","active_4.png","active_5.png","active_6.png","active_7.png","active_8.png","active_9.png","active_10.png"],
              image_length: 11,
              type: hmUI.data_type.FAT_BURNING,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 279,
              y: 269,
              font_array: ["A100_134.png","A100_135.png","A100_136.png","A100_137.png","A100_138.png","A100_139.png","A100_140.png","A100_141.png","A100_142.png","A100_143.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STAND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 0,
              y: 0,
              image_array: ["std_0.png","std_1.png","std_2.png","std_3.png","std_4.png","std_5.png","std_6.png","std_7.png","std_8.png","std_9.png","std_10.png"],
              image_length: 11,
              type: hmUI.data_type.STAND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'img_track_start.png',
              center_x: 100,
              center_y: 164,
              x: 11,
              y: 59,
              start_angle: -135,
              end_angle: 137,
              invalid_visible: false,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 74,
              y: 143,
              font_array: ["A100_300.png","A100_301.png","A100_302.png","A100_303.png","A100_304.png","A100_305.png","A100_306.png","A100_307.png","A100_308.png","A100_309.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 188,
              y: 95,
              font_array: ["A100_114.png","A100_115.png","A100_116.png","A100_117.png","A100_118.png","A100_119.png","A100_120.png","A100_121.png","A100_122.png","A100_123.png"],
              padding: false,
              h_space: -2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 0,
              y: 0,
              image_array: ["move_0.png","move_1.png","move_2.png","move_3.png","move_4.png","move_5.png","move_6.png","move_7.png","move_8.png","move_9.png","move_10.png"],
              image_length: 11,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'img_track_start.png',
              center_x: 240,
              center_y: 408,
              x: 11,
              y: 60,
              start_angle: -135,
              end_angle: 136,
              invalid_visible: false,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 202,
              y: 385,
              font_array: ["A100_300.png","A100_301.png","A100_302.png","A100_303.png","A100_304.png","A100_305.png","A100_306.png","A100_307.png","A100_308.png","A100_309.png"],
              padding: false,
              h_space: -2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'A100_062.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 30,
              hour_posY: 159,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'A100_063.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 30,
              minute_posY: 237,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'A100_064.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 30,
              second_posY: 239,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'aod.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 228,
              y: 30,
              src: 'bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 228,
              y: 426,
              src: 'alarms.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'img_track_start.png',
              center_x: 240,
              center_y: 355,
              x: 11,
              y: 59,
              start_angle: -135,
              end_angle: 135,
              invalid_visible: false,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 216,
              y: 335,
              font_array: ["A100_300.png","A100_301.png","A100_302.png","A100_303.png","A100_304.png","A100_305.png","A100_306.png","A100_307.png","A100_308.png","A100_309.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'A100_062.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 30,
              hour_posY: 159,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'A100_063.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 30,
              minute_posY: 238,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 205,
              y: 376,
              w: 72,
              h: 72,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_cal_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 201,
              y: 103,
              w: 82,
              h: 82,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 64,
              y: 129,
              w: 72,
              h: 72,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 347,
              y: 129,
              w: 72,
              h: 72,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 288,
              y: 258,
              w: 88,
              h: 88,
              type: hmUI.data_type.STAND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_fatBurning_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 103,
              y: 258,
              w: 88,
              h: 88,
              type: hmUI.data_type.FAT_BURNING,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
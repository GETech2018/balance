import * as hmUI from '@zos/ui'

// NRX-0001 ... NRX-0010 = dígitos 0 ... 9
const DIGITS = ['NRX-0001.png','NRX-0002.png','NRX-0003.png','NRX-0004.png','NRX-0005.png',
                'NRX-0006.png','NRX-0007.png','NRX-0008.png','NRX-0009.png','NRX-0010.png']

const NORMAL = hmUI.show_level.ONLY_NORMAL
const AOD = hmUI.show_level.ONAL_AOD

// Centro del hub medido sobre la imagen de fondo
const CX = 236
const CY = 238

WatchFace({
  build() {
    // ---------- Fondos ----------
    hmUI.createWidget(hmUI.widget.IMG, {
      x: 0, y: 0, w: 480, h: 480,
      src: 'Tag_heuer_simple.png',
      show_level: NORMAL
    })
    hmUI.createWidget(hmUI.widget.IMG, {
      x: 0, y: 0, w: 480, h: 480,
      src: 'Tics_Fosf_TH.png',
      show_level: AOD
    })

    // ---------- Día del mes en la ventanilla (solo modo normal) ----------
 /*   hmUI.createWidget(hmUI.widget.TEXT_IMG, {
      x: 404, y: 227, w: 44, h: 28,
      type: hmUI.data_type.DAY,
      font_array: DIGITS,
      h_space: -12,
      align_h: hmUI.align.CENTER_H,
      show_level: NORMAL
    })
*/

    // ---------- Fecha: día dentro de la ventanilla (normal y AOD) ----------
    hmUI.createWidget(hmUI.widget.IMG_DATE, {
      day_startX: 396, day_startY: 228,
      day_sc_array: DIGITS, day_tc_array: DIGITS, day_en_array: DIGITS,
      day_zero: 0, day_space: -11,
      day_align: hmUI.align.LEFT,
      day_is_character: false,
      show_level: BOTH
    })


    // ---------- Agujas (modo normal) ----------
    hmUI.createWidget(hmUI.widget.TIME_POINTER, {
      hour_path: 'ATH0012.png', hour_centerX: CX, hour_centerY: CY, hour_posX: 33, hour_posY: 141,
      show_level: NORMAL
    })
    hmUI.createWidget(hmUI.widget.TIME_POINTER, {
      minute_path: 'ATH0013.png', minute_centerX: CX, minute_centerY: CY, minute_posX: 23, minute_posY: 216,
      show_level: NORMAL
    })
    hmUI.createWidget(hmUI.widget.TIME_POINTER, {
      second_path: 'ATH0014.png', second_centerX: CX, second_centerY: CY, second_posX: 24, second_posY: 223,
      show_level: NORMAL
    })

    // ---------- Agujas (AOD, sin segundero) ----------
    hmUI.createWidget(hmUI.widget.TIME_POINTER, {
      hour_path: 'AOD0032.png', hour_centerX: CX, hour_centerY: CY, hour_posX: 26, hour_posY: 143,
      show_level: AOD
    })
    hmUI.createWidget(hmUI.widget.TIME_POINTER, {
      minute_path: 'AOD0033.png', minute_centerX: CX, minute_centerY: CY, minute_posX: 17, minute_posY: 222,
      show_level: AOD
    })
  }
})

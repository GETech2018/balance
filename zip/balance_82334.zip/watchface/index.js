﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

       let zona1_num = 0
       let zona1_all = 2
		function click_zona1() {
		  zona1_num = (zona1_num + 1) % (zona1_all + 1);
          if (zona1_num == 0) {	  
	normal_temperature_current_text_font.setProperty(hmUI.prop.VISIBLE, true);
    normal_curtemp_icon_img.setProperty(hmUI.prop.VISIBLE, true);
    normal_curtemp_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, true);
    normal_uvi_icon_img.setProperty(hmUI.prop.VISIBLE, false);
    normal_uvi_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
    normal_uvi_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
    normal_humidity_icon_img.setProperty(hmUI.prop.VISIBLE, false);
    normal_humidity_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
    normal_humidity_current_text_font.setProperty(hmUI.prop.VISIBLE, false);	
          };
          if (zona1_num == 1) {			  
	normal_temperature_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
    normal_curtemp_icon_img.setProperty(hmUI.prop.VISIBLE, false);	
	normal_curtemp_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
	normal_uvi_icon_img.setProperty(hmUI.prop.VISIBLE, true);
	normal_uvi_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, true);
	normal_uvi_current_text_font.setProperty(hmUI.prop.VISIBLE, true);
	normal_humidity_icon_img.setProperty(hmUI.prop.VISIBLE, false);
	normal_humidity_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
	normal_humidity_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
          };
          if (zona1_num == 2) {			  
	normal_temperature_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
    normal_curtemp_icon_img.setProperty(hmUI.prop.VISIBLE, false);	
	normal_curtemp_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
	normal_uvi_icon_img.setProperty(hmUI.prop.VISIBLE, false);
	normal_uvi_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
	normal_uvi_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
	normal_humidity_icon_img.setProperty(hmUI.prop.VISIBLE, true);
	normal_humidity_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, true);
	normal_humidity_current_text_font.setProperty(hmUI.prop.VISIBLE, true);
          };			  
		}
		
       let zona2_num = 0
       let zona2_all = 1
		function click_zona2() {
		  zona2_num = (zona2_num + 1) % (zona2_all + 1);
          if (zona2_num == 0) {	  
	normal_calorie_circle_scale.setProperty(hmUI.prop.VISIBLE, true);
    normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, true);
    normal_calorie_current_text_font.setProperty(hmUI.prop.VISIBLE, true);
    normal_heart_rate_circle_scale.setProperty(hmUI.prop.VISIBLE, false);
    normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, false);
    normal_heart_rate_text_font.setProperty(hmUI.prop.VISIBLE, false);	
          };
          if (zona2_num == 1) {			  
	normal_calorie_circle_scale.setProperty(hmUI.prop.VISIBLE, false);
    normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, false);	
	normal_calorie_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
	normal_heart_rate_circle_scale.setProperty(hmUI.prop.VISIBLE, true);
	normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, true);
	normal_heart_rate_text_font.setProperty(hmUI.prop.VISIBLE, true);
          };	  
		}		

       let weatherZoneOff_num = 0
		function click_weatherZoneOff() {	  
          normal_group_ForecastWeather.setProperty(hmUI.prop.VISIBLE, false);
          normal_city_name_text.setProperty(hmUI.prop.VISIBLE, false);
		  normal_wind_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
          normal_wind_direction_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);		  
		  // погода
          normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);
			// кнопки watchface
		    Button_1.setProperty(hmUI.prop.VISIBLE, true);			
						// кнопка выхода
		    Button_2.setProperty(hmUI.prop.VISIBLE, false);
			Button_21.setProperty(hmUI.prop.VISIBLE, false);			
		}				

      let weatherZoneOn_num = 0
		function click_weatherZoneOn() {  
          normal_group_ForecastWeather.setProperty(hmUI.prop.VISIBLE, true);
          normal_city_name_text.setProperty(hmUI.prop.VISIBLE, true);
		  normal_wind_current_text_font.setProperty(hmUI.prop.VISIBLE, true);
          normal_wind_direction_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);		  
          // погода		  
		  normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
		    // кнопки watchface
		    Button_1.setProperty(hmUI.prop.VISIBLE, false);			
						// кнопка выхода
		    Button_2.setProperty(hmUI.prop.VISIBLE, true);
			Button_21.setProperty(hmUI.prop.VISIBLE, false);			
		}	


        let appZoneOn_num = 0
		function click_appZoneOn() {
            // appmenu			  
	        Button_5.setProperty(hmUI.prop.VISIBLE, true);	
            Button_6.setProperty(hmUI.prop.VISIBLE, true);
			Button_7.setProperty(hmUI.prop.VISIBLE, true);
            Button_8.setProperty(hmUI.prop.VISIBLE, true);
            Button_9.setProperty(hmUI.prop.VISIBLE, true);
            Button_10.setProperty(hmUI.prop.VISIBLE, true);	
            Button_11.setProperty(hmUI.prop.VISIBLE, true);
            Button_12.setProperty(hmUI.prop.VISIBLE, true);	
            Button_13.setProperty(hmUI.prop.VISIBLE, true);	
            Button_14.setProperty(hmUI.prop.VISIBLE, true);		
			Button_15.setProperty(hmUI.prop.VISIBLE, true);
			Button_16.setProperty(hmUI.prop.VISIBLE, true);	
            Button_17.setProperty(hmUI.prop.VISIBLE, true);	
            Button_18.setProperty(hmUI.prop.VISIBLE, true);		
			Button_19.setProperty(hmUI.prop.VISIBLE, true);
			Button_20.setProperty(hmUI.prop.VISIBLE, true);				
			normal_image_img.setProperty(hmUI.prop.VISIBLE, true);
		    // кнопки watchface
		    Button_1.setProperty(hmUI.prop.VISIBLE, false);
			Button_21.setProperty(hmUI.prop.VISIBLE, false);			
						// кнопка выхода
		    Button_2.setProperty(hmUI.prop.VISIBLE, false);
			Button_21.setProperty(hmUI.prop.VISIBLE, true);			
		}	

       let appZoneOff_num = 0
		function click_appZoneOff() {
            // appmenu			  
 	        Button_5.setProperty(hmUI.prop.VISIBLE, false);	
            Button_6.setProperty(hmUI.prop.VISIBLE, false);
			Button_7.setProperty(hmUI.prop.VISIBLE, false);
            Button_8.setProperty(hmUI.prop.VISIBLE, false);
            Button_9.setProperty(hmUI.prop.VISIBLE, false);
            Button_10.setProperty(hmUI.prop.VISIBLE, false);	
            Button_11.setProperty(hmUI.prop.VISIBLE, false);
            Button_12.setProperty(hmUI.prop.VISIBLE, false);	
            Button_13.setProperty(hmUI.prop.VISIBLE, false);	
            Button_14.setProperty(hmUI.prop.VISIBLE, false);		
			Button_15.setProperty(hmUI.prop.VISIBLE, false);
			Button_16.setProperty(hmUI.prop.VISIBLE, false);	
            Button_17.setProperty(hmUI.prop.VISIBLE, false);	
            Button_18.setProperty(hmUI.prop.VISIBLE, false);		
			Button_19.setProperty(hmUI.prop.VISIBLE, false);
			Button_20.setProperty(hmUI.prop.VISIBLE, false);			
			normal_image_img.setProperty(hmUI.prop.VISIBLE, false);
		    // кнопки watchface
		    Button_1.setProperty(hmUI.prop.VISIBLE, true);
			Button_21.setProperty(hmUI.prop.VISIBLE, true);			
						// кнопка выхода
		    Button_2.setProperty(hmUI.prop.VISIBLE, false);
			Button_21.setProperty(hmUI.prop.VISIBLE, false);	
		}			
		

        let normal_curtemp_pointer_progress_img_pointer = ''
        let normal_curtemp_icon_img = ''
        let normal_temperature_current_text_font = ''		
        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_dow_text_font = ''
        let normal_DOW_Array = ['ПОН.', 'ВТР.', 'СРЕ.', 'ЧТВ.', 'ПЯТ.', 'СБТ.', 'ВСК.'];
        let normal_day_month_font = ''
        let normal_timerTimeUpdate = undefined;
        let normal_battery_circle_scale = ''
        let normal_battery_icon_img = ''
        let normal_battery_current_text_font = ''
        let normal_humidity_icon_img = ''
        let normal_humidity_pointer_progress_img_pointer = ''
        let normal_humidity_current_text_font = ''
        let normal_uvi_icon_img = ''
        let normal_uvi_pointer_progress_img_pointer = ''
        let normal_uvi_current_text_font = ''
        let normal_heart_rate_circle_scale = ''
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_text_font = ''
        let normal_calorie_circle_scale = ''
        let normal_calorie_icon_img = ''
        let normal_calorie_current_text_font = ''
        let normal_step_circle_scale = ''
        let normal_step_icon_img = ''
        let normal_step_current_text_font = ''
        let normal_time_hour_min_text_font = ''
        let normal_group_ForecastWeather = ''
        let normal_forecast_background = ''
        let normal_forecast_low_text_font = new Array(5);
        let normal_forecast_high_text_font = new Array(5);
        let normal_forecast_date_week_font = new Array(5);
        let normal_forecast_date_week_font_Array = ['Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб', 'Вс'];
        let normal_forecast_image_progress_img_level = new Array(5);
        let normal_forecast_image_array = ['forecast_0.png', 'forecast_1.png', 'forecast_2.png', 'forecast_3.png', 'forecast_4.png', 'forecast_5.png', 'forecast_6.png', 'forecast_7.png', 'forecast_8.png', 'forecast_9.png', 'forecast_10.png', 'forecast_11.png', 'forecast_12.png', 'forecast_13.png', 'forecast_14.png', 'forecast_15.png', 'forecast_16.png', 'forecast_17.png', 'forecast_18.png', 'forecast_19.png', 'forecast_20.png', 'forecast_21.png', 'forecast_22.png', 'forecast_23.png', 'forecast_24.png', 'forecast_25.png', 'forecast_26.png', 'forecast_27.png', 'forecast_28.png'];
        let normal_city_name_text = ''
        let normal_weather_image_progress_img_level = ''
        let normal_wind_direction_image_progress_img_level = ''
        let normal_wind_current_text_font = ''
        let normal_image_img = ''
        let idle_background_bg_img = ''
        let idle_system_disconnect_img = ''
        let idle_dow_text_font = ''
        let idle_DOW_Array = ['ПОН.', 'ВТР.', 'СРЕ.', 'ЧТВ.', 'ПЯТ.', 'СБТ.', 'ВСК.'];
        let idle_day_month_font = ''
        let idle_timerTimeUpdate = undefined;
        let idle_battery_icon_img = ''
        let idle_battery_current_text_font = ''
        let idle_time_hour_min_text_font = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let Button_7 = ''
        let Button_8 = ''
        let Button_9 = ''
        let Button_10 = ''
        let Button_11 = ''
        let Button_12 = ''
        let Button_13 = ''
        let Button_14 = ''
        let Button_15 = ''
        let Button_16 = ''
        let Button_17 = ''
        let Button_18 = ''
        let Button_19 = ''
        let Button_20 = ''
        let Button_21 = ''
        let Button_22 = ''
        let timeSensor = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            // FontName: 02_NTSomic-Medium.ttf; FontSize: 47; Cache: full
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 56,
              h: 56,
              text_size: 47,
              char_space: -2,
              line_space: 0,
              font: 'fonts/02_NTSomic-Medium.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: din-next-w10-medium.ttf; FontSize: 52
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 705,
              h: 58,
              text_size: 52,
              char_space: 0,
              line_space: 0,
              font: 'fonts/din-next-w10-medium.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.RIGHT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: DINNextSlabRust-Bold.ttf; FontSize: 110
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 1515,
              h: 157,
              text_size: 110,
              char_space: 0,
              line_space: 0,
              font: 'fonts/DINNextSlabRust-Bold.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: Rajdhani-SemiBold.ttf; FontSize: 48
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 572,
              h: 74,
              text_size: 48,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Rajdhani-SemiBold.ttf',
              color: 0xFF88D6FF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 0,
              y: 0,
              src: 'btOff.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function() {
              time_update(true);
            });

            normal_dow_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 114,
              y: 152,
              w: 117,
              h: 76,
              text_size: 47,
              char_space: -2,
              line_space: 0,
              font: 'fonts/02_NTSomic-Medium.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              // unit_string: ПОН., ВТР., СРЕ., ЧТВ., ПЯТ., СБТ., ВСК.,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            normal_day_month_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 223,
              y: 166,
              w: 150,
              h: 62,
              text_size: 52,
              char_space: 0,
              line_space: 0,
              font: 'fonts/din-next-w10-medium.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.RIGHT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 240,
              // center_y: 240,
              // start_angle: -120,
              // end_angle: -60,
              // radius: 237,
              // line_width: 18,
              // line_cap: Flat,
              // color: 0xFF71711A,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 240,
              center_y: 240,
              start_angle: -120,
              end_angle: -60,
              radius: 228,
              line_width: 18,
              corner_flag: 3,
              color: 0xFF71711A,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 25,
              y: 216,
              src: 'icon_battery_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 47,
              y: 77,
              w: 150,
              h: 62,
              text_size: 52,
              char_space: -2,
              line_space: 0,
              font: 'fonts/din-next-w10-medium.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 122,
              y: 0,
              src: 'icon_humidity.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'pointer_1.png',
              center_x: 240,
              center_y: 240,
              x: 240,
              y: 240,
              start_angle: -30,
              end_angle: 30,
              invalid_visible: false,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 308,
              y: 77,
              w: 115,
              h: 62,
              text_size: 52,
              char_space: -2,
              line_space: 0,
              font: 'fonts/din-next-w10-medium.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              padding: true,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_uvi_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 122,
              y: 0,
              src: 'icon_uvi.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_uvi_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'pointer_1.png',
              center_x: 240,
              center_y: 240,
              x: 240,
              y: 240,
              start_angle: -30,
              end_angle: 30,
              invalid_visible: false,
              type: hmUI.data_type.UVI,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_uvi_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 308,
              y: 77,
              w: 115,
              h: 62,
              text_size: 52,
              char_space: -2,
              line_space: 0,
              font: 'fonts/din-next-w10-medium.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              padding: true,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.UVI,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('user_script.js');
            // start user_script.js
            normal_curtemp_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 122,
              y: 0,
              src: 'icon_w.temper_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });		 

 normal_curtemp_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'pointer_1.png',
              center_x: 240,
              center_y: 240,
              x: 240,
              y: 240,
              start_angle: -30,
              end_angle: 30,
              invalid_visible: false,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 308,
              y: 77,
              w: 115,
              h: 62,
              text_size: 52,
              char_space: -2,
              line_space: 0,
              font: 'fonts/din-next-w10-medium.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              padding: true,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });	
            // end user_script.js

            // normal_heart_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 240,
              // center_y: 240,
              // start_angle: 150,
              // end_angle: 210,
              // radius: 236,
              // line_width: 14,
              // line_cap: Flat,
              // color: 0xFF5A5A14,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_heart_rate_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 240,
              center_y: 240,
              start_angle: 150,
              end_angle: 210,
              radius: 229,
              line_width: 14,
              corner_flag: 3,
              color: 0xFF5A5A14,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const heart_rate = hmSensor.createSensor(hmSensor.id.HEART);
            heart_rate.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 216,
              y: 435,
              src: 'icon_heart_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 46,
              y: 363,
              w: 150,
              h: 62,
              text_size: 52,
              char_space: -2,
              line_space: 0,
              font: 'fonts/din-next-w10-medium.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_cal_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 240,
              // center_y: 240,
              // start_angle: 150,
              // end_angle: 210,
              // radius: 236,
              // line_width: 14,
              // line_cap: Flat,
              // color: 0xFF5A5A14,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_calorie_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 240,
              center_y: 240,
              start_angle: 150,
              end_angle: 210,
              radius: 229,
              line_width: 14,
              corner_flag: 3,
              color: 0xFF5A5A14,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const calorie = hmSensor.createSensor(hmSensor.id.CALORIE);
            calorie.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 216,
              y: 435,
              src: 'icon_kcal_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 46,
              y: 363,
              w: 150,
              h: 62,
              text_size: 52,
              char_space: -2,
              line_space: 0,
              font: 'fonts/din-next-w10-medium.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 240,
              // center_y: 240,
              // start_angle: 120,
              // end_angle: 60,
              // radius: 236,
              // line_width: 18,
              // line_cap: Flat,
              // color: 0xFF5A5A14,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 240,
              center_y: 240,
              start_angle: 120,
              end_angle: 60,
              radius: 227,
              line_width: 18,
              corner_flag: 3,
              color: 0xFF5A5A14,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 400,
              y: 217,
              src: 'icon_step_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 263,
              y: 363,
              w: 160,
              h: 62,
              text_size: 52,
              char_space: -2,
              line_space: 0,
              font: 'fonts/din-next-w10-medium.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_time_hour_min_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 105,
              y: 218,
              w: 272,
              h: 120,
              text_size: 110,
              char_space: 0,
              line_space: 0,
              font: 'fonts/DINNextSlabRust-Bold.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            // normal_Weather_FewDays = hmUI.createWidget(hmUI.widget.FewDays, {
              // x: 0,
              // y: 0,
              // ColumnWidth: 80,
              // DaysCount: 5,
              // Background: 'BG_Weather.png',
            // });
            
            normal_group_ForecastWeather = hmUI.createWidget(hmUI.widget.GROUP, {
              x: 0,
              y: 0,
              h: 0,
              w: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            //start of ignored block
            if (screenType == hmSetting.screen_type.WATCHFACE) {
              normal_forecast_background = normal_group_ForecastWeather.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                src: 'BG_Weather.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
            };
            //end of ignored block
            // normal_forecast_low_text_font = normal_group_ForecastWeather.createWidget(hmUI.widget.TEXT_Options, {
              // x: 38,
              // y: 325,
              // w: 80,
              // h: 50,
              // text_size: 48,
              // char_space: 0,
              // line_space: 0,
              // font: 'fonts/Rajdhani-SemiBold.ttf',
              // color: 0xFF88D6FF,
              // color_2: 0xFFFF0000,
              // use_color_2: False,
              // align_h: hmUI.align.CENTER_H,
              // align_v: hmUI.align.CENTER_V,
              // text_style: hmUI.text_style.ELLIPSIS,
              // type: hmUI.data_type.forecast_low_text_font,
              // unit_type: 1,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            //start of ignored block
            if (screenType == hmSetting.screen_type.WATCHFACE) {
              for (let i = 0; i < 5; i++) {
                normal_forecast_low_text_font[i] = normal_group_ForecastWeather.createWidget(hmUI.widget.TEXT, {
                  x: 38 + i*80,
                  y: 325,
                  w: 80,
                  h: 50,
                  text_size: 48,
                  char_space: 0,
                  line_space: 0,
                  font: 'fonts/Rajdhani-SemiBold.ttf',
                  color: 0xFF88D6FF,
                  align_h: hmUI.align.CENTER_H,
                  align_v: hmUI.align.CENTER_V,
                  text_style: hmUI.text_style.ELLIPSIS,
                  // unit_type: 1,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
              };
            };
            //end of ignored block

            // normal_forecast_high_text_font = normal_group_ForecastWeather.createWidget(hmUI.widget.TEXT_Options, {
              // x: 38,
              // y: 255,
              // w: 80,
              // h: 50,
              // text_size: 48,
              // char_space: 0,
              // line_space: 0,
              // font: 'fonts/Rajdhani-SemiBold.ttf',
              // color: 0xFFFFE7AF,
              // color_2: 0xFFFF0000,
              // use_color_2: False,
              // align_h: hmUI.align.CENTER_H,
              // align_v: hmUI.align.CENTER_V,
              // text_style: hmUI.text_style.ELLIPSIS,
              // type: hmUI.data_type.forecast_high_text_font,
              // unit_type: 1,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            //start of ignored block
            if (screenType == hmSetting.screen_type.WATCHFACE) {
              for (let i = 0; i < 5; i++) {
                normal_forecast_high_text_font[i] = normal_group_ForecastWeather.createWidget(hmUI.widget.TEXT, {
                  x: 38 + i*80,
                  y: 255,
                  w: 80,
                  h: 50,
                  text_size: 48,
                  char_space: 0,
                  line_space: 0,
                  font: 'fonts/Rajdhani-SemiBold.ttf',
                  color: 0xFFFFE7AF,
                  align_h: hmUI.align.CENTER_H,
                  align_v: hmUI.align.CENTER_V,
                  text_style: hmUI.text_style.ELLIPSIS,
                  // unit_type: 1,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
              };
            };
            //end of ignored block

            // normal_forecast_date_week_font = normal_group_ForecastWeather.createWidget(hmUI.widget.TEXT_Options, {
              // x: 46,
              // y: 180,
              // w: 64,
              // h: 56,
              // text_size: 42,
              // char_space: 0,
              // line_space: 0,
              // color: 0xFFFFFFFF,
              // color_2: 0xFFFF0000,
              // use_color_2: False,
              // align_h: hmUI.align.CENTER_H,
              // align_v: hmUI.align.CENTER_V,
              // text_style: hmUI.text_style.ELLIPSIS,
              // type: hmUI.data_type.forecast_date_week_img,
              // unit_string: Пн, Вт, Ср, Чт, Пт, Сб, Вс,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            //start of ignored block
            if (screenType == hmSetting.screen_type.WATCHFACE) {
              for (let i = 0; i < 5; i++) {
                normal_forecast_date_week_font[i] = normal_group_ForecastWeather.createWidget(hmUI.widget.TEXT, {
                  x: 46 + i*80,
                  y: 180,
                  w: 64,
                  h: 56,
                  text_size: 42,
                  char_space: 0,
                  line_space: 0,
                  color: 0xFFFFFFFF,
                  // color_2: 0xFFFF0000,
                  align_h: hmUI.align.CENTER_H,
                  align_v: hmUI.align.CENTER_V,
                  text_style: hmUI.text_style.ELLIPSIS,
                  // unit_string: Пн, Вт, Ср, Чт, Пт, Сб, Вс,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
              };
            };
            //end of ignored block

            // normal_forecast_image_progress_img_level = normal_group_ForecastWeather.createWidget(hmUI.widget.IMG_LEVEL_Options, {
              // x: 38,
              // y: 100,
              // image_array: ["forecast_0.png","forecast_1.png","forecast_2.png","forecast_3.png","forecast_4.png","forecast_5.png","forecast_6.png","forecast_7.png","forecast_8.png","forecast_9.png","forecast_10.png","forecast_11.png","forecast_12.png","forecast_13.png","forecast_14.png","forecast_15.png","forecast_16.png","forecast_17.png","forecast_18.png","forecast_19.png","forecast_20.png","forecast_21.png","forecast_22.png","forecast_23.png","forecast_24.png","forecast_25.png","forecast_26.png","forecast_27.png","forecast_28.png"],
              // image_length: 29,
              // type: hmUI.data_type.forecast_image,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            //start of ignored block
            if (screenType == hmSetting.screen_type.WATCHFACE) {
              for (let i = 0; i < 5; i++) {
                normal_forecast_image_progress_img_level[i] = normal_group_ForecastWeather.createWidget(hmUI.widget.IMG, {
                  x: 38 + i*80,
                  y: 100,
                  src: normal_forecast_image_array[25],
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
              };
            };
            //end of ignored block
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 0,
              y: 396,
              w: 480,
              h: 40,
              text_size: 34,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 205,
              y: 75,
              image_array: ["forecast_0.png","forecast_1.png","forecast_2.png","forecast_3.png","forecast_4.png","forecast_5.png","forecast_6.png","forecast_7.png","forecast_8.png","forecast_9.png","forecast_10.png","forecast_11.png","forecast_12.png","forecast_13.png","forecast_14.png","forecast_15.png","forecast_16.png","forecast_17.png","forecast_18.png","forecast_19.png","forecast_20.png","forecast_21.png","forecast_22.png","forecast_23.png","forecast_24.png","forecast_25.png","forecast_26.png","forecast_27.png","forecast_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_direction_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 0,
              y: 0,
              image_array: ["windD_1.png","windD_2.png","windD_3.png","windD_4.png","windD_5.png","windD_6.png","windD_7.png","windD_8.png"],
              image_length: 8,
              type: hmUI.data_type.WIND_DIRECTION,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 178,
              y: 34,
              w: 80,
              h: 60,
              text_size: 52,
              char_space: 0,
              line_space: 0,
              font: 'fonts/din-next-w10-medium.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.WIND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'BG_App.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg_AOD.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 217,
              y: 387,
              src: 'btOff2.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_dow_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 114,
              y: 152,
              w: 117,
              h: 76,
              text_size: 47,
              char_space: -2,
              line_space: 0,
              font: 'fonts/02_NTSomic-Medium.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              // unit_string: ПОН., ВТР., СРЕ., ЧТВ., ПЯТ., СБТ., ВСК.,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_day_month_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 223,
              y: 166,
              w: 150,
              h: 62,
              text_size: 52,
              char_space: 0,
              line_space: 0,
              font: 'fonts/din-next-w10-medium.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.RIGHT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              // padding: true,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 134,
              y: 82,
              src: 'icon_battery_1.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 165,
              y: 77,
              w: 150,
              h: 62,
              text_size: 52,
              char_space: -2,
              line_space: 0,
              font: 'fonts/din-next-w10-medium.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_time_hour_min_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 105,
              y: 218,
              w: 272,
              h: 120,
              text_size: 110,
              char_space: 0,
              line_space: 0,
              font: 'fonts/DINNextSlabRust-Bold.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              // padding: true,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 210,
              y: 76,
              w: 60,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'empty.png',
              normal_src: 'empty.png',
              click_func: (button_widget) => {
                click_weatherZoneOn();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 272,
              y: 33,
              w: 60,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'empty.png',
              normal_src: 'empty.png',
              click_func: (button_widget) => {
                click_weatherZoneOff();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 313,
              y: 81,
              w: 100,
              h: 52,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'empty.png',
              normal_src: 'empty.png',
              click_func: (button_widget) => {
                click_zona1();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 81,
              y: 367,
              w: 88,
              h: 52,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'empty.png',
              normal_src: 'empty.png',
              click_func: (button_widget) => {
                click_zona2();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 305,
              y: 45,
              w: 60,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'empty.png',
              normal_src: 'empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'VoiceMemoScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 378,
              y: 113,
              w: 60,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'empty.png',
              normal_src: 'empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'AlarmInfoScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_7 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 402,
              y: 209,
              w: 60,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'empty.png',
              normal_src: 'empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'CountdownAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_8 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 376,
              y: 306,
              w: 60,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'empty.png',
              normal_src: 'empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'StopWatchScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_9 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 305,
              y: 377,
              w: 60,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'empty.png',
              normal_src: 'empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PhoneHomeScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_10 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 209,
              y: 402,
              w: 60,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'empty.png',
              normal_src: 'empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'MusicCommonScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_11 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 113,
              y: 376,
              w: 60,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'empty.png',
              normal_src: 'empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'CompassScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_12 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 42,
              y: 306,
              w: 60,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'empty.png',
              normal_src: 'empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'WeatherScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_13 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 17,
              y: 210,
              w: 60,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'empty.png',
              normal_src: 'empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'TideScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_14 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 113,
              y: 40,
              w: 60,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'empty.png',
              normal_src: 'empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'BaroAltimeterScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_15 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 113,
              y: 209,
              w: 60,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'empty.png',
              normal_src: 'empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'BodyCompositionResultScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_16 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 209,
              y: 113,
              w: 60,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'empty.png',
              normal_src: 'empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'RespirationControlScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_17 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 306,
              y: 209,
              w: 60,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'empty.png',
              normal_src: 'empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'Sleep_HomeScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_18 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 209,
              y: 210,
              w: 60,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'empty.png',
              normal_src: 'empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'activityAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_19 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 42,
              y: 115,
              w: 60,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'empty.png',
              normal_src: 'empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'OfflineMapScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_20 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 209,
              y: 15,
              w: 60,
              h: 76,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'empty.png',
              normal_src: 'empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'tempHomeScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_21 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 210,
              y: 306,
              w: 60,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'empty.png',
              normal_src: 'empty.png',
              click_func: (button_widget) => {
                click_appZoneOff();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_22 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 200,
              y: 355,
              w: 56,
              h: 56,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'empty.png',
              normal_src: 'empty.png',
              click_func: (button_widget) => {
                click_appZoneOn();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            console.log('user_script_end.js');
            // start user_script_end.js

       if (screenType != hmSetting.screen_type.AOD) {
			
            //weatherZone
            normal_group_ForecastWeather.setProperty(hmUI.prop.VISIBLE, false);
            normal_city_name_text.setProperty(hmUI.prop.VISIBLE, false);
		    normal_wind_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
            normal_wind_direction_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
            // click_zona1() //
            normal_uvi_icon_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_uvi_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
            normal_uvi_current_text_font.setProperty(hmUI.prop.VISIBLE, false);	
            // click_zona2() //
            normal_heart_rate_circle_scale.setProperty(hmUI.prop.VISIBLE, false);
            normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_heart_rate_text_font.setProperty(hmUI.prop.VISIBLE, false);
			normal_humidity_icon_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_humidity_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
            normal_humidity_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
            // click_appZone //
 	        Button_5.setProperty(hmUI.prop.VISIBLE, false);	
            Button_6.setProperty(hmUI.prop.VISIBLE, false);
			Button_7.setProperty(hmUI.prop.VISIBLE, false);
            Button_8.setProperty(hmUI.prop.VISIBLE, false);
            Button_9.setProperty(hmUI.prop.VISIBLE, false);
            Button_10.setProperty(hmUI.prop.VISIBLE, false);	
            Button_11.setProperty(hmUI.prop.VISIBLE, false);
            Button_12.setProperty(hmUI.prop.VISIBLE, false);	
            Button_13.setProperty(hmUI.prop.VISIBLE, false);	
            Button_14.setProperty(hmUI.prop.VISIBLE, false);		
			Button_15.setProperty(hmUI.prop.VISIBLE, false);
			Button_16.setProperty(hmUI.prop.VISIBLE, false);	
            Button_17.setProperty(hmUI.prop.VISIBLE, false);	
            Button_18.setProperty(hmUI.prop.VISIBLE, false);		
			Button_19.setProperty(hmUI.prop.VISIBLE, false);
			Button_20.setProperty(hmUI.prop.VISIBLE, false);			
			normal_image_img.setProperty(hmUI.prop.VISIBLE, false);
            // кнопка выхода //
		    Button_2.setProperty(hmUI.prop.VISIBLE, false);
			Button_21.setProperty(hmUI.prop.VISIBLE, false);						
        };				
            // end user_script_end.js

            //start of ignored block
            function weather_few_days() {
              console.log('weather_few_days()');
              let weatherData = weatherSensor.getForecastWeather();
              let forecastData = weatherData.forecastData;

              for (let i = 0; i < 5; i++) {
                // Number_Font_Min
                let minTemperature = '-';
                if (i < forecastData.count) minTemperature = forecastData.data[i].low.toString();
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  normal_forecast_low_text_font[i].setProperty(hmUI.prop.TEXT, minTemperature + '°');
                };
                
                // Number_Font_Max
                let maxTemperature = '-';
                if (i < forecastData.count) maxTemperature = forecastData.data[i].high.toString();
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  normal_forecast_high_text_font[i].setProperty(hmUI.prop.TEXT, maxTemperature + '°');
                };
                
                // DayOfWeek font
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  let dowIndex = timeSensor.week - 1;
                  dowIndex += i;
                  while (dowIndex >= 7) {dowIndex -= 7;}
                  normal_forecast_date_week_font[i].setProperty(hmUI.prop.TEXT, normal_forecast_date_week_font_Array[dowIndex]);
                };
              
                // Images
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  let weatherIndex = 25
                  if (i < forecastData.count) weatherIndex = forecastData.data[i].index;
                  normal_forecast_image_progress_img_level[i].setProperty(hmUI.prop.SRC, normal_forecast_image_array[weatherIndex]);
                };
              
              };  // end for

            };
            //end of ignored block

            //start of ignored block
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              console.log('day of week font');
              if (updateHour) {
                let normal_DOW_Str = normal_DOW_Array[timeSensor.week-1];
                normal_dow_text_font.setProperty(hmUI.prop.TEXT, normal_DOW_Str );
              };

              console.log('day/month font');
              if (updateHour) {
                let normal_DayStr = timeSensor.day.toString();
                let normal_MonthStr = timeSensor.month.toString();
                normal_DayStr = normal_DayStr.padStart(2, '0');
                normal_MonthStr = normal_MonthStr.padStart(2, '0');
                let normal_DayMonthStr = '--';
                const dateFormat = hmSetting.getDateFormat();
                if (dateFormat == 0 || dateFormat == 2) {
                  normal_DayMonthStr = normal_MonthStr + '/' + normal_DayStr;
                }
                if (dateFormat == 1) {
                  normal_DayMonthStr = normal_DayStr + '/' + normal_MonthStr;
                }
                normal_day_month_font.setProperty(hmUI.prop.TEXT, normal_DayMonthStr );
              };

              console.log('hour:min font');
              if (updateMinute) {
                let normal_HourMinStr = format_hour.toString();
                normal_HourMinStr = normal_HourMinStr.padStart(2, '0');
                normal_HourMinStr = normal_HourMinStr + ':' + minute.toString().padStart(2, '0')
                if (!timeSensor.is24Hour) {
                  if (hour > 11) normal_HourMinStr = 'pm ' + normal_HourMinStr
                  else normal_HourMinStr = 'am ' + normal_HourMinStr
                };
                normal_time_hour_min_text_font.setProperty(hmUI.prop.TEXT, normal_HourMinStr );
              };

              console.log('day of week font');
              if (updateHour) {
                let idle_DOW_Str = idle_DOW_Array[timeSensor.week-1];
                idle_dow_text_font.setProperty(hmUI.prop.TEXT, idle_DOW_Str );
              };

              console.log('day/month font');
              if (updateHour) {
                let idle_DayStr = timeSensor.day.toString();
                let idle_MonthStr = timeSensor.month.toString();
                idle_DayStr = idle_DayStr.padStart(2, '0');
                idle_MonthStr = idle_MonthStr.padStart(2, '0');
                let idle_DayMonthStr = '--';
                const dateFormat = hmSetting.getDateFormat();
                if (dateFormat == 0 || dateFormat == 2) {
                  idle_DayMonthStr = idle_MonthStr + '/' + idle_DayStr;
                }
                if (dateFormat == 1) {
                  idle_DayMonthStr = idle_DayStr + '/' + idle_MonthStr;
                }
                idle_day_month_font.setProperty(hmUI.prop.TEXT, idle_DayMonthStr );
              };

              console.log('hour:min font');
              if (updateMinute) {
                let idle_HourMinStr = format_hour.toString();
                idle_HourMinStr = idle_HourMinStr.padStart(2, '0');
                idle_HourMinStr = idle_HourMinStr + ':' + minute.toString().padStart(2, '0')
                if (!timeSensor.is24Hour) {
                  if (hour > 11) idle_HourMinStr = 'pm ' + idle_HourMinStr
                  else idle_HourMinStr = 'am ' + idle_HourMinStr
                };
                idle_time_hour_min_text_font.setProperty(hmUI.prop.TEXT, idle_HourMinStr );
              };

            };

            //end of ignored block
            function scale_call() {
              console.log('scale_call()');

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_cs_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_battery * 100);
                  if (normal_battery_circle_scale) {
                    normal_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 240,
                      center_y: 240,
                      start_angle: -120,
                      end_angle: -60,
                      radius: 228,
                      line_width: 18,
                      corner_flag: 3,
                      color: 0xFF71711A,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales HEART');
                
                let valueHeartRate = heart_rate.last;
                let targetHeartRate = 179;
                let progressHeartRate = (valueHeartRate - 71)/(targetHeartRate - 71);
                if (progressHeartRate < 0) progressHeartRate = 0;
                if (progressHeartRate > 1) progressHeartRate = 1;
                let progress_cs_normal_heart_rate = progressHeartRate;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_heart_rate_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_heart_rate * 100);
                  if (normal_heart_rate_circle_scale) {
                    normal_heart_rate_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 240,
                      center_y: 240,
                      start_angle: 150,
                      end_angle: 210,
                      radius: 229,
                      line_width: 14,
                      corner_flag: 3,
                      color: 0xFF5A5A14,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales CALORIE');
                
                let valueCalories = calorie.current;
                let targetCalories = calorie.target;
                let progressCalories = valueCalories/targetCalories;
                if (progressCalories > 1) progressCalories = 1;
                let progress_cs_normal_calorie = progressCalories;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_calorie_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_calorie * 100);
                  if (normal_calorie_circle_scale) {
                    normal_calorie_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 240,
                      center_y: 240,
                      start_angle: 150,
                      end_angle: 210,
                      radius: 229,
                      line_width: 14,
                      corner_flag: 3,
                      color: 0xFF5A5A14,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_cs_normal_step = progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_step * 100);
                  if (normal_step_circle_scale) {
                    normal_step_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 240,
                      center_y: 240,
                      start_angle: 120,
                      end_angle: 60,
                      radius: 227,
                      line_width: 18,
                      corner_flag: 3,
                      color: 0xFF5A5A14,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

              console.log('Weather city name');
              let weatherData = weatherSensor.getForecastWeather();
              normal_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                time_update(true, true);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerTimeUpdate) {
                    normal_timerTimeUpdate = timer.createTimer(0, 1000, (function (option) {
                      let updateHour = timeSensor.minute == 0;
                      let updateMinute = timeSensor.second < 2;
                      time_update(updateHour, updateMinute);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.AOD) {
                  if (!idle_timerTimeUpdate) {
                    idle_timerTimeUpdate = timer.createTimer(0, 1000, (function (option) {
                      let updateHour = timeSensor.minute == 0;
                      let updateMinute = timeSensor.second < 2;
                      time_update(updateHour, updateMinute);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


                weather_few_days();
              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerTimeUpdate) {
                  timer.stopTimer(normal_timerTimeUpdate);
                  normal_timerTimeUpdate = undefined;
                }
                if (idle_timerTimeUpdate) {
                  timer.stopTimer(idle_timerTimeUpdate);
                  idle_timerTimeUpdate = undefined;
                }

                console.log('pause_call.js');
                // start pause_call.js

click_weatherZoneOff();
click_appZoneOff();
                // end pause_call.js

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
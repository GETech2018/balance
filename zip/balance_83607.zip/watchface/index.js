﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_step_circle_scale = ''
        let normal_step_current_text_font = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_distance_text_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_calorie_current_text_img = ''
        let normal_city_name_text = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_digital_clock_img_time = ''
        let normal_image_img = ''
        let idle_digital_clock_img_time = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let Button_7 = ''
        let Button_8 = ''
        let Button_9 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            // FontName: wfs_inter_medium_3eea8816_1055_4a32_8a2c_c56b19aaa066.ttf; FontSize: 34
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 495,
              h: 49,
              text_size: 34,
              char_space: 0,
              line_space: 0,
              font: 'fonts/wfs_inter_medium_3eea8816_1055_4a32_8a2c_c56b19aaa066.ttf',
              color: 0xFF000000,
              align_h: hmUI.align.RIGHT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 240,
              // center_y: 240,
              // start_angle: 0,
              // end_angle: 350,
              // radius: 239,
              // line_width: 12,
              // line_cap: Flat,
              // color: 0xFFFDCB02,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            let screenType = hmSetting.getScreenType();
            normal_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 240,
              center_y: 240,
              start_angle: 0,
              end_angle: 350,
              radius: 233,
              line_width: 12,
              corner_flag: 3,
              color: 0xFFFDCB02,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_step_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 5,
              y: 220,
              w: 150,
              h: 48,
              text_size: 34,
              char_space: 0,
              line_space: 0,
              font: 'fonts/wfs_inter_medium_3eea8816_1055_4a32_8a2c_c56b19aaa066.ttf',
              color: 0xFF000000,
              align_h: hmUI.align.RIGHT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 249,
              y: 380,
              font_array: ["A100_032.png","A100_033.png","A100_034.png","A100_035.png","A100_036.png","A100_037.png","A100_038.png","A100_039.png","A100_040.png","A100_041.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 211,
              y: 326,
              image_array: ["A100_079.png","A100_080.png","A100_081.png","A100_082.png","A100_083.png","A100_084.png","A100_085.png","A100_086.png","A100_087.png","A100_088.png","A100_089.png"],
              image_length: 11,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 50,
              y: 270,
              font_array: ["A100_032.png","A100_033.png","A100_034.png","A100_035.png","A100_036.png","A100_037.png","A100_038.png","A100_039.png","A100_040.png","A100_041.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'A100_073.png',
              unit_tc: 'A100_073.png',
              unit_en: 'A100_073.png',
              dot_image: 'A100_042.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 77,
              y: 354,
              font_array: ["A100_032.png","A100_033.png","A100_034.png","A100_035.png","A100_036.png","A100_037.png","A100_038.png","A100_039.png","A100_040.png","A100_041.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 69,
              y: 325,
              image_array: ["p_1.png","P_2.png","p_3.png","p_4.png","p_5.png","p_6.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 232,
              month_startY: 131,
              month_sc_array: ["A100_111.png","A100_112.png","A100_113.png","A100_114.png","A100_115.png","A100_116.png","A100_117.png","A100_118.png","A100_119.png","A100_120.png","A100_121.png","A100_122.png"],
              month_tc_array: ["A100_111.png","A100_112.png","A100_113.png","A100_114.png","A100_115.png","A100_116.png","A100_117.png","A100_118.png","A100_119.png","A100_120.png","A100_121.png","A100_122.png"],
              month_en_array: ["A100_111.png","A100_112.png","A100_113.png","A100_114.png","A100_115.png","A100_116.png","A100_117.png","A100_118.png","A100_119.png","A100_120.png","A100_121.png","A100_122.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 243,
              day_startY: 74,
              day_sc_array: ["A100_101.png","A100_102.png","A100_103.png","A100_104.png","A100_105.png","A100_106.png","A100_107.png","A100_108.png","A100_109.png","A100_110.png"],
              day_tc_array: ["A100_101.png","A100_102.png","A100_103.png","A100_104.png","A100_105.png","A100_106.png","A100_107.png","A100_108.png","A100_109.png","A100_110.png"],
              day_en_array: ["A100_101.png","A100_102.png","A100_103.png","A100_104.png","A100_105.png","A100_106.png","A100_107.png","A100_108.png","A100_109.png","A100_110.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 235,
              y: 41,
              week_en: ["A100_094.png","A100_095.png","A100_096.png","A100_097.png","A100_098.png","A100_099.png","A100_100.png"],
              week_tc: ["A100_094.png","A100_095.png","A100_096.png","A100_097.png","A100_098.png","A100_099.png","A100_100.png"],
              week_sc: ["A100_094.png","A100_095.png","A100_096.png","A100_097.png","A100_098.png","A100_099.png","A100_100.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 135,
              y: 182,
              font_array: ["A100_032.png","A100_033.png","A100_034.png","A100_035.png","A100_036.png","A100_037.png","A100_038.png","A100_039.png","A100_040.png","A100_041.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 100,
              y: 52,
              w: 150,
              h: 30,
              text_size: 22,
              char_space: 0,
              line_space: 0,
              color: 0xFF01A6FE,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 59,
              y: 106,
              image_array: ["A100_004.png","A100_005.png","A100_006.png","A100_007.png","A100_008.png","A100_009.png","A100_010.png","A100_011.png","A100_012.png","A100_013.png","A100_014.png","A100_015.png","A100_016.png","A100_017.png","A100_018.png","A100_019.png","A100_020.png","A100_021.png","A100_022.png","A100_023.png","A100_024.png","A100_025.png","A100_026.png","A100_027.png","A100_028.png","A100_029.png","A100_030.png","A100_031.png","A100_032.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 134,
              y: 93,
              font_array: ["A100_032.png","A100_033.png","A100_034.png","A100_035.png","A100_036.png","A100_037.png","A100_038.png","A100_039.png","A100_040.png","A100_041.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'A100_045.png',
              unit_tc: 'A100_045.png',
              unit_en: 'A100_045.png',
              negative_image: 'A100_044.png',
              invalid_image: 'A100_044.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 214,
              hour_startY: 176,
              hour_array: ["A100_123.png","A100_124.png","A100_125.png","A100_126.png","A100_127.png","A100_128.png","A100_129.png","A100_130.png","A100_131.png","A100_132.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 355,
              minute_startY: 179,
              minute_array: ["A100_136.png","A100_137.png","A100_138.png","A100_139.png","A100_140.png","A100_141.png","A100_142.png","A100_143.png","A100_144.png","A100_145.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 391,
              second_startY: 303,
              second_array: ["A100_101.png","A100_102.png","A100_103.png","A100_104.png","A100_105.png","A100_106.png","A100_107.png","A100_108.png","A100_109.png","A100_110.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 314,
              y: 142,
              src: 'A100_135.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 214,
              hour_startY: 176,
              hour_array: ["A100_123.png","A100_124.png","A100_125.png","A100_126.png","A100_127.png","A100_128.png","A100_129.png","A100_130.png","A100_131.png","A100_132.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 355,
              minute_startY: 179,
              minute_array: ["A100_136.png","A100_137.png","A100_138.png","A100_139.png","A100_140.png","A100_141.png","A100_142.png","A100_143.png","A100_144.png","A100_145.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 231,
              y: 355,
              w: 83,
              h: 76,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'null.png',
              normal_src: 'null.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'LowBatteryScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 52,
              y: 313,
              w: 83,
              h: 76,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'null.png',
              normal_src: 'null.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'heart_app_Screen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 57,
              y: 221,
              w: 83,
              h: 76,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'null.png',
              normal_src: 'null.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'activityAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 130,
              y: 139,
              w: 83,
              h: 76,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'null.png',
              normal_src: 'null.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'SportStatusScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 43,
              y: 93,
              w: 83,
              h: 76,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'null.png',
              normal_src: 'null.png',
              click_func: (button_widget) => {
                hmApp.startApp({ appid: 1051195, url: 'page/index', params: { from_wf: true} });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 225,
              y: 58,
              w: 83,
              h: 76,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'null.png',
              normal_src: 'null.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_7 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 127,
              y: 26,
              w: 83,
              h: 76,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'null.png',
              normal_src: 'null.png',
              click_func: (button_widget) => {
                hmApp.startApp({ appid: 1066654, url: 'page/index' });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_8 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 241,
              y: 205,
              w: 83,
              h: 76,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'null.png',
              normal_src: 'null.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'CountdownAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_9 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 362,
              y: 191,
              w: 83,
              h: 76,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'null.png',
              normal_src: 'null.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'StopWatchScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            function scale_call() {
              console.log('scale_call()');

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_cs_normal_step = progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_step * 100);
                  if (normal_step_circle_scale) {
                    normal_step_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 240,
                      center_y: 240,
                      start_angle: 0,
                      end_angle: 350,
                      radius: 233,
                      line_width: 12,
                      corner_flag: 3,
                      color: 0xFFFDCB02,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

              console.log('Weather city name');
              let weatherData = weatherSensor.getForecastWeather();
              normal_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
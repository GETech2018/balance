﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_distance_TextCircle = new Array(5);
        let normal_distance_TextCircle_ASCIIARRAY = new Array(10);
        let normal_distance_TextCircle_img_width = 19;
        let normal_distance_TextCircle_img_height = 35;
        let normal_distance_TextCircle_unit = null;
        let normal_distance_TextCircle_unit_width = 38;
        let normal_distance_TextCircle_dot_width = 10;
        let normal_temp_text_text_img = ''
        let normal_distance_text_separator_img = ''
        let normal_floor_current_text_img = ''
        let normal_fat_burning_current_separator_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_text_separator_img = ''
        let normal_altitude_target_text_img = ''
        let normal_altitude_target_separator_img = ''
        let normal_altimeter_text_text_img = ''
        let normal_stress_text_text_img = ''
        let normal_heart_rate_TextCircle = new Array(3);
        let normal_heart_rate_TextCircle_ASCIIARRAY = new Array(10);
        let normal_heart_rate_TextCircle_img_width = 19;
        let normal_heart_rate_TextCircle_img_height = 35;
        let normal_heart_rate_TextCircle_unit = null;
        let normal_heart_rate_TextCircle_unit_width = 56;
        let normal_calorie_TextCircle = new Array(4);
        let normal_calorie_TextCircle_ASCIIARRAY = new Array(10);
        let normal_calorie_TextCircle_img_width = 19;
        let normal_calorie_TextCircle_img_height = 35;
        let normal_calorie_TextCircle_unit = null;
        let normal_calorie_TextCircle_unit_width = 50;
        let normal_step_TextCircle = new Array(5);
        let normal_step_TextCircle_ASCIIARRAY = new Array(10);
        let normal_step_TextCircle_img_width = 19;
        let normal_step_TextCircle_img_height = 35;
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg_img = ''
        let idle_battery_pointer_progress_img_pointer = ''
        let idle_battery_text_text_img = ''
        let idle_altimeter_text_text_img = ''
        let idle_stress_text_text_img = ''
        let idle_distance_TextCircle = new Array(5);
        let idle_distance_TextCircle_ASCIIARRAY = new Array(10);
        let idle_distance_TextCircle_img_width = 19;
        let idle_distance_TextCircle_img_height = 35;
        let idle_distance_TextCircle_unit = null;
        let idle_distance_TextCircle_unit_width = 38;
        let idle_distance_TextCircle_dot_width = 10;
        let idle_heart_rate_TextCircle = new Array(3);
        let idle_heart_rate_TextCircle_ASCIIARRAY = new Array(10);
        let idle_heart_rate_TextCircle_img_width = 19;
        let idle_heart_rate_TextCircle_img_height = 35;
        let idle_heart_rate_TextCircle_unit = null;
        let idle_heart_rate_TextCircle_unit_width = 56;
        let idle_calorie_TextCircle = new Array(4);
        let idle_calorie_TextCircle_ASCIIARRAY = new Array(10);
        let idle_calorie_TextCircle_img_width = 19;
        let idle_calorie_TextCircle_img_height = 35;
        let idle_calorie_TextCircle_unit = null;
        let idle_calorie_TextCircle_unit_width = 50;
        let idle_step_TextCircle = new Array(5);
        let idle_step_TextCircle_ASCIIARRAY = new Array(10);
        let idle_step_TextCircle_img_width = 19;
        let idle_step_TextCircle_img_height = 35;
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let normal_step_jumpable_img_click = ''
        let normal_cal_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_altimeter_jumpable_img_click = ''
        let normal_stress_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
		const thermometer = hmSensor.createSensor(hmSensor.id.BODY_TEMP)
		
		let btn_zona1 = ''
        let zona1_num = 0
        let zona1_all = 3
		
		function click_zona1() {
		  zona1_num = (zona1_num + 1) % (zona1_all + 1);
          if (zona1_num == 0) {		
		    normal_altitude_target_text_img.setProperty(hmUI.prop.VISIBLE, true);
            normal_altitude_target_separator_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_battery_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_floor_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_fat_burning_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_temp_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		    hmUI.showToast({
            });
          };
		  
		 if (zona1_num == 1) {
			normal_altitude_target_text_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_altitude_target_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_battery_text_separator_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_floor_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_fat_burning_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_temp_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		    hmUI.showToast({
            });
          };
		  
		  if (zona1_num == 2) {
			normal_altitude_target_text_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_altitude_target_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_battery_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_floor_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_fat_burning_current_separator_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_temp_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		    hmUI.showToast({
            });
          };
		  
		  if (zona1_num == 3) {
			normal_altitude_target_text_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_altitude_target_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_battery_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_floor_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_fat_burning_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_temp_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, true);
		    hmUI.showToast({
            });
          };
        }


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_distance_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 240,
              // circle_center_Y: 240,
              // font_array: ["58.png","59.png","60.png","61.png","62.png","63.png","64.png","65.png","66.png","67.png"],
              // radius: 239,
              // angle: -120,
              // char_space_angle: 1,
              // unit: 'A100_068.png',
              // dot_image: 'dot.png',
              // zero: false,
              // reverse_direction: true,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.DISTANCE,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_distance_TextCircle_ASCIIARRAY[0] = '58.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[1] = '59.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[2] = '60.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[3] = '61.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[4] = '62.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[5] = '63.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[6] = '64.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[7] = '65.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[8] = '66.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[9] = '67.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              normal_distance_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 240,
                center_y: 240,
                pos_x: 240 - normal_distance_TextCircle_img_width / 2,
                pos_y: 240 + 204,
                src: '58.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_distance_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_distance_TextCircle_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              center_x: 240,
              center_y: 240,
              pos_x: 240 - normal_distance_TextCircle_unit_width / 2,
              pos_y: 240 + 204,
              src: 'A100_068.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_distance_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block
            
            const distance = hmSensor.createSensor(hmSensor.id.DISTANCE);
            distance.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });
            
            function toDegree (radian) {
              return radian * (180 / Math.PI);
            };

            normal_temp_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 200,
              y: 340,
              font_array: ["58.png","59.png","60.png","61.png","62.png","63.png","64.png","65.png","66.png","67.png"],
              padding: false,
              h_space: -1,
              dot_image: 'dot.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BODY_TEMP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 227,
              y: 302,
              src: 'temp.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_floor_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 212,
              y: 340,
              font_array: ["58.png","59.png","60.png","61.png","62.png","63.png","64.png","65.png","66.png","67.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.FLOOR,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_fat_burning_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 226,
              y: 300,
              src: 'help_climb.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 212,
              y: 340,
              font_array: ["58.png","59.png","60.png","61.png","62.png","63.png","64.png","65.png","66.png","67.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 224,
              y: 298,
              src: 'powers.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altitude_target_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 202,
              y: 340,
              font_array: ["58.png","59.png","60.png","61.png","62.png","63.png","64.png","65.png","66.png","67.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.ALTITUDE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altitude_target_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 224,
              y: 298,
              src: 'pb_list_icon_altitude.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 11,
              y: 143,
              font_array: ["58.png","59.png","60.png","61.png","62.png","63.png","64.png","65.png","66.png","67.png"],
              padding: false,
              h_space: 0,
              angle: -60,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 404,
              y: 98,
              font_array: ["58.png","59.png","60.png","61.png","62.png","63.png","64.png","65.png","66.png","67.png"],
              padding: false,
              h_space: 0,
              angle: 60,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STRESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_heart_rate_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 240,
              // circle_center_Y: 240,
              // font_array: ["58.png","59.png","60.png","61.png","62.png","63.png","64.png","65.png","66.png","67.png"],
              // radius: 206,
              // angle: -2,
              // char_space_angle: 0,
              // unit: 'A100_066.png',
              // zero: false,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_heart_rate_TextCircle_ASCIIARRAY[0] = '58.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[1] = '59.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[2] = '60.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[3] = '61.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[4] = '62.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[5] = '63.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[6] = '64.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[7] = '65.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[8] = '66.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[9] = '67.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 3; i++) {
              normal_heart_rate_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 240,
                center_y: 240,
                pos_x: 240 - normal_heart_rate_TextCircle_img_width / 2,
                pos_y: 240 - 241,
                src: '58.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_heart_rate_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_heart_rate_TextCircle_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              center_x: 240,
              center_y: 240,
              pos_x: 240 - normal_heart_rate_TextCircle_unit_width / 2,
              pos_y: 240 - 241,
              src: 'A100_066.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_heart_rate_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block
            
            const heart_rate = hmSensor.createSensor(hmSensor.id.HEART);
            heart_rate.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            // normal_calorie_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 240,
              // circle_center_Y: 240,
              // font_array: ["58.png","59.png","60.png","61.png","62.png","63.png","64.png","65.png","66.png","67.png"],
              // radius: 239,
              // angle: 181,
              // char_space_angle: 1,
              // unit: 'A100_069.png',
              // zero: false,
              // reverse_direction: true,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_calorie_TextCircle_ASCIIARRAY[0] = '58.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[1] = '59.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[2] = '60.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[3] = '61.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[4] = '62.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[5] = '63.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[6] = '64.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[7] = '65.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[8] = '66.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[9] = '67.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 4; i++) {
              normal_calorie_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 240,
                center_y: 240,
                pos_x: 240 - normal_calorie_TextCircle_img_width / 2,
                pos_y: 240 + 204,
                src: '58.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_calorie_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_calorie_TextCircle_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              center_x: 240,
              center_y: 240,
              pos_x: 240 - normal_calorie_TextCircle_unit_width / 2,
              pos_y: 240 + 204,
              src: 'A100_069.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_calorie_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block
            
            const calorie = hmSensor.createSensor(hmSensor.id.CALORIE);
            calorie.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            // normal_step_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 240,
              // circle_center_Y: 240,
              // font_array: ["58.png","59.png","60.png","61.png","62.png","63.png","64.png","65.png","66.png","67.png"],
              // radius: 239,
              // angle: 120,
              // char_space_angle: 0,
              // zero: false,
              // reverse_direction: true,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_step_TextCircle_ASCIIARRAY[0] = '58.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[1] = '59.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[2] = '60.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[3] = '61.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[4] = '62.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[5] = '63.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[6] = '64.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[7] = '65.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[8] = '66.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[9] = '67.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              normal_step_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 240,
                center_y: 240,
                pos_x: 240 - normal_step_TextCircle_img_width / 2,
                pos_y: 240 + 204,
                src: '58.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_step_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'A100_005.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 24,
              hour_posY: 125,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'A100_008.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 24,
              minute_posY: 176,
              minute_cover_path: 'A100_013.png',
              minute_cover_x: 222,
              minute_cover_y: 222,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'A100_011.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 11,
              second_posY: 186,
              second_cover_path: 'A100_014.png',
              second_cover_x: 230,
              second_cover_y: 230,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'aod.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'up.png',
              center_x: 240,
              center_y: 341,
              x: 10,
              y: 64,
              start_angle: -140,
              end_angle: 140,
              invalid_visible: false,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 210,
              y: 337,
              font_array: ["58.png","59.png","60.png","61.png","62.png","63.png","64.png","65.png","66.png","67.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_altimeter_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 11,
              y: 143,
              font_array: ["58.png","59.png","60.png","61.png","62.png","63.png","64.png","65.png","66.png","67.png"],
              padding: false,
              h_space: 0,
              angle: -60,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_stress_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 404,
              y: 98,
              font_array: ["58.png","59.png","60.png","61.png","62.png","63.png","64.png","65.png","66.png","67.png"],
              padding: false,
              h_space: 0,
              angle: 60,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STRESS,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_distance_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 240,
              // circle_center_Y: 240,
              // font_array: ["58.png","59.png","60.png","61.png","62.png","63.png","64.png","65.png","66.png","67.png"],
              // radius: 239,
              // angle: -120,
              // char_space_angle: 1,
              // unit: 'A100_068.png',
              // dot_image: 'dot.png',
              // zero: false,
              // reverse_direction: true,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.DISTANCE,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_distance_TextCircle_ASCIIARRAY[0] = '58.png';  // set of images with numbers
            idle_distance_TextCircle_ASCIIARRAY[1] = '59.png';  // set of images with numbers
            idle_distance_TextCircle_ASCIIARRAY[2] = '60.png';  // set of images with numbers
            idle_distance_TextCircle_ASCIIARRAY[3] = '61.png';  // set of images with numbers
            idle_distance_TextCircle_ASCIIARRAY[4] = '62.png';  // set of images with numbers
            idle_distance_TextCircle_ASCIIARRAY[5] = '63.png';  // set of images with numbers
            idle_distance_TextCircle_ASCIIARRAY[6] = '64.png';  // set of images with numbers
            idle_distance_TextCircle_ASCIIARRAY[7] = '65.png';  // set of images with numbers
            idle_distance_TextCircle_ASCIIARRAY[8] = '66.png';  // set of images with numbers
            idle_distance_TextCircle_ASCIIARRAY[9] = '67.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              idle_distance_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 240,
                center_y: 240,
                pos_x: 240 - idle_distance_TextCircle_img_width / 2,
                pos_y: 240 + 204,
                src: '58.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_distance_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            idle_distance_TextCircle_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              center_x: 240,
              center_y: 240,
              pos_x: 240 - idle_distance_TextCircle_unit_width / 2,
              pos_y: 240 + 204,
              src: 'A100_068.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            idle_distance_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block

            // idle_heart_rate_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 240,
              // circle_center_Y: 240,
              // font_array: ["58.png","59.png","60.png","61.png","62.png","63.png","64.png","65.png","66.png","67.png"],
              // radius: 206,
              // angle: -2,
              // char_space_angle: 0,
              // unit: 'A100_066.png',
              // zero: false,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_heart_rate_TextCircle_ASCIIARRAY[0] = '58.png';  // set of images with numbers
            idle_heart_rate_TextCircle_ASCIIARRAY[1] = '59.png';  // set of images with numbers
            idle_heart_rate_TextCircle_ASCIIARRAY[2] = '60.png';  // set of images with numbers
            idle_heart_rate_TextCircle_ASCIIARRAY[3] = '61.png';  // set of images with numbers
            idle_heart_rate_TextCircle_ASCIIARRAY[4] = '62.png';  // set of images with numbers
            idle_heart_rate_TextCircle_ASCIIARRAY[5] = '63.png';  // set of images with numbers
            idle_heart_rate_TextCircle_ASCIIARRAY[6] = '64.png';  // set of images with numbers
            idle_heart_rate_TextCircle_ASCIIARRAY[7] = '65.png';  // set of images with numbers
            idle_heart_rate_TextCircle_ASCIIARRAY[8] = '66.png';  // set of images with numbers
            idle_heart_rate_TextCircle_ASCIIARRAY[9] = '67.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 3; i++) {
              idle_heart_rate_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 240,
                center_y: 240,
                pos_x: 240 - idle_heart_rate_TextCircle_img_width / 2,
                pos_y: 240 - 241,
                src: '58.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_heart_rate_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            idle_heart_rate_TextCircle_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              center_x: 240,
              center_y: 240,
              pos_x: 240 - idle_heart_rate_TextCircle_unit_width / 2,
              pos_y: 240 - 241,
              src: 'A100_066.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            idle_heart_rate_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block

            // idle_calorie_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 240,
              // circle_center_Y: 240,
              // font_array: ["58.png","59.png","60.png","61.png","62.png","63.png","64.png","65.png","66.png","67.png"],
              // radius: 239,
              // angle: 181,
              // char_space_angle: 1,
              // unit: 'A100_069.png',
              // zero: false,
              // reverse_direction: true,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_calorie_TextCircle_ASCIIARRAY[0] = '58.png';  // set of images with numbers
            idle_calorie_TextCircle_ASCIIARRAY[1] = '59.png';  // set of images with numbers
            idle_calorie_TextCircle_ASCIIARRAY[2] = '60.png';  // set of images with numbers
            idle_calorie_TextCircle_ASCIIARRAY[3] = '61.png';  // set of images with numbers
            idle_calorie_TextCircle_ASCIIARRAY[4] = '62.png';  // set of images with numbers
            idle_calorie_TextCircle_ASCIIARRAY[5] = '63.png';  // set of images with numbers
            idle_calorie_TextCircle_ASCIIARRAY[6] = '64.png';  // set of images with numbers
            idle_calorie_TextCircle_ASCIIARRAY[7] = '65.png';  // set of images with numbers
            idle_calorie_TextCircle_ASCIIARRAY[8] = '66.png';  // set of images with numbers
            idle_calorie_TextCircle_ASCIIARRAY[9] = '67.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 4; i++) {
              idle_calorie_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 240,
                center_y: 240,
                pos_x: 240 - idle_calorie_TextCircle_img_width / 2,
                pos_y: 240 + 204,
                src: '58.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_calorie_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            idle_calorie_TextCircle_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              center_x: 240,
              center_y: 240,
              pos_x: 240 - idle_calorie_TextCircle_unit_width / 2,
              pos_y: 240 + 204,
              src: 'A100_069.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            idle_calorie_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block

            // idle_step_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 240,
              // circle_center_Y: 240,
              // font_array: ["58.png","59.png","60.png","61.png","62.png","63.png","64.png","65.png","66.png","67.png"],
              // radius: 239,
              // angle: 120,
              // char_space_angle: 0,
              // zero: false,
              // reverse_direction: true,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_step_TextCircle_ASCIIARRAY[0] = '58.png';  // set of images with numbers
            idle_step_TextCircle_ASCIIARRAY[1] = '59.png';  // set of images with numbers
            idle_step_TextCircle_ASCIIARRAY[2] = '60.png';  // set of images with numbers
            idle_step_TextCircle_ASCIIARRAY[3] = '61.png';  // set of images with numbers
            idle_step_TextCircle_ASCIIARRAY[4] = '62.png';  // set of images with numbers
            idle_step_TextCircle_ASCIIARRAY[5] = '63.png';  // set of images with numbers
            idle_step_TextCircle_ASCIIARRAY[6] = '64.png';  // set of images with numbers
            idle_step_TextCircle_ASCIIARRAY[7] = '65.png';  // set of images with numbers
            idle_step_TextCircle_ASCIIARRAY[8] = '66.png';  // set of images with numbers
            idle_step_TextCircle_ASCIIARRAY[9] = '67.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              idle_step_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 240,
                center_y: 240,
                pos_x: 240 - idle_step_TextCircle_img_width / 2,
                pos_y: 240 + 204,
                src: '58.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_step_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'A100_005.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 24,
              hour_posY: 125,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'A100_008.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 24,
              minute_posY: 176,
              minute_cover_path: 'A100_013.png',
              minute_cover_x: 222,
              minute_cover_y: 222,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 365,
              y: 300,
              w: 85,
              h: 85,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_cal_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 198,
              y: 413,
              w: 85,
              h: 85,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            btn_zona1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 190,
              y: 298,
              text: '',
              w: 100,
              h: 80,
              normal_src: 'Empty.png',
              press_src: 'Empty.png',
              click_func: () => {
				click_zona1();
                click_Vibrate();
             },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btn_zona1.setProperty(hmUI.prop.VISIBLE, true);
			normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_battery_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_floor_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_fat_burning_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_temp_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);

            normal_altimeter_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 20,
              y: 100,
              w: 85,
              h: 85,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 365,
              y: 100,
              w: 85,
              h: 85,
              type: hmUI.data_type.STRESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 203,
              y: 203,
              w: 75,
              h: 75,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            //start of ignored block
            function text_update() {
              console.log('text_update()');

              console.log('update text circle DISTANCE');
              let distanceCurrent = distance.current;
              let normal_distance_circle_string = (distanceCurrent / 1000).toFixed(2);

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  normal_distance_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_distance_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
                let char_Angle = 60;
                if (distanceCurrent != null && distanceCurrent != undefined && isFinite(distanceCurrent) && normal_distance_circle_string.length > 0 && normal_distance_circle_string.length <= 5) {  // display data if it was possible to get it
                  let normal_distance_TextCircle_img_angle = 0;
                  let normal_distance_TextCircle_dot_img_angle = 0;
                  let normal_distance_TextCircle_unit_angle = 0;
                  normal_distance_TextCircle_img_angle = toDegree(Math.atan2(normal_distance_TextCircle_img_width/2, 239));
                  normal_distance_TextCircle_dot_img_angle = toDegree(Math.atan2(normal_distance_TextCircle_dot_width/2, 239));
                  normal_distance_TextCircle_unit_angle = toDegree(Math.atan2(normal_distance_TextCircle_unit_width/2, 239));
                  // alignment = CENTER_H
                  let normal_distance_TextCircle_angleOffset = normal_distance_TextCircle_img_angle * (normal_distance_circle_string.length - 1);
                  normal_distance_TextCircle_angleOffset = normal_distance_TextCircle_angleOffset - normal_distance_TextCircle_img_angle + normal_distance_TextCircle_dot_img_angle;
                  normal_distance_TextCircle_angleOffset = normal_distance_TextCircle_angleOffset + 1 * (normal_distance_circle_string.length - 1) / 2;
                  normal_distance_TextCircle_angleOffset = normal_distance_TextCircle_angleOffset + (normal_distance_TextCircle_img_angle + normal_distance_TextCircle_unit_angle + 1) / 2;
                  normal_distance_TextCircle_angleOffset = -normal_distance_TextCircle_angleOffset;
                  char_Angle -= normal_distance_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_distance_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= normal_distance_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_distance_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_distance_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - normal_distance_TextCircle_img_width / 2);
                      normal_distance_TextCircle[index].setProperty(hmUI.prop.SRC, normal_distance_TextCircle_ASCIIARRAY[charCode]);
                      normal_distance_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= normal_distance_TextCircle_img_angle + 1;
                      index++;
                    }  // end if digit
                    else { 
                      if (!firstSymbol) char_Angle -= normal_distance_TextCircle_dot_img_angle; 
                      firstSymbol = false;
                      normal_distance_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_distance_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - normal_distance_TextCircle_dot_width / 2);
                      normal_distance_TextCircle[index].setProperty(hmUI.prop.SRC, 'dot.png');
                      normal_distance_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= normal_distance_TextCircle_dot_img_angle + 1;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                  char_Angle -= normal_distance_TextCircle_unit_angle;
                  normal_distance_TextCircle_unit.setProperty(hmUI.prop.ANGLE, char_Angle);
                  normal_distance_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite

              };

              console.log('update text circle heart_rate_HEART');
              let valueHeartRate = heart_rate.last;
              let normal_heart_rate_circle_string = parseInt(valueHeartRate).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  normal_heart_rate_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_heart_rate_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
                let char_Angle = -2;
                if (valueHeartRate != null && valueHeartRate != undefined && isFinite(valueHeartRate) && normal_heart_rate_circle_string.length > 0 && normal_heart_rate_circle_string.length <= 3) {  // display data if it was possible to get it
                  let normal_heart_rate_TextCircle_img_angle = 0;
                  let normal_heart_rate_TextCircle_dot_img_angle = 0;
                  let normal_heart_rate_TextCircle_unit_angle = 0;
                  normal_heart_rate_TextCircle_img_angle = toDegree(Math.atan2(normal_heart_rate_TextCircle_img_width/2, 206));
                  normal_heart_rate_TextCircle_unit_angle = toDegree(Math.atan2(normal_heart_rate_TextCircle_unit_width/2, 206));
                  // alignment = CENTER_H
                  let normal_heart_rate_TextCircle_angleOffset = normal_heart_rate_TextCircle_img_angle * (normal_heart_rate_circle_string.length - 1);
                  normal_heart_rate_TextCircle_angleOffset = normal_heart_rate_TextCircle_angleOffset + (normal_heart_rate_TextCircle_img_angle + normal_heart_rate_TextCircle_unit_angle + 0) / 2;
                  char_Angle -= normal_heart_rate_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_heart_rate_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += normal_heart_rate_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_heart_rate_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_heart_rate_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - normal_heart_rate_TextCircle_img_width / 2);
                      normal_heart_rate_TextCircle[index].setProperty(hmUI.prop.SRC, normal_heart_rate_TextCircle_ASCIIARRAY[charCode]);
                      normal_heart_rate_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_heart_rate_TextCircle_img_angle;
                      index++;
                    };  // end if digit
                  };  // end char of string
                  char_Angle += normal_heart_rate_TextCircle_unit_angle;
                  normal_heart_rate_TextCircle_unit.setProperty(hmUI.prop.ANGLE, char_Angle);
                  normal_heart_rate_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite

              };

              console.log('update text circle calorie_CALORIE');
              let valueCalories = calorie.current;
              let normal_calorie_circle_string = parseInt(valueCalories).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 4; i++) {  // hide all symbols
                  normal_calorie_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_calorie_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
                let char_Angle = 361;
                if (valueCalories != null && valueCalories != undefined && isFinite(valueCalories) && normal_calorie_circle_string.length > 0 && normal_calorie_circle_string.length <= 4) {  // display data if it was possible to get it
                  let normal_calorie_TextCircle_img_angle = 0;
                  let normal_calorie_TextCircle_dot_img_angle = 0;
                  let normal_calorie_TextCircle_unit_angle = 0;
                  normal_calorie_TextCircle_img_angle = toDegree(Math.atan2(normal_calorie_TextCircle_img_width/2, 239));
                  normal_calorie_TextCircle_unit_angle = toDegree(Math.atan2(normal_calorie_TextCircle_unit_width/2, 239));
                  // alignment = CENTER_H
                  let normal_calorie_TextCircle_angleOffset = normal_calorie_TextCircle_img_angle * (normal_calorie_circle_string.length - 1);
                  normal_calorie_TextCircle_angleOffset = normal_calorie_TextCircle_angleOffset + 1 * (normal_calorie_circle_string.length - 1) / 2;
                  normal_calorie_TextCircle_angleOffset = normal_calorie_TextCircle_angleOffset + (normal_calorie_TextCircle_img_angle + normal_calorie_TextCircle_unit_angle + 1) / 2;
                  normal_calorie_TextCircle_angleOffset = -normal_calorie_TextCircle_angleOffset;
                  char_Angle -= normal_calorie_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_calorie_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 4) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= normal_calorie_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_calorie_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_calorie_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - normal_calorie_TextCircle_img_width / 2);
                      normal_calorie_TextCircle[index].setProperty(hmUI.prop.SRC, normal_calorie_TextCircle_ASCIIARRAY[charCode]);
                      normal_calorie_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= normal_calorie_TextCircle_img_angle + 1;
                      index++;
                    };  // end if digit
                  };  // end char of string
                  char_Angle -= normal_calorie_TextCircle_unit_angle;
                  normal_calorie_TextCircle_unit.setProperty(hmUI.prop.ANGLE, char_Angle);
                  normal_calorie_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite

              };

              console.log('update text circle step_STEP');
              let valueStep = step.current;
              let normal_step_circle_string = parseInt(valueStep).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  normal_step_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = 300;
                if (valueStep != null && valueStep != undefined && isFinite(valueStep) && normal_step_circle_string.length > 0 && normal_step_circle_string.length <= 5) {  // display data if it was possible to get it
                  let normal_step_TextCircle_img_angle = 0;
                  let normal_step_TextCircle_dot_img_angle = 0;
                  normal_step_TextCircle_img_angle = toDegree(Math.atan2(normal_step_TextCircle_img_width/2, 239));
                  // alignment = CENTER_H
                  let normal_step_TextCircle_angleOffset = normal_step_TextCircle_img_angle * (normal_step_circle_string.length - 1);
                  normal_step_TextCircle_angleOffset = -normal_step_TextCircle_angleOffset;
                  char_Angle -= normal_step_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_step_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= normal_step_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_step_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_step_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - normal_step_TextCircle_img_width / 2);
                      normal_step_TextCircle[index].setProperty(hmUI.prop.SRC, normal_step_TextCircle_ASCIIARRAY[charCode]);
                      normal_step_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= normal_step_TextCircle_img_angle;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text circle DISTANCE');
              let idle_distance_circle_string = (distanceCurrent / 1000).toFixed(2);

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  idle_distance_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                idle_distance_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
                let char_Angle = 60;
                if (distanceCurrent != null && distanceCurrent != undefined && isFinite(distanceCurrent) && idle_distance_circle_string.length > 0 && idle_distance_circle_string.length <= 5) {  // display data if it was possible to get it
                  let idle_distance_TextCircle_img_angle = 0;
                  let idle_distance_TextCircle_dot_img_angle = 0;
                  let idle_distance_TextCircle_unit_angle = 0;
                  idle_distance_TextCircle_img_angle = toDegree(Math.atan2(idle_distance_TextCircle_img_width/2, 239));
                  idle_distance_TextCircle_dot_img_angle = toDegree(Math.atan2(idle_distance_TextCircle_dot_width/2, 239));
                  idle_distance_TextCircle_unit_angle = toDegree(Math.atan2(idle_distance_TextCircle_unit_width/2, 239));
                  // alignment = CENTER_H
                  let idle_distance_TextCircle_angleOffset = idle_distance_TextCircle_img_angle * (idle_distance_circle_string.length - 1);
                  idle_distance_TextCircle_angleOffset = idle_distance_TextCircle_angleOffset - idle_distance_TextCircle_img_angle + idle_distance_TextCircle_dot_img_angle;
                  idle_distance_TextCircle_angleOffset = idle_distance_TextCircle_angleOffset + 1 * (idle_distance_circle_string.length - 1) / 2;
                  idle_distance_TextCircle_angleOffset = idle_distance_TextCircle_angleOffset + (idle_distance_TextCircle_img_angle + idle_distance_TextCircle_unit_angle + 1) / 2;
                  idle_distance_TextCircle_angleOffset = -idle_distance_TextCircle_angleOffset;
                  char_Angle -= idle_distance_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of idle_distance_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= idle_distance_TextCircle_img_angle;
                      firstSymbol = false;
                      idle_distance_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      idle_distance_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - idle_distance_TextCircle_img_width / 2);
                      idle_distance_TextCircle[index].setProperty(hmUI.prop.SRC, idle_distance_TextCircle_ASCIIARRAY[charCode]);
                      idle_distance_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= idle_distance_TextCircle_img_angle + 1;
                      index++;
                    }  // end if digit
                    else { 
                      if (!firstSymbol) char_Angle -= idle_distance_TextCircle_dot_img_angle; 
                      firstSymbol = false;
                      idle_distance_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      idle_distance_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - idle_distance_TextCircle_dot_width / 2);
                      idle_distance_TextCircle[index].setProperty(hmUI.prop.SRC, 'dot.png');
                      idle_distance_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= idle_distance_TextCircle_dot_img_angle + 1;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                  char_Angle -= idle_distance_TextCircle_unit_angle;
                  idle_distance_TextCircle_unit.setProperty(hmUI.prop.ANGLE, char_Angle);
                  idle_distance_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite

              };

              console.log('update text circle heart_rate_HEART');
              let idle_heart_rate_circle_string = parseInt(valueHeartRate).toString();

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  idle_heart_rate_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                idle_heart_rate_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
                let char_Angle = -2;
                if (valueHeartRate != null && valueHeartRate != undefined && isFinite(valueHeartRate) && idle_heart_rate_circle_string.length > 0 && idle_heart_rate_circle_string.length <= 3) {  // display data if it was possible to get it
                  let idle_heart_rate_TextCircle_img_angle = 0;
                  let idle_heart_rate_TextCircle_dot_img_angle = 0;
                  let idle_heart_rate_TextCircle_unit_angle = 0;
                  idle_heart_rate_TextCircle_img_angle = toDegree(Math.atan2(idle_heart_rate_TextCircle_img_width/2, 206));
                  idle_heart_rate_TextCircle_unit_angle = toDegree(Math.atan2(idle_heart_rate_TextCircle_unit_width/2, 206));
                  // alignment = CENTER_H
                  let idle_heart_rate_TextCircle_angleOffset = idle_heart_rate_TextCircle_img_angle * (idle_heart_rate_circle_string.length - 1);
                  idle_heart_rate_TextCircle_angleOffset = idle_heart_rate_TextCircle_angleOffset + (idle_heart_rate_TextCircle_img_angle + idle_heart_rate_TextCircle_unit_angle + 0) / 2;
                  char_Angle -= idle_heart_rate_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of idle_heart_rate_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += idle_heart_rate_TextCircle_img_angle;
                      firstSymbol = false;
                      idle_heart_rate_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      idle_heart_rate_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - idle_heart_rate_TextCircle_img_width / 2);
                      idle_heart_rate_TextCircle[index].setProperty(hmUI.prop.SRC, idle_heart_rate_TextCircle_ASCIIARRAY[charCode]);
                      idle_heart_rate_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += idle_heart_rate_TextCircle_img_angle;
                      index++;
                    };  // end if digit
                  };  // end char of string
                  char_Angle += idle_heart_rate_TextCircle_unit_angle;
                  idle_heart_rate_TextCircle_unit.setProperty(hmUI.prop.ANGLE, char_Angle);
                  idle_heart_rate_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite

              };

              console.log('update text circle calorie_CALORIE');
              let idle_calorie_circle_string = parseInt(valueCalories).toString();

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 4; i++) {  // hide all symbols
                  idle_calorie_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                idle_calorie_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
                let char_Angle = 361;
                if (valueCalories != null && valueCalories != undefined && isFinite(valueCalories) && idle_calorie_circle_string.length > 0 && idle_calorie_circle_string.length <= 4) {  // display data if it was possible to get it
                  let idle_calorie_TextCircle_img_angle = 0;
                  let idle_calorie_TextCircle_dot_img_angle = 0;
                  let idle_calorie_TextCircle_unit_angle = 0;
                  idle_calorie_TextCircle_img_angle = toDegree(Math.atan2(idle_calorie_TextCircle_img_width/2, 239));
                  idle_calorie_TextCircle_unit_angle = toDegree(Math.atan2(idle_calorie_TextCircle_unit_width/2, 239));
                  // alignment = CENTER_H
                  let idle_calorie_TextCircle_angleOffset = idle_calorie_TextCircle_img_angle * (idle_calorie_circle_string.length - 1);
                  idle_calorie_TextCircle_angleOffset = idle_calorie_TextCircle_angleOffset + 1 * (idle_calorie_circle_string.length - 1) / 2;
                  idle_calorie_TextCircle_angleOffset = idle_calorie_TextCircle_angleOffset + (idle_calorie_TextCircle_img_angle + idle_calorie_TextCircle_unit_angle + 1) / 2;
                  idle_calorie_TextCircle_angleOffset = -idle_calorie_TextCircle_angleOffset;
                  char_Angle -= idle_calorie_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of idle_calorie_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 4) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= idle_calorie_TextCircle_img_angle;
                      firstSymbol = false;
                      idle_calorie_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      idle_calorie_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - idle_calorie_TextCircle_img_width / 2);
                      idle_calorie_TextCircle[index].setProperty(hmUI.prop.SRC, idle_calorie_TextCircle_ASCIIARRAY[charCode]);
                      idle_calorie_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= idle_calorie_TextCircle_img_angle + 1;
                      index++;
                    };  // end if digit
                  };  // end char of string
                  char_Angle -= idle_calorie_TextCircle_unit_angle;
                  idle_calorie_TextCircle_unit.setProperty(hmUI.prop.ANGLE, char_Angle);
                  idle_calorie_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite

              };

              console.log('update text circle step_STEP');
              let idle_step_circle_string = parseInt(valueStep).toString();

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  idle_step_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = 300;
                if (valueStep != null && valueStep != undefined && isFinite(valueStep) && idle_step_circle_string.length > 0 && idle_step_circle_string.length <= 5) {  // display data if it was possible to get it
                  let idle_step_TextCircle_img_angle = 0;
                  let idle_step_TextCircle_dot_img_angle = 0;
                  idle_step_TextCircle_img_angle = toDegree(Math.atan2(idle_step_TextCircle_img_width/2, 239));
                  // alignment = CENTER_H
                  let idle_step_TextCircle_angleOffset = idle_step_TextCircle_img_angle * (idle_step_circle_string.length - 1);
                  idle_step_TextCircle_angleOffset = -idle_step_TextCircle_angleOffset;
                  char_Angle -= idle_step_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of idle_step_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= idle_step_TextCircle_img_angle;
                      firstSymbol = false;
                      idle_step_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      idle_step_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - idle_step_TextCircle_img_width / 2);
                      idle_step_TextCircle[index].setProperty(hmUI.prop.SRC, idle_step_TextCircle_ASCIIARRAY[charCode]);
                      idle_step_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= idle_step_TextCircle_img_angle;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

            };

            //end of ignored block
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                text_update();
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
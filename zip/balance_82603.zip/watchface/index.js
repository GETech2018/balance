﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

//////////////////////////////////////////////////////////////////////////////////////////////////

        // Start color change
        let deviceInfoS = hmSetting.getDeviceInfo();
        let colornumber = 1
        let totalcolors = 4
        let namecolor = ''

        function click_Color() {
            if(colornumber>=totalcolors) {
            colornumber=1;
                }
            else {
                colornumber=colornumber+1;
            }

if ( colornumber == 1) { namecolor = "Blue";

            normal_battery_icon_img.setProperty(hmUI.prop.MORE, {
              x: deviceInfoS.width / 454 *  154,
              y: deviceInfoS.height / 454 * 386,
              src: 'icon_Batt.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            normal_battery_text_text_img.setProperty(hmUI.prop.MORE, {
              x: deviceInfoS.width / 454 *  195,
              y: deviceInfoS.height / 454 *  384,
              font_array: ["Day_Font_0.png","Day_Font_1.png","Day_Font_2.png","Day_Font_3.png","Day_Font_4.png","Day_Font_5.png","Day_Font_6.png","Day_Font_7.png","Day_Font_8.png","Day_Font_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Batt_Symbo.png',
              unit_tc: 'Batt_Symbo.png',
              unit_en: 'Batt_Symbo.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

 
            normal_date_img_date_day.setProperty(hmUI.prop.MORE, {
              day_startX: deviceInfoS.width / 454 *  199,
              day_startY: deviceInfoS.height / 454 *  89,
              day_sc_array: ["Day_Font_0.png","Day_Font_1.png","Day_Font_2.png","Day_Font_3.png","Day_Font_4.png","Day_Font_5.png","Day_Font_6.png","Day_Font_7.png","Day_Font_8.png","Day_Font_9.png"],
              day_tc_array: ["Day_Font_0.png","Day_Font_1.png","Day_Font_2.png","Day_Font_3.png","Day_Font_4.png","Day_Font_5.png","Day_Font_6.png","Day_Font_7.png","Day_Font_8.png","Day_Font_9.png"],
              day_en_array: ["Day_Font_0.png","Day_Font_1.png","Day_Font_2.png","Day_Font_3.png","Day_Font_4.png","Day_Font_5.png","Day_Font_6.png","Day_Font_7.png","Day_Font_8.png","Day_Font_9.png"],
              day_zero: 1,
              day_space: 1,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

         normal_digital_clock_img_time_AmPm.setProperty(hmUI.prop.MORE, {
              am_x: deviceInfoS.width / 454 *  70,
              am_y: deviceInfoS.height / 454 *  279,
              am_sc_path: 'Clock_AM.png',
              am_en_path: 'Clock_AM.png',
              pm_x: deviceInfoS.width / 454 *  70,
              pm_y: deviceInfoS.height / 454 *  279,
              pm_sc_path: 'Clock_PM.png',
              pm_en_path: 'Clock_PM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_second.setProperty(hmUI.prop.MORE, {
              second_startX: deviceInfoS.width / 454 *  327,
              second_startY: deviceInfoS.height / 454 *  221,
              second_array: ["Time_Sec_Blue_0.png","Time_Sec_Blue_1.png","Time_Sec_Blue_2.png","Time_Sec_Blue_3.png","Time_Sec_Blue_4.png","Time_Sec_Blue_5.png","Time_Sec_Blue_6.png","Time_Sec_Blue_7.png","Time_Sec_Blue_8.png","Time_Sec_Blue_9.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_minute.setProperty(hmUI.prop.MORE, {
              minute_startX: deviceInfoS.width / 454 *  206,
              minute_startY: deviceInfoS.height / 454 *  187,
              minute_array: ["Time_Font_Blue_0.png","Time_Font_Blue_1.png","Time_Font_Blue_2.png","Time_Font_Blue_3.png","Time_Font_Blue_4.png","Time_Font_Blue_5.png","Time_Font_Blue_6.png","Time_Font_Blue_7.png","Time_Font_Blue_8.png","Time_Font_Blue_9.png"],
              minute_zero: 1,
              minute_space: 5,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_hour.setProperty(hmUI.prop.MORE, {
              hour_startX: deviceInfoS.width / 454 *  64,
              hour_startY: deviceInfoS.height / 454 *  187,
              hour_array: ["Time_Font_Blue_0.png","Time_Font_Blue_1.png","Time_Font_Blue_2.png","Time_Font_Blue_3.png","Time_Font_Blue_4.png","Time_Font_Blue_5.png","Time_Font_Blue_6.png","Time_Font_Blue_7.png","Time_Font_Blue_8.png","Time_Font_Blue_9.png"],
              hour_zero: 1,
              hour_space: 5,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img.setProperty(hmUI.prop.MORE, {
              x: deviceInfoS.width / 454 *  158,
              y: deviceInfoS.height / 454 *  180,
              src: 'Time_Dot_Blue.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
const result = hmSetting.setScreenOff()
}

if ( colornumber == 2) { namecolor = "Yellow";

            normal_battery_icon_img.setProperty(hmUI.prop.MORE, {
              x: deviceInfoS.width / 454 *  154,
              y: deviceInfoS.height / 454 *  386,
              src: 'icon_Batt_Yellow.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            normal_battery_text_text_img.setProperty(hmUI.prop.MORE, {
              x: deviceInfoS.width / 454 *  195,
              y: deviceInfoS.height / 454 *  384,
              font_array: ["Day_yellow_0.png","Day_yellow_1.png","Day_yellow_2.png","Day_yellow_3.png","Day_yellow_4.png","Day_yellow_5.png","Day_yellow_6.png","Day_yellow_7.png","Day_yellow_8.png","Day_yellow_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Batt_Symbo_Yellow.png',
              unit_tc: 'Batt_Symbo_Yellow.png',
              unit_en: 'Batt_Symbo_Yellow.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

 
            normal_date_img_date_day.setProperty(hmUI.prop.MORE, {
              day_startX: deviceInfoS.width / 454 *  199,
              day_startY: deviceInfoS.height / 454 *  89,
              day_sc_array: ["Day_yellow_0.png","Day_yellow_1.png","Day_yellow_2.png","Day_yellow_3.png","Day_yellow_4.png","Day_yellow_5.png","Day_yellow_6.png","Day_yellow_7.png","Day_yellow_8.png","Day_yellow_9.png"],
              day_tc_array: ["Day_yellow_0.png","Day_yellow_1.png","Day_yellow_2.png","Day_yellow_3.png","Day_yellow_4.png","Day_yellow_5.png","Day_yellow_6.png","Day_yellow_7.png","Day_yellow_8.png","Day_yellow_9.png"],
              day_en_array: ["Day_yellow_0.png","Day_yellow_1.png","Day_yellow_2.png","Day_yellow_3.png","Day_yellow_4.png","Day_yellow_5.png","Day_yellow_6.png","Day_yellow_7.png","Day_yellow_8.png","Day_yellow_9.png"],
              day_zero: 1,
              day_space: 1,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

         normal_digital_clock_img_time_AmPm.setProperty(hmUI.prop.MORE, {
              am_x: deviceInfoS.width / 454 *  70,
              am_y: deviceInfoS.height / 454 *  279,
              am_sc_path: 'Clock_AM_Yellow.png',
              am_en_path: 'Clock_AM_Yellow.png',
              pm_x: deviceInfoS.width / 454 *  70,
              pm_y: deviceInfoS.height / 454 *  279,
              pm_sc_path: 'Clock_PM_Yellow.png',
              pm_en_path: 'Clock_PM_Yellow.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_second.setProperty(hmUI.prop.MORE, {
              second_startX: deviceInfoS.width / 454 *  327,
              second_startY: deviceInfoS.height / 454 *  221,
              second_array: ["Time_Sec_Yellow_0.png","Time_Sec_Yellow_1.png","Time_Sec_Yellow_2.png","Time_Sec_Yellow_3.png","Time_Sec_Yellow_4.png","Time_Sec_Yellow_5.png","Time_Sec_Yellow_6.png","Time_Sec_Yellow_7.png","Time_Sec_Yellow_8.png","Time_Sec_Yellow_9.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_minute.setProperty(hmUI.prop.MORE, {
              minute_startX: deviceInfoS.width / 454 *  206,
              minute_startY: deviceInfoS.height / 454 *  187,
              minute_array: ["Time_Font_Yellow_0.png","Time_Font_Yellow_1.png","Time_Font_Yellow_2.png","Time_Font_Yellow_3.png","Time_Font_Yellow_4.png","Time_Font_Yellow_5.png","Time_Font_Yellow_6.png","Time_Font_Yellow_7.png","Time_Font_Yellow_8.png","Time_Font_Yellow_9.png"],
              minute_zero: 1,
              minute_space: 5,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_hour.setProperty(hmUI.prop.MORE, {
              hour_startX: deviceInfoS.width / 454 *  64,
              hour_startY: deviceInfoS.height / 454 *  187,
              hour_array: ["Time_Font_Yellow_0.png","Time_Font_Yellow_1.png","Time_Font_Yellow_2.png","Time_Font_Yellow_3.png","Time_Font_Yellow_4.png","Time_Font_Yellow_5.png","Time_Font_Yellow_6.png","Time_Font_Yellow_7.png","Time_Font_Yellow_8.png","Time_Font_Yellow_9.png"],
              hour_zero: 1,
              hour_space: 5,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img.setProperty(hmUI.prop.MORE, {
              x: deviceInfoS.width / 454 *  158,
              y: deviceInfoS.height / 454 *  180,
              src: 'Time_Dot_Yellow.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
const result = hmSetting.setScreenOff()
}
if ( colornumber == 3) { namecolor = "Pink"


            normal_battery_icon_img.setProperty(hmUI.prop.MORE, {
              x: deviceInfoS.width / 454 *  154,
              y: deviceInfoS.height / 454 *  386,
              src: 'icon_Batt_Pink.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            normal_battery_text_text_img.setProperty(hmUI.prop.MORE, {
              x: deviceInfoS.width / 454 *  195,
              y: deviceInfoS.height / 454 *  384,
              font_array: ["Day_pink_0.png","Day_pink_1.png","Day_pink_2.png","Day_pink_3.png","Day_pink_4.png","Day_pink_5.png","Day_pink_6.png","Day_pink_7.png","Day_pink_8.png","Day_pink_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Batt_Symbo_Pink.png',
              unit_tc: 'Batt_Symbo_Pink.png',
              unit_en: 'Batt_Symbo_Pink.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

 
            normal_date_img_date_day.setProperty(hmUI.prop.MORE, {
              day_startX: deviceInfoS.width / 454 *  199,
              day_startY: deviceInfoS.height / 454 *  89,
              day_sc_array: ["Day_pink_0.png","Day_pink_1.png","Day_pink_2.png","Day_pink_3.png","Day_pink_4.png","Day_pink_5.png","Day_pink_6.png","Day_pink_7.png","Day_pink_8.png","Day_pink_9.png"],
              day_tc_array: ["Day_pink_0.png","Day_pink_1.png","Day_pink_2.png","Day_pink_3.png","Day_pink_4.png","Day_pink_5.png","Day_pink_6.png","Day_pink_7.png","Day_pink_8.png","Day_pink_9.png"],
              day_en_array: ["Day_pink_0.png","Day_pink_1.png","Day_pink_2.png","Day_pink_3.png","Day_pink_4.png","Day_pink_5.png","Day_pink_6.png","Day_pink_7.png","Day_pink_8.png","Day_pink_9.png"],
              day_zero: 1,
              day_space: 1,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

         normal_digital_clock_img_time_AmPm.setProperty(hmUI.prop.MORE, {
              am_x: deviceInfoS.width / 454 *  70,
              am_y: deviceInfoS.height / 454 *  279,
              am_sc_path: 'Clock_AM_Pink.png',
              am_en_path: 'Clock_AM_Pink.png',
              pm_x: deviceInfoS.width / 454 *  70,
              pm_y: deviceInfoS.height / 454 *  279,
              pm_sc_path: 'Clock_PM_Pink.png',
              pm_en_path: 'Clock_PM_Pink.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_second.setProperty(hmUI.prop.MORE, {
              second_startX: deviceInfoS.width / 454 *  327,
              second_startY: deviceInfoS.height / 454 *  221,
              second_array: ["Time_Sec_Pink_0.png","Time_Sec_Pink_1.png","Time_Sec_Pink_2.png","Time_Sec_Pink_3.png","Time_Sec_Pink_4.png","Time_Sec_Pink_5.png","Time_Sec_Pink_6.png","Time_Sec_Pink_7.png","Time_Sec_Pink_8.png","Time_Sec_Pink_9.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_minute.setProperty(hmUI.prop.MORE, {
              minute_startX: deviceInfoS.width / 454 *  206,
              minute_startY: deviceInfoS.height / 454 *  187,
              minute_array: ["Time_Font_Pink_0.png","Time_Font_Pink_1.png","Time_Font_Pink_2.png","Time_Font_Pink_3.png","Time_Font_Pink_4.png","Time_Font_Pink_5.png","Time_Font_Pink_6.png","Time_Font_Pink_7.png","Time_Font_Pink_8.png","Time_Font_Pink_9.png"],
              minute_zero: 1,
              minute_space: 5,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_hour.setProperty(hmUI.prop.MORE, {
              hour_startX: deviceInfoS.width / 454 *  64,
              hour_startY: deviceInfoS.height / 454 *  187,
              hour_array: ["Time_Font_Pink_0.png","Time_Font_Pink_1.png","Time_Font_Pink_2.png","Time_Font_Pink_3.png","Time_Font_Pink_4.png","Time_Font_Pink_5.png","Time_Font_Pink_6.png","Time_Font_Pink_7.png","Time_Font_Pink_8.png","Time_Font_Pink_9.png"],
              hour_zero: 1,
              hour_space: 5,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img.setProperty(hmUI.prop.MORE, {
              x: deviceInfoS.width / 454 *  158,
              y: deviceInfoS.height / 454 *  180,
              src: 'Time_Dot_Pink.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
const result = hmSetting.setScreenOff()
}


if ( colornumber == 4) { namecolor = "Green";

            normal_battery_icon_img.setProperty(hmUI.prop.MORE, {
              x: deviceInfoS.width / 454 *  154,
              y: deviceInfoS.height / 454 *  386,
              src: 'icon_Batt_Green.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            normal_battery_text_text_img.setProperty(hmUI.prop.MORE, {
              x: deviceInfoS.width / 454 *  195,
              y: deviceInfoS.height / 454 *  384,
              font_array: ["Day_green_0.png","Day_green_1.png","Day_green_2.png","Day_green_3.png","Day_green_4.png","Day_green_5.png","Day_green_6.png","Day_green_7.png","Day_green_8.png","Day_green_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Batt_Symbo_Green.png',
              unit_tc: 'Batt_Symbo_Green.png',
              unit_en: 'Batt_Symbo_Green.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

 
            normal_date_img_date_day.setProperty(hmUI.prop.MORE, {
              day_startX: deviceInfoS.width / 454 *  199,
              day_startY: deviceInfoS.height / 454 *  89,
              day_sc_array: ["Day_green_0.png","Day_green_1.png","Day_green_2.png","Day_green_3.png","Day_green_4.png","Day_green_5.png","Day_green_6.png","Day_green_7.png","Day_green_8.png","Day_green_9.png"],
              day_tc_array: ["Day_green_0.png","Day_green_1.png","Day_green_2.png","Day_green_3.png","Day_green_4.png","Day_green_5.png","Day_green_6.png","Day_green_7.png","Day_green_8.png","Day_green_9.png"],
              day_en_array: ["Day_green_0.png","Day_green_1.png","Day_green_2.png","Day_green_3.png","Day_green_4.png","Day_green_5.png","Day_green_6.png","Day_green_7.png","Day_green_8.png","Day_green_9.png"],
              day_zero: 1,
              day_space: 1,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

         normal_digital_clock_img_time_AmPm.setProperty(hmUI.prop.MORE, {
              am_x: deviceInfoS.width / 454 *  70,
              am_y: deviceInfoS.height / 454 *  279,
              am_sc_path: 'Clock_AM_Green.png',
              am_en_path: 'Clock_AM_Green.png',
              pm_x: deviceInfoS.width / 454 *  70,
              pm_y: deviceInfoS.height / 454 *  279,
              pm_sc_path: 'Clock_PM_Green.png',
              pm_en_path: 'Clock_PM_Green.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_second.setProperty(hmUI.prop.MORE, {
              second_startX: deviceInfoS.width / 454 *  327,
              second_startY: deviceInfoS.height / 454 *  221,
              second_array: ["Time_Sec_Green_0.png","Time_Sec_Green_1.png","Time_Sec_Green_2.png","Time_Sec_Green_3.png","Time_Sec_Green_4.png","Time_Sec_Green_5.png","Time_Sec_Green_6.png","Time_Sec_Green_7.png","Time_Sec_Green_8.png","Time_Sec_Green_9.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_minute.setProperty(hmUI.prop.MORE, {
              minute_startX: deviceInfoS.width / 454 *  206,
              minute_startY: deviceInfoS.height / 454 *  187,
              minute_array: ["Time_Font_Green_0.png","Time_Font_Green_1.png","Time_Font_Green_2.png","Time_Font_Green_3.png","Time_Font_Green_4.png","Time_Font_Green_5.png","Time_Font_Green_6.png","Time_Font_Green_7.png","Time_Font_Green_8.png","Time_Font_Green_9.png"],
              minute_zero: 1,
              minute_space: 5,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_hour.setProperty(hmUI.prop.MORE, {
              hour_startX: deviceInfoS.width / 454 *  64,
              hour_startY: deviceInfoS.height / 454 *  187,
              hour_array: ["Time_Font_Green_0.png","Time_Font_Green_1.png","Time_Font_Green_2.png","Time_Font_Green_3.png","Time_Font_Green_4.png","Time_Font_Green_5.png","Time_Font_Green_6.png","Time_Font_Green_7.png","Time_Font_Green_8.png","Time_Font_Green_9.png"],
              hour_zero: 1,
              hour_space: 5,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img.setProperty(hmUI.prop.MORE, {
              x: deviceInfoS.width / 454 *  158,
              y: deviceInfoS.height / 454 *  180,
              src: 'Time_Dot_Green.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
const result = hmSetting.setScreenOff()
}

hmUI.showToast({text: namecolor });

             //hmUI.showToast({text: "color " + parseInt(colornumber) });
             normal_background_bg_img.setProperty(hmUI.prop.SRC, "main" + parseInt(colornumber) + ".png");
                           
        }



        function click_ColorT() {
            if(colornumber>=totalcolors) {
            colornumber=1;
                }
            else {
                colornumber=colornumber+1;
            }

if ( colornumber == 1) { namecolor = "Blue";

            normal_battery_icon_img.setProperty(hmUI.prop.MORE, {
              x: deviceInfoS.width / 454 *  154,
              y: deviceInfoS.height / 454 *  386,
              src: 'icon_Batt.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            normal_battery_text_text_img.setProperty(hmUI.prop.MORE, {
              x: deviceInfoS.width / 454 *  195,
              y: deviceInfoS.height / 454 *  384,
              font_array: ["Day_Font_0.png","Day_Font_1.png","Day_Font_2.png","Day_Font_3.png","Day_Font_4.png","Day_Font_5.png","Day_Font_6.png","Day_Font_7.png","Day_Font_8.png","Day_Font_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Batt_Symbo.png',
              unit_tc: 'Batt_Symbo.png',
              unit_en: 'Batt_Symbo.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

 
            normal_date_img_date_day.setProperty(hmUI.prop.MORE, {
              day_startX: deviceInfoS.width / 454 *  199,
              day_startY: deviceInfoS.height / 454 *  89,
              day_sc_array: ["Day_Font_0.png","Day_Font_1.png","Day_Font_2.png","Day_Font_3.png","Day_Font_4.png","Day_Font_5.png","Day_Font_6.png","Day_Font_7.png","Day_Font_8.png","Day_Font_9.png"],
              day_tc_array: ["Day_Font_0.png","Day_Font_1.png","Day_Font_2.png","Day_Font_3.png","Day_Font_4.png","Day_Font_5.png","Day_Font_6.png","Day_Font_7.png","Day_Font_8.png","Day_Font_9.png"],
              day_en_array: ["Day_Font_0.png","Day_Font_1.png","Day_Font_2.png","Day_Font_3.png","Day_Font_4.png","Day_Font_5.png","Day_Font_6.png","Day_Font_7.png","Day_Font_8.png","Day_Font_9.png"],
              day_zero: 1,
              day_space: 1,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

         normal_digital_clock_img_time_AmPm.setProperty(hmUI.prop.MORE, {
              am_x: deviceInfoS.width / 454 *  70,
              am_y: deviceInfoS.height / 454 *  279,
              am_sc_path: 'Clock_AM.png',
              am_en_path: 'Clock_AM.png',
              pm_x: deviceInfoS.width / 454 *  70,
              pm_y: deviceInfoS.height / 454 *  279,
              pm_sc_path: 'Clock_PM.png',
              pm_en_path: 'Clock_PM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_second.setProperty(hmUI.prop.MORE, {
              second_startX: deviceInfoS.width / 454 *  327,
              second_startY: deviceInfoS.height / 454 *  221,
              second_array: ["Time_Sec_Blue_0.png","Time_Sec_Blue_1.png","Time_Sec_Blue_2.png","Time_Sec_Blue_3.png","Time_Sec_Blue_4.png","Time_Sec_Blue_5.png","Time_Sec_Blue_6.png","Time_Sec_Blue_7.png","Time_Sec_Blue_8.png","Time_Sec_Blue_9.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_minute.setProperty(hmUI.prop.MORE, {
              minute_startX: deviceInfoS.width / 454 *  206,
              minute_startY: deviceInfoS.height / 454 *  187,
              minute_array: ["Time_Font_Blue_0.png","Time_Font_Blue_1.png","Time_Font_Blue_2.png","Time_Font_Blue_3.png","Time_Font_Blue_4.png","Time_Font_Blue_5.png","Time_Font_Blue_6.png","Time_Font_Blue_7.png","Time_Font_Blue_8.png","Time_Font_Blue_9.png"],
              minute_zero: 1,
              minute_space: 5,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_hour.setProperty(hmUI.prop.MORE, {
              hour_startX: deviceInfoS.width / 454 *  64,
              hour_startY: deviceInfoS.height / 454 *  187,
              hour_array: ["Time_Font_Blue_0.png","Time_Font_Blue_1.png","Time_Font_Blue_2.png","Time_Font_Blue_3.png","Time_Font_Blue_4.png","Time_Font_Blue_5.png","Time_Font_Blue_6.png","Time_Font_Blue_7.png","Time_Font_Blue_8.png","Time_Font_Blue_9.png"],
              hour_zero: 1,
              hour_space: 5,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img.setProperty(hmUI.prop.MORE, {
              x: deviceInfoS.width / 454 *  158,
              y: deviceInfoS.height / 454 *  180,
              src: 'Time_Dot_Blue.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
const result = hmSetting.setScreenOff()
}

if ( colornumber == 2) { namecolor = "Yellow";

            normal_battery_icon_img.setProperty(hmUI.prop.MORE, {
              x: deviceInfoS.width / 454 *  154,
              y: deviceInfoS.height / 454 *  386,
              src: 'icon_Batt_Yellow.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            normal_battery_text_text_img.setProperty(hmUI.prop.MORE, {
              x: deviceInfoS.width / 454 *  195,
              y: deviceInfoS.height / 454 *  384,
              font_array: ["Day_yellow_0.png","Day_yellow_1.png","Day_yellow_2.png","Day_yellow_3.png","Day_yellow_4.png","Day_yellow_5.png","Day_yellow_6.png","Day_yellow_7.png","Day_yellow_8.png","Day_yellow_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Batt_Symbo_Yellow.png',
              unit_tc: 'Batt_Symbo_Yellow.png',
              unit_en: 'Batt_Symbo_Yellow.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

 
            normal_date_img_date_day.setProperty(hmUI.prop.MORE, {
              day_startX: deviceInfoS.width / 454 *  199,
              day_startY: deviceInfoS.height / 454 *  89,
              day_sc_array: ["Day_yellow_0.png","Day_yellow_1.png","Day_yellow_2.png","Day_yellow_3.png","Day_yellow_4.png","Day_yellow_5.png","Day_yellow_6.png","Day_yellow_7.png","Day_yellow_8.png","Day_yellow_9.png"],
              day_tc_array: ["Day_yellow_0.png","Day_yellow_1.png","Day_yellow_2.png","Day_yellow_3.png","Day_yellow_4.png","Day_yellow_5.png","Day_yellow_6.png","Day_yellow_7.png","Day_yellow_8.png","Day_yellow_9.png"],
              day_en_array: ["Day_yellow_0.png","Day_yellow_1.png","Day_yellow_2.png","Day_yellow_3.png","Day_yellow_4.png","Day_yellow_5.png","Day_yellow_6.png","Day_yellow_7.png","Day_yellow_8.png","Day_yellow_9.png"],
              day_zero: 1,
              day_space: 1,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

         normal_digital_clock_img_time_AmPm.setProperty(hmUI.prop.MORE, {
              am_x: deviceInfoS.width / 454 *  70,
              am_y: deviceInfoS.height / 454 *  279,
              am_sc_path: 'Clock_AM_Yellow.png',
              am_en_path: 'Clock_AM_Yellow.png',
              pm_x: deviceInfoS.width / 454 *  70,
              pm_y: deviceInfoS.height / 454 *  279,
              pm_sc_path: 'Clock_PM_Yellow.png',
              pm_en_path: 'Clock_PM_Yellow.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_second.setProperty(hmUI.prop.MORE, {
              second_startX: deviceInfoS.width / 454 *  327,
              second_startY: deviceInfoS.height / 454 *  221,
              second_array: ["Time_Sec_Yellow_0.png","Time_Sec_Yellow_1.png","Time_Sec_Yellow_2.png","Time_Sec_Yellow_3.png","Time_Sec_Yellow_4.png","Time_Sec_Yellow_5.png","Time_Sec_Yellow_6.png","Time_Sec_Yellow_7.png","Time_Sec_Yellow_8.png","Time_Sec_Yellow_9.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_minute.setProperty(hmUI.prop.MORE, {
              minute_startX: deviceInfoS.width / 454 *  206,
              minute_startY: deviceInfoS.height / 454 *  187,
              minute_array: ["Time_Font_Yellow_0.png","Time_Font_Yellow_1.png","Time_Font_Yellow_2.png","Time_Font_Yellow_3.png","Time_Font_Yellow_4.png","Time_Font_Yellow_5.png","Time_Font_Yellow_6.png","Time_Font_Yellow_7.png","Time_Font_Yellow_8.png","Time_Font_Yellow_9.png"],
              minute_zero: 1,
              minute_space: 5,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_hour.setProperty(hmUI.prop.MORE, {
              hour_startX: deviceInfoS.width / 454 *  64,
              hour_startY: deviceInfoS.height / 454 *  187,
              hour_array: ["Time_Font_Yellow_0.png","Time_Font_Yellow_1.png","Time_Font_Yellow_2.png","Time_Font_Yellow_3.png","Time_Font_Yellow_4.png","Time_Font_Yellow_5.png","Time_Font_Yellow_6.png","Time_Font_Yellow_7.png","Time_Font_Yellow_8.png","Time_Font_Yellow_9.png"],
              hour_zero: 1,
              hour_space: 5,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img.setProperty(hmUI.prop.MORE, {
              x: deviceInfoS.width / 454 *  158,
              y: deviceInfoS.height / 454 *  180,
              src: 'Time_Dot_Yellow.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
const result = hmSetting.setScreenOff()
}
if ( colornumber == 3) { namecolor = "Pink"


            normal_battery_icon_img.setProperty(hmUI.prop.MORE, {
              x: deviceInfoS.width / 454 *  154,
              y: deviceInfoS.height / 454 *  386,
              src: 'icon_Batt_Pink.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            normal_battery_text_text_img.setProperty(hmUI.prop.MORE, {
              x: deviceInfoS.width / 454 *  195,
              y: deviceInfoS.height / 454 *  384,
              font_array: ["Day_pink_0.png","Day_pink_1.png","Day_pink_2.png","Day_pink_3.png","Day_pink_4.png","Day_pink_5.png","Day_pink_6.png","Day_pink_7.png","Day_pink_8.png","Day_pink_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Batt_Symbo_Pink.png',
              unit_tc: 'Batt_Symbo_Pink.png',
              unit_en: 'Batt_Symbo_Pink.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

 
            normal_date_img_date_day.setProperty(hmUI.prop.MORE, {
              day_startX: deviceInfoS.width / 454 *  199,
              day_startY: deviceInfoS.height / 454 *  89,
              day_sc_array: ["Day_pink_0.png","Day_pink_1.png","Day_pink_2.png","Day_pink_3.png","Day_pink_4.png","Day_pink_5.png","Day_pink_6.png","Day_pink_7.png","Day_pink_8.png","Day_pink_9.png"],
              day_tc_array: ["Day_pink_0.png","Day_pink_1.png","Day_pink_2.png","Day_pink_3.png","Day_pink_4.png","Day_pink_5.png","Day_pink_6.png","Day_pink_7.png","Day_pink_8.png","Day_pink_9.png"],
              day_en_array: ["Day_pink_0.png","Day_pink_1.png","Day_pink_2.png","Day_pink_3.png","Day_pink_4.png","Day_pink_5.png","Day_pink_6.png","Day_pink_7.png","Day_pink_8.png","Day_pink_9.png"],
              day_zero: 1,
              day_space: 1,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

         normal_digital_clock_img_time_AmPm.setProperty(hmUI.prop.MORE, {
              am_x: deviceInfoS.width / 454 *  70,
              am_y: deviceInfoS.height / 454 *  279,
              am_sc_path: 'Clock_AM_Pink.png',
              am_en_path: 'Clock_AM_Pink.png',
              pm_x: deviceInfoS.width / 454 *  70,
              pm_y: deviceInfoS.height / 454 *  279,
              pm_sc_path: 'Clock_PM_Pink.png',
              pm_en_path: 'Clock_PM_Pink.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_second.setProperty(hmUI.prop.MORE, {
              second_startX: deviceInfoS.width / 454 *  327,
              second_startY: deviceInfoS.height / 454 *  221,
              second_array: ["Time_Sec_Pink_0.png","Time_Sec_Pink_1.png","Time_Sec_Pink_2.png","Time_Sec_Pink_3.png","Time_Sec_Pink_4.png","Time_Sec_Pink_5.png","Time_Sec_Pink_6.png","Time_Sec_Pink_7.png","Time_Sec_Pink_8.png","Time_Sec_Pink_9.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_minute.setProperty(hmUI.prop.MORE, {
              minute_startX: deviceInfoS.width / 454 *  206,
              minute_startY: deviceInfoS.height / 454 *  187,
              minute_array: ["Time_Font_Pink_0.png","Time_Font_Pink_1.png","Time_Font_Pink_2.png","Time_Font_Pink_3.png","Time_Font_Pink_4.png","Time_Font_Pink_5.png","Time_Font_Pink_6.png","Time_Font_Pink_7.png","Time_Font_Pink_8.png","Time_Font_Pink_9.png"],
              minute_zero: 1,
              minute_space: 5,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_hour.setProperty(hmUI.prop.MORE, {
              hour_startX: deviceInfoS.width / 454 *  64,
              hour_startY: deviceInfoS.height / 454 *  187,
              hour_array: ["Time_Font_Pink_0.png","Time_Font_Pink_1.png","Time_Font_Pink_2.png","Time_Font_Pink_3.png","Time_Font_Pink_4.png","Time_Font_Pink_5.png","Time_Font_Pink_6.png","Time_Font_Pink_7.png","Time_Font_Pink_8.png","Time_Font_Pink_9.png"],
              hour_zero: 1,
              hour_space: 5,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img.setProperty(hmUI.prop.MORE, {
              x: deviceInfoS.width / 454 *  158,
              y: deviceInfoS.height / 454 *  180,
              src: 'Time_Dot_Pink.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
const result = hmSetting.setScreenOff()
}


if ( colornumber == 4) { namecolor = "Green";

            normal_battery_icon_img.setProperty(hmUI.prop.MORE, {
              x: deviceInfoS.width / 454 *  154,
              y: deviceInfoS.height / 454 *  386,
              src: 'icon_Batt_Green.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            normal_battery_text_text_img.setProperty(hmUI.prop.MORE, {
              x: deviceInfoS.width / 454 *  195,
              y: deviceInfoS.height / 454 *  384,
              font_array: ["Day_green_0.png","Day_green_1.png","Day_green_2.png","Day_green_3.png","Day_green_4.png","Day_green_5.png","Day_green_6.png","Day_green_7.png","Day_green_8.png","Day_green_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Batt_Symbo_Green.png',
              unit_tc: 'Batt_Symbo_Green.png',
              unit_en: 'Batt_Symbo_Green.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

 
            normal_date_img_date_day.setProperty(hmUI.prop.MORE, {
              day_startX: deviceInfoS.width / 454 *  199,
              day_startY: deviceInfoS.height / 454 *  89,
              day_sc_array: ["Day_green_0.png","Day_green_1.png","Day_green_2.png","Day_green_3.png","Day_green_4.png","Day_green_5.png","Day_green_6.png","Day_green_7.png","Day_green_8.png","Day_green_9.png"],
              day_tc_array: ["Day_green_0.png","Day_green_1.png","Day_green_2.png","Day_green_3.png","Day_green_4.png","Day_green_5.png","Day_green_6.png","Day_green_7.png","Day_green_8.png","Day_green_9.png"],
              day_en_array: ["Day_green_0.png","Day_green_1.png","Day_green_2.png","Day_green_3.png","Day_green_4.png","Day_green_5.png","Day_green_6.png","Day_green_7.png","Day_green_8.png","Day_green_9.png"],
              day_zero: 1,
              day_space: 1,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

         normal_digital_clock_img_time_AmPm.setProperty(hmUI.prop.MORE, {
              am_x: deviceInfoS.width / 454 *  70,
              am_y: deviceInfoS.height / 454 *  279,
              am_sc_path: 'Clock_AM_Green.png',
              am_en_path: 'Clock_AM_Green.png',
              pm_x: deviceInfoS.width / 454 *  70,
              pm_y: deviceInfoS.height / 454 *  279,
              pm_sc_path: 'Clock_PM_Green.png',
              pm_en_path: 'Clock_PM_Green.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_second.setProperty(hmUI.prop.MORE, {
              second_startX: deviceInfoS.width / 454 *  327,
              second_startY: deviceInfoS.height / 454 *  221,
              second_array: ["Time_Sec_Green_0.png","Time_Sec_Green_1.png","Time_Sec_Green_2.png","Time_Sec_Green_3.png","Time_Sec_Green_4.png","Time_Sec_Green_5.png","Time_Sec_Green_6.png","Time_Sec_Green_7.png","Time_Sec_Green_8.png","Time_Sec_Green_9.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_minute.setProperty(hmUI.prop.MORE, {
              minute_startX: deviceInfoS.width / 454 *  206,
              minute_startY: deviceInfoS.height / 454 *  187,
              minute_array: ["Time_Font_Green_0.png","Time_Font_Green_1.png","Time_Font_Green_2.png","Time_Font_Green_3.png","Time_Font_Green_4.png","Time_Font_Green_5.png","Time_Font_Green_6.png","Time_Font_Green_7.png","Time_Font_Green_8.png","Time_Font_Green_9.png"],
              minute_zero: 1,
              minute_space: 5,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_hour.setProperty(hmUI.prop.MORE, {
              hour_startX: deviceInfoS.width / 454 *  64,
              hour_startY: deviceInfoS.height / 454 *  187,
              hour_array: ["Time_Font_Green_0.png","Time_Font_Green_1.png","Time_Font_Green_2.png","Time_Font_Green_3.png","Time_Font_Green_4.png","Time_Font_Green_5.png","Time_Font_Green_6.png","Time_Font_Green_7.png","Time_Font_Green_8.png","Time_Font_Green_9.png"],
              hour_zero: 1,
              hour_space: 5,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img.setProperty(hmUI.prop.MORE, {
              x: deviceInfoS.width / 454 *  158,
              y: deviceInfoS.height / 454 *  180,
              src: 'Time_Dot_Green.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
const result = hmSetting.setScreenOff()
}

hmUI.showToast({text: namecolor });

                            
        }

/////////////////////////////////////////////////////////////////////////////////////////////////
        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_battery_linear_scale = ''
        let normal_battery_icon_img = ''
        let normal_battery_text_text_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_distance_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_city_name_text = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_date_img_date_week_img = ''
        let normal_digital_clock_img_time_second = ''
        let normal_digital_clock_img_time_minute = ''
        let normal_digital_clock_img_time_hour = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let idle_background_bg_img = ''
        let idle_battery_linear_scale = ''
        let idle_battery_icon_img = ''
        let idle_battery_text_text_img = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_day = ''
        let idle_distance_text_text_img = ''
        let idle_step_current_text_img = ''
        let idle_calorie_current_text_img = ''
        let idle_heart_rate_text_text_img = ''
        let idle_moon_image_progress_img_level = ''
        let idle_city_name_text = ''
        let idle_temperature_current_text_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_date_img_date_week_img = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''
        let idle_digital_clock_img_time_AmPm = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'main1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            if (screenType != hmSetting.screen_type.AOD) {
              normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 167,
              // start_y: 409,
              // color: 0xFFF4630B,
              // lenght: 27,
              // line_width: 15,
              // line_cap: Flat,
              // vertical: False,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 163,
              y: 408,
              src: 'icon_Batt.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 206,
              y: 406,
              font_array: ["Day_Font_0.png","Day_Font_1.png","Day_Font_2.png","Day_Font_3.png","Day_Font_4.png","Day_Font_5.png","Day_Font_6.png","Day_Font_7.png","Day_Font_8.png","Day_Font_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Batt_Symbo.png',
              unit_tc: 'Batt_Symbo.png',
              unit_en: 'Batt_Symbo.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 172,
              month_startY: 49,
              month_sc_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_tc_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_en_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 210,
              day_startY: 94,
              day_sc_array: ["Day_Font_0.png","Day_Font_1.png","Day_Font_2.png","Day_Font_3.png","Day_Font_4.png","Day_Font_5.png","Day_Font_6.png","Day_Font_7.png","Day_Font_8.png","Day_Font_9.png"],
              day_tc_array: ["Day_Font_0.png","Day_Font_1.png","Day_Font_2.png","Day_Font_3.png","Day_Font_4.png","Day_Font_5.png","Day_Font_6.png","Day_Font_7.png","Day_Font_8.png","Day_Font_9.png"],
              day_en_array: ["Day_Font_0.png","Day_Font_1.png","Day_Font_2.png","Day_Font_3.png","Day_Font_4.png","Day_Font_5.png","Day_Font_6.png","Day_Font_7.png","Day_Font_8.png","Day_Font_9.png"],
              day_zero: 1,
              day_space: 1,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 160,
              y: 365,
              font_array: ["Weather_Font_0.png","Weather_Font_1.png","Weather_Font_2.png","Weather_Font_3.png","Weather_Font_4.png","Weather_Font_5.png","Weather_Font_6.png","Weather_Font_7.png","Weather_Font_8.png","Weather_Font_9.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'Dis_KM.png',
              unit_tc: 'Dis_KM.png',
              unit_en: 'Dis_KM.png',
              imperial_unit_sc: 'Dis_Mi.png',
              imperial_unit_tc: 'Dis_Mi.png',
              imperial_unit_en: 'Dis_Mi.png',
              dot_image: 'Dis_dot.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 190,
              y: 333,
              font_array: ["Weather_Font_0.png","Weather_Font_1.png","Weather_Font_2.png","Weather_Font_3.png","Weather_Font_4.png","Weather_Font_5.png","Weather_Font_6.png","Weather_Font_7.png","Weather_Font_8.png","Weather_Font_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 343,
              y: 335,
              font_array: ["Cal_Font_0.png","Cal_Font_1.png","Cal_Font_2.png","Cal_Font_3.png","Cal_Font_4.png","Cal_Font_5.png","Cal_Font_6.png","Cal_Font_7.png","Cal_Font_8.png","Cal_Font_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 77,
              y: 332,
              font_array: ["Weather_Font_0.png","Weather_Font_1.png","Weather_Font_2.png","Weather_Font_3.png","Weather_Font_4.png","Weather_Font_5.png","Weather_Font_6.png","Weather_Font_7.png","Weather_Font_8.png","Weather_Font_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 419,
              y: 230,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 160,
              y: 146,
              w: 161,
              h: 38,
              text_size: 26,
              char_space: 0,
              line_space: 0,
              color: 0xFFFE6601,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 338,
              y: 162,
              font_array: ["Weather_Font_0.png","Weather_Font_1.png","Weather_Font_2.png","Weather_Font_3.png","Weather_Font_4.png","Weather_Font_5.png","Weather_Font_6.png","Weather_Font_7.png","Weather_Font_8.png","Weather_Font_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Weather_Symbo1.png',
              unit_tc: 'Weather_Symbo1.png',
              unit_en: 'Weather_Symbo1.png',
              imperial_unit_sc: 'Weather_Symbo1.png',
              imperial_unit_tc: 'Weather_Symbo1.png',
              imperial_unit_en: 'Weather_Symbo1.png',
              negative_image: 'Weather_Symbo2.png',
              invalid_image: 'Weather_Symbo2.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const temperatureUnit = hmSetting.getTemperatureUnit();
            //start of ignored block
            if (temperatureUnit == 1) {
              normal_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
                x: 338,
                y: 162,
                font_array: ["Weather_Font_0.png","Weather_Font_1.png","Weather_Font_2.png","Weather_Font_3.png","Weather_Font_4.png","Weather_Font_5.png","Weather_Font_6.png","Weather_Font_7.png","Weather_Font_8.png","Weather_Font_9.png"],
                padding: false,
                h_space: 0,
                unit_sc: 'Weather_Symbo1.png',
                unit_tc: 'Weather_Symbo1.png',
                unit_en: 'Weather_Symbo1.png',
                imperial_unit_sc: 'Weather_Symbo1.png',
                imperial_unit_tc: 'Weather_Symbo1.png',
                imperial_unit_en: 'Weather_Symbo1.png',
                negative_image: 'Weather_Symbo2.png',
                invalid_image: 'Weather_Symbo2.png',
                align_h: hmUI.align.CENTER_H,
                type: hmUI.data_type.WEATHER_CURRENT,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
            };
            //end of ignored block

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 96,
              y: 158,
              image_array: ["Weather_icon_01.png","Weather_icon_02.png","Weather_icon_03.png","Weather_icon_04.png","Weather_icon_05.png","Weather_icon_06.png","Weather_icon_07.png","Weather_icon_08.png","Weather_icon_09.png","Weather_icon_10.png","Weather_icon_11.png","Weather_icon_12.png","Weather_icon_13.png","Weather_icon_14.png","Weather_icon_15.png","Weather_icon_16.png","Weather_icon_17.png","Weather_icon_18.png","Weather_icon_19.png","Weather_icon_20.png","Weather_icon_21.png","Weather_icon_22.png","Weather_icon_23.png","Weather_icon_24.png","Weather_icon_25.png","Weather_icon_26.png","Weather_icon_27.png","Weather_icon_28.png","Weather_icon_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 10,
              y: 288,
              src: 'System_BT_OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 44,
              y: 230,
              src: 'System_alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 78,
              y: 126,
              week_en: ["week1.png","week2.png","week3.png","week4.png","week5.png","week6.png","week7.png"],
              week_tc: ["week1.png","week2.png","week3.png","week4.png","week5.png","week6.png","week7.png"],
              week_sc: ["week1.png","week2.png","week3.png","week4.png","week5.png","week6.png","week7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_second = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              second_startX: 346,
              second_startY: 234,
              second_array: ["Time_Sec_Blue_0.png","Time_Sec_Blue_1.png","Time_Sec_Blue_2.png","Time_Sec_Blue_3.png","Time_Sec_Blue_4.png","Time_Sec_Blue_5.png","Time_Sec_Blue_6.png","Time_Sec_Blue_7.png","Time_Sec_Blue_8.png","Time_Sec_Blue_9.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 218,
              minute_startY: 198,
              minute_array: ["Time_Font_Blue_0.png","Time_Font_Blue_1.png","Time_Font_Blue_2.png","Time_Font_Blue_3.png","Time_Font_Blue_4.png","Time_Font_Blue_5.png","Time_Font_Blue_6.png","Time_Font_Blue_7.png","Time_Font_Blue_8.png","Time_Font_Blue_9.png"],
              minute_zero: 1,
              minute_space: 5,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 68,
              hour_startY: 198,
              hour_array: ["Time_Font_Blue_0.png","Time_Font_Blue_1.png","Time_Font_Blue_2.png","Time_Font_Blue_3.png","Time_Font_Blue_4.png","Time_Font_Blue_5.png","Time_Font_Blue_6.png","Time_Font_Blue_7.png","Time_Font_Blue_8.png","Time_Font_Blue_9.png"],
              hour_zero: 1,
              hour_space: 5,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 167,
              y: 190,
              src: 'Time_Dot_Blue.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 74,
              am_y: 295,
              am_sc_path: 'Clock_AM.png',
              am_en_path: 'Clock_AM.png',
              pm_x: 74,
              pm_y: 295,
              pm_sc_path: 'Clock_PM.png',
              pm_en_path: 'Clock_PM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'main1.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            if (screenType == hmSetting.screen_type.AOD) {
              idle_battery_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // idle_battery_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 167,
              // start_y: 409,
              // color: 0xFFF4630B,
              // lenght: 27,
              // line_width: 15,
              // line_cap: Flat,
              // vertical: False,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 163,
              y: 408,
              src: 'icon_Batt.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 206,
              y: 406,
              font_array: ["Day_Font_0.png","Day_Font_1.png","Day_Font_2.png","Day_Font_3.png","Day_Font_4.png","Day_Font_5.png","Day_Font_6.png","Day_Font_7.png","Day_Font_8.png","Day_Font_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Batt_Symbo.png',
              unit_tc: 'Batt_Symbo.png',
              unit_en: 'Batt_Symbo.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 172,
              month_startY: 49,
              month_sc_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_tc_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_en_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 210,
              day_startY: 94,
              day_sc_array: ["Day_Font_0.png","Day_Font_1.png","Day_Font_2.png","Day_Font_3.png","Day_Font_4.png","Day_Font_5.png","Day_Font_6.png","Day_Font_7.png","Day_Font_8.png","Day_Font_9.png"],
              day_tc_array: ["Day_Font_0.png","Day_Font_1.png","Day_Font_2.png","Day_Font_3.png","Day_Font_4.png","Day_Font_5.png","Day_Font_6.png","Day_Font_7.png","Day_Font_8.png","Day_Font_9.png"],
              day_en_array: ["Day_Font_0.png","Day_Font_1.png","Day_Font_2.png","Day_Font_3.png","Day_Font_4.png","Day_Font_5.png","Day_Font_6.png","Day_Font_7.png","Day_Font_8.png","Day_Font_9.png"],
              day_zero: 1,
              day_space: 1,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 160,
              y: 365,
              font_array: ["Weather_Font_0.png","Weather_Font_1.png","Weather_Font_2.png","Weather_Font_3.png","Weather_Font_4.png","Weather_Font_5.png","Weather_Font_6.png","Weather_Font_7.png","Weather_Font_8.png","Weather_Font_9.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'Dis_KM.png',
              unit_tc: 'Dis_KM.png',
              unit_en: 'Dis_KM.png',
              imperial_unit_sc: 'Dis_Mi.png',
              imperial_unit_tc: 'Dis_Mi.png',
              imperial_unit_en: 'Dis_Mi.png',
              dot_image: 'Dis_dot.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 190,
              y: 333,
              font_array: ["Weather_Font_0.png","Weather_Font_1.png","Weather_Font_2.png","Weather_Font_3.png","Weather_Font_4.png","Weather_Font_5.png","Weather_Font_6.png","Weather_Font_7.png","Weather_Font_8.png","Weather_Font_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 343,
              y: 335,
              font_array: ["Cal_Font_0.png","Cal_Font_1.png","Cal_Font_2.png","Cal_Font_3.png","Cal_Font_4.png","Cal_Font_5.png","Cal_Font_6.png","Cal_Font_7.png","Cal_Font_8.png","Cal_Font_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 77,
              y: 332,
              font_array: ["Weather_Font_0.png","Weather_Font_1.png","Weather_Font_2.png","Weather_Font_3.png","Weather_Font_4.png","Weather_Font_5.png","Weather_Font_6.png","Weather_Font_7.png","Weather_Font_8.png","Weather_Font_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 419,
              y: 230,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 160,
              y: 146,
              w: 161,
              h: 38,
              text_size: 26,
              char_space: 0,
              line_space: 0,
              color: 0xFFFE6601,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 338,
              y: 162,
              font_array: ["Weather_Font_0.png","Weather_Font_1.png","Weather_Font_2.png","Weather_Font_3.png","Weather_Font_4.png","Weather_Font_5.png","Weather_Font_6.png","Weather_Font_7.png","Weather_Font_8.png","Weather_Font_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Weather_Symbo1.png',
              unit_tc: 'Weather_Symbo1.png',
              unit_en: 'Weather_Symbo1.png',
              imperial_unit_sc: 'Weather_Symbo1.png',
              imperial_unit_tc: 'Weather_Symbo1.png',
              imperial_unit_en: 'Weather_Symbo1.png',
              negative_image: 'Weather_Symbo2.png',
              invalid_image: 'Weather_Symbo2.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            //start of ignored block
            if (temperatureUnit == 1) {
              idle_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
                x: 338,
                y: 162,
                font_array: ["Weather_Font_0.png","Weather_Font_1.png","Weather_Font_2.png","Weather_Font_3.png","Weather_Font_4.png","Weather_Font_5.png","Weather_Font_6.png","Weather_Font_7.png","Weather_Font_8.png","Weather_Font_9.png"],
                padding: false,
                h_space: 0,
                unit_sc: 'Weather_Symbo1.png',
                unit_tc: 'Weather_Symbo1.png',
                unit_en: 'Weather_Symbo1.png',
                imperial_unit_sc: 'Weather_Symbo1.png',
                imperial_unit_tc: 'Weather_Symbo1.png',
                imperial_unit_en: 'Weather_Symbo1.png',
                negative_image: 'Weather_Symbo2.png',
                invalid_image: 'Weather_Symbo2.png',
                align_h: hmUI.align.CENTER_H,
                type: hmUI.data_type.WEATHER_CURRENT,
                show_level: hmUI.show_level.ONLY_AOD,
              });
            };
            //end of ignored block

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 96,
              y: 158,
              image_array: ["Weather_icon_01.png","Weather_icon_02.png","Weather_icon_03.png","Weather_icon_04.png","Weather_icon_05.png","Weather_icon_06.png","Weather_icon_07.png","Weather_icon_08.png","Weather_icon_09.png","Weather_icon_10.png","Weather_icon_11.png","Weather_icon_12.png","Weather_icon_13.png","Weather_icon_14.png","Weather_icon_15.png","Weather_icon_16.png","Weather_icon_17.png","Weather_icon_18.png","Weather_icon_19.png","Weather_icon_20.png","Weather_icon_21.png","Weather_icon_22.png","Weather_icon_23.png","Weather_icon_24.png","Weather_icon_25.png","Weather_icon_26.png","Weather_icon_27.png","Weather_icon_28.png","Weather_icon_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 10,
              y: 288,
              src: 'System_BT_OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 44,
              y: 230,
              src: 'System_alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 78,
              y: 126,
              week_en: ["week1.png","week2.png","week3.png","week4.png","week5.png","week6.png","week7.png"],
              week_tc: ["week1.png","week2.png","week3.png","week4.png","week5.png","week6.png","week7.png"],
              week_sc: ["week1.png","week2.png","week3.png","week4.png","week5.png","week6.png","week7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 68,
              hour_startY: 198,
              hour_array: ["Time_Font_Blue_0.png","Time_Font_Blue_1.png","Time_Font_Blue_2.png","Time_Font_Blue_3.png","Time_Font_Blue_4.png","Time_Font_Blue_5.png","Time_Font_Blue_6.png","Time_Font_Blue_7.png","Time_Font_Blue_8.png","Time_Font_Blue_9.png"],
              hour_zero: 1,
              hour_space: 5,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 218,
              minute_startY: 198,
              minute_array: ["Time_Font_Blue_0.png","Time_Font_Blue_1.png","Time_Font_Blue_2.png","Time_Font_Blue_3.png","Time_Font_Blue_4.png","Time_Font_Blue_5.png","Time_Font_Blue_6.png","Time_Font_Blue_7.png","Time_Font_Blue_8.png","Time_Font_Blue_9.png"],
              minute_zero: 1,
              minute_space: 5,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 346,
              second_startY: 234,
              second_array: ["Time_Sec_Blue_0.png","Time_Sec_Blue_1.png","Time_Sec_Blue_2.png","Time_Sec_Blue_3.png","Time_Sec_Blue_4.png","Time_Sec_Blue_5.png","Time_Sec_Blue_6.png","Time_Sec_Blue_7.png","Time_Sec_Blue_8.png","Time_Sec_Blue_9.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 167,
              y: 190,
              src: 'Time_Dot_Blue.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 74,
              am_y: 295,
              am_sc_path: 'Clock_AM.png',
              am_en_path: 'Clock_AM.png',
              pm_x: 74,
              pm_y: 295,
              pm_sc_path: 'Clock_PM.png',
              pm_en_path: 'Clock_PM.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 345,
              y: 198,
              w: 58,
              h: 79,
              src: '0_Empty.png',
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 191,
              y: 203,
              w: 27,
              h: 79,
              src: '0_Empty.png',
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 419,
              y: 292,
              w: 48,
              h: 88,
              src: '0_Empty.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 418,
              y: 221,
              w: 57,
              h: 35,
              src: '0_Empty.png',
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 335,
              y: 152,
              w: 75,
              h: 34,
              src: '0_Empty.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 307,
              y: 328,
              w: 103,
              h: 29,
              src: '0_Empty.png',
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 70,
              y: 364,
              w: 103,
              h: 25,
              src: '0_Empty.png',
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 70,
              y: 325,
              w: 101,
              h: 30,
              src: '0_Empty.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 193,
              y: 299,
              w: 98,
              h: 53,
              src: '0_Empty.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 158,
              y: 396,
              w: 174,
              h: 34,
              text: '',
              color: 0xFFFF8C00,
              text_size: 26,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PowerSaveHintScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 3,
              y: 77,
              w: 64,
              h: 126,
              text: '',
              color: 0xFFFF8C00,
              text_size: 26,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 192,
              y: 437,
              w: 101,
              h: 126,
              text: '',
              color: 0xFFFF8C00,
              text_size: 26,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'SportListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 413,
              y: 94,
              w: 58,
              h: 92,
              text: '',
              color: 0xFFFF8C00,
              text_size: 26,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                //color style
   click_Color()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 96,
              y: 210,
              w: 60,
              h: 58,
              text: '',
              color: 0xFFFF8C00,
              text_size: 26,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                // color Time
   click_ColorT()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            function scale_call() {
              console.log('scale_call()');

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_ls_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_linear_scale
                  // initial parameters
                  let start_x_normal_battery = 167;
                  let start_y_normal_battery = 409;
                  let lenght_ls_normal_battery = 27;
                  let line_width_ls_normal_battery = 15;
                  let color_ls_normal_battery = 0xFFF4630B;
                  
                  // calculated parameters
                  let start_x_normal_battery_draw = start_x_normal_battery;
                  let start_y_normal_battery_draw = start_y_normal_battery;
                  lenght_ls_normal_battery = lenght_ls_normal_battery * progress_ls_normal_battery;
                  let lenght_ls_normal_battery_draw = lenght_ls_normal_battery;
                  let line_width_ls_normal_battery_draw = line_width_ls_normal_battery;
                  if (lenght_ls_normal_battery < 0){
                    lenght_ls_normal_battery_draw = -lenght_ls_normal_battery;
                    start_x_normal_battery_draw = start_x_normal_battery - lenght_ls_normal_battery_draw;
                  };
                  
                  normal_battery_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_battery_draw,
                    y: start_y_normal_battery_draw,
                    w: lenght_ls_normal_battery_draw,
                    h: line_width_ls_normal_battery_draw,
                    color: color_ls_normal_battery,
                  });
                };

              console.log('Weather city name');
              let weatherData = weatherSensor.getForecastWeather();
              normal_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

                console.log('update scales BATTERY');
                let progress_ls_idle_battery = progressBattery;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_battery_linear_scale
                  // initial parameters
                  let start_x_idle_battery = 167;
                  let start_y_idle_battery = 409;
                  let lenght_ls_idle_battery = 27;
                  let line_width_ls_idle_battery = 15;
                  let color_ls_idle_battery = 0xFFF4630B;
                  
                  // calculated parameters
                  let start_x_idle_battery_draw = start_x_idle_battery;
                  let start_y_idle_battery_draw = start_y_idle_battery;
                  lenght_ls_idle_battery = lenght_ls_idle_battery * progress_ls_idle_battery;
                  let lenght_ls_idle_battery_draw = lenght_ls_idle_battery;
                  let line_width_ls_idle_battery_draw = line_width_ls_idle_battery;
                  if (lenght_ls_idle_battery < 0){
                    lenght_ls_idle_battery_draw = -lenght_ls_idle_battery;
                    start_x_idle_battery_draw = start_x_idle_battery - lenght_ls_idle_battery_draw;
                  };
                  
                  idle_battery_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_idle_battery_draw,
                    y: start_y_idle_battery_draw,
                    w: lenght_ls_idle_battery_draw,
                    h: line_width_ls_idle_battery_draw,
                    color: color_ls_idle_battery,
                  });
                };

              console.log('Weather city name');
              idle_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg = ''
        let normal_compass_text_img = ''
        let normal_compass_separator_img = ''
        let normal_distance_text_text_img = ''
        let normal_distance_text_separator_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_text_separator_img = ''
        let normal_step_linear_scale = ''
        let normal_step_linear_scale_mirror = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_digital_clock_img_time = ''
        let normal_system_lock_img = ''
        let normal_system_dnd_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_high_text_img = ''
        let normal_temperature_high_separator_img = ''
        let normal_temperature_low_text_img = ''
        let normal_temperature_low_separator_img = ''
        let normal_temperature_current_text_img = ''
        let normal_image_img = ''
        let normal_analog_clock_pro_second_pointer_img = ''
        let normal_timerUpdateSec = undefined;
        let idle_background_bg = ''
        let idle_heart_rate_text_text_img = ''
        let idle_heart_rate_text_separator_img = ''
        let idle_digital_clock_img_time = ''
        let idle_system_lock_img = ''
        let idle_system_dnd_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_battery_text_text_img = ''
        let idle_battery_image_progress_img_level = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_day = ''
        let idle_image_img = ''
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_compass_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 120,
              y: 128,
              font_array: ["24_0.png","24_1.png","24_2.png","24_3.png","24_4.png","24_5.png","24_6.png","24_7.png","24_8.png","24_9.png"],
              padding: true,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.COMPASS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_compass_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 92,
              y: 128,
              src: 'compass.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 284,
              y: 128,
              font_array: ["24_0.png","24_1.png","24_2.png","24_3.png","24_4.png","24_5.png","24_6.png","24_7.png","24_8.png","24_9.png"],
              padding: true,
              h_space: 0,
              dot_image: '24_dot.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 256,
              y: 128,
              src: 'distance.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 120,
              y: 92,
              font_array: ["24_0.png","24_1.png","24_2.png","24_3.png","24_4.png","24_5.png","24_6.png","24_7.png","24_8.png","24_9.png"],
              padding: true,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 92,
              y: 92,
              src: 'heart.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            if (screenType != hmSetting.screen_type.AOD) {
              normal_step_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
              normal_step_linear_scale_mirror = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // normal_step_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 240,
              // start_y: 174,
              // color: 0xFFF7AA00,
              // lenght: 231,
              // line_width: 5,
              // line_cap: Flat,
              // vertical: False,
              // mirror: True,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 284,
              y: 92,
              font_array: ["24_0.png","24_1.png","24_2.png","24_3.png","24_4.png","24_5.png","24_6.png","24_7.png","24_8.png","24_9.png"],
              padding: true,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 256,
              y: 92,
              src: 'steps.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 60,
              hour_startY: 192,
              hour_array: ["72_0.png","72_1.png","72_2.png","72_3.png","72_4.png","72_5.png","72_6.png","72_7.png","72_8.png","72_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_unit_sc: '72_colon.png',
              hour_unit_tc: '72_colon.png',
              hour_unit_en: '72_colon.png',
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 0,
              minute_startY: 0,
              minute_array: ["72_0.png","72_1.png","72_2.png","72_3.png","72_4.png","72_5.png","72_6.png","72_7.png","72_8.png","72_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 1,
              minute_align: hmUI.align.LEFT,

              second_startX: 428,
              second_startY: 252,
              second_array: ["24_0.png","24_1.png","24_2.png","24_3.png","24_4.png","24_5.png","24_6.png","24_7.png","24_8.png","24_9.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 28,
              y: 196,
              src: '24_lock.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 4,
              y: 224,
              src: '24_dnd.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 28,
              y: 252,
              src: '24_bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 428,
              y: 196,
              src: '24_al.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 216,
              y: 408,
              font_array: ["24_0.png","24_1.png","24_2.png","24_3.png","24_4.png","24_5.png","24_6.png","24_7.png","24_8.png","24_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 172,
              y: 408,
              image_array: ["24_batt_00.png","24_batt_01.png","24_batt_02.png","24_batt_03.png","24_batt_04.png","24_batt_05.png","24_batt_06.png","24_batt_07.png","24_batt_08.png","24_batt_09.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 114,
              y: 42,
              week_en: ["DAYS_Image01.png","DAYS_Image02.png","DAYS_Image03.png","DAYS_Image04.png","DAYS_Image05.png","DAYS_Image06.png","DAYS_Image07.png"],
              week_tc: ["DAYS_Image01.png","DAYS_Image02.png","DAYS_Image03.png","DAYS_Image04.png","DAYS_Image05.png","DAYS_Image06.png","DAYS_Image07.png"],
              week_sc: ["DAYS_Image01.png","DAYS_Image02.png","DAYS_Image03.png","DAYS_Image04.png","DAYS_Image05.png","DAYS_Image06.png","DAYS_Image07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 282,
              month_startY: 42,
              month_sc_array: ["MONTH_Image01.png","MONTH_Image02.png","MONTH_Image03.png","MONTH_Image04.png","MONTH_Image05.png","MONTH_Image06.png","MONTH_Image07.png","MONTH_Image08.png","MONTH_Image09.png","MONTH_Image10.png","MONTH_Image11.png","MONTH_Image12.png"],
              month_tc_array: ["MONTH_Image01.png","MONTH_Image02.png","MONTH_Image03.png","MONTH_Image04.png","MONTH_Image05.png","MONTH_Image06.png","MONTH_Image07.png","MONTH_Image08.png","MONTH_Image09.png","MONTH_Image10.png","MONTH_Image11.png","MONTH_Image12.png"],
              month_en_array: ["MONTH_Image01.png","MONTH_Image02.png","MONTH_Image03.png","MONTH_Image04.png","MONTH_Image05.png","MONTH_Image06.png","MONTH_Image07.png","MONTH_Image08.png","MONTH_Image09.png","MONTH_Image10.png","MONTH_Image11.png","MONTH_Image12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 216,
              day_startY: 48,
              day_sc_array: ["24_0.png","24_1.png","24_2.png","24_3.png","24_4.png","24_5.png","24_6.png","24_7.png","24_8.png","24_9.png"],
              day_tc_array: ["24_0.png","24_1.png","24_2.png","24_3.png","24_4.png","24_5.png","24_6.png","24_7.png","24_8.png","24_9.png"],
              day_en_array: ["24_0.png","24_1.png","24_2.png","24_3.png","24_4.png","24_5.png","24_6.png","24_7.png","24_8.png","24_9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 0,
              y: 288,
              image_array: ["row-1-column-1.png","row-2-column-1.png","row-3-column-1.png","row-4-column-1.png","row-5-column-1.png","row-6-column-1.png","row-7-column-1.png","row-8-column-1.png","row-9-column-1.png","row-10-column-1.png","row-11-column-1.png","row-12-column-1.png","row-13-column-1.png","row-14-column-1.png","row-15-column-1.png","row-16-column-1.png","row-17-column-1.png","row-18-column-1.png","row-19-column-1.png","row-20-column-1.png","row-21-column-1.png","row-22-column-1.png","row-23-column-1.png","row-24-column-1.png","row-25-column-1.png","row-26-column-1.png","row-27-column-1.png","row-28-column-1.png","row-29-column-1.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 340,
              y: 324,
              font_array: ["24_0.png","24_1.png","24_2.png","24_3.png","24_4.png","24_5.png","24_6.png","24_7.png","24_8.png","24_9.png"],
              padding: false,
              h_space: 0,
              negative_image: '24_minus.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 334,
              y: 358,
              src: 'LBLS_Image01.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 68,
              y: 324,
              font_array: ["24_0.png","24_1.png","24_2.png","24_3.png","24_4.png","24_5.png","24_6.png","24_7.png","24_8.png","24_9.png"],
              padding: false,
              h_space: 0,
              negative_image: '24_minus.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 62,
              y: 358,
              src: 'LBLS_Image02.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 146,
              y: 330,
              font_array: ["NUMBERS_MEDIUM_01.png","NUMBERS_MEDIUM_02.png","NUMBERS_MEDIUM_03.png","NUMBERS_MEDIUM_04.png","NUMBERS_MEDIUM_05.png","NUMBERS_MEDIUM_06.png","NUMBERS_MEDIUM_07.png","NUMBERS_MEDIUM_08.png","NUMBERS_MEDIUM_09.png","NUMBERS_MEDIUM_10.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'NUMBERS_MEDIUM_11.png',
              unit_tc: 'NUMBERS_MEDIUM_11.png',
              unit_en: 'NUMBERS_MEDIUM_11.png',
              negative_image: 'NUMBERS_MEDIUM_12.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: '24_grid.png',
              // alpha: 127,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img.setAlpha(127);

            const deviceInfo = hmSetting.getDeviceInfo();
            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'sec_dot.png',
              // center_x: 240,
              // center_y: 240,
              // x: 8,
              // y: 240,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 8,
              pos_y: 240 - 240,
              center_x: 240,
              center_y: 240,
              src: 'sec_dot.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 170,
              y: 106,
              font_array: ["NUMBERS_MEDIUM_01.png","NUMBERS_MEDIUM_02.png","NUMBERS_MEDIUM_03.png","NUMBERS_MEDIUM_04.png","NUMBERS_MEDIUM_05.png","NUMBERS_MEDIUM_06.png","NUMBERS_MEDIUM_07.png","NUMBERS_MEDIUM_08.png","NUMBERS_MEDIUM_09.png","NUMBERS_MEDIUM_10.png"],
              padding: true,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 136,
              y: 120,
              src: 'heart.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 60,
              hour_startY: 192,
              hour_array: ["72_0.png","72_1.png","72_2.png","72_3.png","72_4.png","72_5.png","72_6.png","72_7.png","72_8.png","72_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_unit_sc: '72_colon.png',
              hour_unit_tc: '72_colon.png',
              hour_unit_en: '72_colon.png',
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 0,
              minute_startY: 0,
              minute_array: ["72_0.png","72_1.png","72_2.png","72_3.png","72_4.png","72_5.png","72_6.png","72_7.png","72_8.png","72_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 1,
              minute_align: hmUI.align.LEFT,

              second_startX: 428,
              second_startY: 252,
              second_array: ["24_0.png","24_1.png","24_2.png","24_3.png","24_4.png","24_5.png","24_6.png","24_7.png","24_8.png","24_9.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 28,
              y: 196,
              src: '24_lock.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 4,
              y: 224,
              src: '24_dnd.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 28,
              y: 252,
              src: '24_bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 428,
              y: 196,
              src: '24_al.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 216,
              y: 408,
              font_array: ["24_0.png","24_1.png","24_2.png","24_3.png","24_4.png","24_5.png","24_6.png","24_7.png","24_8.png","24_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 172,
              y: 408,
              image_array: ["24_batt_00.png","24_batt_01.png","24_batt_02.png","24_batt_03.png","24_batt_04.png","24_batt_05.png","24_batt_06.png","24_batt_07.png","24_batt_08.png","24_batt_09.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 114,
              y: 42,
              week_en: ["DAYS_Image01.png","DAYS_Image02.png","DAYS_Image03.png","DAYS_Image04.png","DAYS_Image05.png","DAYS_Image06.png","DAYS_Image07.png"],
              week_tc: ["DAYS_Image01.png","DAYS_Image02.png","DAYS_Image03.png","DAYS_Image04.png","DAYS_Image05.png","DAYS_Image06.png","DAYS_Image07.png"],
              week_sc: ["DAYS_Image01.png","DAYS_Image02.png","DAYS_Image03.png","DAYS_Image04.png","DAYS_Image05.png","DAYS_Image06.png","DAYS_Image07.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 282,
              month_startY: 42,
              month_sc_array: ["MONTH_Image01.png","MONTH_Image02.png","MONTH_Image03.png","MONTH_Image04.png","MONTH_Image05.png","MONTH_Image06.png","MONTH_Image07.png","MONTH_Image08.png","MONTH_Image09.png","MONTH_Image10.png","MONTH_Image11.png","MONTH_Image12.png"],
              month_tc_array: ["MONTH_Image01.png","MONTH_Image02.png","MONTH_Image03.png","MONTH_Image04.png","MONTH_Image05.png","MONTH_Image06.png","MONTH_Image07.png","MONTH_Image08.png","MONTH_Image09.png","MONTH_Image10.png","MONTH_Image11.png","MONTH_Image12.png"],
              month_en_array: ["MONTH_Image01.png","MONTH_Image02.png","MONTH_Image03.png","MONTH_Image04.png","MONTH_Image05.png","MONTH_Image06.png","MONTH_Image07.png","MONTH_Image08.png","MONTH_Image09.png","MONTH_Image10.png","MONTH_Image11.png","MONTH_Image12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 216,
              day_startY: 48,
              day_sc_array: ["24_0.png","24_1.png","24_2.png","24_3.png","24_4.png","24_5.png","24_6.png","24_7.png","24_8.png","24_9.png"],
              day_tc_array: ["24_0.png","24_1.png","24_2.png","24_3.png","24_4.png","24_5.png","24_6.png","24_7.png","24_8.png","24_9.png"],
              day_en_array: ["24_0.png","24_1.png","24_2.png","24_3.png","24_4.png","24_5.png","24_6.png","24_7.png","24_8.png","24_9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: '24_grid.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            //start of ignored block
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              let normal_fullAngle_second = 360;
              let normal_angle_second = 0 + normal_fullAngle_second*second/60;
              if (normal_analog_clock_pro_second_pointer_img) normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_second);

            };

            //end of ignored block
            //start of ignored block
            console.log('compass_update()');
            if (screenType == hmSetting.screen_type.WATCHFACE){
              compass = hmSensor.createSensor(hmSensor.id.COMPASS);
              compass.start();

              if (compass.direction_angle && compass.direction  && compass.direction_angle != 'INVALID') { // initial data
                // Compass Number
                let compass_direction_angle = parseInt(compass.direction_angle);
                let normal_compass_direction_angle_text = compass_direction_angle.toString().padStart(3, '0');
                normal_compass_text_img.setProperty(hmUI.prop.TEXT, normal_compass_direction_angle_text);

              } else { // error data
                normal_compass_text_img.setProperty(hmUI.prop.TEXT, '-');

              }

              compass.addEventListener(hmSensor.event.CHANGE, function (compass_res) { // change values when changing direction

                if (compass_res.calibration_status) {
                  // Compass Number
                  let compass_direction_angle = parseInt(compass_res.direction_angle);
                  let normal_compass_direction_angle_text = compass_direction_angle.toString().padStart(3, '0');
                  normal_compass_text_img.setProperty(hmUI.prop.TEXT, normal_compass_direction_angle_text);

                } else { // error data
                  normal_compass_text_img.setProperty(hmUI.prop.TEXT, '-');

                }

              }); // Listener end

            };
            //end of ignored block

            function scale_call() {
              console.log('scale_call()');

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_ls_normal_step = progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_linear_scale
                  // initial parameters
                  let start_x_normal_step = 240;
                  let start_y_normal_step = 174;
                  let lenght_ls_normal_step = 231;
                  let line_width_ls_normal_step = 5;
                  let color_ls_normal_step = 0xFFF7AA00;
                  
                  // calculated parameters
                  let start_x_normal_step_draw = start_x_normal_step;
                  let start_y_normal_step_draw = start_y_normal_step;
                  lenght_ls_normal_step = lenght_ls_normal_step * progress_ls_normal_step;
                  let lenght_ls_normal_step_draw = lenght_ls_normal_step;
                  let line_width_ls_normal_step_draw = line_width_ls_normal_step;
                  if (lenght_ls_normal_step < 0){
                    lenght_ls_normal_step_draw = -lenght_ls_normal_step;
                    start_x_normal_step_draw = start_x_normal_step - lenght_ls_normal_step_draw;
                  };
                  
                  normal_step_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_step_draw,
                    y: start_y_normal_step_draw,
                    w: lenght_ls_normal_step_draw,
                    h: line_width_ls_normal_step_draw,
                    color: color_ls_normal_step,
                  });
                  
                  // normal_step_linear_scale_mirror
                  // initial parameters
                  let start_x_normal_step_mirror = 240;
                  let start_y_normal_step_mirror = 174;
                  let lenght_ls_normal_step_mirror = -231;
                  let line_width_ls_normal_step_mirror =5;
                  let color_ls_normal_step_mirror = 0xFFF7AA00;
                  
                  // calculated parameters
                  let start_x_normal_step_draw_mirror = start_x_normal_step_mirror;
                  let start_y_normal_step_draw_mirror = start_y_normal_step_mirror;
                  lenght_ls_normal_step_mirror = lenght_ls_normal_step_mirror * progress_ls_normal_step;
                  let lenght_ls_normal_step_draw_mirror = lenght_ls_normal_step_mirror;
                  let line_width_ls_normal_step_draw_mirror = line_width_ls_normal_step_mirror;
                  if (lenght_ls_normal_step_mirror < 0){
                    lenght_ls_normal_step_draw_mirror = -lenght_ls_normal_step_mirror;
                    start_x_normal_step_draw_mirror = start_x_normal_step - lenght_ls_normal_step_draw_mirror;
                  };
                  
                  normal_step_linear_scale_mirror.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_step_draw_mirror,
                    y: start_y_normal_step_draw_mirror,
                    w: lenght_ls_normal_step_draw_mirror,
                    h: line_width_ls_normal_step_draw_mirror,
                    color: color_ls_normal_step,
                  });
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                time_update(true, true);
                if (compass && screenType == hmSetting.screen_type.WATCHFACE) compass.start();
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSec) {
                    let animDelay = timeSensor.utc % 1000;
                    let animRepeat = 1000;
                    normal_timerUpdateSec = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, false);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (compass) compass.stop();
                if (normal_timerUpdateSec) {
                  timer.stopTimer(normal_timerUpdateSec);
                  normal_timerUpdateSec = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
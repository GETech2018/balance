﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_year = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_font = ''
        let normal_digital_clock_img_time = ''
        let normal_battery_image_progress_img_level = ''
        let normal_battery_current_text_font = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_year = ''
        let idle_date_img_date_month = ''
        let idle_date_img_date_day = ''
        let idle_digital_clock_img_time = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'FRE144.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 92,
              y: 326,
              week_en: ["SEM01.png","SEM02.png","SEM03.png","SEM04.png","SEM05.png","SEM06.png","SEM07.png"],
              week_tc: ["SEM01.png","SEM02.png","SEM03.png","SEM04.png","SEM05.png","SEM06.png","SEM07.png"],
              week_sc: ["SEM01.png","SEM02.png","SEM03.png","SEM04.png","SEM05.png","SEM06.png","SEM07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 280,
              year_startY: 400,
              year_sc_array: ["Time_s_00.png","Time_s_01.png","Time_s_02.png","Time_s_03.png","Time_s_04.png","Time_s_05.png","Time_s_06.png","Time_s_07.png","Time_s_08.png","Time_s_09.png"],
              year_tc_array: ["Time_s_00.png","Time_s_01.png","Time_s_02.png","Time_s_03.png","Time_s_04.png","Time_s_05.png","Time_s_06.png","Time_s_07.png","Time_s_08.png","Time_s_09.png"],
              year_en_array: ["Time_s_00.png","Time_s_01.png","Time_s_02.png","Time_s_03.png","Time_s_04.png","Time_s_05.png","Time_s_06.png","Time_s_07.png","Time_s_08.png","Time_s_09.png"],
              year_zero: 0,
              year_space: 0,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 217,
              month_startY: 401,
              month_sc_array: ["Time_s_00.png","Time_s_01.png","Time_s_02.png","Time_s_03.png","Time_s_04.png","Time_s_05.png","Time_s_06.png","Time_s_07.png","Time_s_08.png","Time_s_09.png"],
              month_tc_array: ["Time_s_00.png","Time_s_01.png","Time_s_02.png","Time_s_03.png","Time_s_04.png","Time_s_05.png","Time_s_06.png","Time_s_07.png","Time_s_08.png","Time_s_09.png"],
              month_en_array: ["Time_s_00.png","Time_s_01.png","Time_s_02.png","Time_s_03.png","Time_s_04.png","Time_s_05.png","Time_s_06.png","Time_s_07.png","Time_s_08.png","Time_s_09.png"],
              month_zero: 1,
              month_space: 0,
              month_unit_sc: 'Time_s_10.png',
              month_unit_tc: 'Time_s_10.png',
              month_unit_en: 'Time_s_10.png',
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 156,
              day_startY: 401,
              day_sc_array: ["Time_s_00.png","Time_s_01.png","Time_s_02.png","Time_s_03.png","Time_s_04.png","Time_s_05.png","Time_s_06.png","Time_s_07.png","Time_s_08.png","Time_s_09.png"],
              day_tc_array: ["Time_s_00.png","Time_s_01.png","Time_s_02.png","Time_s_03.png","Time_s_04.png","Time_s_05.png","Time_s_06.png","Time_s_07.png","Time_s_08.png","Time_s_09.png"],
              day_en_array: ["Time_s_00.png","Time_s_01.png","Time_s_02.png","Time_s_03.png","Time_s_04.png","Time_s_05.png","Time_s_06.png","Time_s_07.png","Time_s_08.png","Time_s_09.png"],
              day_zero: 1,
              day_space: 0,
              day_unit_sc: 'Time_s_10.png',
              day_unit_tc: 'Time_s_10.png',
              day_unit_en: 'Time_s_10.png',
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 80,
              y: 71,
              image_array: ["W01.png","W015.png","W02.png","W03.png","W04.png","W05.png","W06.png","W07.png","W08.png","W09.png","W10.png","W11.png","W12.png","W13.png","W14.png","W16.png","W17.png","W18.png","W19.png","W20.png","W21.png","W22.png","W23.png","W24.png","W25.png","W26.png","W27.png","W28.png","W29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 282,
              y: 100,
              w: 150,
              h: 30,
              text_size: 35,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 66,
              hour_startY: 160,
              hour_array: ["H-00.png","H-01.png","H-02.png","H-03.png","H-04.png","H-05.png","H-06.png","H-07.png","H-08.png","H-09.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 241,
              minute_startY: 159,
              minute_array: ["G-00.png","G-01.png","G-02.png","G-03.png","G-04.png","G-05.png","G-06.png","G-07.png","G-08.png","G-09.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 179,
              y: 32,
              image_array: ["E01.png","E02.png","E03.png","E04.png","E05.png","E06.png","E07.png","E08.png","E09.png","E10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 170,
              y: 85,
              w: 150,
              h: 30,
              text_size: 23,
              char_space: 0,
              line_space: 0,
              color: 0xFFFF8C00,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 92,
              y: 326,
              week_en: ["SEM01.png","SEM02.png","SEM03.png","SEM04.png","SEM05.png","SEM06.png","SEM07.png"],
              week_tc: ["SEM01.png","SEM02.png","SEM03.png","SEM04.png","SEM05.png","SEM06.png","SEM07.png"],
              week_sc: ["SEM01.png","SEM02.png","SEM03.png","SEM04.png","SEM05.png","SEM06.png","SEM07.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 280,
              year_startY: 400,
              year_sc_array: ["Time_s_00.png","Time_s_01.png","Time_s_02.png","Time_s_03.png","Time_s_04.png","Time_s_05.png","Time_s_06.png","Time_s_07.png","Time_s_08.png","Time_s_09.png"],
              year_tc_array: ["Time_s_00.png","Time_s_01.png","Time_s_02.png","Time_s_03.png","Time_s_04.png","Time_s_05.png","Time_s_06.png","Time_s_07.png","Time_s_08.png","Time_s_09.png"],
              year_en_array: ["Time_s_00.png","Time_s_01.png","Time_s_02.png","Time_s_03.png","Time_s_04.png","Time_s_05.png","Time_s_06.png","Time_s_07.png","Time_s_08.png","Time_s_09.png"],
              year_zero: 0,
              year_space: 0,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 217,
              month_startY: 401,
              month_sc_array: ["Time_s_00.png","Time_s_01.png","Time_s_02.png","Time_s_03.png","Time_s_04.png","Time_s_05.png","Time_s_06.png","Time_s_07.png","Time_s_08.png","Time_s_09.png"],
              month_tc_array: ["Time_s_00.png","Time_s_01.png","Time_s_02.png","Time_s_03.png","Time_s_04.png","Time_s_05.png","Time_s_06.png","Time_s_07.png","Time_s_08.png","Time_s_09.png"],
              month_en_array: ["Time_s_00.png","Time_s_01.png","Time_s_02.png","Time_s_03.png","Time_s_04.png","Time_s_05.png","Time_s_06.png","Time_s_07.png","Time_s_08.png","Time_s_09.png"],
              month_zero: 1,
              month_space: 0,
              month_unit_sc: 'Time_s_10.png',
              month_unit_tc: 'Time_s_10.png',
              month_unit_en: 'Time_s_10.png',
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 156,
              day_startY: 401,
              day_sc_array: ["Time_s_00.png","Time_s_01.png","Time_s_02.png","Time_s_03.png","Time_s_04.png","Time_s_05.png","Time_s_06.png","Time_s_07.png","Time_s_08.png","Time_s_09.png"],
              day_tc_array: ["Time_s_00.png","Time_s_01.png","Time_s_02.png","Time_s_03.png","Time_s_04.png","Time_s_05.png","Time_s_06.png","Time_s_07.png","Time_s_08.png","Time_s_09.png"],
              day_en_array: ["Time_s_00.png","Time_s_01.png","Time_s_02.png","Time_s_03.png","Time_s_04.png","Time_s_05.png","Time_s_06.png","Time_s_07.png","Time_s_08.png","Time_s_09.png"],
              day_zero: 1,
              day_space: 0,
              day_unit_sc: 'Time_s_10.png',
              day_unit_tc: 'Time_s_10.png',
              day_unit_en: 'Time_s_10.png',
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 66,
              hour_startY: 160,
              hour_array: ["H-00.png","H-01.png","H-02.png","H-03.png","H-04.png","H-05.png","H-06.png","H-07.png","H-08.png","H-09.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 241,
              minute_startY: 159,
              minute_array: ["G-00.png","G-01.png","G-02.png","G-03.png","G-04.png","G-05.png","G-06.png","G-07.png","G-08.png","G-09.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
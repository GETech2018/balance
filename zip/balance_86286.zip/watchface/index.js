﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_heart_rate_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_date_img_date_year = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_digital_clock_minute_separator_img = ''
        let idle_background_bg_img = ''
        let idle_battery_image_progress_img_level = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''
        let normal_cal_jumpable_img_click = ''
        let normal_battery_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'mainBG.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 0,
              y: 0,
              src: 'BTOFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 27,
              y: 225,
              font_array: ["digit_01.png","digit_02.png","digit_03.png","digit_04.png","digit_05.png","digit_06.png","digit_07.png","digit_08.png","digit_09.png","digit_10.png"],
              padding: false,
              h_space: -2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 30,
              y: 250,
              image_array: ["power_1.png","power_2.png","power_3.png","power_4.png","power_5.png","power_6.png","power_7.png","power_8.png","power_9.png","power_10.png","power_11.png","power_12.png","power_13.png","power_14.png","power_15.png","power_16.png","power_17.png","power_18.png","power_19.png","power_20.png","power_21.png"],
              image_length: 21,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 184,
              y: 434,
              font_array: ["heart_1.png","heart_2.png","heart_3.png","heart_4.png","heart_5.png","heart_6.png","heart_7.png","heart_8.png","heart_9.png","heart_10.png"],
              padding: false,
              h_space: -1,
              unit_sc: 'bpmicon.png',
              unit_tc: 'bpmicon.png',
              unit_en: 'bpmicon.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 170,
              y: 395,
              font_array: ["digit_01.png","digit_02.png","digit_03.png","digit_04.png","digit_05.png","digit_06.png","digit_07.png","digit_08.png","digit_09.png","digit_10.png"],
              padding: false,
              h_space: -2,
              unit_sc: 'stepicon.png',
              unit_tc: 'stepicon.png',
              unit_en: 'stepicon.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 390,
              y: 180,
              image_array: ["moon_1.png","moon_2.png","moon_3.png","moon_4.png","moon_5.png","moon_6.png","moon_7.png","moon_8.png","moon_9.png","moon_10.png","moon_11.png","moon_12.png","moon_13.png","moon_14.png","moon_15.png","moon_16.png","moon_17.png","moon_18.png","moon_19.png","moon_20.png","moon_21.png","moon_22.png","moon_23.png","moon_24.png","moon_25.png","moon_26.png","moon_27.png","moon_28.png","moon_29.png","moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 390,
              y: 120,
              image_array: ["Weather_big_icon_01.png","Weather_big_icon_02.png","Weather_big_icon_03.png","Weather_big_icon_04.png","Weather_big_icon_05.png","Weather_big_icon_06.png","Weather_big_icon_07.png","Weather_big_icon_08.png","Weather_big_icon_09.png","Weather_big_icon_10.png","Weather_big_icon_11.png","Weather_big_icon_12.png","Weather_big_icon_13.png","Weather_big_icon_14.png","Weather_big_icon_15.png","Weather_big_icon_16.png","Weather_big_icon_17.png","Weather_big_icon_18.png","Weather_big_icon_19.png","Weather_big_icon_20.png","Weather_big_icon_21.png","Weather_big_icon_22.png","Weather_big_icon_23.png","Weather_big_icon_24.png","Weather_big_icon_25.png","Weather_big_icon_26.png","Weather_big_icon_27.png","Weather_big_icon_28.png","Weather_big_icon_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 325,
              y: 80,
              font_array: ["digit_01.png","digit_02.png","digit_03.png","digit_04.png","digit_05.png","digit_06.png","digit_07.png","digit_08.png","digit_09.png","digit_10.png"],
              padding: false,
              h_space: -3,
              unit_sc: 'deg.png',
              unit_tc: 'deg.png',
              unit_en: 'deg.png',
              imperial_unit_sc: 'faren.png',
              imperial_unit_tc: 'faren.png',
              imperial_unit_en: 'faren.png',
              negative_image: 'minus.png',
              invalid_image: 'error.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const temperatureUnit = hmSetting.getTemperatureUnit();
            //start of ignored block
            if (temperatureUnit == 1) {
              normal_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
                x: 325,
                y: 80,
                font_array: ["digit_01.png","digit_02.png","digit_03.png","digit_04.png","digit_05.png","digit_06.png","digit_07.png","digit_08.png","digit_09.png","digit_10.png"],
                padding: false,
                h_space: -3,
                unit_sc: 'faren.png',
                unit_tc: 'faren.png',
                unit_en: 'faren.png',
                imperial_unit_sc: 'deg.png',
                imperial_unit_tc: 'deg.png',
                imperial_unit_en: 'deg.png',
                negative_image: 'minus.png',
                invalid_image: 'error.png',
                align_h: hmUI.align.CENTER_H,
                type: hmUI.data_type.WEATHER_CURRENT,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
            };
            //end of ignored block

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 176,
              year_startY: 70,
              year_sc_array: ["digit_01.png","digit_02.png","digit_03.png","digit_04.png","digit_05.png","digit_06.png","digit_07.png","digit_08.png","digit_09.png","digit_10.png"],
              year_tc_array: ["digit_01.png","digit_02.png","digit_03.png","digit_04.png","digit_05.png","digit_06.png","digit_07.png","digit_08.png","digit_09.png","digit_10.png"],
              year_en_array: ["digit_01.png","digit_02.png","digit_03.png","digit_04.png","digit_05.png","digit_06.png","digit_07.png","digit_08.png","digit_09.png","digit_10.png"],
              year_zero: 0,
              year_space: -3,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 130,
              month_startY: 70,
              month_sc_array: ["digit_01.png","digit_02.png","digit_03.png","digit_04.png","digit_05.png","digit_06.png","digit_07.png","digit_08.png","digit_09.png","digit_10.png"],
              month_tc_array: ["digit_01.png","digit_02.png","digit_03.png","digit_04.png","digit_05.png","digit_06.png","digit_07.png","digit_08.png","digit_09.png","digit_10.png"],
              month_en_array: ["digit_01.png","digit_02.png","digit_03.png","digit_04.png","digit_05.png","digit_06.png","digit_07.png","digit_08.png","digit_09.png","digit_10.png"],
              month_zero: 1,
              month_space: -3,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 85,
              day_startY: 70,
              day_sc_array: ["digit_01.png","digit_02.png","digit_03.png","digit_04.png","digit_05.png","digit_06.png","digit_07.png","digit_08.png","digit_09.png","digit_10.png"],
              day_tc_array: ["digit_01.png","digit_02.png","digit_03.png","digit_04.png","digit_05.png","digit_06.png","digit_07.png","digit_08.png","digit_09.png","digit_10.png"],
              day_en_array: ["digit_01.png","digit_02.png","digit_03.png","digit_04.png","digit_05.png","digit_06.png","digit_07.png","digit_08.png","digit_09.png","digit_10.png"],
              day_zero: 1,
              day_space: -3,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 159,
              hour_startY: 28,
              hour_array: ["time_1.png","time_2.png","time_3.png","time_4.png","time_5.png","time_6.png","time_7.png","time_8.png","time_9.png","time_10.png"],
              hour_zero: 1,
              hour_space: -4,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 218,
              minute_startY: 28,
              minute_array: ["time_1.png","time_2.png","time_3.png","time_4.png","time_5.png","time_6.png","time_7.png","time_8.png","time_9.png","time_10.png"],
              minute_zero: 1,
              minute_space: -4,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 276,
              second_startY: 28,
              second_array: ["time_1.png","time_2.png","time_3.png","time_4.png","time_5.png","time_6.png","time_7.png","time_8.png","time_9.png","time_10.png"],
              second_zero: 1,
              second_space: -4,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 206,
              y: 25,
              src: 'timeicon.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_minute_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 263,
              y: 25,
              src: 'timeicon.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'AODmain.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 210,
              y: 335,
              image_array: ["powerAOD_1.png","powerAOD_2.png","powerAOD_3.png","powerAOD_4.png","powerAOD_5.png","powerAOD_6.png","powerAOD_7.png","powerAOD_8.png","powerAOD_9.png","powerAOD_10.png","powerAOD_11.png","powerAOD_12.png","powerAOD_13.png","powerAOD_14.png","powerAOD_15.png","powerAOD_16.png","powerAOD_17.png","powerAOD_18.png","powerAOD_19.png","powerAOD_20.png","powerAOD_21.png"],
              image_length: 21,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 185,
              hour_startY: 75,
              hour_array: ["timeAOD_1.png","timeAOD_2.png","timeAOD_3.png","timeAOD_4.png","timeAOD_5.png","timeAOD_6.png","timeAOD_7.png","timeAOD_8.png","timeAOD_9.png","timeAOD_10.png"],
              hour_zero: 1,
              hour_space: -4,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 250,
              minute_startY: 75,
              minute_array: ["timeAOD_1.png","timeAOD_2.png","timeAOD_3.png","timeAOD_4.png","timeAOD_5.png","timeAOD_6.png","timeAOD_7.png","timeAOD_8.png","timeAOD_9.png","timeAOD_10.png"],
              minute_zero: 1,
              minute_space: -4,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 235,
              y: 70,
              src: 'timeiconAOD.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_cal_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 200,
              y: 397,
              w: 100,
              h: 55,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 35,
              y: 244,
              w: 50,
              h: 50,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 360,
              y: 115,
              w: 70,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'WeatherScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 110,
              y: 57,
              w: 70,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
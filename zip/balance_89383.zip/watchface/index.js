﻿	//*******************************//
	//*		Double Time				*//
	//*		2024 © leXxiR 4pda		*//
	//*								*//
	//*Edited by Wong Kam Fei - 24hr*//
	//*******************************//

	 
   
    try {
    (() => {

        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;

        const { width: DEVICE_WIDTH, height: DEVICE_HEIGHT } = hmSetting.getDeviceInfo();
		const radius = DEVICE_WIDTH / 2, centerX = DEVICE_WIDTH / 2, centerY = DEVICE_WIDTH / 2
		const koeff = DEVICE_WIDTH / 466;		// scaling factor
		let isAOD = hmSetting.getScreenType() == hmSetting.screen_type.AOD;

		const curTime = hmSensor.createSensor(hmSensor.id.TIME);
		const worldClock = hmSensor.createSensor(hmSensor.id.WORLD_CLOCK);

		let Local24TimeText, secsText, World24TimeText, WorldCityName, WorldDateText
		let clockIndex = -1
		let reInitClock = isAOD ? false : true
		const clockSize = 120
		const secSize = 45
		
        // Set mainColor based on AOD mode
		const mainColor = isAOD ? 0xFFA9A9A9 : 0xFFFFFFFF;
		let secTimer = null

        let normal_system_disconnect_img = ''
        let normal_battery_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''

       //vibrate (add destroy at end)
        const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE)
        function click_Vibrate() {
           vibrate.stop()
           vibrate.scene = 27
           vibrate.start()
        }

		// function of scaling values ​​depending on screen size
		function sc(v) {
			return v * koeff
		}

		// *** Function to set Local Time & World Time Start ***
        function updateTime() {
			updateLocalTime();
			updateWorldTime();
        }

		// Helper function to get formatted date and weekday in specified format
		function getFormattedDateAndWeekday(date) {
			const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
			const weekdayNames = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
			let month = monthNames[date.getMonth()];
			let day = date.getDate().toString().padStart(2, '0');
			let weekday = weekdayNames[date.getDay()];
			return {
				month: month,
				day: day,
				weekday: weekday
			};
		}

        function updateLocalTime() {
			let curHour = curTime.hour.toString().padStart(2, "0");
			let curMinute = curTime.minute.toString().padStart(2, "0");
			Local24TimeText.setProperty(hmUI.prop.TEXT, curHour + ':' + curMinute);

			// Get the current date and split month and weekday for separate display
			const currentDate = new Date();
			const { month, weekday, day } = getFormattedDateAndWeekday(currentDate);

			// Set month and weekday separately for LocalDate
			LocalMonthText.setProperty(hmUI.prop.TEXT, month);           // Show only the month (e.g., "Jan")
			LocalWeekdayText.setProperty(hmUI.prop.TEXT, weekday);       // Show only the weekday (e.g., "Sun")
			LocalDayText.setProperty(hmUI.prop.TEXT, day);               // Show only the day (dd)

			if (!isAOD) updateSeconds();
        }

        function updateSeconds() {
			let curSecond = curTime.second.toString().padStart(2, "0");
			secsText.setProperty(hmUI.prop.TEXT, curSecond);
        }

		function updateWorldTime() {
			let worldHour = '--';
			let worldMinute = '--';
			let timeZoneHour = 0;
			let timeZoneMinute = 0;

			if (clockIndex > -1) {
				const worldData = worldClock.getWorldClockInfo(clockIndex);
				worldHour = worldData.hour.toString().padStart(2, '0');
				worldMinute = worldData.minute.toString().padStart(2, '0');
				timeZoneHour = parseInt(worldData.timeZoneHour);
				timeZoneMinute = parseInt(worldData.timeZoneMinute);
			}

			// Check if worldHour or worldMinute are not set (indicated by '--')
			if (worldHour === '--' || worldMinute === '--') {
				World24TimeText.setProperty(hmUI.prop.TEXT, '--:--');
				WorldDateText.setProperty(hmUI.prop.TEXT, '--');
				return; // Exit the function early
			}

			// Adjust for timezone and determine date
			let curTotalMinutes = curTime.hour * 60 + curTime.minute;
			let timeZoneOffset = timeZoneHour * 60 + timeZoneMinute;
			let totalOffset = curTotalMinutes + timeZoneOffset;

			let displayDate = new Date();
			if (totalOffset >= 24 * 60) {
				displayDate.setDate(displayDate.getDate() + 1);
			} else if (totalOffset < 0) {
				displayDate.setDate(displayDate.getDate() - 1);
			}

			// Set time text for World24TimeText
			World24TimeText.setProperty(hmUI.prop.TEXT, worldHour + ':' + worldMinute);

			// Set date text for WorldDateText
			const { month, day } = getFormattedDateAndWeekday(displayDate);
			WorldDateText.setProperty(hmUI.prop.TEXT, `${month} ${day}`);
		}


		function toggleWorldClock(step = 1) {
			const count = worldClock.getWorldClockCount();
			if (count){
				clockIndex += step;
				clockIndex = clockIndex < 0 ? count + clockIndex : clockIndex % count;
				const worldData = worldClock.getWorldClockInfo(clockIndex);
				WorldCityName.setProperty(hmUI.prop.TEXT, worldData.city);
				updateWorldTime();
				hmFS.SysProSetInt('dt_wf_clockIndex', clockIndex);
			}
        }

        function initWorldClock() {
			if (reInitClock) {
				clockIndex = -1;
				worldClock.uninit();
				hmFS.SysProSetInt('dt_wf_clockIndex', 0);
				reInitClock = false;
			}
			worldClock.init();
			let count = worldClock.getWorldClockCount();
			if (count > 0) {
				clockIndex = 0 || hmFS.SysProGetInt('dt_wf_clockIndex');
				const worldData = worldClock.getWorldClockInfo(clockIndex);
				WorldCityName.setProperty(hmUI.prop.TEXT, worldData.city);
				hmFS.SysProSetInt('dt_wf_clockIndex', clockIndex);
			} else WorldCityName.setProperty(hmUI.prop.TEXT, 'Add City');

		}

		function startSecTimer() {
			if (!secTimer) {
				setTimeout(() => {
					worldClock.init();
					secTimer = setInterval(() => {
						updateSeconds();
					}, 1000);
				}, 1000 - curTime.utc % 1000);
			}
		}

		function stopSecTimer() {
			if (secTimer) clearInterval(secTimer);
			secTimer = null;
		}


		function strokeBtn(props) {			// button with outline
			let rectProps = {
			  x: props.x,
			  y: props.y,
			  w: props.w,
			  h: props.h,
			  radius: props.radius,
			  line_width: props.line_width || 2,
			  color: props.strokeColor,
			  show_level: hmUI.show_level.ONLY_NORMAL,
			}

			let btnProps = {
			  x: props.x + 2,
			  y: props.y + 2,
			  w: props.w - 4,
			  h: props.h - 4,	
			  text: props.text || '',
			  text_size: props.text_size || 26,
			  color: props.textColor || 0xffffff,
			  radius: props.radius - 2,
			  normal_color: props.normal_color || 0x222222,
			  press_color: props.press_color || 0x454545,
			  click_func: props.click_func,
			  show_level: hmUI.show_level.ONLY_NORMAL,
			}

			let gr = props.group || hmUI;
			gr.createWidget(hmUI.widget.STROKE_RECT, rectProps);
			gr.createWidget(hmUI.widget.BUTTON, btnProps);
        }


//----------------------------

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {

			hmUI.createWidget(hmUI.widget.TEXT, {
			  x: DEVICE_WIDTH-2,
			  y: DEVICE_HEIGHT-2,
			  w: 324,
			  h: 155,
			  text_size: clockSize,
			  char_space: 0,
			  line_space: 0,
			  font: 'fonts/Carson.ttf',
			  color: 0xffffff,
			  align_h: hmUI.align.RIGHT,
			  align_v: hmUI.align.TOP,
			  text_style: hmUI.text_style.ELLIPSIS,
			  text: "0123456789 :-",
              show_level: hmUI.show_level.ONLY_NORMAL,
			});

			hmUI.createWidget(hmUI.widget.TEXT, {
			  x: DEVICE_WIDTH-2,
			  y: DEVICE_HEIGHT-2,
			  w: 324,
			  h: 41,
			  text_size: secSize,
			  char_space: 0,
			  line_space: 0,
			  font: 'fonts/Carson.ttf',
			  color: 0xffffff,
			  align_h: hmUI.align.RIGHT,
			  align_v: hmUI.align.TOP,
			  text_style: hmUI.text_style.ELLIPSIS,
			  text: "0123456789",
              show_level: hmUI.show_level.ONLY_NORMAL,
			});

            hmUI.createWidget(hmUI.widget.FILL_RECT, {  // Background color
              x: 0,
              y: 0,
              w: DEVICE_WIDTH,
              h: DEVICE_HEIGHT,
              color: 0x000000,
            });

            LocalMonthText = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 96,
              y: 21,
              w: 103,
              h: 62,
              text_size: 36,
              char_space: 0,
              line_space: 0,
			  text: '',
              color: mainColor,
              align_h: hmUI.align.RIGHT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
            });

            LocalDayText = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 0,
              y: 5,
              w: DEVICE_WIDTH,
              h: 62,
              text_size: 52,
              char_space: 0,
              line_space: 0,
			  text: '',
              color: mainColor,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
            });

            LocalWeekdayText = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 281,
              y: 21,
              w: 103,
              h: 62,
              text_size: 36,
              char_space: 0,
              line_space: 0,
			  text: '',
              color: mainColor,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
            });

            Local24TimeText = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 0,
              y: 46,
              w: DEVICE_WIDTH,
              h: 155,
              text_size: clockSize,
              char_space: 5,
              line_space: 0,
			  text: '00:00',
              font: 'fonts/Carson.ttf',
              color: mainColor,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
            });

            secsText = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 361,
              y: 72,
              w: 82,
              h: 62,
              text_size: secSize,
              char_space: 3,
              line_space: 0,
			  text: '00',
              font: 'fonts/Carson.ttf',
              color: mainColor,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            Local_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 62,
              y: centerY - 62,
              w: DEVICE_WIDTH - 124,
              h: 52,
              text_size: 37,
              char_space: 0,
              line_space: 0,
			  color: mainColor,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.NONE,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 240,
              src: 'World_Map.png',
            });

            battery_empty_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 238,
              src: 'Bat-lvl-1.png',
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 0,
              y: 238,
              image_array: ["Bat-lvl-1.png","Bat-lvl-2.png","Bat-lvl-3.png","Bat-lvl-4.png","Bat-lvl-5.png","Bat-lvl-6.png","Bat-lvl-7.png","Bat-lvl-8.png","Bat-lvl-9.png","Bat-lvl-10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 21,
              y: 136,
              src: isAOD ? 'Battery_Icon_AOD.png' : 'Battery_Icon.png',
            });

            normal_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 31,
              y: 124,
              w: 103,
              h: 62,
              text_size: secSize,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Carson.ttf',
              color: isAOD ? 0xFFE6E6E6 : mainColor,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.BATTERY,
            });
            
            normal_step_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 352,
              y: 298,
              w: 100, //164 
              h: 62,
              text_size: secSize, 
              char_space: 0,
              line_space: 0,
              font: 'fonts/Carson.ttf',
              color: isAOD ? 0xFFE6E6E6 : mainColor,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });








			strokeBtn({     // Botton to change World City
			  x: 1,
			  y: DEVICE_HEIGHT/2 - 31,
			  w: 62,
			  h: 62,
			  text: '◁',
			  text_size: 41,
			  radius: 31,
			  textColor: mainColor,
			  strokeColor: mainColor,
			  click_func: () => {
				toggleWorldClock(-1);
                click_Vibrate();
			  },
			});

			strokeBtn({     // Botton to change World City
			  x: DEVICE_WIDTH - 62,
			  y: DEVICE_HEIGHT/2 - 31,
			  w: 62,
			  h: 62,
			  text: '▷',
			  text_size: 41,
			  radius: 31,
			  textColor: mainColor,
			  strokeColor: mainColor,
			  click_func: () => {
				toggleWorldClock(1);
                click_Vibrate();
			  },
			});

            WorldCityName = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 62,
              y: centerY + 5,
              w: DEVICE_WIDTH - 124,
              h: 52,
              text_size: 37,
              char_space: 0,
              line_space: 0,
			  text: '',
              color: mainColor,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.NONE,
            });

            World24TimeText = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 0,
              y: 278,
              w: DEVICE_WIDTH,
              h: 155,
              text_size: clockSize,
              char_space: 5,
              line_space: 0,
			  text: '00:00',
              font: 'fonts/Carson.ttf',
              color: mainColor,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
            });

            WorldDateText = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 0,
              y: 412,
              w: DEVICE_WIDTH,
              h: 52,
              text_size: 37,
              char_space: 0,
              line_space: 0,
			  text: '',
              color: mainColor,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 62,
              y: 77,
              src: 'Statuses-BlueTooth.png',
              type: hmUI.system_status.DISCONNECT,
//              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 9,
              // disconneсnt_toast_text: Connection Lost,
              // conneсnt_vibrate_type: 9,
              // conneсnt_toast_text: Connection Restored,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              console.log('checkConnection()');
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  hmUI.showToast({text: "Connection Lost"});
                  vibro(9);
                }
                if(status) {
                  hmUI.showToast({text: "Connection Restored"});
                  vibro(9);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              if (scene != 1) timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function
            console.log('Watch_Face.Shortcuts');


// world clock Shortcut
			hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 62,
              y: centerY - 36,
              w: DEVICE_WIDTH - 124,
              h: 82,
			  text: '',
			  normal_src: 'blank.png',
			  press_src: 'blank.png',
			  click_func: () => {
				hmApp.startApp({ url: 'WorldClockScreen', native: true });
				reInitClock = true;
			  },
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});	

//Calendar Shortcut
           hmUI.createWidget(hmUI.widget.BUTTON, {
             x: 103,
             y: 0,
             w: 274,
             h: 77,
			 text: '',    
			 normal_src: 'shortcut.png',   
			 press_src: 'shortcut.png', 
			 click_func: () => {
				hmApp.startApp({ url: 'ScheduleCalScreen', native: true });
				},
				show_level: hmUI.show_level.ONLY_NORMAL,
			});

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 0,
              y: 77,
              w: 124,
              h: 103,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 124,
              y: 300,
              w: 274,
              h: 103,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 356,
              y: 77,
              w: 103,
              h: 103,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 103,
              y: 77,
              w: 274,
              h: 103,
              src: 'blank.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

			if(isAOD) {
				clockIndex = hmFS.SysProGetInt('dt_wf_clockIndex');
			}
			curTime.addEventListener(curTime.event.MINUTEEND, function () {
				initWorldClock();
				updateTime();
			});

		// *** Local City Start ***
            function scale_call() {

              console.log('Weather city name');
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);
              const weatherData = weatherSensor.getForecastWeather();
              Local_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

            };

		// *** Local City End ***


			const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
			  resume_call: (function () {
                scale_call();
				initWorldClock();
				updateTime();
                checkConnection();
                stopVibro();
				if (!isAOD) startSecTimer();

			  }),
			  pause_call: (function () {
				stopSecTimer();
                console.log('pause_call()');
                stopVibro();

			  }),
			})

			

            },
            onInit() {
            },
            build() {
				this.init_view();
            },
            onDestroy() {
				worldClock.uninit();
            }
        });
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
}

﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_distance_icon_img = ''
        let normal_distance_text_text_img = ''
        let normal_step_icon_img = ''
        let normal_step_current_text_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_image_img = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_month_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_month_img = ''
        let normal_step_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: '0001.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 372,
              y: 239,
              image_array: ["W01.png","W02.png","W03.png","W04.png","W05.png","W06.png","W07.png","W08.png","W09.png","W10.png","W11.png","W12.png","W13.png","W14.png","W15.png","W16.png","W17.png","W18.png","W19.png","W20.png","W21.png","W22.png","W23.png","W24.png","W25.png","W26.png","W27.png","W28.png","W29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 382,
              y: 329,
              font_array: ["CH01.png","CH02.png","CH03.png","CH04.png","CH05.png","CH06.png","CH07.png","CH08.png","CH09.png","CH10.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'CH13.png',
              unit_tc: 'CH13.png',
              unit_en: 'CH13.png',
              negative_image: 'CH15.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 32,
              y: 293,
              font_array: ["CH01.png","CH02.png","CH03.png","CH04.png","CH05.png","CH06.png","CH07.png","CH08.png","CH09.png","CH10.png"],
              padding: false,
              h_space: 0,
              angle: 9,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 324,
              y: 381,
              font_array: ["AH01.png","AH02.png","AH03.png","AH04.png","AH05.png","AH06.png","AH07.png","AH08.png","AH09.png","AH10.png"],
              padding: false,
              h_space: 0,
              angle: 48,
              unit_sc: 'AH13.png',
              unit_tc: 'AH13.png',
              unit_en: 'AH13.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 206,
              y: 392,
              image_array: ["E01.png","E02.png","E03.png","E04.png","E05.png","E06.png","E07.png","E08.png","E09.png","E10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 194,
              y: 280,
              src: 'LINES.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 209,
              y: 326,
              font_array: ["AH01.png","AH02.png","AH03.png","AH04.png","AH05.png","AH06.png","AH07.png","AH08.png","AH09.png","AH10.png"],
              padding: true,
              h_space: 0,
              unit_sc: 'AH12.png',
              unit_tc: 'AH12.png',
              unit_en: 'AH12.png',
              dot_image: 'AH11.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 91,
              y: 299,
              src: 'Rabbit02.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 210,
              y: 292,
              font_array: ["AH01.png","AH02.png","AH03.png","AH04.png","AH05.png","AH06.png","AH07.png","AH08.png","AH09.png","AH10.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 223,
              y: 9,
              src: '0002.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 104,
              y: 393,
              src: 'ALARM.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 49,
              y: 47,
              src: 'Cache.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 72,
              hour_startY: 183,
              hour_array: ["Z00.png","Z01.png","Z02.png","Z03.png","Z04.png","Z05.png","Z06.png","Z07.png","Z08.png","Z09.png"],
              hour_zero: 1,
              hour_space: -21,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 250,
              minute_startY: 183,
              minute_array: ["Z00.png","Z01.png","Z02.png","Z03.png","Z04.png","Z05.png","Z06.png","Z07.png","Z08.png","Z09.png"],
              minute_zero: 1,
              minute_space: -23,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 395,
              second_startY: 196,
              second_array: ["AH01.png","AH02.png","AH03.png","AH04.png","AH05.png","AH06.png","AH07.png","AH08.png","AH09.png","AH10.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 205,
              y: 178,
              src: 'w00.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 141,
              y: 80,
              week_en: ["SEM01.png","SEM02.png","SEM03.png","SEM04.png","SEM05.png","SEM06.png","SEM07.png"],
              week_tc: ["SEM01.png","SEM02.png","SEM03.png","SEM04.png","SEM05.png","SEM06.png","SEM07.png"],
              week_sc: ["SEM01.png","SEM02.png","SEM03.png","SEM04.png","SEM05.png","SEM06.png","SEM07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 70,
              day_startY: 132,
              day_sc_array: ["CH01.png","CH02.png","CH03.png","CH04.png","CH05.png","CH06.png","CH07.png","CH08.png","CH09.png","CH10.png"],
              day_tc_array: ["CH01.png","CH02.png","CH03.png","CH04.png","CH05.png","CH06.png","CH07.png","CH08.png","CH09.png","CH10.png"],
              day_en_array: ["CH01.png","CH02.png","CH03.png","CH04.png","CH05.png","CH06.png","CH07.png","CH08.png","CH09.png","CH10.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 63,
              month_startY: 151,
              month_sc_array: ["MOIS01.png","MOIS02.png","MOIS03.png","MOIS04.png","MOIS05.png","MOIS06.png","MOIS07.png","MOIS08.png","MOIS09.png","MOIS10.png","MOIS11.png","MOIS12.png"],
              month_tc_array: ["MOIS01.png","MOIS02.png","MOIS03.png","MOIS04.png","MOIS05.png","MOIS06.png","MOIS07.png","MOIS08.png","MOIS09.png","MOIS10.png","MOIS11.png","MOIS12.png"],
              month_en_array: ["MOIS01.png","MOIS02.png","MOIS03.png","MOIS04.png","MOIS05.png","MOIS06.png","MOIS07.png","MOIS08.png","MOIS09.png","MOIS10.png","MOIS11.png","MOIS12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 256,
              y: 271,
              src: '0002.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 183,
              y: 277,
              src: 'ALARM.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 72,
              hour_startY: 183,
              hour_array: ["Z00.png","Z01.png","Z02.png","Z03.png","Z04.png","Z05.png","Z06.png","Z07.png","Z08.png","Z09.png"],
              hour_zero: 1,
              hour_space: -21,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 250,
              minute_startY: 183,
              minute_array: ["Z00.png","Z01.png","Z02.png","Z03.png","Z04.png","Z05.png","Z06.png","Z07.png","Z08.png","Z09.png"],
              minute_zero: 1,
              minute_space: -23,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 395,
              second_startY: 196,
              second_array: ["CH01.png","CH02.png","CH03.png","CH04.png","CH05.png","CH06.png","CH07.png","CH08.png","CH09.png","CH10.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 205,
              y: 178,
              src: 'w00.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 147,
              y: 68,
              week_en: ["SEM01.png","SEM02.png","SEM03.png","SEM04.png","SEM05.png","SEM06.png","SEM07.png"],
              week_tc: ["SEM01.png","SEM02.png","SEM03.png","SEM04.png","SEM05.png","SEM06.png","SEM07.png"],
              week_sc: ["SEM01.png","SEM02.png","SEM03.png","SEM04.png","SEM05.png","SEM06.png","SEM07.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 215,
              day_startY: 121,
              day_sc_array: ["CH01.png","CH02.png","CH03.png","CH04.png","CH05.png","CH06.png","CH07.png","CH08.png","CH09.png","CH10.png"],
              day_tc_array: ["CH01.png","CH02.png","CH03.png","CH04.png","CH05.png","CH06.png","CH07.png","CH08.png","CH09.png","CH10.png"],
              day_en_array: ["CH01.png","CH02.png","CH03.png","CH04.png","CH05.png","CH06.png","CH07.png","CH08.png","CH09.png","CH10.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 202,
              month_startY: 149,
              month_sc_array: ["MOIS01.png","MOIS02.png","MOIS03.png","MOIS04.png","MOIS05.png","MOIS06.png","MOIS07.png","MOIS08.png","MOIS09.png","MOIS10.png","MOIS11.png","MOIS12.png"],
              month_tc_array: ["MOIS01.png","MOIS02.png","MOIS03.png","MOIS04.png","MOIS05.png","MOIS06.png","MOIS07.png","MOIS08.png","MOIS09.png","MOIS10.png","MOIS11.png","MOIS12.png"],
              month_en_array: ["MOIS01.png","MOIS02.png","MOIS03.png","MOIS04.png","MOIS05.png","MOIS06.png","MOIS07.png","MOIS08.png","MOIS09.png","MOIS10.png","MOIS11.png","MOIS12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 9,
              // disconneсnt_toast_text: BT OFF,
              // conneсnt_vibrate_type: 9,
              // conneсnt_toast_text: BT ON,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              console.log('checkConnection()');
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  hmUI.showToast({text: "BT OFF"});
                  vibro(9);
                }
                if(status) {
                  hmUI.showToast({text: "BT ON"});
                  vibro(9);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              if (scene != 1) timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 152,
              y: 265,
              w: 100,
              h: 100,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 96,
              y: 381,
              w: 50,
              h: 50,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                checkConnection();
                stopVibro();

              }),
              pause_call: (function () {
                console.log('pause_call()');
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js
		// user_script_end START
		let cc = 0
		// user_script_end END
		
		// Menu START
		let menunumber = 1
        let total_menu = 2

        function click_MENU() {
            if(menunumber==total_menu) {
            menunumber=1;
                UpdatemenuOne();
                }
            else {
                menunumber=menunumber+1;
                if(menunumber==2) {
                  UpdatemenuTwo();
                }
            }
        }

        function UpdatemenuOne(){
				normal_stress_icon_img.setProperty(hmUI.prop.VISIBLE, false);
				Button_2.setProperty(hmUI.prop.VISIBLE, false);
				Button_3.setProperty(hmUI.prop.VISIBLE, false);
				
				Button_4.setProperty(hmUI.prop.VISIBLE, true);
				Button_5.setProperty(hmUI.prop.VISIBLE, true);
				Button_6.setProperty(hmUI.prop.VISIBLE, true);
				Button_7.setProperty(hmUI.prop.VISIBLE, true);
				
				Button_8.setProperty(hmUI.prop.VISIBLE, true);
				normal_step_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
				normal_heart_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
				normal_battery_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
				normal_sunrise_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
				normal_moon_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
				normal_temperature_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
				normal_altimeter_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
				normal_countdown_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
				normal_stopwatch_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
				normal_altitude_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
				normal_readiness_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
        }

        function UpdatemenuTwo(){
				normal_stress_icon_img.setProperty(hmUI.prop.VISIBLE, true);
				Button_2.setProperty(hmUI.prop.VISIBLE, true);
				Button_3.setProperty(hmUI.prop.VISIBLE, true);
				
				Button_4.setProperty(hmUI.prop.VISIBLE, false);
				Button_5.setProperty(hmUI.prop.VISIBLE, false);
				Button_6.setProperty(hmUI.prop.VISIBLE, false);
				Button_7.setProperty(hmUI.prop.VISIBLE, false);
				
				Button_8.setProperty(hmUI.prop.VISIBLE, false);
				normal_step_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
				normal_heart_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
				normal_battery_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
				normal_sunrise_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
				normal_moon_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
				normal_temperature_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
				normal_altimeter_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
				normal_countdown_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
				normal_stopwatch_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
				normal_altitude_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
				normal_readiness_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        }
		// Menu END
		
		// Hands START
		let handsnumber = 1
        let total_hands = 4

        function click_HANDS() {
            if(handsnumber==total_hands) {
            handsnumber=1;
                UpdatehandsOne();
                }
            else {
                handsnumber=handsnumber+1;
                if(handsnumber==2) {
                  UpdatehandsTwo();
                }
				if(handsnumber==3) {
                  UpdatehandsThree();
                }
				if(handsnumber==4) {
                  UpdatehandsFour();
                }
            }
            if(handsnumber==1) hmUI.showToast({text: 'NORMAL SEC'});
            if(handsnumber==2) hmUI.showToast({text: 'SMOOTH SEC'});
			if(handsnumber==3) hmUI.showToast({text: 'NO SECOND'});
			if(handsnumber==4) hmUI.showToast({text: 'NO HANDS'});
        }

        function UpdatehandsOne(){
				normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.VISIBLE, true);
				normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.VISIBLE, true);
                normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, true);
                normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_fat_burning_icon_img.setProperty(hmUI.prop.VISIBLE, true);
				normal_spo2_icon_img.setProperty(hmUI.prop.VISIBLE, false);
        }

        function UpdatehandsTwo(){
				normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.VISIBLE, true);
				normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.VISIBLE, true);
				normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, false);
                normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.VISIBLE, true);
				normal_fat_burning_icon_img.setProperty(hmUI.prop.VISIBLE, true);
				normal_spo2_icon_img.setProperty(hmUI.prop.VISIBLE, false);
        }
		
        function UpdatehandsThree(){
				normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.VISIBLE, true);
				normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.VISIBLE, true);
				normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, false);
                normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_fat_burning_icon_img.setProperty(hmUI.prop.VISIBLE, true);
				normal_spo2_icon_img.setProperty(hmUI.prop.VISIBLE, false);
        }
		
        function UpdatehandsFour(){
				normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.VISIBLE, false);
				normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.VISIBLE, false);
				normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, false);
                normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_fat_burning_icon_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_spo2_icon_img.setProperty(hmUI.prop.VISIBLE, true);
        }
		// Hands END
		
		// Color START	
		let colornumber_main = 1
        let totalcolors_main = 15
		let colorstring = '0xFFFF8000'
	
		function click_COLOR() {
            if(colornumber_main>=totalcolors_main) {
            colornumber_main=1;
            }
            else {
                colornumber_main=colornumber_main+1;
            }
			if ( colornumber_main == 1) {colorstring = '0xFFFF8000'}
			if ( colornumber_main == 2) {colorstring = '0xFF008080'}
			if ( colornumber_main == 3) {colorstring = '0xFF808000'}
			if ( colornumber_main == 4) {colorstring = '0xFF800000'}
			if ( colornumber_main == 5) {colorstring = '0xFF00FFFF'}
			if ( colornumber_main == 6) {colorstring = '0xFF008000'}
			if ( colornumber_main == 7) {colorstring = '0xFFFF0000'}
			if ( colornumber_main == 8) {colorstring = '0xFFFFFF00'}
			if ( colornumber_main == 9) {colorstring = '0xFFBFFF00'}
			if ( colornumber_main == 10) {colorstring = '0xFFA020F0'}
			if ( colornumber_main == 11) {colorstring = '0xFF0000FF'}
			if ( colornumber_main == 12) {colorstring = '0xFFFF00FF'}
			if ( colornumber_main == 13) {colorstring = '0xFFA5694F'}
			if ( colornumber_main == 14) {colorstring = '0xFFFFBF00'}
			if ( colornumber_main == 15) {colorstring = '0xFFFFFFFF'}
			if ( colornumber_main <= 15) { 
			
             normal_background_bg.setProperty(hmUI.prop.MORE, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: colorstring,
              show_level: hmUI.show_level.ONLY_NORMAL,
             });
			 
			 normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.MORE, {
              second_path: "hand_sec" + parseInt(colornumber_main) + ".png",
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 240,
              second_posY: 240,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.SRC, "hand_sec" + parseInt(colornumber_main) + ".png");
			} 
			
		}
		// Color END
		
		// Element_1 (Weather) START
		let elementnumber_1 = 1
        let total_elemente_1 = 2

        function click_Element_1() {
            if(elementnumber_1==total_elemente_1) {
            elementnumber_1=1;
                UpdateElemente_1Show();
                }
            else {
                elementnumber_1=elementnumber_1+1;
                if(elementnumber_1==2) {
                  UpdateElemente_1Hide();
                }
            }
        }

        function UpdateElemente_1Show(){
				normal_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, true);
                normal_city_name_text.setProperty(hmUI.prop.VISIBLE, true);
				normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);
				normal_temperature_current_text_font.setProperty(hmUI.prop.VISIBLE, true);
        }

        function UpdateElemente_1Hide(){
				normal_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_city_name_text.setProperty(hmUI.prop.VISIBLE, false);
				normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
				normal_temperature_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
        }
		// Element_1 (Weather) END
		
		// Element_2 (Activity) START
		let elementnumber_2 = 1
        let total_elemente_2 = 2

        function click_Element_2() {
            if(elementnumber_2==total_elemente_2) {
            elementnumber_2=1;
                UpdateElemente_2Show();
                }
            else {
                elementnumber_2=elementnumber_2+1;
                if(elementnumber_2==2) {
                  UpdateElemente_2Hide();
                }
            }
        }

        function UpdateElemente_2Show(){
				normal_distance_icon_img.setProperty(hmUI.prop.VISIBLE, true);
                normal_distance_current_text_font.setProperty(hmUI.prop.VISIBLE, true);
				normal_step_current_text_font.setProperty(hmUI.prop.VISIBLE, true);
				normal_calorie_current_text_font.setProperty(hmUI.prop.VISIBLE, true);
				normal_heart_rate_text_font.setProperty(hmUI.prop.VISIBLE, true);
        }

        function UpdateElemente_2Hide(){
				normal_distance_icon_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_distance_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
				normal_step_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
				normal_calorie_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
				normal_heart_rate_text_font.setProperty(hmUI.prop.VISIBLE, false);
        }
		// Element_2 (Activity) END
		
		// Element_3 (Altimeter) START
		let elementnumber_3 = 1
        let total_elemente_3 = 2

        function click_Element_3() {
            if(elementnumber_3==total_elemente_3) {
            elementnumber_3=1;
                UpdateElemente_3Show();
                }
            else {
                elementnumber_3=elementnumber_3+1;
                if(elementnumber_3==2) {
                  UpdateElemente_3Hide();
                }
            }
        }

        function UpdateElemente_3Show(){
				normal_wind_icon_img.setProperty(hmUI.prop.VISIBLE, true);
                normal_wind_current_text_font.setProperty(hmUI.prop.VISIBLE, true);
				normal_humidity_current_text_font.setProperty(hmUI.prop.VISIBLE, true);
				normal_altitude_target_text_font.setProperty(hmUI.prop.VISIBLE, true);
				normal_altimeter_current_text_font.setProperty(hmUI.prop.VISIBLE, true);
        }

        function UpdateElemente_3Hide(){
				normal_wind_icon_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_wind_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
				normal_humidity_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
				normal_altitude_target_text_font.setProperty(hmUI.prop.VISIBLE, false);
				normal_altimeter_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
        }
		// Element_3 (Altimeter) END
		
		// Element_4 (Sun & Moon) START
		let elementnumber_4 = 1
        let total_elemente_4 = 2

        function click_Element_4() {
            if(elementnumber_4==total_elemente_4) {
            elementnumber_4=1;
                UpdateElemente_4Show();
                }
            else {
                elementnumber_4=elementnumber_4+1;
                if(elementnumber_4==2) {
                  UpdateElemente_4Hide();
                }
            }
        }

        function UpdateElemente_4Show(){
				normal_moon_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);
				normal_sun_icon_img.setProperty(hmUI.prop.VISIBLE, true);
                normal_sun_high_text_font.setProperty(hmUI.prop.VISIBLE, true);
				normal_sun_low_text_font.setProperty(hmUI.prop.VISIBLE, true);
        }

        function UpdateElemente_4Hide(){
				normal_moon_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
				normal_sun_icon_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_sun_high_text_font.setProperty(hmUI.prop.VISIBLE, false);
				normal_sun_low_text_font.setProperty(hmUI.prop.VISIBLE, false);
        }
		// Element_4 (Sun & Moon) END
		
        // end user_functions.js

        let normal_background_bg = ''
        let normal_battery_linear_scale = ''
        let normal_battery_icon_img = ''
        let normal_temperature_icon_img = ''
        let normal_city_name_text = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_font = ''
        let normal_moon_image_progress_img_level = ''
        let normal_sun_icon_img = ''
        let normal_sun_high_text_font = ''
        let normal_sun_low_text_font = ''
        let normal_wind_icon_img = ''
        let normal_wind_current_text_font = ''
        let normal_humidity_current_text_font = ''
        let normal_altitude_target_text_font = ''
        let normal_altimeter_current_text_font = ''
        let normal_distance_icon_img = ''
        let normal_distance_current_text_font = ''
        let normal_step_current_text_font = ''
        let normal_calorie_current_text_font = ''
        let normal_heart_rate_text_font = ''
        let normal_day_text_font = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_week_img = ''
        let normal_spo2_icon_img = ''
        let normal_time_hour_text_font = ''
        let normal_timerTimeUpdate = undefined;
        let normal_time_minute_text_font = ''
        let normal_time_second_text_font = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_analog_clock_pro_second_pointer_img = ''
        let normal_timerUpdateSecSmooth = undefined;
        let lastTime = 0;
        let normal_fat_burning_icon_img = ''
        let normal_stand_icon_img = ''
        let normal_stress_icon_img = ''
        let idle_background_bg_img = ''
        let idle_battery_current_text_font = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_fat_burning_icon_img = ''
        let normal_step_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_battery_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_moon_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_altimeter_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_altitude_jumpable_img_click = ''
        let normal_readiness_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let Button_7 = ''
        let Button_8 = ''
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            // FontName: Dystopia.ttf; FontSize: 26; Cache: full
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 31,
              h: 31,
              text_size: 26,
              char_space: 2,
              line_space: 0,
              font: 'fonts/Dystopia.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: Dystopia.ttf; FontSize: 36
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 495,
              h: 44,
              text_size: 36,
              char_space: 2,
              line_space: 0,
              font: 'fonts/Dystopia.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.RIGHT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: Dystopia.ttf; FontSize: 44
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 576,
              h: 55,
              text_size: 44,
              char_space: 2,
              line_space: 0,
              font: 'fonts/Dystopia.ttf',
              color: 0xFF000000,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: Dystopia.ttf; FontSize: 100
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 1189,
              h: 124,
              text_size: 100,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Dystopia.ttf',
              color: 0xFF000000,
              align_h: hmUI.align.RIGHT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: Dystopia.ttf; FontSize: 52
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 703,
              h: 66,
              text_size: 52,
              char_space: 3,
              line_space: 0,
              font: 'fonts/Dystopia.ttf',
              color: 0xFF000000,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFFFF8000',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            if (screenType != hmSetting.screen_type.AOD) {
              normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 365,
              // start_y: 207,
              // color: 0xFF000000,
              // lenght: 52,
              // line_width: 22,
              // line_cap: Flat,
              // vertical: False,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'main.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'sym_wea.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 60,
              y: 150,
              w: 170,
              h: 26,
              text_size: 26,
              char_space: 2,
              line_space: 0,
              font: 'fonts/Dystopia.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              // unit_type: 1,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 160,
              y: 50,
              image_array: ["weatherl_00.png","weatherl_01.png","weatherl_02.png","weatherl_03.png","weatherl_04.png","weatherl_05.png","weatherl_06.png","weatherl_07.png","weatherl_08.png","weatherl_09.png","weatherl_10.png","weatherl_11.png","weatherl_12.png","weatherl_13.png","weatherl_14.png","weatherl_15.png","weatherl_16.png","weatherl_17.png","weatherl_18.png","weatherl_19.png","weatherl_20.png","weatherl_21.png","weatherl_22.png","weatherl_23.png","weatherl_24.png","weatherl_25.png","weatherl_26.png","weatherl_27.png","weatherl_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 40,
              y: 112,
              w: 150,
              h: 36,
              text_size: 36,
              char_space: 2,
              line_space: 0,
              font: 'fonts/Dystopia.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.RIGHT,
              align_v: hmUI.align.CENTER_V,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 255,
              y: 365,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'sym_sun.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 290,
              y: 300,
              w: 150,
              h: 26,
              text_size: 26,
              char_space: 2,
              line_space: 0,
              font: 'fonts/Dystopia.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 290,
              y: 330,
              w: 150,
              h: 26,
              text_size: 26,
              char_space: 2,
              line_space: 0,
              font: 'fonts/Dystopia.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'sym_bar.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 40,
              y: 390,
              w: 150,
              h: 26,
              text_size: 26,
              char_space: 2,
              line_space: 0,
              font: 'fonts/Dystopia.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.RIGHT,
              align_v: hmUI.align.CENTER_V,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.WIND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 40,
              y: 360,
              w: 150,
              h: 26,
              text_size: 26,
              char_space: 2,
              line_space: 0,
              font: 'fonts/Dystopia.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.RIGHT,
              align_v: hmUI.align.CENTER_V,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altitude_target_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 14,
              y: 330,
              w: 150,
              h: 26,
              text_size: 26,
              char_space: 2,
              line_space: 0,
              font: 'fonts/Dystopia.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.RIGHT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.ALTITUDE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 40,
              y: 300,
              w: 150,
              h: 26,
              text_size: 26,
              char_space: 2,
              line_space: 0,
              font: 'fonts/Dystopia.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.RIGHT,
              align_v: hmUI.align.CENTER_V,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'sym_act.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 290,
              y: 150,
              w: 150,
              h: 26,
              text_size: 26,
              char_space: 2,
              line_space: 0,
              font: 'fonts/Dystopia.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 290,
              y: 120,
              w: 150,
              h: 26,
              text_size: 26,
              char_space: 2,
              line_space: 0,
              font: 'fonts/Dystopia.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 290,
              y: 90,
              w: 150,
              h: 26,
              text_size: 26,
              char_space: 2,
              line_space: 0,
              font: 'fonts/Dystopia.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 290,
              y: 60,
              w: 150,
              h: 26,
              text_size: 26,
              char_space: 2,
              line_space: 0,
              font: 'fonts/Dystopia.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function() {
              time_update(true);
            });

            normal_day_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 61,
              y: 232,
              w: 60,
              h: 44,
              text_size: 44,
              char_space: 2,
              line_space: 0,
              font: 'fonts/Dystopia.ttf',
              color: 0xFF000000,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 0,
              month_startY: 0,
              month_sc_array: ["mo01.png","mo02.png","mo03.png","mo04.png","mo05.png","mo06.png","mo07.png","mo08.png","mo09.png","mo10.png","mo11.png","mo12.png"],
              month_tc_array: ["mo01.png","mo02.png","mo03.png","mo04.png","mo05.png","mo06.png","mo07.png","mo08.png","mo09.png","mo10.png","mo11.png","mo12.png"],
              month_en_array: ["mo01.png","mo02.png","mo03.png","mo04.png","mo05.png","mo06.png","mo07.png","mo08.png","mo09.png","mo10.png","mo11.png","mo12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 0,
              y: 0,
              week_en: ["wd1.png","wd2.png","wd3.png","wd4.png","wd5.png","wd6.png","wd7.png"],
              week_tc: ["wd1.png","wd2.png","wd3.png","wd4.png","wd5.png","wd6.png","wd7.png"],
              week_sc: ["wd1.png","wd2.png","wd3.png","wd4.png","wd5.png","wd6.png","wd7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'seperator.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_time_hour_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 75,
              y: 191,
              w: 150,
              h: 100,
              text_size: 100,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Dystopia.ttf',
              color: 0xFF000000,
              align_h: hmUI.align.RIGHT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_time_minute_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 262,
              y: 191,
              w: 150,
              h: 100,
              text_size: 100,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Dystopia.ttf',
              color: 0xFF000000,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_time_second_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 354,
              y: 231,
              w: 80,
              h: 52,
              text_size: 52,
              char_space: 3,
              line_space: 0,
              font: 'fonts/Dystopia.ttf',
              color: 0xFF000000,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hand_hour.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 240,
              hour_posY: 240,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'hand_min.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 240,
              minute_posY: 240,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'hand_sec1.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 240,
              second_posY: 240,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const deviceInfo = hmSetting.getDeviceInfo();
            // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'hand_sec1.png',
              // center_x: 240,
              // center_y: 240,
              // x: 240,
              // y: 240,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 240,
              pos_y: 240 - 240,
              center_x: 240,
              center_y: 240,
              src: 'hand_sec1.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            function startSecAnim(sec, animDuration) {
              const secAnim = {
                anim_steps: [{
                  anim_rate: 'linear',
                  anim_duration: animDuration,
                  anim_from: sec,
                  anim_to: sec + (360*(animDuration*6/1000))/360,
                  anim_key: 'angle',
                }],
                anim_fps: 15,
                anim_auto_start: 1,
                anim_repeat: 0,
                anim_auto_destroy: 1,
              }
              normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANIM, secAnim);
            }
            // normal_analog_clock_pro_smooth_second = hmUI.createWidget(hmUI.widget.SMOOTH_SECOND, {
              // type: 4,
              // fps: 15,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_fat_burning_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'hand_top.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'top.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'menu.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'aod.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 190,
              y: 400,
              w: 100,
              h: 36,
              text_size: 36,
              char_space: 2,
              line_space: 0,
              font: 'fonts/Dystopia.ttf',
              color: 0xFFC0C0C0,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hand_hour.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 240,
              hour_posY: 240,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'hand_min.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 240,
              minute_posY: 240,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_fat_burning_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'aod_top.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 250,
              y: 115,
              w: 90,
              h: 60,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 250,
              y: 50,
              w: 60,
              h: 60,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 361,
              y: 210,
              w: 60,
              h: 60,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 250,
              y: 297,
              w: 90,
              h: 60,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 250,
              y: 360,
              w: 60,
              h: 60,
              type: hmUI.data_type.MOON_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 140,
              y: 115,
              w: 90,
              h: 60,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 140,
              y: 297,
              w: 90,
              h: 60,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 130,
              y: 210,
              w: 60,
              h: 60,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 290,
              y: 210,
              w: 60,
              h: 60,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altitude_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 170,
              y: 360,
              w: 60,
              h: 60,
              type: hmUI.data_type.ALTITUDE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_readiness_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 170,
              y: 50,
              w: 60,
              h: 60,
              type: hmUI.data_type.READINESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 200,
              y: 200,
              w: 80,
              h: 80,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                				click_MENU();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 141,
              y: 82,
              w: 80,
              h: 80,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                				click_HANDS();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 258,
              y: 82,
              w: 80,
              h: 80,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                				click_COLOR();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 55,
              y: 55,
              w: 80,
              h: 80,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                				click_Element_1();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 345,
              y: 55,
              w: 80,
              h: 80,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                				click_Element_2();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 55,
              y: 345,
              w: 80,
              h: 80,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                				click_Element_3();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_7 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 345,
              y: 345,
              w: 80,
              h: 80,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                				click_Element_4();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_8 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 59,
              y: 210,
              w: 60,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            console.log('user_script_end.js');
            // start user_script_end.js
			if (cc ==0 ){
			  normal_spo2_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			  normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.VISIBLE, false);
			  normal_stress_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			  
			  Button_2.setProperty(hmUI.prop.VISIBLE, false);
			  Button_3.setProperty(hmUI.prop.VISIBLE, false);
			cc = 1;
			}
            // end user_script_end.js

            //start of ignored block
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              console.log('day font');
              if (updateHour) {
                let normal_dayStr = timeSensor.day.toString();
                normal_dayStr = normal_dayStr.padStart(2, '0');
                normal_day_text_font.setProperty(hmUI.prop.TEXT, normal_dayStr );
              };

              console.log('hour font');
              if (updateHour) {
                let normal_hourStr = format_hour.toString();
                normal_hourStr = normal_hourStr.padStart(2, '0');
                normal_time_hour_text_font.setProperty(hmUI.prop.TEXT, normal_hourStr );
              };

              console.log('minute font');
              if (updateMinute) {
                let normal_minuteStr = minute.toString();
                normal_minuteStr = normal_minuteStr.padStart(2, '0');
                normal_time_minute_text_font.setProperty(hmUI.prop.TEXT, normal_minuteStr );
              };

              console.log('second font');
                let normal_secondStr = second.toString();
                normal_secondStr = normal_secondStr.padStart(2, '0');
                normal_time_second_text_font.setProperty(hmUI.prop.TEXT, normal_secondStr );
            };

            //end of ignored block
            function scale_call() {
              console.log('scale_call()');

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_ls_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_linear_scale
                  // initial parameters
                  let start_x_normal_battery = 365;
                  let start_y_normal_battery = 207;
                  let lenght_ls_normal_battery = 52;
                  let line_width_ls_normal_battery = 22;
                  let color_ls_normal_battery = 0xFF000000;
                  
                  // calculated parameters
                  let start_x_normal_battery_draw = start_x_normal_battery;
                  let start_y_normal_battery_draw = start_y_normal_battery;
                  lenght_ls_normal_battery = lenght_ls_normal_battery * progress_ls_normal_battery;
                  let lenght_ls_normal_battery_draw = lenght_ls_normal_battery;
                  let line_width_ls_normal_battery_draw = line_width_ls_normal_battery;
                  if (lenght_ls_normal_battery < 0){
                    lenght_ls_normal_battery_draw = -lenght_ls_normal_battery;
                    start_x_normal_battery_draw = start_x_normal_battery - lenght_ls_normal_battery_draw;
                  };
                  
                  normal_battery_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_battery_draw,
                    y: start_y_normal_battery_draw,
                    w: lenght_ls_normal_battery_draw,
                    h: line_width_ls_normal_battery_draw,
                    color: color_ls_normal_battery,
                  });
                };

              console.log('Weather city name');
              let weatherData = weatherSensor.getForecastWeather();
              normal_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                time_update(true, true);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerTimeUpdate) {
                    normal_timerTimeUpdate = timer.createTimer(0, 1000, (function (option) {
                      let updateHour = timeSensor.minute == 0 && timeSensor.second < 2;
                      let updateMinute = timeSensor.second < 2;
                      time_update(updateHour, updateMinute);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                let secAngle = 0 + (360*6)*(timeSensor.second + ((timeSensor.utc % 1000) / 1000))/360;
                normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, secAngle);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSecSmooth) {
                    let duration = 0;
                    let animDuration = 5000;
                    if (timeSensor.second > 55) animDuration = 1000*(60.1 - (timeSensor.second - (timeSensor.utc % 1000) / 1000));
                    let diffTime = timeSensor.utc - lastTime;
                    if (diffTime < animDuration) duration = animDuration - diffTime;
                    normal_timerUpdateSecSmooth = timer.createTimer(duration, animDuration, (function (option) {
                      lastTime = timeSensor.utc;
                      secAngle = 0 + (360*6)*(timeSensor.second + ((timeSensor.utc % 1000) / 1000))/360;
                      startSecAnim(secAngle, animDuration);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerTimeUpdate) {
                  timer.stopTimer(normal_timerTimeUpdate);
                  normal_timerTimeUpdate = undefined;
                }
                if (normal_timerUpdateSecSmooth) {
                  timer.stopTimer(normal_timerUpdateSecSmooth);
                  normal_timerUpdateSecSmooth = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
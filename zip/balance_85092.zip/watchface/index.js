﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js
		
		// Color START	
		let colornumber_main = 1
        let totalcolors_main = 16
	
		function click_COLOR() {
            if(colornumber_main>=totalcolors_main) {
            colornumber_main=1;
            }
            else {
                colornumber_main=colornumber_main+1;
            }
			
			normal_image_img.setProperty(hmUI.prop.SRC, "color" + parseInt(colornumber_main) + ".png"); 
		}
		// Color END
        // end user_functions.js

        let normal_background_bg = ''
        let normal_image_img = ''
        let normal_fat_burning_icon_img = ''
        let normal_heart_rate_TextRotate = new Array(3);
        let normal_heart_rate_TextRotate_ASCIIARRAY = new Array(10);
        let normal_heart_rate_TextRotate_img_width = 32;
        let normal_battery_TextRotate = new Array(3);
        let normal_battery_TextRotate_ASCIIARRAY = new Array(10);
        let normal_battery_TextRotate_img_width = 22;
        let normal_step_TextRotate = new Array(5);
        let normal_step_TextRotate_ASCIIARRAY = new Array(10);
        let normal_step_TextRotate_img_width = 32;
        let normal_date_img_date_week_img = ''
        let normal_group_ForecastWeather = ''
        let normal_forecast_low_text_img = new Array(3);
        let normal_forecast_high_text_img = new Array(3);
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_TextRotate = new Array(4);
        let normal_temperature_current_TextRotate_ASCIIARRAY = new Array(10);
        let normal_temperature_current_TextRotate_img_width = 32;
        let normal_temperature_current_TextRotate_dot_width = 32;
        let normal_date_img_date_month_img = ''
        let normal_day_TextRotate = new Array(2);
        let normal_day_TextRotate_ASCIIARRAY = new Array(10);
        let normal_day_TextRotate_img_width = 52;
        let normal_timerTextUpdate = undefined;
        let normal_hour_TextRotate = new Array(2);
        let normal_hour_TextRotate_ASCIIARRAY = new Array(10);
        let normal_hour_TextRotate_img_width = 52;
        let normal_minute_TextRotate = new Array(2);
        let normal_minute_TextRotate_ASCIIARRAY = new Array(10);
        let normal_minute_TextRotate_img_width = 32;
        let normal_second_TextRotate = new Array(2);
        let normal_second_TextRotate_ASCIIARRAY = new Array(10);
        let normal_second_TextRotate_img_width = 22;
        let normal_stress_icon_img = ''
        let idle_background_bg = ''
        let idle_image_img = ''
        let idle_fat_burning_icon_img = ''
        let idle_heart_rate_TextRotate = new Array(3);
        let idle_heart_rate_TextRotate_ASCIIARRAY = new Array(10);
        let idle_heart_rate_TextRotate_img_width = 32;
        let idle_battery_TextRotate = new Array(3);
        let idle_battery_TextRotate_ASCIIARRAY = new Array(10);
        let idle_battery_TextRotate_img_width = 22;
        let idle_step_TextRotate = new Array(5);
        let idle_step_TextRotate_ASCIIARRAY = new Array(10);
        let idle_step_TextRotate_img_width = 32;
        let idle_weather_image_progress_img_level = ''
        let idle_temperature_current_TextRotate = new Array(4);
        let idle_temperature_current_TextRotate_ASCIIARRAY = new Array(10);
        let idle_temperature_current_TextRotate_img_width = 32;
        let idle_temperature_current_TextRotate_dot_width = 32;
        let idle_date_img_date_month_img = ''
        let idle_day_TextRotate = new Array(2);
        let idle_day_TextRotate_ASCIIARRAY = new Array(10);
        let idle_day_TextRotate_img_width = 52;
        let idle_timerTextUpdate = undefined;
        let idle_hour_TextRotate = new Array(2);
        let idle_hour_TextRotate_ASCIIARRAY = new Array(10);
        let idle_hour_TextRotate_img_width = 52;
        let idle_minute_TextRotate = new Array(2);
        let idle_minute_TextRotate_ASCIIARRAY = new Array(10);
        let idle_minute_TextRotate_img_width = 32;
        let idle_stress_icon_img = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let Button_7 = ''
        let Button_8 = ''
        let Button_Switch_BG_Color = ''

        let bgColorIndex = 0;
        let bgColorList = [0xFF9C9578, 0xFFFF8C00, 0xFF008080, 0xFF808000, 0xFF800000, 0xFF00FFFF, 0xFF008000, 0xFFFF0000, 0xFFFFFF00, 0xFFA020F0, 0xFFBFFF00, 0xFF0000FF, 0xFFFF00FF, 0xFFA5694F, 0xFFFFBF00, 0xFFA5A9B4, 0xFFFFFFFF];
        let bgColorToastList = ['ORIGINAL', 'ORANGE', 'TEAL', 'OLIVE', 'MAROON', 'AQUA', 'GREEN', 'RED', 'YELLOW', 'PURPLE', 'LIME', 'BLUE', 'FUCHSIA', 'SEPIA', 'AMBER', 'SILVER', 'WHITE'];
        const watchfaceId = hmApp.packageInfo().watchfaceId;
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            //start of ignored block
            console.log('SwitchBG_Color');
            function switchBG_Color() {
              bgColorIndex++;
              if (bgColorIndex >= bgColorList.length) bgColorIndex = 0;
              hmFS.SysProSetInt(`bgColorIndex_${watchfaceId}`, bgColorIndex);
              let toastText = bgColorToastList[bgColorIndex].replace('%s', `${bgColorIndex + 1}`);
              if (toastText.length > 0) hmUI.showToast({text: toastText});
              normal_background_bg.setProperty(hmUI.prop.COLOR, bgColorList[bgColorIndex]);
            };
            //end of ignored block

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFF9C9578',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'color1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_fat_burning_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'back.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_heart_rate_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 176,
              // y: 365,
              // font_array: ["72num_00.png","72num_01.png","72num_02.png","72num_03.png","72num_04.png","72num_05.png","72num_06.png","72num_07.png","72num_08.png","72num_09.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: 17,
              // align_h: hmUI.align.RIGHT,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_heart_rate_TextRotate_ASCIIARRAY[0] = '72num_00.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[1] = '72num_01.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[2] = '72num_02.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[3] = '72num_03.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[4] = '72num_04.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[5] = '72num_05.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[6] = '72num_06.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[7] = '72num_07.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[8] = '72num_08.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[9] = '72num_09.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 3; i++) {
              normal_heart_rate_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 176,
                center_y: 365,
                pos_x: 176,
                pos_y: 365,
                angle: 17,
                src: '72num_00.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_heart_rate_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            
            const heart_rate = hmSensor.createSensor(hmSensor.id.HEART);
            heart_rate.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            // normal_battery_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 92,
              // y: 290,
              // font_array: ["48num_00.png","48num_01.png","48num_02.png","48num_03.png","48num_04.png","48num_05.png","48num_06.png","48num_07.png","48num_08.png","48num_09.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: -1,
              // angle: 17,
              // align_h: hmUI.align.RIGHT,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_battery_TextRotate_ASCIIARRAY[0] = '48num_00.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[1] = '48num_01.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[2] = '48num_02.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[3] = '48num_03.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[4] = '48num_04.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[5] = '48num_05.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[6] = '48num_06.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[7] = '48num_07.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[8] = '48num_08.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[9] = '48num_09.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 3; i++) {
              normal_battery_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 92,
                center_y: 290,
                pos_x: 92,
                pos_y: 290,
                angle: 17,
                src: '48num_00.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_battery_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            // normal_step_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 174,
              // y: 252,
              // font_array: ["72num_00.png","72num_01.png","72num_02.png","72num_03.png","72num_04.png","72num_05.png","72num_06.png","72num_07.png","72num_08.png","72num_09.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: 17,
              // align_h: hmUI.align.RIGHT,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_step_TextRotate_ASCIIARRAY[0] = '72num_00.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[1] = '72num_01.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[2] = '72num_02.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[3] = '72num_03.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[4] = '72num_04.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[5] = '72num_05.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[6] = '72num_06.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[7] = '72num_07.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[8] = '72num_08.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[9] = '72num_09.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              normal_step_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 174,
                center_y: 252,
                pos_x: 174,
                pos_y: 252,
                angle: 17,
                src: '72num_00.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_step_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 230,
              y: 148,
              week_en: ["wd1.png","wd2.png","wd3.png","wd4.png","wd5.png","wd6.png","wd7.png"],
              week_tc: ["wd1.png","wd2.png","wd3.png","wd4.png","wd5.png","wd6.png","wd7.png"],
              week_sc: ["wd1.png","wd2.png","wd3.png","wd4.png","wd5.png","wd6.png","wd7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();            
            // normal_Weather_FewDays = hmUI.createWidget(hmUI.widget.FewDays, {
              // x: 0,
              // y: 0,
              // ColumnWidth: 400,
              // DaysCount: 3,
            // });
            
            normal_group_ForecastWeather = hmUI.createWidget(hmUI.widget.GROUP, {
              x: 0,
              y: 0,
              h: 0,
              w: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_forecast_low_text_img = normal_group_ForecastWeather.createWidget(hmUI.widget.TEXT_IMG_Options, {
              // x: -212,
              // y: 199,
              // font_array: ["48num_00.png","48num_01.png","48num_02.png","48num_03.png","48num_04.png","48num_05.png","48num_06.png","48num_07.png","48num_08.png","48num_09.png"],
              // padding: false,
              // h_space: -1,
              // angle: -6,
              // negative_image: '48num_10.png',
              // dot_image: '48num_10.png',
              // align_h: hmUI.align.RIGHT,
              // type: hmUI.data_type.forecast_low_text_img,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            //start of ignored block
            if (screenType == hmSetting.screen_type.WATCHFACE) {
              for (let i = 0; i < 3; i++) {
                normal_forecast_low_text_img[i] = normal_group_ForecastWeather.createWidget(hmUI.widget.TEXT_IMG, {
                  x: -212 + i*400,
                  y: 199,
                  font_array: ["48num_00.png","48num_01.png","48num_02.png","48num_03.png","48num_04.png","48num_05.png","48num_06.png","48num_07.png","48num_08.png","48num_09.png"],
                  padding: false,
                  h_space: -1,
                  angle: -6,
                  negative_image: '48num_10.png',
                  align_h: hmUI.align.RIGHT,
                  // type: hmUI.data_type.FORECAST_NUMBER_MAX,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
              };
            };
            //end of ignored block

            // normal_forecast_high_text_img = normal_group_ForecastWeather.createWidget(hmUI.widget.TEXT_IMG_Options, {
              // x: -129,
              // y: 189,
              // font_array: ["48num_00.png","48num_01.png","48num_02.png","48num_03.png","48num_04.png","48num_05.png","48num_06.png","48num_07.png","48num_08.png","48num_09.png"],
              // padding: false,
              // h_space: -1,
              // angle: -6,
              // negative_image: '48num_10.png',
              // dot_image: '48num_10.png',
              // align_h: hmUI.align.RIGHT,
              // type: hmUI.data_type.forecast_high_text_img,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            //start of ignored block
            if (screenType == hmSetting.screen_type.WATCHFACE) {
              for (let i = 0; i < 3; i++) {
                normal_forecast_high_text_img[i] = normal_group_ForecastWeather.createWidget(hmUI.widget.TEXT_IMG, {
                  x: -129 + i*400,
                  y: 189,
                  font_array: ["48num_00.png","48num_01.png","48num_02.png","48num_03.png","48num_04.png","48num_05.png","48num_06.png","48num_07.png","48num_08.png","48num_09.png"],
                  padding: false,
                  h_space: -1,
                  angle: -6,
                  negative_image: '48num_10.png',
                  align_h: hmUI.align.RIGHT,
                  // type: hmUI.data_type.FORECAST_NUMBER_MAX,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
              };
            };
            //end of ignored block

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 228,
              y: 18,
              image_array: ["weatherd_00.png","weatherd_01.png","weatherd_02.png","weatherd_03.png","weatherd_04.png","weatherd_05.png","weatherd_06.png","weatherd_07.png","weatherd_08.png","weatherd_09.png","weatherd_10.png","weatherd_11.png","weatherd_12.png","weatherd_13.png","weatherd_14.png","weatherd_15.png","weatherd_16.png","weatherd_17.png","weatherd_18.png","weatherd_19.png","weatherd_20.png","weatherd_21.png","weatherd_22.png","weatherd_23.png","weatherd_24.png","weatherd_25.png","weatherd_26.png","weatherd_27.png","weatherd_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_temperature_current_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 303,
              // y: 81,
              // font_array: ["72num_00.png","72num_01.png","72num_02.png","72num_03.png","72num_04.png","72num_05.png","72num_06.png","72num_07.png","72num_08.png","72num_09.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: -6,
              // negative_image: '72num_10.png',
              // dot_image: '72num_10.png',
              // align_h: hmUI.align.RIGHT,
              // type: hmUI.data_type.WEATHER_CURRENT,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_temperature_current_TextRotate_ASCIIARRAY[0] = '72num_00.png';  // set of images with numbers
            normal_temperature_current_TextRotate_ASCIIARRAY[1] = '72num_01.png';  // set of images with numbers
            normal_temperature_current_TextRotate_ASCIIARRAY[2] = '72num_02.png';  // set of images with numbers
            normal_temperature_current_TextRotate_ASCIIARRAY[3] = '72num_03.png';  // set of images with numbers
            normal_temperature_current_TextRotate_ASCIIARRAY[4] = '72num_04.png';  // set of images with numbers
            normal_temperature_current_TextRotate_ASCIIARRAY[5] = '72num_05.png';  // set of images with numbers
            normal_temperature_current_TextRotate_ASCIIARRAY[6] = '72num_06.png';  // set of images with numbers
            normal_temperature_current_TextRotate_ASCIIARRAY[7] = '72num_07.png';  // set of images with numbers
            normal_temperature_current_TextRotate_ASCIIARRAY[8] = '72num_08.png';  // set of images with numbers
            normal_temperature_current_TextRotate_ASCIIARRAY[9] = '72num_09.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 4; i++) {
              normal_temperature_current_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 303,
                center_y: 81,
                pos_x: 303,
                pos_y: 81,
                angle: -6,
                src: '72num_00.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_temperature_current_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 50,
              month_startY: 90,
              month_sc_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_tc_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_en_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_day_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 102,
              // y: 145,
              // font_array: ["120num_00.png","120num_01.png","120num_02.png","120num_03.png","120num_04.png","120num_05.png","120num_06.png","120num_07.png","120num_08.png","120num_09.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: -72,
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.DAY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_day_TextRotate_ASCIIARRAY[0] = '120num_00.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[1] = '120num_01.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[2] = '120num_02.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[3] = '120num_03.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[4] = '120num_04.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[5] = '120num_05.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[6] = '120num_06.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[7] = '120num_07.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[8] = '120num_08.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[9] = '120num_09.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              normal_day_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 102,
                center_y: 145,
                pos_x: 102,
                pos_y: 145,
                angle: -72,
                src: '120num_00.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_day_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            // normal_hour_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 237,
              // y: 392,
              // font_array: ["120num_00.png","120num_01.png","120num_02.png","120num_03.png","120num_04.png","120num_05.png","120num_06.png","120num_07.png","120num_08.png","120num_09.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: -42,
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.HOUR,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_hour_TextRotate_ASCIIARRAY[0] = '120num_00.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[1] = '120num_01.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[2] = '120num_02.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[3] = '120num_03.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[4] = '120num_04.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[5] = '120num_05.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[6] = '120num_06.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[7] = '120num_07.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[8] = '120num_08.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[9] = '120num_09.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              normal_hour_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 237,
                center_y: 392,
                pos_x: 237,
                pos_y: 392,
                angle: -42,
                src: '120num_00.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_hour_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            // normal_minute_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 333,
              // y: 309,
              // font_array: ["72num_00.png","72num_01.png","72num_02.png","72num_03.png","72num_04.png","72num_05.png","72num_06.png","72num_07.png","72num_08.png","72num_09.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: -42,
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.MINUTE,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_minute_TextRotate_ASCIIARRAY[0] = '72num_00.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[1] = '72num_01.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[2] = '72num_02.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[3] = '72num_03.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[4] = '72num_04.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[5] = '72num_05.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[6] = '72num_06.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[7] = '72num_07.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[8] = '72num_08.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[9] = '72num_09.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              normal_minute_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 333,
                center_y: 309,
                pos_x: 333,
                pos_y: 309,
                angle: -42,
                src: '72num_00.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_minute_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            // normal_second_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 376,
              // y: 359,
              // font_array: ["48num_00.png","48num_01.png","48num_02.png","48num_03.png","48num_04.png","48num_05.png","48num_06.png","48num_07.png","48num_08.png","48num_09.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: -1,
              // angle: -42,
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.SECOND,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_second_TextRotate_ASCIIARRAY[0] = '48num_00.png';  // set of images with numbers
            normal_second_TextRotate_ASCIIARRAY[1] = '48num_01.png';  // set of images with numbers
            normal_second_TextRotate_ASCIIARRAY[2] = '48num_02.png';  // set of images with numbers
            normal_second_TextRotate_ASCIIARRAY[3] = '48num_03.png';  // set of images with numbers
            normal_second_TextRotate_ASCIIARRAY[4] = '48num_04.png';  // set of images with numbers
            normal_second_TextRotate_ASCIIARRAY[5] = '48num_05.png';  // set of images with numbers
            normal_second_TextRotate_ASCIIARRAY[6] = '48num_06.png';  // set of images with numbers
            normal_second_TextRotate_ASCIIARRAY[7] = '48num_07.png';  // set of images with numbers
            normal_second_TextRotate_ASCIIARRAY[8] = '48num_08.png';  // set of images with numbers
            normal_second_TextRotate_ASCIIARRAY[9] = '48num_09.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              normal_second_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 376,
                center_y: 359,
                pos_x: 376,
                pos_y: 359,
                angle: -42,
                src: '48num_00.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_second_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            normal_stress_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'main.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFF9C9578',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'aod.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_fat_burning_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'back.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_heart_rate_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 176,
              // y: 365,
              // font_array: ["72num_00.png","72num_01.png","72num_02.png","72num_03.png","72num_04.png","72num_05.png","72num_06.png","72num_07.png","72num_08.png","72num_09.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: 17,
              // align_h: hmUI.align.RIGHT,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_heart_rate_TextRotate_ASCIIARRAY[0] = '72num_00.png';  // set of images with numbers
            idle_heart_rate_TextRotate_ASCIIARRAY[1] = '72num_01.png';  // set of images with numbers
            idle_heart_rate_TextRotate_ASCIIARRAY[2] = '72num_02.png';  // set of images with numbers
            idle_heart_rate_TextRotate_ASCIIARRAY[3] = '72num_03.png';  // set of images with numbers
            idle_heart_rate_TextRotate_ASCIIARRAY[4] = '72num_04.png';  // set of images with numbers
            idle_heart_rate_TextRotate_ASCIIARRAY[5] = '72num_05.png';  // set of images with numbers
            idle_heart_rate_TextRotate_ASCIIARRAY[6] = '72num_06.png';  // set of images with numbers
            idle_heart_rate_TextRotate_ASCIIARRAY[7] = '72num_07.png';  // set of images with numbers
            idle_heart_rate_TextRotate_ASCIIARRAY[8] = '72num_08.png';  // set of images with numbers
            idle_heart_rate_TextRotate_ASCIIARRAY[9] = '72num_09.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 3; i++) {
              idle_heart_rate_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 176,
                center_y: 365,
                pos_x: 176,
                pos_y: 365,
                angle: 17,
                src: '72num_00.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_heart_rate_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            // idle_battery_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 92,
              // y: 290,
              // font_array: ["48num_00.png","48num_01.png","48num_02.png","48num_03.png","48num_04.png","48num_05.png","48num_06.png","48num_07.png","48num_08.png","48num_09.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: -1,
              // angle: 17,
              // align_h: hmUI.align.RIGHT,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_battery_TextRotate_ASCIIARRAY[0] = '48num_00.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[1] = '48num_01.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[2] = '48num_02.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[3] = '48num_03.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[4] = '48num_04.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[5] = '48num_05.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[6] = '48num_06.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[7] = '48num_07.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[8] = '48num_08.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[9] = '48num_09.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 3; i++) {
              idle_battery_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 92,
                center_y: 290,
                pos_x: 92,
                pos_y: 290,
                angle: 17,
                src: '48num_00.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_battery_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            // idle_step_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 174,
              // y: 252,
              // font_array: ["72num_00.png","72num_01.png","72num_02.png","72num_03.png","72num_04.png","72num_05.png","72num_06.png","72num_07.png","72num_08.png","72num_09.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: 17,
              // align_h: hmUI.align.RIGHT,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_step_TextRotate_ASCIIARRAY[0] = '72num_00.png';  // set of images with numbers
            idle_step_TextRotate_ASCIIARRAY[1] = '72num_01.png';  // set of images with numbers
            idle_step_TextRotate_ASCIIARRAY[2] = '72num_02.png';  // set of images with numbers
            idle_step_TextRotate_ASCIIARRAY[3] = '72num_03.png';  // set of images with numbers
            idle_step_TextRotate_ASCIIARRAY[4] = '72num_04.png';  // set of images with numbers
            idle_step_TextRotate_ASCIIARRAY[5] = '72num_05.png';  // set of images with numbers
            idle_step_TextRotate_ASCIIARRAY[6] = '72num_06.png';  // set of images with numbers
            idle_step_TextRotate_ASCIIARRAY[7] = '72num_07.png';  // set of images with numbers
            idle_step_TextRotate_ASCIIARRAY[8] = '72num_08.png';  // set of images with numbers
            idle_step_TextRotate_ASCIIARRAY[9] = '72num_09.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              idle_step_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 174,
                center_y: 252,
                pos_x: 174,
                pos_y: 252,
                angle: 17,
                src: '72num_00.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_step_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 228,
              y: 18,
              image_array: ["weatherd_00.png","weatherd_01.png","weatherd_02.png","weatherd_03.png","weatherd_04.png","weatherd_05.png","weatherd_06.png","weatherd_07.png","weatherd_08.png","weatherd_09.png","weatherd_10.png","weatherd_11.png","weatherd_12.png","weatherd_13.png","weatherd_14.png","weatherd_15.png","weatherd_16.png","weatherd_17.png","weatherd_18.png","weatherd_19.png","weatherd_20.png","weatherd_21.png","weatherd_22.png","weatherd_23.png","weatherd_24.png","weatherd_25.png","weatherd_26.png","weatherd_27.png","weatherd_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_temperature_current_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 303,
              // y: 81,
              // font_array: ["72num_00.png","72num_01.png","72num_02.png","72num_03.png","72num_04.png","72num_05.png","72num_06.png","72num_07.png","72num_08.png","72num_09.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: -6,
              // negative_image: '72num_10.png',
              // dot_image: '72num_10.png',
              // align_h: hmUI.align.RIGHT,
              // type: hmUI.data_type.WEATHER_CURRENT,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_temperature_current_TextRotate_ASCIIARRAY[0] = '72num_00.png';  // set of images with numbers
            idle_temperature_current_TextRotate_ASCIIARRAY[1] = '72num_01.png';  // set of images with numbers
            idle_temperature_current_TextRotate_ASCIIARRAY[2] = '72num_02.png';  // set of images with numbers
            idle_temperature_current_TextRotate_ASCIIARRAY[3] = '72num_03.png';  // set of images with numbers
            idle_temperature_current_TextRotate_ASCIIARRAY[4] = '72num_04.png';  // set of images with numbers
            idle_temperature_current_TextRotate_ASCIIARRAY[5] = '72num_05.png';  // set of images with numbers
            idle_temperature_current_TextRotate_ASCIIARRAY[6] = '72num_06.png';  // set of images with numbers
            idle_temperature_current_TextRotate_ASCIIARRAY[7] = '72num_07.png';  // set of images with numbers
            idle_temperature_current_TextRotate_ASCIIARRAY[8] = '72num_08.png';  // set of images with numbers
            idle_temperature_current_TextRotate_ASCIIARRAY[9] = '72num_09.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 4; i++) {
              idle_temperature_current_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 303,
                center_y: 81,
                pos_x: 303,
                pos_y: 81,
                angle: -6,
                src: '72num_00.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_temperature_current_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 50,
              month_startY: 90,
              month_sc_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_tc_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_en_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_day_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 102,
              // y: 145,
              // font_array: ["120num_00.png","120num_01.png","120num_02.png","120num_03.png","120num_04.png","120num_05.png","120num_06.png","120num_07.png","120num_08.png","120num_09.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: -72,
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.DAY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_day_TextRotate_ASCIIARRAY[0] = '120num_00.png';  // set of images with numbers
            idle_day_TextRotate_ASCIIARRAY[1] = '120num_01.png';  // set of images with numbers
            idle_day_TextRotate_ASCIIARRAY[2] = '120num_02.png';  // set of images with numbers
            idle_day_TextRotate_ASCIIARRAY[3] = '120num_03.png';  // set of images with numbers
            idle_day_TextRotate_ASCIIARRAY[4] = '120num_04.png';  // set of images with numbers
            idle_day_TextRotate_ASCIIARRAY[5] = '120num_05.png';  // set of images with numbers
            idle_day_TextRotate_ASCIIARRAY[6] = '120num_06.png';  // set of images with numbers
            idle_day_TextRotate_ASCIIARRAY[7] = '120num_07.png';  // set of images with numbers
            idle_day_TextRotate_ASCIIARRAY[8] = '120num_08.png';  // set of images with numbers
            idle_day_TextRotate_ASCIIARRAY[9] = '120num_09.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              idle_day_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 102,
                center_y: 145,
                pos_x: 102,
                pos_y: 145,
                angle: -72,
                src: '120num_00.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_day_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            // idle_hour_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 237,
              // y: 392,
              // font_array: ["120num_00.png","120num_01.png","120num_02.png","120num_03.png","120num_04.png","120num_05.png","120num_06.png","120num_07.png","120num_08.png","120num_09.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: -42,
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.HOUR,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_hour_TextRotate_ASCIIARRAY[0] = '120num_00.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[1] = '120num_01.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[2] = '120num_02.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[3] = '120num_03.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[4] = '120num_04.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[5] = '120num_05.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[6] = '120num_06.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[7] = '120num_07.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[8] = '120num_08.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[9] = '120num_09.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              idle_hour_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 237,
                center_y: 392,
                pos_x: 237,
                pos_y: 392,
                angle: -42,
                src: '120num_00.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_hour_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            // idle_minute_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 333,
              // y: 309,
              // font_array: ["72num_00.png","72num_01.png","72num_02.png","72num_03.png","72num_04.png","72num_05.png","72num_06.png","72num_07.png","72num_08.png","72num_09.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: -42,
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.MINUTE,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_minute_TextRotate_ASCIIARRAY[0] = '72num_00.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[1] = '72num_01.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[2] = '72num_02.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[3] = '72num_03.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[4] = '72num_04.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[5] = '72num_05.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[6] = '72num_06.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[7] = '72num_07.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[8] = '72num_08.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[9] = '72num_09.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              idle_minute_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 333,
                center_y: 309,
                pos_x: 333,
                pos_y: 309,
                angle: -42,
                src: '72num_00.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_minute_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            idle_stress_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'main.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 360,
              y: 170,
              w: 90,
              h: 90,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                				click_COLOR();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 65,
              y: 80,
              w: 100,
              h: 100,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 220,
              y: 65,
              w: 100,
              h: 100,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'WeatherScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 260,
              y: 340,
              w: 100,
              h: 100,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'CountdownAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 335,
              y: 261,
              w: 78,
              h: 78,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'StopWatchScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 70,
              y: 345,
              w: 100,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'heart_app_Screen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_7 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 20,
              y: 275,
              w: 100,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PowerSaveHintScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_8 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 20,
              y: 215,
              w: 100,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'activityAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            console.log('Watch_Face.SwitchBG_Color');
            // Button_Switch_BG_Color = hmUI.createWidget(hmUI.widget.SwitchBG_Color, {
              // x: 225,
              // y: 230,
              // w: 100,
              // h: 100,
              // text: '',
              // color: 0xFFFF8C00,
              // text_size: 25,
              // press_src: '0_Empty.png',
              // normal_src: '0_Empty.png',
              // color_list: 0xFF9C9578|0xFFFF8C00|0xFF008080|0xFF808000|0xFF800000|0xFF00FFFF|0xFF008000|0xFFFF0000|0xFFFFFF00|0xFFA020F0|0xFFBFFF00|0xFF0000FF|0xFFFF00FF|0xFFA5694F|0xFFFFBF00|0xFFA5A9B4|0xFFFFFFFF,
              // toast_list: ORIGINAL|ORANGE|TEAL|OLIVE|MAROON|AQUA|GREEN|RED|YELLOW|PURPLE|LIME|BLUE|FUCHSIA|SEPIA|AMBER|SILVER|WHITE,
              // use_crown: False,
              // use_in_AOD: True,
              // vibro: False,
            // });

            Button_Switch_BG_Color = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 225,
              y: 230,
              w: 100,
              h: 100,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                switchBG_Color();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            //start of ignored block
            function weather_few_days() {
              console.log('weather_few_days()');
              let weatherData = weatherSensor.getForecastWeather();
              let forecastData = weatherData.forecastData;

              for (let i = 0; i < 3; i++) {
                // Number_Min
                let minTemperature = '-';
                if (i < forecastData.count) minTemperature = forecastData.data[i].low.toString();
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  normal_forecast_low_text_img[i].setProperty(hmUI.prop.TEXT, minTemperature);
                };
                
                // Number_Max
                let maxTemperature = '-';
                if (i < forecastData.count) maxTemperature = forecastData.data[i].high.toString();
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  normal_forecast_high_text_img[i].setProperty(hmUI.prop.TEXT, maxTemperature);
                };
                
              };  // end for

            };
            //end of ignored block

            //start of ignored block
            function text_update() {
              console.log('text_update()');

              console.log('update text rotate heart_rate_HEART');
              let valueHeartRate = heart_rate.last;
              let normal_heart_rate_rotate_string = parseInt(valueHeartRate).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  normal_heart_rate_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueHeartRate != null && valueHeartRate != undefined && isFinite(valueHeartRate) && normal_heart_rate_rotate_string.length > 0 && normal_heart_rate_rotate_string.length <= 3) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = RIGHT
                  let normal_heart_rate_TextRotate_posOffset = normal_heart_rate_TextRotate_img_width * normal_heart_rate_rotate_string.length;
                  img_offset -= normal_heart_rate_TextRotate_posOffset;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_heart_rate_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_heart_rate_TextRotate[index].setProperty(hmUI.prop.POS_X, 176 + img_offset);
                      normal_heart_rate_TextRotate[index].setProperty(hmUI.prop.SRC, normal_heart_rate_TextRotate_ASCIIARRAY[charCode]);
                      normal_heart_rate_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_heart_rate_TextRotate_img_width;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate battery_BATTERY');
              let valueBattery = battery.current;
              let normal_battery_rotate_string = parseInt(valueBattery).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  normal_battery_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueBattery != null && valueBattery != undefined && isFinite(valueBattery) && normal_battery_rotate_string.length > 0 && normal_battery_rotate_string.length <= 3) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = RIGHT
                  let normal_battery_TextRotate_posOffset = normal_battery_TextRotate_img_width * normal_battery_rotate_string.length;
                  normal_battery_TextRotate_posOffset = normal_battery_TextRotate_posOffset + -1 * (normal_battery_rotate_string.length - 1);
                  img_offset -= normal_battery_TextRotate_posOffset;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_battery_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_battery_TextRotate[index].setProperty(hmUI.prop.POS_X, 92 + img_offset);
                      normal_battery_TextRotate[index].setProperty(hmUI.prop.SRC, normal_battery_TextRotate_ASCIIARRAY[charCode]);
                      normal_battery_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_battery_TextRotate_img_width + -1;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate step_STEP');
              let valueStep = step.current;
              let normal_step_rotate_string = parseInt(valueStep).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  normal_step_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueStep != null && valueStep != undefined && isFinite(valueStep) && normal_step_rotate_string.length > 0 && normal_step_rotate_string.length <= 5) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = RIGHT
                  let normal_step_TextRotate_posOffset = normal_step_TextRotate_img_width * normal_step_rotate_string.length;
                  img_offset -= normal_step_TextRotate_posOffset;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_step_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_step_TextRotate[index].setProperty(hmUI.prop.POS_X, 174 + img_offset);
                      normal_step_TextRotate[index].setProperty(hmUI.prop.SRC, normal_step_TextRotate_ASCIIARRAY[charCode]);
                      normal_step_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_step_TextRotate_img_width;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };
              let weatherData = weatherSensor.getForecastWeather();
              let temperature_current_temp = -100;
              if (weatherSensor.current != undefined && weatherSensor.current != 'undefined') {
                temperature_current_temp = weatherSensor.current;
              }; // end currentWeather;

              console.log('update text rotate temperature_current_currentWeather');
              let temperatureCurrent = undefined;
              let normal_temperature_current_rotate_string = undefined;
              if (temperature_current_temp > -100) {
                temperatureCurrent = 0;
                normal_temperature_current_rotate_string = String(temperature_current_temp)
              };

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 4; i++) {  // hide all symbols
                  normal_temperature_current_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (temperatureCurrent != null && temperatureCurrent != undefined && isFinite(temperatureCurrent) && normal_temperature_current_rotate_string.length > 0 && normal_temperature_current_rotate_string.length <= 4) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = RIGHT
                  let normal_temperature_current_TextRotate_posOffset = normal_temperature_current_TextRotate_img_width * normal_temperature_current_rotate_string.length;
                  img_offset -= normal_temperature_current_TextRotate_posOffset;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_temperature_current_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 4) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_temperature_current_TextRotate[index].setProperty(hmUI.prop.POS_X, 303 + img_offset);
                      normal_temperature_current_TextRotate[index].setProperty(hmUI.prop.SRC, normal_temperature_current_TextRotate_ASCIIARRAY[charCode]);
                      normal_temperature_current_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_temperature_current_TextRotate_img_width;
                      index++;
                    }  // end if digit
                    else { 
                      normal_temperature_current_TextRotate[index].setProperty(hmUI.prop.POS_X, 303 + img_offset);
                      normal_temperature_current_TextRotate[index].setProperty(hmUI.prop.SRC, '72num_10.png');
                      normal_temperature_current_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_temperature_current_TextRotate_dot_width;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate day_TIME');
              let valueDay = timeSensor.day;
              let normal_day_rotate_string = parseInt(valueDay).toString();
              normal_day_rotate_string = normal_day_rotate_string.padStart(2, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_day_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueDay != null && valueDay != undefined && isFinite(valueDay) && normal_day_rotate_string.length > 0 && normal_day_rotate_string.length <= 2) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let normal_day_TextRotate_posOffset = normal_day_TextRotate_img_width * normal_day_rotate_string.length;
                  img_offset -= normal_day_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_day_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_day_TextRotate[index].setProperty(hmUI.prop.POS_X, 102 + img_offset);
                      normal_day_TextRotate[index].setProperty(hmUI.prop.SRC, normal_day_TextRotate_ASCIIARRAY[charCode]);
                      normal_day_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_day_TextRotate_img_width;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate hour_TIME');
              let valueHour = timeSensor.format_hour;
              let normal_hour_rotate_string = parseInt(valueHour).toString();
              normal_hour_rotate_string = normal_hour_rotate_string.padStart(2, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_hour_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueHour != null && valueHour != undefined && isFinite(valueHour) && normal_hour_rotate_string.length > 0 && normal_hour_rotate_string.length <= 2) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of normal_hour_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_hour_TextRotate[index].setProperty(hmUI.prop.POS_X, 237 + img_offset);
                      normal_hour_TextRotate[index].setProperty(hmUI.prop.SRC, normal_hour_TextRotate_ASCIIARRAY[charCode]);
                      normal_hour_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_hour_TextRotate_img_width;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate minute_TIME');
              let valueMinute = timeSensor.minute;
              let normal_minute_rotate_string = parseInt(valueMinute).toString();
              normal_minute_rotate_string = normal_minute_rotate_string.padStart(2, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_minute_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueMinute != null && valueMinute != undefined && isFinite(valueMinute) && normal_minute_rotate_string.length > 0 && normal_minute_rotate_string.length <= 2) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of normal_minute_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_minute_TextRotate[index].setProperty(hmUI.prop.POS_X, 333 + img_offset);
                      normal_minute_TextRotate[index].setProperty(hmUI.prop.SRC, normal_minute_TextRotate_ASCIIARRAY[charCode]);
                      normal_minute_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_minute_TextRotate_img_width;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate second_TIME');
              let valueSecond = timeSensor.second;
              let normal_second_rotate_string = parseInt(valueSecond).toString();
              normal_second_rotate_string = normal_second_rotate_string.padStart(2, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_second_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueSecond != null && valueSecond != undefined && isFinite(valueSecond) && normal_second_rotate_string.length > 0 && normal_second_rotate_string.length <= 2) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of normal_second_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_second_TextRotate[index].setProperty(hmUI.prop.POS_X, 376 + img_offset);
                      normal_second_TextRotate[index].setProperty(hmUI.prop.SRC, normal_second_TextRotate_ASCIIARRAY[charCode]);
                      normal_second_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_second_TextRotate_img_width + -1;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate heart_rate_HEART');
              let idle_heart_rate_rotate_string = parseInt(valueHeartRate).toString();

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  idle_heart_rate_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueHeartRate != null && valueHeartRate != undefined && isFinite(valueHeartRate) && idle_heart_rate_rotate_string.length > 0 && idle_heart_rate_rotate_string.length <= 3) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = RIGHT
                  let idle_heart_rate_TextRotate_posOffset = idle_heart_rate_TextRotate_img_width * idle_heart_rate_rotate_string.length;
                  img_offset -= idle_heart_rate_TextRotate_posOffset;
                  // alignment end
                  
                  let index = 0;
                  for (let char of idle_heart_rate_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_heart_rate_TextRotate[index].setProperty(hmUI.prop.POS_X, 176 + img_offset);
                      idle_heart_rate_TextRotate[index].setProperty(hmUI.prop.SRC, idle_heart_rate_TextRotate_ASCIIARRAY[charCode]);
                      idle_heart_rate_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_heart_rate_TextRotate_img_width;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate battery_BATTERY');
              let idle_battery_rotate_string = parseInt(valueBattery).toString();

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  idle_battery_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueBattery != null && valueBattery != undefined && isFinite(valueBattery) && idle_battery_rotate_string.length > 0 && idle_battery_rotate_string.length <= 3) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = RIGHT
                  let idle_battery_TextRotate_posOffset = idle_battery_TextRotate_img_width * idle_battery_rotate_string.length;
                  idle_battery_TextRotate_posOffset = idle_battery_TextRotate_posOffset + -1 * (idle_battery_rotate_string.length - 1);
                  img_offset -= idle_battery_TextRotate_posOffset;
                  // alignment end
                  
                  let index = 0;
                  for (let char of idle_battery_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_battery_TextRotate[index].setProperty(hmUI.prop.POS_X, 92 + img_offset);
                      idle_battery_TextRotate[index].setProperty(hmUI.prop.SRC, idle_battery_TextRotate_ASCIIARRAY[charCode]);
                      idle_battery_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_battery_TextRotate_img_width + -1;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate step_STEP');
              let idle_step_rotate_string = parseInt(valueStep).toString();

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  idle_step_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueStep != null && valueStep != undefined && isFinite(valueStep) && idle_step_rotate_string.length > 0 && idle_step_rotate_string.length <= 5) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = RIGHT
                  let idle_step_TextRotate_posOffset = idle_step_TextRotate_img_width * idle_step_rotate_string.length;
                  img_offset -= idle_step_TextRotate_posOffset;
                  // alignment end
                  
                  let index = 0;
                  for (let char of idle_step_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_step_TextRotate[index].setProperty(hmUI.prop.POS_X, 174 + img_offset);
                      idle_step_TextRotate[index].setProperty(hmUI.prop.SRC, idle_step_TextRotate_ASCIIARRAY[charCode]);
                      idle_step_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_step_TextRotate_img_width;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate temperature_current_currentWeather');
              let idle_temperature_current_rotate_string = undefined;
              if (temperature_current_temp > -100) {
                temperatureCurrent = 0;
                idle_temperature_current_rotate_string = String(temperature_current_temp)
              };

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 4; i++) {  // hide all symbols
                  idle_temperature_current_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (temperatureCurrent != null && temperatureCurrent != undefined && isFinite(temperatureCurrent) && idle_temperature_current_rotate_string.length > 0 && idle_temperature_current_rotate_string.length <= 4) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = RIGHT
                  let idle_temperature_current_TextRotate_posOffset = idle_temperature_current_TextRotate_img_width * idle_temperature_current_rotate_string.length;
                  img_offset -= idle_temperature_current_TextRotate_posOffset;
                  // alignment end
                  
                  let index = 0;
                  for (let char of idle_temperature_current_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 4) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_temperature_current_TextRotate[index].setProperty(hmUI.prop.POS_X, 303 + img_offset);
                      idle_temperature_current_TextRotate[index].setProperty(hmUI.prop.SRC, idle_temperature_current_TextRotate_ASCIIARRAY[charCode]);
                      idle_temperature_current_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_temperature_current_TextRotate_img_width;
                      index++;
                    }  // end if digit
                    else { 
                      idle_temperature_current_TextRotate[index].setProperty(hmUI.prop.POS_X, 303 + img_offset);
                      idle_temperature_current_TextRotate[index].setProperty(hmUI.prop.SRC, '72num_10.png');
                      idle_temperature_current_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_temperature_current_TextRotate_dot_width;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate day_TIME');
              let idle_day_rotate_string = parseInt(valueDay).toString();
              idle_day_rotate_string = idle_day_rotate_string.padStart(2, '0');

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  idle_day_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueDay != null && valueDay != undefined && isFinite(valueDay) && idle_day_rotate_string.length > 0 && idle_day_rotate_string.length <= 2) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let idle_day_TextRotate_posOffset = idle_day_TextRotate_img_width * idle_day_rotate_string.length;
                  img_offset -= idle_day_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of idle_day_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_day_TextRotate[index].setProperty(hmUI.prop.POS_X, 102 + img_offset);
                      idle_day_TextRotate[index].setProperty(hmUI.prop.SRC, idle_day_TextRotate_ASCIIARRAY[charCode]);
                      idle_day_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_day_TextRotate_img_width;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate hour_TIME');
              let idle_hour_rotate_string = parseInt(valueHour).toString();
              idle_hour_rotate_string = idle_hour_rotate_string.padStart(2, '0');

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  idle_hour_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueHour != null && valueHour != undefined && isFinite(valueHour) && idle_hour_rotate_string.length > 0 && idle_hour_rotate_string.length <= 2) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of idle_hour_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_hour_TextRotate[index].setProperty(hmUI.prop.POS_X, 237 + img_offset);
                      idle_hour_TextRotate[index].setProperty(hmUI.prop.SRC, idle_hour_TextRotate_ASCIIARRAY[charCode]);
                      idle_hour_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_hour_TextRotate_img_width;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate minute_TIME');
              let idle_minute_rotate_string = parseInt(valueMinute).toString();
              idle_minute_rotate_string = idle_minute_rotate_string.padStart(2, '0');

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  idle_minute_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueMinute != null && valueMinute != undefined && isFinite(valueMinute) && idle_minute_rotate_string.length > 0 && idle_minute_rotate_string.length <= 2) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of idle_minute_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_minute_TextRotate[index].setProperty(hmUI.prop.POS_X, 333 + img_offset);
                      idle_minute_TextRotate[index].setProperty(hmUI.prop.SRC, idle_minute_TextRotate_ASCIIARRAY[charCode]);
                      idle_minute_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_minute_TextRotate_img_width;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

            };

            //end of ignored block
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                text_update();
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerTextUpdate) {
                    normal_timerTextUpdate = timer.createTimer(0, 1000, (function (option) {
                      text_update();
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.AOD) {
                  if (!idle_timerTextUpdate) {
                    idle_timerTextUpdate = timer.createTimer(0, 1000, (function (option) {
                      text_update();
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


                //SwitchBgColor
                if (hmFS.SysProGetInt(`bgColorIndex_${watchfaceId}`) === undefined) {
                  bgColorIndex = 0;
                  hmFS.SysProSetInt(`bgColorIndex_${watchfaceId}`, bgColorIndex);
                } else {
                  bgColorIndex = hmFS.SysProGetInt(`bgColorIndex_${watchfaceId}`);
                };
                if (screenType == hmSetting.screen_type.WATCHFACE && normal_background_bg) normal_background_bg.setProperty(hmUI.prop.COLOR, bgColorList[bgColorIndex]);
                if (screenType == hmSetting.screen_type.AOD && idle_background_bg) idle_background_bg.setProperty(hmUI.prop.COLOR, bgColorList[bgColorIndex]);
                weather_few_days();
              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerTextUpdate) {
                  timer.stopTimer(normal_timerTextUpdate);
                  normal_timerTextUpdate = undefined;
                }
                if (idle_timerTextUpdate) {
                  timer.stopTimer(idle_timerTextUpdate);
                  idle_timerTextUpdate = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
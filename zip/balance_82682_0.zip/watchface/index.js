﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_calorie_current_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_battery_text_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_image_img = ''
        let normal_date_img_date_day = ''
        let normal_dow_text_font = ''
        let normal_DOW_Array = ['LUNES', 'MARTES', 'MIERCOLES', 'JUEVES', 'VIERNES', 'SABADO', 'DOMINGO', ];
        let normal_digital_clock_img_time = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_minute_separator_img = ''
        let idle_image_img = ''
        let timeSensor = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            // FontName: a love of thunder.ttf; FontSize: 46; Cache: full
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 55,
              h: 55,
              text_size: 46,
              char_space: 0,
              line_space: 0,
              font: 'fonts/a love of thunder.ttf',
              color: 0xFF000000,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: '0001.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 167,
              y: 109,
              font_array: ["pulse_00011.png","pulse_00022.png","pulse_00033.png","pulse_00044.png","pulse_00055.png","pulse_00066.png","pulse_00077.png","pulse_00088.png","pulse_00099.png","pulse_001010.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 124,
              y: 416,
              font_array: ["temp_0001.png","temp_0002.png","temp_0003.png","temp_0004.png","temp_0005.png","temp_0006.png","temp_0007.png","temp_0008.png","temp_0009.png","temp_0010.png"],
              padding: false,
              h_space: -3,
              unit_sc: 'temp_0013.png',
              unit_tc: 'temp_0013.png',
              unit_en: 'temp_0013.png',
              negative_image: 'temp_0011.png',
              invalid_image: 'temp_0012.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 93,
              y: 364,
              image_array: ["weather_0001.png","weather_0002.png","weather_0003.png","weather_0004.png","weather_0005.png","weather_0006.png","weather_0007.png","weather_0008.png","weather_0009.png","weather_0010.png","weather_0011.png","weather_0012.png","weather_0013.png","weather_0014.png","weather_0015.png","weather_0016.png","weather_0017.png","weather_0018.png","weather_0019.png","weather_0020.png","weather_0021.png","weather_0022.png","weather_0023.png","weather_0024.png","weather_0025.png","weather_0026.png","weather_0027.png","weather_0028.png","weather_0029.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 267,
              y: 417,
              font_array: ["pulse_00011.png","pulse_00022.png","pulse_00033.png","pulse_00044.png","pulse_00055.png","pulse_00066.png","pulse_00077.png","pulse_00088.png","pulse_00099.png","pulse_001010.png"],
              padding: false,
              h_space: -5,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 380,
              y: 298,
              font_array: ["pulse_0001.png","pulse_0002.png","pulse_0003.png","pulse_0004.png","pulse_0005.png","pulse_0006.png","pulse_0007.png","pulse_0008.png","pulse_0009.png","pulse_0010.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 211,
              y: 340,
              font_array: ["steps_0001.png","steps_0002.png","steps_0003.png","steps_0004.png","steps_0005.png","steps_0006.png","steps_0007.png","steps_0008.png","steps_0009.png","steps_0010.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 210,
              y: 334,
              src: '0003.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 341,
              day_startY: 101,
              day_sc_array: ["temp_0001.png","temp_0002.png","temp_0003.png","temp_0004.png","temp_0005.png","temp_0006.png","temp_0007.png","temp_0008.png","temp_0009.png","temp_0010.png"],
              day_tc_array: ["temp_0001.png","temp_0002.png","temp_0003.png","temp_0004.png","temp_0005.png","temp_0006.png","temp_0007.png","temp_0008.png","temp_0009.png","temp_0010.png"],
              day_en_array: ["temp_0001.png","temp_0002.png","temp_0003.png","temp_0004.png","temp_0005.png","temp_0006.png","temp_0007.png","temp_0008.png","temp_0009.png","temp_0010.png"],
              day_zero: 1,
              day_space: -3,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function() {
              time_update(true);
            });

            normal_dow_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 108,
              y: 34,
              w: 265,
              h: 53,
              text_size: 46,
              char_space: 0,
              line_space: 0,
              font: 'fonts/a love of thunder.ttf',
              color: 0xFF000000,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              // unit_string: LUNES, MARTES, MIERCOLES, JUEVES, VIERNES, SABADO, DOMINGO,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 56,
              hour_startY: 176,
              hour_array: ["min_0001.png","min_0002.png","min_0003.png","min_0004.png","min_0005.png","min_0006.png","min_0007.png","min_0008.png","min_0009.png","min_0010.png"],
              hour_zero: 1,
              hour_space: -5,
              hour_angle: 0,
              hour_align: hmUI.align.RIGHT,

              minute_startX: 236,
              minute_startY: 176,
              minute_array: ["min_0001.png","min_0002.png","min_0003.png","min_0004.png","min_0005.png","min_0006.png","min_0007.png","min_0008.png","min_0009.png","min_0010.png"],
              minute_zero: 1,
              minute_space: -5,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 201,
              second_startY: 174,
              second_array: ["sep_0001.png","sep_0002.png","sep_0003.png","sep_0004.png","sep_0005.png","sep_0006.png","sep_0007.png","sep_0008.png","sep_0009.png","sep_0010.png"],
              second_zero: 0,
              second_space: -37,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: '0600.png',
              second_centerX: 431,
              second_centerY: 224,
              second_posX: 12,
              second_posY: 42,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 94,
              hour_startY: 197,
              hour_array: ["aod_0001.png","aod_0002.png","aod_0003.png","aod_0004.png","aod_0005.png","aod_0006.png","aod_0007.png","aod_0008.png","aod_0009.png","aod_0010.png"],
              hour_zero: 1,
              hour_space: -3,
              hour_angle: 0,
              hour_unit_sc: 'aod_0011.png',
              hour_unit_tc: 'aod_0011.png',
              hour_unit_en: 'aod_0011.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 256,
              minute_startY: 197,
              minute_array: ["aod_0001.png","aod_0002.png","aod_0003.png","aod_0004.png","aod_0005.png","aod_0006.png","aod_0007.png","aod_0008.png","aod_0009.png","aod_0010.png"],
              minute_zero: 1,
              minute_space: -3,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_minute_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: '1000.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'aodblend.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            let screenType = hmSetting.getScreenType();
            //start of ignored block
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              console.log('day of week font');
              if (updateHour) {
                let normal_DOW_Str = normal_DOW_Array[timeSensor.week-1];
                normal_dow_text_font.setProperty(hmUI.prop.TEXT, normal_DOW_Str );
              };

            };

            //end of ignored block
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                time_update(true, true);
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
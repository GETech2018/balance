﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

		let colornumber_main = 1
		let button_color1 = ''
		let button_color2 = ''
		let button_color3 = ''
		let button_color4 = ''
		let button_color5 = ''
		let button_color6 = ''
		let button_color7 = ''
		let button_color8 = ''
		let button_color9 = ''
		let button_color10 = ''
		let button_color11 = ''
		let button_color12 = ''
		let button_color13 = ''
		let button_color14 = ''
		let button_color15 = ''
		let button_color16 = ''
		
		function click_COLOR() {
			
			normal_stress_icon_img.setProperty(hmUI.prop.VISIBLE, true);
			button_color1.setProperty(hmUI.prop.VISIBLE, true);
			button_color2.setProperty(hmUI.prop.VISIBLE, true);
			button_color3.setProperty(hmUI.prop.VISIBLE, true);
			button_color4.setProperty(hmUI.prop.VISIBLE, true);
			button_color5.setProperty(hmUI.prop.VISIBLE, true);
			button_color6.setProperty(hmUI.prop.VISIBLE, true);
			button_color7.setProperty(hmUI.prop.VISIBLE, true);
			button_color8.setProperty(hmUI.prop.VISIBLE, true);
			button_color9.setProperty(hmUI.prop.VISIBLE, true);
			button_color10.setProperty(hmUI.prop.VISIBLE, true);
			button_color11.setProperty(hmUI.prop.VISIBLE, true);
			button_color12.setProperty(hmUI.prop.VISIBLE, true);
			button_color13.setProperty(hmUI.prop.VISIBLE, true);
			button_color14.setProperty(hmUI.prop.VISIBLE, true);
			button_color15.setProperty(hmUI.prop.VISIBLE, true);
			button_color16.setProperty(hmUI.prop.VISIBLE, true);
			Button_2.setProperty(hmUI.prop.VISIBLE, false);
			Button_3.setProperty(hmUI.prop.VISIBLE, false);
			Button_4.setProperty(hmUI.prop.VISIBLE, false);
			Button_5.setProperty(hmUI.prop.VISIBLE, false);
			Button_6.setProperty(hmUI.prop.VISIBLE, false);
			Button_7.setProperty(hmUI.prop.VISIBLE, false);
			Button_8.setProperty(hmUI.prop.VISIBLE, false);
			Button_9.setProperty(hmUI.prop.VISIBLE, false);
			Button_10.setProperty(hmUI.prop.VISIBLE, false);
			Button_11.setProperty(hmUI.prop.VISIBLE, false);
			Button_12.setProperty(hmUI.prop.VISIBLE, false);
			Button_13.setProperty(hmUI.prop.VISIBLE, false);
			Button_14.setProperty(hmUI.prop.VISIBLE, false);
			Button_15.setProperty(hmUI.prop.VISIBLE, false);
			Button_16.setProperty(hmUI.prop.VISIBLE, false);
            hmUI.showToast({text: 'CHOOSE YOUR BACKGROUND'});
        }

        function CHOOSE_COLOR(){
			
			normal_image_img.setProperty(hmUI.prop.SRC, "color" + parseInt(colornumber_main) + ".png");
			normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.SRC, "hand_sec" + parseInt(colornumber_main) + ".png");
			
			setTimeout(function(){
			normal_stress_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			button_color1.setProperty(hmUI.prop.VISIBLE, false);
			button_color2.setProperty(hmUI.prop.VISIBLE, false);
			button_color3.setProperty(hmUI.prop.VISIBLE, false);
			button_color4.setProperty(hmUI.prop.VISIBLE, false);
			button_color5.setProperty(hmUI.prop.VISIBLE, false);
			button_color6.setProperty(hmUI.prop.VISIBLE, false);
			button_color7.setProperty(hmUI.prop.VISIBLE, false);
			button_color8.setProperty(hmUI.prop.VISIBLE, false);
			button_color9.setProperty(hmUI.prop.VISIBLE, false);
			button_color10.setProperty(hmUI.prop.VISIBLE, false);
			button_color11.setProperty(hmUI.prop.VISIBLE, false);
			button_color12.setProperty(hmUI.prop.VISIBLE, false);
			button_color13.setProperty(hmUI.prop.VISIBLE, false);
			button_color14.setProperty(hmUI.prop.VISIBLE, false);
			button_color15.setProperty(hmUI.prop.VISIBLE, false);
			button_color16.setProperty(hmUI.prop.VISIBLE, false);
			Button_2.setProperty(hmUI.prop.VISIBLE, true);
			Button_3.setProperty(hmUI.prop.VISIBLE, true);
			Button_4.setProperty(hmUI.prop.VISIBLE, true);
			Button_5.setProperty(hmUI.prop.VISIBLE, true);
			Button_6.setProperty(hmUI.prop.VISIBLE, true);
			Button_7.setProperty(hmUI.prop.VISIBLE, true);
			Button_8.setProperty(hmUI.prop.VISIBLE, true);
			Button_9.setProperty(hmUI.prop.VISIBLE, true);
			Button_10.setProperty(hmUI.prop.VISIBLE, true);
			Button_11.setProperty(hmUI.prop.VISIBLE, true);
			Button_12.setProperty(hmUI.prop.VISIBLE, true);
			Button_13.setProperty(hmUI.prop.VISIBLE, true);
			Button_14.setProperty(hmUI.prop.VISIBLE, true);
			Button_15.setProperty(hmUI.prop.VISIBLE, true);
			Button_16.setProperty(hmUI.prop.VISIBLE, true);
			}, 1200);
		}
		
		function click_COLOR1() {
            colornumber_main=1;
			hmUI.showToast({text: 'O R A N G E'});
			CHOOSE_COLOR();
        }
		
		function click_COLOR2() {
            colornumber_main=2;
			hmUI.showToast({text: 'T E A L'});
			CHOOSE_COLOR();
        }
		
		function click_COLOR3() {
            colornumber_main=3;
			hmUI.showToast({text: 'O L I V E'});
			CHOOSE_COLOR();
        }
		
		function click_COLOR4() {
            colornumber_main=4;
			hmUI.showToast({text: 'M A R O O N'});
			CHOOSE_COLOR();
        }
		
		function click_COLOR5() {
            colornumber_main=5;
			hmUI.showToast({text: 'A Q U A'});
			CHOOSE_COLOR();
        }
		
		function click_COLOR6() {
            colornumber_main=6;
			hmUI.showToast({text: 'G R E E N'});
			CHOOSE_COLOR();
        }
		
		function click_COLOR7() {
            colornumber_main=7;
			hmUI.showToast({text: 'R E D'});
			CHOOSE_COLOR();
        }
		
		function click_COLOR8() {
            colornumber_main=8;
			hmUI.showToast({text: 'Y E L L O W'});
			CHOOSE_COLOR();
        }
		
		function click_COLOR9() {
            colornumber_main=9;
			hmUI.showToast({text: 'L I M E'});
			CHOOSE_COLOR();
        }
		
		function click_COLOR10() {
            colornumber_main=10;
			hmUI.showToast({text: 'P U R P L E'});
			CHOOSE_COLOR();
        }
		
		function click_COLOR11() {
            colornumber_main=11;
			hmUI.showToast({text: 'B L U E'});
			CHOOSE_COLOR();
        }
		
		function click_COLOR12() {
            colornumber_main=12;
			hmUI.showToast({text: 'F U C H S I A'});
			CHOOSE_COLOR();
        }
		
		function click_COLOR13() {
            colornumber_main=13;
			hmUI.showToast({text: 'S E P I A'});
			CHOOSE_COLOR();
        }
		
		function click_COLOR14() {
            colornumber_main=14;
			hmUI.showToast({text: 'A M B E R'});
			CHOOSE_COLOR();
        }
		
		function click_COLOR15() {
            colornumber_main=15;
			hmUI.showToast({text: 'S I L V E R'});
			CHOOSE_COLOR();
        }
		
		function click_COLOR16() {
            colornumber_main=16;
			hmUI.showToast({text: 'W H I T E'});
			CHOOSE_COLOR();
        }
        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_analog_clock_pro_second_pointer_img = ''
        let normal_timerUpdateSecSmooth = undefined;
        let lastTime = 0;
        let normal_spo2_icon_img = ''
        let normal_image_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_high_text_img = ''
        let normal_temperature_low_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_sun_current_text_img = ''
        let normal_battery_circle_scale = ''
        let normal_battery_icon_img = ''
        let normal_battery_text_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_distance_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_step_circle_scale = ''
        let normal_step_icon_img = ''
        let normal_calorie_circle_scale = ''
        let normal_calorie_icon_img = ''
        let normal_calorie_current_text_img = ''
        let normal_system_disconnect_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let normal_stress_icon_img = ''
        let idle_background_bg_img = ''
        let idle_battery_circle_scale = ''
        let idle_battery_icon_img = ''
        let idle_battery_text_text_img = ''
        let idle_heart_rate_text_text_img = ''
        let idle_distance_text_text_img = ''
        let idle_step_current_text_img = ''
        let idle_step_circle_scale = ''
        let idle_step_icon_img = ''
        let idle_calorie_circle_scale = ''
        let idle_calorie_icon_img = ''
        let idle_calorie_current_text_img = ''
        let idle_system_disconnect_img = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let Button_7 = ''
        let Button_8 = ''
        let Button_9 = ''
        let Button_10 = ''
        let Button_11 = ''
        let Button_12 = ''
        let Button_13 = ''
        let Button_14 = ''
        let Button_15 = ''
        let Button_16 = ''
        let timeSensor = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            const deviceInfo = hmSetting.getDeviceInfo();
            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'hand_sec1.png',
              // center_x: 240,
              // center_y: 240,
              // x: 240,
              // y: 240,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 240,
              pos_y: 240 - 240,
              center_x: 240,
              center_y: 240,
              src: 'hand_sec1.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            function startSecAnim(sec, animDuration) {
              const secAnim = {
                anim_steps: [{
                  anim_rate: 'linear',
                  anim_duration: animDuration,
                  anim_from: sec,
                  anim_to: sec + (360*(animDuration*6/1000))/360,
                  anim_key: 'angle',
                }],
                anim_fps: 15,
                anim_auto_start: 1,
                anim_repeat: 1,
                anim_auto_destroy: 1,
              }
              normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANIM, secAnim);
            }
            // normal_analog_clock_pro_smooth_second = hmUI.createWidget(hmUI.widget.SMOOTH_SECOND, {
              // type: 4,
              // fps: 15,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_spo2_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'mask.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'color1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 44,
              y: 168,
              image_array: ["weather_01.png","weather_02.png","weather_03.png","weather_04.png","weather_05.png","weather_06.png","weather_07.png","weather_08.png","weather_09.png","weather_10.png","weather_11.png","weather_12.png","weather_13.png","weather_14.png","weather_15.png","weather_16.png","weather_17.png","weather_18.png","weather_19.png","weather_20.png","weather_21.png","weather_22.png","weather_23.png","weather_24.png","weather_25.png","weather_26.png","weather_27.png","weather_28.png","weather_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 199,
              y: 200,
              font_array: ["d20_00.png","d20_01.png","d20_02.png","d20_03.png","d20_04.png","d20_05.png","d20_06.png","d20_07.png","d20_08.png","d20_09.png"],
              padding: false,
              h_space: -2,
              unit_sc: 'd20_12.png',
              unit_tc: 'd20_12.png',
              unit_en: 'd20_12.png',
              imperial_unit_sc: 'd20_13.png',
              imperial_unit_tc: 'd20_13.png',
              imperial_unit_en: 'd20_13.png',
              negative_image: 'd20_11.png',
              invalid_image: 'd20_10.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const temperatureUnit = hmSetting.getTemperatureUnit();
            //start of ignored block
            if (temperatureUnit == 1) {
              normal_temperature_high_text_img.setProperty(hmUI.prop.MORE, {
                x: 199,
                y: 200,
                font_array: ["d20_00.png","d20_01.png","d20_02.png","d20_03.png","d20_04.png","d20_05.png","d20_06.png","d20_07.png","d20_08.png","d20_09.png"],
                padding: false,
                h_space: -2,
                unit_sc: 'd20_13.png',
                unit_tc: 'd20_13.png',
                unit_en: 'd20_13.png',
                imperial_unit_sc: 'd20_12.png',
                imperial_unit_tc: 'd20_12.png',
                imperial_unit_en: 'd20_12.png',
                negative_image: 'd20_11.png',
                invalid_image: 'd20_10.png',
                align_h: hmUI.align.RIGHT,
                type: hmUI.data_type.WEATHER_HIGH,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
            };
            //end of ignored block

            normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 195,
              y: 221,
              font_array: ["d20_00.png","d20_01.png","d20_02.png","d20_03.png","d20_04.png","d20_05.png","d20_06.png","d20_07.png","d20_08.png","d20_09.png"],
              padding: false,
              h_space: -2,
              unit_sc: 'd20_12.png',
              unit_tc: 'd20_12.png',
              unit_en: 'd20_12.png',
              imperial_unit_sc: 'd20_13.png',
              imperial_unit_tc: 'd20_13.png',
              imperial_unit_en: 'd20_13.png',
              negative_image: 'd20_11.png',
              invalid_image: 'd20_10.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            //start of ignored block
            if (temperatureUnit == 1) {
              normal_temperature_low_text_img.setProperty(hmUI.prop.MORE, {
                x: 195,
                y: 221,
                font_array: ["d20_00.png","d20_01.png","d20_02.png","d20_03.png","d20_04.png","d20_05.png","d20_06.png","d20_07.png","d20_08.png","d20_09.png"],
                padding: false,
                h_space: -2,
                unit_sc: 'd20_13.png',
                unit_tc: 'd20_13.png',
                unit_en: 'd20_13.png',
                imperial_unit_sc: 'd20_12.png',
                imperial_unit_tc: 'd20_12.png',
                imperial_unit_en: 'd20_12.png',
                negative_image: 'd20_11.png',
                invalid_image: 'd20_10.png',
                align_h: hmUI.align.RIGHT,
                type: hmUI.data_type.WEATHER_LOW,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
            };
            //end of ignored block

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 88,
              y: 208,
              font_array: ["d30_00.png","d30_01.png","d30_02.png","d30_03.png","d30_04.png","d30_05.png","d30_06.png","d30_07.png","d30_08.png","d30_09.png"],
              padding: false,
              h_space: -2,
              unit_sc: 'd30_11.png',
              unit_tc: 'd30_11.png',
              unit_en: 'd30_11.png',
              imperial_unit_sc: 'd30_12.png',
              imperial_unit_tc: 'd30_12.png',
              imperial_unit_en: 'd30_12.png',
              negative_image: 'd30_13.png',
              invalid_image: 'd30_10.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            //start of ignored block
            if (temperatureUnit == 1) {
              normal_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
                x: 88,
                y: 208,
                font_array: ["d30_00.png","d30_01.png","d30_02.png","d30_03.png","d30_04.png","d30_05.png","d30_06.png","d30_07.png","d30_08.png","d30_09.png"],
                padding: false,
                h_space: -2,
                unit_sc: 'd30_12.png',
                unit_tc: 'd30_12.png',
                unit_en: 'd30_12.png',
                imperial_unit_sc: 'd30_11.png',
                imperial_unit_tc: 'd30_11.png',
                imperial_unit_en: 'd30_11.png',
                negative_image: 'd30_13.png',
                invalid_image: 'd30_10.png',
                align_h: hmUI.align.RIGHT,
                type: hmUI.data_type.WEATHER_CURRENT,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
            };
            //end of ignored block

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 224,
              day_startY: 260,
              day_sc_array: ["d30_00.png","d30_01.png","d30_02.png","d30_03.png","d30_04.png","d30_05.png","d30_06.png","d30_07.png","d30_08.png","d30_09.png"],
              day_tc_array: ["d30_00.png","d30_01.png","d30_02.png","d30_03.png","d30_04.png","d30_05.png","d30_06.png","d30_07.png","d30_08.png","d30_09.png"],
              day_en_array: ["d30_00.png","d30_01.png","d30_02.png","d30_03.png","d30_04.png","d30_05.png","d30_06.png","d30_07.png","d30_08.png","d30_09.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 75,
              y: 244,
              week_en: ["wd1.png","wd2.png","wd3.png","wd4.png","wd5.png","wd6.png","wd7.png"],
              week_tc: ["wd1.png","wd2.png","wd3.png","wd4.png","wd5.png","wd6.png","wd7.png"],
              week_sc: ["wd1.png","wd2.png","wd3.png","wd4.png","wd5.png","wd6.png","wd7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 140,
              month_startY: 260,
              month_sc_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_tc_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_en_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 215,
              y: 93,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 199,
              y: 17,
              font_array: ["l20_00.png","l20_01.png","l20_02.png","l20_03.png","l20_04.png","l20_05.png","l20_06.png","l20_07.png","l20_08.png","l20_09.png"],
              padding: false,
              h_space: 0,
              dot_image: 'l20_10.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 337,
              // center_y: 88,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 52,
              // line_width: 10,
              // line_cap: Flat,
              // color: 0xFF000000,
              // mirror: False,
              // inversion: True,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 337,
              center_y: 88,
              start_angle: 360,
              end_angle: 0,
              radius: 47,
              line_width: 10,
              corner_flag: 3,
              color: 0xFF000000,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'top_batt.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 302,
              y: 92,
              font_array: ["l20_00.png","l20_01.png","l20_02.png","l20_03.png","l20_04.png","l20_05.png","l20_06.png","l20_07.png","l20_08.png","l20_09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'l20_11.png',
              unit_tc: 'l20_11.png',
              unit_en: 'l20_11.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 201,
              y: 297,
              font_array: ["l24_00.png","l24_01.png","l24_02.png","l24_03.png","l24_04.png","l24_05.png","l24_06.png","l24_07.png","l24_08.png","l24_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 201,
              y: 347,
              image_array: ["hr1.png","hr2.png","hr3.png","hr4.png","hr5.png","hr6.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 58,
              y: 310,
              font_array: ["l24_00.png","l24_01.png","l24_02.png","l24_03.png","l24_04.png","l24_05.png","l24_06.png","l24_07.png","l24_08.png","l24_09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'l24_10.png',
              unit_tc: 'l24_10.png',
              unit_en: 'l24_10.png',
              imperial_unit_sc: 'l24_11.png',
              imperial_unit_tc: 'l24_11.png',
              imperial_unit_en: 'l24_11.png',
              dot_image: 'l24_12.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 88,
              y: 348,
              font_array: ["l20_00.png","l20_01.png","l20_02.png","l20_03.png","l20_04.png","l20_05.png","l20_06.png","l20_07.png","l20_08.png","l20_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 181,
              // center_y: 402,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 38,
              // line_width: 7,
              // line_cap: Rounded,
              // color: 0xFF000000,
              // mirror: False,
              // inversion: True,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 181,
              center_y: 402,
              start_angle: 360,
              end_angle: 0,
              radius: 35,
              line_width: 7,
              corner_flag: 0,
              color: 0xFF000000,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'top_step.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_cal_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 139,
              // center_y: 101,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 57,
              // line_width: 12,
              // line_cap: Flat,
              // color: 0xFF000000,
              // mirror: False,
              // inversion: True,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_calorie_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 139,
              center_y: 101,
              start_angle: 360,
              end_angle: 0,
              radius: 51,
              line_width: 12,
              corner_flag: 3,
              color: 0xFF000000,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const calorie = hmSensor.createSensor(hmSensor.id.CALORIE);
            calorie.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'top_cal.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 98,
              y: 106,
              font_array: ["l24_00.png","l24_01.png","l24_02.png","l24_03.png","l24_04.png","l24_05.png","l24_06.png","l24_07.png","l24_08.png","l24_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 48,
              y: 117,
              src: 'bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 0,
              am_y: 0,
              am_sc_path: 'time_am.png',
              am_en_path: 'time_am.png',
              pm_x: 0,
              pm_y: 0,
              pm_sc_path: 'time_pm.png',
              pm_en_path: 'time_pm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 306,
              hour_startY: 174,
              hour_array: ["time_00.png","time_01.png","time_02.png","time_03.png","time_04.png","time_05.png","time_06.png","time_07.png","time_08.png","time_09.png"],
              hour_zero: 1,
              hour_space: -10,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 290,
              minute_startY: 290,
              minute_array: ["time_00.png","time_01.png","time_02.png","time_03.png","time_04.png","time_05.png","time_06.png","time_07.png","time_08.png","time_09.png"],
              minute_zero: 1,
              minute_space: -10,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 389,
              second_startY: 265,
              second_array: ["sec_00.png","sec_01.png","sec_02.png","sec_03.png","sec_04.png","sec_05.png","sec_06.png","sec_07.png","sec_08.png","sec_09.png"],
              second_zero: 1,
              second_space: -22,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'Theme_Picker.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'aod_bg.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 337,
              // center_y: 88,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 52,
              // line_width: 10,
              // line_cap: Flat,
              // color: 0xFF808080,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 337,
              center_y: 88,
              start_angle: 0,
              end_angle: 360,
              radius: 47,
              line_width: 10,
              corner_flag: 3,
              color: 0xFF808080,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'top_batt.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 302,
              y: 92,
              font_array: ["l20_00.png","l20_01.png","l20_02.png","l20_03.png","l20_04.png","l20_05.png","l20_06.png","l20_07.png","l20_08.png","l20_09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'l20_11.png',
              unit_tc: 'l20_11.png',
              unit_en: 'l20_11.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 201,
              y: 310,
              font_array: ["l24_00.png","l24_01.png","l24_02.png","l24_03.png","l24_04.png","l24_05.png","l24_06.png","l24_07.png","l24_08.png","l24_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 58,
              y: 310,
              font_array: ["l24_00.png","l24_01.png","l24_02.png","l24_03.png","l24_04.png","l24_05.png","l24_06.png","l24_07.png","l24_08.png","l24_09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'l24_10.png',
              unit_tc: 'l24_10.png',
              unit_en: 'l24_10.png',
              imperial_unit_sc: 'l24_11.png',
              imperial_unit_tc: 'l24_11.png',
              imperial_unit_en: 'l24_11.png',
              dot_image: 'l24_12.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 88,
              y: 348,
              font_array: ["l20_00.png","l20_01.png","l20_02.png","l20_03.png","l20_04.png","l20_05.png","l20_06.png","l20_07.png","l20_08.png","l20_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 181,
              // center_y: 402,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 38,
              // line_width: 7,
              // line_cap: Rounded,
              // color: 0xFF808080,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 181,
              center_y: 402,
              start_angle: 0,
              end_angle: 360,
              radius: 35,
              line_width: 7,
              corner_flag: 0,
              color: 0xFF808080,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'aod_top.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_cal_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 139,
              // center_y: 101,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 57,
              // line_width: 12,
              // line_cap: Flat,
              // color: 0xFF808080,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_calorie_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 139,
              center_y: 101,
              start_angle: 0,
              end_angle: 360,
              radius: 51,
              line_width: 12,
              corner_flag: 3,
              color: 0xFF808080,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'top_cal.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 98,
              y: 106,
              font_array: ["l24_00.png","l24_01.png","l24_02.png","l24_03.png","l24_04.png","l24_05.png","l24_06.png","l24_07.png","l24_08.png","l24_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 48,
              y: 117,
              src: 'bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 0,
              am_y: 0,
              am_sc_path: 'time_am.png',
              am_en_path: 'time_am.png',
              pm_x: 0,
              pm_y: 0,
              pm_sc_path: 'time_pm.png',
              pm_en_path: 'time_pm.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 306,
              hour_startY: 174,
              hour_array: ["time_00.png","time_01.png","time_02.png","time_03.png","time_04.png","time_05.png","time_06.png","time_07.png","time_08.png","time_09.png"],
              hour_zero: 1,
              hour_space: -10,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 290,
              minute_startY: 290,
              minute_array: ["time_00.png","time_01.png","time_02.png","time_03.png","time_04.png","time_05.png","time_06.png","time_07.png","time_08.png","time_09.png"],
              minute_zero: 1,
              minute_space: -10,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 305,
              y: 410,
              w: 50,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                				click_COLOR();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 42,
              y: 110,
              w: 40,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'FindPhoneScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 300,
              y: 305,
              w: 80,
              h: 80,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'CountdownAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 315,
              y: 189,
              w: 80,
              h: 80,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'TomatoMainScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 395,
              y: 260,
              w: 60,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'StopWatchScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 45,
              y: 189,
              w: 100,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'BaroAltimeterScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_7 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 155,
              y: 189,
              w: 120,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'WeatherScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_8 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 155,
              y: 242,
              w: 120,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_9 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 75,
              y: 315,
              w: 100,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'activityAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_10 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 35,
              y: 255,
              w: 50,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'SportStatusScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_11 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 150,
              y: 370,
              w: 65,
              h: 65,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'SportListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_12 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 195,
              y: 295,
              w: 75,
              h: 75,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'heart_app_Screen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_13 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 95,
              y: 55,
              w: 90,
              h: 90,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PAI_app_Screen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_14 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 295,
              y: 45,
              w: 85,
              h: 85,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PowerSaveHintScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_15 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 205,
              y: 85,
              w: 70,
              h: 70,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'Sleep_HomeScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_16 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 200,
              y: 15,
              w: 80,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'TideScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            console.log('user_script_end.js');
            // start user_script_end.js

			button_color1 = hmUI.createWidget(hmUI.widget.BUTTON, {
			  x: 95,
              y: 95,
              w: 65,
              h: 65,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                click_COLOR1();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button
			
			button_color2 = hmUI.createWidget(hmUI.widget.BUTTON, {
			  x: 170,
              y: 95,
              w: 65,
              h: 65,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                click_COLOR2();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button
			
			button_color3 = hmUI.createWidget(hmUI.widget.BUTTON, {
			  x: 245,
              y: 95,
              w: 65,
              h: 65,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                click_COLOR3();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button
			
			button_color4 = hmUI.createWidget(hmUI.widget.BUTTON, {
			  x: 320,
              y: 95,
              w: 65,
              h: 65,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                click_COLOR4();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button
			
			button_color5 = hmUI.createWidget(hmUI.widget.BUTTON, {
			  x: 95,
              y: 170,
              w: 65,
              h: 65,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                click_COLOR5();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button
			
			button_color6 = hmUI.createWidget(hmUI.widget.BUTTON, {
			  x: 170,
              y: 170,
              w: 65,
              h: 65,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                click_COLOR6();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button
			
			button_color7 = hmUI.createWidget(hmUI.widget.BUTTON, {
			  x: 245,
              y: 170,
              w: 65,
              h: 65,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                click_COLOR7();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button
			
			button_color8 = hmUI.createWidget(hmUI.widget.BUTTON, {
			  x: 320,
              y: 170,
              w: 65,
              h: 65,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                click_COLOR8();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button
			
			button_color9 = hmUI.createWidget(hmUI.widget.BUTTON, {
			  x: 95,
              y: 245,
              w: 65,
              h: 65,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                click_COLOR9();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button
			
			button_color10 = hmUI.createWidget(hmUI.widget.BUTTON, {
			  x: 170,
              y: 245,
              w: 65,
              h: 65,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                click_COLOR10();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button
			
			button_color11 = hmUI.createWidget(hmUI.widget.BUTTON, {
			  x: 245,
              y: 245,
              w: 65,
              h: 65,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                click_COLOR11();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button
			
			button_color12 = hmUI.createWidget(hmUI.widget.BUTTON, {
			  x: 320,
              y: 245,
              w: 65,
              h: 65,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                click_COLOR12();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button
			
			button_color13 = hmUI.createWidget(hmUI.widget.BUTTON, {
			  x: 95,
              y: 320,
              w: 65,
              h: 65,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                click_COLOR13();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button
			
			button_color14 = hmUI.createWidget(hmUI.widget.BUTTON, {
			  x: 170,
              y: 320,
              w: 65,
              h: 65,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                click_COLOR14();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button
			
			button_color15 = hmUI.createWidget(hmUI.widget.BUTTON, {
			  x: 245,
              y: 320,
              w: 65,
              h: 65,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                click_COLOR15();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button
			
			button_color16 = hmUI.createWidget(hmUI.widget.BUTTON, {
			  x: 320,
              y: 320,
              w: 65,
              h: 65,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                click_COLOR16();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button
			
			let cc = 0
			if (cc ==0 ){
			normal_stress_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			button_color1.setProperty(hmUI.prop.VISIBLE, false);
			button_color2.setProperty(hmUI.prop.VISIBLE, false);
			button_color3.setProperty(hmUI.prop.VISIBLE, false);
			button_color4.setProperty(hmUI.prop.VISIBLE, false);
			button_color5.setProperty(hmUI.prop.VISIBLE, false);
			button_color6.setProperty(hmUI.prop.VISIBLE, false);
			button_color7.setProperty(hmUI.prop.VISIBLE, false);
			button_color8.setProperty(hmUI.prop.VISIBLE, false);
			button_color9.setProperty(hmUI.prop.VISIBLE, false);
			button_color10.setProperty(hmUI.prop.VISIBLE, false);
			button_color11.setProperty(hmUI.prop.VISIBLE, false);
			button_color12.setProperty(hmUI.prop.VISIBLE, false);
			button_color13.setProperty(hmUI.prop.VISIBLE, false);
			button_color14.setProperty(hmUI.prop.VISIBLE, false);
			button_color15.setProperty(hmUI.prop.VISIBLE, false);
			button_color16.setProperty(hmUI.prop.VISIBLE, false);
			cc = 1;
			}
            // end user_script_end.js

            function scale_call() {
              console.log('scale_call()');

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_cs_normal_battery = 1 - progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_battery * 100);
                  if (normal_battery_circle_scale) {
                    normal_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 337,
                      center_y: 88,
                      start_angle: 360,
                      end_angle: 0,
                      radius: 47,
                      line_width: 10,
                      corner_flag: 3,
                      color: 0xFF000000,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_cs_normal_step = 1 - progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_step * 100);
                  if (normal_step_circle_scale) {
                    normal_step_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 181,
                      center_y: 402,
                      start_angle: 360,
                      end_angle: 0,
                      radius: 35,
                      line_width: 7,
                      corner_flag: 0,
                      color: 0xFF000000,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales CALORIE');
                
                let valueCalories = calorie.current;
                let targetCalories = calorie.target;
                let progressCalories = valueCalories/targetCalories;
                if (progressCalories > 1) progressCalories = 1;
                let progress_cs_normal_calorie = 1 - progressCalories;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_calorie_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_calorie * 100);
                  if (normal_calorie_circle_scale) {
                    normal_calorie_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 139,
                      center_y: 101,
                      start_angle: 360,
                      end_angle: 0,
                      radius: 51,
                      line_width: 12,
                      corner_flag: 3,
                      color: 0xFF000000,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales BATTERY');
                let progress_cs_idle_battery = progressBattery;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_battery_circle_scale_circle_scale
                  let level = Math.round(progress_cs_idle_battery * 100);
                  if (idle_battery_circle_scale) {
                    idle_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 337,
                      center_y: 88,
                      start_angle: 0,
                      end_angle: 360,
                      radius: 47,
                      line_width: 10,
                      corner_flag: 3,
                      color: 0xFF808080,
                      show_level: hmUI.show_level.ONLY_AOD,
                      level: level,
                    });
                  };
                };

                console.log('update scales STEP');
                let progress_cs_idle_step = progressStep;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_step_circle_scale_circle_scale
                  let level = Math.round(progress_cs_idle_step * 100);
                  if (idle_step_circle_scale) {
                    idle_step_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 181,
                      center_y: 402,
                      start_angle: 0,
                      end_angle: 360,
                      radius: 35,
                      line_width: 7,
                      corner_flag: 0,
                      color: 0xFF808080,
                      show_level: hmUI.show_level.ONLY_AOD,
                      level: level,
                    });
                  };
                };

                console.log('update scales CALORIE');
                let progress_cs_idle_calorie = progressCalories;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_calorie_circle_scale_circle_scale
                  let level = Math.round(progress_cs_idle_calorie * 100);
                  if (idle_calorie_circle_scale) {
                    idle_calorie_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 139,
                      center_y: 101,
                      start_angle: 0,
                      end_angle: 360,
                      radius: 51,
                      line_width: 12,
                      corner_flag: 3,
                      color: 0xFF808080,
                      show_level: hmUI.show_level.ONLY_AOD,
                      level: level,
                    });
                  };
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                let secAngle = 0 + (360*6)*(timeSensor.second + ((timeSensor.utc % 1000) / 1000))/360;
                normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, secAngle);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSecSmooth) {
                    let duration = 0;
                    let animDuration = 5000;
                    if (timeSensor.second > 55) animDuration = 1000*(60.1 - (timeSensor.second - (timeSensor.utc % 1000) / 1000));
                    let diffTime = timeSensor.utc - lastTime;
                    if (diffTime < animDuration) duration = animDuration - diffTime;
                    normal_timerUpdateSecSmooth = timer.createTimer(duration, animDuration, (function (option) {
                      lastTime = timeSensor.utc;
                      secAngle = 0 + (360*6)*(timeSensor.second + ((timeSensor.utc % 1000) / 1000))/360;
                      startSecAnim(secAngle, animDuration);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerUpdateSecSmooth) {
                  timer.stopTimer(normal_timerUpdateSecSmooth);
                  normal_timerUpdateSecSmooth = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
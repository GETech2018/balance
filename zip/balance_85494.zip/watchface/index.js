﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {
    (()=>{
        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_city_name_text = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_high_text_img = ''
        let normal_temperature_low_text_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_month = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_icon_img = ''
        let normal_distance_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_digital_clock_minute_separator_img = ''
        let idle_date_img_date_week_img = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_minute_separator_img = ''


        //dynamic modify end
        const e = __$$hmAppManager$$__.currentApp;
        const o = e.current
          , {px: i} = (new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(e,o)),
        e.__globals__)
          , n = Logger.getLogger("watchface6");
        o.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'Quadrante_01.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 162,
              y: 430,
              w: 150,
              h: 40,
              text_size: 25,
              char_space: 0,
              line_space: 0,
              color: 0xFF000000,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 65,
              y: 310,
              font_array: ["Att_01.png","Att_02.png","Att_03.png","Att_04.png","Att_05.png","Att_06.png","Att_07.png","Att_08.png","Att_09.png","Att_10.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Att_14.png',
              unit_tc: 'Att_14.png',
              unit_en: 'Att_14.png',
              negative_image: 'Att_13.png',
              invalid_image: 'Att_11.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 80,
              y: 350,
              image_array: ["clima_01.png","clima_02.png","clima_03.png","clima_04.png","clima_05.png","clima_06.png","clima_07.png","clima_08.png","clima_09.png","clima_10.png","clima_11.png","clima_12.png","clima_13.png","clima_14.png","clima_15.png","clima_16.png","clima_17.png","clima_18.png","clima_19.png","clima_20.png","clima_21.png","clima_22.png","clima_23.png","clima_24.png","clima_25.png","clima_26.png","clima_27.png","clima_28.png","clima_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 320,
              y: 320,
              font_array: ["Att_01.png","Att_02.png","Att_03.png","Att_04.png","Att_05.png","Att_06.png","Att_07.png","Att_08.png","Att_09.png","Att_10.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Att_14.png',
              unit_tc: 'Att_14.png',
              unit_en: 'Att_14.png',
              negative_image: 'Att_13.png',
              invalid_image: 'Att_11.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 320,
              y: 387,
              font_array: ["Att_01.png","Att_02.png","Att_03.png","Att_04.png","Att_05.png","Att_06.png","Att_07.png","Att_08.png","Att_09.png","Att_10.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Att_14.png',
              unit_tc: 'Att_14.png',
              unit_en: 'Att_14.png',
              negative_image: 'Att_13.png',
              invalid_image: 'Att_11.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 150,
              y: 340,
              week_en: ["week_01.png","week_02.png","week_03.png","week_04.png","week_05.png","week_06.png","week_07.png"],
              week_tc: ["week_01.png","week_02.png","week_03.png","week_04.png","week_05.png","week_06.png","week_07.png"],
              week_sc: ["week_01.png","week_02.png","week_03.png","week_04.png","week_05.png","week_06.png","week_07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 250,
              day_startY: 305,
              day_sc_array: ["Att_01.png","Att_02.png","Att_03.png","Att_04.png","Att_05.png","Att_06.png","Att_07.png","Att_08.png","Att_09.png","Att_10.png"],
              day_tc_array: ["Att_01.png","Att_02.png","Att_03.png","Att_04.png","Att_05.png","Att_06.png","Att_07.png","Att_08.png","Att_09.png","Att_10.png"],
              day_en_array: ["Att_01.png","Att_02.png","Att_03.png","Att_04.png","Att_05.png","Att_06.png","Att_07.png","Att_08.png","Att_09.png","Att_10.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 180,
              month_startY: 305,
              month_sc_array: ["Att_01.png","Att_02.png","Att_03.png","Att_04.png","Att_05.png","Att_06.png","Att_07.png","Att_08.png","Att_09.png","Att_10.png"],
              month_tc_array: ["Att_01.png","Att_02.png","Att_03.png","Att_04.png","Att_05.png","Att_06.png","Att_07.png","Att_08.png","Att_09.png","Att_10.png"],
              month_en_array: ["Att_01.png","Att_02.png","Att_03.png","Att_04.png","Att_05.png","Att_06.png","Att_07.png","Att_08.png","Att_09.png","Att_10.png"],
              month_zero: 1,
              month_space: 0,
              month_unit_sc: 'Att_15.png',
              month_unit_tc: 'Att_15.png',
              month_unit_en: 'Att_15.png',
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 325,
              y: 85,
              font_array: ["Att_01.png","Att_02.png","Att_03.png","Att_04.png","Att_05.png","Att_06.png","Att_07.png","Att_08.png","Att_09.png","Att_10.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 340,
              y: 50,
              src: 'Heart.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 166,
              y: 85,
              font_array: ["Att_01.png","Att_02.png","Att_03.png","Att_04.png","Att_05.png","Att_06.png","Att_07.png","Att_08.png","Att_09.png","Att_10.png"],
              padding: false,
              h_space: 0,
              dot_image: 'Att_15.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 159,
              y: 30,
              font_array: ["Att_01.png","Att_02.png","Att_03.png","Att_04.png","Att_05.png","Att_06.png","Att_07.png","Att_08.png","Att_09.png","Att_10.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 50,
              y: 85,
              font_array: ["Att_01.png","Att_02.png","Att_03.png","Att_04.png","Att_05.png","Att_06.png","Att_07.png","Att_08.png","Att_09.png","Att_10.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 115,
              y: 35,
              image_array: ["battery_1.png","battery_2.png","battery_3.png","battery_4.png","battery_5.png","battery_6.png","battery_7.png","battery_8.png","battery_9.png","battery_10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 360,
              am_y: 130,
              am_sc_path: 'am.png',
              am_en_path: 'am.png',
              pm_x: 360,
              pm_y: 130,
              pm_sc_path: 'pm.png',
              pm_en_path: 'pm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 15,
              hour_startY: 140,
              hour_array: ["Ore_01.png","Ore_02.png","Ore_03.png","Ore_04.png","Ore_05.png","Ore_06.png","Ore_07.png","Ore_08.png","Ore_09.png","Ore_10.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 205,
              minute_startY: 140,
              minute_array: ["Ore_01.png","Ore_02.png","Ore_03.png","Ore_04.png","Ore_05.png","Ore_06.png","Ore_07.png","Ore_08.png","Ore_09.png","Ore_10.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 360,
              second_startY: 185,
              second_array: ["Secondi_01.png","Secondi_02.png","Secondi_03.png","Secondi_04.png","Secondi_05.png","Secondi_06.png","Secondi_07.png","Secondi_08.png","Secondi_09.png","Secondi_10.png"],
              second_zero: 1,
              second_space: -8,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 180,
              y: 140,
              src: 'Ore_11.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_minute_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'Att_01.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 145,
              y: 290,
              week_en: ["B_WEEK_1.png","B_WEEK_2.png","B_WEEK_3.png","B_WEEK_4.png","B_WEEK_5.png","B_WEEK_6.png","B_WEEK_7.png"],
              week_tc: ["B_WEEK_1.png","B_WEEK_2.png","B_WEEK_3.png","B_WEEK_4.png","B_WEEK_5.png","B_WEEK_6.png","B_WEEK_7.png"],
              week_sc: ["B_WEEK_1.png","B_WEEK_2.png","B_WEEK_3.png","B_WEEK_4.png","B_WEEK_5.png","B_WEEK_6.png","B_WEEK_7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 72,
              hour_startY: 150,
              hour_array: ["B_ore_01.png","B_ore_02.png","B_ore_03.png","B_ore_04.png","B_ore_05.png","B_ore_06.png","B_ore_07.png","B_ore_08.png","B_ore_09.png","B_ore_10.png"],
              hour_zero: 1,
              hour_space: -2,
              hour_unit_sc: 'B_ore_11.png',
              hour_unit_tc: 'B_ore_11.png',
              hour_unit_en: 'B_ore_11.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 255,
              minute_startY: 150,
              minute_array: ["B_ore_01.png","B_ore_02.png","B_ore_03.png","B_ore_04.png","B_ore_05.png","B_ore_06.png","B_ore_07.png","B_ore_08.png","B_ore_09.png","B_ore_10.png"],
              minute_zero: 1,
              minute_space: -2,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_minute_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'Att_01.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            function scale_call() {

              console.log('Weather city name');
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);
              const weatherData = weatherSensor.getForecastWeather();
              normal_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                scale_call();
              }),
            });

                //dynamic modify end
            },
            onInit() {
                n.log("index page.js on init invoke")
            },
            build() {
                this.init_view(),
                n.log("index page.js on ready invoke")
            },
            onDestroy() {
                n.log("index page.js on destroy invoke")
            }
        })
    }
    )()
} catch (e) {
    console.log("Mini Program Error", e),
    e && e.stack && e.stack.split(/\n/).forEach((e=>console.log("error stack", e)))
}

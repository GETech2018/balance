﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_date_day_separator_img = ''
        let normal_date_img_date_week_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_text_separator_img = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_moon_image_progress_img_level = ''
        let idle_background_bg_img = ''
        let idle_sun_high_text_img = ''
        let idle_sun_high_separator_img = ''
        let idle_sun_low_text_img = ''
        let idle_sun_low_separator_img = ''
        let idle_temperature_current_text_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_month = ''
        let idle_date_img_date_day = ''
        let idle_date_day_separator_img = ''
        let idle_battery_text_text_img = ''
        let idle_battery_text_separator_img = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_analog_clock_time_pointer_second = ''
        let idle_moon_image_progress_img_level = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: '12-2hellblau.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 90,
              y: 155,
              font_array: ["0051.png","0052.png","0053.png","0054.png","0055.png","0056.png","0057.png","0058.png","0059.png","0060.png"],
              padding: false,
              h_space: 0,
              unit_sc: '0062.png',
              unit_tc: '0062.png',
              unit_en: '0062.png',
              negative_image: '0061.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 290,
              y: 140,
              image_array: ["w0035.png","w0036.png","w0037.png","w0038.png","w0039.png","w0040.png","w0041.png","w0042.png","w0043.png","w0044.png","w0045.png","w0046.png","w0047.png","w0048.png","w0049.png","w0050.png","w0051.png","w0052.png","w0053.png","w0054.png","w0055.png","w0056.png","w0057.png","w0058.png","w0059.png","w0060.png","w0061.png","w0062.png","w0063.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 190,
              y: 110,
              font_array: ["100.png","101.png","102.png","103.png","104.png","105.png","106.png","107.png","108.png","109.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 220,
              y: 70,
              src: '110.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 330,
              month_startY: 270,
              month_sc_array: ["70.png","71.png","72.png","73.png","74.png","75.png","76.png","77.png","78.png","79.png"],
              month_tc_array: ["70.png","71.png","72.png","73.png","74.png","75.png","76.png","77.png","78.png","79.png"],
              month_en_array: ["70.png","71.png","72.png","73.png","74.png","75.png","76.png","77.png","78.png","79.png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 280,
              day_startY: 270,
              day_sc_array: ["70.png","71.png","72.png","73.png","74.png","75.png","76.png","77.png","78.png","79.png"],
              day_tc_array: ["70.png","71.png","72.png","73.png","74.png","75.png","76.png","77.png","78.png","79.png"],
              day_en_array: ["70.png","71.png","72.png","73.png","74.png","75.png","76.png","77.png","78.png","79.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.RIGHT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_day_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 315,
              y: 270,
              src: '80.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 90,
              y: 270,
              week_en: ["40.png","41.png","42.png","43.png","44.png","45.png","46.png"],
              week_tc: ["40.png","41.png","42.png","43.png","44.png","45.png","46.png"],
              week_sc: ["40.png","41.png","42.png","43.png","44.png","45.png","46.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 240,
              y: 385,
              font_array: ["digital1_0.png","digital1_1.png","digital1_2.png","digital1_3.png","digital1_4.png","digital1_5.png","digital1_6.png","digital1_7.png","digital1_8.png","digital1_9.png"],
              padding: false,
              h_space: -2,
              unit_sc: 'pr3.png',
              unit_tc: 'pr3.png',
              unit_en: 'pr3.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 200,
              y: 386,
              src: '6.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 130,
              hour_startY: 314,
              hour_array: ["t01.png","t02.png","t03.png","t04.png","t05.png","t06.png","t07.png","t08.png","t09.png","t10.png"],
              hour_zero: 1,
              hour_space: 6,
              hour_angle: 0,
              hour_align: hmUI.align.RIGHT,

              minute_startX: 240,
              minute_startY: 314,
              minute_array: ["t01.png","t02.png","t03.png","t04.png","t05.png","t06.png","t07.png","t08.png","t09.png","t10.png"],
              minute_zero: 1,
              minute_space: 6,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.RIGHT,

              second_startX: 276,
              second_startY: 324,
              second_array: ["s01.png","s02.png","s03.png","s04.png","s05.png","s06.png","s07.png","s08.png","s09.png","s10.png"],
              second_zero: 1,
              second_space: 6,
              second_angle: 0,
              second_follow: 1,
              second_align: hmUI.align.RIGHT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 205,
              y: 312,
              src: '5.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: '1.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 25,
              hour_posY: 162,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: '2.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 25,
              minute_posY: 244,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: '20.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 28,
              second_posY: 228,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 210,
              y: 210,
              image_array: ["moon_1.png","moon_2.png","moon_3.png","moon_4.png","moon_5.png","moon_6.png","moon_7.png"],
              image_length: 7,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: '12-2hellblau-aod.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 140,
              y: 100,
              font_array: ["70.png","71.png","72.png","73.png","74.png","75.png","76.png","77.png","78.png","79.png"],
              padding: false,
              h_space: 0,
              dot_image: '125.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_sun_high_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 170,
              y: 60,
              src: 'SUN_0090.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 250,
              y: 100,
              font_array: ["70.png","71.png","72.png","73.png","74.png","75.png","76.png","77.png","78.png","79.png"],
              padding: false,
              h_space: 0,
              dot_image: '125.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_sun_low_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 280,
              y: 60,
              src: 'SUN_0091.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 90,
              y: 155,
              font_array: ["0051.png","0052.png","0053.png","0054.png","0055.png","0056.png","0057.png","0058.png","0059.png","0060.png"],
              padding: false,
              h_space: 0,
              unit_sc: '0062.png',
              unit_tc: '0062.png',
              unit_en: '0062.png',
              negative_image: '0061.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 290,
              y: 140,
              image_array: ["w0035.png","w0036.png","w0037.png","w0038.png","w0039.png","w0040.png","w0041.png","w0042.png","w0043.png","w0044.png","w0045.png","w0046.png","w0047.png","w0048.png","w0049.png","w0050.png","w0051.png","w0052.png","w0053.png","w0054.png","w0055.png","w0056.png","w0057.png","w0058.png","w0059.png","w0060.png","w0061.png","w0062.png","w0063.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 90,
              y: 270,
              week_en: ["40.png","41.png","42.png","43.png","44.png","45.png","46.png"],
              week_tc: ["40.png","41.png","42.png","43.png","44.png","45.png","46.png"],
              week_sc: ["40.png","41.png","42.png","43.png","44.png","45.png","46.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 330,
              month_startY: 270,
              month_sc_array: ["70.png","71.png","72.png","73.png","74.png","75.png","76.png","77.png","78.png","79.png"],
              month_tc_array: ["70.png","71.png","72.png","73.png","74.png","75.png","76.png","77.png","78.png","79.png"],
              month_en_array: ["70.png","71.png","72.png","73.png","74.png","75.png","76.png","77.png","78.png","79.png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 280,
              day_startY: 270,
              day_sc_array: ["70.png","71.png","72.png","73.png","74.png","75.png","76.png","77.png","78.png","79.png"],
              day_tc_array: ["70.png","71.png","72.png","73.png","74.png","75.png","76.png","77.png","78.png","79.png"],
              day_en_array: ["70.png","71.png","72.png","73.png","74.png","75.png","76.png","77.png","78.png","79.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.RIGHT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_day_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 315,
              y: 270,
              src: '80.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 240,
              y: 385,
              font_array: ["digital1_0.png","digital1_1.png","digital1_2.png","digital1_3.png","digital1_4.png","digital1_5.png","digital1_6.png","digital1_7.png","digital1_8.png","digital1_9.png"],
              padding: false,
              h_space: -2,
              unit_sc: 'pr3.png',
              unit_tc: 'pr3.png',
              unit_en: 'pr3.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 200,
              y: 386,
              src: '6.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 130,
              hour_startY: 314,
              hour_array: ["t01.png","t02.png","t03.png","t04.png","t05.png","t06.png","t07.png","t08.png","t09.png","t10.png"],
              hour_zero: 1,
              hour_space: 6,
              hour_angle: 0,
              hour_align: hmUI.align.RIGHT,

              minute_startX: 240,
              minute_startY: 314,
              minute_array: ["t01.png","t02.png","t03.png","t04.png","t05.png","t06.png","t07.png","t08.png","t09.png","t10.png"],
              minute_zero: 1,
              minute_space: 6,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.RIGHT,

              second_startX: 276,
              second_startY: 324,
              second_array: ["s01.png","s02.png","s03.png","s04.png","s05.png","s06.png","s07.png","s08.png","s09.png","s10.png"],
              second_zero: 1,
              second_space: 6,
              second_angle: 0,
              second_follow: 1,
              second_align: hmUI.align.RIGHT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 205,
              y: 312,
              src: '5.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: '1.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 25,
              hour_posY: 162,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: '2.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 25,
              minute_posY: 244,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: '20.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 28,
              second_posY: 228,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 210,
              y: 210,
              image_array: ["moon_1.png","moon_2.png","moon_3.png","moon_4.png","moon_5.png","moon_6.png","moon_7.png"],
              image_length: 7,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_AOD,
            });


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

let cc=0;
let nTopLeftStatus=0;
let nTopRightStatus=0;
let nBtmLeftStatus=0;
let nBtmRightStatus=0;
let cDisplayStatus="Date/Time/Steps";
let nLineAnim=0;

function click_LineAnim(){
    nLineAnim=1-nLineAnim;
    Show_LineAnim();
}
function click_TopLeft(){
    nTopLeftStatus=1-nTopLeftStatus;
	nTopRightStatus=0;
	cDisplayStatus="Top: Energetical information";
    Show_TopDisplay();
}
function click_TopRight(){
    nTopRightStatus=1-nTopRightStatus;
	nTopLeftStatus=0;
	cDisplayStatus="Top: Weather information";
    Show_TopDisplay();
}
function click_BtmLeft(){
    nBtmLeftStatus=1-nBtmLeftStatus;
	nBtmRightStatus=0;
	cDisplayStatus="Bottom: Steps and distance";
    Show_BtmDisplay();
}
function click_BtmRight(){
    nBtmRightStatus=1-nBtmRightStatus;
	nBtmLeftStatus=0;
	cDisplayStatus="Bottom: Health information";
    Show_BtmDisplay();
}

//////////////////////////////////////////////////////////////////////////////////////////////////
function Show_TopDisplay(){
  //hmUI.showToast({text: ' Top Left: #'+parseInt(nTopLeftStatus)+' Top Right: #'+parseInt(nTopRightStatus)});
  //hmUI.showToast({text: cDisplayStatus);
  //normal_city_name_text.setProperty(hmUI.prop.VISIBLE,  true);

	normal_date_img_date_week_img.setProperty(hmUI.prop.VISIBLE,           (nTopLeftStatus==0 && nTopRightStatus==0));
	normal_date_img_date_year.setProperty(hmUI.prop.VISIBLE,               (nTopLeftStatus==0 && nTopRightStatus==0));
	normal_date_img_date_day.setProperty(hmUI.prop.VISIBLE,                (nTopLeftStatus==0 && nTopRightStatus==0));
	normal_date_img_date_month.setProperty(hmUI.prop.VISIBLE,              (nTopLeftStatus==0 && nTopRightStatus==0));
	normal_date_img_date_month_img.setProperty(hmUI.prop.VISIBLE,          (nTopLeftStatus==0 && nTopRightStatus==0));
	
    normal_battery_icon_img.setProperty(hmUI.prop.VISIBLE,                 (nTopLeftStatus==1 && nTopRightStatus==0));
    normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE,            (nTopLeftStatus==1 && nTopRightStatus==0));
    normal_battery_text_separator_img.setProperty(hmUI.prop.VISIBLE,       (nTopLeftStatus==1 && nTopRightStatus==0));
    normal_stress_text_text_img.setProperty(hmUI.prop.VISIBLE,             (nTopLeftStatus==1 && nTopRightStatus==0));
    normal_stress_text_separator_img.setProperty(hmUI.prop.VISIBLE,        (nTopLeftStatus==1 && nTopRightStatus==0));
    
	normal_uvi_image_progress_img_level.setProperty(hmUI.prop.VISIBLE,     (nTopLeftStatus==0 && nTopRightStatus==1));
    normal_temperature_icon_img.setProperty(hmUI.prop.VISIBLE,             (nTopLeftStatus==0 && nTopRightStatus==1));
    normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, (nTopLeftStatus==0 && nTopRightStatus==1));
    normal_temperature_high_text_img.setProperty(hmUI.prop.VISIBLE,        (nTopLeftStatus==0 && nTopRightStatus==1));
    normal_temperature_low_text_img.setProperty(hmUI.prop.VISIBLE,         (nTopLeftStatus==0 && nTopRightStatus==1));
    normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE,     (nTopLeftStatus==0 && nTopRightStatus==1));

	
}//////////////////////////////////////////////////////////////////////////////////////////////////
function Show_BtmDisplay(){
  //hmUI.showToast({text: 'Bottom Left: #'+parseInt(nBtmLeftStatus)+'Bottom Right: #'+parseInt(nBtmRightStatus)});
  //hmUI.showToast({text: cDisplayStatus);
  //normal_city_name_text.setProperty(hmUI.prop.VISIBLE,  true);

  //NORMAL mode  
	normal_sun_high_text_img.setProperty(hmUI.prop.VISIBLE,            (nBtmLeftStatus==0 && nBtmRightStatus==0));
	normal_sun_high_separator_img.setProperty(hmUI.prop.VISIBLE,       (nBtmLeftStatus==0 && nBtmRightStatus==0));
	normal_sun_low_text_img.setProperty(hmUI.prop.VISIBLE,             (nBtmLeftStatus==0 && nBtmRightStatus==0));
	normal_sun_low_separator_img.setProperty(hmUI.prop.VISIBLE,        (nBtmLeftStatus==0 && nBtmRightStatus==0));
  //STEPS mode	
	normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE,        (nBtmLeftStatus==1 && nBtmRightStatus==0));
	normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE,   (nBtmLeftStatus==1 && nBtmRightStatus==0));
	normal_step_icon_img.setProperty(hmUI.prop.VISIBLE,                (nBtmLeftStatus==1 && nBtmRightStatus==0));
	normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE,       (nBtmLeftStatus==1 && nBtmRightStatus==0));
	normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE,  (nBtmLeftStatus==1 && nBtmRightStatus==0));
  //HEALTH mode																	   
	normal_spo2_text_text_img.setProperty(hmUI.prop.VISIBLE,           (nBtmLeftStatus==0 && nBtmRightStatus==1));
	normal_spo2_text_separator_img.setProperty(hmUI.prop.VISIBLE,      (nBtmLeftStatus==0 && nBtmRightStatus==1));
	normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE,          (nBtmLeftStatus==0 && nBtmRightStatus==1));
	normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE,     (nBtmLeftStatus==0 && nBtmRightStatus==1));
	normal_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE,(nBtmLeftStatus==0 && nBtmRightStatus==1));
	
}

// Animation ON
function Show_LineAnim(){

  if(nLineAnim==1){
	hmUI.showToast({text: 'Animation: continuous'});
	normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);
	normal_frame_animation_1.setProperty(hmUI.prop.VISIBLE,    true);
    normal_second_TextRotate[0].setProperty(hmUI.prop.VISIBLE, false);
    normal_second_TextRotate[1].setProperty(hmUI.prop.VISIBLE, false);
  }else{
	hmUI.showToast({text: 'Animation: intermittent'});
    normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);
	normal_frame_animation_1.setProperty(hmUI.prop.VISIBLE,    false);
    normal_second_TextRotate[0].setProperty(hmUI.prop.VISIBLE, true);
    normal_second_TextRotate[1].setProperty(hmUI.prop.VISIBLE, true);
  }

}
        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_stand_current_text_img = ''
        let normal_spo2_text_text_img = ''
        let normal_spo2_text_separator_img = ''
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_text_separator_img = ''
        let normal_distance_text_text_img = ''
        let normal_distance_text_separator_img = ''
        let normal_step_icon_img = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_sun_high_text_img = ''
        let normal_sun_high_separator_img = ''
        let normal_sun_low_text_img = ''
        let normal_sun_low_separator_img = ''
        let normal_uvi_image_progress_img_level = ''
        let normal_temperature_icon_img = ''
        let normal_city_name_text = ''
        let normal_temperature_high_text_img = ''
        let normal_temperature_low_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_stress_text_text_img = ''
        let normal_stress_text_separator_img = ''
        let normal_battery_icon_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_text_separator_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_year = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_month_img = ''
        let normal_system_lock_img = ''
        let normal_system_dnd_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_digital_clock_img_time = ''
        let normal_second_TextRotate = new Array(2);
        let normal_second_TextRotate_ASCIIARRAY = new Array(10);
        let normal_second_TextRotate_img_width = 150;
        let normal_timerTextUpdate = undefined;
        let normal_frame_animation_1 = ''
        let idle_background_bg_img = ''
        let idle_digital_clock_img_time = ''
        let image_top_img = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg_light.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 0,
              y: 0,
              font_array: ["numa00.png","numa01.png","numa02.png","numa03.png","numa04.png","numa05.png","numa06.png","numa07.png","numa08.png","numa09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STAND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 90,
              y: 355,
              font_array: ["numa00.png","numa01.png","numa02.png","numa03.png","numa04.png","numa05.png","numa06.png","numa07.png","numa08.png","numa09.png"],
              padding: true,
              h_space: -10,
              unit_sc: 'text_percent.png',
              unit_tc: 'text_percent.png',
              unit_en: 'text_percent.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 105,
              y: 338,
              src: 'text_SPO2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 408,
              y: 325,
              src: 'icon_health0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 270,
              y: 355,
              font_array: ["numa00.png","numa01.png","numa02.png","numa03.png","numa04.png","numa05.png","numa06.png","numa07.png","numa08.png","numa09.png"],
              padding: true,
              h_space: -10,
              unit_sc: 'text_bpm.png',
              unit_tc: 'text_bpm.png',
              unit_en: 'text_bpm.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 271,
              y: 338,
              src: 'text_heart.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 246,
              y: 355,
              font_array: ["numa00.png","numa01.png","numa02.png","numa03.png","numa04.png","numa05.png","numa06.png","numa07.png","numa08.png","numa09.png"],
              padding: true,
              h_space: -10,
              unit_sc: 'text_kms.png',
              unit_tc: 'text_kms.png',
              unit_en: 'text_kms.png',
              imperial_unit_sc: 'text_miles.png',
              imperial_unit_tc: 'text_miles.png',
              imperial_unit_en: 'text_miles.png',
              dot_image: 'numasd.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 290,
              y: 338,
              src: 'text_distances.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 28,
              y: 325,
              src: 'icon_steps0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 65,
              y: 355,
              font_array: ["numa00.png","numa01.png","numa02.png","numa03.png","numa04.png","numa05.png","numa06.png","numa07.png","numa08.png","numa09.png"],
              padding: true,
              h_space: -10,
              unit_sc: 'text_steps.png',
              unit_tc: 'text_steps.png',
              unit_en: 'text_steps.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 109,
              y: 338,
              src: 'text_steps.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 50,
              y: 355,
              font_array: ["numa00.png","numa01.png","numa02.png","numa03.png","numa04.png","numa05.png","numa06.png","numa07.png","numa08.png","numa09.png"],
              padding: false,
              h_space: -8,
              dot_image: 'numadd.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 103,
              y: 337,
              src: 'sunrise.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 230,
              y: 355,
              font_array: ["numa00.png","numa01.png","numa02.png","numa03.png","numa04.png","numa05.png","numa06.png","numa07.png","numa08.png","numa09.png"],
              padding: false,
              h_space: -8,
              dot_image: 'numadd.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 290,
              y: 340,
              src: 'sunset.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_uvi_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 311,
              y: 55,
              image_array: ["uvind02.png","uvind04.png","uvind06.png","uvind09.png","uvind11.png"],
              image_length: 5,
              type: hmUI.data_type.UVI,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 413,
              y: 116,
              src: 'icon_weather0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 90,
              y: 150,
              w: 300,
              h: 45,
              text_size: 30,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFF80,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 85,
              y: 40,
              font_array: ["numa00.png","numa01.png","numa02.png","numa03.png","numa04.png","numa05.png","numa06.png","numa07.png","numa08.png","numa09.png"],
              padding: false,
              h_space: -10,
              unit_sc: 'text_celsius.png',
              unit_tc: 'text_celsius.png',
              unit_en: 'text_celsius.png',
              negative_image: 'numanus.png',
              invalid_image: 'numanone.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 84,
              y: 85,
              font_array: ["numa00.png","numa01.png","numa02.png","numa03.png","numa04.png","numa05.png","numa06.png","numa07.png","numa08.png","numa09.png"],
              padding: false,
              h_space: -10,
              unit_sc: 'text_celsius.png',
              unit_tc: 'text_celsius.png',
              unit_en: 'text_celsius.png',
              negative_image: 'numanus.png',
              invalid_image: 'numanone.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 170,
              y: 110,
              font_array: ["numy00.png","numy01.png","numy02.png","numy03.png","numy04.png","numy05.png","numy06.png","numy07.png","numy08.png","numy09.png"],
              padding: false,
              h_space: -10,
              unit_sc: 'text_celsius.png',
              unit_tc: 'text_celsius.png',
              unit_en: 'text_celsius.png',
              negative_image: 'numynus.png',
              invalid_image: 'numynone.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 200,
              y: 35,
              image_array: ["0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png","0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png","0050.png","0051.png","0052.png","0053.png","0054.png","0055.png","0056.png","0057.png","0058.png","0059.png","0060.png","0061.png","0062.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 265,
              y: 88,
              font_array: ["numa00.png","numa01.png","numa02.png","numa03.png","numa04.png","numa05.png","numa06.png","numa07.png","numa08.png","numa09.png"],
              padding: true,
              h_space: -10,
              unit_sc: 'text_percent.png',
              unit_tc: 'text_percent.png',
              unit_en: 'text_percent.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STRESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 280,
              y: 125,
              src: 'text_stress.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 28,
              y: 109,
              src: 'icon_battery0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 105,
              y: 90,
              font_array: ["numa00.png","numa01.png","numa02.png","numa03.png","numa04.png","numa05.png","numa06.png","numa07.png","numa08.png","numa09.png"],
              padding: true,
              h_space: -10,
              unit_sc: 'text_percent.png',
              unit_tc: 'text_percent.png',
              unit_en: 'text_percent.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 110,
              y: 125,
              src: 'text_battery.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 105,
              y: 34,
              week_en: ["wden01.png","wden02.png","wden03.png","wden04.png","wden05.png","wden06.png","wden07.png"],
              week_tc: ["wden01.png","wden02.png","wden03.png","wden04.png","wden05.png","wden06.png","wden07.png"],
              week_sc: ["wden01.png","wden02.png","wden03.png","wden04.png","wden05.png","wden06.png","wden07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 254,
              year_startY: 108,
              year_sc_array: ["numb00.png","numb01.png","numb02.png","numb03.png","numb04.png","numb05.png","numb06.png","numb07.png","numb08.png","numb09.png"],
              year_tc_array: ["numb00.png","numb01.png","numb02.png","numb03.png","numb04.png","numb05.png","numb06.png","numb07.png","numb08.png","numb09.png"],
              year_en_array: ["numb00.png","numb01.png","numb02.png","numb03.png","numb04.png","numb05.png","numb06.png","numb07.png","numb08.png","numb09.png"],
              year_zero: 1,
              year_space: -15,
              year_align: hmUI.align.CENTER_H,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 173,
              day_startY: 108,
              day_sc_array: ["numb00.png","numb01.png","numb02.png","numb03.png","numb04.png","numb05.png","numb06.png","numb07.png","numb08.png","numb09.png"],
              day_tc_array: ["numb00.png","numb01.png","numb02.png","numb03.png","numb04.png","numb05.png","numb06.png","numb07.png","numb08.png","numb09.png"],
              day_en_array: ["numb00.png","numb01.png","numb02.png","numb03.png","numb04.png","numb05.png","numb06.png","numb07.png","numb08.png","numb09.png"],
              day_zero: 1,
              day_space: -13,
              day_unit_sc: 'numb0sd.png',
              day_unit_tc: 'numb0sd.png',
              day_unit_en: 'numb0sd.png',
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 90,
              month_startY: 108,
              month_sc_array: ["numb00.png","numb01.png","numb02.png","numb03.png","numb04.png","numb05.png","numb06.png","numb07.png","numb08.png","numb09.png"],
              month_tc_array: ["numb00.png","numb01.png","numb02.png","numb03.png","numb04.png","numb05.png","numb06.png","numb07.png","numb08.png","numb09.png"],
              month_en_array: ["numb00.png","numb01.png","numb02.png","numb03.png","numb04.png","numb05.png","numb06.png","numb07.png","numb08.png","numb09.png"],
              month_zero: 1,
              month_space: -13,
              month_unit_sc: 'numb0sd.png',
              month_unit_tc: 'numb0sd.png',
              month_unit_en: 'numb0sd.png',
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 110,
              month_startY: 70,
              month_sc_array: ["monen01.png","monen02.png","monen03.png","monen04.png","monen05.png","monen06.png","monen07.png","monen08.png","monen09.png","monen10.png","monen11.png","monen12.png"],
              month_tc_array: ["monen01.png","monen02.png","monen03.png","monen04.png","monen05.png","monen06.png","monen07.png","monen08.png","monen09.png","monen10.png","monen11.png","monen12.png"],
              month_en_array: ["monen01.png","monen02.png","monen03.png","monen04.png","monen05.png","monen06.png","monen07.png","monen08.png","monen09.png","monen10.png","monen11.png","monen12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 249,
              y: 392,
              src: '0069.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 177,
              y: 392,
              src: '0070.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 105,
              y: 392,
              src: '0068.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 317,
              y: 392,
              src: '0067.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 95,
              hour_startY: 196,
              hour_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              hour_zero: 1,
              hour_space: -5,
              hour_angle: 0,
              hour_unit_sc: 'num_dd.png',
              hour_unit_tc: 'num_dd.png',
              hour_unit_en: 'num_dd.png',
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 300,
              minute_startY: 196,
              minute_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              minute_zero: 1,
              minute_space: -5,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 205,
              second_startY: 10,
              second_array: ["numy00.png","numy01.png","numy02.png","numy03.png","numy04.png","numy05.png","numy06.png","numy07.png","numy08.png","numy09.png"],
              second_zero: 1,
              second_space: -10,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_second_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: -50,
              // y: 139,
              // font_array: ["frame_00.png","frame_01.png","frame_02.png","frame_03.png","frame_04.png","frame_05.png","frame_06.png","frame_07.png","frame_08.png","frame_09.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: 30,
              // angle: 0,
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.SECOND,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_second_TextRotate_ASCIIARRAY[0] = 'frame_00.png';  // set of images with numbers
            normal_second_TextRotate_ASCIIARRAY[1] = 'frame_01.png';  // set of images with numbers
            normal_second_TextRotate_ASCIIARRAY[2] = 'frame_02.png';  // set of images with numbers
            normal_second_TextRotate_ASCIIARRAY[3] = 'frame_03.png';  // set of images with numbers
            normal_second_TextRotate_ASCIIARRAY[4] = 'frame_04.png';  // set of images with numbers
            normal_second_TextRotate_ASCIIARRAY[5] = 'frame_05.png';  // set of images with numbers
            normal_second_TextRotate_ASCIIARRAY[6] = 'frame_06.png';  // set of images with numbers
            normal_second_TextRotate_ASCIIARRAY[7] = 'frame_07.png';  // set of images with numbers
            normal_second_TextRotate_ASCIIARRAY[8] = 'frame_08.png';  // set of images with numbers
            normal_second_TextRotate_ASCIIARRAY[9] = 'frame_09.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              normal_second_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: -50,
                center_y: 139,
                pos_x: -50,
                pos_y: 139,
                angle: 0,
                src: 'frame_00.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_second_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            let screenType = hmSetting.getScreenType();
            normal_frame_animation_1 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
              x: -35,
              y: 139,
              anim_path: "animation",
              anim_ext: "png",
              anim_prefix: "frame",
              anim_fps: 10,
              anim_size: 16,
              repeat_count: 0,
              anim_repeat: true,
              anim_status:hmUI.anim_status.START,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg_dark.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 95,
              hour_startY: 196,
              hour_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              hour_zero: 1,
              hour_space: -5,
              hour_angle: 0,
              hour_unit_sc: 'num_dd.png',
              hour_unit_tc: 'num_dd.png',
              hour_unit_en: 'num_dd.png',
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 300,
              minute_startY: 196,
              minute_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              minute_zero: 1,
              minute_space: -5,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 25,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              console.log('checkConnection()');
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  vibro(25);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              if (scene != 1) timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function
            
            // repeatAlert = hmUI.createWidget(hmUI.widget.RepeatAlert, {
              // everyHour_vibrate_type: 9,
            // });


            timeSensor.addEventListener(timeSensor.event.MINUTEEND, function() {
              repeat_alerts();
            });
            // repeat alerts
            function repeat_alerts() {
              let hourEnd = false;
              if(timeSensor.minute == 0) {
                hourEnd = true;
                vibro(9);
              }
            };

            // end repeat alerts

            image_top_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 54,
              y: 14,
              src: 'shadowlens.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 10,
              y: 96,
              w: 75,
              h: 75,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'icon_battery1.png',
              normal_src: '_blank.png',
              click_func: (button_widget) => {
                click_TopLeft();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 399,
              y: 100,
              w: 75,
              h: 75,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'icon_weather1.png',
              normal_src: '_blank.png',
              click_func: (button_widget) => {
                click_TopRight();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 10,
              y: 315,
              w: 75,
              h: 75,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'icon_steps1.png',
              normal_src: '_blank.png',
              click_func: (button_widget) => {
                click_BtmLeft();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 0,
              y: 173,
              w: 100,
              h: 140,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '_blank.png',
              normal_src: '_blank.png',
              click_func: (button_widget) => {
                click_LineAnim();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 395,
              y: 313,
              w: 75,
              h: 75,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'icon_health1.png',
              normal_src: '_blank.png',
              click_func: (button_widget) => {
                click_BtmRight();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            console.log('user_script_end.js');
            // start user_script_end.js

if (cc==0 ){
nTopLeftStatus=0;
nTopRightStatus=0;
nBtmLeftStatus=0;
nBtmRightStatus=0;
nLineAnim=0;

Show_LineAnim();
Show_TopDisplay();
Show_BtmDisplay();

hmUI.showToast({text: 'Init'});
cc =1;
}
// a 'körbeírt' szövegek automatikus megjelenítését meg kell akadályozni, 
// hogy csak a saját fázisukban jelenjenek meg...
// if (screenType != hmSetting.screen_type.AOD && nDisplayState==1)
            // end user_script_end.js

            //start of ignored block
            function text_update() {
              console.log('text_update()');

              console.log('update text rotate second_TIME');
              let valueSecond = timeSensor.second;
              let normal_second_rotate_string = parseInt(valueSecond).toString();
              normal_second_rotate_string = normal_second_rotate_string.padStart(2, '0');

              if (screenType != hmSetting.screen_type.AOD && nLineAnim==0) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_second_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueSecond != null && valueSecond != undefined && isFinite(valueSecond) && normal_second_rotate_string.length > 0 && normal_second_rotate_string.length <= 2) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let normal_second_TextRotate_posOffset = normal_second_TextRotate_img_width * normal_second_rotate_string.length;
                  normal_second_TextRotate_posOffset = normal_second_TextRotate_posOffset + 30 * (normal_second_rotate_string.length - 1);
                  img_offset -= normal_second_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_second_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_second_TextRotate[index].setProperty(hmUI.prop.POS_X, -50 + img_offset);
                      normal_second_TextRotate[index].setProperty(hmUI.prop.SRC, normal_second_TextRotate_ASCIIARRAY[charCode]);
                      normal_second_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_second_TextRotate_img_width + 30;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

            };

            //end of ignored block
            function scale_call() {
              console.log('scale_call()');

              console.log('Weather city name');
              let weatherData = weatherSensor.getForecastWeather();
              normal_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                text_update();
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerTextUpdate) {
                    normal_timerTextUpdate = timer.createTimer(0, 1000, (function (option) {
                      text_update();
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);
                checkConnection();
                stopVibro();

              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerTextUpdate) {
                  timer.stopTimer(normal_timerTextUpdate);
                  normal_timerTextUpdate = undefined;
                }
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_sun_icon_img = ''
        let normal_sun_high_text_img = ''
        let normal_sun_low_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_date_img_date_day = ''
        let normal_heart_rate_text_text_img = ''
        let normal_digital_clock_img_time = ''
        let normal_date_img_date_week_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let idle_date_img_date_day = ''
        let idle_digital_clock_img_time = ''
        let idle_date_img_date_week_img = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: '0000.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 55,
              y: 74,
              src: 'sunset.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 108,
              y: 70,
              font_array: ["b0003.png","b0004.png","b0005.png","b0006.png","b0007.png","b0008.png","b0009.png","b0010.png","b0011.png","b0012.png"],
              padding: false,
              h_space: -1,
              dot_image: 'b0013.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 108,
              y: 94,
              font_array: ["b0003.png","b0004.png","b0005.png","b0006.png","b0007.png","b0008.png","b0009.png","b0010.png","b0011.png","b0012.png"],
              padding: false,
              h_space: -1,
              dot_image: 'b0013.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 21,
              y: 309,
              font_array: ["0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png"],
              padding: false,
              h_space: -3,
              unit_sc: '0014.png',
              unit_tc: '0014.png',
              unit_en: '0014.png',
              dot_image: '0013.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 359,
              y: 77,
              font_array: ["b0003.png","b0004.png","b0005.png","b0006.png","b0007.png","b0008.png","b0009.png","b0010.png","b0011.png","b0012.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'b0016.png',
              unit_tc: 'b0016.png',
              unit_en: 'b0016.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 300,
              y: 77,
              image_array: ["Le00.png","Le01.png","Le02.png","Le03.png","Le04.png","Le05.png","Le07.png","Le08.png"],
              image_length: 8,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 204,
              day_startY: 400,
              day_sc_array: ["CH01).png","CH02).png","CH03).png","CH04).png","CH05).png","CH06).png","CH07).png","CH08).png","CH09).png","CH10).png"],
              day_tc_array: ["CH01).png","CH02).png","CH03).png","CH04).png","CH05).png","CH06).png","CH07).png","CH08).png","CH09).png","CH10).png"],
              day_en_array: ["CH01).png","CH02).png","CH03).png","CH04).png","CH05).png","CH06).png","CH07).png","CH08).png","CH09).png","CH10).png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 381,
              y: 309,
              font_array: ["0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png"],
              padding: false,
              h_space: -4,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 27,
              hour_startY: 125,
              hour_array: ["A00.png","A01.png","A02.png","A03.png","A04.png","A05.png","A06.png","A07.png","A08.png","A09.png"],
              hour_zero: 1,
              hour_space: -42,
              hour_angle: 0,
              hour_unit_sc: 'A11.png',
              hour_unit_tc: 'A11.png',
              hour_unit_en: 'A11.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 244,
              minute_startY: 125,
              minute_array: ["A00.png","A01.png","A02.png","A03.png","A04.png","A05.png","A06.png","A07.png","A08.png","A09.png"],
              minute_zero: 1,
              minute_space: -42,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 226,
              second_startY: 286,
              second_array: ["0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png"],
              second_zero: 1,
              second_space: -2,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 104,
              y: 321,
              week_en: ["S01_P.png","S02_P.png","S03_P.png","S04_P.png","S05_P.png","S06_P.png","S07_P.png"],
              week_tc: ["S01_P.png","S02_P.png","S03_P.png","S04_P.png","S05_P.png","S06_P.png","S07_P.png"],
              week_sc: ["S01_P.png","S02_P.png","S03_P.png","S04_P.png","S05_P.png","S06_P.png","S07_P.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 190,
              y: 4,
              image_array: ["weather_01.png","weather_02.png","weather_03.png","weather_04.png","weather_05.png","weather_06.png","weather_07.png","weather_08.png","weather_09.png","weather_10.png","weather_11.png","weather_12.png","weather_13.png","weather_14.png","weather_15.png","weather_16.png","weather_17.png","weather_18.png","weather_19.png","weather_20.png","weather_21.png","weather_22.png","weather_23.png","weather_24.png","weather_25.png","weather_26.png","weather_27.png","weather_28.png","weather_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 278,
              y: 27,
              font_array: ["0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png"],
              padding: false,
              h_space: -4,
              unit_sc: '0002.png',
              unit_tc: '0002.png',
              unit_en: '0002.png',
              negative_image: '0001.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 204,
              day_startY: 400,
              day_sc_array: ["CH01).png","CH02).png","CH03).png","CH04).png","CH05).png","CH06).png","CH07).png","CH08).png","CH09).png","CH10).png"],
              day_tc_array: ["CH01).png","CH02).png","CH03).png","CH04).png","CH05).png","CH06).png","CH07).png","CH08).png","CH09).png","CH10).png"],
              day_en_array: ["CH01).png","CH02).png","CH03).png","CH04).png","CH05).png","CH06).png","CH07).png","CH08).png","CH09).png","CH10).png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 27,
              hour_startY: 125,
              hour_array: ["A00.png","A01.png","A02.png","A03.png","A04.png","A05.png","A06.png","A07.png","A08.png","A09.png"],
              hour_zero: 1,
              hour_space: -42,
              hour_angle: 0,
              hour_unit_sc: 'A11.png',
              hour_unit_tc: 'A11.png',
              hour_unit_en: 'A11.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 244,
              minute_startY: 125,
              minute_array: ["A00.png","A01.png","A02.png","A03.png","A04.png","A05.png","A06.png","A07.png","A08.png","A09.png"],
              minute_zero: 1,
              minute_space: -42,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 226,
              second_startY: 286,
              second_array: ["0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png"],
              second_zero: 1,
              second_space: -2,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 104,
              y: 321,
              week_en: ["S01_P.png","S02_P.png","S03_P.png","S04_P.png","S05_P.png","S06_P.png","S07_P.png"],
              week_tc: ["S01_P.png","S02_P.png","S03_P.png","S04_P.png","S05_P.png","S06_P.png","S07_P.png"],
              week_sc: ["S01_P.png","S02_P.png","S03_P.png","S04_P.png","S05_P.png","S06_P.png","S07_P.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
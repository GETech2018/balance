﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_heart_rate_text_text_img = ''
        let normal_temperature_high_text_font = ''
        let normal_temperature_low_text_font = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_step_circle_scale = ''
        let normal_step_pointer_progress_img_pointer = ''
        let normal_step_current_text_img = ''
        let normal_battery_pointer_progress_img_pointer = ''
        let normal_battery_text_text_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_month_img = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg_img = ''
        let idle_analog_clock_time_pointer_second = ''
        let idle_heart_rate_text_text_img = ''
        let idle_temperature_high_text_font = ''
        let idle_temperature_low_text_font = ''
        let idle_temperature_current_text_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_step_circle_scale = ''
        let idle_step_pointer_progress_img_pointer = ''
        let idle_step_current_text_img = ''
        let idle_battery_pointer_progress_img_pointer = ''
        let idle_battery_text_text_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_month_img = ''
        let idle_digital_clock_img_time = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'AFFmAIN.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'sec1.png',
              second_centerX: 238,
              second_centerY: 242,
              second_posX: 150,
              second_posY: 150,
              second_cover_path: 'AFFmAIN.png',
              second_cover_x: 0,
              second_cover_y: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 325,
              y: 376,
              font_array: ["dig_red_0.png","dig_red_1.png","dig_red_2.png","dig_red_3.png","dig_red_4.png","dig_red_5.png","dig_red_6.png","dig_red_7.png","dig_red_8.png","dig_red_9.png"],
              padding: false,
              h_space: -7,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 83,
              y: 338,
              w: 150,
              h: 30,
              text_size: 24,
              char_space: -2,
              line_space: 0,
              color: 0xFF808080,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 0,
              y: 338,
              w: 150,
              h: 30,
              text_size: 24,
              char_space: -4,
              line_space: 0,
              color: 0xFF808080,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 87,
              y: 390,
              font_array: ["digits_medium_0.png","digits_medium_1.png","digits_medium_2.png","digits_medium_3.png","digits_medium_4.png","digits_medium_5.png","digits_medium_6.png","digits_medium_7.png","digits_medium_8.png","digits_medium_9.png"],
              padding: false,
              h_space: -9,
              unit_sc: 'gradi.png',
              unit_tc: 'gradi.png',
              unit_en: 'gradi.png',
              negative_image: 'meno.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 63,
              y: 272,
              image_array: ["met_01.png","met_02.png","met_03.png","met_04.png","met_05.png","met_06.png","met_07.png","met_08.png","met_09.png","met_10.png","met_11.png","met_12.png","met_13.png","met_14.png","met_15.png","met_16.png","met_17.png","met_18.png","met_19.png","met_20.png","met_21.png","met_22.png","met_23.png","met_24.png","met_25.png","met_26.png","met_27.png","met_28.png","met_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 245,
              // center_y: 235,
              // start_angle: 93,
              // end_angle: -32,
              // radius: 114,
              // line_width: 13,
              // line_cap: Flat,
              // color: 0xFFB50E00,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            let screenType = hmSetting.getScreenType();
            normal_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 245,
              center_y: 235,
              start_angle: 93,
              end_angle: -32,
              radius: 108,
              line_width: 13,
              corner_flag: 3,
              color: 0xFFB50E00,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_step_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'steps_point_red.png',
              center_x: 241,
              center_y: 239,
              x: 50,
              y: -93,
              start_angle: 254,
              end_angle: 127,
              invalid_visible: false,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 201,
              y: 165,
              font_array: ["dig_small_0.png","dig_small_1.png","dig_small_2.png","dig_small_3.png","dig_small_4.png","dig_small_5.png","dig_small_6.png","dig_small_7.png","dig_small_8.png","dig_small_9.png"],
              padding: false,
              h_space: -6,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'indic.png',
              center_x: 109,
              center_y: 233,
              x: 49,
              y: 66,
              start_angle: -129,
              end_angle: 136,
              invalid_visible: false,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 59,
              y: 260,
              font_array: ["digits_medium_0.png","digits_medium_1.png","digits_medium_2.png","digits_medium_3.png","digits_medium_4.png","digits_medium_5.png","digits_medium_6.png","digits_medium_7.png","digits_medium_8.png","digits_medium_9.png"],
              padding: false,
              h_space: -8,
              unit_sc: 'perc.png',
              unit_tc: 'perc.png',
              unit_en: 'perc.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 185,
              y: 238,
              week_en: ["ba40.png","ba41.png","ba42.png","ba43.png","ba44.png","ba45.png","ba46.png"],
              week_tc: ["ba40.png","ba41.png","ba42.png","ba43.png","ba44.png","ba45.png","ba46.png"],
              week_sc: ["ba40.png","ba41.png","ba42.png","ba43.png","ba44.png","ba45.png","ba46.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 352,
              day_startY: 283,
              day_sc_array: ["dig_red_0.png","dig_red_1.png","dig_red_2.png","dig_red_3.png","dig_red_4.png","dig_red_5.png","dig_red_6.png","dig_red_7.png","dig_red_8.png","dig_red_9.png"],
              day_tc_array: ["dig_red_0.png","dig_red_1.png","dig_red_2.png","dig_red_3.png","dig_red_4.png","dig_red_5.png","dig_red_6.png","dig_red_7.png","dig_red_8.png","dig_red_9.png"],
              day_en_array: ["dig_red_0.png","dig_red_1.png","dig_red_2.png","dig_red_3.png","dig_red_4.png","dig_red_5.png","dig_red_6.png","dig_red_7.png","dig_red_8.png","dig_red_9.png"],
              day_zero: 1,
              day_space: -5,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 219,
              month_startY: 332,
              month_sc_array: ["mon_1.png","mon_2.png","mon_3.png","mon_4.png","mon_5.png","mon_6.png","mon_7.png","mon_8.png","mon_9.png","mon_10.png","mon_11.png","mon_12.png"],
              month_tc_array: ["mon_1.png","mon_2.png","mon_3.png","mon_4.png","mon_5.png","mon_6.png","mon_7.png","mon_8.png","mon_9.png","mon_10.png","mon_11.png","mon_12.png"],
              month_en_array: ["mon_1.png","mon_2.png","mon_3.png","mon_4.png","mon_5.png","mon_6.png","mon_7.png","mon_8.png","mon_9.png","mon_10.png","mon_11.png","mon_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 152,
              hour_startY: 378,
              hour_array: ["v0.png","v1.png","v2.png","v3.png","v4.png","v5.png","v6.png","v7.png","v8.png","v9.png"],
              hour_zero: 1,
              hour_space: -2,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 247,
              minute_startY: 378,
              minute_array: ["m00.png","m01.png","m02.png","m03.png","m04.png","m05.png","m06.png","m07.png","m08.png","m09.png"],
              minute_zero: 1,
              minute_space: -2,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'aodAff.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'sec1.png',
              second_centerX: 238,
              second_centerY: 242,
              second_posX: 150,
              second_posY: 150,
              second_cover_path: 'aodAff.png',
              second_cover_x: 0,
              second_cover_y: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 325,
              y: 376,
              font_array: ["dig_red_0.png","dig_red_1.png","dig_red_2.png","dig_red_3.png","dig_red_4.png","dig_red_5.png","dig_red_6.png","dig_red_7.png","dig_red_8.png","dig_red_9.png"],
              padding: false,
              h_space: -7,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_high_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 83,
              y: 338,
              w: 150,
              h: 30,
              text_size: 24,
              char_space: -2,
              line_space: 0,
              color: 0xFF808080,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_low_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 0,
              y: 338,
              w: 150,
              h: 30,
              text_size: 24,
              char_space: -4,
              line_space: 0,
              color: 0xFF808080,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 87,
              y: 390,
              font_array: ["digits_medium_0.png","digits_medium_1.png","digits_medium_2.png","digits_medium_3.png","digits_medium_4.png","digits_medium_5.png","digits_medium_6.png","digits_medium_7.png","digits_medium_8.png","digits_medium_9.png"],
              padding: false,
              h_space: -9,
              unit_sc: 'gradi.png',
              unit_tc: 'gradi.png',
              unit_en: 'gradi.png',
              negative_image: 'meno.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 63,
              y: 272,
              image_array: ["met_01.png","met_02.png","met_03.png","met_04.png","met_05.png","met_06.png","met_07.png","met_08.png","met_09.png","met_10.png","met_11.png","met_12.png","met_13.png","met_14.png","met_15.png","met_16.png","met_17.png","met_18.png","met_19.png","met_20.png","met_21.png","met_22.png","met_23.png","met_24.png","met_25.png","met_26.png","met_27.png","met_28.png","met_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 245,
              // center_y: 235,
              // start_angle: 93,
              // end_angle: -32,
              // radius: 114,
              // line_width: 13,
              // line_cap: Flat,
              // color: 0xFFB50E00,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 245,
              center_y: 235,
              start_angle: 93,
              end_angle: -32,
              radius: 108,
              line_width: 13,
              corner_flag: 3,
              color: 0xFFB50E00,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'steps_point_red.png',
              center_x: 241,
              center_y: 239,
              x: 50,
              y: -93,
              start_angle: 254,
              end_angle: 127,
              invalid_visible: false,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 201,
              y: 165,
              font_array: ["dig_small_0.png","dig_small_1.png","dig_small_2.png","dig_small_3.png","dig_small_4.png","dig_small_5.png","dig_small_6.png","dig_small_7.png","dig_small_8.png","dig_small_9.png"],
              padding: false,
              h_space: -6,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'indic.png',
              center_x: 109,
              center_y: 233,
              x: 49,
              y: 66,
              start_angle: -129,
              end_angle: 136,
              invalid_visible: false,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 59,
              y: 260,
              font_array: ["digits_medium_0.png","digits_medium_1.png","digits_medium_2.png","digits_medium_3.png","digits_medium_4.png","digits_medium_5.png","digits_medium_6.png","digits_medium_7.png","digits_medium_8.png","digits_medium_9.png"],
              padding: false,
              h_space: -8,
              unit_sc: 'perc.png',
              unit_tc: 'perc.png',
              unit_en: 'perc.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 185,
              y: 238,
              week_en: ["ba40.png","ba41.png","ba42.png","ba43.png","ba44.png","ba45.png","ba46.png"],
              week_tc: ["ba40.png","ba41.png","ba42.png","ba43.png","ba44.png","ba45.png","ba46.png"],
              week_sc: ["ba40.png","ba41.png","ba42.png","ba43.png","ba44.png","ba45.png","ba46.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 352,
              day_startY: 283,
              day_sc_array: ["dig_red_0.png","dig_red_1.png","dig_red_2.png","dig_red_3.png","dig_red_4.png","dig_red_5.png","dig_red_6.png","dig_red_7.png","dig_red_8.png","dig_red_9.png"],
              day_tc_array: ["dig_red_0.png","dig_red_1.png","dig_red_2.png","dig_red_3.png","dig_red_4.png","dig_red_5.png","dig_red_6.png","dig_red_7.png","dig_red_8.png","dig_red_9.png"],
              day_en_array: ["dig_red_0.png","dig_red_1.png","dig_red_2.png","dig_red_3.png","dig_red_4.png","dig_red_5.png","dig_red_6.png","dig_red_7.png","dig_red_8.png","dig_red_9.png"],
              day_zero: 1,
              day_space: -5,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 219,
              month_startY: 332,
              month_sc_array: ["mon_1.png","mon_2.png","mon_3.png","mon_4.png","mon_5.png","mon_6.png","mon_7.png","mon_8.png","mon_9.png","mon_10.png","mon_11.png","mon_12.png"],
              month_tc_array: ["mon_1.png","mon_2.png","mon_3.png","mon_4.png","mon_5.png","mon_6.png","mon_7.png","mon_8.png","mon_9.png","mon_10.png","mon_11.png","mon_12.png"],
              month_en_array: ["mon_1.png","mon_2.png","mon_3.png","mon_4.png","mon_5.png","mon_6.png","mon_7.png","mon_8.png","mon_9.png","mon_10.png","mon_11.png","mon_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 152,
              hour_startY: 378,
              hour_array: ["v0.png","v1.png","v2.png","v3.png","v4.png","v5.png","v6.png","v7.png","v8.png","v9.png"],
              hour_zero: 1,
              hour_space: -2,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 247,
              minute_startY: 378,
              minute_array: ["m00.png","m01.png","m02.png","m03.png","m04.png","m05.png","m06.png","m07.png","m08.png","m09.png"],
              minute_zero: 1,
              minute_space: -2,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 233,
              y: 250,
              w: 58,
              h: 112,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'vuoto.png',
              normal_src: 'vuoto.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 87,
              y: 297,
              w: 58,
              h: 112,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'vuoto.png',
              normal_src: 'vuoto.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'WeatherScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 213,
              y: 165,
              w: 58,
              h: 52,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'vuoto.png',
              normal_src: 'vuoto.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'activityAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 335,
              y: 354,
              w: 58,
              h: 52,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'vuoto.png',
              normal_src: 'vuoto.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'heart_app_Screen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            function scale_call() {
              console.log('scale_call()');

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_cs_normal_step = progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_step * 100);
                  if (normal_step_circle_scale) {
                    normal_step_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 245,
                      center_y: 235,
                      start_angle: 93,
                      end_angle: -32,
                      radius: 108,
                      line_width: 13,
                      corner_flag: 3,
                      color: 0xFFB50E00,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales STEP');
                let progress_cs_idle_step = progressStep;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_step_circle_scale_circle_scale
                  let level = Math.round(progress_cs_idle_step * 100);
                  if (idle_step_circle_scale) {
                    idle_step_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 245,
                      center_y: 235,
                      start_angle: 93,
                      end_angle: -32,
                      radius: 108,
                      line_width: 13,
                      corner_flag: 3,
                      color: 0xFFB50E00,
                      show_level: hmUI.show_level.ONLY_AOD,
                      level: level,
                    });
                  };
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
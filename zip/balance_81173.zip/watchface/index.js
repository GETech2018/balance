﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_pointer_progress_img_pointer = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_text_separator_img = ''
        let normal_battery_pointer_progress_img_pointer = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_humidity_text_text_img = ''
        let normal_wind_icon_img = ''
        let normal_wind_direction_image_progress_img_level = ''
        let normal_wind_pointer_progress_img_pointer = ''
        let normal_wind_text_text_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_distance_TextRotate = new Array(5);
        let normal_distance_TextRotate_ASCIIARRAY = new Array(10);
        let normal_distance_TextRotate_img_width = 1;
        let normal_distance_TextRotate_unit = null;
        let normal_distance_TextRotate_unit_width = 17;
        let normal_distance_TextRotate_dot_width = 1;
        let normal_distance_TextRotate_error_img_width = 1;
        let normal_distance_text_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_step_current_text_img = ''
        let normal_digital_clock_img_time_second = ''
        let normal_digital_clock_second_separator_img = ''
        let normal_digital_clock_img_time_minute = ''
        let normal_digital_clock_minute_separator_img = ''
        let normal_digital_clock_img_time_hour = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_analog_clock_pro_hour_pointer_img = ''
        let normal_analog_clock_pro_minute_pointer_img = ''
        let normal_timerUpdateSec = undefined;
        let normal_analog_clock_pro_second_pointer_img = ''
        let normal_timerUpdateSecSmooth = undefined;
        let lastTime = 0;
        let idle_background_bg_img = ''
        let idle_heart_rate_icon_img = ''
        let idle_heart_rate_pointer_progress_img_pointer = ''
        let idle_heart_rate_text_text_img = ''
        let idle_heart_rate_text_separator_img = ''
        let idle_battery_pointer_progress_img_pointer = ''
        let idle_temperature_current_text_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_humidity_text_text_img = ''
        let idle_wind_icon_img = ''
        let idle_wind_direction_image_progress_img_level = ''
        let idle_wind_pointer_progress_img_pointer = ''
        let idle_wind_text_text_img = ''
        let idle_moon_image_progress_img_level = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_day = ''
        let idle_distance_TextRotate = new Array(5);
        let idle_distance_TextRotate_ASCIIARRAY = new Array(10);
        let idle_distance_TextRotate_img_width = 1;
        let idle_distance_TextRotate_unit = null;
        let idle_distance_TextRotate_unit_width = 17;
        let idle_distance_TextRotate_dot_width = 1;
        let idle_distance_TextRotate_error_img_width = 1;
        let idle_distance_text_text_img = ''
        let idle_calorie_current_text_img = ''
        let idle_step_current_text_img = ''
        let idle_digital_clock_img_time_second = ''
        let idle_digital_clock_second_separator_img = ''
        let idle_digital_clock_img_time_minute = ''
        let idle_digital_clock_minute_separator_img = ''
        let idle_digital_clock_img_time_hour = ''
        let idle_digital_clock_hour_separator_img = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_analog_clock_pro_hour_pointer_img = ''
        let idle_analog_clock_pro_minute_pointer_img = ''
        let idle_timerUpdateSec = undefined;
        let idle_analog_clock_pro_second_pointer_img = ''
        let idle_timerUpdateSecSmooth = undefined;
        let normal_stopwatch_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let Button_7 = ''
        let timeSensor = ''

       console.log('user_functions.js');
        // start user_functions.js
        let normal_compass_angle_img = '' 
        let compass = null 


        // Start color change screen
        let colornumber_main = 1
        let totalcolors_main = 7
        let namecolor_main = ''

        function click_Color() {
            if(colornumber_main>=totalcolors_main) {
            colornumber_main=1;
                }
            else {
                colornumber_main=colornumber_main+1;
            }

if ( colornumber_main == 1) { namecolor_main = "Gray"}
if ( colornumber_main == 2) { namecolor_main = "Red"}
if ( colornumber_main == 3) { namecolor_main = "Orange"}
if ( colornumber_main == 4) { namecolor_main = "Blue"}
if ( colornumber_main == 5) { namecolor_main = "Blue Green"}
if ( colornumber_main == 6) { namecolor_main = "Green"}
if ( colornumber_main == 7) { namecolor_main = "Yellow"}
hmUI.showToast({text: namecolor_main });


             normal_background_bg_img.setProperty(hmUI.prop.SRC, "main" + parseInt(colornumber_main) + ".png");
                           
        }

        // Start color change analog
        let colornumber_mainH = 1
        let totalcolors_mainH = 4
        let namecolor_mainH = ''

        function click_Analog() {

 if(elementnumber_1==1){
            if(colornumber_mainH >= totalcolors_mainH) {
            colornumber_mainH=1;
                }
            else {
                colornumber_mainH=colornumber_mainH+1;
            }

if ( colornumber_mainH == 1) { namecolor_mainH = "Blue"}
if ( colornumber_mainH == 2) { namecolor_mainH = "Yellow"}
if ( colornumber_mainH == 3) { namecolor_mainH = "Green"}
if ( colornumber_mainH == 4) { namecolor_mainH = "Pink"}

hmUI.showToast({text: namecolor_mainH });


             normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.SRC, "Hand_H" + parseInt(colornumber_mainH) + ".png");
             normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.SRC, "Hand_M" + parseInt(colornumber_mainH) + ".png");
                           
        }
}

        // Start analog on/off
        let btn_element_1 = ''
        let elementnumber_1 = 1
        let total_elemente = 2

        function click_elemente() {
            if(elementnumber_1==total_elemente) {
            elementnumber_1=1;
                UpdateElementeOne();
                }
            else {
                elementnumber_1=elementnumber_1+1;
                if(elementnumber_1==2) {
                  UpdateElementeTwo();
                }

            }
            if(elementnumber_1==1) hmUI.showToast({text: 'Hand clock ON'});
            if(elementnumber_1==2) hmUI.showToast({text: 'Handclock OFF'});
        }

        //Hand clock on
        function UpdateElementeOne(){
               normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.VISIBLE, true);
               normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.VISIBLE, true);
                normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.VISIBLE, true);

        }

        //hand clock off
        function UpdateElementeTwo(){

               normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.VISIBLE, false);
               normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.VISIBLE, false);

        }



        // end user_functions.js

        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'main1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 312,
              y: 169,
              src: 'amazfit_logo.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'Pointer_heart.png',
              center_x: 121,
              center_y: 238,
              x: 23,
              y: 71,
              start_angle: 182,
              end_angle: 125,
              invalid_visible: false,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 376,
              y: 293,
              font_array: ["Act2W_0.png","Act2W_1.png","Act2W_2.png","Act2W_3.png","Act2W_4.png","Act2W_5.png","Act2W_6.png","Act2W_7.png","Act2W_8.png","Act2W_9.png"],
              padding: false,
              h_space: 0,
              invalid_image: 'Act2W_0.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 357,
              y: 301,
              src: 'Heart_icon.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'Pointer_Batt.png',
              center_x: 121,
              center_y: 239,
              x: 21,
              y: 40,
              start_angle: 212,
              end_angle: 391,
              invalid_visible: false,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 353,
              y: 260,
              font_array: ["Act2_0.png","Act2_1.png","Act2_2.png","Act2_3.png","Act2_4.png","Act2_5.png","Act2_6.png","Act2_7.png","Act2_8.png","Act2_9.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'Weather_Symbo1.png',
              unit_tc: 'Weather_Symbo1.png',
              unit_en: 'Weather_Symbo1.png',
              negative_image: 'Weather_Symbo2.png',
              invalid_image: 'Weather_Symbo2.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 364,
              y: 225,
              image_array: ["Weather_icon_BL_01.png","Weather_icon_BL_02.png","Weather_icon_BL_03.png","Weather_icon_BL_04.png","Weather_icon_BL_05.png","Weather_icon_BL_06.png","Weather_icon_BL_07.png","Weather_icon_BL_08.png","Weather_icon_BL_09.png","Weather_icon_BL_10.png","Weather_icon_BL_11.png","Weather_icon_BL_12.png","Weather_icon_BL_13.png","Weather_icon_BL_14.png","Weather_icon_BL_15.png","Weather_icon_BL_16.png","Weather_icon_BL_17.png","Weather_icon_BL_18.png","Weather_icon_BL_19.png","Weather_icon_BL_20.png","Weather_icon_BL_21.png","Weather_icon_BL_22.png","Weather_icon_BL_23.png","Weather_icon_BL_24.png","Weather_icon_BL_25.png","Weather_icon_BL_26.png","Weather_icon_BL_27.png","Weather_icon_BL_28.png","Weather_icon_BL_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 289,
              y: 288,
              font_array: ["Act2_0.png","Act2_1.png","Act2_2.png","Act2_3.png","Act2_4.png","Act2_5.png","Act2_6.png","Act2_7.png","Act2_8.png","Act2_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'hum_unit.png',
              unit_tc: 'hum_unit.png',
              unit_en: 'hum_unit.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 245,
              y: 368,
              src: 'wind_icon.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_direction_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 194,
              y: 369,
              image_array: ["Compass1.png","Compass2.png","Compass3.png","Compass4.png","Compass5.png","Compass6.png","Compass7.png","Compass8.png"],
              image_length: 8,
              type: hmUI.data_type.WIND_DIRECTION,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'compass.png',
              center_x: 282,
              center_y: 343,
              x: 12,
              y: 14,
              start_angle: 0,
              end_angle: 360,
              invalid_visible: false,
              type: hmUI.data_type.WIND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 218,
              y: 369,
              font_array: ["TimeS_0.png","TimeS_1.png","TimeS_2.png","TimeS_3.png","TimeS_4.png","TimeS_5.png","TimeS_6.png","TimeS_7.png","TimeS_8.png","TimeS_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WIND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 185,
              y: 327,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 225,
              month_startY: 344,
              month_sc_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_tc_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_en_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 201,
              y: 284,
              week_en: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              week_tc: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              week_sc: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 223,
              day_startY: 307,
              day_sc_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              day_tc_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              day_en_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              day_zero: 1,
              day_space: 1,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_distance_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 299,
              // y: 72,
              // font_array: ["e0.png","e1.png","e2.png","e3.png","e4.png","e5.png","e6.png","e7.png","e8.png","e9.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: 0,
              // unit_en: 'Dis_KM.png',
              // imperial_unit_en: 'Dis_Mi.png',
              // invalid_image: '0_Empty.png',
              // dot_image: '0_Empty.png',
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.DISTANCE,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_distance_TextRotate_ASCIIARRAY[0] = 'e0.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[1] = 'e1.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[2] = 'e2.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[3] = 'e3.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[4] = 'e4.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[5] = 'e5.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[6] = 'e6.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[7] = 'e7.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[8] = 'e8.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[9] = 'e9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              normal_distance_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 299,
                center_y: 72,
                pos_x: 299,
                pos_y: 72,
                angle: 0,
                src: 'e0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_distance_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_distance_TextRotate_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              center_x: 299,
              center_y: 72,
              pos_x: 299,
              pos_y: 72,
              angle: 0,
              src: 'Dis_KM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_distance_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);

            const mileageUnit = hmSetting.getMileageUnit();
            if (mileageUnit == 1) {
              normal_distance_TextRotate_unit.setProperty(hmUI.prop.SRC, 'Dis_Mi.png');
            };
            //end of ignored block
            
            const distance = hmSensor.createSensor(hmSensor.id.DISTANCE);
            distance.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });
            
            function toDegree (radian) {
              return radian * (180 / Math.PI);
            };

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 259,
              y: 83,
              font_array: ["Act2_0.png","Act2_1.png","Act2_2.png","Act2_3.png","Act2_4.png","Act2_5.png","Act2_6.png","Act2_7.png","Act2_8.png","Act2_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: '0_Empty.png',
              unit_tc: '0_Empty.png',
              unit_en: '0_Empty.png',
              imperial_unit_sc: '0_Empty.png',
              imperial_unit_tc: '0_Empty.png',
              imperial_unit_en: '0_Empty.png',
              dot_image: 'Dis_dot.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 168,
              y: 84,
              font_array: ["Act2_0.png","Act2_1.png","Act2_2.png","Act2_3.png","Act2_4.png","Act2_5.png","Act2_6.png","Act2_7.png","Act2_8.png","Act2_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 201,
              y: 100,
              font_array: ["Act1_0.png","Act1_1.png","Act1_2.png","Act1_3.png","Act1_4.png","Act1_5.png","Act1_6.png","Act1_7.png","Act1_8.png","Act1_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_second = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              second_startX: 301,
              second_startY: 121,
              second_array: ["TimeS_0.png","TimeS_1.png","TimeS_2.png","TimeS_3.png","TimeS_4.png","TimeS_5.png","TimeS_6.png","TimeS_7.png","TimeS_8.png","TimeS_9.png"],
              second_zero: 1,
              second_space: 1,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_second_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 255,
              y: 120,
              src: 'icon_sec.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 246,
              minute_startY: 136,
              minute_array: ["Time_0.png","Time_1.png","Time_2.png","Time_3.png","Time_4.png","Time_5.png","Time_6.png","Time_7.png","Time_8.png","Time_9.png"],
              minute_zero: 1,
              minute_space: -1,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_minute_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 153,
              y: 120,
              src: 'Clock_24H.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 181,
              hour_startY: 135,
              hour_array: ["Time_0.png","Time_1.png","Time_2.png","Time_3.png","Time_4.png","Time_5.png","Time_6.png","Time_7.png","Time_8.png","Time_9.png"],
              hour_zero: 1,
              hour_space: -1,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 237,
              y: 136,
              src: 'Time_dot.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 153,
              am_y: 120,
              am_sc_path: 'Clock_AM.png',
              am_en_path: 'Clock_AM.png',
              pm_x: 153,
              pm_y: 120,
              pm_sc_path: 'Clock_PM.png',
              pm_en_path: 'Clock_PM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 348,
              y: 349,
              src: 'System_BT_OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 164,
              y: 134,
              src: 'System_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

//////////
/////////
            console.log('user_script.js');
            // start user_script.js
         normal_compass_angle_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 218,
              y: 200,
              pos_x: 0,
              pos_y: 0,
              center_x: 28,
              center_y: 31,
              angle: 0,
              src: 'compassN.png',
//          src: 'bgpoint.png',
       //   src: 'preview.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

        const screen_type = hmSetting.getScreenType()
 if(screen_type == hmSetting.screen_type.WATCHFACE){
                compass = hmSensor.createSensor(hmSensor.id.COMPASS)
                compass.start()

                if (compass.direction_angle && compass.direction  && compass.direction_angle != 'INVALID') { // устанавливаем первоночальные надписи
                     let compass_direction_angle = `${compass.direction_angle}`;
                    let compass_direction_angle_direction = `${compass.direction_angle}° ${compass.direction}`;
                    normal_compass_angle_img.setProperty(hmUI.prop.ANGLE, -compass.direction_angle);
                } else {
                    normal_compass_angle_img.setProperty(hmUI.prop.ANGLE, 0);
                }



                compass.addEventListener(hmSensor.event.CHANGE, function (compass_res) { // меняем надписи при изменении направления
                    if (compass_res.calibration_status) {
                        let compass_direction_angle = `${compass_res.direction_angle}`;
                        let compass_direction_angle_direction = `${compass_res.direction_angle}° ${compass_res.direction}`;
                        normal_compass_angle_img.setProperty(hmUI.prop.ANGLE, -compass_res.direction_angle);
                    } else {
                        normal_compass_angle_img.setProperty(hmUI.prop.ANGLE, 0);
                    }

                })
            }
            // end user_script.js


/////////
////////


            const deviceInfo = hmSetting.getDeviceInfo();
            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.MINUTEEND, function() {
              let updateHour = timeSensor.minute == 0;

              time_update(UpdateHour, true);
            });

            // normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'Hand_H1.png',
              // center_x: 240,
              // center_y: 240,
              // x: 36,
              // y: 231,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.hour,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 36,
              pos_y: 240 - 231,
              center_x: 240,
              center_y: 240,
              src: 'Hand_H1.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            // normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'Hand_M1.png',
              // center_x: 240,
              // center_y: 240,
              // x: 36,
              // y: 231,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.minute,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 36,
              pos_y: 240 - 231,
              center_x: 240,
              center_y: 240,
              src: 'Hand_M1.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'Hand_S1.png',
              // center_x: 240,
              // center_y: 240,
              // x: 36,
              // y: 231,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 36,
              pos_y: 240 - 231,
              center_x: 240,
              center_y: 240,
              src: 'Hand_S1.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            function startSecAnim(sec, animDuration) {
              const secAnim = {
                anim_steps: [{
                  anim_rate: 'linear',
                  anim_duration: animDuration,
                  anim_from: sec,
                  anim_to: sec + (360*(animDuration*6/1000))/360,
                  anim_key: 'angle',
                }],
                anim_fps: 15,
                anim_auto_start: 1,
                anim_repeat: 1,
                anim_auto_destroy: 1,
              }
              normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANIM, secAnim);
            }
            // normal_analog_clock_pro_smooth_second = hmUI.createWidget(hmUI.widget.SMOOTH_SECOND, {
              // type: 4,
              // fps: 15,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });



            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'main1.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 312,
              y: 169,
              src: 'amazfit_logo.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'Pointer_heart.png',
              center_x: 121,
              center_y: 238,
              x: 23,
              y: 71,
              start_angle: 182,
              end_angle: 125,
              invalid_visible: false,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 376,
              y: 293,
              font_array: ["Act2W_0.png","Act2W_1.png","Act2W_2.png","Act2W_3.png","Act2W_4.png","Act2W_5.png","Act2W_6.png","Act2W_7.png","Act2W_8.png","Act2W_9.png"],
              padding: false,
              h_space: 0,
              invalid_image: 'Act2W_0.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 357,
              y: 301,
              src: 'Heart_icon.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'Pointer_Batt.png',
              center_x: 121,
              center_y: 239,
              x: 21,
              y: 40,
              start_angle: 212,
              end_angle: 391,
              invalid_visible: false,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 353,
              y: 260,
              font_array: ["Act2_0.png","Act2_1.png","Act2_2.png","Act2_3.png","Act2_4.png","Act2_5.png","Act2_6.png","Act2_7.png","Act2_8.png","Act2_9.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'Weather_Symbo1.png',
              unit_tc: 'Weather_Symbo1.png',
              unit_en: 'Weather_Symbo1.png',
              negative_image: 'Weather_Symbo2.png',
              invalid_image: 'Weather_Symbo2.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 364,
              y: 225,
              image_array: ["Weather_icon_BL_01.png","Weather_icon_BL_02.png","Weather_icon_BL_03.png","Weather_icon_BL_04.png","Weather_icon_BL_05.png","Weather_icon_BL_06.png","Weather_icon_BL_07.png","Weather_icon_BL_08.png","Weather_icon_BL_09.png","Weather_icon_BL_10.png","Weather_icon_BL_11.png","Weather_icon_BL_12.png","Weather_icon_BL_13.png","Weather_icon_BL_14.png","Weather_icon_BL_15.png","Weather_icon_BL_16.png","Weather_icon_BL_17.png","Weather_icon_BL_18.png","Weather_icon_BL_19.png","Weather_icon_BL_20.png","Weather_icon_BL_21.png","Weather_icon_BL_22.png","Weather_icon_BL_23.png","Weather_icon_BL_24.png","Weather_icon_BL_25.png","Weather_icon_BL_26.png","Weather_icon_BL_27.png","Weather_icon_BL_28.png","Weather_icon_BL_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 289,
              y: 288,
              font_array: ["Act2_0.png","Act2_1.png","Act2_2.png","Act2_3.png","Act2_4.png","Act2_5.png","Act2_6.png","Act2_7.png","Act2_8.png","Act2_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'hum_unit.png',
              unit_tc: 'hum_unit.png',
              unit_en: 'hum_unit.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_wind_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 245,
              y: 368,
              src: 'wind_icon.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_wind_direction_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 194,
              y: 369,
              image_array: ["Compass1.png","Compass2.png","Compass3.png","Compass4.png","Compass5.png","Compass6.png","Compass7.png","Compass8.png"],
              image_length: 8,
              type: hmUI.data_type.WIND_DIRECTION,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_wind_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'compass.png',
              center_x: 282,
              center_y: 343,
              x: 12,
              y: 14,
              start_angle: 0,
              end_angle: 360,
              invalid_visible: false,
              type: hmUI.data_type.WIND,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_wind_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 218,
              y: 369,
              font_array: ["TimeS_0.png","TimeS_1.png","TimeS_2.png","TimeS_3.png","TimeS_4.png","TimeS_5.png","TimeS_6.png","TimeS_7.png","TimeS_8.png","TimeS_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WIND,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 185,
              y: 327,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 225,
              month_startY: 344,
              month_sc_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_tc_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_en_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 201,
              y: 284,
              week_en: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              week_tc: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              week_sc: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 223,
              day_startY: 307,
              day_sc_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              day_tc_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              day_en_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              day_zero: 1,
              day_space: 1,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_distance_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 299,
              // y: 72,
              // font_array: ["e0.png","e1.png","e2.png","e3.png","e4.png","e5.png","e6.png","e7.png","e8.png","e9.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: 0,
              // unit_en: 'Dis_KM.png',
              // imperial_unit_en: 'Dis_Mi.png',
              // invalid_image: '0_Empty.png',
              // dot_image: '0_Empty.png',
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.DISTANCE,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_distance_TextRotate_ASCIIARRAY[0] = 'e0.png';  // set of images with numbers
            idle_distance_TextRotate_ASCIIARRAY[1] = 'e1.png';  // set of images with numbers
            idle_distance_TextRotate_ASCIIARRAY[2] = 'e2.png';  // set of images with numbers
            idle_distance_TextRotate_ASCIIARRAY[3] = 'e3.png';  // set of images with numbers
            idle_distance_TextRotate_ASCIIARRAY[4] = 'e4.png';  // set of images with numbers
            idle_distance_TextRotate_ASCIIARRAY[5] = 'e5.png';  // set of images with numbers
            idle_distance_TextRotate_ASCIIARRAY[6] = 'e6.png';  // set of images with numbers
            idle_distance_TextRotate_ASCIIARRAY[7] = 'e7.png';  // set of images with numbers
            idle_distance_TextRotate_ASCIIARRAY[8] = 'e8.png';  // set of images with numbers
            idle_distance_TextRotate_ASCIIARRAY[9] = 'e9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              idle_distance_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 299,
                center_y: 72,
                pos_x: 299,
                pos_y: 72,
                angle: 0,
                src: 'e0.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_distance_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            idle_distance_TextRotate_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              center_x: 299,
              center_y: 72,
              pos_x: 299,
              pos_y: 72,
              angle: 0,
              src: 'Dis_KM.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            idle_distance_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);

            if (mileageUnit == 1) {
              idle_distance_TextRotate_unit.setProperty(hmUI.prop.SRC, 'Dis_Mi.png');
            };
            //end of ignored block

            idle_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 259,
              y: 83,
              font_array: ["Act2_0.png","Act2_1.png","Act2_2.png","Act2_3.png","Act2_4.png","Act2_5.png","Act2_6.png","Act2_7.png","Act2_8.png","Act2_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: '0_Empty.png',
              unit_tc: '0_Empty.png',
              unit_en: '0_Empty.png',
              imperial_unit_sc: '0_Empty.png',
              imperial_unit_tc: '0_Empty.png',
              imperial_unit_en: '0_Empty.png',
              dot_image: 'Dis_dot.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 168,
              y: 84,
              font_array: ["Act2_0.png","Act2_1.png","Act2_2.png","Act2_3.png","Act2_4.png","Act2_5.png","Act2_6.png","Act2_7.png","Act2_8.png","Act2_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 201,
              y: 100,
              font_array: ["Act1_0.png","Act1_1.png","Act1_2.png","Act1_3.png","Act1_4.png","Act1_5.png","Act1_6.png","Act1_7.png","Act1_8.png","Act1_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_second = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              second_startX: 301,
              second_startY: 121,
              second_array: ["TimeS_0.png","TimeS_1.png","TimeS_2.png","TimeS_3.png","TimeS_4.png","TimeS_5.png","TimeS_6.png","TimeS_7.png","TimeS_8.png","TimeS_9.png"],
              second_zero: 1,
              second_space: 1,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_second_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 255,
              y: 120,
              src: 'icon_sec.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 246,
              minute_startY: 136,
              minute_array: ["Time_0.png","Time_1.png","Time_2.png","Time_3.png","Time_4.png","Time_5.png","Time_6.png","Time_7.png","Time_8.png","Time_9.png"],
              minute_zero: 1,
              minute_space: -1,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_minute_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 153,
              y: 120,
              src: 'Clock_24H.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 181,
              hour_startY: 135,
              hour_array: ["Time_0.png","Time_1.png","Time_2.png","Time_3.png","Time_4.png","Time_5.png","Time_6.png","Time_7.png","Time_8.png","Time_9.png"],
              hour_zero: 1,
              hour_space: -1,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 237,
              y: 136,
              src: 'Time_dot.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 153,
              am_y: 120,
              am_sc_path: 'Clock_AM.png',
              am_en_path: 'Clock_AM.png',
              pm_x: 153,
              pm_y: 120,
              pm_sc_path: 'Clock_PM.png',
              pm_en_path: 'Clock_PM.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'Hand_H1.png',
              // center_x: 240,
              // center_y: 240,
              // x: 36,
              // y: 231,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.hour,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });


            idle_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 36,
              pos_y: 240 - 231,
              center_x: 240,
              center_y: 240,
              src: 'Hand_H1.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'Hand_M1.png',
              // center_x: 240,
              // center_y: 240,
              // x: 36,
              // y: 231,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.minute,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });


            idle_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 36,
              pos_y: 240 - 231,
              center_x: 240,
              center_y: 240,
              src: 'Hand_M1.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'Hand_S1.png',
              // center_x: 240,
              // center_y: 240,
              // x: 36,
              // y: 231,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });


            idle_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 36,
              pos_y: 240 - 231,
              center_x: 240,
              center_y: 240,
              src: 'Hand_S1.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_analog_clock_pro_smooth_second = hmUI.createWidget(hmUI.widget.SMOOTH_SECOND, {
              // type: 2,
              // fps: 15,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            console.log('Watch_Face.Shortcuts');

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 259,
              y: 137,
              w: 33,
              h: 31,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 195,
              y: 140,
              w: 28,
              h: 28,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 146,
              y: 119,
              w: 34,
              h: 36,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 185,
              y: 325,
              w: 32,
              h: 32,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 350,
              y: 228,
              w: 48,
              h: 42,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 177,
              y: 60,
              w: 35,
              h: 36,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 360,
              y: 289,
              w: 59,
              h: 30,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 121,
              y: 272,
              w: 61,
              h: 42,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 224,
              y: 78,
              w: 31,
              h: 40,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 314,
              y: 170,
              w: 47,
              h: 35,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'CompassScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 266,
              y: 61,
              w: 47,
              h: 35,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'SportListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 219,
              y: 285,
              w: 46,
              h: 56,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 61,
              y: 190,
              w: 45,
              h: 96,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PowerSaveHintScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 218,
              y: 404,
              w: 45,
              h: 96,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                click_Color() 
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button


            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 220,
              y: 212,
              w: 45,
              h: 45,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
               click_Analog() 
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button


            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 387,
              y: 169,
              w: 63,
              h: 45,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
             click_elemente()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button




            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              if (updateHour) {
                let normal_hour = hour;
                let normal_fullAngle_hour = 360;
                if (normal_hour > 11) normal_hour -= 12;
                let normal_angle_hour = 0 + normal_fullAngle_hour*normal_hour/12 + (normal_fullAngle_hour/12)*minute/60;
                if (normal_analog_clock_pro_hour_pointer_img) normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_hour);
              };

              if (updateMinute) {
                let normal_fullAngle_minute = 360;
                let normal_angle_minute = 0 + normal_fullAngle_minute*(minute + second/60)/60;
                if (normal_analog_clock_pro_minute_pointer_img) normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_minute);
              };

              if (updateHour) {
                let idle_hour = hour;
                let idle_fullAngle_hour = 360;
                if (idle_hour > 11) idle_hour -= 12;
                let idle_angle_hour = 0 + idle_fullAngle_hour*idle_hour/12 + (idle_fullAngle_hour/12)*minute/60;
                if (idle_analog_clock_pro_hour_pointer_img) idle_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.ANGLE, idle_angle_hour);
              };

              if (updateMinute) {
                let idle_fullAngle_minute = 360;
                let idle_angle_minute = 0 + idle_fullAngle_minute*(minute + second/60)/60;
                if (idle_analog_clock_pro_minute_pointer_img) idle_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.ANGLE, idle_angle_minute);
              };

              let idle_fullAngle_second = 360;
              let idle_angle_second = 0 + idle_fullAngle_second*(second + (timeSensor.utc % 1000)/1000)/60;
              if (idle_analog_clock_pro_second_pointer_img) idle_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, idle_angle_second);

            };

            function text_update() {
              console.log('text_update()');

              console.log('update text rotate DISTANCE');
              let distanceCurrent = distance.current;
              let normal_distance_rotate_string = (distanceCurrent / 1000).toFixed(2);

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  normal_distance_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_distance_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
                if (distanceCurrent != null && distanceCurrent != undefined && isFinite(distanceCurrent) && normal_distance_rotate_string.length > 0 && normal_distance_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let normal_distance_TextRotate_posOffset = normal_distance_TextRotate_img_width * normal_distance_rotate_string.length;
                  normal_distance_TextRotate_posOffset = normal_distance_TextRotate_posOffset - normal_distance_TextRotate_img_width + normal_distance_TextRotate_dot_width;
                  img_offset -= normal_distance_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_distance_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_distance_TextRotate[index].setProperty(hmUI.prop.POS_X, 299 + img_offset);
                      normal_distance_TextRotate[index].setProperty(hmUI.prop.SRC, normal_distance_TextRotate_ASCIIARRAY[charCode]);
                      normal_distance_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_distance_TextRotate_img_width;
                      index++;
                    }  // end if digit
                    else { 
                      normal_distance_TextRotate[index].setProperty(hmUI.prop.POS_X, 299 + img_offset);
                      normal_distance_TextRotate[index].setProperty(hmUI.prop.SRC, '0_Empty.png');
                      normal_distance_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_distance_TextRotate_dot_width;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                  normal_distance_TextRotate_unit.setProperty(hmUI.prop.POS_X, 299 + img_offset);
                  normal_distance_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite
                else {
                  normal_distance_TextRotate[0].setProperty(hmUI.prop.POS_X, 299 - normal_distance_TextRotate_error_img_width / 2);
                  normal_distance_TextRotate[0].setProperty(hmUI.prop.SRC, '0_Empty.png');
                  normal_distance_TextRotate[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

              console.log('update text rotate DISTANCE');
              let idle_distance_rotate_string = (distanceCurrent / 1000).toFixed(2);

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  idle_distance_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                idle_distance_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
                if (distanceCurrent != null && distanceCurrent != undefined && isFinite(distanceCurrent) && idle_distance_rotate_string.length > 0 && idle_distance_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let idle_distance_TextRotate_posOffset = idle_distance_TextRotate_img_width * idle_distance_rotate_string.length;
                  idle_distance_TextRotate_posOffset = idle_distance_TextRotate_posOffset - idle_distance_TextRotate_img_width + idle_distance_TextRotate_dot_width;
                  img_offset -= idle_distance_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of idle_distance_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_distance_TextRotate[index].setProperty(hmUI.prop.POS_X, 299 + img_offset);
                      idle_distance_TextRotate[index].setProperty(hmUI.prop.SRC, idle_distance_TextRotate_ASCIIARRAY[charCode]);
                      idle_distance_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_distance_TextRotate_img_width;
                      index++;
                    }  // end if digit
                    else { 
                      idle_distance_TextRotate[index].setProperty(hmUI.prop.POS_X, 299 + img_offset);
                      idle_distance_TextRotate[index].setProperty(hmUI.prop.SRC, '0_Empty.png');
                      idle_distance_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_distance_TextRotate_dot_width;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                  idle_distance_TextRotate_unit.setProperty(hmUI.prop.POS_X, 299 + img_offset);
                  idle_distance_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite
                else {
                  idle_distance_TextRotate[0].setProperty(hmUI.prop.POS_X, 299 - idle_distance_TextRotate_error_img_width / 2);
                  idle_distance_TextRotate[0].setProperty(hmUI.prop.SRC, '0_Empty.png');
                  idle_distance_TextRotate[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                // start resume_call.js

if (compass) compass.start();
                // end resume_call.js

                console.log('resume_call()');
                time_update(true, true);
                text_update();
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSec) {
                    let animDelay = timeSensor.utc % 1000;
                    let animRepeat = 1000;
                    normal_timerUpdateSec = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, true);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                let secAngle = 0 + (360*6)*(timeSensor.second + ((timeSensor.utc % 1000) / 1000))/360;
                normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, secAngle);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSecSmooth) {
                    let duration = 0;
                    let animDuration = 5000;
                    if (timeSensor.second > 55) animDuration = 1000*(60.1 - (timeSensor.second - (timeSensor.utc % 1000) / 1000));
                    let diffTime = timeSensor.utc - lastTime;
                    if (diffTime < animDuration) duration = animDuration - diffTime;
                    normal_timerUpdateSecSmooth = timer.createTimer(duration, animDuration, (function (option) {
                      lastTime = timeSensor.utc;
                      secAngle = 0 + (360*6)*(timeSensor.second + ((timeSensor.utc % 1000) / 1000))/360;
                      startSecAnim(secAngle, animDuration);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.AOD) {
                  if (!idle_timerUpdateSec) {
                    let animDelay = timeSensor.utc % 1000;
                    let animRepeat = 1000;
                    idle_timerUpdateSec = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, true);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.AOD) {
                  if (!idle_timerUpdateSecSmooth) {
                    let animDelay = 0;
                    let animRepeat = 1000/15;
                    idle_timerUpdateSecSmooth = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, false);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                console.log('pause_call()');
             // start pause_call.js

if (compass) compass.stop();
                // end pause_call.js
                if (normal_timerUpdateSec) {
                  timer.stopTimer(normal_timerUpdateSec);
                  normal_timerUpdateSec = undefined;
                }
                if (normal_timerUpdateSecSmooth) {
                  timer.stopTimer(normal_timerUpdateSecSmooth);
                  normal_timerUpdateSecSmooth = undefined;
                }
                if (idle_timerUpdateSec) {
                  timer.stopTimer(idle_timerUpdateSec);
                  idle_timerUpdateSec = undefined;
                }
                if (idle_timerUpdateSecSmooth) {
                  timer.stopTimer(idle_timerUpdateSecSmooth);
                  idle_timerUpdateSecSmooth = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
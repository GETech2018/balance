﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

       // Start step / distance
        let elementnumber_1 = 1
        let total_elemente = 2

        function click_elemente() {
            if(elementnumber_1==total_elemente) {
            elementnumber_1=1;
                UpdateElementeOne();
                }
            else {
                elementnumber_1=elementnumber_1+1;
                if(elementnumber_1==2) {
                  UpdateElementeTwo();
                }

            }
            if(elementnumber_1==1) hmUI.showToast({text: 'STEPS'});
            if(elementnumber_1==2) hmUI.showToast({text: 'DISTANCE'});
        }

        //STEPS
        function UpdateElementeOne(){

        normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, true);

        }

        //DISTANCE
        function UpdateElementeTwo(){


        normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        }

        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_battery_text_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_distance_text_separator_img = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_current_TextRotate = new Array(4);
        let normal_current_TextRotate_ASCIIARRAY = new Array(10);
        let normal_current_TextRotate_img_width = 23;
        let normal_current_TextRotate_unit = null;
        let normal_current_TextRotate_unit_width = 11;
        let normal_current_TextRotate_dot_width = 11;
        let normal_current_TextRotate_error_img_width = 11;
        let normal_low_TextRotate = new Array(4);
        let normal_low_TextRotate_ASCIIARRAY = new Array(10);
        let normal_low_TextRotate_img_width = 17;
        let normal_low_TextRotate_unit = null;
        let normal_low_TextRotate_unit_width = 9;
        let normal_low_TextRotate_dot_width = 9;
        let normal_low_TextRotate_error_img_width = 9;
        let normal_high_TextRotate = new Array(4);
        let normal_high_TextRotate_ASCIIARRAY = new Array(10);
        let normal_high_TextRotate_img_width = 17;
        let normal_high_TextRotate_unit = null;
        let normal_high_TextRotate_unit_width = 9;
        let normal_high_TextRotate_dot_width = 9;
        let normal_high_TextRotate_error_img_width = 9;
        let normal_weather_image_progress_img_level = ''
        let normal_second_TextRotate = new Array(2);
        let normal_second_TextRotate_ASCIIARRAY = new Array(10);
        let normal_second_TextRotate_img_width = 21;
        let normal_timerTextUpdate = undefined;
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time_minute = ''
        let normal_digital_clock_img_time_hour = ''
        let idle_background_bg_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_moon_image_progress_img_level = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_day = ''
        let idle_battery_text_text_img = ''
        let idle_calorie_current_text_img = ''
        let idle_heart_rate_text_text_img = ''
        let idle_step_current_text_img = ''
        let idle_step_current_separator_img = ''
        let idle_current_TextRotate = new Array(4);
        let idle_current_TextRotate_ASCIIARRAY = new Array(10);
        let idle_current_TextRotate_img_width = 23;
        let idle_current_TextRotate_unit = null;
        let idle_current_TextRotate_unit_width = 11;
        let idle_current_TextRotate_dot_width = 11;
        let idle_current_TextRotate_error_img_width = 11;
        let idle_low_TextRotate = new Array(4);
        let idle_low_TextRotate_ASCIIARRAY = new Array(10);
        let idle_low_TextRotate_img_width = 17;
        let idle_low_TextRotate_unit = null;
        let idle_low_TextRotate_unit_width = 9;
        let idle_low_TextRotate_dot_width = 9;
        let idle_low_TextRotate_error_img_width = 9;
        let idle_high_TextRotate = new Array(4);
        let idle_high_TextRotate_ASCIIARRAY = new Array(10);
        let idle_high_TextRotate_img_width = 17;
        let idle_high_TextRotate_unit = null;
        let idle_high_TextRotate_unit_width = 9;
        let idle_high_TextRotate_dot_width = 9;
        let idle_high_TextRotate_error_img_width = 9;
        let idle_weather_image_progress_img_level = ''
        let idle_second_TextRotate = new Array(2);
        let idle_second_TextRotate_ASCIIARRAY = new Array(10);
        let idle_second_TextRotate_img_width = 21;
        let idle_timerTextUpdate = undefined;
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time_minute = ''
        let idle_digital_clock_img_time_hour = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let timeSensor = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'main1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 31,
              y: 187,
              src: 'System_BT_OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 437,
              y: 146,
              src: 'System_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 23,
              y: 306,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 81,
              y: 393,
              week_en: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              week_tc: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              week_sc: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 62,
              day_startY: 328,
              day_sc_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              day_tc_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              day_en_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              day_zero: 1,
              day_space: -3,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 172,
              y: 443,
              font_array: ["Act_white_0.png","Act_white_1.png","Act_white_2.png","Act_white_3.png","Act_white_4.png","Act_white_5.png","Act_white_6.png","Act_white_7.png","Act_white_8.png","Act_white_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Batt_unit.png',
              unit_tc: 'Batt_unit.png',
              unit_en: 'Batt_unit.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 342,
              y: 267,
              font_array: ["Act_pink_0.png","Act_pink_1.png","Act_pink_2.png","Act_pink_3.png","Act_pink_4.png","Act_pink_5.png","Act_pink_6.png","Act_pink_7.png","Act_pink_8.png","Act_pink_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 46,
              y: 243,
              font_array: ["Act_Big_0.png","Act_Big_1.png","Act_Big_2.png","Act_Big_3.png","Act_Big_4.png","Act_Big_5.png","Act_Big_6.png","Act_Big_7.png","Act_Big_8.png","Act_Big_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 102,
              y: 189,
              font_array: ["Act_0.png","Act_1.png","Act_2.png","Act_3.png","Act_4.png","Act_5.png","Act_6.png","Act_7.png","Act_8.png","Act_9.png"],
              padding: false,
              h_space: -2,
              unit_sc: 'Dis_KM.png',
              unit_tc: 'Dis_KM.png',
              unit_en: 'Dis_KM.png',
              imperial_unit_sc: 'Dis_Mi.png',
              imperial_unit_tc: 'Dis_Mi.png',
              imperial_unit_en: 'Dis_Mi.png',
              dot_image: 'dis_dot.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 242,
              y: 183,
              src: 'icon_Dis.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 92,
              y: 189,
              font_array: ["Act_0.png","Act_1.png","Act_2.png","Act_3.png","Act_4.png","Act_5.png","Act_6.png","Act_7.png","Act_8.png","Act_9.png"],
              padding: false,
              h_space: -2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 170,
              y: 183,
              src: 'icon_Step.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_current_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 295,
              // y: 353,
              // font_array: ["Act_Small_0.png","Act_Small_1.png","Act_Small_2.png","Act_Small_3.png","Act_Small_4.png","Act_Small_5.png","Act_Small_6.png","Act_Small_7.png","Act_Small_8.png","Act_Small_9.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: -1,
              // angle: 271,
              // unit_en: 'Weather_Symbo1.png',
              // imperial_unit_en: 'Weather_Symbo3.png',
              // invalid_image: 'Weather_Symbo2.png',
              // dot_image: 'Weather_Symbo2.png',
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.WEATHER_CURRENT,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_current_TextRotate_ASCIIARRAY[0] = 'Act_Small_0.png';  // set of images with numbers
            normal_current_TextRotate_ASCIIARRAY[1] = 'Act_Small_1.png';  // set of images with numbers
            normal_current_TextRotate_ASCIIARRAY[2] = 'Act_Small_2.png';  // set of images with numbers
            normal_current_TextRotate_ASCIIARRAY[3] = 'Act_Small_3.png';  // set of images with numbers
            normal_current_TextRotate_ASCIIARRAY[4] = 'Act_Small_4.png';  // set of images with numbers
            normal_current_TextRotate_ASCIIARRAY[5] = 'Act_Small_5.png';  // set of images with numbers
            normal_current_TextRotate_ASCIIARRAY[6] = 'Act_Small_6.png';  // set of images with numbers
            normal_current_TextRotate_ASCIIARRAY[7] = 'Act_Small_7.png';  // set of images with numbers
            normal_current_TextRotate_ASCIIARRAY[8] = 'Act_Small_8.png';  // set of images with numbers
            normal_current_TextRotate_ASCIIARRAY[9] = 'Act_Small_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 4; i++) {
              normal_current_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 295,
                center_y: 353,
                pos_x: 295,
                pos_y: 353,
                angle: 271,
                src: 'Act_Small_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_current_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_current_TextRotate_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              center_x: 295,
              center_y: 353,
              pos_x: 295,
              pos_y: 353,
              angle: 271,
              src: 'Weather_Symbo1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_current_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block
            const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

            // normal_low_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 375,
              // y: 358,
              // font_array: ["Act_Ws_0.png","Act_Ws_1.png","Act_Ws_2.png","Act_Ws_3.png","Act_Ws_4.png","Act_Ws_5.png","Act_Ws_6.png","Act_Ws_7.png","Act_Ws_8.png","Act_Ws_9.png"],
              // zero: false,
              // unit_in_alignment: true,
              // h_space: -2,
              // angle: 0,
              // unit_en: 'Weather_Symbo4.png',
              // imperial_unit_en: 'Weather_Symbo4.png',
              // invalid_image: 'Weather_Symbo5.png',
              // dot_image: 'Weather_Symbo5.png',
              // align_h: hmUI.align.RIGHT,
              // type: hmUI.data_type.WEATHER_LOW,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_low_TextRotate_ASCIIARRAY[0] = 'Act_Ws_0.png';  // set of images with numbers
            normal_low_TextRotate_ASCIIARRAY[1] = 'Act_Ws_1.png';  // set of images with numbers
            normal_low_TextRotate_ASCIIARRAY[2] = 'Act_Ws_2.png';  // set of images with numbers
            normal_low_TextRotate_ASCIIARRAY[3] = 'Act_Ws_3.png';  // set of images with numbers
            normal_low_TextRotate_ASCIIARRAY[4] = 'Act_Ws_4.png';  // set of images with numbers
            normal_low_TextRotate_ASCIIARRAY[5] = 'Act_Ws_5.png';  // set of images with numbers
            normal_low_TextRotate_ASCIIARRAY[6] = 'Act_Ws_6.png';  // set of images with numbers
            normal_low_TextRotate_ASCIIARRAY[7] = 'Act_Ws_7.png';  // set of images with numbers
            normal_low_TextRotate_ASCIIARRAY[8] = 'Act_Ws_8.png';  // set of images with numbers
            normal_low_TextRotate_ASCIIARRAY[9] = 'Act_Ws_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 4; i++) {
              normal_low_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 375,
                center_y: 358,
                pos_x: 375,
                pos_y: 358,
                angle: 0,
                src: 'Act_Ws_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_low_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_low_TextRotate_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              center_x: 375,
              center_y: 358,
              pos_x: 375,
              pos_y: 358,
              angle: 0,
              src: 'Weather_Symbo4.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_low_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);

            const temperatureUnit = hmSetting.getTemperatureUnit();
            if (temperatureUnit == 1) {
              normal_low_TextRotate_unit.setProperty(hmUI.prop.SRC, 'Weather_Symbo4.png');
            };
            //end of ignored block

            // normal_high_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 375,
              // y: 322,
              // font_array: ["Act_Ws_0.png","Act_Ws_1.png","Act_Ws_2.png","Act_Ws_3.png","Act_Ws_4.png","Act_Ws_5.png","Act_Ws_6.png","Act_Ws_7.png","Act_Ws_8.png","Act_Ws_9.png"],
              // zero: false,
              // unit_in_alignment: true,
              // h_space: -2,
              // angle: 0,
              // unit_en: 'Weather_Symbo4.png',
              // imperial_unit_en: 'Weather_Symbo4.png',
              // invalid_image: 'Weather_Symbo5.png',
              // dot_image: 'Weather_Symbo5.png',
              // align_h: hmUI.align.RIGHT,
              // type: hmUI.data_type.WEATHER_HIGH,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_high_TextRotate_ASCIIARRAY[0] = 'Act_Ws_0.png';  // set of images with numbers
            normal_high_TextRotate_ASCIIARRAY[1] = 'Act_Ws_1.png';  // set of images with numbers
            normal_high_TextRotate_ASCIIARRAY[2] = 'Act_Ws_2.png';  // set of images with numbers
            normal_high_TextRotate_ASCIIARRAY[3] = 'Act_Ws_3.png';  // set of images with numbers
            normal_high_TextRotate_ASCIIARRAY[4] = 'Act_Ws_4.png';  // set of images with numbers
            normal_high_TextRotate_ASCIIARRAY[5] = 'Act_Ws_5.png';  // set of images with numbers
            normal_high_TextRotate_ASCIIARRAY[6] = 'Act_Ws_6.png';  // set of images with numbers
            normal_high_TextRotate_ASCIIARRAY[7] = 'Act_Ws_7.png';  // set of images with numbers
            normal_high_TextRotate_ASCIIARRAY[8] = 'Act_Ws_8.png';  // set of images with numbers
            normal_high_TextRotate_ASCIIARRAY[9] = 'Act_Ws_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 4; i++) {
              normal_high_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 375,
                center_y: 322,
                pos_x: 375,
                pos_y: 322,
                angle: 0,
                src: 'Act_Ws_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_high_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_high_TextRotate_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              center_x: 375,
              center_y: 322,
              pos_x: 375,
              pos_y: 322,
              angle: 0,
              src: 'Weather_Symbo4.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_high_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);

            if (temperatureUnit == 1) {
              normal_high_TextRotate_unit.setProperty(hmUI.prop.SRC, 'Weather_Symbo4.png');
            };
            //end of ignored block

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 191,
              y: 326,
              image_array: ["Weather_icon_01.png","Weather_icon_02.png","Weather_icon_03.png","Weather_icon_04.png","Weather_icon_05.png","Weather_icon_06.png","Weather_icon_07.png","Weather_icon_08.png","Weather_icon_09.png","Weather_icon_10.png","Weather_icon_11.png","Weather_icon_12.png","Weather_icon_13.png","Weather_icon_14.png","Weather_icon_15.png","Weather_icon_16.png","Weather_icon_17.png","Weather_icon_18.png","Weather_icon_19.png","Weather_icon_20.png","Weather_icon_21.png","Weather_icon_22.png","Weather_icon_23.png","Weather_icon_24.png","Weather_icon_25.png","Weather_icon_26.png","Weather_icon_27.png","Weather_icon_28.png","Weather_icon_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_second_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 354,
              // y: 40,
              // font_array: ["TimeS_0.png","TimeS_1.png","TimeS_2.png","TimeS_3.png","TimeS_4.png","TimeS_5.png","TimeS_6.png","TimeS_7.png","TimeS_8.png","TimeS_9.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: 45,
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.SECOND,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_second_TextRotate_ASCIIARRAY[0] = 'TimeS_0.png';  // set of images with numbers
            normal_second_TextRotate_ASCIIARRAY[1] = 'TimeS_1.png';  // set of images with numbers
            normal_second_TextRotate_ASCIIARRAY[2] = 'TimeS_2.png';  // set of images with numbers
            normal_second_TextRotate_ASCIIARRAY[3] = 'TimeS_3.png';  // set of images with numbers
            normal_second_TextRotate_ASCIIARRAY[4] = 'TimeS_4.png';  // set of images with numbers
            normal_second_TextRotate_ASCIIARRAY[5] = 'TimeS_5.png';  // set of images with numbers
            normal_second_TextRotate_ASCIIARRAY[6] = 'TimeS_6.png';  // set of images with numbers
            normal_second_TextRotate_ASCIIARRAY[7] = 'TimeS_7.png';  // set of images with numbers
            normal_second_TextRotate_ASCIIARRAY[8] = 'TimeS_8.png';  // set of images with numbers
            normal_second_TextRotate_ASCIIARRAY[9] = 'TimeS_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              normal_second_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 354,
                center_y: 40,
                pos_x: 354,
                pos_y: 40,
                angle: 45,
                src: 'TimeS_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_second_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            let screenType = hmSetting.getScreenType();
            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 74,
              am_y: 41,
              am_sc_path: 'Clock_AM.png',
              am_en_path: 'Clock_AM.png',
              pm_x: 74,
              pm_y: 41,
              pm_sc_path: 'Clock_PM.png',
              pm_en_path: 'Clock_PM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 314,
              minute_startY: 78,
              minute_array: ["TimeM_0.png","TimeM_1.png","TimeM_2.png","TimeM_3.png","TimeM_4.png","TimeM_5.png","TimeM_6.png","TimeM_7.png","TimeM_8.png","TimeM_9.png"],
              minute_zero: 1,
              minute_space: -7,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 129,
              hour_startY: 4,
              hour_array: ["Time_0.png","Time_1.png","Time_2.png","Time_3.png","Time_4.png","Time_5.png","Time_6.png","Time_7.png","Time_8.png","Time_9.png"],
              hour_zero: 1,
              hour_space: -18,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'main1.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 31,
              y: 187,
              src: 'System_BT_OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 437,
              y: 146,
              src: 'System_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 23,
              y: 306,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 81,
              y: 393,
              week_en: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              week_tc: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              week_sc: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 62,
              day_startY: 328,
              day_sc_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              day_tc_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              day_en_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              day_zero: 1,
              day_space: -3,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 172,
              y: 443,
              font_array: ["Act_white_0.png","Act_white_1.png","Act_white_2.png","Act_white_3.png","Act_white_4.png","Act_white_5.png","Act_white_6.png","Act_white_7.png","Act_white_8.png","Act_white_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Batt_unit.png',
              unit_tc: 'Batt_unit.png',
              unit_en: 'Batt_unit.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 342,
              y: 267,
              font_array: ["Act_pink_0.png","Act_pink_1.png","Act_pink_2.png","Act_pink_3.png","Act_pink_4.png","Act_pink_5.png","Act_pink_6.png","Act_pink_7.png","Act_pink_8.png","Act_pink_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 46,
              y: 243,
              font_array: ["Act_Big_0.png","Act_Big_1.png","Act_Big_2.png","Act_Big_3.png","Act_Big_4.png","Act_Big_5.png","Act_Big_6.png","Act_Big_7.png","Act_Big_8.png","Act_Big_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 92,
              y: 189,
              font_array: ["Act_0.png","Act_1.png","Act_2.png","Act_3.png","Act_4.png","Act_5.png","Act_6.png","Act_7.png","Act_8.png","Act_9.png"],
              padding: false,
              h_space: -2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 170,
              y: 183,
              src: 'icon_Step.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_current_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 295,
              // y: 353,
              // font_array: ["Act_Small_0.png","Act_Small_1.png","Act_Small_2.png","Act_Small_3.png","Act_Small_4.png","Act_Small_5.png","Act_Small_6.png","Act_Small_7.png","Act_Small_8.png","Act_Small_9.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: -1,
              // angle: 271,
              // unit_en: 'Weather_Symbo1.png',
              // imperial_unit_en: 'Weather_Symbo3.png',
              // invalid_image: 'Weather_Symbo2.png',
              // dot_image: 'Weather_Symbo2.png',
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.WEATHER_CURRENT,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_current_TextRotate_ASCIIARRAY[0] = 'Act_Small_0.png';  // set of images with numbers
            idle_current_TextRotate_ASCIIARRAY[1] = 'Act_Small_1.png';  // set of images with numbers
            idle_current_TextRotate_ASCIIARRAY[2] = 'Act_Small_2.png';  // set of images with numbers
            idle_current_TextRotate_ASCIIARRAY[3] = 'Act_Small_3.png';  // set of images with numbers
            idle_current_TextRotate_ASCIIARRAY[4] = 'Act_Small_4.png';  // set of images with numbers
            idle_current_TextRotate_ASCIIARRAY[5] = 'Act_Small_5.png';  // set of images with numbers
            idle_current_TextRotate_ASCIIARRAY[6] = 'Act_Small_6.png';  // set of images with numbers
            idle_current_TextRotate_ASCIIARRAY[7] = 'Act_Small_7.png';  // set of images with numbers
            idle_current_TextRotate_ASCIIARRAY[8] = 'Act_Small_8.png';  // set of images with numbers
            idle_current_TextRotate_ASCIIARRAY[9] = 'Act_Small_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 4; i++) {
              idle_current_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 295,
                center_y: 353,
                pos_x: 295,
                pos_y: 353,
                angle: 271,
                src: 'Act_Small_0.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_current_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            idle_current_TextRotate_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              center_x: 295,
              center_y: 353,
              pos_x: 295,
              pos_y: 353,
              angle: 271,
              src: 'Weather_Symbo1.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            idle_current_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block

            // idle_low_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 375,
              // y: 358,
              // font_array: ["Act_Ws_0.png","Act_Ws_1.png","Act_Ws_2.png","Act_Ws_3.png","Act_Ws_4.png","Act_Ws_5.png","Act_Ws_6.png","Act_Ws_7.png","Act_Ws_8.png","Act_Ws_9.png"],
              // zero: false,
              // unit_in_alignment: true,
              // h_space: -2,
              // angle: 0,
              // unit_en: 'Weather_Symbo4.png',
              // imperial_unit_en: 'Weather_Symbo4.png',
              // invalid_image: 'Weather_Symbo5.png',
              // dot_image: 'Weather_Symbo5.png',
              // align_h: hmUI.align.RIGHT,
              // type: hmUI.data_type.WEATHER_LOW,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_low_TextRotate_ASCIIARRAY[0] = 'Act_Ws_0.png';  // set of images with numbers
            idle_low_TextRotate_ASCIIARRAY[1] = 'Act_Ws_1.png';  // set of images with numbers
            idle_low_TextRotate_ASCIIARRAY[2] = 'Act_Ws_2.png';  // set of images with numbers
            idle_low_TextRotate_ASCIIARRAY[3] = 'Act_Ws_3.png';  // set of images with numbers
            idle_low_TextRotate_ASCIIARRAY[4] = 'Act_Ws_4.png';  // set of images with numbers
            idle_low_TextRotate_ASCIIARRAY[5] = 'Act_Ws_5.png';  // set of images with numbers
            idle_low_TextRotate_ASCIIARRAY[6] = 'Act_Ws_6.png';  // set of images with numbers
            idle_low_TextRotate_ASCIIARRAY[7] = 'Act_Ws_7.png';  // set of images with numbers
            idle_low_TextRotate_ASCIIARRAY[8] = 'Act_Ws_8.png';  // set of images with numbers
            idle_low_TextRotate_ASCIIARRAY[9] = 'Act_Ws_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 4; i++) {
              idle_low_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 375,
                center_y: 358,
                pos_x: 375,
                pos_y: 358,
                angle: 0,
                src: 'Act_Ws_0.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_low_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            idle_low_TextRotate_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              center_x: 375,
              center_y: 358,
              pos_x: 375,
              pos_y: 358,
              angle: 0,
              src: 'Weather_Symbo4.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            idle_low_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);

            if (temperatureUnit == 1) {
              idle_low_TextRotate_unit.setProperty(hmUI.prop.SRC, 'Weather_Symbo4.png');
            };
            //end of ignored block

            // idle_high_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 375,
              // y: 322,
              // font_array: ["Act_Ws_0.png","Act_Ws_1.png","Act_Ws_2.png","Act_Ws_3.png","Act_Ws_4.png","Act_Ws_5.png","Act_Ws_6.png","Act_Ws_7.png","Act_Ws_8.png","Act_Ws_9.png"],
              // zero: false,
              // unit_in_alignment: true,
              // h_space: -2,
              // angle: 0,
              // unit_en: 'Weather_Symbo4.png',
              // imperial_unit_en: 'Weather_Symbo4.png',
              // invalid_image: 'Weather_Symbo5.png',
              // dot_image: 'Weather_Symbo5.png',
              // align_h: hmUI.align.RIGHT,
              // type: hmUI.data_type.WEATHER_HIGH,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_high_TextRotate_ASCIIARRAY[0] = 'Act_Ws_0.png';  // set of images with numbers
            idle_high_TextRotate_ASCIIARRAY[1] = 'Act_Ws_1.png';  // set of images with numbers
            idle_high_TextRotate_ASCIIARRAY[2] = 'Act_Ws_2.png';  // set of images with numbers
            idle_high_TextRotate_ASCIIARRAY[3] = 'Act_Ws_3.png';  // set of images with numbers
            idle_high_TextRotate_ASCIIARRAY[4] = 'Act_Ws_4.png';  // set of images with numbers
            idle_high_TextRotate_ASCIIARRAY[5] = 'Act_Ws_5.png';  // set of images with numbers
            idle_high_TextRotate_ASCIIARRAY[6] = 'Act_Ws_6.png';  // set of images with numbers
            idle_high_TextRotate_ASCIIARRAY[7] = 'Act_Ws_7.png';  // set of images with numbers
            idle_high_TextRotate_ASCIIARRAY[8] = 'Act_Ws_8.png';  // set of images with numbers
            idle_high_TextRotate_ASCIIARRAY[9] = 'Act_Ws_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 4; i++) {
              idle_high_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 375,
                center_y: 322,
                pos_x: 375,
                pos_y: 322,
                angle: 0,
                src: 'Act_Ws_0.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_high_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            idle_high_TextRotate_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              center_x: 375,
              center_y: 322,
              pos_x: 375,
              pos_y: 322,
              angle: 0,
              src: 'Weather_Symbo4.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            idle_high_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);

            if (temperatureUnit == 1) {
              idle_high_TextRotate_unit.setProperty(hmUI.prop.SRC, 'Weather_Symbo4.png');
            };
            //end of ignored block

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 191,
              y: 326,
              image_array: ["Weather_icon_01.png","Weather_icon_02.png","Weather_icon_03.png","Weather_icon_04.png","Weather_icon_05.png","Weather_icon_06.png","Weather_icon_07.png","Weather_icon_08.png","Weather_icon_09.png","Weather_icon_10.png","Weather_icon_11.png","Weather_icon_12.png","Weather_icon_13.png","Weather_icon_14.png","Weather_icon_15.png","Weather_icon_16.png","Weather_icon_17.png","Weather_icon_18.png","Weather_icon_19.png","Weather_icon_20.png","Weather_icon_21.png","Weather_icon_22.png","Weather_icon_23.png","Weather_icon_24.png","Weather_icon_25.png","Weather_icon_26.png","Weather_icon_27.png","Weather_icon_28.png","Weather_icon_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_second_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 354,
              // y: 40,
              // font_array: ["TimeS_0.png","TimeS_1.png","TimeS_2.png","TimeS_3.png","TimeS_4.png","TimeS_5.png","TimeS_6.png","TimeS_7.png","TimeS_8.png","TimeS_9.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: 45,
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.SECOND,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_second_TextRotate_ASCIIARRAY[0] = 'TimeS_0.png';  // set of images with numbers
            idle_second_TextRotate_ASCIIARRAY[1] = 'TimeS_1.png';  // set of images with numbers
            idle_second_TextRotate_ASCIIARRAY[2] = 'TimeS_2.png';  // set of images with numbers
            idle_second_TextRotate_ASCIIARRAY[3] = 'TimeS_3.png';  // set of images with numbers
            idle_second_TextRotate_ASCIIARRAY[4] = 'TimeS_4.png';  // set of images with numbers
            idle_second_TextRotate_ASCIIARRAY[5] = 'TimeS_5.png';  // set of images with numbers
            idle_second_TextRotate_ASCIIARRAY[6] = 'TimeS_6.png';  // set of images with numbers
            idle_second_TextRotate_ASCIIARRAY[7] = 'TimeS_7.png';  // set of images with numbers
            idle_second_TextRotate_ASCIIARRAY[8] = 'TimeS_8.png';  // set of images with numbers
            idle_second_TextRotate_ASCIIARRAY[9] = 'TimeS_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              idle_second_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 354,
                center_y: 40,
                pos_x: 354,
                pos_y: 40,
                angle: 45,
                src: 'TimeS_0.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_second_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 74,
              am_y: 41,
              am_sc_path: 'Clock_AM.png',
              am_en_path: 'Clock_AM.png',
              pm_x: 74,
              pm_y: 41,
              pm_sc_path: 'Clock_PM.png',
              pm_en_path: 'Clock_PM.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 314,
              minute_startY: 78,
              minute_array: ["TimeM_0.png","TimeM_1.png","TimeM_2.png","TimeM_3.png","TimeM_4.png","TimeM_5.png","TimeM_6.png","TimeM_7.png","TimeM_8.png","TimeM_9.png"],
              minute_zero: 1,
              minute_space: -7,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 129,
              hour_startY: 4,
              hour_array: ["Time_0.png","Time_1.png","Time_2.png","Time_3.png","Time_4.png","Time_5.png","Time_6.png","Time_7.png","Time_8.png","Time_9.png"],
              hour_zero: 1,
              hour_space: -18,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 336,
              y: 102,
              w: 72,
              h: 61,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 308,
              y: 17,
              w: 83,
              h: 57,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 431,
              y: 98,
              w: 41,
              h: 77,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 9,
              y: 304,
              w: 55,
              h: 44,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 295,
              y: 315,
              w: 136,
              h: 62,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 413,
              y: 186,
              w: 52,
              h: 102,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 181,
              y: 244,
              w: 74,
              h: 59,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 41,
              y: 241,
              w: 123,
              h: 48,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 97,
              y: 186,
              w: 137,
              h: 40,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 271,
              y: 186,
              w: 111,
              h: 41,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                // Steps and distance
click_elemente()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 81,
              y: 334,
              w: 64,
              h: 97,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 187,
              y: 441,
              w: 102,
              h: 37,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PowerSaveHintScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            console.log('user_script_end.js');
            // start user_script_end.js


 let cc = 0
 if (cc == 0){ 
UpdateElementeOne()
cc =1
}
            // end user_script_end.js

            //start of ignored block
            function text_update() {
              console.log('text_update()');
              let weatherData = weatherSensor.getForecastWeather();
              let current_temp = -100;
              if (weatherSensor.current != undefined && weatherSensor.current != 'undefined') {
                current_temp = weatherSensor.current;
              }; // end currentWeather;

              console.log('update text rotate current_currentWeather');
              let temperatureCurrent = undefined;
              let normal_current_rotate_string = undefined;
              if (current_temp > -100) {
                temperatureCurrent = 0;
                normal_current_rotate_string = String(current_temp)
              };

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 4; i++) {  // hide all symbols
                  normal_current_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_current_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
                if (temperatureCurrent != null && temperatureCurrent != undefined && isFinite(temperatureCurrent) && normal_current_rotate_string.length > 0 && normal_current_rotate_string.length <= 4) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let normal_current_TextRotate_posOffset = normal_current_TextRotate_img_width * normal_current_rotate_string.length;
                  normal_current_TextRotate_posOffset = normal_current_TextRotate_posOffset + -1 * (normal_current_rotate_string.length - 1);
                  img_offset -= normal_current_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_current_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 4) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_current_TextRotate[index].setProperty(hmUI.prop.POS_X, 295 + img_offset);
                      normal_current_TextRotate[index].setProperty(hmUI.prop.SRC, normal_current_TextRotate_ASCIIARRAY[charCode]);
                      normal_current_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_current_TextRotate_img_width + -1;
                      index++;
                    }  // end if digit
                    else { 
                      normal_current_TextRotate[index].setProperty(hmUI.prop.POS_X, 295 + img_offset);
                      normal_current_TextRotate[index].setProperty(hmUI.prop.SRC, 'Weather_Symbo2.png');
                      normal_current_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_current_TextRotate_dot_width + -1;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                  normal_current_TextRotate_unit.setProperty(hmUI.prop.POS_X, 295 + img_offset);
                  normal_current_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite
                else {
                  normal_current_TextRotate[0].setProperty(hmUI.prop.POS_X, 295 - normal_current_TextRotate_error_img_width / 2);
                  normal_current_TextRotate[0].setProperty(hmUI.prop.SRC, 'Weather_Symbo2.png');
                  normal_current_TextRotate[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };
              let forecastData = weatherData.forecastData;
              let low_temp = -100;
              if (forecastData.count > 0) {
                low_temp = forecastData.data[0].low;
              }; // end forecastData;

              console.log('update text rotate low_forecastData');
              let temperatureLow = undefined;
              let normal_low_rotate_string = undefined;
              if (low_temp > -100) {
                temperatureLow = 0;
                normal_low_rotate_string = String(low_temp)
              };

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 4; i++) {  // hide all symbols
                  normal_low_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_low_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
                if (temperatureLow != null && temperatureLow != undefined && isFinite(temperatureLow) && normal_low_rotate_string.length > 0 && normal_low_rotate_string.length <= 4) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = RIGHT
                  let normal_low_TextRotate_posOffset = normal_low_TextRotate_img_width * normal_low_rotate_string.length;
                  normal_low_TextRotate_posOffset = normal_low_TextRotate_posOffset + -2 * (normal_low_rotate_string.length - 1);
                  normal_low_TextRotate_posOffset = normal_low_TextRotate_posOffset + normal_low_TextRotate_unit_width + -2;
                  img_offset -= normal_low_TextRotate_posOffset;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_low_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 4) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_low_TextRotate[index].setProperty(hmUI.prop.POS_X, 375 + img_offset);
                      normal_low_TextRotate[index].setProperty(hmUI.prop.SRC, normal_low_TextRotate_ASCIIARRAY[charCode]);
                      normal_low_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_low_TextRotate_img_width + -2;
                      index++;
                    }  // end if digit
                    else { 
                      normal_low_TextRotate[index].setProperty(hmUI.prop.POS_X, 375 + img_offset);
                      normal_low_TextRotate[index].setProperty(hmUI.prop.SRC, 'Weather_Symbo5.png');
                      normal_low_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_low_TextRotate_dot_width + -2;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                  normal_low_TextRotate_unit.setProperty(hmUI.prop.POS_X, 375 + img_offset);
                  normal_low_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite
                else {
                  normal_low_TextRotate[0].setProperty(hmUI.prop.POS_X, 375 - normal_low_TextRotate_error_img_width / 2);
                  normal_low_TextRotate[0].setProperty(hmUI.prop.SRC, 'Weather_Symbo5.png');
                  normal_low_TextRotate[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };
              let high_temp = -100;
              if (forecastData.count > 0) {
                high_temp = forecastData.data[0].high;
              }; // end forecastData;

              console.log('update text rotate high_forecastData');
              let temperatureHigh = undefined;
              let normal_high_rotate_string = undefined;
              if (high_temp > -100) {
                temperatureHigh = 0;
                normal_high_rotate_string = String(high_temp)
              };

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 4; i++) {  // hide all symbols
                  normal_high_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_high_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
                if (temperatureHigh != null && temperatureHigh != undefined && isFinite(temperatureHigh) && normal_high_rotate_string.length > 0 && normal_high_rotate_string.length <= 4) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = RIGHT
                  let normal_high_TextRotate_posOffset = normal_high_TextRotate_img_width * normal_high_rotate_string.length;
                  normal_high_TextRotate_posOffset = normal_high_TextRotate_posOffset + -2 * (normal_high_rotate_string.length - 1);
                  normal_high_TextRotate_posOffset = normal_high_TextRotate_posOffset + normal_high_TextRotate_unit_width + -2;
                  img_offset -= normal_high_TextRotate_posOffset;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_high_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 4) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_high_TextRotate[index].setProperty(hmUI.prop.POS_X, 375 + img_offset);
                      normal_high_TextRotate[index].setProperty(hmUI.prop.SRC, normal_high_TextRotate_ASCIIARRAY[charCode]);
                      normal_high_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_high_TextRotate_img_width + -2;
                      index++;
                    }  // end if digit
                    else { 
                      normal_high_TextRotate[index].setProperty(hmUI.prop.POS_X, 375 + img_offset);
                      normal_high_TextRotate[index].setProperty(hmUI.prop.SRC, 'Weather_Symbo5.png');
                      normal_high_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_high_TextRotate_dot_width + -2;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                  normal_high_TextRotate_unit.setProperty(hmUI.prop.POS_X, 375 + img_offset);
                  normal_high_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite
                else {
                  normal_high_TextRotate[0].setProperty(hmUI.prop.POS_X, 375 - normal_high_TextRotate_error_img_width / 2);
                  normal_high_TextRotate[0].setProperty(hmUI.prop.SRC, 'Weather_Symbo5.png');
                  normal_high_TextRotate[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

              console.log('update text rotate second_TIME');
              let valueSecond = timeSensor.second;
              let normal_second_rotate_string = parseInt(valueSecond).toString();
              normal_second_rotate_string = normal_second_rotate_string.padStart(2, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_second_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueSecond != null && valueSecond != undefined && isFinite(valueSecond) && normal_second_rotate_string.length > 0 && normal_second_rotate_string.length <= 2) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let normal_second_TextRotate_posOffset = normal_second_TextRotate_img_width * normal_second_rotate_string.length;
                  img_offset -= normal_second_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_second_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_second_TextRotate[index].setProperty(hmUI.prop.POS_X, 354 + img_offset);
                      normal_second_TextRotate[index].setProperty(hmUI.prop.SRC, normal_second_TextRotate_ASCIIARRAY[charCode]);
                      normal_second_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_second_TextRotate_img_width;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate current_currentWeather');
              let idle_current_rotate_string = undefined;
              if (current_temp > -100) {
                temperatureCurrent = 0;
                idle_current_rotate_string = String(current_temp)
              };

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 4; i++) {  // hide all symbols
                  idle_current_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                idle_current_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
                if (temperatureCurrent != null && temperatureCurrent != undefined && isFinite(temperatureCurrent) && idle_current_rotate_string.length > 0 && idle_current_rotate_string.length <= 4) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let idle_current_TextRotate_posOffset = idle_current_TextRotate_img_width * idle_current_rotate_string.length;
                  idle_current_TextRotate_posOffset = idle_current_TextRotate_posOffset + -1 * (idle_current_rotate_string.length - 1);
                  img_offset -= idle_current_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of idle_current_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 4) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_current_TextRotate[index].setProperty(hmUI.prop.POS_X, 295 + img_offset);
                      idle_current_TextRotate[index].setProperty(hmUI.prop.SRC, idle_current_TextRotate_ASCIIARRAY[charCode]);
                      idle_current_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_current_TextRotate_img_width + -1;
                      index++;
                    }  // end if digit
                    else { 
                      idle_current_TextRotate[index].setProperty(hmUI.prop.POS_X, 295 + img_offset);
                      idle_current_TextRotate[index].setProperty(hmUI.prop.SRC, 'Weather_Symbo2.png');
                      idle_current_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_current_TextRotate_dot_width + -1;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                  idle_current_TextRotate_unit.setProperty(hmUI.prop.POS_X, 295 + img_offset);
                  idle_current_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite
                else {
                  idle_current_TextRotate[0].setProperty(hmUI.prop.POS_X, 295 - idle_current_TextRotate_error_img_width / 2);
                  idle_current_TextRotate[0].setProperty(hmUI.prop.SRC, 'Weather_Symbo2.png');
                  idle_current_TextRotate[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

              console.log('update text rotate low_forecastData');
              let idle_low_rotate_string = undefined;
              if (low_temp > -100) {
                temperatureLow = 0;
                idle_low_rotate_string = String(low_temp)
              };

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 4; i++) {  // hide all symbols
                  idle_low_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                idle_low_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
                if (temperatureLow != null && temperatureLow != undefined && isFinite(temperatureLow) && idle_low_rotate_string.length > 0 && idle_low_rotate_string.length <= 4) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = RIGHT
                  let idle_low_TextRotate_posOffset = idle_low_TextRotate_img_width * idle_low_rotate_string.length;
                  idle_low_TextRotate_posOffset = idle_low_TextRotate_posOffset + -2 * (idle_low_rotate_string.length - 1);
                  idle_low_TextRotate_posOffset = idle_low_TextRotate_posOffset + idle_low_TextRotate_unit_width + -2;
                  img_offset -= idle_low_TextRotate_posOffset;
                  // alignment end
                  
                  let index = 0;
                  for (let char of idle_low_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 4) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_low_TextRotate[index].setProperty(hmUI.prop.POS_X, 375 + img_offset);
                      idle_low_TextRotate[index].setProperty(hmUI.prop.SRC, idle_low_TextRotate_ASCIIARRAY[charCode]);
                      idle_low_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_low_TextRotate_img_width + -2;
                      index++;
                    }  // end if digit
                    else { 
                      idle_low_TextRotate[index].setProperty(hmUI.prop.POS_X, 375 + img_offset);
                      idle_low_TextRotate[index].setProperty(hmUI.prop.SRC, 'Weather_Symbo5.png');
                      idle_low_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_low_TextRotate_dot_width + -2;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                  idle_low_TextRotate_unit.setProperty(hmUI.prop.POS_X, 375 + img_offset);
                  idle_low_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite
                else {
                  idle_low_TextRotate[0].setProperty(hmUI.prop.POS_X, 375 - idle_low_TextRotate_error_img_width / 2);
                  idle_low_TextRotate[0].setProperty(hmUI.prop.SRC, 'Weather_Symbo5.png');
                  idle_low_TextRotate[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

              console.log('update text rotate high_forecastData');
              let idle_high_rotate_string = undefined;
              if (high_temp > -100) {
                temperatureHigh = 0;
                idle_high_rotate_string = String(high_temp)
              };

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 4; i++) {  // hide all symbols
                  idle_high_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                idle_high_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
                if (temperatureHigh != null && temperatureHigh != undefined && isFinite(temperatureHigh) && idle_high_rotate_string.length > 0 && idle_high_rotate_string.length <= 4) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = RIGHT
                  let idle_high_TextRotate_posOffset = idle_high_TextRotate_img_width * idle_high_rotate_string.length;
                  idle_high_TextRotate_posOffset = idle_high_TextRotate_posOffset + -2 * (idle_high_rotate_string.length - 1);
                  idle_high_TextRotate_posOffset = idle_high_TextRotate_posOffset + idle_high_TextRotate_unit_width + -2;
                  img_offset -= idle_high_TextRotate_posOffset;
                  // alignment end
                  
                  let index = 0;
                  for (let char of idle_high_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 4) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_high_TextRotate[index].setProperty(hmUI.prop.POS_X, 375 + img_offset);
                      idle_high_TextRotate[index].setProperty(hmUI.prop.SRC, idle_high_TextRotate_ASCIIARRAY[charCode]);
                      idle_high_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_high_TextRotate_img_width + -2;
                      index++;
                    }  // end if digit
                    else { 
                      idle_high_TextRotate[index].setProperty(hmUI.prop.POS_X, 375 + img_offset);
                      idle_high_TextRotate[index].setProperty(hmUI.prop.SRC, 'Weather_Symbo5.png');
                      idle_high_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_high_TextRotate_dot_width + -2;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                  idle_high_TextRotate_unit.setProperty(hmUI.prop.POS_X, 375 + img_offset);
                  idle_high_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite
                else {
                  idle_high_TextRotate[0].setProperty(hmUI.prop.POS_X, 375 - idle_high_TextRotate_error_img_width / 2);
                  idle_high_TextRotate[0].setProperty(hmUI.prop.SRC, 'Weather_Symbo5.png');
                  idle_high_TextRotate[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

              console.log('update text rotate second_TIME');
              let idle_second_rotate_string = parseInt(valueSecond).toString();
              idle_second_rotate_string = idle_second_rotate_string.padStart(2, '0');

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  idle_second_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueSecond != null && valueSecond != undefined && isFinite(valueSecond) && idle_second_rotate_string.length > 0 && idle_second_rotate_string.length <= 2) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let idle_second_TextRotate_posOffset = idle_second_TextRotate_img_width * idle_second_rotate_string.length;
                  img_offset -= idle_second_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of idle_second_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_second_TextRotate[index].setProperty(hmUI.prop.POS_X, 354 + img_offset);
                      idle_second_TextRotate[index].setProperty(hmUI.prop.SRC, idle_second_TextRotate_ASCIIARRAY[charCode]);
                      idle_second_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_second_TextRotate_img_width;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

            };

            //end of ignored block
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                text_update();
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerTextUpdate) {
                    normal_timerTextUpdate = timer.createTimer(0, 1000, (function (option) {
                      text_update();
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.AOD) {
                  if (!idle_timerTextUpdate) {
                    idle_timerTextUpdate = timer.createTimer(0, 1000, (function (option) {
                      text_update();
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerTextUpdate) {
                  timer.stopTimer(normal_timerTextUpdate);
                  normal_timerTextUpdate = undefined;
                }
                if (idle_timerTextUpdate) {
                  timer.stopTimer(idle_timerTextUpdate);
                  idle_timerTextUpdate = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
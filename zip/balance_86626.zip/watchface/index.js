﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start
		function read_pressure() {
      console.log("read_pressure()");
      const file_name_alt = "../../../baro_altim/pressure.dat";
      const [fs_stat, err] = hmFS.stat(file_name_alt);
      if (err == 0) {
        let file_size = fs_stat.size;
        const len = file_size / 4;
        console.log(`size_alt: ${file_size}, lenght: ${len}`)
        const fh = hmFS.open(file_name_alt, hmFS.O_RDONLY)
      
        let array_buffer = new Float32Array(len);
        hmFS.read(fh, array_buffer.buffer, 0, file_size);
        hmFS.close(fh);
        console.log(`value ${array_buffer[array_buffer.length -1]}`);
        return array_buffer;
      } else {
        console.log('err:', err)
      }
      return null;
      }
      
      function getPressureValue(pressure_array) {
      console.log("getPressureValue()");
      if(pressure_array == null || pressure_array == undefined || pressure_array.length == 0) return 0;
      let start_index = pressure_array.length - 1;
      let end_index = start_index - 30*3; // 3 часа
      if(end_index < 0) end_index = 0;
      for (let index = start_index; index >= end_index; index--) {
        if(pressure_array[index] != 0) return parseInt(pressure_array[index] / 100);
      }
      return 0;
      }
      
      function hPa_To_mmHg(hPa_value = 0) {
      let mmHg = Math.round(hPa_value * 0.750064);
      return mmHg;
      }
      
      function getPressureMMHG() {
      const pressure_array = read_pressure();
      const val = hPa_To_mmHg(getPressureValue(pressure_array));		// получаем давление и переводим в мм рт. ст.
          
      return val
      }
      
      function updatePressure() {
      normal_altimeter_text_text_img.setProperty({
              x: 348,
              y: 138,
              font_array: ["0061.png","0062.png","0063.png","0064.png","0065.png","0066.png","0067.png","0068.png","0069.png","0070.png"],
              padding: false,
              h_space: 0,
              invalid_image: 'icon_3.png',
              text: getPressureMMHG(),
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
      }
	  
	  

        
        let normal_background_bg_img = ''
		let normal_altimeter_text_text_img = ''
        let normal_vo2max_icon_img = ''
        let normal_floor_icon_img = ''
        let normal_hrv_icon_img = ''
        let normal_bio_charge_icon_img = ''
        let normal_moon_icon_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_sun_high_text_img = ''
        let normal_sun_low_text_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_text_separator_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_text_separator_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_date_day_separator_img = ''
        let normal_date_img_date_week_img = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg = ''
        let idle_date_img_date_week_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_minute_separator_img = ''
        let normal_moon_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let Button_7 = ''
        let Button_8 = ''
        let Button_9 = ''
		// Создаем сенсор времени
const timeSensorForHoliday = hmSensor.createSensor(hmSensor.id.TIME);

// Список праздников
// Список праздников России
const holidays = {
    // Январь
    "01-01": "Новый год 🎉",
    "01-02": "Новогодние каникулы 🎄",
    "01-03": "Новогодние каникулы 🎄", 
    "01-04": "Новогодние каникулы 🎄",
    "01-05": "Новогодние каникулы 🎄",
    "01-06": "Новогодние каникулы 🎄",
    "01-07": "Рождество Христово ✨",
    "01-08": "Новогодние каникулы 🎄",
    "01-14": "Старый Новый год",
    
    // Февраль
    "02-14": "День святого Валентина ❤️",
    "02-15": "День памяти воинов-интернационалистов 🎖",
    "02-23": "День защитника Отечества ⭐",
    
    // Март
    "03-08": "Международный женский день 🌹",
    "03-10": "День работников ЖКХ 🏠",
    "03-19": "День моряка-подводника ⚓",
    "03-27": "День войск национальной гвардии 🛡️",
    
    // Апрель
    "04-01": "День смеха 😄",
    "04-02": "День единения народов 🤝",
    "04-07": "День здоровья 💊",
    "04-12": "День космонавтики 🚀",
    "04-18": "День победы на Чудском озере 🛡️",
    "04-26": "День участников ликвидации радиационных аварий ☢️",
    "04-30": "День пожарной охраны 🚒",
    
    // Май
    "05-01": "Праздник Весны и Труда 🌷",
    "05-07": "День радио 📻",
    "05-09": "День Победы 🎖",
    "05-12": "День экологического образования 🌍",
    "05-15": "Международный день семьи 👨‍👩‍👧‍👦",
    "05-18": "День Балтийского флота ⚓",
    "05-24": "День славянской письменности и культуры 📖",
    "05-26": "День российского предпринимательства 💼",
    "05-27": "День библиотек 📚",
    "05-28": "День пограничника 🎯",
    "05-31": "День адвокатуры ⚖️",
    
    // Июнь
    "06-01": "Международный день защиты детей 👧🧒",
    "06-06": "Пушкинский день России ✒️",
    "06-12": "День России 🇷🇺",
    "06-22": "День памяти и скорби 🕯",
    "06-27": "День молодежи 🎭",
    
    // Июль
    "07-02": "День следователя 🔍",
    "07-08": "День семьи, любви и верности 💞",
    "07-10": "День воинской славы России 🎖",
    "07-17": "День этнографа 🌍",
    "07-24": "День кадастрового инженера 🗺️",
    "07-28": "День Крещения Руси ✝",
    
    // Август
    "08-01": "День Тыла Вооруженных Сил РФ 🎖",
    "08-02": "День ВДВ 🇷🇺",
    "08-06": "День Железнодорожных войск 🚂",
    "08-09": "День воинской славы России 🛡️",
    "08-12": "День ВВС ✈️",
    "08-15": "День археологии 🏺",
    "08-22": "День Государственного флага РФ 🇷🇺",
    "08-27": "День российского кино 🎬",
    
    // Сентябрь
    "09-01": "День знаний 🎓",
    "09-03": "День солидарности в борьбе с терроризмом 🕯",
    "09-08": "День финансиста 💰",
    "09-11": "День воинской славы России 🎖",
    "09-13": "День программиста 💻",
    "09-19": "День оружейника 🔫",
    "09-21": "День победы в Куликовской битве 🛡️",
    "09-27": "День воспитателя 👩‍🏫",
    
    // Октябрь
    "10-01": "День пожилых людей 👵🧓",
    "10-04": "День космических войск 🛰️",
    "10-05": "День учителя 🍎",
    "10-20": "День военного связиста 📡",
    "10-24": "День подразделений спецназа ⭐",
    "10-25": "День таможенника 🛄",
    "10-29": "День вневедомственной охраны 👮",
    "10-30": "День инженера-механика 🔧",
    "10-31": "Хэллоуин 🎃",
    
    // Ноябрь
    "11-04": "День народного единства 🤝",
    "11-07": "День воинской славы России 🎖",
    "11-10": "День сотрудника органов внутренних дел 👮‍♂️",
    "11-19": "День ракетных войск и артиллерии 🚀",
    "11-21": "День бухгалтера 📊",
    "11-27": "День морской пехоты ⚓",
    
    // Декабрь
    "12-03": "День юриста ⚖️",
    "12-09": "День Героев Отечества ⭐",
    "12-12": "День Конституции РФ 📜",
    "12-17": "День РВСН 🚀",
    "12-20": "День работника органов безопасности 🛡️",
    "12-22": "День энергетика ⚡",
    "12-24": "День воинской славы России 🎖",
    "12-25": "Католическое Рождество ✨",
    "12-27": "День спасателя 🚑",
    "12-31": "Канун Нового года 🎆"
};

// Функция для получения текста праздника
function getHolidayText() {
    const t = hmSensor.createSensor(hmSensor.id.TIME);
    const m = String(t.month).padStart(2, "0");
    const d = String(t.day).padStart(2, "0");
    return holidays[`${m}-${d}`] || "Обычный день";
}


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			 normal_altimeter_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 348,
              y: 138,
              font_array: ["0061.png","0062.png","0063.png","0064.png","0065.png","0066.png","0067.png","0068.png","0069.png","0070.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              text: getPressureMMHG(),
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_vo2max_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 16,
              y: 248,
              src: 'vos.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_floor_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 417,
              y: 248,
              src: 'zak.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_hrv_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 410,
              y: 134,
              src: 'atm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_bio_charge_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 369,
              y: 87,
              src: 'btoff1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 89,
              y: 90,
              src: 'al5.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 42,
              y: 342,
              image_array: ["moon_1.png","moon_2.png","moon_3.png","moon_4.png","moon_5.png","moon_6.png","moon_7.png","moon_8.png","moon_9.png","moon_10.png","moon_11.png","moon_12.png","moon_13.png","moon_14.png","moon_15.png","moon_16.png","moon_17.png","moon_18.png","moon_19.png","moon_20.png","moon_21.png","moon_22.png","moon_23.png","moon_24.png","moon_25.png","moon_26.png","moon_27.png","moon_28.png","moon_29.png","moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 71,
              y: 260,
              font_array: ["161.png","162.png","163.png","164.png","165.png","166.png","167.png","168.png","169.png","170.png"],
              padding: false,
              h_space: 2,
              dot_image: 'raz1.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 330,
              y: 260,
              font_array: ["161.png","162.png","163.png","164.png","165.png","166.png","167.png","168.png","169.png","170.png"],
              padding: false,
              h_space: 2,
              dot_image: 'raz1.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 369,
              y: 87,
              src: 'btoff2.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 89,
              y: 90,
              src: 'al4.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

           

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 416,
              y: 184,
              image_array: ["clima_1.png","clima_2.png","clima_3.png","clima_4.png","clima_5.png","clima_6.png","clima_7.png","clima_8.png","clima_9.png","clima_10.png","clima_11.png","clima_12.png","clima_13.png","clima_14.png","clima_15.png","clima_16.png","clima_17.png","clima_18.png","clima_19.png","clima_20.png","clima_21.png","clima_22.png","clima_23.png","clima_24.png","clima_25.png","clima_26.png","clima_27.png","clima_28.png","clima_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 345,
              y: 199,
              font_array: ["0061.png","0062.png","0063.png","0064.png","0065.png","0066.png","0067.png","0068.png","0069.png","0070.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'icon_1.png',
              unit_tc: 'icon_1.png',
              unit_en: 'icon_1.png',
              negative_image: 'icon_3.png',
              invalid_image: 'icon_3.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 60,
              y: 199,
              font_array: ["0061.png","0062.png","0063.png","0064.png","0065.png","0066.png","0067.png","0068.png","0069.png","0070.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 22,
              y: 197,
              src: 'step.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 74,
              y: 138,
              font_array: ["0061.png","0062.png","0063.png","0064.png","0065.png","0066.png","0067.png","0068.png","0069.png","0070.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 39,
              y: 133,
              src: 'puls.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 210,
              y: 441,
              font_array: ["0061.png","0062.png","0063.png","0064.png","0065.png","0066.png","0067.png","0068.png","0069.png","0070.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'icon_2.png',
              unit_tc: 'icon_2.png',
              unit_en: 'icon_2.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 191,
              y: 437,
              src: 'zar.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 162,
              month_startY: 246,
              month_sc_array: ["77.png","78.png","79.png","80.png","81.png","82.png","83.png","84.png","85.png","86.png","87.png","88.png"],
              month_tc_array: ["77.png","78.png","79.png","80.png","81.png","82.png","83.png","84.png","85.png","86.png","87.png","88.png"],
              month_en_array: ["77.png","78.png","79.png","80.png","81.png","82.png","83.png","84.png","85.png","86.png","87.png","88.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 155,
              day_startY: 130,
              day_sc_array: ["148.png","149.png","150.png","151.png","152.png","153.png","154.png","155.png","156.png","157.png"],
              day_tc_array: ["148.png","149.png","150.png","151.png","152.png","153.png","154.png","155.png","156.png","157.png"],
              day_en_array: ["148.png","149.png","150.png","151.png","152.png","153.png","154.png","155.png","156.png","157.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_day_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 37,
              src: 'pol.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 141,
              y: 84,
              week_en: ["89.png","90.png","91.png","92.png","93.png","94.png","95.png"],
              week_tc: ["89.png","90.png","91.png","92.png","93.png","94.png","95.png"],
              week_sc: ["89.png","90.png","91.png","92.png","93.png","94.png","95.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 99,
              hour_startY: 349,
              hour_array: ["6.png","7.png","8.png","9.png","10.png","11.png","12.png","13.png","14.png","15.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_unit_sc: '5.png',
              hour_unit_tc: '5.png',
              hour_unit_en: '5.png',
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 0,
              minute_startY: 0,
              minute_array: ["6.png","7.png","8.png","9.png","10.png","11.png","12.png","13.png","14.png","15.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 1,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 391,
              second_startY: 349,
              second_array: ["16.png","17.png","18.png","19.png","20.png","21.png","22.png","23.png","24.png","25.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 74,
              y: 260,
              week_en: ["week_0.png","week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png"],
              week_tc: ["week_0.png","week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png"],
              week_sc: ["week_0.png","week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 328,
              y: 217,
              src: '0499.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 25,
              y: 217,
              src: '0501.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 56,
              hour_startY: 106,
              hour_array: ["148.png","149.png","150.png","151.png","152.png","153.png","154.png","155.png","156.png","157.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 256,
              minute_startY: 106,
              minute_array: ["148.png","149.png","150.png","151.png","152.png","153.png","154.png","155.png","156.png","157.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_minute_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 234,
              y: 134,
              src: '158.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_moon_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 52,
              y: 340,
              w: 45,
              h: 48,
              type: hmUI.data_type.MOON_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 172,
              y: 97,
              w: 132,
              h: 139,
              text: '',
              color: 0xFFFF8C00,
              text_size: 26,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({ appid: 1057409, url: 'page/index' });
              }, // end func
              longpress_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 318,
              y: 126,
              w: 103,
              h: 49,
              text: '',
              color: 0xFFFF8C00,
              text_size: 26,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'BaroAltimeterScreen', native: true });
              }, // end func
              longpress_func: (button_widget) => {
                hmApp.startApp({url: 'CompassScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 318,
              y: 190,
              w: 103,
              h: 48,
              text: '',
              color: 0xFFFF8C00,
              text_size: 26,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({ appid: 1051195, url: 'page/index', params: { from_wf: true} });
              }, // end func
              longpress_func: (button_widget) => {
                hmApp.startApp({url: 'WeatherScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 99,
              y: 346,
              w: 126,
              h: 81,
              text: '',
              color: 0xFFFF8C00,
              text_size: 26,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'AlarmInfoScreen', native: true });
              }, // end func
              longpress_func: (button_widget) => {
                hmApp.startApp({url: 'Sleep_HomeScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 256,
              y: 349,
              w: 126,
              h: 81,
              text: '',
              color: 0xFFFF8C00,
              text_size: 26,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'CountdownAppScreen', native: true });
              }, // end func
              longpress_func: (button_widget) => {
                hmApp.startApp({url: 'StopWatchScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 169,
              y: 434,
              w: 142,
              h: 34,
              text: '',
              color: 0xFFFF8C00,
              text_size: 26,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'Settings_batteryManagerScreen', native: true });
              }, // end func
              longpress_func: (button_widget) => {
                hmApp.startApp({url: 'FindPhoneScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_7 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 31,
              y: 127,
              w: 137,
              h: 42,
              text: '',
              color: 0xFFFF8C00,
              text_size: 26,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'heart_app_Screen', native: true });
              }, // end func
              longpress_func: (button_widget) => {
                hmApp.startApp({url: 'oneKeyAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_8 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 31,
              y: 191,
              w: 134,
              h: 41,
              text: '',
              color: 0xFFFF8C00,
              text_size: 26,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'activityAppScreen', native: true });
              }, // end func
              longpress_func: (button_widget) => {
                hmApp.startApp({url: 'SportListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_9 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 31,
              y: 243,
              w: 124,
              h: 41,
              text: '',
              color: 0xFFFF8C00,
              text_size: 26,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'TideScreen', native: true });
              }, // end func
              longpress_func: (button_widget) => {
                hmApp.startApp({url: 'MusicCommonScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button
			
			// Виджет отображения праздника
const holidayTextWidget = hmUI.createWidget(hmUI.widget.TEXT, {
    x: 0,
    y: 294,       // при необходимости поменяй
    w: 480,
    h: 40,
    text: getHolidayText(),
    color: 0xffFF0000,
    text_size: 24,
    font: 'fonts/Franklin.ttf',
    text_style: hmUI.text_style.WRAP,
    align_h: hmUI.align.CENTER_H,
    align_v: hmUI.align.CENTER_V,
	show_level: hmUI.show_level.ONLY_NORMAL, 
    visible: true
	
	
	
});

// Функция обновления
function updateHoliday() {
    holidayTextWidget.setProperty(hmUI.prop.TEXT, getHolidayText());
}
        // Первоначальное обновление праздника
        updateHoliday();

        console.log('Watch_Face.ScreenAOD');
        // === Delegate for time and resume events ===
const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {

    // Вызывается при каждом изменении минуты
    minute_change_call() {
        updatePressure();
        updateHoliday();   // обновляем праздник
    },

    // Вызывается при возвращении на циферблат
    resume_call() {
        console.log("resume_call()");
        updatePressure();
        updateHoliday();
    }
});



                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
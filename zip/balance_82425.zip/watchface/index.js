﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_distance_text_text_img = ''
        let normal_distance_text_separator_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_text_separator_img = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_calorie_current_text_img = ''
        let normal_calorie_current_separator_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_img_time_AmPm = ''
        let idle_background_bg_img = ''
        let idle_step_current_text_img = ''
        let idle_step_current_separator_img = ''
        let idle_battery_text_text_img = ''
        let idle_battery_text_separator_img = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_img_time_AmPm = ''
        let image_top_img = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 325,
              y: 257,
              font_array: ["sml_dark_00.png","sml_dark_01.png","sml_dark_02.png","sml_dark_03.png","sml_dark_04.png","sml_dark_05.png","sml_dark_06.png","sml_dark_07.png","sml_dark_08.png","sml_dark_09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'sml_dark_km.png',
              unit_tc: 'sml_dark_km.png',
              unit_en: 'sml_dark_km.png',
              dot_image: 'sml_dark_decimal.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 280,
              y: 257,
              src: 'distance.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 325,
              y: 326,
              font_array: ["sml_dark_00.png","sml_dark_01.png","sml_dark_02.png","sml_dark_03.png","sml_dark_04.png","sml_dark_05.png","sml_dark_06.png","sml_dark_07.png","sml_dark_08.png","sml_dark_09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'sml_dark_pctg.png',
              unit_tc: 'sml_dark_pctg.png',
              unit_en: 'sml_dark_pctg.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 280,
              y: 326,
              src: 'battery.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 325,
              y: 187,
              font_array: ["sml_dark_00.png","sml_dark_01.png","sml_dark_02.png","sml_dark_03.png","sml_dark_04.png","sml_dark_05.png","sml_dark_06.png","sml_dark_07.png","sml_dark_08.png","sml_dark_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 280,
              y: 187,
              src: 'steps.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 325,
              y: 118,
              font_array: ["sml_dark_00.png","sml_dark_01.png","sml_dark_02.png","sml_dark_03.png","sml_dark_04.png","sml_dark_05.png","sml_dark_06.png","sml_dark_07.png","sml_dark_08.png","sml_dark_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 280,
              y: 118,
              src: 'calories.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 188,
              y: 414,
              font_array: ["sml_lght_00.png","sml_lght_01.png","sml_lght_02.png","sml_lght_03.png","sml_lght_04.png","sml_lght_05.png","sml_lght_06.png","sml_lght_07.png","sml_lght_08.png","sml_lght_09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'sml_lght_degree.png',
              unit_tc: 'sml_lght_degree.png',
              unit_en: 'sml_lght_degree.png',
              imperial_unit_sc: 'sml_lght_degree.png',
              imperial_unit_tc: 'sml_lght_degree.png',
              imperial_unit_en: 'sml_lght_degree.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const temperatureUnit = hmSetting.getTemperatureUnit();
            //start of ignored block
            if (temperatureUnit == 1) {
              normal_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
                x: 188,
                y: 414,
                font_array: ["sml_lght_00.png","sml_lght_01.png","sml_lght_02.png","sml_lght_03.png","sml_lght_04.png","sml_lght_05.png","sml_lght_06.png","sml_lght_07.png","sml_lght_08.png","sml_lght_09.png"],
                padding: false,
                h_space: 0,
                unit_sc: 'sml_lght_degree.png',
                unit_tc: 'sml_lght_degree.png',
                unit_en: 'sml_lght_degree.png',
                imperial_unit_sc: 'sml_lght_degree.png',
                imperial_unit_tc: 'sml_lght_degree.png',
                imperial_unit_en: 'sml_lght_degree.png',
                align_h: hmUI.align.RIGHT,
                type: hmUI.data_type.WEATHER_CURRENT,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
            };
            //end of ignored block

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 282,
              y: 386,
              image_array: ["weather01.png","weather02.png","weather03.png","weather04.png","weather05.png","weather06.png","weather07.png","weather08.png","weather09.png","weather10.png","weather11.png","weather12.png","weather13.png","weather14.png","weather15.png","weather16.png","weather17.png","weather18.png","weather19.png","weather20.png","weather21.png","weather22.png","weather23.png","weather24.png","weather25.png","weather26.png","weather27.png","weather28.png","weather29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 187,
              y: 366,
              week_en: ["wday01.png","wday02.png","wday03.png","wday04.png","wday05.png","wday06.png","wday07.png"],
              week_tc: ["wday01.png","wday02.png","wday03.png","wday04.png","wday05.png","wday06.png","wday07.png"],
              week_sc: ["wday01.png","wday02.png","wday03.png","wday04.png","wday05.png","wday06.png","wday07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 193,
              month_startY: 80,
              month_sc_array: ["mnth01.png","mnth02.png","mnth03.png","mnth04.png","mnth05.png","mnth06.png","mnth07.png","mnth08.png","mnth09.png","mnth10.png","mnth11.png","mnth12.png"],
              month_tc_array: ["mnth01.png","mnth02.png","mnth03.png","mnth04.png","mnth05.png","mnth06.png","mnth07.png","mnth08.png","mnth09.png","mnth10.png","mnth11.png","mnth12.png"],
              month_en_array: ["mnth01.png","mnth02.png","mnth03.png","mnth04.png","mnth05.png","mnth06.png","mnth07.png","mnth08.png","mnth09.png","mnth10.png","mnth11.png","mnth12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 220,
              day_startY: 32,
              day_sc_array: ["sml_lght_00.png","sml_lght_01.png","sml_lght_02.png","sml_lght_03.png","sml_lght_04.png","sml_lght_05.png","sml_lght_06.png","sml_lght_07.png","sml_lght_08.png","sml_lght_09.png"],
              day_tc_array: ["sml_lght_00.png","sml_lght_01.png","sml_lght_02.png","sml_lght_03.png","sml_lght_04.png","sml_lght_05.png","sml_lght_06.png","sml_lght_07.png","sml_lght_08.png","sml_lght_09.png"],
              day_en_array: ["sml_lght_00.png","sml_lght_01.png","sml_lght_02.png","sml_lght_03.png","sml_lght_04.png","sml_lght_05.png","sml_lght_06.png","sml_lght_07.png","sml_lght_08.png","sml_lght_09.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.RIGHT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 134,
              hour_startY: 119,
              hour_array: ["big00.png","big01.png","big02.png","big03.png","big04.png","big05.png","big06.png","big07.png","big08.png","big09.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 134,
              minute_startY: 243,
              minute_array: ["big00.png","big01.png","big02.png","big03.png","big04.png","big05.png","big06.png","big07.png","big08.png","big09.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 84,
              am_y: 223,
              am_sc_path: 'am.png',
              am_en_path: 'am.png',
              pm_x: 84,
              pm_y: 223,
              pm_sc_path: 'pm.png',
              pm_en_path: 'pm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg_aod.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 325,
              y: 187,
              font_array: ["sml_lght_00.png","sml_lght_01.png","sml_lght_02.png","sml_lght_03.png","sml_lght_04.png","sml_lght_05.png","sml_lght_06.png","sml_lght_07.png","sml_lght_08.png","sml_lght_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 280,
              y: 187,
              src: 'steps_aod.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 325,
              y: 257,
              font_array: ["sml_lght_00.png","sml_lght_01.png","sml_lght_02.png","sml_lght_03.png","sml_lght_04.png","sml_lght_05.png","sml_lght_06.png","sml_lght_07.png","sml_lght_08.png","sml_lght_09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'sml_lght_pctg.png',
              unit_tc: 'sml_lght_pctg.png',
              unit_en: 'sml_lght_pctg.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 280,
              y: 257,
              src: 'battery_aod.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 134,
              hour_startY: 119,
              hour_array: ["bigaod00.png","bigaod01.png","bigaod02.png","bigaod03.png","bigaod04.png","bigaod05.png","bigaod06.png","bigaod07.png","bigaod08.png","bigaod09.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 134,
              minute_startY: 243,
              minute_array: ["bigaod00.png","bigaod01.png","bigaod02.png","bigaod03.png","bigaod04.png","bigaod05.png","bigaod06.png","bigaod07.png","bigaod08.png","bigaod09.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 88,
              am_y: 223,
              am_sc_path: 'am.png',
              am_en_path: 'am.png',
              pm_x: 88,
              pm_y: 223,
              pm_sc_path: 'pm.png',
              pm_en_path: 'pm.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            image_top_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'top.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            console.log('Watch_Face.Shortcuts');

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 134,
              y: 243,
              w: 123,
              h: 120,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 134,
              y: 118,
              w: 123,
              h: 120,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 278,
              y: 114,
              w: 150,
              h: 46,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 278,
              y: 183,
              w: 150,
              h: 46,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 284,
              y: 40,
              w: 54,
              h: 54,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'heartrate.png',
              normal_src: 'heartrate.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'heart_app_Screen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 192,
              y: 365,
              w: 65,
              h: 86,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'spacer.png',
              normal_src: 'spacer.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'WeatherScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 192,
              y: 29,
              w: 65,
              h: 88,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'spacer.png',
              normal_src: 'spacer.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 279,
              y: 321,
              w: 119,
              h: 46,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'spacer.png',
              normal_src: 'spacer.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'Settings_batteryManagerScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
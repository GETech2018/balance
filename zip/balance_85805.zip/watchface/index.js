﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_step_icon_img = ''
        let normal_step_current_text_img = ''
        let normal_battery_text_text_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_sun_icon_img = ''
        let normal_sun_high_text_img = ''
        let normal_sun_low_text_img = ''
        let normal_pai_weekly_text_img = ''
        let normal_spo2_text_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_altimeter_text_text_img = ''
        let normal_humidity_text_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_distance_text_text_img = ''
        let normal_stand_current_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_analog_clock_time_pointer_second_classic = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_altimeter_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let idle_background_bg_img = ''
        let idle_step_current_text_img = ''
        let idle_battery_text_text_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_day = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''

        // Mutiinfo on-off
        let btnmultiinfo
        let lmultiinfo = false

        function click_Multiinfo() {
            if(lmultiinfo) {
                lmultiinfo=false
                normal_calorie_current_text_img.setProperty(hmUI.prop.X, 139);
                normal_distance_text_text_img.setProperty(hmUI.prop.X, 251);
                normal_temperature_current_text_img.setProperty(hmUI.prop.X, 144);
                normal_weather_image_progress_img_level.setProperty(hmUI.prop.X, 161);
                normal_humidity_text_text_img.setProperty(hmUI.prop.X, 277);
                normal_heart_rate_text_text_img.setProperty(hmUI.prop.X, 148);
                normal_pai_weekly_text_img.setProperty(hmUI.prop.X, 277);
                }
            else {
                lmultiinfo=true
                normal_calorie_current_text_img.setProperty(hmUI.prop.X, 112);
                normal_distance_text_text_img.setProperty(hmUI.prop.X, 273);
                normal_temperature_current_text_img.setProperty(hmUI.prop.X, 121);
                normal_weather_image_progress_img_level.setProperty(hmUI.prop.X, 138);
                normal_humidity_text_text_img.setProperty(hmUI.prop.X, 211);
                normal_heart_rate_text_text_img.setProperty(hmUI.prop.X, 123);
                normal_pai_weekly_text_img.setProperty(hmUI.prop.X, 297);
                }
            if(backgroundnumber==2) UpdateBackgroundTwo();
            if(backgroundnumber==3) UpdateBackgroundThree();
            if(backgroundnumber==4) UpdateBackgroundFour();
            if(lmultiinfo) hmUI.showToast({text: 'Multi Info: On'});
            if(!lmultiinfo) hmUI.showToast({text: 'Multi Info: Off'});
        }


        // moon sunset on-off
        let btnsunmoon = ''
        let lsunmoon = false

        function click_Sunmoon() {
            if(lsunmoon) {
                lsunmoon=false
                normal_moon_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
                normal_sun_icon_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_sun_high_text_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_sun_low_text_img .setProperty(hmUI.prop.VISIBLE, false);
                }
            else {
                lsunmoon=true
                normal_moon_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);
                normal_sun_icon_img.setProperty(hmUI.prop.VISIBLE, true);
                normal_sun_high_text_img.setProperty(hmUI.prop.VISIBLE, true);
                normal_sun_low_text_img .setProperty(hmUI.prop.VISIBLE, true);
                }
            if(lsunmoon) hmUI.showToast({text: 'Alba-Tramonto: On'});
            if(!lsunmoon) hmUI.showToast({text: 'Alba-Tramonto: Off'});
        }


        // Bezel on-off
        let btnbezel = ''
        let lbezel = false

        function click_Bezel() {
            if(lbezel) {
                lbezel=false
                normal_background_bg_img.setProperty(hmUI.prop.SRC, "color" + parseInt(colornumber) + ".png");
                }
            else {
                lbezel=true
                normal_background_bg_img.setProperty(hmUI.prop.SRC, "colorb" + parseInt(colornumber) + ".png");
                }
            if(lbezel) hmUI.showToast({text: 'Lunetta: Off'});
            if(!lbezel) hmUI.showToast({text: 'Lunetta: On'});
        }


        // Start color change
        let btncolor = ''
        let colornumber = 1
        let totalcolors = 12

        function click_Color() {
            if(colornumber==totalcolors) {
            colornumber=0;
                }
            else {
                colornumber=colornumber+1;
            }
            hmUI.showToast({text: "Colore " + parseInt(colornumber) });
            if(lbezel) {
                  normal_background_bg_img.setProperty(hmUI.prop.SRC, "colorb" + parseInt(colornumber) + ".png");
               }
            else {
                normal_background_bg_img.setProperty(hmUI.prop.SRC, "color" + parseInt(colornumber) + ".png");
            }
            call_change_Hands();
        }

        // Change hands called by backgroundcolor (default color with background)
        function call_change_Hands() {
              if(colornumber==9) {
                ChangeHands(1);
              } else if(colornumber==10) {
                ChangeHands(2);
              } else if(colornumber==11) {
                ChangeHands(3);
              } else if(colornumber==12) {
                ChangeHands(4);
              } else if(colornumber==0) {
                ChangeHands(0);
              }
        }

        // Start Change hands color (press button hour1)
        let btnchangehands = ''
        let handsnumber = 0
        let totalhands = 5

        function click_Changehands() {
          handsnumber=handsnumber+1;
          switch (handsnumber) {
            case 1:
              ChangeHands(1); break;
            case 2:
              ChangeHands(2); break;
            case 3:
              ChangeHands(3); break;
            case 4:
              ChangeHands(4); break;
            case 5:
              ChangeHands(5); break;
            default:
              ChangeHands(0); handsnumber=0;
          }
          hmUI.showToast({text: "Colore Lancette " + parseInt(handsnumber) });
        }

        // Give handsnumber. Must exist
        function ChangeHands(number) {
           if(number==1) {
                  hourstring='hour1.png';
                  minutestring='min1.png';
             } else if(number==2) {
                  hourstring='hour2.png';
                  minutestring='min2.png';
             } else if(number==3) {
                  hourstring='hour3.png';
                  minutestring='min3.png';
             } else if(number==4) {
                  hourstring='hour4.png';
                  minutestring='min4.png';
             } else if(number==5) {
                  hourstring='hour5.png';
                  minutestring='min5.png';
             } else {
                  hourstring='hour0.png';
                  minutestring='min0.png';
             }
             normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.MORE, {
             hour_path: hourstring,
             hour_centerX: 240,
             hour_centerY: 240,
             hour_posX: 15,
             hour_posY: 140,
             show_level: hmUI.show_level.ONLY_NORMAL,
             });

             normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.MORE, {
             minute_path: minutestring,
             minute_centerX: 240,
             minute_centerY: 240,
             minute_posX: 21,
             minute_posY: 227,
             show_level: hmUI.show_level.ONLY_NORMAL,
             });
        }


        // Start background change
        let btnbackground = ''
        let backgroundnumber = 1
        let totalpictures = 4

        function click_Background() {
            if(backgroundnumber==totalpictures) {
            backgroundnumber=1;
                UpdateBackgroundOne();
                }
            else {
                backgroundnumber=backgroundnumber+1;
                if(backgroundnumber==2) {
                  UpdateBackgroundTwo();
                }
                if(backgroundnumber==3) {
                  UpdateBackgroundThree();
                }
                if(backgroundnumber==4) {
                  UpdateBackgroundFour();
                }
            }
            if(lmultiinfo) {
                 if(backgroundnumber==2) hmUI.showToast({text: 'Kcal-In piedi-Distanza'});
                 if(backgroundnumber==3) hmUI.showToast({text: 'Meteo-Umidità-Pressione'});
                 if(backgroundnumber==4) hmUI.showToast({text: 'Battiti-Ossigeno-PAI'});
            }
            else {
                 if(backgroundnumber==2) hmUI.showToast({text: 'Kcal-Distanza'});
                 if(backgroundnumber==3) hmUI.showToast({text: 'Meteo-Umidità'});
                 if(backgroundnumber==4) hmUI.showToast({text: 'Battiti-PAI'});
            }
            if(backgroundnumber==1) hmUI.showToast({text: 'Orologio Digitale'});
        }

        //digital
        function UpdateBackgroundOne(){
                normal_digital_clock_img_time_AmPm.setProperty(hmUI.prop.VISIBLE, true);
                normal_digital_clock_img_time.setProperty(hmUI.prop.VISIBLE, true);
                normal_digital_clock_hour_separator_img.setProperty(hmUI.prop.VISIBLE, true);
                normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_pai_weekly_text_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_humidity_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);

                normal_heart_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
                normal_pai_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
                normal_temperature_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);

                normal_spo2_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_spo2_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
                normal_altimeter_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_altimeter_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);

                normal_step_icon_img.setProperty(hmUI.prop.SRC, "background" + parseInt(backgroundnumber) + ".png");
        }

        //kcal-distance stand
        function UpdateBackgroundTwo(){
                normal_digital_clock_img_time_AmPm.setProperty(hmUI.prop.VISIBLE, false);
                normal_digital_clock_img_time.setProperty(hmUI.prop.VISIBLE, false);
                normal_digital_clock_hour_separator_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
                normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
                normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_pai_weekly_text_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_humidity_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);

                normal_heart_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
                normal_pai_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
                normal_temperature_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);

                normal_spo2_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_spo2_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
                normal_altimeter_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_altimeter_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);

                if(lmultiinfo) {
                   normal_stand_current_text_img.setProperty(hmUI.prop.VISIBLE, true);

                   normal_step_icon_img.setProperty(hmUI.prop.SRC, "backgroundm" + parseInt(backgroundnumber) + ".png");
                }
                else {
                   normal_stand_current_text_img.setProperty(hmUI.prop.VISIBLE, false);

                   normal_step_icon_img.setProperty(hmUI.prop.SRC, "background" + parseInt(backgroundnumber) + ".png");
                }
        }

        //weather-humi and hpa
        function UpdateBackgroundThree(){
                normal_digital_clock_img_time_AmPm.setProperty(hmUI.prop.VISIBLE, false);
                normal_digital_clock_img_time.setProperty(hmUI.prop.VISIBLE, false);
                normal_digital_clock_hour_separator_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_pai_weekly_text_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_humidity_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
                normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
                normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);

                normal_heart_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
                normal_pai_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
                normal_temperature_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);

                normal_spo2_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_spo2_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
                normal_stand_current_text_img.setProperty(hmUI.prop.VISIBLE, false);

                if(lmultiinfo) {
                   normal_altimeter_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
                   normal_altimeter_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);

                   normal_step_icon_img.setProperty(hmUI.prop.SRC, "backgroundm" + parseInt(backgroundnumber) + ".png");
                }
                else {
                   normal_altimeter_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
                   normal_altimeter_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);

                   normal_step_icon_img.setProperty(hmUI.prop.SRC, "background" + parseInt(backgroundnumber) + ".png");
                }
        }

        //heart-pai and spo2
        function UpdateBackgroundFour(){
                normal_digital_clock_img_time_AmPm.setProperty(hmUI.prop.VISIBLE, false);
                normal_digital_clock_img_time.setProperty(hmUI.prop.VISIBLE, false);
                normal_digital_clock_hour_separator_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
                normal_pai_weekly_text_img.setProperty(hmUI.prop.VISIBLE, true);
                normal_humidity_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);

                normal_heart_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
                normal_pai_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
                normal_temperature_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);

                normal_altimeter_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_altimeter_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
                normal_stand_current_text_img.setProperty(hmUI.prop.VISIBLE, false);

                if(lmultiinfo) {
                   normal_spo2_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
                   normal_spo2_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);

                   normal_step_icon_img.setProperty(hmUI.prop.SRC, "backgroundm" + parseInt(backgroundnumber) + ".png");
                }
                else {
                   normal_spo2_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
                   normal_spo2_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);

                   normal_step_icon_img.setProperty(hmUI.prop.SRC, "background" + parseInt(backgroundnumber) + ".png");
                }
        }

        // btnsecondhand
        let btnsecondhand = ''
        let lsecondhand = false
        let countsecondhand = 0
        function click_Secondhand(){
                lsecondhand=true
                stopSecAnim();
                countsecondhand=countsecondhand+1;
                if(countsecondhand==1) {
                  animFps = 4;
                }
                if(countsecondhand==2) {
                  animFps = 6;
                }
                if(countsecondhand==3) {
                  animFps = 8;
                }
                if(countsecondhand==4) {
                  animFps = 10;
                }
                if(countsecondhand==5) {
                  animFps = 25;
                }
                if(countsecondhand==6) {
                  lsecondhand=false
                  countsecondhand = 0;
                }
                if(!lsecondhand) {
                               normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, false);
                               normal_analog_clock_time_pointer_second_classic.setProperty(hmUI.prop.VISIBLE, true);
                               hmUI.showToast({text: "Secondi Normali"});
                }
                else {
                      normal_analog_clock_time_pointer_second_classic.setProperty(hmUI.prop.VISIBLE, false);
                      startSecHandTimer();
                      normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, true);
                      if (animFps==25) { hmUI.showToast({text: "Secondi Fluidi"});
                      } else { hmUI.showToast({text: "Livello Fluidità " + parseInt(animFps) }); }
                }
        }

		/**
         * SMOOTH SECONDS SCRIPTS
         */
        let now;
        let lastTime = 0;
        let animTimer;
        const animDuration = 5000;
        let animFps = 25; // 8 for 28800VPH, 10 for 36000VPH, 25 for smooth motion

        function setSec() {
          const screenType = hmSetting.getScreenType();
          if (screenType === hmSetting.screen_type.AOD) {
           return stopSecAnim();
          }
          if (!now) {
            now = hmSensor.createSensor(hmSensor.id.TIME);
          }
        }

        function startSecAnim(sec) {
          const secAnim = {
            anim_rate: 'linear',
            anim_duration: animDuration,
            anim_from: sec,
            anim_to: sec + animDuration * 6 / 1000,
            repeat_count: 1,
            anim_fps: animFps,
            anim_key: "angle",
            anim_status: 1,
          }

          normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.ANIM, secAnim);
        }

        /**
         * onDestroy()
         */
        function stopSecAnim() {
          if (animTimer) {
            timer.stopTimer(animTimer);
            animTimer = undefined;
          }
        }

        // start secondhand
        function startSecHandTimer() {
              if (animTimer) return;

              let duration = 0;
              const diffTime = now.utc - lastTime;
              if (diffTime < animDuration) {
                duration = animDuration - diffTime;
              }

              animTimer = timer.createTimer(duration, animDuration, (function (option) {
                lastTime = now.utc;
                startSecAnim(now.second * 6);

              }));
        }

	    /** END SMOOTH SECOND SCRIPTS 'search widgetDelegate and setsec' */

        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'color1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'background1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 277,
              y: 239,
              font_array: ["digital1_0.png","digital1_1.png","digital1_2.png","digital1_3.png","digital1_4.png","digital1_5.png","digital1_6.png","digital1_7.png","digital1_8.png","digital1_9.png"],
              padding: false,
              h_space: -1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 123,
              y: 239,
              font_array: ["digital1_0.png","digital1_1.png","digital1_2.png","digital1_3.png","digital1_4.png","digital1_5.png","digital1_6.png","digital1_7.png","digital1_8.png","digital1_9.png"],
              padding: false,
              h_space: -1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 222,
              y: 354,
              image_array: ["Moon_30_01.png","Moon_30_02.png","Moon_30_03.png","Moon_30_04.png","Moon_30_05.png","Moon_30_06.png","Moon_30_07.png","Moon_30_08.png","Moon_30_09.png","Moon_30_10.png","Moon_30_11.png","Moon_30_12.png","Moon_30_13.png","Moon_30_14.png","Moon_30_15.png","Moon_30_16.png","Moon_30_17.png","Moon_30_18.png","Moon_30_19.png","Moon_30_20.png","Moon_30_21.png","Moon_30_22.png","Moon_30_23.png","Moon_30_24.png","Moon_30_25.png","Moon_30_26.png","Moon_30_27.png","Moon_30_28.png","Moon_30_29.png","Moon_30_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_moon_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);

            normal_sun_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'backsunset.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_sun_icon_img.setProperty(hmUI.prop.VISIBLE, false);

            normal_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 134,
              y: 180,
              font_array: ["small_0.png","small_1.png","small_2.png","small_3.png","small_4.png","small_5.png","small_6.png","small_7.png","small_8.png","small_9.png"],
              padding: false,
              h_space: 0,
              dot_image: 'small_point.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_sun_high_text_img.setProperty(hmUI.prop.VISIBLE, false);

            normal_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 270,
              y: 180,
              font_array: ["small_0.png","small_1.png","small_2.png","small_3.png","small_4.png","small_5.png","small_6.png","small_7.png","small_8.png","small_9.png"],
              padding: false,
              h_space: 0,
              dot_image: 'small_point.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_sun_low_text_img .setProperty(hmUI.prop.VISIBLE, false);

            normal_pai_weekly_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 277,
              y: 317,
              font_array: ["digital1_0.png","digital1_1.png","digital1_2.png","digital1_3.png","digital1_4.png","digital1_5.png","digital1_6.png","digital1_7.png","digital1_8.png","digital1_9.png"],
              padding: false,
              h_space: -1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_pai_weekly_text_img.setProperty(hmUI.prop.VISIBLE, false);

            normal_spo2_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 211,
              y: 317,
              font_array: ["digital1_0.png","digital1_1.png","digital1_2.png","digital1_3.png","digital1_4.png","digital1_5.png","digital1_6.png","digital1_7.png","digital1_8.png","digital1_9.png"],
              padding: false,
              h_space: -1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_spo2_text_text_img.setProperty(hmUI.prop.VISIBLE, false);

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 148,
              y: 317,
              font_array: ["digital1_0.png","digital1_1.png","digital1_2.png","digital1_3.png","digital1_4.png","digital1_5.png","digital1_6.png","digital1_7.png","digital1_8.png","digital1_9.png"],
              padding: false,
              h_space: -1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);

            normal_altimeter_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 287,
              y: 317,
              font_array: ["digital1_0.png","digital1_1.png","digital1_2.png","digital1_3.png","digital1_4.png","digital1_5.png","digital1_6.png","digital1_7.png","digital1_8.png","digital1_9.png"],
              padding: false,
              h_space: -1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_altimeter_text_text_img.setProperty(hmUI.prop.VISIBLE, false);

            normal_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 277,
              y: 317,
              font_array: ["digital1_0.png","digital1_1.png","digital1_2.png","digital1_3.png","digital1_4.png","digital1_5.png","digital1_6.png","digital1_7.png","digital1_8.png","digital1_9.png"],
              padding: false,
              h_space: -1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_humidity_text_text_img.setProperty(hmUI.prop.VISIBLE, false);

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 144,
              y: 317,
              font_array: ["digital1_0.png","digital1_1.png","digital1_2.png","digital1_3.png","digital1_4.png","digital1_5.png","digital1_6.png","digital1_7.png","digital1_8.png","digital1_9.png"],
              padding: false,
              h_space: -1,
              unit_sc: 'weather_318.png',
              unit_tc: 'weather_318.png',
              unit_en: 'weather_318.png',
              negative_image: 'weather_30.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 161,
              y: 283,
              image_array: ["weather_0.png","weather_1.png","weather_2.png","weather_3.png","weather_4.png","weather_5.png","weather_6.png","weather_7.png","weather_8.png","weather_9.png","weather_10.png","weather_11.png","weather_12.png","weather_13.png","weather_14.png","weather_15.png","weather_16.png","weather_17.png","weather_18.png","weather_19.png","weather_20.png","weather_21.png","weather_22.png","weather_23.png","weather_24.png","weather_25.png","weather_26.png","weather_27.png","weather_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 251,
              y: 317,
              font_array: ["digital1_0.png","digital1_1.png","digital1_2.png","digital1_3.png","digital1_4.png","digital1_5.png","digital1_6.png","digital1_7.png","digital1_8.png","digital1_9.png"],
              padding: false,
              h_space: -1,
              unit_sc: 'km.png',
              unit_tc: 'km.png',
              unit_en: 'km.png',
              imperial_unit_sc: 'ml.png',
              imperial_unit_tc: 'ml.png',
              imperial_unit_en: 'ml.png',
              dot_image: 'digital1_10.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);

            normal_stand_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 191,
              y: 317,
              font_array: ["digital1_0.png","digital1_1.png","digital1_2.png","digital1_3.png","digital1_4.png","digital1_5.png","digital1_6.png","digital1_7.png","digital1_8.png","digital1_9.png"],
              padding: false,
              h_space: -1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STAND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_stand_current_text_img.setProperty(hmUI.prop.VISIBLE, false);

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 139,
              y: 317,
              font_array: ["digital1_0.png","digital1_1.png","digital1_2.png","digital1_3.png","digital1_4.png","digital1_5.png","digital1_6.png","digital1_7.png","digital1_8.png","digital1_9.png"],
              padding: false,
              h_space: -1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 222,
              am_y: 285,
              am_sc_path: 'am.png',
              am_en_path: 'am.png',
              pm_x: 222,
              pm_y: 285,
              pm_sc_path: 'pm.png',
              pm_en_path: 'pm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 197,
              hour_startY: 315,
              hour_array: ["digital1_0.png","digital1_1.png","digital1_2.png","digital1_3.png","digital1_4.png","digital1_5.png","digital1_6.png","digital1_7.png","digital1_8.png","digital1_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 249,
              minute_startY: 315,
              minute_array: ["digital1_0.png","digital1_1.png","digital1_2.png","digital1_3.png","digital1_4.png","digital1_5.png","digital1_6.png","digital1_7.png","digital1_8.png","digital1_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 233,
              y: 315,
              src: 'digital1_11.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 212,
              y: 175,
              src: 'bluetooth_off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 244,
              y: 175,
              src: 'alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 45,
              y: 142,
              week_en: ["day_0.png","day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png"],
              week_tc: ["day_0.png","day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png"],
              week_sc: ["day_0.png","day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 67,
              month_startY: 110,
              month_sc_array: ["month_0.png","month_1.png","month_2.png","month_3.png","month_4.png","month_5.png","month_6.png","month_7.png","month_8.png","month_9.png","month_10.png","month_11.png"],
              month_tc_array: ["month_0.png","month_1.png","month_2.png","month_3.png","month_4.png","month_5.png","month_6.png","month_7.png","month_8.png","month_9.png","month_10.png","month_11.png"],
              month_en_array: ["month_0.png","month_1.png","month_2.png","month_3.png","month_4.png","month_5.png","month_6.png","month_7.png","month_8.png","month_9.png","month_10.png","month_11.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 195,
              day_startY: 110,
              day_sc_array: ["digital1_aod_0.png","digital1_aod_1.png","digital1_aod_2.png","digital1_aod_3.png","digital1_aod_4.png","digital1_aod_5.png","digital1_aod_6.png","digital1_aod_7.png","digital1_aod_8.png","digital1_aod_9.png"],
              day_tc_array: ["digital1_aod_0.png","digital1_aod_1.png","digital1_aod_2.png","digital1_aod_3.png","digital1_aod_4.png","digital1_aod_5.png","digital1_aod_6.png","digital1_aod_7.png","digital1_aod_8.png","digital1_aod_9.png"],
              day_en_array: ["digital1_aod_0.png","digital1_aod_1.png","digital1_aod_2.png","digital1_aod_3.png","digital1_aod_4.png","digital1_aod_5.png","digital1_aod_6.png","digital1_aod_7.png","digital1_aod_8.png","digital1_aod_9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.RIGHT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hour0.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 15,
              hour_posY: 140,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'min0.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 21,
              minute_posY: 227,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // Start Analog secondhand (start with normal secondhand)
            normal_analog_clock_time_pointer_second_classic = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'sec0.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 8,
              second_posY: 221,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.IMG, {
               x: 0,
               y: 0,
               w: 480,
               h: 480,
               pos_x: 480 / 2 - 8,
               pos_y: 480 / 2 - 221,
               center_x: 240,
               center_y: 240,
               src: "sec0.png",
               angle: 0,
               show_level: hmUI.show_level.ONLY_NORMAL,
            });
            setSec();
            normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, false);
            // End Analog secondhand

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 110,
              y: 201,
              w: 84,
              h: 70,
              src: 'shortcut.png',
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 205,
              y: 144,
              w: 70,
              h: 70,
              src: 'shortcut.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 95,
              y: 122,
              w: 84,
              h: 70,
              src: 'shortcut.png',
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 265,
              y: 285,
              w: 100,
              h: 70,
              src: 'shortcut.png',
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_altimeter_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 120,
              y: 285,
              w: 100,
              h: 70,
              src: 'shortcut.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_temperature_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 265,
              y: 285,
              w: 100,
              h: 70,
              src: 'shortcut.png',
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_pai_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 221,
              y: 285,
              w: 43,
              h: 70,
              src: 'shortcut.png',
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_spo2_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 120,
              y: 285,
              w: 100,
              h: 70,
              src: 'shortcut.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_heart_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 279,
              y: 199,
              w: 100,
              h: 70,
              src: 'shortcut.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            //AOD
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'color0.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 277,
              y: 239,
              font_array: ["digital1_0.png","digital1_1.png","digital1_2.png","digital1_3.png","digital1_4.png","digital1_5.png","digital1_6.png","digital1_7.png","digital1_8.png","digital1_9.png"],
              padding: false,
              h_space: -1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 123,
              y: 239,
              font_array: ["digital1_0.png","digital1_1.png","digital1_2.png","digital1_3.png","digital1_4.png","digital1_5.png","digital1_6.png","digital1_7.png","digital1_8.png","digital1_9.png"],
              padding: false,
              h_space: -1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 212,
              y: 175,
              src: 'bluetooth_off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 244,
              y: 175,
              src: 'alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 45,
              y: 142,
              week_en: ["day_0.png","day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png"],
              week_tc: ["day_0.png","day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png"],
              week_sc: ["day_0.png","day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png"],
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 67,
              month_startY: 110,
              month_sc_array: ["month_0.png","month_1.png","month_2.png","month_3.png","month_4.png","month_5.png","month_6.png","month_7.png","month_8.png","month_9.png","month_10.png","month_11.png"],
              month_tc_array: ["month_0.png","month_1.png","month_2.png","month_3.png","month_4.png","month_5.png","month_6.png","month_7.png","month_8.png","month_9.png","month_10.png","month_11.png"],
              month_en_array: ["month_0.png","month_1.png","month_2.png","month_3.png","month_4.png","month_5.png","month_6.png","month_7.png","month_8.png","month_9.png","month_10.png","month_11.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 195,
              day_startY: 110,
              day_sc_array: ["digital1_aod_0.png","digital1_aod_1.png","digital1_aod_2.png","digital1_aod_3.png","digital1_aod_4.png","digital1_aod_5.png","digital1_aod_6.png","digital1_aod_7.png","digital1_aod_8.png","digital1_aod_9.png"],
              day_tc_array: ["digital1_aod_0.png","digital1_aod_1.png","digital1_aod_2.png","digital1_aod_3.png","digital1_aod_4.png","digital1_aod_5.png","digital1_aod_6.png","digital1_aod_7.png","digital1_aod_8.png","digital1_aod_9.png"],
              day_en_array: ["digital1_aod_0.png","digital1_aod_1.png","digital1_aod_2.png","digital1_aod_3.png","digital1_aod_4.png","digital1_aod_5.png","digital1_aod_6.png","digital1_aod_7.png","digital1_aod_8.png","digital1_aod_9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.RIGHT,
              day_is_character: false,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hour0.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 15,
              hour_posY: 140,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'min0.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 21,
              minute_posY: 227,
              minute_cover_path: 'timetop.png',
              minute_cover_x: 218,
              minute_cover_y: 221,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            // Change color background shortcut start
            btncolor = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 207,
              y: 0,
              text: '',
              w: 80,
              h: 105,
              normal_src: 'shortcut.png',
              press_src: 'shortcut.png',
              click_func: () => {
               click_Color();
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btncolor.setProperty(hmUI.prop.VISIBLE, true);
            //Change color background shortcut end

            // Change background shortcut start
            btnbackground = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 207,
              y: 382,
              text: '',
              w: 80,
              h: 98,
              normal_src: 'shortcut.png',
              press_src: 'shortcut.png',
              click_func: () => {
               click_Background();
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btnbackground.setProperty(hmUI.prop.VISIBLE, true);
            // Change background shortcut end

            // Bezel on-off shortcut start
            btnbezel = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 0,
              y: 200,
              text: '',
              w: 80,
              h: 80,
              normal_src: 'shortcut.png',
              press_src: 'shortcut.png',
              click_func: () => {
               click_Bezel();
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btnbezel.setProperty(hmUI.prop.VISIBLE, true);
            //Bezel on-off shortcut end

            // Sunmoon shortcut start
            btnsunmoon = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 385,
              y: 105,
              text: '',
              w: 80,
              h: 80,
              normal_src: 'shortcut.png',
              press_src: 'shortcut.png',
              click_func: () => {
               click_Sunmoon();
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btnsunmoon.setProperty(hmUI.prop.VISIBLE, true);
            // Sunmoon shortcut end

            // Changehands shortcut start
            btnchangehands = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 315,
              y: 24,
              text: '',
              w: 80,
              h: 80,
              normal_src: 'shortcut.png',
              press_src: 'shortcut.png',
              click_func: () => {
               click_Changehands();
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btnchangehands.setProperty(hmUI.prop.VISIBLE, true);
            // Changehands shortcut end

            // Multiinfo shortcut start
            btnmultiinfo = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 400,
              y: 200,
              text: '',
              w: 80,
              h: 80,
              normal_src: 'shortcut.png',
              press_src: 'shortcut.png',
              click_func: () => {
               click_Multiinfo();
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btnmultiinfo.setProperty(hmUI.prop.VISIBLE, true);
            // Multiinfo shortcut end

            // Secondhand shortcut start
            btnsecondhand = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 385,
              y: 305,
              text: '',
              w: 80,
              h: 80,
              normal_src: 'shortcut.png',
              press_src: 'shortcut.png',
              click_func: () => {
               click_Secondhand();
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btnsecondhand.setProperty(hmUI.prop.VISIBLE, false);
            // Secondhand shortcut end

            /**
            * SMOOTH SECONDS SCRIPTS widgetDelegate
            */
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {

               if(lsecondhand) {
                  startSecHandTimer();
               }

            }),
            pause_call: (function () {

               if(lsecondhand) {
                  stopSecAnim();
               }

            }),
           });
           /** END SMOOTH SECOND SCRIPTS widgetDelegate */

            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
            stopSecAnim();
          },

          onDestroy() {
            console.log('index page.js on destroy invoke')
            stopSecAnim();
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  
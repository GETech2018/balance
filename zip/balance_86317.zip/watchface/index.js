﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
              
      
        const { width: DEVICE_WIDTH, height: DEVICE_HEIGHT} = hmSetting.getDeviceInfo();
        const radius = DEVICE_WIDTH / 2, centerX = DEVICE_WIDTH / 2, centerY = DEVICE_HEIGHT / 2
      
        const curTime = hmSensor.createSensor(hmSensor.id.TIME);
        const weather = hmSensor.createSensor(hmSensor.id.WEATHER);
      
        let weatherImg, tempText, cityNameText, tempMinText, tempMaxText, tempFeelsText, descriptionText
        let weatherProvider
        
        const vibrator = hmSensor.createSensor(hmSensor.id.VIBRATE);
        let stopVibro_Timer = null;
    
        function vibro(mode = 25, stopDelay = 30) {
            vibrator.stop();
            vibrator.scene = mode;
            vibrator.start();
            stopVibro_Timer = setTimeout(() => {
              stopVibro();
            }, stopDelay);
        }		
    
        function stopVibro(){
            vibrator.stop();
            if (stopVibro_Timer) clearTimeout(stopVibro_Timer);
        } 
 

        class WeatherProvider {
          constructor(props = {}) {
            this.props = {
              night_icons: [],											// индексы иконок для замены день-ночь
              index: hmFS.SysProGetInt('WeatherProviderIndex') ?? 0,		// текущий индекс провайдера (сохраняется и считывается из памяти)
              show_toast: true,											// показывать всплывающее сообщение при переключении провайдера
              temp_widget: null,											// виджет TEXT для отображения температуры
              temp_max_widget: null,										// виджет TEXT для отображения максимальной температуры
              temp_min_widget: null,										// виджет TEXT для отображения минимальной температуры
              temp_feels_widget: null,									// виджет TEXT для отображения ощущаемой температуры
              description_widget: null,									// виджет TEXT для отображения текстового описания текущей погоды
              cityName_widget: null,										// виджет TEXT для отображения названия города
              icon_widget: null,											// виджет IMG для отображения значка погоды
              time_sensor: null,											// сенсор времени, если не задан, то создается новый
              weather_sensor: null,										// сенсор погоды, если не задан, то создается новый
              file_name: 'weather.json',									// имя файла с погодными данными
              auto_update: true,											// автоматическое обновление погоды (нет необходимости добавлять weatherProvider.update() в event.MINUTEEND и WIDGET_DELEGATE)
              lang: hmSetting.getLanguage() == 4 ? 0 : 1,					// языка устройства	(Русский = 0 / Английский = 1)
              ...props,
            };
            this.providers = [
              {name: ['Zepp', 'Zepp'], appId: null},							// 0
              {name: ['Погодный сервис', 'Weather service'], appId: 1065824},	// 1 
              //{name: ['RuWeather', 'RWeather'], appId: 1066654},				// 2
            ]

            this.description = [
                ['Облачно', 'Временами дождь', 'Временами снег', 'Ясно', 'Пасмурно', 'Слабый дождь', 'Слабый снег', 'Умеренный дождь', 'Умеренный снег', 'Сильный снегопад', 'Сильный дождь', 'Песчаная буря', 'Мокрый снег', 'Туман', 'Дымка', 'Дождь с грозой', 'Метель', 'Пыльно', 'Ливень', 'Дождь с градом', 'Сильный дождь с градом', 'Сильный дождь', 'Пыльная буря', 'Сильная песчаная буря', 'Сильный дождь', 'Обновите погоду', 'Облачно ночью', 'Дождливо ночью', 'Ясно ночью'],
                ['Cloudy', 'Showers', 'Snow Showers', 'Sunny', 'Overcast', 'Light Rain', 'Light Snow', 'Moderate Rain', 'Moderate Snow', 'Heavy Snow', 'Heavy Rain', 'Sandstorm', 'Rain and Snow', 'Fog', 'Hazy', 'T-Storms', 'Snowstorm', 'Floating dust', 'Very Heavy Rainstorm', 'Rain and Hail', 'T-Storms and Hail', 'Heavy Rainstorm', 'Dust', 'Heavy sand storm', 'Rainstorm', 'Unknown', 'Cloudy Nighttime', 'Showers Nighttime', 'Sunny Nighttime'],
              ]      
              
            this.last = {
                weatherIcon: 25,
                weatherDescription:  'Нет данных',
                temperature: '--',
                temperatureFeels: '--',
                temperatureMax: '--',
                temperatureMin: '--',
                cityName: '--',
                modTime: null,
            }      
            
            if (!this.props.time_sensor) this.props.time_sensor = hmSensor.createSensor(hmSensor.id.TIME);
            if (!this.props.weather_sensor) this.props.weather_sensor = hmSensor.createSensor(hmSensor.id.WEATHER);
            if (isFinite(props.index)) hmFS.SysProSetInt('WeatherProviderIndex', props.index);
            if (this.props.auto_update) this.createHandlers();
        } 
        
        
        createHandlers() {
          this.props.time_sensor.addEventListener(this.props.time_sensor.event.MINUTEEND, () => this.update());

          this.widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
            resume_call: ( () => this.update() )
          })
        }   
        
        arrayBufferToCyrillic(buffer) {
          let result = '';
          const bytes = new Uint8Array(buffer);

          let i = 0;
          while (i < bytes.length) {
              let byte1 = bytes[i++];
          
              if (byte1 < 0x80) {								// Обработка 1-байтовых символов (ASCII)
                result += String.fromCharCode(byte1);
              } else if (byte1 >= 0xC0 && byte1 < 0xE0) {		// Обработка 2-байтовых символов (UTF-8 кодировка для кириллицы)
                let byte2 = bytes[i++];
                let charCode = ((byte1 & 0x1F) << 6) | (byte2 & 0x3F);
                result += String.fromCharCode(charCode);
              } else if (byte1 >= 0xE0 && byte1 < 0xF0) {		// Обработка 3-байтовых символов (например, для UTF-8)
                let byte2 = bytes[i++];
                let byte3 = bytes[i++];
                let charCode = ((byte1 & 0x0F) << 12) | ((byte2 & 0x3F) << 6) | (byte3 & 0x3F);
                result += String.fromCharCode(charCode);
              }
          }

          return result
        } 
        
        readFile(app_id) {
          if (!app_id) return null				
          let str_result = "";
          try {
              const [fs_stat, err] = hmFS.stat(this.props.file_name, {
                  appid: app_id,
              });
              if (err == 0) {
                  const fh = hmFS.open(this.props.file_name, hmFS.O_RDONLY, {
                  appid: app_id,
                  });

                  const len = fs_stat.size;
                  let array_buffer = new ArrayBuffer(len);
                  hmFS.read(fh, array_buffer, 0, len);
                  hmFS.close(fh);
                  str_result = this.arrayBufferToCyrillic(array_buffer);

                  return str_result;
              } else {
                  console.log("err:", err);
              }
          } catch (error) {
          console.log("error:", error);
          console.log("FAIL: No access to hmFS.");
          }
          return null;
        }    
        
        getFileModTime(app_id) {
          if (!app_id) return null
          try {
              const [fs_stat, err] = hmFS.stat(this.props.file_name, {
                  appid: app_id,
              });
          
              if (err == 0) {
                  return fs_stat.mtime
              } else {
                  console.log("ModTime err:", err);
              }
          } catch (error) {
            console.log("ModTime error:", error);
            console.log("FAIL: No access to hmFS.");
          }
            return null
        }  
        
        isDayNow() {
          const sunData = this.props.weather_sensor.getForecastWeather().tideData;
          let sunriseMins = 8 * 60;			// время восхода
          let sunsetMins = 20 * 60;			// и заката по умолчанию

          if (sunData.count > 0){
              const today = sunData.data[0];
              sunriseMins = today.sunrise.hour * 60 + today.sunrise.minute;
              sunsetMins = today.sunset.hour * 60 + today.sunset.minute;
          }

          const curMins = curTime.hour * 60 + curTime.minute;
          const nowIsDay = (curMins >= sunriseMins) && (curMins < sunsetMins);

          return nowIsDay
        }  
        
        getZeppIconIndex(index, app_id = null) {
                        
          if (!app_id)  return index;			//	если нет app_id, то не меняем индекс иконки

          let newIndex = 25;
          
          if (app_id == 1065824) {					// WeatherService
              switch(index) {
              case 1:
                      newIndex = 3;
                  break;
              case 2:
                      newIndex = 0;
                  break;
              case 3:
              case 4:
                      newIndex = 4;
                  break;
              case 5:
                      newIndex = 1;
                  break;
              case 6:
                      newIndex = 5;
                  break;
              case 7:
                      newIndex = 10;
                  break;
              case 8:
                      newIndex = 15;
                  break;
              case 9:
                      newIndex = 6;
                  break;
              case 10:
                      newIndex = 8;
                  break;
              case 11:
                      newIndex = 9;
                  break;
              case 12:
                      newIndex = 12;
                  break;
              case 13:
                      newIndex = 13;
                  break;
              case 14:
                      newIndex = 17;
                  break;
              default:
                      newIndex = 25;
                  break;
              }
          } else if (app_id == 1066654) {					// 
              newIndex = index - 1;
          }

          return newIndex
        }  
       
        tempWithSign(val){
          val = parseFloat(val);
          if (!isFinite(val)) return '--'		// если на входе не число - возвращаем прочерки
          val = Math.round(val);
          if (val > 0) val = '+' + val;
          val += '°';
          
          return val
        }    
        
        getZeppWeatherData() {
          const iconIndex = this.props.weather_sensor.curAirIconIndex ?? 25;
          const data = {
              weatherIcon: iconIndex,
              weatherDescription:  this.description[this.props.lang][iconIndex],
              temperature: this.props.weather_sensor.current ?? '--',
              temperatureFeels: '--',
              temperatureMax: this.props.weather_sensor.high ?? '--',
              temperatureMin: this.props.weather_sensor.low ?? '--',
              cityName: this.props.weather_sensor.getForecastWeather().cityName ?? '--',
          }

          return data
        }  
        
        getAppWeatherData(app_id) {
          const data = {
              weatherIcon: 25,
              weatherDescription:  'Нет данных',
              temperature: '--',
              temperatureFeels: '--',
              temperatureMax: '--',
              temperatureMin: '--',
              cityName: '--',
          }
          
          let weather_str = this.readFile(app_id);
          let weatherJson = JSON.parse(weather_str);

          if (weatherJson) {
              if (isFinite(weatherJson.weatherIcon)) {		// считываем индекс иконки погоды и сразу переводим в нумерацию Zepp
                  data.weatherIcon = this.getZeppIconIndex(parseInt(weatherJson.weatherIcon), app_id);
              }

              if (weatherJson?.weatherDescriptionExtended?.length) {
                  data.weatherDescription = weatherJson.weatherDescriptionExtended;
                  data.weatherDescription = data.weatherDescription.replace(data.weatherDescription[0], data.weatherDescription[0].toUpperCase());
              } else data.weatherDescription = this.description[data.weatherIcon];

              if (isFinite(weatherJson.temperature)) {
                  data.temperature = parseFloat(weatherJson.temperature);
                  data.temperature = Math.round(data.temperature);
              }
              
              if (isFinite(weatherJson.temperatureFeels)){
                  data.temperatureFeels = parseFloat(weatherJson.temperatureFeels);
                  data.temperatureFeels = Math.round(data.temperatureFeels);
              }
                  
              if (isFinite(weatherJson.temperatureMax)){
                  data.temperatureMax = parseFloat(weatherJson.temperatureMax);
                  data.temperatureMax = Math.round(data.temperatureMax);
              }
                  
              if (isFinite(weatherJson.temperatureMin)){
                  data.temperatureMin = parseFloat(weatherJson.temperatureMin);
                  data.temperatureMin = Math.round(data.temperatureMin);
              }
              
              if (weatherJson.city) {
                  data.cityName = weatherJson.city;
              }
          }
          
          return data
        }  
        
        getWeatherData(app_id = null) {
          if (!app_id) return this.getZeppWeatherData()		// если нет app_id, то получаем данные от Zepp
          else return this.getAppWeatherData(app_id);			// иначе читаем данные из файла данных приложения
        }  
        
        update() {
          let curIcon = parseInt(this.last.weatherIcon);				// текущий индекс значка погоды без учета времени суток (т.е. число без "n")

          const modTime = this.getFileModTime(this.providers[this.props.index].appId);		// время изменеия файла с данными
          
          if (!modTime || this.last.modTime != modTime){										// если не получено время изменеия или оно отличается от последнего времени изменеия
              const newData = this.getWeatherData(this.providers[this.props.index].appId);	// тогда читаем новые данные из файла
              this.last.modTime = modTime;

              let val = this.tempWithSign(newData.temperature);
              if (val != this.last.temperature){
                  this.last.temperature = val;
                  if (this.props.temp_widget) this.props.temp_widget.setProperty(hmUI.prop.TEXT, val);
              }

              val = this.tempWithSign(newData.temperatureMax);
              if (val != this.last.temperatureMax){
                  this.last.temperatureMax = val;
                  if (this.props.temp_max_widget) this.props.temp_max_widget.setProperty(hmUI.prop.TEXT, val);
              }

              val = this.tempWithSign(newData.temperatureMin);
              if (val != this.last.temperatureMin){
                  this.last.temperatureMin = val;
                  if (this.props.temp_min_widget) this.props.temp_min_widget.setProperty(hmUI.prop.TEXT, val);
              }

              val = this.tempWithSign(newData.temperatureFeels);
              if (val != this.last.temperatureFeels){
                  this.last.temperatureFeels = val;
                  if (this.props.temp_feels_widget) this.props.temp_feels_widget.setProperty(hmUI.prop.TEXT, val);
              }

              val = newData.cityName;
              if (val != this.last.cityName){
                  this.last.cityName = val;
                  if (this.props.cityName_widget) this.props.cityName_widget.setProperty(hmUI.prop.TEXT, val);
              }

              val = newData.weatherDescription;
              if (val != this.last.weatherDescription){
                  this.last.weatherDescription = val;
                  if (this.props.description_widget) this.props.description_widget.setProperty(hmUI.prop.TEXT, val);
              }

              
              curIcon = newData.weatherIcon;						// получаем текущий индекс значка погоды
          }

          if (this.props.night_icons.includes(curIcon) && !this.isDayNow()){		// если он в списке ночных иконок и сейчас "ночь", то добавляем суффикс 'n'
              curIcon += 'n';
          }

          if (curIcon != this.last.weatherIcon){
              this.last.weatherIcon = curIcon;
              if (this.props.icon_widget) this.props.icon_widget.setProperty(hmUI.prop.SRC, `w_${curIcon}.png`);
          }
        } 
        
        next(show_toast = this.props.show_toast) {
          const v = (this.props.index + 1) % this.providers.length;
          this.provider = v;
          if (show_toast) hmUI.showToast({text: this.name});
        }        
        
        prev(show_toast = this.props.show_toast) {
          const v = (this.props.index - 1 + this.providers.length) % this.providers.length;
          this.provider = v;
          if (show_toast) hmUI.showToast({text: this.name});
        }   
        
        toggle(dir, show_toast = this.props.show_toast) {
          if (dir > 0) this.next(show_toast)
          else this.prev(show_toast);
        }   
        
        set provider(v) {
          this.props.index = v;
          hmFS.SysProSetInt('WeatherProviderIndex', v);
          this.update();
        }   
        
        get index() {
          return this.props.index
        }     
      
        
        get name() {
            return this.providers[this.props.index].name[this.props.lang]
        }    
        
        get cityName() {
          return this.last.cityName
        }     
        
        get temperature() {
          return this.last.temperature
        }   
        
        get temperatureMax() {
          return this.last.temperatureMax
        }

        
        get temperatureMin() {
            return this.last.temperatureMin
        }        

          
        get weatherDescription() {
            return this.last.weatherDescription
        }      
        
       delete() {
          this.providers = null;
          this.props = null;
          this.last = null;
          this.description = null;
          if (this.widgetDelegate) {
              hmUI.deleteWidget(this.widgetDelegate);
              this.widgetDelegate = null;
          }
       }

      } 
      // start user_functions.js
const {
  width: D_W,
  height: D_H
} = hmSetting.getDeviceInfo();  

        //day
        function isLeapYear(year) {
          return (year % 4 === 0 && year % 100 !== 0) || (year % 400 === 0);
        }

        function getDayOfYear(year, month, day) {
          const monthDays = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334];
          let days = monthDays[month - 1] + day;
          if (month > 2 && isLeapYear(year)) {
            days += 1;
          }
          return days;
        }
        //end of ignored block

        //dynamic modify start
        let btn_bezel = ''
        let bezel_num = 1
        let bezel_all = 6  
        
        let normal_background_bg_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_image_img = ''
        let normal_time_hour_text_font = ''
        let normal_timerTimeUpdate = undefined;
        let normal_time_minute_text_font = ''
        let normal_digital_clock_img_time_second_D = ''
        let normal_digital_clock_img_time_second_N = ''
        let normal_moon_icon_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_day_now = ''
        let normal_alarm_clock_current_text_font = ''
        let normal_system_clock_img = ''
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_text_font = ''
        let normal_sun_icon_img = ''
        let normal_sun_high_text_font = ''
        let normal_sun_low_text_font = ''
        let normal_step_icon_img = ''
        let normal_step_linear_scale = ''
        let normal_step_current_text_font = ''
        let normal_month_name_font = ''
        let normal_Month_Array = ['Январь', 'Февраль', 'Март', 'Апрель', 'Май', 'Июнь', 'Июль', 'Август', 'Сентябрь', 'Октябрь', 'Ноябрь', 'Декабрь', ];
        let normal_battery_current_text_font = ''
        let normal_analog_clock_pro_second_pointer_img = ''
        let normal_timerUpdateSec = undefined;
        let idle_background_bg_img = ''
        let idle_date_img_date_week_img = ''
        let idle_image_img = ''
        let idle_time_hour_text_font = ''
        let idle_timerTimeUpdate = undefined;
        let idle_time_minute_text_font = ''
        let idle_day_text_font = ''
        let idle_alarm_clock_current_text_font = ''
        let idle_city_name_text = ''
        let idle_weather_image_progress_img_level = ''
        let idle_temperature_high_text_font = ''
        let idle_temperature_low_text_font = ''
        let idle_temperature_current_text_font = ''
        let idle_month_name_font = ''
        let idle_Month_Array = ['Январь', 'Февраль', 'Март', 'Апрель', 'Май', 'Июнь', 'Июль', 'Август', 'Сентябрь', 'Октябрь', 'Ноябрь', 'Декабрь', ];
        let idle_battery_icon_img = ''
        let idle_battery_current_text_font = ''
        let normal_step_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_battery_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''        
        let timeSensor = '';
        //let weatherSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
            function click_Bezel() {
              if(bezel_num>=bezel_all) {bezel_num=1;}
              else { bezel_num=bezel_num+1;}
              hmUI.showToast({text: "Цвет " + parseInt(bezel_num) });
                normal_background_bg_img.setProperty(hmUI.prop.SRC, "osn_" + parseInt(bezel_num) + ".png");
                normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.SRC, "Sekk_" + parseInt(bezel_num) + ".png");
            }                    
                
            // FontName: Netflix.ttf; FontSize: 128
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 1404,
              h: 169,
              text_size: 128,
              char_space: 3,
              line_space: 0,
              font: 'fonts/Netflix.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: Netflix.ttf; FontSize: 27
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 337,
              h: 34,
              text_size: 27,
              char_space: 2,
              line_space: 0,
              font: 'fonts/Netflix.ttf',
              color: 0xFF000000,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: Netflix.ttf; FontSize: 35
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 390,
              h: 45,
              text_size: 35,
              char_space: 1,
              line_space: 0,
              font: 'fonts/Netflix.ttf',
              color: 0xFF000000,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: Netflix.ttf; FontSize: 26; Cache: full
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 31,
              h: 31,
              text_size: 26,
              char_space: 1,
              line_space: 0,
              font: 'fonts/Netflix.ttf',
              color: 0xFF000000,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.NONE,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: Netflix.ttf; FontSize: 30
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 339,
              h: 39,
              text_size: 30,
              char_space: 1,
              line_space: 0,
              font: 'fonts/Netflix.ttf',
              color: 0xFF676767,
              align_h: hmUI.align.RIGHT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: Netflix.ttf; FontSize: 30; Cache: full
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 36,
              h: 36,
              text_size: 30,
              char_space: 1,
              line_space: 0,
              font: 'fonts/Netflix.ttf',
              color: 0xFF676767,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.NONE,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: Netflix.ttf; FontSize: 23; Cache: full
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 27,
              h: 27,
              text_size: 23,
              char_space: 1,
              line_space: 0,
              font: 'fonts/Netflix.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.NONE,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: Netflix.ttf; FontSize: 21
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 241,
              h: 27,
              text_size: 21,
              char_space: 1,
              line_space: 0,
              font: 'fonts/Netflix.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: Netflix.ttf; FontSize: 33
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 367,
              h: 43,
              text_size: 33,
              char_space: 1,
              line_space: 0,
              font: 'fonts/Netflix.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'osn_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 67,
              y: 155,
              week_en: ["D_0.png","D_1.png","D_2.png","D_3.png","D_4.png","D_5.png","D_6.png"],
              week_tc: ["D_0.png","D_1.png","D_2.png","D_3.png","D_4.png","D_5.png","D_6.png"],
              week_sc: ["D_0.png","D_1.png","D_2.png","D_3.png","D_4.png","D_5.png","D_6.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 111,
              day_startY: 76,
              day_sc_array: ["day_0.png","day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png","day_8.png","day_9.png"],
              day_tc_array: ["day_0.png","day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png","day_8.png","day_9.png"],
              day_en_array: ["day_0.png","day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png","day_8.png","day_9.png"],
              day_zero: 1,
              day_space: -5,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'zapl_up.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);            
            let screenType = hmSetting.getScreenType();
            normal_time_hour_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 8,
              y: 190,
              w: 200,
              h: 150,
              text_size: 128,
              char_space: 3,
              font: 'fonts/Netflix.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_time_minute_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 140,
              y: 190,
              w: 200,
              h: 150,
              text_size: 128,
              char_space: 3,
              font: 'fonts/Netflix.ttf',
              color: 0xFF676767,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_second_D = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              second_startX: 310,
              second_startY: 202,
              second_array: ["sek_0.png","sek_1.png","sek_2.png","sek_3.png","sek_4.png","sek_5.png","sek_6.png","sek_7.png","sek_8.png","sek_9.png"],
              second_zero: 1,
              second_space: -6,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_second_N = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              second_startX: 310,
              second_startY: 202,
              second_array: ["sekD_0.png","sekD_1.png","sekD_2.png","sekD_3.png","sekD_4.png","sekD_5.png","sekD_6.png","sekD_7.png","sekD_8.png","sekD_9.png"],
              second_zero: 1,
              second_space: -6,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });            

            if (screenType != hmSetting.screen_type.AOD) {
              normal_step_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // normal_step_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 336,
              // start_y: 351,
              // color: 0xFF000000,
              // lenght: 55,
              // line_width: 38,
              // line_cap: Flat,
              // vertical: False,
              // mirror: False,
              // inversion: True,
              // alpha: 255,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });            

            normal_moon_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'zapl_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 283,
              y: 400,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_day_now = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 161,
              y: 59,
              w: 100,
              h: 30,
              text_size: 25,
              char_space: 0,
              font: 'fonts/Netflix.ttf',
              color: 0xFF676767,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.RIGHT,
              text: '---',  // Начальный текст, будет обновлён
              show_level: hmUI.show_level.ONLY_NORMAL,
            });            

            normal_alarm_clock_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 283,
              y: 330,
              w: 150,
              h: 30,
              text_size: 27,
              char_space: 2,
              font: 'fonts/Netflix.ttf',
              color: 0xFF000000,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              padding: true,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 309,
              y: 305,
              src: 'alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 100,
              y: 329,
              src: 'pulse.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 41,
              y: 360,
              w: 150,
              h: 50,
              text_size: 35,
              char_space: 1,
              font: 'fonts/Netflix.ttf',
              color: 0xFF000000,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const weatherInfo = hmUI.createWidget(hmUI.widget.GROUP, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
            });
            
            weatherImg = weatherInfo.createWidget(hmUI.widget.IMG, {
                x: 329,
                y: 66,
                w: 80,
                h: 80,
                src: 'w_25.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
            });   
            
            tempText = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 285,
              y: 127,
              w: 150,
              h: 50,
              text_size: 35,
              char_space: 1,
              font: 'fonts/Netflix.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              unit_type: 1,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });     
            
            tempMinText = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 284,
              y: 131,
              w: 150,
              h: 40,
              text_size: 30,
              char_space: 1,
              font: 'fonts/Netflix.ttf',
              color: 0xFF676767,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              unit_type: 1,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });    
            
            tempMaxText = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 113,
              y: 131,
              w: 150,
              h: 40,
              text_size: 30,
              char_space: 1,
              font: 'fonts/Netflix.ttf',
              color: 0xFF676767,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.RIGHT,
              unit_type: 1,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });    
            
            descriptionText = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 72,
              y: 298,
              w: 224,
              h: 50,
              text_size: 26,
              char_space: 1,
              font: 'fonts/Netflix.ttf',
              color: 0xFF000000,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });            

            // экземпляр класса
            weatherProvider = new WeatherProvider({
                night_icons: [0, 1, 2, 3, 14],
                show_toast: false,
                temp_widget: tempText,
                temp_max_widget: tempMaxText,
                temp_min_widget: tempMinText,
                temp_feels_widget: tempFeelsText,
                description_widget: descriptionText,
                cityName_widget: cityNameText,
                icon_widget: weatherImg,
                time_sensor: curTime,
                weather_sensor: weather,
            });             

            normal_sun_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 176,
              y: 325,
              src: 'vosh.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 118,
              y: 360,
              w: 150,
              h: 50,
              text_size: 35,
              char_space: 1,
              font: 'fonts/Netflix.ttf',
              color: 0xFF000000,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 118,
              y: 360,
              w: 150,
              h: 50,
              text_size: 35,
              char_space: 1,
              font: 'fonts/Netflix.ttf',
              color: 0xFF000000,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 176,
              y: 329,
              src: 'zakat.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_step_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 214,
              y: 360,
              w: 150,
              h: 50,
              text_size: 35,
              char_space: 1,
              font: 'fonts/Netflix.ttf',
              color: 0xFF000000,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function() {
              time_update(true);
            });

            normal_month_name_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 171,
              y: 97,
              w: 200,
              h: 40,
              text_size: 30,
              char_space: 1,
              font: 'fonts/Netflix.ttf',
              color: 0xFF676767,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // unit_string: Январь, Февраль, Март, Апрель, Май, Июнь, Июль, Август, Сентябрь, Октябрь, Ноябрь, Декабрь,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 169,
              y: 427,
              w: 150,
              h: 30,
              text_size: 30,
              char_space: 1,
              font: 'fonts/Netflix.ttf',
              color: 0xFF000000,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              unit_type: 1,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const deviceInfo = hmSetting.getDeviceInfo();            
            // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'Sekk_1.png',
              // center_x: 240,
              // center_y: 240,
              // x: 2,
              // y: 232,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 2,
              pos_y: 240 - 232,
              center_x: 240,
              center_y: 240,
              src: 'Sekk_1.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'osn_AOD.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });            

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 67,
              y: 155,
              week_en: ["D_0.png","D_1.png","D_2.png","D_3.png","D_4.png","D_5.png","D_6.png"],
              week_tc: ["D_0.png","D_1.png","D_2.png","D_3.png","D_4.png","D_5.png","D_6.png"],
              week_sc: ["D_0.png","D_1.png","D_2.png","D_3.png","D_4.png","D_5.png","D_6.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'zapl_AOD.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_time_hour_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 8,
              y: 190,
              w: 200,
              h: 150,
              text_size: 128,
              char_space: 3,
              font: 'fonts/Netflix.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // padding: true,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_time_minute_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 140,
              y: 190,
              w: 200,
              h: 150,
              text_size: 128,
              char_space: 3,
              font: 'fonts/Netflix.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // padding: true,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_day_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 74,
              y: 295,
              w: 150,
              h: 40,
              text_size: 30,
              char_space: 2,
              font: 'fonts/Netflix.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_alarm_clock_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 186,
              y: 295,
              w: 150,
              h: 40,
              text_size: 30,
              char_space: 2,
              font: 'fonts/Netflix.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              padding: true,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

            idle_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 304,
              y: 272,
              w: 106,
              h: 50,
              text_size: 23,
              char_space: 1,
              font: 'fonts/Netflix.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 301,
              y: 206,
              image_array: ["w_0.png","w_1.png","w_2.png","w_3.png","w_4.png","w_5.png","w_6.png","w_7.png","w_8.png","w_9.png","w_10.png","w_11.png","w_12.png","w_13.png","w_14.png","w_15.png","w_16.png","w_17.png","w_18.png","w_19.png","w_20.png","w_21.png","w_22.png","w_23.png","w_24.png","w_25.png","w_26.png","w_27.png","w_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_high_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 337,
              y: 201,
              w: 100,
              h: 40,
              text_size: 21,
              char_space: 1,
              font: 'fonts/Netflix.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              unit_type: 1,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_low_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 337,
              y: 253,
              w: 100,
              h: 40,
              text_size: 21,
              char_space: 1,
              font: 'fonts/Netflix.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              unit_type: 1,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 311,
              y: 222,
              w: 150,
              h: 50,
              text_size: 33,
              char_space: 1,
              font: 'fonts/Netflix.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              unit_type: 1,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_month_name_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 114,
              y: 295,
              w: 200,
              h: 40,
              text_size: 30,
              char_space: 1,
              font: 'fonts/Netflix.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              // unit_string: Январь, Февраль, Март, Апрель, Май, Июнь, Июль, Август, Сентябрь, Октябрь, Ноябрь, Декабрь,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 326,
              y: 298,
              src: 'batt.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 354,
              y: 295,
              w: 150,
              h: 30,
              text_size: 30,
              char_space: 1,
              font: 'fonts/Netflix.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              unit_type: 1,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 254,
              y: 337,
              w: 70,
              h: 50,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 83,
              y: 336,
              w: 70,
              h: 50,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 215,
              y: 403,
              w: 50,
              h: 70,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 161,
              y: 336,
              w: 70,
              h: 50,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 207,
              y: 206,
              w: 70,
              h: 70,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 326,
              y: 221,
              w: 60,
              h: 60,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 308,
              y: 295,
              w: 100,
              h: 40,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 273,
              y: 391,
              w: 50,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'clean.png',
              normal_src: 'clean.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'FlashLightScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 129,
              y: 93,
              w: 50,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'clean.png',
              normal_src: 'clean.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 73,
              y: 206,
              w: 70,
              h: 70,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'clean.png',
              normal_src: 'clean.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'SportListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 338,
              y: 122,
              w: 40,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'clean.png',
              normal_src: 'clean.png',
              click_func: (button_widget) => {
                hmApp.startApp({ appid: 1065824, url: 'page/index', params: { from_wf: true} });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button   
            
            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 335,
              y: 66,
              w: 40,
              h: 40,
              text: '',
              text_size: 25,
              color: 0xFFFF8C00,
              press_src: 'clean.png',
              normal_src: 'clean.png',
              click_func: () => {                
                weatherProvider.prev(true);                
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });             

            btn_bezel = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 163,
              y: 390,
              text: '',
              w: 50,
              h: 50,
              normal_src: 'clean.png',
              press_src: 'clean.png',
              click_func: () => {
               click_Bezel();
               
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btn_bezel.setProperty(hmUI.prop.VISIBLE, true);              

            //#region time_update
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              console.log('hour font');
              if (updateHour) {
                let normal_hourStr = format_hour.toString();
                normal_hourStr = normal_hourStr.padStart(2, '0');
                normal_time_hour_text_font.setProperty(hmUI.prop.TEXT, normal_hourStr );
              };

              console.log('minute font');
              if (updateMinute) {
                let normal_minuteStr = minute.toString();
                normal_minuteStr = normal_minuteStr.padStart(2, '0');
                normal_time_minute_text_font.setProperty(hmUI.prop.TEXT, normal_minuteStr );
              };

              console.log('month font');
              if (updateHour) {
                let normal_Month_Str = normal_Month_Array[timeSensor.month-1];
                normal_month_name_font.setProperty(hmUI.prop.TEXT, normal_Month_Str );
              };

              // Second Pointer
              let normal_fullAngle_second = 360;
              let normal_angle_second = 0 + normal_fullAngle_second*second/60;
              if (normal_analog_clock_pro_second_pointer_img) normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_second);

              if (updateHour) {
                let dayOfYear = getDayOfYear(timeSensor.year, timeSensor.month, timeSensor.day);
                let dayStr = dayOfYear.toString().padStart(3, '0');
                normal_day_now.setProperty(hmUI.prop.TEXT, dayStr);
              }              

              console.log('hour font');
              if (updateHour) {
                let idle_hourStr = format_hour.toString();
                idle_hourStr = idle_hourStr.padStart(2, '0');
                idle_time_hour_text_font.setProperty(hmUI.prop.TEXT, idle_hourStr );
              };

              console.log('minute font');
              if (updateMinute) {
                let idle_minuteStr = minute.toString();
                idle_minuteStr = idle_minuteStr.padStart(2, '0');
                idle_time_minute_text_font.setProperty(hmUI.prop.TEXT, idle_minuteStr );
              };

              console.log('day font');
              if (updateHour) {
                let idle_dayStr = timeSensor.day.toString();
                idle_day_text_font.setProperty(hmUI.prop.TEXT, idle_dayStr );
              };

              console.log('month font');
              if (updateHour) {
                let idle_Month_Str = idle_Month_Array[timeSensor.month-1];
                idle_month_name_font.setProperty(hmUI.prop.TEXT, idle_Month_Str );
              };

              //const weather = hmSensor.createSensor(hmSensor.id.WEATHER);
              const weatherData = weatherSensor.getForecastWeather();
              const tide = weatherData.tideData.data[0];
              let sunriseMinutes = tide.sunrise.hour * 60 + tide.sunrise.minute;
              let sunsetMinutes = tide.sunset.hour * 60 + tide.sunset.minute;
              let currentMinutes = timeSensor.hour * 60 + timeSensor.minute;
              let isDay = currentMinutes >= sunriseMinutes && currentMinutes < sunsetMinutes;

              if (isDay) {
                
                normal_moon_icon_img.setProperty(hmUI.prop.SRC, 'zapl_1.png');
                normal_digital_clock_img_time_second_D.setProperty(hmUI.prop.VISIBLE, true);
                normal_digital_clock_img_time_second_N.setProperty(hmUI.prop.VISIBLE, false);
                normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, true);
                normal_sun_icon_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_sun_low_text_font.setProperty(hmUI.prop.VISIBLE, true);
                normal_sun_high_text_font.setProperty(hmUI.prop.VISIBLE, false);
              } else {
                
                normal_moon_icon_img.setProperty(hmUI.prop.SRC, 'zapl_2.png');
                normal_digital_clock_img_time_second_N.setProperty(hmUI.prop.VISIBLE, true);
                normal_digital_clock_img_time_second_D.setProperty(hmUI.prop.VISIBLE, false);
                normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_sun_icon_img.setProperty(hmUI.prop.VISIBLE, true);
                normal_sun_low_text_font.setProperty(hmUI.prop.VISIBLE, false);
                normal_sun_high_text_font.setProperty(hmUI.prop.VISIBLE, true);
              }               

            };

            //#endregion
            function scale_call() {
              console.log('scale_call()');

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_ls_normal_step = 1 - progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_linear_scale
                  // initial parameters
                  let start_x_normal_step = 391;
                  let start_y_normal_step = 351;
                  let lenght_ls_normal_step = -55;
                  let line_width_ls_normal_step = 38;
                  let color_ls_normal_step = 0xFF000000;
                  
                  // calculated parameters
                  let start_x_normal_step_draw = start_x_normal_step;
                  let start_y_normal_step_draw = start_y_normal_step;
                  lenght_ls_normal_step = lenght_ls_normal_step * progress_ls_normal_step;
                  let lenght_ls_normal_step_draw = lenght_ls_normal_step;
                  let line_width_ls_normal_step_draw = line_width_ls_normal_step;
                  if (lenght_ls_normal_step < 0){
                    lenght_ls_normal_step_draw = -lenght_ls_normal_step;
                    start_x_normal_step_draw = start_x_normal_step - lenght_ls_normal_step_draw;
                  };
                  
                  normal_step_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_step_draw,
                    y: start_y_normal_step_draw,
                    w: lenght_ls_normal_step_draw,
                    h: line_width_ls_normal_step_draw,
                    color: color_ls_normal_step,
                  });
                };

              console.log('Weather city name');
              let weatherData = weatherSensor.getForecastWeather();
              let idle_cityNameStr = weatherData.cityName;
              idle_city_name_text.setProperty(hmUI.prop.TEXT, idle_cityNameStr);

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                time_update(true, true);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerTimeUpdate) {
                    normal_timerTimeUpdate = timer.createTimer(0, 1000, (function (option) {
                      let updateHour = timeSensor.minute == 0 && timeSensor.second < 2;
                      let updateMinute = timeSensor.second < 2;
                      time_update(updateHour, updateMinute);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSec) {
                    let animDelay = timeSensor.utc % 1000;
                    let animRepeat = 1000;
                    normal_timerUpdateSec = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, false);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.AOD) {
                  if (!idle_timerTimeUpdate) {
                    idle_timerTimeUpdate = timer.createTimer(0, 1000, (function (option) {
                      let updateHour = timeSensor.minute == 0 && timeSensor.second < 2;
                      let updateMinute = timeSensor.second < 2;
                      time_update(updateHour, updateMinute);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerTimeUpdate) {
                  timer.stopTimer(normal_timerTimeUpdate);
                  normal_timerTimeUpdate = undefined;
                }
                if (normal_timerUpdateSec) {
                  timer.stopTimer(normal_timerUpdateSec);
                  normal_timerUpdateSec = undefined;
                }
                if (idle_timerTimeUpdate) {
                  timer.stopTimer(idle_timerTimeUpdate);
                  idle_timerTimeUpdate = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
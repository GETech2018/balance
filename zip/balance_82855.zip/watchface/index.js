﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_calorie_icon_img = ''
        let normal_calorie_linear_scale = ''
        let normal_calorie_linear_scale_mirror = ''
        let normal_calorie_current_text_img = ''
        let normal_date_img_date_week_img = ''
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_linear_scale = ''
        let normal_heart_rate_linear_scale_mirror = ''
        let normal_battery_image_progress_img_level = ''
        let normal_battery_text_text_img = ''
        let normal_date_img_date_day = ''
        let normal_step_icon_img = ''
        let normal_step_current_text_img = ''
        let normal_step_linear_scale = ''
        let normal_step_linear_scale_mirror = ''
        let normal_date_img_date_month_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_digital_clock_img_time = ''
        let idle_date_img_date_week_img = ''
        let idle_battery_image_progress_img_level = ''
        let idle_battery_text_text_img = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_month_img = ''
        let idle_digital_clock_img_time = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'sfondo.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 334,
              y: 397,
              src: 'icon_calories.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            if (screenType != hmSetting.screen_type.AOD) {
              normal_calorie_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
              normal_calorie_linear_scale_mirror = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // normal_calorie_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 351,
              // start_y: 387,
              // color: 0xFFFF8000,
              // lenght: 35,
              // line_width: 6,
              // line_cap: Flat,
              // vertical: False,
              // mirror: True,
              // inversion: False,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const calorie = hmSensor.createSensor(hmSensor.id.CALORIE);
            calorie.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 308,
              y: 350,
              font_array: ["0050.png","0051.png","0052.png","0053.png","0054.png","0055.png","0056.png","0057.png","0058.png","0059.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 87,
              y: 86,
              week_en: ["dd01.png","dd02.png","dd03.png","dd04.png","dd05.png","dd06.png","dd07.png"],
              week_tc: ["dd01.png","dd02.png","dd03.png","dd04.png","dd05.png","dd06.png","dd07.png"],
              week_sc: ["dd01.png","dd02.png","dd03.png","dd04.png","dd05.png","dd06.png","dd07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 112,
              y: 397,
              src: 'icon_heart.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 98,
              y: 350,
              font_array: ["0050.png","0051.png","0052.png","0053.png","0054.png","0055.png","0056.png","0057.png","0058.png","0059.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (screenType != hmSetting.screen_type.AOD) {
              normal_heart_rate_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
              normal_heart_rate_linear_scale_mirror = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // normal_heart_rate_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 130,
              // start_y: 387,
              // color: 0xFFFF0000,
              // lenght: 35,
              // line_width: 6,
              // line_cap: Flat,
              // vertical: False,
              // mirror: True,
              // inversion: False,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const heart_rate = hmSensor.createSensor(hmSensor.id.HEART);
            heart_rate.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 215,
              y: 451,
              image_array: ["38.png","39.png","40.png","41.png","42.png","43.png","44.png","45.png","46.png","47.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 212,
              y: 455,
              font_array: ["date_00.png","date_01.png","date_02.png","date_03.png","date_04.png","date_05.png","date_06.png","date_07.png","date_08.png","date_09.png"],
              padding: false,
              h_space: -4,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 217,
              day_startY: 93,
              day_sc_array: ["0050.png","0051.png","0052.png","0053.png","0054.png","0055.png","0056.png","0057.png","0058.png","0059.png"],
              day_tc_array: ["0050.png","0051.png","0052.png","0053.png","0054.png","0055.png","0056.png","0057.png","0058.png","0059.png"],
              day_en_array: ["0050.png","0051.png","0052.png","0053.png","0054.png","0055.png","0056.png","0057.png","0058.png","0059.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 222,
              y: 397,
              src: 'icon_steps.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 185,
              y: 350,
              font_array: ["0050.png","0051.png","0052.png","0053.png","0054.png","0055.png","0056.png","0057.png","0058.png","0059.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (screenType != hmSetting.screen_type.AOD) {
              normal_step_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
              normal_step_linear_scale_mirror = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // normal_step_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 241,
              // start_y: 387,
              // color: 0xFF0000FF,
              // lenght: 53,
              // line_width: 6,
              // line_cap: Flat,
              // vertical: False,
              // mirror: True,
              // inversion: False,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 267,
              month_startY: 86,
              month_sc_array: ["md01.png","md02.png","md03.png","md04.png","md05.png","md06.png","md07.png","md08.png","md09.png","md10.png","md11.png","md12.png"],
              month_tc_array: ["md01.png","md02.png","md03.png","md04.png","md05.png","md06.png","md07.png","md08.png","md09.png","md10.png","md11.png","md12.png"],
              month_en_array: ["md01.png","md02.png","md03.png","md04.png","md05.png","md06.png","md07.png","md08.png","md09.png","md10.png","md11.png","md12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 163,
              y: 11,
              image_array: ["Weather_1.png","Weather_2.png","Weather_3.png","Weather_4.png","Weather_5.png","Weather_6.png","Weather_7.png","Weather_8.png","Weather_9.png","Weather_10.png","Weather_11.png","Weather_12.png","Weather_13.png","Weather_14.png","Weather_15.png","Weather_16.png","Weather_17.png","Weather_18.png","Weather_19.png","Weather_20.png","Weather_21.png","Weather_22.png","Weather_23.png","Weather_24.png","Weather_25.png","Weather_26.png","Weather_27.png","Weather_28.png","Weather_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 230,
              y: 23,
              font_array: ["0050.png","0051.png","0052.png","0053.png","0054.png","0055.png","0056.png","0057.png","0058.png","0059.png"],
              padding: false,
              h_space: 0,
              unit_sc: '0060.png',
              unit_tc: '0060.png',
              unit_en: '0060.png',
              negative_image: '0065.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 7,
              hour_startY: 150,
              hour_array: ["b0.png","b1.png","b2.png","b3.png","b4.png","b5.png","b6.png","b7.png","b8.png","b9.png"],
              hour_zero: 1,
              hour_space: -2,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 244,
              minute_startY: 150,
              minute_array: ["e1_1.png","e1_2.png","e1_3.png","e1_4.png","e1_5.png","e1_6.png","e1_7.png","e1_8.png","e1_9.png","e1_10.png"],
              minute_zero: 1,
              minute_space: -2,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 87,
              y: 86,
              week_en: ["dd01.png","dd02.png","dd03.png","dd04.png","dd05.png","dd06.png","dd07.png"],
              week_tc: ["dd01.png","dd02.png","dd03.png","dd04.png","dd05.png","dd06.png","dd07.png"],
              week_sc: ["dd01.png","dd02.png","dd03.png","dd04.png","dd05.png","dd06.png","dd07.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 215,
              y: 451,
              image_array: ["38.png","39.png","40.png","41.png","42.png","43.png","44.png","45.png","46.png","47.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 212,
              y: 455,
              font_array: ["date_00.png","date_01.png","date_02.png","date_03.png","date_04.png","date_05.png","date_06.png","date_07.png","date_08.png","date_09.png"],
              padding: false,
              h_space: -4,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 217,
              day_startY: 93,
              day_sc_array: ["0050.png","0051.png","0052.png","0053.png","0054.png","0055.png","0056.png","0057.png","0058.png","0059.png"],
              day_tc_array: ["0050.png","0051.png","0052.png","0053.png","0054.png","0055.png","0056.png","0057.png","0058.png","0059.png"],
              day_en_array: ["0050.png","0051.png","0052.png","0053.png","0054.png","0055.png","0056.png","0057.png","0058.png","0059.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 267,
              month_startY: 86,
              month_sc_array: ["md01.png","md02.png","md03.png","md04.png","md05.png","md06.png","md07.png","md08.png","md09.png","md10.png","md11.png","md12.png"],
              month_tc_array: ["md01.png","md02.png","md03.png","md04.png","md05.png","md06.png","md07.png","md08.png","md09.png","md10.png","md11.png","md12.png"],
              month_en_array: ["md01.png","md02.png","md03.png","md04.png","md05.png","md06.png","md07.png","md08.png","md09.png","md10.png","md11.png","md12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 7,
              hour_startY: 150,
              hour_array: ["b0.png","b1.png","b2.png","b3.png","b4.png","b5.png","b6.png","b7.png","b8.png","b9.png"],
              hour_zero: 1,
              hour_space: -2,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 244,
              minute_startY: 150,
              minute_array: ["e1_1.png","e1_2.png","e1_3.png","e1_4.png","e1_5.png","e1_6.png","e1_7.png","e1_8.png","e1_9.png","e1_10.png"],
              minute_zero: 1,
              minute_space: -2,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            function scale_call() {
              console.log('scale_call()');

                console.log('update scales CALORIE');
                
                let valueCalories = calorie.current;
                let targetCalories = calorie.target;
                let progressCalories = valueCalories/targetCalories;
                if (progressCalories > 1) progressCalories = 1;
                let progress_ls_normal_calorie = progressCalories;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_calorie_linear_scale
                  // initial parameters
                  let start_x_normal_calorie = 351;
                  let start_y_normal_calorie = 387;
                  let lenght_ls_normal_calorie = 35;
                  let line_width_ls_normal_calorie = 6;
                  let color_ls_normal_calorie = 0xFFFF8000;
                  
                  // calculated parameters
                  let start_x_normal_calorie_draw = start_x_normal_calorie;
                  let start_y_normal_calorie_draw = start_y_normal_calorie;
                  lenght_ls_normal_calorie = lenght_ls_normal_calorie * progress_ls_normal_calorie;
                  let lenght_ls_normal_calorie_draw = lenght_ls_normal_calorie;
                  let line_width_ls_normal_calorie_draw = line_width_ls_normal_calorie;
                  if (lenght_ls_normal_calorie < 0){
                    lenght_ls_normal_calorie_draw = -lenght_ls_normal_calorie;
                    start_x_normal_calorie_draw = start_x_normal_calorie - lenght_ls_normal_calorie_draw;
                  };
                  
                  normal_calorie_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_calorie_draw,
                    y: start_y_normal_calorie_draw,
                    w: lenght_ls_normal_calorie_draw,
                    h: line_width_ls_normal_calorie_draw,
                    color: color_ls_normal_calorie,
                  });
                  
                  // normal_calorie_linear_scale_mirror
                  // initial parameters
                  let start_x_normal_calorie_mirror = 351;
                  let start_y_normal_calorie_mirror = 387;
                  let lenght_ls_normal_calorie_mirror = -35;
                  let line_width_ls_normal_calorie_mirror =6;
                  let color_ls_normal_calorie_mirror = 0xFFFF8000;
                  
                  // calculated parameters
                  let start_x_normal_calorie_draw_mirror = start_x_normal_calorie_mirror;
                  let start_y_normal_calorie_draw_mirror = start_y_normal_calorie_mirror;
                  lenght_ls_normal_calorie_mirror = lenght_ls_normal_calorie_mirror * progress_ls_normal_calorie;
                  let lenght_ls_normal_calorie_draw_mirror = lenght_ls_normal_calorie_mirror;
                  let line_width_ls_normal_calorie_draw_mirror = line_width_ls_normal_calorie_mirror;
                  if (lenght_ls_normal_calorie_mirror < 0){
                    lenght_ls_normal_calorie_draw_mirror = -lenght_ls_normal_calorie_mirror;
                    start_x_normal_calorie_draw_mirror = start_x_normal_calorie - lenght_ls_normal_calorie_draw_mirror;
                  };
                  
                  normal_calorie_linear_scale_mirror.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_calorie_draw_mirror,
                    y: start_y_normal_calorie_draw_mirror,
                    w: lenght_ls_normal_calorie_draw_mirror,
                    h: line_width_ls_normal_calorie_draw_mirror,
                    color: color_ls_normal_calorie,
                  });
                };

                console.log('update scales HEART');
                
                let valueHeartRate = heart_rate.last;
                let targetHeartRate = 179;
                let progressHeartRate = (valueHeartRate - 71)/(targetHeartRate - 71);
                if (progressHeartRate < 0) progressHeartRate = 0;
                if (progressHeartRate > 1) progressHeartRate = 1;
                let progress_ls_normal_heart_rate = progressHeartRate;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_heart_rate_linear_scale
                  // initial parameters
                  let start_x_normal_heart_rate = 130;
                  let start_y_normal_heart_rate = 387;
                  let lenght_ls_normal_heart_rate = 35;
                  let line_width_ls_normal_heart_rate = 6;
                  let color_ls_normal_heart_rate = 0xFFFF0000;
                  
                  // calculated parameters
                  let start_x_normal_heart_rate_draw = start_x_normal_heart_rate;
                  let start_y_normal_heart_rate_draw = start_y_normal_heart_rate;
                  lenght_ls_normal_heart_rate = lenght_ls_normal_heart_rate * progress_ls_normal_heart_rate;
                  let lenght_ls_normal_heart_rate_draw = lenght_ls_normal_heart_rate;
                  let line_width_ls_normal_heart_rate_draw = line_width_ls_normal_heart_rate;
                  if (lenght_ls_normal_heart_rate < 0){
                    lenght_ls_normal_heart_rate_draw = -lenght_ls_normal_heart_rate;
                    start_x_normal_heart_rate_draw = start_x_normal_heart_rate - lenght_ls_normal_heart_rate_draw;
                  };
                  
                  normal_heart_rate_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_heart_rate_draw,
                    y: start_y_normal_heart_rate_draw,
                    w: lenght_ls_normal_heart_rate_draw,
                    h: line_width_ls_normal_heart_rate_draw,
                    color: color_ls_normal_heart_rate,
                  });
                  
                  // normal_heart_rate_linear_scale_mirror
                  // initial parameters
                  let start_x_normal_heart_rate_mirror = 130;
                  let start_y_normal_heart_rate_mirror = 387;
                  let lenght_ls_normal_heart_rate_mirror = -35;
                  let line_width_ls_normal_heart_rate_mirror =6;
                  let color_ls_normal_heart_rate_mirror = 0xFFFF0000;
                  
                  // calculated parameters
                  let start_x_normal_heart_rate_draw_mirror = start_x_normal_heart_rate_mirror;
                  let start_y_normal_heart_rate_draw_mirror = start_y_normal_heart_rate_mirror;
                  lenght_ls_normal_heart_rate_mirror = lenght_ls_normal_heart_rate_mirror * progress_ls_normal_heart_rate;
                  let lenght_ls_normal_heart_rate_draw_mirror = lenght_ls_normal_heart_rate_mirror;
                  let line_width_ls_normal_heart_rate_draw_mirror = line_width_ls_normal_heart_rate_mirror;
                  if (lenght_ls_normal_heart_rate_mirror < 0){
                    lenght_ls_normal_heart_rate_draw_mirror = -lenght_ls_normal_heart_rate_mirror;
                    start_x_normal_heart_rate_draw_mirror = start_x_normal_heart_rate - lenght_ls_normal_heart_rate_draw_mirror;
                  };
                  
                  normal_heart_rate_linear_scale_mirror.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_heart_rate_draw_mirror,
                    y: start_y_normal_heart_rate_draw_mirror,
                    w: lenght_ls_normal_heart_rate_draw_mirror,
                    h: line_width_ls_normal_heart_rate_draw_mirror,
                    color: color_ls_normal_heart_rate,
                  });
                };

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_ls_normal_step = progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_linear_scale
                  // initial parameters
                  let start_x_normal_step = 241;
                  let start_y_normal_step = 387;
                  let lenght_ls_normal_step = 53;
                  let line_width_ls_normal_step = 6;
                  let color_ls_normal_step = 0xFF0000FF;
                  
                  // calculated parameters
                  let start_x_normal_step_draw = start_x_normal_step;
                  let start_y_normal_step_draw = start_y_normal_step;
                  lenght_ls_normal_step = lenght_ls_normal_step * progress_ls_normal_step;
                  let lenght_ls_normal_step_draw = lenght_ls_normal_step;
                  let line_width_ls_normal_step_draw = line_width_ls_normal_step;
                  if (lenght_ls_normal_step < 0){
                    lenght_ls_normal_step_draw = -lenght_ls_normal_step;
                    start_x_normal_step_draw = start_x_normal_step - lenght_ls_normal_step_draw;
                  };
                  
                  normal_step_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_step_draw,
                    y: start_y_normal_step_draw,
                    w: lenght_ls_normal_step_draw,
                    h: line_width_ls_normal_step_draw,
                    color: color_ls_normal_step,
                  });
                  
                  // normal_step_linear_scale_mirror
                  // initial parameters
                  let start_x_normal_step_mirror = 241;
                  let start_y_normal_step_mirror = 387;
                  let lenght_ls_normal_step_mirror = -53;
                  let line_width_ls_normal_step_mirror =6;
                  let color_ls_normal_step_mirror = 0xFF0000FF;
                  
                  // calculated parameters
                  let start_x_normal_step_draw_mirror = start_x_normal_step_mirror;
                  let start_y_normal_step_draw_mirror = start_y_normal_step_mirror;
                  lenght_ls_normal_step_mirror = lenght_ls_normal_step_mirror * progress_ls_normal_step;
                  let lenght_ls_normal_step_draw_mirror = lenght_ls_normal_step_mirror;
                  let line_width_ls_normal_step_draw_mirror = line_width_ls_normal_step_mirror;
                  if (lenght_ls_normal_step_mirror < 0){
                    lenght_ls_normal_step_draw_mirror = -lenght_ls_normal_step_mirror;
                    start_x_normal_step_draw_mirror = start_x_normal_step - lenght_ls_normal_step_draw_mirror;
                  };
                  
                  normal_step_linear_scale_mirror.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_step_draw_mirror,
                    y: start_y_normal_step_draw_mirror,
                    w: lenght_ls_normal_step_draw_mirror,
                    h: line_width_ls_normal_step_draw_mirror,
                    color: color_ls_normal_step,
                  });
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
﻿    /*
    ** Watch_Face_Editor tool v 18.0
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_stand_current_text_img = ''
        let normal_spo2_text_text_img = ''
        let normal_vo2max_text_text_img = ''
        let normal_sleep_score_font = ''
        let array_sleep_chart = []
        let normal_sleep_chart_group = ''
        let normal_heart_rate_linear_scale = ''
        let normal_heart_rate_text_text_img = ''
        let normal_pai_linear_scale = ''
        let normal_pai_weekly_text_img = ''
        let normal_hrv_text_text_img = ''
        let normal_hrv_image_progress_img_level = ''
        let normal_bio_charge_text_text_img = ''
        let normal_bio_charge_image_progress_img_level = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_icon_img = ''
        let normal_temperature_current_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_step_circle_scale = ''
        let normal_step_current_text_img = ''
        let normal_battery_linear_scale = ''
        let normal_battery_linear_scale_pointer_img = ''
        let normal_battery_text_text_img = ''
        let normal_digital_clock_img_time_minute = ''
        let normal_digital_clock_img_time_hour = ''
        let normal_digital_clock_img_time_second = ''
        let idle_background_bg_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_stand_current_text_img = ''
        let idle_spo2_text_text_img = ''
        let idle_vo2max_text_text_img = ''
        let idle_sleep_score_font = ''
        let idle_sleep_chart_group = ''
        let idle_heart_rate_linear_scale = ''
        let idle_heart_rate_text_text_img = ''
        let idle_pai_linear_scale = ''
        let idle_pai_weekly_text_img = ''
        let idle_hrv_text_text_img = ''
        let idle_hrv_image_progress_img_level = ''
        let idle_bio_charge_text_text_img = ''
        let idle_bio_charge_image_progress_img_level = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_week_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_temperature_icon_img = ''
        let idle_temperature_current_text_img = ''
        let idle_distance_text_text_img = ''
        let idle_calorie_current_text_img = ''
        let idle_step_circle_scale = ''
        let idle_step_current_text_img = ''
        let idle_battery_linear_scale = ''
        let idle_battery_linear_scale_pointer_img = ''
        let idle_battery_text_text_img = ''
        let idle_digital_clock_img_time_minute = ''
        let idle_digital_clock_img_time_hour = ''
        let idle_second_TextRotate = new Array(2);
        let idle_second_TextRotate_ASCIIARRAY = new Array(10);
        let idle_second_TextRotate_img_width = 42;
        let idle_timerTextUpdate = undefined;
        let normal_step_jumpable_img_click = ''
        let normal_cal_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_battery_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_stand_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_vo2max_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let timeSensor = '';
        let sleepSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            // FontName: ; FontSize: 41
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 571,
              h: 56,
              text_size: 41,
              char_space: 0,
              line_space: 0,
              font: 'fonts/DINNextW1G-Bold.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg007.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 178,
              y: 450,
              src: '0500.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 178,
              y: 10,
              src: '0501.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 202,
              y: 371,
              font_array: ["Middle_0.png","Middle_1.png","Middle_2.png","Middle_3.png","Middle_4.png","Middle_5.png","Middle_6.png","Middle_7.png","Middle_8.png","Middle_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STAND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 240,
              y: 412,
              font_array: ["Middle_0.png","Middle_1.png","Middle_2.png","Middle_3.png","Middle_4.png","Middle_5.png","Middle_6.png","Middle_7.png","Middle_8.png","Middle_9.png"],
              padding: false,
              h_space: 0,
              invalid_image: 'Middle_null.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_vo2max_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 160,
              y: 412,
              font_array: ["Middle_0.png","Middle_1.png","Middle_2.png","Middle_3.png","Middle_4.png","Middle_5.png","Middle_6.png","Middle_7.png","Middle_8.png","Middle_9.png"],
              padding: false,
              h_space: 0,
              invalid_image: 'Middle_null.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.VO2MAX,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sleep_score_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 120,
              y: 371,
              w: 76,
              h: 42,
              text_size: 41,
              char_space: 0,
              font: 'fonts/DINNextW1G-Bold.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sleep_chart_group = hmUI.createWidget(hmUI.widget.GROUP, {
              x: 173,
              y: 373,
              w: 70,
              h: 29,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            if (screenType != hmSetting.screen_type.AOD) {
              normal_heart_rate_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // normal_heart_rate_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 395,
              // start_y: 306,
              // color: 0xFFFF0000,
              // lenght: 49,
              // line_width: 11,
              // line_cap: Rounded,
              // vertical: False,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const heart_rate = hmSensor.createSensor(hmSensor.id.HEART);
            heart_rate.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 387,
              y: 260,
              font_array: ["Middle_0.png","Middle_1.png","Middle_2.png","Middle_3.png","Middle_4.png","Middle_5.png","Middle_6.png","Middle_7.png","Middle_8.png","Middle_9.png"],
              padding: false,
              h_space: -1,
              invalid_image: 'Middle_null.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (screenType != hmSetting.screen_type.AOD) {
              normal_pai_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // normal_pai_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 322,
              // start_y: 306,
              // color: 0xFFFF00FF,
              // lenght: 49,
              // line_width: 11,
              // line_cap: Rounded,
              // vertical: False,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.PAI_WEEKLY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const pai = hmSensor.createSensor(hmSensor.id.PAI);
            pai.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_pai_weekly_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 313,
              y: 260,
              font_array: ["Middle_0.png","Middle_1.png","Middle_2.png","Middle_3.png","Middle_4.png","Middle_5.png","Middle_6.png","Middle_7.png","Middle_8.png","Middle_9.png"],
              padding: false,
              h_space: -1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_hrv_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 242,
              y: 260,
              font_array: ["Middle_0.png","Middle_1.png","Middle_2.png","Middle_3.png","Middle_4.png","Middle_5.png","Middle_6.png","Middle_7.png","Middle_8.png","Middle_9.png"],
              padding: false,
              h_space: -1,
              invalid_image: 'Middle_null.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HRV,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_hrv_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 249,
              y: 305,
              image_array: ["HRV_01.png","HRV_02.png","HRV_03.png","HRV_04.png","HRV_05.png","HRV_06.png","HRV_07.png","HRV_08.png","HRV_09.png","HRV_10.png"],
              image_length: 10,
              type: hmUI.data_type.HRV,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_bio_charge_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 20,
              y: 262,
              font_array: ["Large_0.png","Large_1.png","Large_2.png","Large_3.png","Large_4.png","Large_5.png","Large_6.png","Large_7.png","Large_8.png","Large_9.png"],
              padding: false,
              h_space: -3,
              invalid_image: 'Large_null.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BIO_CHARGE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_bio_charge_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 163,
              y: 292,
              image_array: ["Power_01.png","Power_02.png","Power_03.png","Power_04.png","Power_05.png","Power_06.png","Power_07.png","Power_08.png","Power_09.png","Power_10.png"],
              image_length: 10,
              type: hmUI.data_type.BIO_CHARGE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 426,
              day_startY: 198,
              day_sc_array: ["Small_0.png","Small_1.png","Small_2.png","Small_3.png","Small_4.png","Small_5.png","Small_6.png","Small_7.png","Small_8.png","Small_9.png"],
              day_tc_array: ["Small_0.png","Small_1.png","Small_2.png","Small_3.png","Small_4.png","Small_5.png","Small_6.png","Small_7.png","Small_8.png","Small_9.png"],
              day_en_array: ["Small_0.png","Small_1.png","Small_2.png","Small_3.png","Small_4.png","Small_5.png","Small_6.png","Small_7.png","Small_8.png","Small_9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 380,
              y: 198,
              week_en: ["0019.png","0020.png","0021.png","0022.png","0023.png","0024.png","0025.png"],
              week_tc: ["0019.png","0020.png","0021.png","0022.png","0023.png","0024.png","0025.png"],
              week_sc: ["0019.png","0020.png","0021.png","0022.png","0023.png","0024.png","0025.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 397,
              y: 110,
              image_array: ["Weather_01.png","Weather_02.png","Weather_03.png","Weather_04.png","Weather_05.png","Weather_06.png","Weather_07.png","Weather_08.png","Weather_09.png","Weather_10.png","Weather_11.png","Weather_12.png","Weather_13.png","Weather_14.png","Weather_15.png","Weather_16.png","Weather_17.png","Weather_18.png","Weather_19.png","Weather_20.png","Weather_21.png","Weather_22.png","Weather_23.png","Weather_24.png","Weather_25.png","Weather_26.png","Weather_27.png","Weather_28.png","Weather_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 391,
              y: 126,
              src: 'mask.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 376,
              y: 156,
              font_array: ["Middle_0.png","Middle_1.png","Middle_2.png","Middle_3.png","Middle_4.png","Middle_5.png","Middle_6.png","Middle_7.png","Middle_8.png","Middle_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Middle_du.png',
              unit_tc: 'Middle_du.png',
              unit_en: 'Middle_du.png',
              imperial_unit_sc: 'Middle_du.png',
              imperial_unit_tc: 'Middle_du.png',
              imperial_unit_en: 'Middle_du.png',
              negative_image: 'Middle_fu.png',
              invalid_image: 'Middle_null.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const temperatureUnit = hmSetting.getTemperatureUnit();
            //#region temperatureUnit
            if (temperatureUnit == 1) {
              normal_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
                x: 376,
                y: 156,
                font_array: ["Middle_0.png","Middle_1.png","Middle_2.png","Middle_3.png","Middle_4.png","Middle_5.png","Middle_6.png","Middle_7.png","Middle_8.png","Middle_9.png"],
                padding: false,
                h_space: 0,
                unit_sc: 'Middle_du.png',
                unit_tc: 'Middle_du.png',
                unit_en: 'Middle_du.png',
                imperial_unit_sc: 'Middle_du.png',
                imperial_unit_tc: 'Middle_du.png',
                imperial_unit_en: 'Middle_du.png',
                negative_image: 'Middle_fu.png',
                invalid_image: 'Middle_null.png',
                align_h: hmUI.align.CENTER_H,
                type: hmUI.data_type.WEATHER_CURRENT,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
            };
            //#endregion

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 312,
              y: 73,
              font_array: ["Small_0.png","Small_1.png","Small_2.png","Small_3.png","Small_4.png","Small_5.png","Small_6.png","Small_7.png","Small_8.png","Small_9.png"],
              padding: false,
              h_space: -1,
              unit_sc: 'Small_km.png',
              unit_tc: 'Small_km.png',
              unit_en: 'Small_km.png',
              imperial_unit_sc: 'Small_mi.png',
              imperial_unit_tc: 'Small_mi.png',
              imperial_unit_en: 'Small_mi.png',
              dot_image: 'Small_dot.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 312,
              y: 41,
              font_array: ["Small_0.png","Small_1.png","Small_2.png","Small_3.png","Small_4.png","Small_5.png","Small_6.png","Small_7.png","Small_8.png","Small_9.png"],
              padding: false,
              h_space: -1,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 134,
              // center_y: 66,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 32,
              // line_width: 9,
              // line_cap: Flat,
              // color: 0xFFBCFF00,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 134,
              center_y: 66,
              start_angle: 0,
              end_angle: 360,
              radius: 28,
              line_width: 9,
              corner_flag: 3,
              color: 0xFFBCFF00,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 172,
              y: 73,
              font_array: ["Small_0.png","Small_1.png","Small_2.png","Small_3.png","Small_4.png","Small_5.png","Small_6.png","Small_7.png","Small_8.png","Small_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (screenType != hmSetting.screen_type.AOD) {
              normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            normal_battery_linear_scale_pointer_img = hmUI.createWidget(hmUI.widget.IMG);
            // normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 45,
              // start_y: 341,
              // color: 0xFFBCFF00,
              // pointer: 'Batt_Pointer.png',
              // lenght: 335,
              // line_width: 18,
              // line_cap: Rounded,
              // vertical: False,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 380,
              y: 341,
              font_array: ["Black_0.png","Black_1.png","Black_2.png","Black_3.png","Black_4.png","Black_5.png","Black_6.png","Black_7.png","Black_8.png","Black_9.png"],
              padding: false,
              h_space: -2,
              unit_sc: 'per.png',
              unit_tc: 'per.png',
              unit_en: 'per.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 208,
              minute_startY: 110,
              minute_array: ["Time_0.png","Time_1.png","Time_2.png","Time_3.png","Time_4.png","Time_5.png","Time_6.png","Time_7.png","Time_8.png","Time_9.png"],
              minute_zero: 1,
              minute_space: 2,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 30,
              hour_startY: 110,
              hour_array: ["Time_0.png","Time_1.png","Time_2.png","Time_3.png","Time_4.png","Time_5.png","Time_6.png","Time_7.png","Time_8.png","Time_9.png"],
              hour_zero: 1,
              hour_space: 2,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_second = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              second_startX: 156,
              second_startY: 226,
              second_array: ["AOD_Large_0.png","AOD_Large_1.png","AOD_Large_2.png","AOD_Large_3.png","AOD_Large_4.png","AOD_Large_5.png","AOD_Large_6.png","AOD_Large_7.png","AOD_Large_8.png","AOD_Large_9.png"],
              second_zero: 1,
              second_space: -2,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg007.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 178,
              y: 450,
              src: '0500.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 178,
              y: 10,
              src: '0501.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_stand_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 202,
              y: 371,
              font_array: ["Middle_0.png","Middle_1.png","Middle_2.png","Middle_3.png","Middle_4.png","Middle_5.png","Middle_6.png","Middle_7.png","Middle_8.png","Middle_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STAND,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_spo2_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 240,
              y: 412,
              font_array: ["Middle_0.png","Middle_1.png","Middle_2.png","Middle_3.png","Middle_4.png","Middle_5.png","Middle_6.png","Middle_7.png","Middle_8.png","Middle_9.png"],
              padding: false,
              h_space: 0,
              invalid_image: 'Middle_null.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_vo2max_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 160,
              y: 412,
              font_array: ["Middle_0.png","Middle_1.png","Middle_2.png","Middle_3.png","Middle_4.png","Middle_5.png","Middle_6.png","Middle_7.png","Middle_8.png","Middle_9.png"],
              padding: false,
              h_space: 0,
              invalid_image: 'Middle_null.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.VO2MAX,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_sleep_score_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 120,
              y: 371,
              w: 76,
              h: 42,
              text_size: 41,
              char_space: 0,
              font: 'fonts/DINNextW1G-Bold.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_sleep_chart_group = hmUI.createWidget(hmUI.widget.GROUP, {
              x: 173,
              y: 373,
              w: 70,
              h: 29,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            if (screenType == hmSetting.screen_type.AOD) {
              idle_heart_rate_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // idle_heart_rate_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 395,
              // start_y: 306,
              // color: 0xFFFF0000,
              // lenght: 49,
              // line_width: 11,
              // line_cap: Rounded,
              // vertical: False,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 387,
              y: 260,
              font_array: ["Middle_0.png","Middle_1.png","Middle_2.png","Middle_3.png","Middle_4.png","Middle_5.png","Middle_6.png","Middle_7.png","Middle_8.png","Middle_9.png"],
              padding: false,
              h_space: -1,
              invalid_image: 'Middle_null.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            if (screenType == hmSetting.screen_type.AOD) {
              idle_pai_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // idle_pai_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 322,
              // start_y: 306,
              // color: 0xFFFF00FF,
              // lenght: 49,
              // line_width: 11,
              // line_cap: Rounded,
              // vertical: False,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.PAI_WEEKLY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_pai_weekly_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 313,
              y: 260,
              font_array: ["Middle_0.png","Middle_1.png","Middle_2.png","Middle_3.png","Middle_4.png","Middle_5.png","Middle_6.png","Middle_7.png","Middle_8.png","Middle_9.png"],
              padding: false,
              h_space: -1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_hrv_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 242,
              y: 260,
              font_array: ["Middle_0.png","Middle_1.png","Middle_2.png","Middle_3.png","Middle_4.png","Middle_5.png","Middle_6.png","Middle_7.png","Middle_8.png","Middle_9.png"],
              padding: false,
              h_space: -1,
              invalid_image: 'Middle_null.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HRV,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_hrv_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 249,
              y: 305,
              image_array: ["HRV_01.png","HRV_02.png","HRV_03.png","HRV_04.png","HRV_05.png","HRV_06.png","HRV_07.png","HRV_08.png","HRV_09.png","HRV_10.png"],
              image_length: 10,
              type: hmUI.data_type.HRV,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_bio_charge_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 20,
              y: 262,
              font_array: ["Large_0.png","Large_1.png","Large_2.png","Large_3.png","Large_4.png","Large_5.png","Large_6.png","Large_7.png","Large_8.png","Large_9.png"],
              padding: false,
              h_space: -3,
              invalid_image: 'Large_null.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BIO_CHARGE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_bio_charge_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 163,
              y: 292,
              image_array: ["Power_01.png","Power_02.png","Power_03.png","Power_04.png","Power_05.png","Power_06.png","Power_07.png","Power_08.png","Power_09.png","Power_10.png"],
              image_length: 10,
              type: hmUI.data_type.BIO_CHARGE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 426,
              day_startY: 198,
              day_sc_array: ["Small_0.png","Small_1.png","Small_2.png","Small_3.png","Small_4.png","Small_5.png","Small_6.png","Small_7.png","Small_8.png","Small_9.png"],
              day_tc_array: ["Small_0.png","Small_1.png","Small_2.png","Small_3.png","Small_4.png","Small_5.png","Small_6.png","Small_7.png","Small_8.png","Small_9.png"],
              day_en_array: ["Small_0.png","Small_1.png","Small_2.png","Small_3.png","Small_4.png","Small_5.png","Small_6.png","Small_7.png","Small_8.png","Small_9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 380,
              y: 198,
              week_en: ["0019.png","0020.png","0021.png","0022.png","0023.png","0024.png","0025.png"],
              week_tc: ["0019.png","0020.png","0021.png","0022.png","0023.png","0024.png","0025.png"],
              week_sc: ["0019.png","0020.png","0021.png","0022.png","0023.png","0024.png","0025.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 397,
              y: 110,
              image_array: ["Weather_01.png","Weather_02.png","Weather_03.png","Weather_04.png","Weather_05.png","Weather_06.png","Weather_07.png","Weather_08.png","Weather_09.png","Weather_10.png","Weather_11.png","Weather_12.png","Weather_13.png","Weather_14.png","Weather_15.png","Weather_16.png","Weather_17.png","Weather_18.png","Weather_19.png","Weather_20.png","Weather_21.png","Weather_22.png","Weather_23.png","Weather_24.png","Weather_25.png","Weather_26.png","Weather_27.png","Weather_28.png","Weather_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 391,
              y: 126,
              src: 'mask.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 376,
              y: 156,
              font_array: ["Middle_0.png","Middle_1.png","Middle_2.png","Middle_3.png","Middle_4.png","Middle_5.png","Middle_6.png","Middle_7.png","Middle_8.png","Middle_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Middle_du.png',
              unit_tc: 'Middle_du.png',
              unit_en: 'Middle_du.png',
              imperial_unit_sc: 'Middle_du.png',
              imperial_unit_tc: 'Middle_du.png',
              imperial_unit_en: 'Middle_du.png',
              negative_image: 'Middle_fu.png',
              invalid_image: 'Middle_null.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            //#region temperatureUnit
            if (temperatureUnit == 1) {
              idle_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
                x: 376,
                y: 156,
                font_array: ["Middle_0.png","Middle_1.png","Middle_2.png","Middle_3.png","Middle_4.png","Middle_5.png","Middle_6.png","Middle_7.png","Middle_8.png","Middle_9.png"],
                padding: false,
                h_space: 0,
                unit_sc: 'Middle_du.png',
                unit_tc: 'Middle_du.png',
                unit_en: 'Middle_du.png',
                imperial_unit_sc: 'Middle_du.png',
                imperial_unit_tc: 'Middle_du.png',
                imperial_unit_en: 'Middle_du.png',
                negative_image: 'Middle_fu.png',
                invalid_image: 'Middle_null.png',
                align_h: hmUI.align.CENTER_H,
                type: hmUI.data_type.WEATHER_CURRENT,
                show_level: hmUI.show_level.ONLY_AOD,
              });
            };
            //#endregion

            idle_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 312,
              y: 73,
              font_array: ["Small_0.png","Small_1.png","Small_2.png","Small_3.png","Small_4.png","Small_5.png","Small_6.png","Small_7.png","Small_8.png","Small_9.png"],
              padding: false,
              h_space: -1,
              unit_sc: 'Small_km.png',
              unit_tc: 'Small_km.png',
              unit_en: 'Small_km.png',
              imperial_unit_sc: 'Small_mi.png',
              imperial_unit_tc: 'Small_mi.png',
              imperial_unit_en: 'Small_mi.png',
              dot_image: 'Small_dot.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 312,
              y: 41,
              font_array: ["Small_0.png","Small_1.png","Small_2.png","Small_3.png","Small_4.png","Small_5.png","Small_6.png","Small_7.png","Small_8.png","Small_9.png"],
              padding: false,
              h_space: -1,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 134,
              // center_y: 66,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 32,
              // line_width: 9,
              // line_cap: Flat,
              // color: 0xFFBCFF00,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 134,
              center_y: 66,
              start_angle: 0,
              end_angle: 360,
              radius: 28,
              line_width: 9,
              corner_flag: 3,
              color: 0xFFBCFF00,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 172,
              y: 73,
              font_array: ["Small_0.png","Small_1.png","Small_2.png","Small_3.png","Small_4.png","Small_5.png","Small_6.png","Small_7.png","Small_8.png","Small_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            if (screenType == hmSetting.screen_type.AOD) {
              idle_battery_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            idle_battery_linear_scale_pointer_img = hmUI.createWidget(hmUI.widget.IMG);
            // idle_battery_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 45,
              // start_y: 341,
              // color: 0xFFBCFF00,
              // pointer: 'Batt_Pointer.png',
              // lenght: 335,
              // line_width: 18,
              // line_cap: Rounded,
              // vertical: False,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 380,
              y: 341,
              font_array: ["Black_0.png","Black_1.png","Black_2.png","Black_3.png","Black_4.png","Black_5.png","Black_6.png","Black_7.png","Black_8.png","Black_9.png"],
              padding: false,
              h_space: -2,
              unit_sc: 'per.png',
              unit_tc: 'per.png',
              unit_en: 'per.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 208,
              minute_startY: 110,
              minute_array: ["Time_0.png","Time_1.png","Time_2.png","Time_3.png","Time_4.png","Time_5.png","Time_6.png","Time_7.png","Time_8.png","Time_9.png"],
              minute_zero: 1,
              minute_space: 2,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 30,
              hour_startY: 110,
              hour_array: ["Time_0.png","Time_1.png","Time_2.png","Time_3.png","Time_4.png","Time_5.png","Time_6.png","Time_7.png","Time_8.png","Time_9.png"],
              hour_zero: 1,
              hour_space: 2,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_second_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 197,
              // y: 226,
              // font_array: ["AOD_Large_0.png","AOD_Large_1.png","AOD_Large_2.png","AOD_Large_3.png","AOD_Large_4.png","AOD_Large_5.png","AOD_Large_6.png","AOD_Large_7.png","AOD_Large_8.png","AOD_Large_9.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: -2,
              // angle: 0,
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.SECOND,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_second_TextRotate_ASCIIARRAY[0] = 'AOD_Large_0.png';  // set of images with numbers
            idle_second_TextRotate_ASCIIARRAY[1] = 'AOD_Large_1.png';  // set of images with numbers
            idle_second_TextRotate_ASCIIARRAY[2] = 'AOD_Large_2.png';  // set of images with numbers
            idle_second_TextRotate_ASCIIARRAY[3] = 'AOD_Large_3.png';  // set of images with numbers
            idle_second_TextRotate_ASCIIARRAY[4] = 'AOD_Large_4.png';  // set of images with numbers
            idle_second_TextRotate_ASCIIARRAY[5] = 'AOD_Large_5.png';  // set of images with numbers
            idle_second_TextRotate_ASCIIARRAY[6] = 'AOD_Large_6.png';  // set of images with numbers
            idle_second_TextRotate_ASCIIARRAY[7] = 'AOD_Large_7.png';  // set of images with numbers
            idle_second_TextRotate_ASCIIARRAY[8] = 'AOD_Large_8.png';  // set of images with numbers
            idle_second_TextRotate_ASCIIARRAY[9] = 'AOD_Large_9.png';  // set of images with numbers

            //#region TextRotate
            for (let i = 0; i < 2; i++) {
              idle_second_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 197,
                center_y: 226,
                pos_x: 197,
                pos_y: 226,
                angle: 0,
                src: 'AOD_Large_0.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_second_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //#endregion

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 174,
              y: 29,
              w: 76,
              h: 67,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_cal_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 256,
              y: 33,
              w: 107,
              h: 63,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 378,
              y: 231,
              w: 55,
              h: 88,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 307,
              y: 229,
              w: 49,
              h: 91,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 48,
              y: 340,
              w: 388,
              h: 33,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 386,
              y: 96,
              w: 51,
              h: 53,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 363,
              y: 151,
              w: 79,
              h: 36,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 314,
              y: 375,
              w: 107,
              h: 36,
              type: hmUI.data_type.STAND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 263,
              y: 416,
              w: 116,
              h: 48,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 233,
              y: 122,
              w: 81,
              h: 84,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 160,
              y: 220,
              w: 70,
              h: 70,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_vo2max_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 93,
              y: 417,
              w: 111,
              h: 49,
              type: hmUI.data_type.VO2MAX,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 360,
              y: 190,
              w: 87,
              h: 37,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 102,
              y: 29,
              w: 66,
              h: 73,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'SportListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 239,
              y: 230,
              w: 50,
              h: 91,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({ appid: 1047865, url: 'page/round/index' });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 65,
              y: 377,
              w: 140,
              h: 33,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'Sleep_HomeScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 38,
              y: 229,
              w: 108,
              h: 98,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'BioChargeHomeScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            //#region text_update
            function text_update() {
              console.log('text_update()');

              console.log('update text rotate second_TIME');
              let valueSecond = timeSensor.second;
              let idle_second_rotate_string = parseInt(valueSecond).toString();
              idle_second_rotate_string = idle_second_rotate_string.padStart(2, '0');

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  idle_second_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueSecond != null && valueSecond != undefined && isFinite(valueSecond) && idle_second_rotate_string.length > 0 && idle_second_rotate_string.length <= 2) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let idle_second_TextRotate_posOffset = idle_second_TextRotate_img_width * idle_second_rotate_string.length;
                  idle_second_TextRotate_posOffset = idle_second_TextRotate_posOffset + -2 * (idle_second_rotate_string.length - 1);
                  img_offset -= idle_second_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of idle_second_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_second_TextRotate[index].setProperty(hmUI.prop.POS_X, 197 + img_offset);
                      idle_second_TextRotate[index].setProperty(hmUI.prop.SRC, idle_second_TextRotate_ASCIIARRAY[charCode]);
                      idle_second_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_second_TextRotate_img_width + -2;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

            };

            //#endregion
            if (!sleepSensor) sleepSensor = hmSensor.createSensor(hmSensor.id.SLEEP);
            //#region sleep_update
            function sleep_update() {
              console.log('sleep_update()');
              let sleepInfo = sleepSensor.getBasicInfo();

              console.log('sleep score');
              let sleepScore = sleepInfo.score;
              if (normal_sleep_score_font) normal_sleep_score_font.setProperty(hmUI.prop.TEXT, String(sleepScore));

              console.log('sleep chart');
              let normal_sleepColors = [0xFF743ED4, 0xFF6284EF, 0xFF46C536, 0xFFAE433B];
              let normal_sleppChartWidth = 70;
              let normal_sleppChartHeight = 29;
              let normal_sleepScaleX = normal_sleppChartWidth / sleepSensor.getTotalTime();
              let normal_sleepScaleY = normal_sleppChartHeight / 4;
              const modelData = sleepSensor.getSleepStageModel();
              let sleepStageArray = sleepSensor.getSleepStageData();
              let sleepChartStartTime = 0;
              if (array_sleep_chart.length > 0) {
                console.log('deleteWidget screen on');
                for (let i = 0; i < array_sleep_chart.length; i++) {
                  if (array_sleep_chart[i]) hmUI.deleteWidget(array_sleep_chart[i]);
                }
                array_sleep_chart = [];
              } // end if

              if (sleepStageArray != undefined && sleepStageArray.length > 0) sleepChartStartTime = sleepStageArray[0].start;
              // console.log('draw normal_sleep_chart');
              if (screenType == hmSetting.screen_type.WATCHFACE) {
                for (let i = 0; i < sleepStageArray.length; i++) { //ONLY_NORMAL
                  let data = sleepStageArray[i];
                  let normal_color = normal_sleepColors[0];
                  let normal_posY = 3 * normal_sleepScaleY;

                  switch (data.model) {
                    case modelData.WAKE_STAGE:
                      normal_color = normal_sleepColors[3];
                      normal_posY = 0;
                      break;
                    case modelData.REM_STAGE:
                      normal_color = normal_sleepColors[2];
                      normal_posY = normal_sleepScaleY; 
                      break;
                    case modelData.LIGHT_STAGE:
                      normal_color = normal_sleepColors[1];
                      normal_posY = 2 * normal_sleepScaleY; 
                      break;
                  };
                  let normal_x = (data.start - sleepChartStartTime) * normal_sleepScaleX;
                  let normal_w = (data.stop + 1 - data.start) * normal_sleepScaleX;
                  const fill_rect = normal_sleep_chart_group.createWidget(hmUI.widget.FILL_RECT, {
                    x: normal_x,
                    y: normal_posY,
                    w: normal_w < 2 ? 2 : normal_w,
                    h: normal_sleepScaleY,
                    radius: 5,
                    color: normal_color,
                  });
                  array_sleep_chart.push(fill_rect);
                }; // for
              }; // end screenType

              console.log('sleep score');
              if (idle_sleep_score_font) idle_sleep_score_font.setProperty(hmUI.prop.TEXT, String(sleepScore));

              console.log('sleep chart');
              let idle_sleepColors = [0xFF743ED4, 0xFF6284EF, 0xFF46C536, 0xFFAE433B];
              let idle_sleppChartWidth = 70;
              let idle_sleppChartHeight = 29;
              let idle_sleepScaleX = idle_sleppChartWidth / sleepSensor.getTotalTime();
              let idle_sleepScaleY = idle_sleppChartHeight / 4;
              // console.log('draw idle_sleep_chart');
              if (screenType == hmSetting.screen_type.AOD) {
                for (let i = 0; i < sleepStageArray.length; i++) { //ONLY_AOD
                  let data = sleepStageArray[i];
                  let idle_color = idle_sleepColors[0];
                  let idle_posY = 3 * idle_sleepScaleY;

                  switch (data.model) {
                    case modelData.WAKE_STAGE:
                      idle_color = idle_sleepColors[3];
                      idle_posY = 0;
                      break;
                    case modelData.REM_STAGE:
                      idle_color = idle_sleepColors[2];
                      idle_posY = idle_sleepScaleY; 
                      break;
                    case modelData.LIGHT_STAGE:
                      idle_color = idle_sleepColors[1];
                      idle_posY = 2 * idle_sleepScaleY; 
                      break;
                  };
                  let idle_x = (data.start - sleepChartStartTime) * idle_sleepScaleX;
                  let idle_w = (data.stop + 1 - data.start) * idle_sleepScaleX;
                  const fill_rect = idle_sleep_chart_group.createWidget(hmUI.widget.FILL_RECT, {
                    x: idle_x,
                    y: idle_posY,
                    w: idle_w < 2 ? 2 : idle_w,
                    h: idle_sleepScaleY,
                    radius: 5,
                    color: idle_color,
                  });
                  array_sleep_chart.push(fill_rect);
                }; // for
              }; // end screenType

            };

            //#endregion
            function scale_call() {
              console.log('scale_call()');

                console.log('update scales HEART');
                
                let valueHeartRate = heart_rate.last;
                let targetHeartRate = 184;
                let progressHeartRate = (valueHeartRate - 30)/(targetHeartRate - 30);
                if (progressHeartRate < 0) progressHeartRate = 0;
                if (progressHeartRate > 1) progressHeartRate = 1;
                let progress_ls_normal_heart_rate = progressHeartRate;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_heart_rate_linear_scale
                  // initial parameters
                  let start_x_normal_heart_rate = 395;
                  let start_y_normal_heart_rate = 306;
                  let lenght_ls_normal_heart_rate = 49;
                  let line_width_ls_normal_heart_rate = 11;
                  let color_ls_normal_heart_rate = 0xFFFF0000;
                  
                  // calculated parameters
                  let start_x_normal_heart_rate_draw = start_x_normal_heart_rate;
                  let start_y_normal_heart_rate_draw = start_y_normal_heart_rate;
                  lenght_ls_normal_heart_rate = lenght_ls_normal_heart_rate * progress_ls_normal_heart_rate;
                  let lenght_ls_normal_heart_rate_draw = lenght_ls_normal_heart_rate;
                  let line_width_ls_normal_heart_rate_draw = line_width_ls_normal_heart_rate;
                  if (lenght_ls_normal_heart_rate < 0){
                    lenght_ls_normal_heart_rate_draw = -lenght_ls_normal_heart_rate;
                    start_x_normal_heart_rate_draw = start_x_normal_heart_rate - lenght_ls_normal_heart_rate_draw;
                  };
                  
                  normal_heart_rate_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_heart_rate_draw,
                    y: start_y_normal_heart_rate_draw,
                    w: lenght_ls_normal_heart_rate_draw,
                    h: line_width_ls_normal_heart_rate_draw,
                    radius: 5,
                    color: color_ls_normal_heart_rate,
                  });
                };

                console.log('update scales PAI');
                
                let valuePAI = pai.totalpai;
                let targetPAI = 100;
                let progressPAI = valuePAI/targetPAI;
                if (progressPAI > 1) progressPAI = 1;
                let progress_ls_normal_pai = progressPAI;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_pai_linear_scale
                  // initial parameters
                  let start_x_normal_pai = 322;
                  let start_y_normal_pai = 306;
                  let lenght_ls_normal_pai = 49;
                  let line_width_ls_normal_pai = 11;
                  let color_ls_normal_pai = 0xFFFF00FF;
                  
                  // calculated parameters
                  let start_x_normal_pai_draw = start_x_normal_pai;
                  let start_y_normal_pai_draw = start_y_normal_pai;
                  lenght_ls_normal_pai = lenght_ls_normal_pai * progress_ls_normal_pai;
                  let lenght_ls_normal_pai_draw = lenght_ls_normal_pai;
                  let line_width_ls_normal_pai_draw = line_width_ls_normal_pai;
                  if (lenght_ls_normal_pai < 0){
                    lenght_ls_normal_pai_draw = -lenght_ls_normal_pai;
                    start_x_normal_pai_draw = start_x_normal_pai - lenght_ls_normal_pai_draw;
                  };
                  
                  normal_pai_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_pai_draw,
                    y: start_y_normal_pai_draw,
                    w: lenght_ls_normal_pai_draw,
                    h: line_width_ls_normal_pai_draw,
                    radius: 5,
                    color: color_ls_normal_pai,
                  });
                };

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_cs_normal_step = progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_step * 100);
                  if (normal_step_circle_scale) {
                    normal_step_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 134,
                      center_y: 66,
                      start_angle: 0,
                      end_angle: 360,
                      radius: 28,
                      line_width: 9,
                      corner_flag: 3,
                      color: 0xFFBCFF00,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_ls_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_linear_scale
                  // initial parameters
                  let start_x_normal_battery = 45;
                  let start_y_normal_battery = 341;
                  let lenght_ls_normal_battery = 335;
                  let line_width_ls_normal_battery = 18;
                  let color_ls_normal_battery = 0xFFBCFF00;
                  
                  // calculated parameters
                  let start_x_normal_battery_draw = start_x_normal_battery;
                  let start_y_normal_battery_draw = start_y_normal_battery;
                  lenght_ls_normal_battery = lenght_ls_normal_battery * progress_ls_normal_battery;
                  let lenght_ls_normal_battery_draw = lenght_ls_normal_battery;
                  let line_width_ls_normal_battery_draw = line_width_ls_normal_battery;
                  if (lenght_ls_normal_battery < 0){
                    lenght_ls_normal_battery_draw = -lenght_ls_normal_battery;
                    start_x_normal_battery_draw = start_x_normal_battery - lenght_ls_normal_battery_draw;
                  };
                  
                  normal_battery_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_battery_draw,
                    y: start_y_normal_battery_draw,
                    w: lenght_ls_normal_battery_draw,
                    h: line_width_ls_normal_battery_draw,
                    radius: 9,
                    color: color_ls_normal_battery,
                  });
                  
                  // pointers parameters
                  let pointer_offset_x_ls_normal_battery = 69;
                  let pointer_offset_y_ls_normal_battery = 17;
                  normal_battery_linear_scale_pointer_img.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_battery + lenght_ls_normal_battery - pointer_offset_x_ls_normal_battery,
                    y: start_y_normal_battery_draw + line_width_ls_normal_battery / 2 - pointer_offset_y_ls_normal_battery,
                    src: 'Batt_Pointer.png',
                    show_level: hmUI.show_level.ONLY_NORMAL,
                  });
                };

                console.log('update scales HEART');
                let progress_ls_idle_heart_rate = progressHeartRate;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_heart_rate_linear_scale
                  // initial parameters
                  let start_x_idle_heart_rate = 395;
                  let start_y_idle_heart_rate = 306;
                  let lenght_ls_idle_heart_rate = 49;
                  let line_width_ls_idle_heart_rate = 11;
                  let color_ls_idle_heart_rate = 0xFFFF0000;
                  
                  // calculated parameters
                  let start_x_idle_heart_rate_draw = start_x_idle_heart_rate;
                  let start_y_idle_heart_rate_draw = start_y_idle_heart_rate;
                  lenght_ls_idle_heart_rate = lenght_ls_idle_heart_rate * progress_ls_idle_heart_rate;
                  let lenght_ls_idle_heart_rate_draw = lenght_ls_idle_heart_rate;
                  let line_width_ls_idle_heart_rate_draw = line_width_ls_idle_heart_rate;
                  if (lenght_ls_idle_heart_rate < 0){
                    lenght_ls_idle_heart_rate_draw = -lenght_ls_idle_heart_rate;
                    start_x_idle_heart_rate_draw = start_x_idle_heart_rate - lenght_ls_idle_heart_rate_draw;
                  };
                  
                  idle_heart_rate_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_idle_heart_rate_draw,
                    y: start_y_idle_heart_rate_draw,
                    w: lenght_ls_idle_heart_rate_draw,
                    h: line_width_ls_idle_heart_rate_draw,
                    radius: 5,
                    color: color_ls_idle_heart_rate,
                  });
                };

                console.log('update scales PAI');
                let progress_ls_idle_pai = progressPAI;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_pai_linear_scale
                  // initial parameters
                  let start_x_idle_pai = 322;
                  let start_y_idle_pai = 306;
                  let lenght_ls_idle_pai = 49;
                  let line_width_ls_idle_pai = 11;
                  let color_ls_idle_pai = 0xFFFF00FF;
                  
                  // calculated parameters
                  let start_x_idle_pai_draw = start_x_idle_pai;
                  let start_y_idle_pai_draw = start_y_idle_pai;
                  lenght_ls_idle_pai = lenght_ls_idle_pai * progress_ls_idle_pai;
                  let lenght_ls_idle_pai_draw = lenght_ls_idle_pai;
                  let line_width_ls_idle_pai_draw = line_width_ls_idle_pai;
                  if (lenght_ls_idle_pai < 0){
                    lenght_ls_idle_pai_draw = -lenght_ls_idle_pai;
                    start_x_idle_pai_draw = start_x_idle_pai - lenght_ls_idle_pai_draw;
                  };
                  
                  idle_pai_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_idle_pai_draw,
                    y: start_y_idle_pai_draw,
                    w: lenght_ls_idle_pai_draw,
                    h: line_width_ls_idle_pai_draw,
                    radius: 5,
                    color: color_ls_idle_pai,
                  });
                };

                console.log('update scales STEP');
                let progress_cs_idle_step = progressStep;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_step_circle_scale_circle_scale
                  let level = Math.round(progress_cs_idle_step * 100);
                  if (idle_step_circle_scale) {
                    idle_step_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 134,
                      center_y: 66,
                      start_angle: 0,
                      end_angle: 360,
                      radius: 28,
                      line_width: 9,
                      corner_flag: 3,
                      color: 0xFFBCFF00,
                      show_level: hmUI.show_level.ONLY_AOD,
                      level: level,
                    });
                  };
                };

                console.log('update scales BATTERY');
                let progress_ls_idle_battery = progressBattery;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_battery_linear_scale
                  // initial parameters
                  let start_x_idle_battery = 45;
                  let start_y_idle_battery = 341;
                  let lenght_ls_idle_battery = 335;
                  let line_width_ls_idle_battery = 18;
                  let color_ls_idle_battery = 0xFFBCFF00;
                  
                  // calculated parameters
                  let start_x_idle_battery_draw = start_x_idle_battery;
                  let start_y_idle_battery_draw = start_y_idle_battery;
                  lenght_ls_idle_battery = lenght_ls_idle_battery * progress_ls_idle_battery;
                  let lenght_ls_idle_battery_draw = lenght_ls_idle_battery;
                  let line_width_ls_idle_battery_draw = line_width_ls_idle_battery;
                  if (lenght_ls_idle_battery < 0){
                    lenght_ls_idle_battery_draw = -lenght_ls_idle_battery;
                    start_x_idle_battery_draw = start_x_idle_battery - lenght_ls_idle_battery_draw;
                  };
                  
                  idle_battery_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_idle_battery_draw,
                    y: start_y_idle_battery_draw,
                    w: lenght_ls_idle_battery_draw,
                    h: line_width_ls_idle_battery_draw,
                    radius: 9,
                    color: color_ls_idle_battery,
                  });
                  
                  // pointers parameters
                  let pointer_offset_x_ls_idle_battery = 69;
                  let pointer_offset_y_ls_idle_battery = 17;
                  idle_battery_linear_scale_pointer_img.setProperty(hmUI.prop.MORE, {
                    x: start_x_idle_battery + lenght_ls_idle_battery - pointer_offset_x_ls_idle_battery,
                    y: start_y_idle_battery_draw + line_width_ls_idle_battery / 2 - pointer_offset_y_ls_idle_battery,
                    src: 'Batt_Pointer.png',
                    show_level: hmUI.show_level.ONLY_AOD,
                  });
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                text_update();
                sleep_update();
                if (screenType == hmSetting.screen_type.AOD) {
                  if (!idle_timerTextUpdate) {
                    idle_timerTextUpdate = timer.createTimer(0, 1000, (function (option) {
                      text_update();
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                console.log('pause_call()');

                if (array_sleep_chart.length > 0) {
                console.log('deleteWidget screen off');
                  for (let i = 0; i < array_sleep_chart.length; i++) {
                    if (array_sleep_chart[i]) hmUI.deleteWidget(array_sleep_chart[i]);
                  }
                  array_sleep_chart = [];
                } // end if
                if (idle_timerTextUpdate) {
                  timer.stopTimer(idle_timerTextUpdate);
                  idle_timerTextUpdate = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                heart_rate.removeEventListener(heart.event.CURRENT, hrCurrListener);
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
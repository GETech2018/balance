﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_humidity_text_text_img = ''
        let normal_battery_text_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_step_current_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_second_circle_scale = ''
        let normal_timerUpdateSecCircle = undefined;
        let normal_minute_circle_scale = ''
        let normal_timerUpdateSec = undefined;
        let normal_hour_circle_scale = ''
        let normal_digital_clock_img_time_second = ''
        let normal_digital_clock_img_time_minute = ''
        let normal_digital_clock_img_time_hour = ''
        let idle_background_bg_img = ''
        let idle_moon_image_progress_img_level = ''
        let idle_humidity_text_text_img = ''
        let idle_battery_text_text_img = ''
        let idle_heart_rate_text_text_img = ''
        let idle_calorie_current_text_img = ''
        let idle_step_current_text_img = ''
        let idle_distance_text_text_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_day = ''
        let idle_weather_image_progress_img_level = ''
        let idle_temperature_current_text_img = ''
        let idle_second_circle_scale = ''
        let idle_timerUpdateSec = undefined;
        let idle_minute_circle_scale = ''
        let idle_hour_circle_scale = ''
        let idle_digital_clock_img_time_second = ''
        let idle_digital_clock_img_time_minute = ''
        let idle_digital_clock_img_time_hour = ''
        let image_top_img = ''
        let normal_step_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_moon_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'BG1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 437,
              y: 225,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 355,
              y: 388,
              font_array: ["Heart_0.png","Heart_1.png","Heart_2.png","Heart_3.png","Heart_4.png","Heart_5.png","Heart_6.png","Heart_7.png","Heart_8.png","Heart_9.png"],
              padding: false,
              h_space: 1,
              unit_sc: '0023.png',
              unit_tc: '0023.png',
              unit_en: '0023.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 76,
              y: 389,
              font_array: ["Heart_0.png","Heart_1.png","Heart_2.png","Heart_3.png","Heart_4.png","Heart_5.png","Heart_6.png","Heart_7.png","Heart_8.png","Heart_9.png"],
              padding: false,
              h_space: 1,
              unit_sc: '0023.png',
              unit_tc: '0023.png',
              unit_en: '0023.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 4,
              y: 244,
              font_array: ["Heart_0.png","Heart_1.png","Heart_2.png","Heart_3.png","Heart_4.png","Heart_5.png","Heart_6.png","Heart_7.png","Heart_8.png","Heart_9.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 68,
              y: 348,
              font_array: ["0039.png","0040.png","0041.png","0042.png","0043.png","0044.png","0045.png","0046.png","0047.png","0048.png"],
              padding: true,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 54,
              y: 317,
              font_array: ["0039.png","0040.png","0041.png","0042.png","0043.png","0044.png","0045.png","0046.png","0047.png","0048.png"],
              padding: true,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 39,
              y: 288,
              font_array: ["0039.png","0040.png","0041.png","0042.png","0043.png","0044.png","0045.png","0046.png","0047.png","0048.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Dis_KM.png',
              unit_tc: 'Dis_KM.png',
              unit_en: 'Dis_KM.png',
              imperial_unit_sc: 'Dis_KM.png',
              imperial_unit_tc: 'Dis_KM.png',
              imperial_unit_en: 'Dis_KM.png',
              dot_image: 'Dis_Dot.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 231,
              y: 461,
              src: 'System_BT_OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 235,
              y: 223,
              src: 'System_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 273,
              month_startY: 30,
              month_sc_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_tc_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_en_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 127,
              y: 31,
              week_en: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              week_tc: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              week_sc: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 216,
              day_startY: 22,
              day_sc_array: ["Act_s_0.png","Act_s_1.png","Act_s_2.png","Act_s_3.png","Act_s_4.png","Act_s_5.png","Act_s_6.png","Act_s_7.png","Act_s_8.png","Act_s_9.png"],
              day_tc_array: ["Act_s_0.png","Act_s_1.png","Act_s_2.png","Act_s_3.png","Act_s_4.png","Act_s_5.png","Act_s_6.png","Act_s_7.png","Act_s_8.png","Act_s_9.png"],
              day_en_array: ["Act_s_0.png","Act_s_1.png","Act_s_2.png","Act_s_3.png","Act_s_4.png","Act_s_5.png","Act_s_6.png","Act_s_7.png","Act_s_8.png","Act_s_9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 366,
              y: 316,
              image_array: ["Weather_01.png","Weather_02.png","Weather_03.png","Weather_04.png","Weather_05.png","Weather_06.png","Weather_07.png","Weather_08.png","Weather_09.png","Weather_10.png","Weather_11.png","Weather_12.png","Weather_13.png","Weather_14.png","Weather_15.png","Weather_16.png","Weather_17.png","Weather_18.png","Weather_19.png","Weather_20.png","Weather_21.png","Weather_22.png","Weather_23.png","Weather_24.png","Weather_25.png","Weather_26.png","Weather_27.png","Weather_28.png","Weather_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 354,
              y: 287,
              font_array: ["Act_s_0.png","Act_s_1.png","Act_s_2.png","Act_s_3.png","Act_s_4.png","Act_s_5.png","Act_s_6.png","Act_s_7.png","Act_s_8.png","Act_s_9.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'TempC.png',
              unit_tc: 'TempC.png',
              unit_en: 'TempC.png',
              imperial_unit_sc: 'TempF.png',
              imperial_unit_tc: 'TempF.png',
              imperial_unit_en: 'TempF.png',
              negative_image: 'Temp_Error.png',
              invalid_image: 'Temp_Error.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const temperatureUnit = hmSetting.getTemperatureUnit();
            //#region temperatureUnit
            if (temperatureUnit == 1) {
              normal_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
                x: 354,
                y: 287,
                font_array: ["Act_s_0.png","Act_s_1.png","Act_s_2.png","Act_s_3.png","Act_s_4.png","Act_s_5.png","Act_s_6.png","Act_s_7.png","Act_s_8.png","Act_s_9.png"],
                padding: false,
                h_space: 2,
                unit_sc: 'TempF.png',
                unit_tc: 'TempF.png',
                unit_en: 'TempF.png',
                imperial_unit_sc: 'TempC.png',
                imperial_unit_tc: 'TempC.png',
                imperial_unit_en: 'TempC.png',
                negative_image: 'Temp_Error.png',
                invalid_image: 'Temp_Error.png',
                align_h: hmUI.align.CENTER_H,
                type: hmUI.data_type.WEATHER_CURRENT,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
            };
            //#endregion

            // normal_second_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 239,
              // center_y: 353,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 105,
              // line_width: 9,
              // line_cap: Flat,
              // color: 0xFFA4A4A4,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.SECOND,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_second_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 239,
              center_y: 353,
              start_angle: 0,
              end_angle: 360,
              radius: 101,
              line_width: 9,
              corner_flag: 3,
              color: 0xFFA4A4A4,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            let screenType = hmSetting.getScreenType();
            // normal_minute_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 349,
              // center_y: 169,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 105,
              // line_width: 9,
              // line_cap: Flat,
              // color: 0xFFFF1C1C,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.MINUTE,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_minute_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 349,
              center_y: 169,
              start_angle: 0,
              end_angle: 360,
              radius: 101,
              line_width: 9,
              corner_flag: 3,
              color: 0xFFFF1C1C,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            timeSensor.addEventListener(timeSensor.event.MINUTEEND, function() {
              time_update(true, true);
            });

            // normal_hour_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 130,
              // center_y: 169,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 105,
              // line_width: 9,
              // line_cap: Flat,
              // color: 0xFF1188FF,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.HOUR,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_hour_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 130,
              center_y: 169,
              start_angle: 0,
              end_angle: 360,
              radius: 101,
              line_width: 9,
              corner_flag: 3,
              color: 0xFF1188FF,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_time_circle_options = hmUI.createWidget(hmUI.widget.TIME_CIRCLE_OPTIONS, {
              // smooth: true,
              // format24h: false,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_digital_clock_img_time_second = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              second_startX: 172,
              second_startY: 310,
              second_array: ["Time_S_0.png","Time_S_1.png","Time_S_2.png","Time_S_3.png","Time_S_4.png","Time_S_5.png","Time_S_6.png","Time_S_7.png","Time_S_8.png","Time_S_9.png"],
              second_zero: 1,
              second_space: 5,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 283,
              minute_startY: 121,
              minute_array: ["Time_M_0.png","Time_M_1.png","Time_M_2.png","Time_M_3.png","Time_M_4.png","Time_M_5.png","Time_M_6.png","Time_M_7.png","Time_M_8.png","Time_M_9.png"],
              minute_zero: 1,
              minute_space: 5,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 63,
              hour_startY: 121,
              hour_array: ["Time_H_0.png","Time_H_1.png","Time_H_2.png","Time_H_3.png","Time_H_4.png","Time_H_5.png","Time_H_6.png","Time_H_7.png","Time_H_8.png","Time_H_9.png"],
              hour_zero: 1,
              hour_space: 5,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'BG1.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 437,
              y: 225,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 355,
              y: 388,
              font_array: ["Heart_0.png","Heart_1.png","Heart_2.png","Heart_3.png","Heart_4.png","Heart_5.png","Heart_6.png","Heart_7.png","Heart_8.png","Heart_9.png"],
              padding: false,
              h_space: 1,
              unit_sc: '0023.png',
              unit_tc: '0023.png',
              unit_en: '0023.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 76,
              y: 389,
              font_array: ["Heart_0.png","Heart_1.png","Heart_2.png","Heart_3.png","Heart_4.png","Heart_5.png","Heart_6.png","Heart_7.png","Heart_8.png","Heart_9.png"],
              padding: false,
              h_space: 1,
              unit_sc: '0023.png',
              unit_tc: '0023.png',
              unit_en: '0023.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 4,
              y: 244,
              font_array: ["Heart_0.png","Heart_1.png","Heart_2.png","Heart_3.png","Heart_4.png","Heart_5.png","Heart_6.png","Heart_7.png","Heart_8.png","Heart_9.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 68,
              y: 348,
              font_array: ["0039.png","0040.png","0041.png","0042.png","0043.png","0044.png","0045.png","0046.png","0047.png","0048.png"],
              padding: true,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 54,
              y: 317,
              font_array: ["0039.png","0040.png","0041.png","0042.png","0043.png","0044.png","0045.png","0046.png","0047.png","0048.png"],
              padding: true,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 39,
              y: 288,
              font_array: ["0039.png","0040.png","0041.png","0042.png","0043.png","0044.png","0045.png","0046.png","0047.png","0048.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Dis_KM.png',
              unit_tc: 'Dis_KM.png',
              unit_en: 'Dis_KM.png',
              imperial_unit_sc: 'Dis_KM.png',
              imperial_unit_tc: 'Dis_KM.png',
              imperial_unit_en: 'Dis_KM.png',
              dot_image: 'Dis_Dot.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 231,
              y: 461,
              src: 'System_BT_OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 235,
              y: 223,
              src: 'System_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 273,
              month_startY: 30,
              month_sc_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_tc_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_en_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 127,
              y: 31,
              week_en: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              week_tc: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              week_sc: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 216,
              day_startY: 22,
              day_sc_array: ["Act_s_0.png","Act_s_1.png","Act_s_2.png","Act_s_3.png","Act_s_4.png","Act_s_5.png","Act_s_6.png","Act_s_7.png","Act_s_8.png","Act_s_9.png"],
              day_tc_array: ["Act_s_0.png","Act_s_1.png","Act_s_2.png","Act_s_3.png","Act_s_4.png","Act_s_5.png","Act_s_6.png","Act_s_7.png","Act_s_8.png","Act_s_9.png"],
              day_en_array: ["Act_s_0.png","Act_s_1.png","Act_s_2.png","Act_s_3.png","Act_s_4.png","Act_s_5.png","Act_s_6.png","Act_s_7.png","Act_s_8.png","Act_s_9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 366,
              y: 316,
              image_array: ["Weather_01.png","Weather_02.png","Weather_03.png","Weather_04.png","Weather_05.png","Weather_06.png","Weather_07.png","Weather_08.png","Weather_09.png","Weather_10.png","Weather_11.png","Weather_12.png","Weather_13.png","Weather_14.png","Weather_15.png","Weather_16.png","Weather_17.png","Weather_18.png","Weather_19.png","Weather_20.png","Weather_21.png","Weather_22.png","Weather_23.png","Weather_24.png","Weather_25.png","Weather_26.png","Weather_27.png","Weather_28.png","Weather_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 354,
              y: 287,
              font_array: ["Act_s_0.png","Act_s_1.png","Act_s_2.png","Act_s_3.png","Act_s_4.png","Act_s_5.png","Act_s_6.png","Act_s_7.png","Act_s_8.png","Act_s_9.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'TempC.png',
              unit_tc: 'TempC.png',
              unit_en: 'TempC.png',
              imperial_unit_sc: 'TempF.png',
              imperial_unit_tc: 'TempF.png',
              imperial_unit_en: 'TempF.png',
              negative_image: 'Temp_Error.png',
              invalid_image: 'Temp_Error.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            //#region temperatureUnit
            if (temperatureUnit == 1) {
              idle_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
                x: 354,
                y: 287,
                font_array: ["Act_s_0.png","Act_s_1.png","Act_s_2.png","Act_s_3.png","Act_s_4.png","Act_s_5.png","Act_s_6.png","Act_s_7.png","Act_s_8.png","Act_s_9.png"],
                padding: false,
                h_space: 2,
                unit_sc: 'TempF.png',
                unit_tc: 'TempF.png',
                unit_en: 'TempF.png',
                imperial_unit_sc: 'TempC.png',
                imperial_unit_tc: 'TempC.png',
                imperial_unit_en: 'TempC.png',
                negative_image: 'Temp_Error.png',
                invalid_image: 'Temp_Error.png',
                align_h: hmUI.align.CENTER_H,
                type: hmUI.data_type.WEATHER_CURRENT,
                show_level: hmUI.show_level.ONLY_AOD,
              });
            };
            //#endregion

            // idle_second_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 239,
              // center_y: 353,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 105,
              // line_width: 9,
              // line_cap: Flat,
              // color: 0xFFA4A4A4,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.SECOND,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });


            idle_second_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 239,
              center_y: 353,
              start_angle: 0,
              end_angle: 360,
              radius: 101,
              line_width: 9,
              corner_flag: 3,
              color: 0xFFA4A4A4,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_minute_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 349,
              // center_y: 169,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 105,
              // line_width: 9,
              // line_cap: Flat,
              // color: 0xFFFF1C1C,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.MINUTE,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });


            idle_minute_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 349,
              center_y: 169,
              start_angle: 0,
              end_angle: 360,
              radius: 101,
              line_width: 9,
              corner_flag: 3,
              color: 0xFFFF1C1C,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_hour_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 130,
              // center_y: 169,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 105,
              // line_width: 9,
              // line_cap: Flat,
              // color: 0xFF1188FF,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.HOUR,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });


            idle_hour_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 130,
              center_y: 169,
              start_angle: 0,
              end_angle: 360,
              radius: 101,
              line_width: 9,
              corner_flag: 3,
              color: 0xFF1188FF,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_time_circle_options = hmUI.createWidget(hmUI.widget.TIME_CIRCLE_OPTIONS, {
              // smooth: false,
              // format24h: false,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });


            idle_digital_clock_img_time_second = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              second_startX: 172,
              second_startY: 310,
              second_array: ["Time_S_0.png","Time_S_1.png","Time_S_2.png","Time_S_3.png","Time_S_4.png","Time_S_5.png","Time_S_6.png","Time_S_7.png","Time_S_8.png","Time_S_9.png"],
              second_zero: 1,
              second_space: 5,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 283,
              minute_startY: 121,
              minute_array: ["Time_M_0.png","Time_M_1.png","Time_M_2.png","Time_M_3.png","Time_M_4.png","Time_M_5.png","Time_M_6.png","Time_M_7.png","Time_M_8.png","Time_M_9.png"],
              minute_zero: 1,
              minute_space: 5,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 63,
              hour_startY: 121,
              hour_array: ["Time_H_0.png","Time_H_1.png","Time_H_2.png","Time_H_3.png","Time_H_4.png","Time_H_5.png","Time_H_6.png","Time_H_7.png","Time_H_8.png","Time_H_9.png"],
              hour_zero: 1,
              hour_space: 5,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            image_top_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'Top1.png',
              show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 19,
              y: 308,
              w: 110,
              h: 30,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 2,
              y: 221,
              w: 52,
              h: 39,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 33,
              y: 344,
              w: 94,
              h: 31,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 439,
              y: 221,
              w: 36,
              h: 44,
              type: hmUI.data_type.MOON_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 372,
              y: 282,
              w: 66,
              h: 59,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 311,
              y: 131,
              w: 81,
              h: 69,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 199,
              y: 313,
              w: 79,
              h: 69,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 220,
              y: 203,
              w: 43,
              h: 53,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 83,
              y: 388,
              w: 58,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PowerSaveHintScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 216,
              y: 50,
              w: 50,
              h: 52,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            //#region time_update
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              // Second Circle
              let normal_secondCircleProgress = 100 * (second + (timeSensor.utc % 1000)/1000)/60;
              if (normal_second_circle_scale) normal_second_circle_scale.setProperty(hmUI.prop.LEVEL, normal_secondCircleProgress );

              if (updateMinute) { // Minute Circle
                let normal_minuteCircleProgress = minute/60 +(second / 60) / 60;
                normal_minuteCircleProgress = normal_minuteCircleProgress * 100;
                if (normal_minute_circle_scale) normal_minute_circle_scale.setProperty(hmUI.prop.LEVEL, normal_minuteCircleProgress );
              };

              if (updateMinute) { // Hour Circle
                let normal_circle_scale_hour = hour;
                if (normal_circle_scale_hour > 11) normal_circle_scale_hour -= 12;
                let normal_hourCircleProgress = normal_circle_scale_hour/12 + (minute/60)/12;
                normal_hourCircleProgress = normal_hourCircleProgress * 100;
                if (normal_hour_circle_scale) normal_hour_circle_scale.setProperty(hmUI.prop.LEVEL, normal_hourCircleProgress );
              };

              // Second Circle
              let idle_secondCircleProgress = 100 * second/60;
              if (idle_second_circle_scale) idle_second_circle_scale.setProperty(hmUI.prop.LEVEL, idle_secondCircleProgress );

              if (updateMinute) { // Minute Circle
                let idle_minuteCircleProgress = minute/60;
                idle_minuteCircleProgress = idle_minuteCircleProgress * 100;
                if (idle_minute_circle_scale) idle_minute_circle_scale.setProperty(hmUI.prop.LEVEL, idle_minuteCircleProgress );
              };

              if (updateMinute) { // Hour Circle
                let idle_circle_scale_hour = hour;
                if (idle_circle_scale_hour > 11) idle_circle_scale_hour -= 12;
                let idle_hourCircleProgress = idle_circle_scale_hour/12 + (minute/60)/12;
                idle_hourCircleProgress = idle_hourCircleProgress * 100;
                if (idle_hour_circle_scale) idle_hour_circle_scale.setProperty(hmUI.prop.LEVEL, idle_hourCircleProgress );
              };

            };

            //#endregion
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                time_update(true, true);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSecCircle) {
                    let animDelay = 0;
                    let animRepeat = 1000/12;
                    normal_timerUpdateSecCircle = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, false);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSec) {
                    let animDelay = timeSensor.utc % 1000;
                    let animRepeat = 1000;
                    normal_timerUpdateSec = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, true);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.AOD) {
                  if (!idle_timerUpdateSec) {
                    let animDelay = timeSensor.utc % 1000;
                    let animRepeat = 1000;
                    idle_timerUpdateSec = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, false);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerUpdateSecCircle) {
                  timer.stopTimer(normal_timerUpdateSecCircle);
                  normal_timerUpdateSecCircle = undefined;
                }
                if (normal_timerUpdateSec) {
                  timer.stopTimer(normal_timerUpdateSec);
                  normal_timerUpdateSec = undefined;
                }
                if (idle_timerUpdateSec) {
                  timer.stopTimer(idle_timerUpdateSec);
                  idle_timerUpdateSec = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
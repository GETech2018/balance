﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_sleep_text_img = ''
        let normal_stress_text_text_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_month_img = ''
        let normal_altitude_target_text_img = ''
        let normal_stand_target_text_img = ''
        let normal_stand_current_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_distance_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_battery_text_text_img = ''
        let normal_battery_text_separator_img = ''
        let normal_readiness_text_text_img = ''
        let normal_readiness_image_progress_img_level = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg_img = ''
        let idle_stress_text_text_img = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_month_img = ''
        let idle_altitude_target_text_img = ''
        let idle_stand_target_text_img = ''
        let idle_stand_current_text_img = ''
        let idle_calorie_current_text_img = ''
        let idle_heart_rate_text_text_img = ''
        let idle_distance_text_text_img = ''
        let idle_step_current_text_img = ''
        let idle_step_image_progress_img_level = ''
        let idle_battery_text_text_img = ''
        let idle_battery_text_separator_img = ''
        let idle_readiness_text_text_img = ''
        let idle_readiness_image_progress_img_level = ''
        let idle_digital_clock_img_time = ''
        let normal_step_jumpable_img_click = ''
        let normal_cal_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_battery_jumpable_img_click = ''
        let normal_stand_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_sleep_jumpable_img_click = ''
        let normal_altitude_jumpable_img_click = ''
        let normal_readiness_jumpable_img_click = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sleep_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 270,
              y: 111,
              font_array: ["data_0.png","data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png"],
              padding: false,
              h_space: 0,
              dot_image: 'dotsl.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SLEEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 327,
              y: 350,
              font_array: ["bpm_0.png","bpm_1.png","bpm_2.png","bpm_3.png","bpm_4.png","bpm_5.png","bpm_6.png","bpm_7.png","bpm_8.png","bpm_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STRESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 249,
              day_startY: 28,
              day_sc_array: ["date_0.png","date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png","date_8.png","date_9.png"],
              day_tc_array: ["date_0.png","date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png","date_8.png","date_9.png"],
              day_en_array: ["date_0.png","date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png","date_8.png","date_9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 161,
              month_startY: 28,
              month_sc_array: ["m_0.png","m_1.png","m_2.png","m_3.png","m_4.png","m_5.png","m_6.png","m_7.png","m_8.png","m_9.png","m_10.png","m_11.png"],
              month_tc_array: ["m_0.png","m_1.png","m_2.png","m_3.png","m_4.png","m_5.png","m_6.png","m_7.png","m_8.png","m_9.png","m_10.png","m_11.png"],
              month_en_array: ["m_0.png","m_1.png","m_2.png","m_3.png","m_4.png","m_5.png","m_6.png","m_7.png","m_8.png","m_9.png","m_10.png","m_11.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altitude_target_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 353,
              y: 111,
              font_array: ["data_0.png","data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'm.png',
              unit_tc: 'm.png',
              unit_en: 'm.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.ALTITUDE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_target_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 196,
              y: 111,
              font_array: ["data_0.png","data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STAND_TARGET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 124,
              y: 111,
              font_array: ["data_0.png","data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png"],
              padding: true,
              h_space: 0,
              unit_sc: 'fenhao.png',
              unit_tc: 'fenhao.png',
              unit_en: 'fenhao.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STAND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 54,
              y: 111,
              font_array: ["data_0.png","data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 99,
              y: 350,
              font_array: ["bpm_0.png","bpm_1.png","bpm_2.png","bpm_3.png","bpm_4.png","bpm_5.png","bpm_6.png","bpm_7.png","bpm_8.png","bpm_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 111,
              y: 381,
              image_array: ["h_1.png","h_2.png","h_3.png","h_4.png","h_5.png","h_6.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 354,
              y: 269,
              font_array: ["dist_0.png","dist_1.png","dist_2.png","dist_3.png","dist_4.png","dist_5.png","dist_6.png","dist_7.png","dist_8.png","dist_9.png"],
              padding: false,
              h_space: -2,
              unit_sc: 'km.png',
              unit_tc: 'km.png',
              unit_en: 'km.png',
              dot_image: 'dot.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 182,
              y: 273,
              font_array: ["step_0.png","step_1.png","step_2.png","step_3.png","step_4.png","step_5.png","step_6.png","step_7.png","step_8.png","step_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 74,
              y: 276,
              image_array: ["stplvl_1.png","stplvl_2.png","stplvl_3.png","stplvl_4.png","stplvl_5.png","stplvl_6.png","stplvl_7.png","stplvl_8.png","stplvl_9.png","stplvl_10.png"],
              image_length: 10,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 219,
              y: 312,
              font_array: ["batt_0.png","batt_1.png","batt_2.png","batt_3.png","batt_4.png","batt_5.png","batt_6.png","batt_7.png","batt_8.png","batt_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'unit.png',
              unit_tc: 'unit.png',
              unit_en: 'unit.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 194,
              y: 312,
              src: 'icon.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_readiness_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 198,
              y: 355,
              font_array: ["read_0.png","read_1.png","read_2.png","read_3.png","read_4.png","read_5.png","read_6.png","read_7.png","read_8.png","read_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.READINESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_readiness_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 0,
              y: 332,
              image_array: ["lvlread_1.png","lvlread_2.png","lvlread_3.png","lvlread_4.png","lvlread_5.png","lvlread_6.png","lvlread_7.png","lvlread_8.png","lvlread_9.png","lvlread_10.png","lvlread_11.png","lvlread_12.png","lvlread_13.png","lvlread_14.png","lvlread_15.png","lvlread_16.png","lvlread_17.png","lvlread_18.png","lvlread_19.png","lvlread_20.png"],
              image_length: 20,
              type: hmUI.data_type.READINESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 26,
              hour_startY: 152,
              hour_array: ["time_0.png","time_1.png","time_2.png","time_3.png","time_4.png","time_5.png","time_6.png","time_7.png","time_8.png","time_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 254,
              minute_startY: 152,
              minute_array: ["time_0.png","time_1.png","time_2.png","time_3.png","time_4.png","time_5.png","time_6.png","time_7.png","time_8.png","time_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'aodbg.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_stress_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 327,
              y: 350,
              font_array: ["aodbpm_0.png","aodbpm_1.png","aodbpm_2.png","aodbpm_3.png","aodbpm_4.png","aodbpm_5.png","aodbpm_6.png","aodbpm_7.png","aodbpm_8.png","aodbpm_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STRESS,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 249,
              day_startY: 28,
              day_sc_array: ["aoddate_0.png","aoddate_1.png","aoddate_2.png","aoddate_3.png","aoddate_4.png","aoddate_5.png","aoddate_6.png","aoddate_7.png","aoddate_8.png","aoddate_9.png"],
              day_tc_array: ["aoddate_0.png","aoddate_1.png","aoddate_2.png","aoddate_3.png","aoddate_4.png","aoddate_5.png","aoddate_6.png","aoddate_7.png","aoddate_8.png","aoddate_9.png"],
              day_en_array: ["aoddate_0.png","aoddate_1.png","aoddate_2.png","aoddate_3.png","aoddate_4.png","aoddate_5.png","aoddate_6.png","aoddate_7.png","aoddate_8.png","aoddate_9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 161,
              month_startY: 28,
              month_sc_array: ["aodm_0.png","aodm_1.png","aodm_2.png","aodm_3.png","aodm_4.png","aodm_5.png","aodm_6.png","aodm_7.png","aodm_8.png","aodm_9.png","aodm_10.png","aodm_11.png"],
              month_tc_array: ["aodm_0.png","aodm_1.png","aodm_2.png","aodm_3.png","aodm_4.png","aodm_5.png","aodm_6.png","aodm_7.png","aodm_8.png","aodm_9.png","aodm_10.png","aodm_11.png"],
              month_en_array: ["aodm_0.png","aodm_1.png","aodm_2.png","aodm_3.png","aodm_4.png","aodm_5.png","aodm_6.png","aodm_7.png","aodm_8.png","aodm_9.png","aodm_10.png","aodm_11.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_altitude_target_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 303,
              y: 111,
              font_array: ["aoddata_0.png","aoddata_1.png","aoddata_2.png","aoddata_3.png","aoddata_4.png","aoddata_5.png","aoddata_6.png","aoddata_7.png","aoddata_8.png","aoddata_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'aodm.png',
              unit_tc: 'aodm.png',
              unit_en: 'aodm.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.ALTITUDE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_stand_target_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 246,
              y: 111,
              font_array: ["aoddata_0.png","aoddata_1.png","aoddata_2.png","aoddata_3.png","aoddata_4.png","aoddata_5.png","aoddata_6.png","aoddata_7.png","aoddata_8.png","aoddata_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STAND_TARGET,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_stand_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 174,
              y: 111,
              font_array: ["aoddata_0.png","aoddata_1.png","aoddata_2.png","aoddata_3.png","aoddata_4.png","aoddata_5.png","aoddata_6.png","aoddata_7.png","aoddata_8.png","aoddata_9.png"],
              padding: true,
              h_space: 0,
              unit_sc: 'aodfenhao.png',
              unit_tc: 'aodfenhao.png',
              unit_en: 'aodfenhao.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STAND,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 104,
              y: 111,
              font_array: ["aoddata_0.png","aoddata_1.png","aoddata_2.png","aoddata_3.png","aoddata_4.png","aoddata_5.png","aoddata_6.png","aoddata_7.png","aoddata_8.png","aoddata_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 99,
              y: 350,
              font_array: ["aodbpm_0.png","aodbpm_1.png","aodbpm_2.png","aodbpm_3.png","aodbpm_4.png","aodbpm_5.png","aodbpm_6.png","aodbpm_7.png","aodbpm_8.png","aodbpm_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 354,
              y: 269,
              font_array: ["aodbpm_0.png","aodbpm_1.png","aodbpm_2.png","aodbpm_3.png","aodbpm_4.png","aodbpm_5.png","aodbpm_6.png","aodbpm_7.png","aodbpm_8.png","aodbpm_9.png"],
              padding: false,
              h_space: -2,
              unit_sc: 'aodkm.png',
              unit_tc: 'aodkm.png',
              unit_en: 'aodkm.png',
              dot_image: 'aoddot.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 182,
              y: 273,
              font_array: ["aodstep_0.png","aodstep_1.png","aodstep_2.png","aodstep_3.png","aodstep_4.png","aodstep_5.png","aodstep_6.png","aodstep_7.png","aodstep_8.png","aodstep_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 74,
              y: 276,
              image_array: ["aodsteplvl_1.png","aodsteplvl_2.png","aodsteplvl_3.png","aodsteplvl_4.png","aodsteplvl_5.png","aodsteplvl_6.png","aodsteplvl_7.png","aodsteplvl_8.png","aodsteplvl_9.png","aodsteplvl_10.png"],
              image_length: 10,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 219,
              y: 312,
              font_array: ["batt_0.png","batt_1.png","batt_2.png","batt_3.png","batt_4.png","batt_5.png","batt_6.png","batt_7.png","batt_8.png","batt_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'unit.png',
              unit_tc: 'unit.png',
              unit_en: 'unit.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 194,
              y: 312,
              src: 'icon.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_readiness_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 198,
              y: 355,
              font_array: ["aodread_0.png","aodread_1.png","aodread_2.png","aodread_3.png","aodread_4.png","aodread_5.png","aodread_6.png","aodread_7.png","aodread_8.png","aodread_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.READINESS,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_readiness_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 0,
              y: 332,
              image_array: ["aodlvlread_1.png","aodlvlread_2.png","aodlvlread_3.png","aodlvlread_4.png","aodlvlread_5.png","aodlvlread_6.png","aodlvlread_7.png","aodlvlread_8.png","aodlvlread_9.png","aodlvlread_10.png","aodlvlread_11.png","aodlvlread_12.png","aodlvlread_13.png","aodlvlread_14.png","aodlvlread_15.png","aodlvlread_16.png","aodlvlread_17.png","aodlvlread_18.png","aodlvlread_19.png","aodlvlread_20.png"],
              image_length: 20,
              type: hmUI.data_type.READINESS,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 26,
              hour_startY: 152,
              hour_array: ["aodtime_0.png","aodtime_1.png","aodtime_2.png","aodtime_3.png","aodtime_4.png","aodtime_5.png","aodtime_6.png","aodtime_7.png","aodtime_8.png","aodtime_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 254,
              minute_startY: 152,
              minute_array: ["aodtime_0.png","aodtime_1.png","aodtime_2.png","aodtime_3.png","aodtime_4.png","aodtime_5.png","aodtime_6.png","aodtime_7.png","aodtime_8.png","aodtime_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 170,
              y: 252,
              w: 103,
              h: 52,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_cal_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 43,
              y: 82,
              w: 82,
              h: 62,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 77,
              y: 335,
              w: 82,
              h: 82,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 188,
              y: 309,
              w: 103,
              h: 44,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 147,
              y: 82,
              w: 82,
              h: 62,
              type: hmUI.data_type.STAND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 67,
              y: 155,
              w: 103,
              h: 88,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 299,
              y: 155,
              w: 103,
              h: 88,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sleep_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 249,
              y: 82,
              w: 82,
              h: 62,
              type: hmUI.data_type.SLEEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altitude_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 352,
              y: 82,
              w: 82,
              h: 62,
              type: hmUI.data_type.ALTITUDE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_readiness_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 188,
              y: 361,
              w: 103,
              h: 72,
              type: hmUI.data_type.READINESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
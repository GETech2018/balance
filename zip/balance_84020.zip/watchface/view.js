import * as hmUI from "@zos/ui";

export function buildView() {

    console.log('in view buildview');

    hmUI.createWidget(hmUI.widget.IMG, {
        x: px(0),
        y: px(0),
        w: px(480),
        h: px(480),
        src: 'bg.png',
        show_level: hmUI.show_level.ONLY_AOD,
    });

    hmUI.createWidget(hmUI.widget.TIME_POINTER, {
        hour_centerX: 240,
        hour_centerY: 240,
        hour_posX: 15,
        hour_posY: 149,
        hour_path: 'hour.png',
        minute_centerX: 240,
        minute_centerY: 240,
        minute_posX: 15,
        minute_posY: 212,
        minute_path: 'minute.png',
        second_centerX: 240,
        second_centerY: 240,
        second_posX: 17,
        second_posY: 172,
        second_path: 'second.png',
        show_level: hmUI.show_level.ONLY_AOD,
    });

    hmUI.createWidget(hmUI.widget.TIME_POINTER, {
        hour_centerX: 240,
        hour_centerY: 240,
        hour_posX: 15,
        hour_posY: 149,
        hour_path: 'hour-aod.png',
        minute_centerX: 240,
        minute_centerY: 240,
        minute_posX: 15,
        minute_posY: 212,
        minute_path: 'minute-aod.png',
        show_level: hmUI.show_level.ONLY_NORMAL,
    });
}

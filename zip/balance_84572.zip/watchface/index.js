﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_heart_rate_text_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_week_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''
        let normal_heart_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'FOND0001.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 381,
              y: 209,
              font_array: ["MINI00.png","MINI01.png","MINI02.png","MINI03.png","MINI04.png","MINI05.png","MINI06.png","MINI07.png","MINI08.png","MINI09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'MINI13.png',
              unit_tc: 'MINI13.png',
              unit_en: 'MINI13.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 364,
              y: 174,
              image_array: ["ENE01.png","ENE02.png","ENE03.png","ENE04.png","ENE05.png","ENE06.png","ENE07.png","ENE08.png","ENE09.png","ENE10.png","ENE11.png","ENE12.png","ENE13.png","ENE14.png","ENE15.png","ENE16.png","ENE17.png","ENE18.png","ENE19.png","ENE20.png","ENE21.png","ENE22.png","ENE23.png","ENE24.png","ENE25.png","ENE26.png","ENE27.png","ENE28.png"],
              image_length: 28,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 222,
              y: 125,
              font_array: ["INI00.png","INI01.png","INI02.png","INI03.png","INI04.png","INI05.png","INI06.png","INI07.png","INI08.png","INI09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 34,
              y: 237,
              font_array: ["INI00.png","INI01.png","INI02.png","INI03.png","INI04.png","INI05.png","INI06.png","INI07.png","INI08.png","INI09.png"],
              padding: false,
              h_space: 0,
              dot_image: 'INI10.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 22,
              y: 204,
              font_array: ["MINI00.png","MINI01.png","MINI02.png","MINI03.png","MINI04.png","MINI05.png","MINI06.png","MINI07.png","MINI08.png","MINI09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 176,
              month_startY: 226,
              month_sc_array: ["M01.png","M02.png","M03.png","M04.png","M05.png","M06.png","M07.png","M08.png","M09.png","M10.png","M11.png","M12.png"],
              month_tc_array: ["M01.png","M02.png","M03.png","M04.png","M05.png","M06.png","M07.png","M08.png","M09.png","M10.png","M11.png","M12.png"],
              month_en_array: ["M01.png","M02.png","M03.png","M04.png","M05.png","M06.png","M07.png","M08.png","M09.png","M10.png","M11.png","M12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 198,
              day_startY: 158,
              day_sc_array: ["NU00.png","NU01.png","NU02.png","NU03.png","NU04.png","NU05.png","NU06.png","NU07.png","NU08.png","NU09.png"],
              day_tc_array: ["NU00.png","NU01.png","NU02.png","NU03.png","NU04.png","NU05.png","NU06.png","NU07.png","NU08.png","NU09.png"],
              day_en_array: ["NU00.png","NU01.png","NU02.png","NU03.png","NU04.png","NU05.png","NU06.png","NU07.png","NU08.png","NU09.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 92,
              y: 7,
              week_en: ["Ssem01.png","Ssem02.png","Ssem03.png","Ssem04.png","Ssem05.png","Ssem06.png","Ssem07.png"],
              week_tc: ["Ssem01.png","Ssem02.png","Ssem03.png","Ssem04.png","Ssem05.png","Ssem06.png","Ssem07.png"],
              week_sc: ["Ssem01.png","Ssem02.png","Ssem03.png","Ssem04.png","Ssem05.png","Ssem06.png","Ssem07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 324,
              y: 262,
              src: 'BT1.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 134,
              y: 260,
              src: 'alarme.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 82,
              hour_startY: 321,
              hour_array: ["H00.png","H01.png","H02.png","H03.png","H04.png","H05.png","H06.png","H07.png","H08.png","H09.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 255,
              minute_startY: 321,
              minute_array: ["H11.png","H12.png","H13.png","H14.png","H15.png","H16.png","H17.png","H18.png","H19.png","H20.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 213,
              second_startY: 420,
              second_array: ["miniG00.png","miniG01.png","miniG02.png","miniG03.png","miniG04.png","miniG05.png","miniG06.png","miniG07.png","miniG08.png","miniG09.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 228,
              y: 320,
              src: 'H21.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 176,
              month_startY: 226,
              month_sc_array: ["M01.png","M02.png","M03.png","M04.png","M05.png","M06.png","M07.png","M08.png","M09.png","M10.png","M11.png","M12.png"],
              month_tc_array: ["M01.png","M02.png","M03.png","M04.png","M05.png","M06.png","M07.png","M08.png","M09.png","M10.png","M11.png","M12.png"],
              month_en_array: ["M01.png","M02.png","M03.png","M04.png","M05.png","M06.png","M07.png","M08.png","M09.png","M10.png","M11.png","M12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 200,
              day_startY: 143,
              day_sc_array: ["NU00.png","NU01.png","NU02.png","NU03.png","NU04.png","NU05.png","NU06.png","NU07.png","NU08.png","NU09.png"],
              day_tc_array: ["NU00.png","NU01.png","NU02.png","NU03.png","NU04.png","NU05.png","NU06.png","NU07.png","NU08.png","NU09.png"],
              day_en_array: ["NU00.png","NU01.png","NU02.png","NU03.png","NU04.png","NU05.png","NU06.png","NU07.png","NU08.png","NU09.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 92,
              y: 7,
              week_en: ["Ssem01.png","Ssem02.png","Ssem03.png","Ssem04.png","Ssem05.png","Ssem06.png","Ssem07.png"],
              week_tc: ["Ssem01.png","Ssem02.png","Ssem03.png","Ssem04.png","Ssem05.png","Ssem06.png","Ssem07.png"],
              week_sc: ["Ssem01.png","Ssem02.png","Ssem03.png","Ssem04.png","Ssem05.png","Ssem06.png","Ssem07.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 324,
              y: 262,
              src: 'BT1.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 134,
              y: 260,
              src: 'alarme.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 82,
              hour_startY: 321,
              hour_array: ["H00.png","H01.png","H02.png","H03.png","H04.png","H05.png","H06.png","H07.png","H08.png","H09.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 255,
              minute_startY: 321,
              minute_array: ["H11.png","H12.png","H13.png","H14.png","H15.png","H16.png","H17.png","H18.png","H19.png","H20.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 220,
              second_startY: 420,
              second_array: ["miniG00.png","miniG01.png","miniG02.png","miniG03.png","miniG04.png","miniG05.png","miniG06.png","miniG07.png","miniG08.png","miniG09.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 228,
              y: 320,
              src: 'H21.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 9,
              // disconneсnt_toast_text: BT OFF,
              // conneсnt_vibrate_type: 9,
              // conneсnt_toast_text: BT ON,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              console.log('checkConnection()');
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  hmUI.showToast({text: "BT OFF"});
                  vibro(9);
                }
                if(status) {
                  hmUI.showToast({text: "BT ON"});
                  vibro(9);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              if (scene != 1) timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function
            console.log('Watch_Face.Shortcuts');

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 188,
              y: 102,
              w: 100,
              h: 50,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 124,
              y: 250,
              w: 50,
              h: 50,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                checkConnection();
                stopVibro();

              }),
              pause_call: (function () {
                console.log('pause_call()');
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
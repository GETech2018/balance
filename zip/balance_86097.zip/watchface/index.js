﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
              
      
        const { width: DEVICE_WIDTH, height: DEVICE_HEIGHT} = hmSetting.getDeviceInfo();
        const radius = DEVICE_WIDTH / 2, centerX = DEVICE_WIDTH / 2, centerY = DEVICE_HEIGHT / 2
      
        const curTime = hmSensor.createSensor(hmSensor.id.TIME);
        const weather = hmSensor.createSensor(hmSensor.id.WEATHER);
      
        let weatherImg, tempText, cityNameText, tempMinText, tempMaxText, tempFeelsText, descriptionText
        let weatherProvider
        
        const vibrator = hmSensor.createSensor(hmSensor.id.VIBRATE);
        let stopVibro_Timer = null;
    
        function vibro(mode = 25, stopDelay = 30) {
            vibrator.stop();
            vibrator.scene = mode;
            vibrator.start();
            stopVibro_Timer = setTimeout(() => {
              stopVibro();
            }, stopDelay);
        }		
    
        function stopVibro(){
            vibrator.stop();
            if (stopVibro_Timer) clearTimeout(stopVibro_Timer);
        } 
 

        class WeatherProvider {
          constructor(props = {}) {
            this.props = {
              night_icons: [],											// индексы иконок для замены день-ночь
              index: hmFS.SysProGetInt('WeatherProviderIndex') ?? 0,		// текущий индекс провайдера (сохраняется и считывается из памяти)
              show_toast: true,											// показывать всплывающее сообщение при переключении провайдера
              temp_widget: null,											// виджет TEXT для отображения температуры
              temp_max_widget: null,										// виджет TEXT для отображения максимальной температуры
              temp_min_widget: null,										// виджет TEXT для отображения минимальной температуры
              temp_feels_widget: null,									// виджет TEXT для отображения ощущаемой температуры
              description_widget: null,									// виджет TEXT для отображения текстового описания текущей погоды
              cityName_widget: null,										// виджет TEXT для отображения названия города
              icon_widget: null,											// виджет IMG для отображения значка погоды
              time_sensor: null,											// сенсор времени, если не задан, то создается новый
              weather_sensor: null,										// сенсор погоды, если не задан, то создается новый
              file_name: 'weather.json',									// имя файла с погодными данными
              auto_update: true,											// автоматическое обновление погоды (нет необходимости добавлять weatherProvider.update() в event.MINUTEEND и WIDGET_DELEGATE)
              lang: hmSetting.getLanguage() == 4 ? 0 : 1,					// языка устройства	(Русский = 0 / Английский = 1)
              ...props,
            };
            this.providers = [
              {name: ['Zepp', 'Zepp'], appId: null},							// 0
              {name: ['Погодный сервис', 'Weather service'], appId: 1065824},	// 1 
              //{name: ['RuWeather', 'RWeather'], appId: 1066654},				// 2
            ]

            this.description = [
                ['Облачно', 'Временами дождь', 'Временами снег', 'Ясно', 'Пасмурно', 'Слабый дождь', 'Слабый снег', 'Умеренный дождь', 'Умеренный снег', 'Сильный снегопад', 'Сильный дождь', 'Песчаная буря', 'Мокрый снег', 'Туман', 'Дымка', 'Дождь с грозой', 'Метель', 'Пыльно', 'Ливень', 'Дождь с градом', 'Сильный дождь с градом', 'Сильный дождь', 'Пыльная буря', 'Сильная песчаная буря', 'Сильный дождь', 'Обновите погоду', 'Облачно ночью', 'Дождливо ночью', 'Ясно ночью'],
                ['Cloudy', 'Showers', 'Snow Showers', 'Sunny', 'Overcast', 'Light Rain', 'Light Snow', 'Moderate Rain', 'Moderate Snow', 'Heavy Snow', 'Heavy Rain', 'Sandstorm', 'Rain and Snow', 'Fog', 'Hazy', 'T-Storms', 'Snowstorm', 'Floating dust', 'Very Heavy Rainstorm', 'Rain and Hail', 'T-Storms and Hail', 'Heavy Rainstorm', 'Dust', 'Heavy sand storm', 'Rainstorm', 'Unknown', 'Cloudy Nighttime', 'Showers Nighttime', 'Sunny Nighttime'],
              ]      
              
            this.last = {
                weatherIcon: 25,
                weatherDescription:  'Нет данных',
                temperature: '--',
                temperatureFeels: '--',
                temperatureMax: '--',
                temperatureMin: '--',
                cityName: '--',
                modTime: null,
            }      
            
            if (!this.props.time_sensor) this.props.time_sensor = hmSensor.createSensor(hmSensor.id.TIME);
            if (!this.props.weather_sensor) this.props.weather_sensor = hmSensor.createSensor(hmSensor.id.WEATHER);
            if (isFinite(props.index)) hmFS.SysProSetInt('WeatherProviderIndex', props.index);
            if (this.props.auto_update) this.createHandlers();
        } 
        
        
        createHandlers() {
          this.props.time_sensor.addEventListener(this.props.time_sensor.event.MINUTEEND, () => this.update());

          this.widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
            resume_call: ( () => this.update() )
          })
        }   
        
        arrayBufferToCyrillic(buffer) {
          let result = '';
          const bytes = new Uint8Array(buffer);

          let i = 0;
          while (i < bytes.length) {
              let byte1 = bytes[i++];
          
              if (byte1 < 0x80) {								// Обработка 1-байтовых символов (ASCII)
                result += String.fromCharCode(byte1);
              } else if (byte1 >= 0xC0 && byte1 < 0xE0) {		// Обработка 2-байтовых символов (UTF-8 кодировка для кириллицы)
                let byte2 = bytes[i++];
                let charCode = ((byte1 & 0x1F) << 6) | (byte2 & 0x3F);
                result += String.fromCharCode(charCode);
              } else if (byte1 >= 0xE0 && byte1 < 0xF0) {		// Обработка 3-байтовых символов (например, для UTF-8)
                let byte2 = bytes[i++];
                let byte3 = bytes[i++];
                let charCode = ((byte1 & 0x0F) << 12) | ((byte2 & 0x3F) << 6) | (byte3 & 0x3F);
                result += String.fromCharCode(charCode);
              }
          }

          return result
        } 
        
        readFile(app_id) {
          if (!app_id) return null				
          let str_result = "";
          try {
              const [fs_stat, err] = hmFS.stat(this.props.file_name, {
                  appid: app_id,
              });
              if (err == 0) {
                  const fh = hmFS.open(this.props.file_name, hmFS.O_RDONLY, {
                  appid: app_id,
                  });

                  const len = fs_stat.size;
                  let array_buffer = new ArrayBuffer(len);
                  hmFS.read(fh, array_buffer, 0, len);
                  hmFS.close(fh);
                  str_result = this.arrayBufferToCyrillic(array_buffer);

                  return str_result;
              } else {
                  console.log("err:", err);
              }
          } catch (error) {
          console.log("error:", error);
          console.log("FAIL: No access to hmFS.");
          }
          return null;
        }    
        
        getFileModTime(app_id) {
          if (!app_id) return null
          try {
              const [fs_stat, err] = hmFS.stat(this.props.file_name, {
                  appid: app_id,
              });
          
              if (err == 0) {
                  return fs_stat.mtime
              } else {
                  console.log("ModTime err:", err);
              }
          } catch (error) {
            console.log("ModTime error:", error);
            console.log("FAIL: No access to hmFS.");
          }
            return null
        }  
        
        isDayNow() {
          const sunData = this.props.weather_sensor.getForecastWeather().tideData;
          let sunriseMins = 8 * 60;			// время восхода
          let sunsetMins = 20 * 60;			// и заката по умолчанию

          if (sunData.count > 0){
              const today = sunData.data[0];
              sunriseMins = today.sunrise.hour * 60 + today.sunrise.minute;
              sunsetMins = today.sunset.hour * 60 + today.sunset.minute;
          }

          const curMins = curTime.hour * 60 + curTime.minute;
          const nowIsDay = (curMins >= sunriseMins) && (curMins < sunsetMins);

          return nowIsDay
        }  
        
        getZeppIconIndex(index, app_id = null) {
                        
          if (!app_id)  return index;			//	если нет app_id, то не меняем индекс иконки

          let newIndex = 25;
          
          if (app_id == 1065824) {					// WeatherService
              switch(index) {
              case 1:
                      newIndex = 3;
                  break;
              case 2:
                      newIndex = 0;
                  break;
              case 3:
              case 4:
                      newIndex = 4;
                  break;
              case 5:
                      newIndex = 1;
                  break;
              case 6:
                      newIndex = 5;
                  break;
              case 7:
                      newIndex = 10;
                  break;
              case 8:
                      newIndex = 15;
                  break;
              case 9:
                      newIndex = 6;
                  break;
              case 10:
                      newIndex = 8;
                  break;
              case 11:
                      newIndex = 9;
                  break;
              case 12:
                      newIndex = 12;
                  break;
              case 13:
                      newIndex = 13;
                  break;
              case 14:
                      newIndex = 17;
                  break;
              default:
                      newIndex = 25;
                  break;
              }
          } else if (app_id == 1066654) {					// 
              newIndex = index - 1;
          }

          return newIndex
        }  
       
        tempWithSign(val){
          val = parseFloat(val);
          if (!isFinite(val)) return '--'		// если на входе не число - возвращаем прочерки
          val = Math.round(val);
          if (val > 0) val = '+' + val;
          val += '°';
          
          return val
        }    
        
        getZeppWeatherData() {
          const iconIndex = this.props.weather_sensor.curAirIconIndex ?? 25;
          const data = {
              weatherIcon: iconIndex,
              weatherDescription:  this.description[this.props.lang][iconIndex],
              temperature: this.props.weather_sensor.current ?? '--',
              temperatureFeels: '--',
              temperatureMax: this.props.weather_sensor.high ?? '--',
              temperatureMin: this.props.weather_sensor.low ?? '--',
              cityName: this.props.weather_sensor.getForecastWeather().cityName ?? '--',
          }

          return data
        }  
        
        getAppWeatherData(app_id) {
          const data = {
              weatherIcon: 25,
              weatherDescription:  'Нет данных',
              temperature: '--',
              temperatureFeels: '--',
              temperatureMax: '--',
              temperatureMin: '--',
              cityName: '--',
          }
          
          let weather_str = this.readFile(app_id);
          let weatherJson = JSON.parse(weather_str);

          if (weatherJson) {
              if (isFinite(weatherJson.weatherIcon)) {		// считываем индекс иконки погоды и сразу переводим в нумерацию Zepp
                  data.weatherIcon = this.getZeppIconIndex(parseInt(weatherJson.weatherIcon), app_id);
              }

              if (weatherJson?.weatherDescriptionExtended?.length) {
                  data.weatherDescription = weatherJson.weatherDescriptionExtended;
                  data.weatherDescription = data.weatherDescription.replace(data.weatherDescription[0], data.weatherDescription[0].toUpperCase());
              } else data.weatherDescription = this.description[data.weatherIcon];

              if (isFinite(weatherJson.temperature)) {
                  data.temperature = parseFloat(weatherJson.temperature);
                  data.temperature = Math.round(data.temperature);
              }
              
              if (isFinite(weatherJson.temperatureFeels)){
                  data.temperatureFeels = parseFloat(weatherJson.temperatureFeels);
                  data.temperatureFeels = Math.round(data.temperatureFeels);
              }
                  
              if (isFinite(weatherJson.temperatureMax)){
                  data.temperatureMax = parseFloat(weatherJson.temperatureMax);
                  data.temperatureMax = Math.round(data.temperatureMax);
              }
                  
              if (isFinite(weatherJson.temperatureMin)){
                  data.temperatureMin = parseFloat(weatherJson.temperatureMin);
                  data.temperatureMin = Math.round(data.temperatureMin);
              }
              
              if (weatherJson.city) {
                  data.cityName = weatherJson.city;
              }
          }
          
          return data
        }  
        
        getWeatherData(app_id = null) {
          if (!app_id) return this.getZeppWeatherData()		// если нет app_id, то получаем данные от Zepp
          else return this.getAppWeatherData(app_id);			// иначе читаем данные из файла данных приложения
        }  
        
        update() {
          let curIcon = parseInt(this.last.weatherIcon);				// текущий индекс значка погоды без учета времени суток (т.е. число без "n")

          const modTime = this.getFileModTime(this.providers[this.props.index].appId);		// время изменеия файла с данными
          
          if (!modTime || this.last.modTime != modTime){										// если не получено время изменеия или оно отличается от последнего времени изменеия
              const newData = this.getWeatherData(this.providers[this.props.index].appId);	// тогда читаем новые данные из файла
              this.last.modTime = modTime;

              let val = this.tempWithSign(newData.temperature);
              if (val != this.last.temperature){
                  this.last.temperature = val;
                  if (this.props.temp_widget) this.props.temp_widget.setProperty(hmUI.prop.TEXT, val);
              }

              val = this.tempWithSign(newData.temperatureMax);
              if (val != this.last.temperatureMax){
                  this.last.temperatureMax = val;
                  if (this.props.temp_max_widget) this.props.temp_max_widget.setProperty(hmUI.prop.TEXT, val);
              }

              val = this.tempWithSign(newData.temperatureMin);
              if (val != this.last.temperatureMin){
                  this.last.temperatureMin = val;
                  if (this.props.temp_min_widget) this.props.temp_min_widget.setProperty(hmUI.prop.TEXT, val);
              }

              val = this.tempWithSign(newData.temperatureFeels);
              if (val != this.last.temperatureFeels){
                  this.last.temperatureFeels = val;
                  if (this.props.temp_feels_widget) this.props.temp_feels_widget.setProperty(hmUI.prop.TEXT, val);
              }

              val = newData.cityName;
              if (val != this.last.cityName){
                  this.last.cityName = val;
                  if (this.props.cityName_widget) this.props.cityName_widget.setProperty(hmUI.prop.TEXT, val);
              }

              val = newData.weatherDescription;
              if (val != this.last.weatherDescription){
                  this.last.weatherDescription = val;
                  if (this.props.description_widget) this.props.description_widget.setProperty(hmUI.prop.TEXT, val);
              }

              
              curIcon = newData.weatherIcon;						// получаем текущий индекс значка погоды
          }

          if (this.props.night_icons.includes(curIcon) && !this.isDayNow()){		// если он в списке ночных иконок и сейчас "ночь", то добавляем суффикс 'n'
              curIcon += 'n';
          }

          if (curIcon != this.last.weatherIcon){
              this.last.weatherIcon = curIcon;
              if (this.props.icon_widget) this.props.icon_widget.setProperty(hmUI.prop.SRC, `w_${curIcon}.png`);
          }
        } 
        
        next(show_toast = this.props.show_toast) {
          const v = (this.props.index + 1) % this.providers.length;
          this.provider = v;
          if (show_toast) hmUI.showToast({text: this.name});
        }        
        
        prev(show_toast = this.props.show_toast) {
          const v = (this.props.index - 1 + this.providers.length) % this.providers.length;
          this.provider = v;
          if (show_toast) hmUI.showToast({text: this.name});
        }   
        
        toggle(dir, show_toast = this.props.show_toast) {
          if (dir > 0) this.next(show_toast)
          else this.prev(show_toast);
        }   
        
        set provider(v) {
          this.props.index = v;
          hmFS.SysProSetInt('WeatherProviderIndex', v);
          this.update();
        }   
        
        get index() {
          return this.props.index
        }     
      
        
        get name() {
            return this.providers[this.props.index].name[this.props.lang]
        }    
        
        get cityName() {
          return this.last.cityName
        }     
        
        get temperature() {
          return this.last.temperature
        }   
        
        get temperatureMax() {
          return this.last.temperatureMax
        }

        
        get temperatureMin() {
            return this.last.temperatureMin
        }        

          
        get weatherDescription() {
            return this.last.weatherDescription
        }      
        
       delete() {
          this.providers = null;
          this.props = null;
          this.last = null;
          this.description = null;
          if (this.widgetDelegate) {
              hmUI.deleteWidget(this.widgetDelegate);
              this.widgetDelegate = null;
          }
       }

      } 
      // start user_functions.js
const {
  width: D_W,
  height: D_H
} = hmSetting.getDeviceInfo();
        //end of ignored block

        //dynamic modify start
        let btn_bezel = ''
        let bezel_num = 1
        let bezel_all = 5
        
        let normal_background_bg_img = ''
        let normal_image_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_heart_rate_text_font = ''
        let normal_step_current_text_font = ''
        let normal_battery_text_text_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_digital_clock_img_time = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let idle_background_bg_img = ''
        let idle_image_img = ''
        let idle_moon_image_progress_img_level = ''
        let idle_heart_rate_text_font = ''
        let idle_step_current_text_font = ''
        let idle_battery_text_text_img = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_day = ''
        let idle_city_name_text = ''
        let idle_weather_image_progress_img_level = ''
        let idle_temperature_current_text_font = ''
        let idle_digital_clock_img_time = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let normal_step_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_battery_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''        


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
            function click_Bezel() {
              if(bezel_num>=bezel_all) {bezel_num=1;}
              else { bezel_num=bezel_num+1;}
              hmUI.showToast({text: "Основной " + parseInt(bezel_num) });
                normal_background_bg_img.setProperty(hmUI.prop.SRC, "zapl_" + parseInt(bezel_num) + ".png");

            }                     
                
            // FontName: GoogleSans-Regular.ttf; FontSize: 31
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 427,
              h: 48,
              text_size: 31,
              char_space: 0,
              line_space: 0,
              font: 'fonts/GoogleSans-Regular.ttf',
              color: 0xFF000000,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: GoogleSans-Regular.ttf; FontSize: 25; Cache: full
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 30,
              h: 30,
              text_size: 25,
              char_space: 0,
              line_space: 0,
              font: 'fonts/GoogleSans-Regular.ttf',
              color: 0xFF000000,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.NONE,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: GoogleSans-Regular.ttf; FontSize: 30
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 412,
              h: 46,
              text_size: 30,
              char_space: 0,
              line_space: 0,
              font: 'fonts/GoogleSans-Regular.ttf',
              color: 0xFF000000,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'zapl_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'osn_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 386,
              y: 326,
              image_array: ["moon_1.png","moon_2.png","moon_3.png","moon_4.png","moon_5.png","moon_6.png","moon_7.png","moon_8.png","moon_9.png","moon_10.png","moon_11.png","moon_12.png","moon_13.png","moon_14.png","moon_15.png","moon_16.png","moon_17.png","moon_18.png","moon_19.png","moon_20.png","moon_21.png","moon_22.png","moon_23.png","moon_24.png","moon_25.png","moon_26.png","moon_27.png","moon_28.png","moon_29.png","moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 68,
              y: 397,
              w: 150,
              h: 40,
              text_size: 31,
              char_space: 0,
              font: 'fonts/GoogleSans-Regular.ttf',
              color: 0xFF000000,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 263,
              y: 397,
              w: 150,
              h: 40,
              text_size: 31,
              char_space: 0,
              font: 'fonts/GoogleSans-Regular.ttf',
              color: 0xFF000000,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 200,
              y: 402,
              font_array: ["zr_0.png","zr_1.png","zr_2.png","zr_3.png","zr_4.png","zr_5.png","zr_6.png","zr_7.png","zr_8.png","zr_9.png"],
              padding: true,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 33,
              month_startY: 329,
              month_sc_array: ["mon_0.png","mon_1.png","mon_2.png","mon_3.png","mon_4.png","mon_5.png","mon_6.png","mon_7.png","mon_8.png","mon_9.png","mon_10.png","mon_11.png"],
              month_tc_array: ["mon_0.png","mon_1.png","mon_2.png","mon_3.png","mon_4.png","mon_5.png","mon_6.png","mon_7.png","mon_8.png","mon_9.png","mon_10.png","mon_11.png"],
              month_en_array: ["mon_0.png","mon_1.png","mon_2.png","mon_3.png","mon_4.png","mon_5.png","mon_6.png","mon_7.png","mon_8.png","mon_9.png","mon_10.png","mon_11.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 33,
              y: 110,
              week_en: ["day_0.png","day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png"],
              week_tc: ["day_0.png","day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png"],
              week_sc: ["day_0.png","day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 17,
              day_startY: 159,
              day_sc_array: ["Sekk_0.png","Sekk_1.png","Sekk_2.png","Sekk_3.png","Sekk_4.png","Sekk_5.png","Sekk_6.png","Sekk_7.png","Sekk_8.png","Sekk_9.png"],
              day_tc_array: ["Sekk_0.png","Sekk_1.png","Sekk_2.png","Sekk_3.png","Sekk_4.png","Sekk_5.png","Sekk_6.png","Sekk_7.png","Sekk_8.png","Sekk_9.png"],
              day_en_array: ["Sekk_0.png","Sekk_1.png","Sekk_2.png","Sekk_3.png","Sekk_4.png","Sekk_5.png","Sekk_6.png","Sekk_7.png","Sekk_8.png","Sekk_9.png"],
              day_zero: 1,
              day_space: -1,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const weatherInfo = hmUI.createWidget(hmUI.widget.GROUP, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
            });
              
            weatherImg = weatherInfo.createWidget(hmUI.widget.IMG, {
                x: 384,
                y: 101,
                w: 80,
                h: 80,
                src: 'w_25.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
            }); 
              
            tempText = weatherInfo.createWidget(hmUI.widget.TEXT, {
                x: 166,
                y: 8,
                w: 150,
                h: 35,
                text_size: 30,
                char_space: 0,
                line_space: 0,
                font: 'fonts/GoogleSans-Regular.ttf',
                text: '--',
                color: 0xFF000000,
                align_h: hmUI.align.CENTER_H,
                align_v: hmUI.align.TOP,
                unit_type: 1,
                text_style: hmUI.text_style.ELLIPSIS,
                show_level: hmUI.show_level.ONLY_NORMAL,
            });   
              
            descriptionText = hmUI.createWidget(hmUI.widget.TEXT, {
                x: 135,
                y: 44,
                w: 214,
                h: 30,
                text_size: 25,
                char_space: 0,
                line_space: 0,
                font: 'fonts/GoogleSans-Regular.ttf',
                text: '--',
                color: 0xFF000000,
                align_h: hmUI.align.CENTER_H,
                align_v: hmUI.align.TOP,
                text_style: hmUI.text_style.ELLIPSIS,
                show_level: hmUI.show_level.ONLY_NORMAL,
            }); 
         

            // экземпляр класса
            weatherProvider = new WeatherProvider({
                night_icons: [0, 1, 2, 3, 14],
                show_toast: false,
                temp_widget: tempText,
                temp_max_widget: tempMaxText,
                temp_min_widget: tempMinText,
                temp_feels_widget: tempFeelsText,
                description_widget: descriptionText,
                cityName_widget: cityNameText,
                icon_widget: weatherImg,
                time_sensor: curTime,
                weather_sensor: weather,
            });                

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 101,
              hour_startY: 80,
              hour_array: ["H_0.png","H_1.png","H_2.png","H_3.png","H_4.png","H_5.png","H_6.png","H_7.png","H_8.png","H_9.png"],
              hour_zero: 1,
              hour_space: -2,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 247,
              minute_startY: 80,
              minute_array: ["H_0.png","H_1.png","H_2.png","H_3.png","H_4.png","H_5.png","H_6.png","H_7.png","H_8.png","H_9.png"],
              minute_zero: 1,
              minute_space: -2,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 378,
              second_startY: 159,
              second_array: ["Sekk_0.png","Sekk_1.png","Sekk_2.png","Sekk_3.png","Sekk_4.png","Sekk_5.png","Sekk_6.png","Sekk_7.png","Sekk_8.png","Sekk_9.png"],
              second_zero: 1,
              second_space: -1,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 204,
              y: 310,
              src: 'bt_off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 220,
              y: 127,
              src: 'alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img.setAlpha(80);


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'zapl_1.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'osn_1.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 386,
              y: 326,
              image_array: ["moon_1.png","moon_2.png","moon_3.png","moon_4.png","moon_5.png","moon_6.png","moon_7.png","moon_8.png","moon_9.png","moon_10.png","moon_11.png","moon_12.png","moon_13.png","moon_14.png","moon_15.png","moon_16.png","moon_17.png","moon_18.png","moon_19.png","moon_20.png","moon_21.png","moon_22.png","moon_23.png","moon_24.png","moon_25.png","moon_26.png","moon_27.png","moon_28.png","moon_29.png","moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 68,
              y: 397,
              w: 150,
              h: 40,
              text_size: 31,
              char_space: 0,
              font: 'fonts/GoogleSans-Regular.ttf',
              color: 0xFF000000,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 263,
              y: 397,
              w: 150,
              h: 40,
              text_size: 31,
              char_space: 0,
              font: 'fonts/GoogleSans-Regular.ttf',
              color: 0xFF000000,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 200,
              y: 402,
              font_array: ["zr_0.png","zr_1.png","zr_2.png","zr_3.png","zr_4.png","zr_5.png","zr_6.png","zr_7.png","zr_8.png","zr_9.png"],
              padding: true,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 33,
              month_startY: 329,
              month_sc_array: ["mon_0.png","mon_1.png","mon_2.png","mon_3.png","mon_4.png","mon_5.png","mon_6.png","mon_7.png","mon_8.png","mon_9.png","mon_10.png","mon_11.png"],
              month_tc_array: ["mon_0.png","mon_1.png","mon_2.png","mon_3.png","mon_4.png","mon_5.png","mon_6.png","mon_7.png","mon_8.png","mon_9.png","mon_10.png","mon_11.png"],
              month_en_array: ["mon_0.png","mon_1.png","mon_2.png","mon_3.png","mon_4.png","mon_5.png","mon_6.png","mon_7.png","mon_8.png","mon_9.png","mon_10.png","mon_11.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 33,
              y: 110,
              week_en: ["day_0.png","day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png"],
              week_tc: ["day_0.png","day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png"],
              week_sc: ["day_0.png","day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 17,
              day_startY: 159,
              day_sc_array: ["Sekk_0.png","Sekk_1.png","Sekk_2.png","Sekk_3.png","Sekk_4.png","Sekk_5.png","Sekk_6.png","Sekk_7.png","Sekk_8.png","Sekk_9.png"],
              day_tc_array: ["Sekk_0.png","Sekk_1.png","Sekk_2.png","Sekk_3.png","Sekk_4.png","Sekk_5.png","Sekk_6.png","Sekk_7.png","Sekk_8.png","Sekk_9.png"],
              day_en_array: ["Sekk_0.png","Sekk_1.png","Sekk_2.png","Sekk_3.png","Sekk_4.png","Sekk_5.png","Sekk_6.png","Sekk_7.png","Sekk_8.png","Sekk_9.png"],
              day_zero: 1,
              day_space: -1,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

            idle_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 133,
              y: 44,
              w: 214,
              h: 30,
              text_size: 25,
              char_space: 0,
              font: 'fonts/GoogleSans-Regular.ttf',
              color: 0xFF000000,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 384,
              y: 101,
              image_array: ["w_0.png","w_1.png","w_2.png","w_3.png","w_4.png","w_7.png","w_8.png","w_9.png","w_10.png","w_11.png","w_12.png","w_13.png","w_14.png","w_15.png","w_16.png","w_17.png","w_20.png","w_21.png","w_22.png","w_23.png","w_24.png","w_25.png","w_26.png","w_27.png","w_28.png","w_0n.png","w_14n.png","w_1n.png","w_2n.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 166,
              y: 8,
              w: 150,
              h: 35,
              text_size: 30,
              char_space: 0,
              font: 'fonts/GoogleSans-Regular.ttf',
              color: 0xFF000000,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              unit_type: 1,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 101,
              hour_startY: 80,
              hour_array: ["H_0.png","H_1.png","H_2.png","H_3.png","H_4.png","H_5.png","H_6.png","H_7.png","H_8.png","H_9.png"],
              hour_zero: 1,
              hour_space: -2,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 247,
              minute_startY: 80,
              minute_array: ["H_0.png","H_1.png","H_2.png","H_3.png","H_4.png","H_5.png","H_6.png","H_7.png","H_8.png","H_9.png"],
              minute_zero: 1,
              minute_space: -2,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 378,
              second_startY: 159,
              second_array: ["Sekk_0.png","Sekk_1.png","Sekk_2.png","Sekk_3.png","Sekk_4.png","Sekk_5.png","Sekk_6.png","Sekk_7.png","Sekk_8.png","Sekk_9.png"],
              second_zero: 1,
              second_space: -1,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 204,
              y: 310,
              src: 'bt_off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 220,
              y: 127,
              src: 'alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img.setAlpha(80);
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 296,
              y: 402,
              w: 73,
              h: 56,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 106,
              y: 402,
              w: 78,
              h: 56,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 202,
              y: 418,
              w: 78,
              h: 43,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 280,
              y: 214,
              w: 70,
              h: 50,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 396,
              y: 219,
              w: 49,
              h: 40,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 220,
              y: 122,
              w: 40,
              h: 56,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 391,
              y: 333,
              w: 44,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'clean.png',
              normal_src: 'clean.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'FlashLightScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 28,
              y: 218,
              w: 59,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'clean.png',
              normal_src: 'clean.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 129,
              y: 216,
              w: 78,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'clean.png',
              normal_src: 'clean.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'WorldClockScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 384,
              y: 100,
              w: 50,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'clean.png',
              normal_src: 'clean.png',
              click_func: (button_widget) => {
                hmApp.startApp({ appid: 1065824, url: 'page/index', params: { from_wf: true} });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button   
            
            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 208,
              y: 42,
              w: 50,
              h: 50,
              text: '',
              text_size: 25,
              color: 0xFFFF8C00,
              press_src: 'clean.png',
              normal_src: 'clean.png',
              click_func: () => {                
                weatherProvider.prev(true);                
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });   
            
            btn_bezel = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 215,
              y: 205,
              text: '',
              w: 50,
              h: 50,
              normal_src: 'clean.png',
              press_src: 'clean.png',
              click_func: () => {
               click_Bezel();
               
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btn_bezel.setProperty(hmUI.prop.VISIBLE, true);               

            function scale_call() {
              console.log('scale_call()');

              console.log('Weather city name');
              let weatherData = weatherSensor.getForecastWeather();
              let idle_cityNameStr = weatherData.cityName;
              idle_city_name_text.setProperty(hmUI.prop.TEXT, idle_cityNameStr);

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
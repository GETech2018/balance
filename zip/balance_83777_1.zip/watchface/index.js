﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_image_img = ''
        let normal_battery_current_text_font = ''
        let normal_calorie_current_text_font = ''
        let normal_step_current_text_font = ''
        let normal_heart_rate_text_font = ''
        let normal_month_text_font = ''
        let normal_date_img_date_week_img = ''
        let normal_time_hour_text_font = ''
        let normal_timerTimeUpdate = undefined;
        let normal_time_minute_text_font = ''
        let normal_digital_clock_img_time_second = ''
        let normal_digital_clock_second_separator_img = ''
        let normal_step_jumpable_img_click = ''
        let normal_cal_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_battery_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let timeSensor = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg_edit_2_preview.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'image_(47).png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 209,
              y: 426,
              w: 47,
              h: 41,
              text_size: 30,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.RIGHT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 248,
              y: 340,
              w: 150,
              h: 55,
              text_size: 40,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 60,
              y: 340,
              w: 160,
              h: 55,
              text_size: 40,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 160,
              y: 85,
              w: 150,
              h: 54,
              text_size: 35,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.RIGHT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function() {
              time_update(true);
            });

            normal_month_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 61,
              y: 88,
              w: 150,
              h: 49,
              text_size: 30,
              char_space: 0,
              line_space: 0,
              color: 0xFF000000,
              align_h: hmUI.align.RIGHT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 93,
              y: 94,
              week_en: ["img_arr_0003_01.png","img_arr_0003_02.png","img_arr_0003_03.png","img_arr_0003_04.png","img_arr_0003_05.png","img_arr_0003_06.png","img_arr_0004_00.png"],
              week_tc: ["img_arr_0003_01.png","img_arr_0003_02.png","img_arr_0003_03.png","img_arr_0003_04.png","img_arr_0003_05.png","img_arr_0003_06.png","img_arr_0004_00.png"],
              week_sc: ["img_arr_0003_01.png","img_arr_0003_02.png","img_arr_0003_03.png","img_arr_0003_04.png","img_arr_0003_05.png","img_arr_0003_06.png","img_arr_0004_00.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            normal_time_hour_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 50,
              y: 115,
              w: 175,
              h: 185,
              text_size: 150,
              char_space: 0,
              line_space: 0,
              color: 0xFFFF8C00,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_time_minute_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 260,
              y: 115,
              w: 175,
              h: 185,
              text_size: 150,
              char_space: 0,
              line_space: 0,
              color: 0xFFFF8C00,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_second = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              second_startX: 228,
              second_startY: 224,
              second_array: ["img_arr_0002_00.png","img_arr_0002_01.png","img_arr_0002_02.png","img_arr_0002_03.png","img_arr_0002_04.png","img_arr_0002_05.png","img_arr_0002_06.png","img_arr_0002_07.png","img_arr_0002_08.png","img_arr_0002_09.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_second_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'image (37).png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 69,
              y: 310,
              w: 146,
              h: 86,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_cal_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 250,
              y: 310,
              w: 174,
              h: 88,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 250,
              y: 86,
              w: 101,
              h: 68,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 208,
              y: 412,
              w: 73,
              h: 60,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 268,
              y: 179,
              w: 151,
              h: 119,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 71,
              y: 177,
              w: 145,
              h: 120,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 103,
              y: 88,
              w: 117,
              h: 58,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'image (37).png',
              normal_src: 'image (37).png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 184,
              y: 2,
              w: 117,
              h: 75,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'image (37).png',
              normal_src: 'image (37).png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'AppListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            //start of ignored block
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              console.log('month font');
              if (updateHour) {
                let normal_monthStr = timeSensor.month.toString();
                normal_month_text_font.setProperty(hmUI.prop.TEXT, normal_monthStr );
              };

              console.log('hour font');
              if (updateHour) {
                let normal_hourStr = format_hour.toString();
                normal_hourStr = normal_hourStr.padStart(2, '0');
                normal_time_hour_text_font.setProperty(hmUI.prop.TEXT, normal_hourStr );
              };

              console.log('minute font');
              if (updateMinute) {
                let normal_minuteStr = minute.toString();
                normal_minuteStr = normal_minuteStr.padStart(2, '0');
                normal_time_minute_text_font.setProperty(hmUI.prop.TEXT, normal_minuteStr );
              };

            };

            //end of ignored block
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                time_update(true, true);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerTimeUpdate) {
                    normal_timerTimeUpdate = timer.createTimer(0, 1000, (function (option) {
                      let updateHour = timeSensor.minute == 0 && timeSensor.second < 2;
                      let updateMinute = timeSensor.second < 2;
                      time_update(updateHour, updateMinute);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerTimeUpdate) {
                  timer.stopTimer(normal_timerTimeUpdate);
                  normal_timerTimeUpdate = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
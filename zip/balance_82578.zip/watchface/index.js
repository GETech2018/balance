﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_step_current_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_battery_text_text_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_month_img = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg_img = ''
        let idle_step_current_text_img = ''
        let idle_heart_rate_text_text_img = ''
        let idle_battery_text_text_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_month_img = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_analog_clock_time_pointer_second = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: '1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 211,
              y: 333,
              font_array: ["U0.png","U1.png","U2.png","U3.png","U4.png","U5.png","U6.png","U7.png","U8.png","U9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 292,
              y: 223,
              font_array: ["U0.png","U1.png","U2.png","U3.png","U4.png","U5.png","U6.png","U7.png","U8.png","U9.png"],
              padding: false,
              h_space: -1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 118,
              y: 224,
              font_array: ["U0.png","U1.png","U2.png","U3.png","U4.png","U5.png","U6.png","U7.png","U8.png","U9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'PER.png',
              unit_tc: 'PER.png',
              unit_en: 'PER.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 280,
              y: 119,
              week_en: ["S1.png","S2.png","S3.png","S4.png","S5.png","S6.png","S7.png"],
              week_tc: ["S1.png","S2.png","S3.png","S4.png","S5.png","S6.png","S7.png"],
              week_sc: ["S1.png","S2.png","S3.png","S4.png","S5.png","S6.png","S7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 218,
              day_startY: 118,
              day_sc_array: ["N0.png","N1.png","N2.png","N3.png","N4.png","N5.png","N6.png","N7.png","N8.png","N9.png"],
              day_tc_array: ["N0.png","N1.png","N2.png","N3.png","N4.png","N5.png","N6.png","N7.png","N8.png","N9.png"],
              day_en_array: ["N0.png","N1.png","N2.png","N3.png","N4.png","N5.png","N6.png","N7.png","N8.png","N9.png"],
              day_zero: 1,
              day_space: 2,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 136,
              month_startY: 119,
              month_sc_array: ["m01.png","m02.png","m03.png","m04.png","m05.png","m06.png","m07.png","m08.png","m09.png","m10.png","m11.png","m12.png"],
              month_tc_array: ["m01.png","m02.png","m03.png","m04.png","m05.png","m06.png","m07.png","m08.png","m09.png","m10.png","m11.png","m12.png"],
              month_en_array: ["m01.png","m02.png","m03.png","m04.png","m05.png","m06.png","m07.png","m08.png","m09.png","m10.png","m11.png","m12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'ore.png',
              hour_centerX: 243,
              hour_centerY: 240,
              hour_posX: 33,
              hour_posY: 175,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'minuti.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 39,
              minute_posY: 216,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'sec.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 24,
              second_posY: 216,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: '1.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 211,
              y: 333,
              font_array: ["U0.png","U1.png","U2.png","U3.png","U4.png","U5.png","U6.png","U7.png","U8.png","U9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 292,
              y: 223,
              font_array: ["U0.png","U1.png","U2.png","U3.png","U4.png","U5.png","U6.png","U7.png","U8.png","U9.png"],
              padding: false,
              h_space: -1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 118,
              y: 224,
              font_array: ["U0.png","U1.png","U2.png","U3.png","U4.png","U5.png","U6.png","U7.png","U8.png","U9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'PER.png',
              unit_tc: 'PER.png',
              unit_en: 'PER.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 280,
              y: 119,
              week_en: ["S1.png","S2.png","S3.png","S4.png","S5.png","S6.png","S7.png"],
              week_tc: ["S1.png","S2.png","S3.png","S4.png","S5.png","S6.png","S7.png"],
              week_sc: ["S1.png","S2.png","S3.png","S4.png","S5.png","S6.png","S7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 218,
              day_startY: 118,
              day_sc_array: ["N0.png","N1.png","N2.png","N3.png","N4.png","N5.png","N6.png","N7.png","N8.png","N9.png"],
              day_tc_array: ["N0.png","N1.png","N2.png","N3.png","N4.png","N5.png","N6.png","N7.png","N8.png","N9.png"],
              day_en_array: ["N0.png","N1.png","N2.png","N3.png","N4.png","N5.png","N6.png","N7.png","N8.png","N9.png"],
              day_zero: 1,
              day_space: 2,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 136,
              month_startY: 119,
              month_sc_array: ["m01.png","m02.png","m03.png","m04.png","m05.png","m06.png","m07.png","m08.png","m09.png","m10.png","m11.png","m12.png"],
              month_tc_array: ["m01.png","m02.png","m03.png","m04.png","m05.png","m06.png","m07.png","m08.png","m09.png","m10.png","m11.png","m12.png"],
              month_en_array: ["m01.png","m02.png","m03.png","m04.png","m05.png","m06.png","m07.png","m08.png","m09.png","m10.png","m11.png","m12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'ore.png',
              hour_centerX: 243,
              hour_centerY: 240,
              hour_posX: 33,
              hour_posY: 175,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'minuti.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 39,
              minute_posY: 216,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'sec.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 24,
              second_posY: 216,
              show_level: hmUI.show_level.ONLY_AOD,
            });


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_aqi_image_progress_img_level = ''
        let normal_group_ForecastWeather = ''
        let normal_forecast_image_progress_img_level = new Array(5);
        let normal_forecast_image_array = ['pronos_01.png', 'pronos_02.png', 'pronos_03.png', 'pronos_04.png', 'pronos_05.png', 'pronos_06.png', 'pronos_07.png', 'pronos_08.png', 'pronos_09.png', 'pronos_10.png', 'pronos_11.png', 'pronos_12.png', 'pronos_13.png', 'pronos_14.png', 'pronos_15.png', 'pronos_16.png', 'pronos_17.png', 'pronos_18.png', 'pronos_19.png', 'pronos_20.png', 'pronos_21.png', 'pronos_22.png', 'pronos_23.png', 'pronos_24.png', 'pronos_25.png', 'pronos_26.png', 'pronos_27.png', 'pronos_28.png', 'pronos_29.png'];
        let normal_moon_image_progress_img_level = ''
        let normal_uvi_image_progress_img_level = ''
        let normal_wind_direction_image_progress_img_level = ''
        let normal_wind_text_text_img = ''
        let normal_city_name_text = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_high_text_img = ''
        let normal_temperature_low_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_humidity_text_text_img = ''
        let normal_sun_high_text_img = ''
        let normal_sun_low_text_img = ''
        let normal_calorie_image_progress_img_level = ''
        let normal_calorie_current_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_battery_text_text_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_lock_img = ''
        let normal_system_dnd_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_step_current_text_img = ''
        let normal_digital_clock_img_time = ''
        let normal_date_img_date_year = ''
        let normal_alarm_clock_text_text_img = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let idle_background_bg_img = ''
        let idle_date_img_date_year = ''
        let idle_date_img_date_month = ''
        let idle_date_img_date_week_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_lock_img = ''
        let idle_system_dnd_img = ''
        let idle_digital_clock_img_time = ''
        let idle_date_img_date_day = ''
        let idle_analog_clock_pro_minute_pointer_img = ''
        let idle_analog_clock_pro_hour_pointer_img = ''
        let normal_altitude_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let Button_1 = ''
        let Button_Switch_BG = ''

        let backgroundIndex = 0;
        let backgroundList = ['2.png', '2_2_cian.png', '2_3_verde.png', '2_4_amarillo.png', '2_5_naranja.png', '2_6_rosa.png', '2_7_rojo.png'];
        let backgroundToastList = ['Blanco', 'Cian', 'Verde', 'Amarillo', 'Naranja', 'Rosa', 'Rojo'];
        const watchfaceId = hmApp.packageInfo().watchfaceId;
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            //start of ignored block
            console.log('SwitchBackground');
            function switchBackground() {
              backgroundIndex++;
              if (backgroundIndex >= backgroundList.length) backgroundIndex = 0;
              hmFS.SysProSetInt(`backgroundIndex_${watchfaceId}`, backgroundIndex);
              let toastText = backgroundToastList[backgroundIndex].replace('%s', `${backgroundIndex + 1}`);
              if (toastText.length > 0) hmUI.showToast({text: toastText});
              normal_background_bg_img.setProperty(hmUI.prop.SRC, backgroundList[backgroundIndex]);
              vibro(28);
            };
            //end of ignored block

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: '2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_aqi_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 408,
              y: 321,
              image_array: ["air1.png","air2.png","air3.png","air4.png","air5.png","air6.png"],
              image_length: 6,
              type: hmUI.data_type.AQI,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();            
            // normal_Weather_FewDays = hmUI.createWidget(hmUI.widget.FewDays, {
              // x: 0,
              // y: 0,
              // ColumnWidth: 45,
              // DaysCount: 5,
            // });
            
            normal_group_ForecastWeather = hmUI.createWidget(hmUI.widget.GROUP, {
              x: 0,
              y: 0,
              h: 0,
              w: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_forecast_image_progress_img_level = normal_group_ForecastWeather.createWidget(hmUI.widget.IMG_LEVEL_Options, {
              // x: 125,
              // y: 311,
              // image_array: ["pronos_01.png","pronos_02.png","pronos_03.png","pronos_04.png","pronos_05.png","pronos_06.png","pronos_07.png","pronos_08.png","pronos_09.png","pronos_10.png","pronos_11.png","pronos_12.png","pronos_13.png","pronos_14.png","pronos_15.png","pronos_16.png","pronos_17.png","pronos_18.png","pronos_19.png","pronos_20.png","pronos_21.png","pronos_22.png","pronos_23.png","pronos_24.png","pronos_25.png","pronos_26.png","pronos_27.png","pronos_28.png","pronos_29.png"],
              // image_length: 29,
              // type: hmUI.data_type.forecast_image,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            //start of ignored block
            if (screenType == hmSetting.screen_type.WATCHFACE) {
              for (let i = 0; i < 5; i++) {
                normal_forecast_image_progress_img_level[i] = normal_group_ForecastWeather.createWidget(hmUI.widget.IMG, {
                  x: 125 + i*45,
                  y: 311,
                  src: normal_forecast_image_array[25],
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
              };
            };
            //end of ignored block

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 72,
              y: 294,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_uvi_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 142,
              y: -8,
              image_array: ["temp_1.png","temp_2.png","temp_3.png","temp_4.png","temp_5.png"],
              image_length: 5,
              type: hmUI.data_type.UVI,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_direction_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 409,
              y: 322,
              image_array: ["Viento01.png","Viento02.png","Viento03.png","Viento04.png","Viento05.png","Viento06.png","Viento07.png","Viento08.png"],
              image_length: 8,
              type: hmUI.data_type.WIND_DIRECTION,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 341,
              y: 373,
              font_array: ["47.png","48.png","49.png","50.png","51.png","52.png","53.png","54.png","55.png","56.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WIND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 116,
              y: 339,
              w: 247,
              h: 45,
              text_size: 30,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 194,
              y: 24,
              image_array: ["18.png","19.png","20.png","21.png","22.png","23.png","24.png","25.png","26.png","27.png","28.png","29.png","30.png","31.png","32.png","33.png","34.png","35.png","36.png","37.png","38.png","39.png","40.png","41.png","42.png","43.png","44.png","45.png","46.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 325,
              y: 80,
              font_array: ["47.png","48.png","49.png","50.png","51.png","52.png","53.png","54.png","55.png","56.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'grados.png',
              unit_tc: 'grados.png',
              unit_en: 'grados.png',
              negative_image: 'minus_peq.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 87,
              y: 80,
              font_array: ["47.png","48.png","49.png","50.png","51.png","52.png","53.png","54.png","55.png","56.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'grados.png',
              unit_tc: 'grados.png',
              unit_en: 'grados.png',
              negative_image: 'minus_peq.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 191,
              y: 104,
              font_array: ["115.png","116.png","117.png","118.png","119.png","120.png","121.png","122.png","123.png","124.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'grados.png',
              unit_tc: 'grados.png',
              unit_en: 'grados.png',
              negative_image: 'minus.png',
              invalid_image: 'error.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 75,
              y: 373,
              font_array: ["47.png","48.png","49.png","50.png","51.png","52.png","53.png","54.png","55.png","56.png"],
              padding: false,
              h_space: 0,
              invalid_image: '67.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 65,
              y: 131,
              font_array: ["47.png","48.png","49.png","50.png","51.png","52.png","53.png","54.png","55.png","56.png"],
              padding: true,
              h_space: -1,
              invalid_image: '68.png',
              dot_image: '69.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 308,
              y: 131,
              font_array: ["47.png","48.png","49.png","50.png","51.png","52.png","53.png","54.png","55.png","56.png"],
              padding: true,
              h_space: -1,
              invalid_image: '70.png',
              dot_image: '69.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 2,
              y: 114,
              image_array: ["72.png","73.png","74.png","75.png","76.png","77.png"],
              image_length: 6,
              // alpha: 254,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_image_progress_img_level.setAlpha(254);

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 28,
              y: 205,
              font_array: ["47.png","48.png","49.png","50.png","51.png","52.png","53.png","54.png","55.png","56.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 353,
              y: 114,
              image_array: ["bat01.png","bat02.png","bat03.png","bat04.png","bat05.png","bat06.png","bat07.png","bat08.png","bat09.png","bat10.png","bat11.png"],
              image_length: 11,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 374,
              y: 205,
              font_array: ["47.png","48.png","49.png","50.png","51.png","52.png","53.png","54.png","55.png","56.png"],
              padding: false,
              h_space: 0,
              unit_sc: '84.png',
              unit_tc: '84.png',
              unit_en: '84.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 364,
              y: 293,
              src: 'Bluetoothe.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 171,
              y: 32,
              src: 'lock.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 288,
              y: 32,
              src: 'dnd.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 100,
              y: 420,
              image_array: ["step_01.png","step_02.png","step_03.png","step_04.png","step_05.png","step_06.png"],
              image_length: 6,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 185,
              y: 416,
              font_array: ["47.png","48.png","49.png","50.png","51.png","52.png","53.png","54.png","55.png","56.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 107,
              hour_startY: 186,
              hour_array: ["3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png","12.png"],
              hour_zero: 1,
              hour_space: -1,
              hour_angle: 0,
              hour_unit_sc: '114.png',
              hour_unit_tc: '114.png',
              hour_unit_en: '114.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 254,
              minute_startY: 186,
              minute_array: ["3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png","12.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 297,
              year_startY: 272,
              year_sc_array: ["47.png","48.png","49.png","50.png","51.png","52.png","53.png","54.png","55.png","56.png"],
              year_tc_array: ["47.png","48.png","49.png","50.png","51.png","52.png","53.png","54.png","55.png","56.png"],
              year_en_array: ["47.png","48.png","49.png","50.png","51.png","52.png","53.png","54.png","55.png","56.png"],
              year_zero: 0,
              year_space: 3,
              year_align: hmUI.align.CENTER_H,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_clock_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 199,
              y: 162,
              font_array: ["peq_01.png","peq_02.png","peq_03.png","peq_04.png","peq_05.png","peq_06.png","peq_07.png","peq_08.png","peq_09.png","peq_10.png"],
              padding: true,
              h_space: 1,
              unit_sc: '113.png',
              unit_tc: '113.png',
              unit_en: '113.png',
              invalid_image: 'noalarm.png',
              dot_image: 'peq_11.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 231,
              month_startY: 272,
              month_sc_array: ["47.png","48.png","49.png","50.png","51.png","52.png","53.png","54.png","55.png","56.png"],
              month_tc_array: ["47.png","48.png","49.png","50.png","51.png","52.png","53.png","54.png","55.png","56.png"],
              month_en_array: ["47.png","48.png","49.png","50.png","51.png","52.png","53.png","54.png","55.png","56.png"],
              month_zero: 1,
              month_space: 2,
              month_unit_sc: 'mes.png',
              month_unit_tc: 'mes.png',
              month_unit_en: 'mes.png',
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 167,
              day_startY: 272,
              day_sc_array: ["47.png","48.png","49.png","50.png","51.png","52.png","53.png","54.png","55.png","56.png"],
              day_tc_array: ["47.png","48.png","49.png","50.png","51.png","52.png","53.png","54.png","55.png","56.png"],
              day_en_array: ["47.png","48.png","49.png","50.png","51.png","52.png","53.png","54.png","55.png","56.png"],
              day_zero: 1,
              day_space: 2,
              day_unit_sc: 'mes.png',
              day_unit_tc: 'mes.png',
              day_unit_en: 'mes.png',
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 132,
              y: 272,
              week_en: ["dia_1.png","dia_2.png","dia_3.png","dia_4.png","dia_5.png","dia_6.png","dia_7.png"],
              week_tc: ["dia_1.png","dia_2.png","dia_3.png","dia_4.png","dia_5.png","dia_6.png","dia_7.png"],
              week_sc: ["dia_1.png","dia_2.png","dia_3.png","dia_4.png","dia_5.png","dia_6.png","dia_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'AOD.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 297,
              year_startY: 272,
              year_sc_array: ["47.png","48.png","49.png","50.png","51.png","52.png","53.png","54.png","55.png","56.png"],
              year_tc_array: ["47.png","48.png","49.png","50.png","51.png","52.png","53.png","54.png","55.png","56.png"],
              year_en_array: ["47.png","48.png","49.png","50.png","51.png","52.png","53.png","54.png","55.png","56.png"],
              year_zero: 0,
              year_space: 3,
              year_align: hmUI.align.CENTER_H,
              year_is_character: false,
              // alpha: 60,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_year.setAlpha(60);

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 231,
              month_startY: 272,
              month_sc_array: ["47.png","48.png","49.png","50.png","51.png","52.png","53.png","54.png","55.png","56.png"],
              month_tc_array: ["47.png","48.png","49.png","50.png","51.png","52.png","53.png","54.png","55.png","56.png"],
              month_en_array: ["47.png","48.png","49.png","50.png","51.png","52.png","53.png","54.png","55.png","56.png"],
              month_zero: 1,
              month_space: 2,
              month_unit_sc: 'mes.png',
              month_unit_tc: 'mes.png',
              month_unit_en: 'mes.png',
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              // alpha: 60,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month.setAlpha(60);

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 132,
              y: 272,
              week_en: ["dia_1.png","dia_2.png","dia_3.png","dia_4.png","dia_5.png","dia_6.png","dia_7.png"],
              week_tc: ["dia_1.png","dia_2.png","dia_3.png","dia_4.png","dia_5.png","dia_6.png","dia_7.png"],
              week_sc: ["dia_1.png","dia_2.png","dia_3.png","dia_4.png","dia_5.png","dia_6.png","dia_7.png"],
              // alpha: 80,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img.setAlpha(80);

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 364,
              y: 293,
              src: 'Bluetoothe.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 171,
              y: 32,
              src: 'lock.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 288,
              y: 32,
              src: 'dnd.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 107,
              hour_startY: 186,
              hour_array: ["3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png","12.png"],
              hour_zero: 1,
              hour_space: -1,
              hour_angle: 0,
              hour_unit_sc: '114.png',
              hour_unit_tc: '114.png',
              hour_unit_en: '114.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 254,
              minute_startY: 186,
              minute_array: ["3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png","12.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 167,
              day_startY: 272,
              day_sc_array: ["47.png","48.png","49.png","50.png","51.png","52.png","53.png","54.png","55.png","56.png"],
              day_tc_array: ["47.png","48.png","49.png","50.png","51.png","52.png","53.png","54.png","55.png","56.png"],
              day_en_array: ["47.png","48.png","49.png","50.png","51.png","52.png","53.png","54.png","55.png","56.png"],
              day_zero: 1,
              day_space: 2,
              day_unit_sc: 'mes.png',
              day_unit_tc: 'mes.png',
              day_unit_en: 'mes.png',
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              // alpha: 70,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day.setAlpha(70);

            const deviceInfo = hmSetting.getDeviceInfo();
            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.MINUTEEND, function() {
              let updateHour = timeSensor.minute == 0;

              time_update(updateHour, true);
            });

            // idle_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'minute.png',
              // center_x: 240,
              // center_y: 240,
              // x: 35,
              // y: 262,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.minute,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });


            idle_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 35,
              pos_y: 240 - 262,
              center_x: 240,
              center_y: 240,
              src: 'minute.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'hour.png',
              // center_x: 240,
              // center_y: 240,
              // x: 35,
              // y: 262,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.hour,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });


            idle_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 35,
              pos_y: 240 - 262,
              center_x: 240,
              center_y: 240,
              src: 'hour.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 9,
              // disconneсnt_toast_text: Sin conexión,
              // conneсnt_vibrate_type: 9,
              // conneсnt_toast_text: Conectado,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              console.log('checkConnection()');
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  hmUI.showToast({text: "Sin conexión"});
                  vibro(9);
                }
                if(status) {
                  hmUI.showToast({text: "Conectado"});
                  vibro(9);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              if (scene != 1) timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function
            console.log('Watch_Face.Shortcuts');

            normal_altitude_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 30,
              y: 323,
              w: 40,
              h: 40,
              src: 'altimeter.png',
              type: hmUI.data_type.ALTITUDE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 115,
              y: 13,
              w: 253,
              h: 102,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 48,
              y: 234,
              w: 70,
              h: 65,
              src: 'countdown.png',
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 361,
              y: 234,
              w: 70,
              h: 65,
              src: 'chrono.png',
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 180,
              y: 145,
              w: 150,
              h: 38,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 167,
              y: 271,
              w: 178,
              h: 42,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              longpress_func: (button_widget) => {
                hmApp.startApp({url: 'todoListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            console.log('Watch_Face.SwitchBackground');
            // Button_Switch_BG = hmUI.createWidget(hmUI.widget.SwitchBackground, {
              // x: 388,
              // y: 170,
              // w: 40,
              // h: 40,
              // text: '',
              // color: 0xFFFF8C00,
              // text_size: 25,
              // press_src: 'rainbow.png',
              // normal_src: 'black.png',
              // bg_list: 2|2_2_cian|2_3_verde|2_4_amarillo|2_5_naranja|2_6_rosa|2_7_rojo,
              // toast_list: Blanco|Cian|Verde|Amarillo|Naranja|Rosa|Rojo,
              // use_crown: False,
              // use_in_AOD: False,
              // vibro: True,
            // });

            Button_Switch_BG = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 388,
              y: 170,
              w: 40,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'rainbow.png',
              normal_src: 'black.png',
              click_func: (button_widget) => {
                switchBackground();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            //start of ignored block
            function weather_few_days() {
              console.log('weather_few_days()');
              let weatherData = weatherSensor.getForecastWeather();
              let forecastData = weatherData.forecastData;

              for (let i = 0; i < 5; i++) {
                // Images
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  let weatherIndex = 25
                  if (i < forecastData.count) weatherIndex = forecastData.data[i].index;
                  normal_forecast_image_progress_img_level[i].setProperty(hmUI.prop.SRC, normal_forecast_image_array[weatherIndex]);
                };
              
              };  // end for

            };
            //end of ignored block

            //start of ignored block
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              if (updateMinute) {
                let idle_fullAngle_minute = 360;
                let idle_angle_minute = 0 + idle_fullAngle_minute*minute/60;
                if (idle_analog_clock_pro_minute_pointer_img) idle_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.ANGLE, idle_angle_minute);
              };

              if (updateMinute) {
                let idle_hour = hour;
                let idle_fullAngle_hour = 360;
                if (idle_hour > 11) idle_hour -= 12;
                let idle_angle_hour = 0 + idle_fullAngle_hour*idle_hour/12 + (idle_fullAngle_hour/12)*minute/60;
                if (idle_analog_clock_pro_hour_pointer_img) idle_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.ANGLE, idle_angle_hour);
              };

            };

            //end of ignored block
            function scale_call() {
              console.log('scale_call()');

              console.log('Weather city name');
              let weatherData = weatherSensor.getForecastWeather();
              let normal_cityNameStr = weatherData.cityName;
              normal_city_name_text.setProperty(hmUI.prop.TEXT, normal_cityNameStr);

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                time_update(true, true);
                checkConnection();
                stopVibro();

                //SwitchBackground
                if (hmFS.SysProGetInt(`backgroundIndex_${watchfaceId}`) === undefined) {
                  backgroundIndex = 0;
                  hmFS.SysProSetInt(`backgroundIndex_${watchfaceId}`, backgroundIndex);
                } else {
                  backgroundIndex = hmFS.SysProGetInt(`backgroundIndex_${watchfaceId}`);
                };
                if (screenType == hmSetting.screen_type.WATCHFACE && normal_background_bg_img) normal_background_bg_img.setProperty(hmUI.prop.SRC, backgroundList[backgroundIndex]);
                weather_few_days();
              }),
              pause_call: (function () {
                console.log('pause_call()');
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
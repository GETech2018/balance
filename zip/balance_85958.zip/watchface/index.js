﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start
        let btn_bezel = ''
        let bezel_num = 1
        let bezel_all = 2
        
        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_date_img_date_week_img_top = ''
        let normal_date_img_date_week_img_bottom = ''
        let normal_date_img_date_day_top = ''
        let normal_date_img_date_day_bottom = ''
        let normal_battery_text_text_img_top = ''
        let normal_battery_text_text_img_bottom = ''
        let normal_analog_clock_pro_hour_pointer_img = ''
        let normal_analog_clock_pro_minute_pointer_img = ''
        let normal_analog_clock_pro_second_pointer_img = ''
        let normal_timerUpdateSec = undefined;

        let normal_hour_TextRotate = new Array(2);
        let normal_hour_TextRotate_ASCIIARRAY = new Array(10);
        let normal_hour_TextRotate_img_width = 24;
        let normal_img_height = 28;
        let normal_timerTextUpdate = undefined;
        let normal_minute_TextRotate = new Array(2);
        let normal_minute_TextRotate_ASCIIARRAY = new Array(10);
        let normal_minute_TextRotate_img_width = 24; 

        let idle_background_bg_img = ''
        let idle_system_disconnect_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_day = ''
        let idle_battery_text_text_img = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
            function click_Bezel() {
              if(bezel_num>=bezel_all) {bezel_num=1;}
              else { bezel_num=bezel_num+1;}
              hmUI.showToast({text: "Цвет " + parseInt(bezel_num) });
                normal_background_bg_img.setProperty(hmUI.prop.SRC, "osn_" + parseInt(bezel_num) + ".png");
                normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.SRC, "Hour_" + parseInt(bezel_num) + ".png");
                normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.SRC, "Min_" + parseInt(bezel_num) + ".png");
                normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.SRC, "Sek_" + parseInt(bezel_num) + ".png");
                
            }                      
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'osn_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 0,
              y: 0,
              src: 'bt_off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img_top = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 247,
              y: 53,
              week_en: ["D_0.png","D_1.png","D_2.png","D_3.png","D_4.png","D_5.png","D_6.png"],
              week_tc: ["D_0.png","D_1.png","D_2.png","D_3.png","D_4.png","D_5.png","D_6.png"],
              week_sc: ["D_0.png","D_1.png","D_2.png","D_3.png","D_4.png","D_5.png","D_6.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_date_img_date_week_img_top.setProperty(hmUI.prop.VISIBLE, true);

            normal_date_img_date_week_img_bottom = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 247,
              y: 365,
              week_en: ["D_0.png","D_1.png","D_2.png","D_3.png","D_4.png","D_5.png","D_6.png"],
              week_tc: ["D_0.png","D_1.png","D_2.png","D_3.png","D_4.png","D_5.png","D_6.png"],
              week_sc: ["D_0.png","D_1.png","D_2.png","D_3.png","D_4.png","D_5.png","D_6.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_date_img_date_week_img_bottom.setProperty(hmUI.prop.VISIBLE, false);

            normal_date_img_date_day_top = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 187,
              day_startY: 53,
              day_sc_array: ["H_0.png","H_1.png","H_2.png","H_3.png","H_4.png","H_5.png","H_6.png","H_7.png","H_8.png","H_9.png"],
              day_tc_array: ["H_0.png","H_1.png","H_2.png","H_3.png","H_4.png","H_5.png","H_6.png","H_7.png","H_8.png","H_9.png"],
              day_en_array: ["H_0.png","H_1.png","H_2.png","H_3.png","H_4.png","H_5.png","H_6.png","H_7.png","H_8.png","H_9.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_date_img_date_day_top.setProperty(hmUI.prop.VISIBLE, true);

            normal_date_img_date_day_bottom = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 187,
              day_startY: 365,
              day_sc_array: ["H_0.png","H_1.png","H_2.png","H_3.png","H_4.png","H_5.png","H_6.png","H_7.png","H_8.png","H_9.png"],
              day_tc_array: ["H_0.png","H_1.png","H_2.png","H_3.png","H_4.png","H_5.png","H_6.png","H_7.png","H_8.png","H_9.png"],
              day_en_array: ["H_0.png","H_1.png","H_2.png","H_3.png","H_4.png","H_5.png","H_6.png","H_7.png","H_8.png","H_9.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_date_img_date_day_bottom.setProperty(hmUI.prop.VISIBLE, false);

            normal_battery_text_text_img_top = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 186,
              y: 88,
              font_array: ["H_0.png","H_1.png","H_2.png","H_3.png","H_4.png","H_5.png","H_6.png","H_7.png","H_8.png","H_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'H_pr.png',
              unit_tc: 'H_pr.png',
              unit_en: 'H_pr.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_battery_text_text_img_top.setProperty(hmUI.prop.VISIBLE, true);

            normal_battery_text_text_img_bottom = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 186,
              y: 400,
              font_array: ["H_0.png","H_1.png","H_2.png","H_3.png","H_4.png","H_5.png","H_6.png","H_7.png","H_8.png","H_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'H_pr.png',
              unit_tc: 'H_pr.png',
              unit_en: 'H_pr.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_battery_text_text_img_bottom.setProperty(hmUI.prop.VISIBLE, false);

            const deviceInfo = hmSetting.getDeviceInfo();
            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.MINUTEEND, function() {
              let updateHour = timeSensor.minute == 0;

              time_update(updateHour, true);
              text_update();
            });

            // normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'Hour_1.png',
              // center_x: 240,
              // center_y: 240,
              // x: 48,
              // y: 239,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.hour,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 48,
              pos_y: 240 - 239,
              center_x: 240,
              center_y: 240,
              src: 'Hour_1.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'Min_1.png',
              // center_x: 240,
              // center_y: 240,
              // x: 48,
              // y: 239,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.minute,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 48,
              pos_y: 240 - 239,
              center_x: 240,
              center_y: 240,
              src: 'Min_1.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'Sek_1.png',
              // center_x: 240,
              // center_y: 240,
              // x: 48,
              // y: 239,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 48,
              pos_y: 240 - 239,
              center_x: 240,
              center_y: 240,
              src: 'Sek_1.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // массивы картинок для цифр
            for (let i = 0; i < 10; i++) {
              normal_hour_TextRotate_ASCIIARRAY[i] = `H_${i}.png`;
              normal_minute_TextRotate_ASCIIARRAY[i] = `H_${i}.png`;
            }

            // IMG для часов
            for (let i = 0; i < 2; i++) {
              normal_hour_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0, y: 0, w: 480, h: 480,
                center_x: 240, center_y: 240,
                src: 'H_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_hour_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            }

            // IMG для минут
            for (let i = 0; i < 2; i++) {
              normal_minute_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0, y: 0, w: 480, h: 480,
                center_x: 240, center_y: 240,
                src: 'H_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_minute_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            }               

            let screenType = hmSetting.getScreenType();

            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'osn_1.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 0,
              y: 0,
              src: 'bt_off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 247,
              y: 53,
              week_en: ["D_0.png","D_1.png","D_2.png","D_3.png","D_4.png","D_5.png","D_6.png"],
              week_tc: ["D_0.png","D_1.png","D_2.png","D_3.png","D_4.png","D_5.png","D_6.png"],
              week_sc: ["D_0.png","D_1.png","D_2.png","D_3.png","D_4.png","D_5.png","D_6.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 187,
              day_startY: 53,
              day_sc_array: ["H_0.png","H_1.png","H_2.png","H_3.png","H_4.png","H_5.png","H_6.png","H_7.png","H_8.png","H_9.png"],
              day_tc_array: ["H_0.png","H_1.png","H_2.png","H_3.png","H_4.png","H_5.png","H_6.png","H_7.png","H_8.png","H_9.png"],
              day_en_array: ["H_0.png","H_1.png","H_2.png","H_3.png","H_4.png","H_5.png","H_6.png","H_7.png","H_8.png","H_9.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 186,
              y: 88,
              font_array: ["H_0.png","H_1.png","H_2.png","H_3.png","H_4.png","H_5.png","H_6.png","H_7.png","H_8.png","H_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'H_pr.png',
              unit_tc: 'H_pr.png',
              unit_en: 'H_pr.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'Hour_1.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 48,
              hour_posY: 239,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'Min_AOD.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 48,
              minute_posY: 239,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            btn_bezel = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 216,
              y: 213,
              text: '',
              w: 50,
              h: 50,
              normal_src: 'clean.png',
              press_src: 'clean.png',
              click_func: () => {
               click_Bezel();
               
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btn_bezel.setProperty(hmUI.prop.VISIBLE, true);               

            //#region time_update
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              if (updateMinute) {
                let normal_hour = hour;
                let normal_fullAngle_hour = 360;
                if (normal_hour > 11) normal_hour -= 12;
                let normal_angle_hour = 0 + normal_fullAngle_hour*normal_hour/12 + (normal_fullAngle_hour/12)*minute/60;
                if (normal_analog_clock_pro_hour_pointer_img) normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_hour);
              };

              if (updateMinute) {
                let normal_fullAngle_minute = 360;
                let normal_angle_minute = 0 + normal_fullAngle_minute*minute/60;
                if (normal_analog_clock_pro_minute_pointer_img) normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_minute);
              };

              let normal_fullAngle_second = 360;
              let normal_angle_second = 0 + normal_fullAngle_second*second/60;
              if (normal_analog_clock_pro_second_pointer_img) normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_second);

            };

            function text_update() {
              if (screenType == hmSetting.screen_type.AOD) return;
              let valueHour = timeSensor.format_hour;
              let valueMinute = timeSensor.minute;
              let valueSecond = timeSensor.second;

              // угол минутной стрелки
              let angle = valueMinute * 6;
              let rad = angle * Math.PI / 180;

              // направление стрелки
              let dx = Math.sin(rad);
              let dy = -Math.cos(rad);

              // радиус до центра блока (подгони под длину стрелки)
              let R = 150;

              // точка привязки блока (центр строки)
              let baseX = 240 + R * dx;
              let baseY = 240 + R * dy;

              // строка HHMM
              let hourStr = String(valueHour).padStart(2, '0');
              let minStr = String(valueMinute).padStart(2, '0');
              let fullStr = hourStr + minStr;

              // угол для блока
              let displayAngle = (valueMinute < 30 ? angle - 90 : angle + 90);

              // ширина строки
              let extra_space = 15; // Задайте здесь желаемый отступ в пикселях между часами и минутами
              let totalWidth = (fullStr.length * normal_hour_TextRotate_img_width) + extra_space; // Учитываем отступ в общей ширине
              let initialOffset = -totalWidth / 2;
              let offset = initialOffset;

              let displayRad = displayAngle * Math.PI / 180;
              let cos = Math.cos(displayRad);
              let sin = Math.sin(displayRad);
              let centerX = 240;
              let centerY = 240;
              let width = normal_hour_TextRotate_img_width;
              let height = normal_img_height;

              // Вычисляем перпендикулярное направление для сдвига
              let perpX = -sin; // Перпендикуляр к направлению строки
              let perpY = cos;

              // Фиксированный сдвиг для центрирования цифры по высоте (верхний левый -> центр)
              let fixedShift = -height / 2;

              // Переменный сдвиг для корректировки расстояния (max при 0/30, min при 15/45)
              let cosAbs = Math.abs(Math.cos(rad));
              let maxShift = 0; // Подгони значение max расстояния
              let minShift = 0;
              let variableShift = minShift + (maxShift - minShift) * cosAbs;

              // Общий сдвиг (можно изменить знак для направления)
              let shiftAmount = fixedShift + variableShift;

              // Применяем сдвиг к base
              baseX += shiftAmount * perpX;
              baseY += shiftAmount * perpY;

              // отрисовка
              for (let i = 0; i < fullStr.length; i++) {
                let charCode = fullStr.charCodeAt(i) - 48;
                if (charCode >= 0 && charCode <= 9) {
                  // desired top-left D
                  let desired_D_x = baseX + offset * cos;
                  let desired_D_y = baseY + offset * sin;

                  // vector from rotation center
                  let vx = desired_D_x - centerX;
                  let vy = desired_D_y - centerY;

                  // apply inverse rotation: R(-displayAngle)
                  let pre_vx = cos * vx + sin * vy;
                  let pre_vy = -sin * vx + cos * vy;

                  let pre_pos_x = centerX + pre_vx;
                  let pre_pos_y = centerY + pre_vy;

                  let pos_x = Math.round(pre_pos_x);
                  let pos_y = Math.round(pre_pos_y);

                  let widget = (i < 2 ? normal_hour_TextRotate[i] : normal_minute_TextRotate[i - 2]);

                  widget.setProperty(hmUI.prop.POS_X, pos_x);
                  widget.setProperty(hmUI.prop.POS_Y, pos_y);
                  widget.setProperty(hmUI.prop.SRC, normal_hour_TextRotate_ASCIIARRAY[charCode]);
                  widget.setProperty(hmUI.prop.ANGLE, displayAngle);
                  widget.setProperty(hmUI.prop.VISIBLE, true);

                  offset += width;
                  if (i === 1) { // Добавляем отступ после второй цифры часов (перед минутами)
                    offset += extra_space;
                  }
                }
              }

              // Обновление видимости виджетов в зависимости от минут
              if (valueMinute >= 50 || valueMinute <= 10) {
                normal_date_img_date_week_img_top.setProperty(hmUI.prop.VISIBLE, false);
                normal_date_img_date_week_img_bottom.setProperty(hmUI.prop.VISIBLE, true);
                normal_date_img_date_day_top.setProperty(hmUI.prop.VISIBLE, false);
                normal_date_img_date_day_bottom.setProperty(hmUI.prop.VISIBLE, true);
                normal_battery_text_text_img_top.setProperty(hmUI.prop.VISIBLE, false);
                normal_battery_text_text_img_bottom.setProperty(hmUI.prop.VISIBLE, true);
              } else {
                normal_date_img_date_week_img_top.setProperty(hmUI.prop.VISIBLE, true);
                normal_date_img_date_week_img_bottom.setProperty(hmUI.prop.VISIBLE, false);
                normal_date_img_date_day_top.setProperty(hmUI.prop.VISIBLE, true);
                normal_date_img_date_day_bottom.setProperty(hmUI.prop.VISIBLE, false);
                normal_battery_text_text_img_top.setProperty(hmUI.prop.VISIBLE, true);
                normal_battery_text_text_img_bottom.setProperty(hmUI.prop.VISIBLE, false);
              }
            }             

            //#endregion
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                time_update(true, true);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSec) {
                    let animDelay = timeSensor.utc % 1000;
                    let animRepeat = 1000;
                    normal_timerUpdateSec = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, false);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType
                text_update();


              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerUpdateSec) {
                  timer.stopTimer(normal_timerUpdateSec);
                  normal_timerUpdateSec = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
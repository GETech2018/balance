﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_distance_text_text_img = ''
        let normal_temperature_high_text_img = ''
        let normal_temperature_low_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_battery_text_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_digital_clock_img_time = ''
        let normal_analog_clock_pro_hour_pointer_img = ''
        let normal_analog_clock_pro_minute_pointer_img = ''
        let normal_analog_clock_pro_second_pointer_img = ''
        let normal_timerUpdateSec = undefined;
        let idle_background_bg_img = ''
        let idle_temperature_current_text_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_day = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_analog_clock_time_pointer_second = ''
        let timeSensor = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'MAIN.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 218,
              y: 169,
              image_array: ["m01.png","m02.png","m03.png","m04.png","m05.png","m06.png","m07.png","m08.png","m09.png","m10.png","m11.png","m12.png","m13.png","m14.png","m15.png","m16.png","m17.png","m18.png","m19.png","m20.png","m21.png","m22.png","m23.png","m24.png","m25.png","m26.png","m27.png","m28.png","m29.png","m30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 228,
              month_startY: 379,
              month_sc_array: ["mesi0051.png","mesi0052.png","mesi0053.png","mesi0054.png","mesi0055.png","mesi0056.png","mesi0057.png","mesi0058.png","mesi0059.png","mesi0060.png","mesi0061.png","mesi0062.png"],
              month_tc_array: ["mesi0051.png","mesi0052.png","mesi0053.png","mesi0054.png","mesi0055.png","mesi0056.png","mesi0057.png","mesi0058.png","mesi0059.png","mesi0060.png","mesi0061.png","mesi0062.png"],
              month_en_array: ["mesi0051.png","mesi0052.png","mesi0053.png","mesi0054.png","mesi0055.png","mesi0056.png","mesi0057.png","mesi0058.png","mesi0059.png","mesi0060.png","mesi0061.png","mesi0062.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 142,
              y: 406,
              week_en: ["GGwd1.png","GGwd2.png","GGwd3.png","GGwd4.png","GGwd5.png","GGwd6.png","GGwd7.png"],
              week_tc: ["GGwd1.png","GGwd2.png","GGwd3.png","GGwd4.png","GGwd5.png","GGwd6.png","GGwd7.png"],
              week_sc: ["GGwd1.png","GGwd2.png","GGwd3.png","GGwd4.png","GGwd5.png","GGwd6.png","GGwd7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 168,
              day_startY: 378,
              day_sc_array: ["nume0003.png","nume0004.png","nume0005.png","nume0006.png","nume0007.png","nume0008.png","nume0009.png","nume0010.png","nume0011.png","nume0012.png"],
              day_tc_array: ["nume0003.png","nume0004.png","nume0005.png","nume0006.png","nume0007.png","nume0008.png","nume0009.png","nume0010.png","nume0011.png","nume0012.png"],
              day_en_array: ["nume0003.png","nume0004.png","nume0005.png","nume0006.png","nume0007.png","nume0008.png","nume0009.png","nume0010.png","nume0011.png","nume0012.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 320,
              y: 360,
              font_array: ["PROVA24.png","PROVA25.png","PROVA26.png","PROVA27.png","PROVA28.png","PROVA29.png","PROVA30.png","PROVA31.png","PROVA32.png","PROVA33.png"],
              padding: false,
              h_space: -2,
              dot_image: 'punto.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 114,
              y: 110,
              font_array: ["PROVA24.png","PROVA25.png","PROVA26.png","PROVA27.png","PROVA28.png","PROVA29.png","PROVA30.png","PROVA31.png","PROVA32.png","PROVA33.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'gradi.png',
              unit_tc: 'gradi.png',
              unit_en: 'gradi.png',
              negative_image: 'meno.png',
              invalid_image: 'bho.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 124,
              y: 84,
              font_array: ["PROVA24.png","PROVA25.png","PROVA26.png","PROVA27.png","PROVA28.png","PROVA29.png","PROVA30.png","PROVA31.png","PROVA32.png","PROVA33.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'gradi.png',
              unit_tc: 'gradi.png',
              unit_en: 'gradi.png',
              negative_image: 'meno.png',
              invalid_image: 'bho.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 338,
              y: 102,
              font_array: ["PROVA24.png","PROVA25.png","PROVA26.png","PROVA27.png","PROVA28.png","PROVA29.png","PROVA30.png","PROVA31.png","PROVA32.png","PROVA33.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'gradi.png',
              unit_tc: 'gradi.png',
              unit_en: 'gradi.png',
              negative_image: 'meno.png',
              invalid_image: 'bho.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 208,
              y: 41,
              image_array: ["w_1.png","w_2.png","w_3.png","w_4.png","w_5.png","w_6.png","w_7.png","w_8.png","w_9.png","w_10.png","w_11.png","w_12.png","w_13.png","w_14.png","w_15.png","w_16.png","w_17.png","w_18.png","w_19.png","w_20.png","w_21.png","w_22.png","w_23.png","w_24.png","w_25.png","w_26.png","w_27.png","w_28.png","w_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 105,
              y: 360,
              font_array: ["PROVA24.png","PROVA25.png","PROVA26.png","PROVA27.png","PROVA28.png","PROVA29.png","PROVA30.png","PROVA31.png","PROVA32.png","PROVA33.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'percentuale.png',
              unit_tc: 'percentuale.png',
              unit_en: 'percentuale.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 320,
              y: 230,
              font_array: ["PROVA24.png","PROVA25.png","PROVA26.png","PROVA27.png","PROVA28.png","PROVA29.png","PROVA30.png","PROVA31.png","PROVA32.png","PROVA33.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 127,
              y: 230,
              font_array: ["PROVA24.png","PROVA25.png","PROVA26.png","PROVA27.png","PROVA28.png","PROVA29.png","PROVA30.png","PROVA31.png","PROVA32.png","PROVA33.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 197,
              y: 307,
              font_array: ["PROVA24.png","PROVA25.png","PROVA26.png","PROVA27.png","PROVA28.png","PROVA29.png","PROVA30.png","PROVA31.png","PROVA32.png","PROVA33.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 173,
              hour_startY: 143,
              hour_array: ["nume0003.png","nume0004.png","nume0005.png","nume0006.png","nume0007.png","nume0008.png","nume0009.png","nume0010.png","nume0011.png","nume0012.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 256,
              minute_startY: 143,
              minute_array: ["nume0003.png","nume0004.png","nume0005.png","nume0006.png","nume0007.png","nume0008.png","nume0009.png","nume0010.png","nume0011.png","nume0012.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const deviceInfo = hmSetting.getDeviceInfo();
            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.MINUTEEND, function() {
              let updateHour = timeSensor.minute == 0;

              time_update(UpdateHour, true);
            });

            // normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'hour_7.png',
              // center_x: 240,
              // center_y: 240,
              // x: 241,
              // y: 241,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.hour,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 241,
              pos_y: 240 - 241,
              center_x: 240,
              center_y: 240,
              src: 'hour_7.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'min_4.png',
              // center_x: 240,
              // center_y: 240,
              // x: 239,
              // y: 240,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.minute,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 239,
              pos_y: 240 - 240,
              center_x: 240,
              center_y: 240,
              src: 'min_4.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: '38.png',
              // center_x: 240,
              // center_y: 240,
              // x: 19,
              // y: 185,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 19,
              pos_y: 240 - 185,
              center_x: 240,
              center_y: 240,
              src: '38.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();

            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'AOD.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 221,
              y: 130,
              font_array: ["PROVA24.png","PROVA25.png","PROVA26.png","PROVA27.png","PROVA28.png","PROVA29.png","PROVA30.png","PROVA31.png","PROVA32.png","PROVA33.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'gradi.png',
              unit_tc: 'gradi.png',
              unit_en: 'gradi.png',
              negative_image: 'meno.png',
              invalid_image: 'bho.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 208,
              y: 41,
              image_array: ["w_1.png","w_2.png","w_3.png","w_4.png","w_5.png","w_6.png","w_7.png","w_8.png","w_9.png","w_10.png","w_11.png","w_12.png","w_13.png","w_14.png","w_15.png","w_16.png","w_17.png","w_18.png","w_19.png","w_20.png","w_21.png","w_22.png","w_23.png","w_24.png","w_25.png","w_26.png","w_27.png","w_28.png","w_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 228,
              month_startY: 379,
              month_sc_array: ["mesi0051.png","mesi0052.png","mesi0053.png","mesi0054.png","mesi0055.png","mesi0056.png","mesi0057.png","mesi0058.png","mesi0059.png","mesi0060.png","mesi0061.png","mesi0062.png"],
              month_tc_array: ["mesi0051.png","mesi0052.png","mesi0053.png","mesi0054.png","mesi0055.png","mesi0056.png","mesi0057.png","mesi0058.png","mesi0059.png","mesi0060.png","mesi0061.png","mesi0062.png"],
              month_en_array: ["mesi0051.png","mesi0052.png","mesi0053.png","mesi0054.png","mesi0055.png","mesi0056.png","mesi0057.png","mesi0058.png","mesi0059.png","mesi0060.png","mesi0061.png","mesi0062.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 142,
              y: 406,
              week_en: ["GGwd1.png","GGwd2.png","GGwd3.png","GGwd4.png","GGwd5.png","GGwd6.png","GGwd7.png"],
              week_tc: ["GGwd1.png","GGwd2.png","GGwd3.png","GGwd4.png","GGwd5.png","GGwd6.png","GGwd7.png"],
              week_sc: ["GGwd1.png","GGwd2.png","GGwd3.png","GGwd4.png","GGwd5.png","GGwd6.png","GGwd7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 168,
              day_startY: 378,
              day_sc_array: ["nume0003.png","nume0004.png","nume0005.png","nume0006.png","nume0007.png","nume0008.png","nume0009.png","nume0010.png","nume0011.png","nume0012.png"],
              day_tc_array: ["nume0003.png","nume0004.png","nume0005.png","nume0006.png","nume0007.png","nume0008.png","nume0009.png","nume0010.png","nume0011.png","nume0012.png"],
              day_en_array: ["nume0003.png","nume0004.png","nume0005.png","nume0006.png","nume0007.png","nume0008.png","nume0009.png","nume0010.png","nume0011.png","nume0012.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hour_7.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 241,
              hour_posY: 241,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'min_4.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 239,
              minute_posY: 240,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: '38.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 19,
              second_posY: 185,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            //start of ignored block
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              if (updateHour) {
                let normal_hour = hour;
                let normal_fullAngle_hour = 360;
                if (normal_hour > 11) normal_hour -= 12;
                let normal_angle_hour = 0 + normal_fullAngle_hour*normal_hour/12 + (normal_fullAngle_hour/12)*minute/60;
                if (normal_analog_clock_pro_hour_pointer_img) normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_hour);
              };

              if (updateMinute) {
                let normal_fullAngle_minute = 360;
                let normal_angle_minute = 0 + normal_fullAngle_minute*minute/60;
                if (normal_analog_clock_pro_minute_pointer_img) normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_minute);
              };

              let normal_fullAngle_second = 360;
              let normal_angle_second = 0 + normal_fullAngle_second*second/60;
              if (normal_analog_clock_pro_second_pointer_img) normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_second);

            };

            //end of ignored block
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                time_update(true, true);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSec) {
                    let animDelay = timeSensor.utc % 1000;
                    let animRepeat = 1000;
                    normal_timerUpdateSec = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, false);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerUpdateSec) {
                  timer.stopTimer(normal_timerUpdateSec);
                  normal_timerUpdateSec = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_frame_animation_1 = ''
        let normal_distance_text_text_img = ''
        let normal_pai_weekly_text_img = ''
        let normal_pai_image_progress_img_level = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_calorie_current_text_img = ''
        let normal_step_current_text_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_date_img_date_year = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_week_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_moon_image_progress_img_level = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_high_text_img = ''
        let normal_temperature_low_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_digital_clock_img_time = ''
        let normal_analog_clock_pro_second_pointer_img = ''
        let normal_timerUpdateSec = undefined;
        let idle_background_bg_img = ''
        let idle_digital_clock_img_time = ''
        let idle_analog_clock_pro_second_pointer_img = ''
        let idle_timerUpdateSec = undefined;
        let normal_step_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_moon_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_fatBurning_jumpable_img_click = ''
        let Button_Switch_BG = ''

        let backgroundIndex = 0;
        let backgroundList = ['base_f.png', 'base_b.png', 'base_g.png', 'base_m.png', 'base_r.png', 'base_y.png'];
        let backgroundToastList = ['Background %s', 'Background %s', 'Background %s', 'Background %s', 'Background %s', 'Background %s'];
        const watchfaceId = hmApp.packageInfo().watchfaceId;
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            //#region SwitchBackground
            console.log('SwitchBackground');
            function switchBackground() {
              backgroundIndex++;
              if (backgroundIndex >= backgroundList.length) backgroundIndex = 0;
              hmFS.SysProSetInt(`backgroundIndex_${watchfaceId}`, backgroundIndex);
              let toastText = backgroundToastList[backgroundIndex].replace('%s', `${backgroundIndex + 1}`);
              if (toastText.length > 0) hmUI.showToast({text: toastText});
              normal_background_bg_img.setProperty(hmUI.prop.SRC, backgroundList[backgroundIndex]);
            };
            //#endregion

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'base_f.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 423,
              y: 229,
              src: 'bluetooth.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 36,
              y: 229,
              src: 'alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_frame_animation_1 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
              x: 94,
              y: 350,
              anim_path: "animation",
              anim_ext: "png",
              anim_prefix: "h",
              anim_fps: 2,
              anim_size: 2,
              repeat_count: 0,
              anim_repeat: true,
              anim_status:hmUI.anim_status.START,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 196,
              y: 402,
              font_array: ["dt_0.png","dt_1.png","dt_2.png","dt_3.png","dt_4.png","dt_5.png","dt_6.png","dt_7.png","dt_8.png","dt_9.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'di_0.png',
              unit_tc: 'di_0.png',
              unit_en: 'di_0.png',
              dot_image: 'dot.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_weekly_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 277,
              y: 346,
              font_array: ["dt_0.png","dt_1.png","dt_2.png","dt_3.png","dt_4.png","dt_5.png","dt_6.png","dt_7.png","dt_8.png","dt_9.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 279,
              y: 380,
              image_array: ["pai_000.png","pai_001.png","pai_002.png","pai_003.png","pai_004.png","pai_005.png","pai_006.png","pai_007.png","pai_008.png","pai_009.png","pai_010.png","pai_011.png","pai_012.png","pai_013.png","pai_014.png","pai_015.png","pai_016.png","pai_017.png","pai_018.png","pai_019.png","pai_020.png","pai_021.png","pai_022.png","pai_023.png","pai_024.png","pai_025.png","pai_026.png","pai_027.png","pai_028.png","pai_029.png","pai_030.png","pai_031.png","pai_032.png","pai_033.png","pai_034.png","pai_035.png","pai_036.png","pai_037.png","pai_038.png","pai_039.png","pai_040.png","pai_041.png","pai_042.png","pai_043.png","pai_044.png","pai_045.png","pai_046.png","pai_047.png","pai_048.png","pai_049.png","pai_050.png","pai_051.png","pai_052.png","pai_053.png","pai_054.png","pai_055.png","pai_056.png","pai_057.png","pai_058.png","pai_059.png","pai_060.png","pai_061.png","pai_062.png","pai_063.png","pai_064.png","pai_065.png","pai_066.png","pai_067.png","pai_068.png","pai_069.png","pai_070.png","pai_071.png","pai_072.png","pai_073.png","pai_074.png","pai_075.png","pai_076.png","pai_077.png","pai_078.png","pai_079.png","pai_080.png","pai_081.png","pai_082.png","pai_083.png","pai_084.png","pai_085.png","pai_086.png","pai_087.png","pai_088.png","pai_089.png","pai_090.png","pai_091.png","pai_092.png","pai_093.png","pai_094.png","pai_095.png","pai_096.png","pai_097.png","pai_098.png","pai_099.png","pai_100.png","pai_101.png","pai_102.png","pai_103.png","pai_104.png"],
              image_length: 105,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 120,
              y: 346,
              font_array: ["dt_0.png","dt_1.png","dt_2.png","dt_3.png","dt_4.png","dt_5.png","dt_6.png","dt_7.png","dt_8.png","dt_9.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 110,
              y: 380,
              image_array: ["hr_1.png","hr_2.png","hr_3.png","hr_4.png","hr_5.png","hr_6.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 277,
              y: 303,
              font_array: ["dt_0.png","dt_1.png","dt_2.png","dt_3.png","dt_4.png","dt_5.png","dt_6.png","dt_7.png","dt_8.png","dt_9.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 99,
              y: 303,
              font_array: ["dt_0.png","dt_1.png","dt_2.png","dt_3.png","dt_4.png","dt_5.png","dt_6.png","dt_7.png","dt_8.png","dt_9.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 67,
              y: 302,
              image_array: ["st_00.png","st_01.png","st_02.png","st_03.png","st_04.png","st_05.png","st_06.png","st_07.png","st_08.png","st_09.png","st_10.png","st_11.png","st_12.png","st_13.png","st_14.png","st_15.png","st_16.png","st_17.png","st_18.png","st_19.png","st_20.png","st_21.png","st_22.png","st_23.png","st_24.png","st_25.png","st_26.png","st_27.png","st_28.png","st_29.png","st_30.png","st_31.png","st_32.png","st_33.png","st_34.png","st_35.png","st_36.png","st_37.png","st_38.png","st_39.png","st_40.png","st_41.png","st_42.png","st_43.png","st_44.png","st_45.png","st_46.png","st_47.png","st_48.png","st_49.png","st_50.png","st_51.png","st_52.png","st_53.png","st_54.png","st_55.png","st_56.png","st_57.png","st_58.png","st_59.png","st_60.png","st_61.png","st_62.png","st_63.png","st_64.png","st_65.png","st_66.png","st_67.png","st_68.png","st_69.png","st_70.png","st_71.png","st_72.png","st_73.png","st_74.png","st_75.png","st_76.png","st_77.png","st_78.png","st_79.png","st_80.png","st_81.png","st_82.png","st_83.png","st_84.png","st_85.png","st_86.png","st_87.png","st_88.png","st_89.png","st_90.png","st_91.png","st_92.png","st_93.png","st_94.png","st_95.png","st_96.png","st_97.png","st_98.png","st_99.png"],
              image_length: 100,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 318,
              year_startY: 151,
              year_sc_array: ["dt_0.png","dt_1.png","dt_2.png","dt_3.png","dt_4.png","dt_5.png","dt_6.png","dt_7.png","dt_8.png","dt_9.png"],
              year_tc_array: ["dt_0.png","dt_1.png","dt_2.png","dt_3.png","dt_4.png","dt_5.png","dt_6.png","dt_7.png","dt_8.png","dt_9.png"],
              year_en_array: ["dt_0.png","dt_1.png","dt_2.png","dt_3.png","dt_4.png","dt_5.png","dt_6.png","dt_7.png","dt_8.png","dt_9.png"],
              year_zero: 1,
              year_space: 2,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 254,
              day_startY: 151,
              day_sc_array: ["dt_0.png","dt_1.png","dt_2.png","dt_3.png","dt_4.png","dt_5.png","dt_6.png","dt_7.png","dt_8.png","dt_9.png"],
              day_tc_array: ["dt_0.png","dt_1.png","dt_2.png","dt_3.png","dt_4.png","dt_5.png","dt_6.png","dt_7.png","dt_8.png","dt_9.png"],
              day_en_array: ["dt_0.png","dt_1.png","dt_2.png","dt_3.png","dt_4.png","dt_5.png","dt_6.png","dt_7.png","dt_8.png","dt_9.png"],
              day_zero: 1,
              day_space: 2,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 168,
              month_startY: 148,
              month_sc_array: ["mo_01.png","mo_02.png","mo_03.png","mo_04.png","mo_05.png","mo_06.png","mo_07.png","mo_08.png","mo_09.png","mo_10.png","mo_11.png","mo_12.png"],
              month_tc_array: ["mo_01.png","mo_02.png","mo_03.png","mo_04.png","mo_05.png","mo_06.png","mo_07.png","mo_08.png","mo_09.png","mo_10.png","mo_11.png","mo_12.png"],
              month_en_array: ["mo_01.png","mo_02.png","mo_03.png","mo_04.png","mo_05.png","mo_06.png","mo_07.png","mo_08.png","mo_09.png","mo_10.png","mo_11.png","mo_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 82,
              y: 148,
              week_en: ["wk_1.png","wk_2.png","wk_3.png","wk_4.png","wk_5.png","wk_6.png","wk_7.png"],
              week_tc: ["wk_1.png","wk_2.png","wk_3.png","wk_4.png","wk_5.png","wk_6.png","wk_7.png"],
              week_sc: ["wk_1.png","wk_2.png","wk_3.png","wk_4.png","wk_5.png","wk_6.png","wk_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 332,
              y: 114,
              font_array: ["ds_0.png","ds_1.png","ds_2.png","ds_3.png","ds_4.png","ds_5.png","ds_6.png","ds_7.png","ds_8.png","ds_9.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'prc.png',
              unit_tc: 'prc.png',
              unit_en: 'prc.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 307,
              y: 107,
              image_array: ["b-00.png","b-01.png","b-02.png","b-03.png","b-04.png","b-05.png","b-06.png","b-07.png","b-08.png","b-09.png","b-10.png","b-11.png","b-12.png","b-13.png","b-14.png","b-15.png","b-16.png","b-17.png","b-18.png","b-19.png","b-20.png","b-21.png","b-22.png","b-23.png","b-24.png","b-25.png","b-26.png","b-27.png","b-28.png","b-29.png","b-30.png","b-31.png","b-32.png","b-33.png","b-34.png","b-35.png","b-36.png","b-37.png","b-38.png","b-39.png","b-40.png","b-41.png","b-42.png","b-43.png","b-44.png","b-45.png","b-46.png","b-47.png","b-48.png","b-49.png","b-50.png","b-51.png","b-52.png","b-53.png","b-54.png","b-55.png","b-56.png","b-57.png","b-58.png","b-59.png","b-60.png","b-61.png","b-62.png","b-63.png","b-64.png","b-65.png","b-66.png","b-67.png","b-68.png","b-69.png","b-70.png","b-71.png","b-72.png","b-73.png","b-74.png","b-75.png","b-76.png","b-77.png","b-78.png","b-79.png","b-80.png","b-81.png","b-82.png","b-83.png","b-84.png","b-85.png","b-86.png","b-87.png","b-88.png","b-89.png","b-90.png","b-91.png","b-92.png","b-93.png","b-94.png","b-95.png","b-96.png","b-97.png","b-98.png","b-99.png"],
              image_length: 100,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 224,
              y: 102,
              image_array: ["moon_01.png","moon_02.png","moon_03.png","moon_04.png","moon_05.png","moon_06.png","moon_07.png","moon_08.png","moon_09.png","moon_10.png","moon_11.png","moon_12.png","moon_13.png","moon_14.png","moon_15.png","moon_16.png","moon_17.png","moon_18.png","moon_19.png","moon_20.png","moon_21.png","moon_22.png","moon_23.png","moon_24.png","moon_25.png","moon_26.png","moon_27.png","moon_28.png","moon_29.png","moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 109,
              y: 77,
              image_array: ["w-01.png","w-02.png","w-03.png","w-04.png","w-05.png","w-06.png","w-07.png","w-08.png","w-09.png","w-10.png","w-11.png","w-12.png","w-13.png","w-14.png","w-15.png","w-16.png","w-17.png","w-18.png","w-19.png","w-20.png","w-21.png","w-22.png","w-23.png","w-24.png","w-25.png","w-26.png","w-27.png","w-28.png","w-29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 168,
              y: 95,
              font_array: ["dss_0.png","dss_1.png","dss_2.png","dss_3.png","dss_4.png","dss_5.png","dss_6.png","dss_7.png","dss_8.png","dss_9.png"],
              padding: false,
              h_space: 0,
              negative_image: 'minus_s.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 168,
              y: 117,
              font_array: ["dss_0.png","dss_1.png","dss_2.png","dss_3.png","dss_4.png","dss_5.png","dss_6.png","dss_7.png","dss_8.png","dss_9.png"],
              padding: false,
              h_space: 0,
              negative_image: 'minus_s.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 82,
              y: 114,
              font_array: ["ds_0.png","ds_1.png","ds_2.png","ds_3.png","ds_4.png","ds_5.png","ds_6.png","ds_7.png","ds_8.png","ds_9.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'tm_0.png',
              unit_tc: 'tm_0.png',
              unit_en: 'tm_0.png',
              imperial_unit_sc: 'tm_1.png',
              imperial_unit_tc: 'tm_1.png',
              imperial_unit_en: 'tm_1.png',
              negative_image: 'minus.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const temperatureUnit = hmSetting.getTemperatureUnit();
            //#region temperatureUnit
            if (temperatureUnit == 1) {
              normal_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
                x: 82,
                y: 114,
                font_array: ["ds_0.png","ds_1.png","ds_2.png","ds_3.png","ds_4.png","ds_5.png","ds_6.png","ds_7.png","ds_8.png","ds_9.png"],
                padding: false,
                h_space: 2,
                unit_sc: 'tm_1.png',
                unit_tc: 'tm_1.png',
                unit_en: 'tm_1.png',
                imperial_unit_sc: 'tm_0.png',
                imperial_unit_tc: 'tm_0.png',
                imperial_unit_en: 'tm_0.png',
                negative_image: 'minus.png',
                align_h: hmUI.align.RIGHT,
                type: hmUI.data_type.WEATHER_CURRENT,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
            };
            //#endregion

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 64,
              hour_startY: 189,
              hour_array: ["t_0.png","t_1.png","t_2.png","t_3.png","t_4.png","t_5.png","t_6.png","t_7.png","t_8.png","t_9.png"],
              hour_zero: 1,
              hour_space: 2,
              hour_angle: 0,
              hour_align: hmUI.align.RIGHT,

              minute_startX: 262,
              minute_startY: 189,
              minute_array: ["t_0.png","t_1.png","t_2.png","t_3.png","t_4.png","t_5.png","t_6.png","t_7.png","t_8.png","t_9.png"],
              minute_zero: 1,
              minute_space: 2,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.RIGHT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const deviceInfo = hmSetting.getDeviceInfo();
            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'sh.png',
              // center_x: 239,
              // center_y: 239,
              // x: 239,
              // y: 239,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 239 - 239,
              pos_y: 239 - 239,
              center_x: 239,
              center_y: 239,
              src: 'sh.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();

            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'aod_base.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 64,
              hour_startY: 189,
              hour_array: ["t_0.png","t_1.png","t_2.png","t_3.png","t_4.png","t_5.png","t_6.png","t_7.png","t_8.png","t_9.png"],
              hour_zero: 1,
              hour_space: 2,
              hour_angle: 0,
              hour_align: hmUI.align.RIGHT,

              minute_startX: 262,
              minute_startY: 189,
              minute_array: ["t_0.png","t_1.png","t_2.png","t_3.png","t_4.png","t_5.png","t_6.png","t_7.png","t_8.png","t_9.png"],
              minute_zero: 1,
              minute_space: 2,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.RIGHT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'sh.png',
              // center_x: 239,
              // center_y: 239,
              // x: 239,
              // y: 239,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });


            idle_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 239 - 239,
              pos_y: 239 - 239,
              center_x: 239,
              center_y: 239,
              src: 'sh.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 109,
              y: 301,
              w: 114,
              h: 33,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 109,
              y: 344,
              w: 114,
              h: 33,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 256,
              y: 344,
              w: 114,
              h: 33,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 220,
              y: 98,
              w: 45,
              h: 45,
              type: hmUI.data_type.MOON_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 104,
              y: 69,
              w: 65,
              h: 66,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 220,
              y: 201,
              w: 40,
              h: 80,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 23,
              y: 217,
              w: 50,
              h: 50,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_fatBurning_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 256,
              y: 301,
              w: 114,
              h: 33,
              type: hmUI.data_type.FAT_BURNING,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.SwitchBackground');
            // Button_Switch_BG = hmUI.createWidget(hmUI.widget.SwitchBackground, {
              // x: 193,
              // y: 42,
              // w: 100,
              // h: 50,
              // text: '',
              // color: 0xFFFF8C00,
              // text_size: 25,
              // press_src: 'transparent.png',
              // normal_src: 'transparent.png',
              // bg_list: base_f|base_b|base_g|base_m|base_r|base_y,
              // toast_list: Background %s|Background %s|Background %s|Background %s|Background %s|Background %s,
              // use_crown: False,
              // use_in_AOD: False,
              // vibro: False,
            // });

            Button_Switch_BG = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 193,
              y: 42,
              w: 100,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'transparent.png',
              normal_src: 'transparent.png',
              click_func: (button_widget) => {
                switchBackground();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            //#region time_update
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              // Second Pointer
              let normal_fullAngle_second = 360;
              let normal_angle_second = 0 + normal_fullAngle_second*second/60;
              if (normal_analog_clock_pro_second_pointer_img) normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_second);

              // Second Pointer
              let idle_fullAngle_second = 360;
              let idle_angle_second = 0 + idle_fullAngle_second*second/60;
              if (idle_analog_clock_pro_second_pointer_img) idle_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, idle_angle_second);

            };

            //#endregion
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                time_update(true, true);
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSec) {
                    let animDelay = timeSensor.utc % 1000;
                    let animRepeat = 1000;
                    normal_timerUpdateSec = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, false);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.AOD) {
                  if (!idle_timerUpdateSec) {
                    let animDelay = timeSensor.utc % 1000;
                    let animRepeat = 1000;
                    idle_timerUpdateSec = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, false);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


                //SwitchBackground
                if (hmFS.SysProGetInt(`backgroundIndex_${watchfaceId}`) === undefined) {
                  backgroundIndex = 0;
                  hmFS.SysProSetInt(`backgroundIndex_${watchfaceId}`, backgroundIndex);
                } else {
                  backgroundIndex = hmFS.SysProGetInt(`backgroundIndex_${watchfaceId}`);
                };
                if (screenType == hmSetting.screen_type.WATCHFACE && normal_background_bg_img) normal_background_bg_img.setProperty(hmUI.prop.SRC, backgroundList[backgroundIndex]);
              }),
              pause_call: (function () {
                console.log('pause_call()');
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);
                if (normal_timerUpdateSec) {
                  timer.stopTimer(normal_timerUpdateSec);
                  normal_timerUpdateSec = undefined;
                }
                if (idle_timerUpdateSec) {
                  timer.stopTimer(idle_timerUpdateSec);
                  idle_timerUpdateSec = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
try {
    (() => {
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface6');
        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 480,
                    h: 480,
                    src: '4.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_WEEK, {
                    x: 170,
                    y: 39,
                    week_en: [
                        '12.png',
                        '13.png',
                        '14.png',
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png'
                    ],
                    week_tc: [
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png',
                        '23.png',
                        '24.png',
                        '25.png'
                    ],
                    week_sc: [
                        '26.png',
                        '27.png',
                        '28.png',
                        '29.png',
                        '30.png',
                        '31.png',
                        '32.png'
                    ],
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_DATE, {
                    day_startX: 261,
                    day_startY: 37,
                    day_sc_array: [
                        '33.png',
                        '34.png',
                        '35.png',
                        '36.png',
                        '37.png',
                        '38.png',
                        '39.png',
                        '40.png',
                        '41.png',
                        '42.png'
                    ],
                    day_tc_array: [
                        '33.png',
                        '34.png',
                        '35.png',
                        '36.png',
                        '37.png',
                        '38.png',
                        '39.png',
                        '40.png',
                        '41.png',
                        '42.png'
                    ],
                    day_en_array: [
                        '33.png',
                        '34.png',
                        '35.png',
                        '36.png',
                        '37.png',
                        '38.png',
                        '39.png',
                        '40.png',
                        '41.png',
                        '42.png'
                    ],
                    day_align: hmUI.align.LEFT,
                    day_zero: 1,
                    day_follow: 0,
                    day_space: 0,
                    day_is_character: false,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    hour_val: new Date().getHours(),
                    hour_zero: 1,
                    hour_startX: 239,
                    hour_startY: 109,
                    hour_array: [
                        '43.png',
                        '44.png',
                        '45.png',
                        '46.png',
                        '47.png',
                        '48.png',
                        '49.png',
                        '50.png',
                        '51.png',
                        '52.png'
                    ],
                    hour_space: 0,
                    hour_align: hmUI.align.CENTER_H,
                    minute_val: new Date().getMinutes(),
                    minute_zero: 1,
                    minute_startX: 239,
                    minute_startY: 255,
                    minute_array: [
                        '53.png',
                        '54.png',
                        '55.png',
                        '56.png',
                        '57.png',
                        '58.png',
                        '59.png',
                        '60.png',
                        '61.png',
                        '62.png'
                    ],
                    minute_space: 0,
                    minute_align: hmUI.align.CENTER_H,
                    minute_follow: 0,
                    am_x: 400,
                    am_y: 220,
                    am_en_path: '63.png',
                    pm_x: 400,
                    pm_y: 220,
                    pm_en_path: '64.png',
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                    x: 176,
                    y: 404,
                    image_array: [
                        '65.png',
                        '66.png',
                        '67.png',
                        '68.png',
                        '69.png',
                        '70.png',
                        '71.png',
                        '72.png',
                        '73.png',
                        '74.png',
                        '75.png',
                        '76.png',
                        '77.png',
                        '78.png',
                        '79.png',
                        '80.png',
                        '81.png',
                        '82.png',
                        '83.png',
                        '84.png',
                        '85.png',
                        '86.png',
                        '87.png',
                        '88.png',
                        '89.png',
                        '90.png',
                        '91.png',
                        '92.png',
                        '93.png'
                    ],
                    image_length: 29,
                    type: hmUI.data_type.WEATHER_CURRENT,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 121,
                    y: 290,
                    type: hmUI.data_type.STEP,
                    font_array: [
                        '94.png',
                        '95.png',
                        '96.png',
                        '97.png',
                        '98.png',
                        '99.png',
                        '100.png',
                        '101.png',
                        '102.png',
                        '103.png'
                    ],
                    align_h: hmUI.align.LEFT,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    invalid_image: '104.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                    x: 87,
                    y: 110,
                    image_array: [
                        '105.png',
                        '106.png',
                        '107.png',
                        '108.png',
                        '109.png',
                        '110.png',
                        '111.png',
                        '112.png'
                    ],
                    image_length: 8,
                    type: hmUI.data_type.STEP,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 121,
                    y: 340,
                    type: hmUI.data_type.CAL,
                    font_array: [
                        '113.png',
                        '114.png',
                        '115.png',
                        '116.png',
                        '117.png',
                        '118.png',
                        '119.png',
                        '120.png',
                        '121.png',
                        '122.png'
                    ],
                    align_h: hmUI.align.LEFT,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    invalid_image: '123.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                    x: 72,
                    y: 95,
                    image_array: [
                        '124.png',
                        '125.png',
                        '126.png',
                        '127.png',
                        '128.png',
                        '129.png',
                        '130.png',
                        '131.png'
                    ],
                    image_length: 8,
                    type: hmUI.data_type.CAL,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                    x: 102,
                    y: 125,
                    image_array: [
                        '132.png',
                        '133.png',
                        '134.png',
                        '135.png',
                        '136.png',
                        '137.png',
                        '138.png',
                        '139.png'
                    ],
                    image_length: 8,
                    type: hmUI.data_type.BATTERY,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 121,
                    y: 240,
                    type: hmUI.data_type.BATTERY,
                    font_array: [
                        '140.png',
                        '141.png',
                        '142.png',
                        '143.png',
                        '144.png',
                        '145.png',
                        '146.png',
                        '147.png',
                        '148.png',
                        '149.png'
                    ],
                    align_h: hmUI.align.LEFT,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    unit_sc: '151.png',
                    unit_tc: '151.png',
                    unit_en: '151.png',
                    invalid_image: '150.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 239,
                    y: 406,
                    type: hmUI.data_type.WEATHER_CURRENT,
                    font_array: [
                        '152.png',
                        '153.png',
                        '154.png',
                        '155.png',
                        '156.png',
                        '157.png',
                        '158.png',
                        '159.png',
                        '160.png',
                        '161.png'
                    ],
                    align_h: hmUI.align.LEFT,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    unit_sc: '164.png',
                    unit_tc: '164.png',
                    unit_en: '164.png',
                    negative_image: '163.png',
                    invalid_image: '162.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    hour_val: new Date().getHours(),
                    hour_zero: 1,
                    hour_startX: 239,
                    hour_startY: 109,
                    hour_array: [
                        '43.png',
                        '44.png',
                        '45.png',
                        '46.png',
                        '47.png',
                        '48.png',
                        '49.png',
                        '50.png',
                        '51.png',
                        '52.png'
                    ],
                    hour_space: 0,
                    hour_align: hmUI.align.CENTER_H,
                    minute_val: new Date().getMinutes(),
                    minute_zero: 1,
                    minute_startX: 239,
                    minute_startY: 255,
                    minute_array: [
                        '53.png',
                        '54.png',
                        '55.png',
                        '56.png',
                        '57.png',
                        '58.png',
                        '59.png',
                        '60.png',
                        '61.png',
                        '62.png'
                    ],
                    minute_space: 0,
                    minute_align: hmUI.align.CENTER_H,
                    minute_follow: 0,
                    am_x: 400,
                    am_y: 220,
                    am_en_path: '63.png',
                    pm_x: 400,
                    pm_y: 220,
                    pm_en_path: '64.png',
                    enable: false,
                    show_level: hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 70,
                    y: 287,
                    w: 124,
                    h: 37,
                    type: hmUI.data_type.STEP,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 70,
                    y: 339,
                    w: 124,
                    h: 37,
                    type: hmUI.data_type.CAL,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 70,
                    y: 238,
                    w: 124,
                    h: 37,
                    type: hmUI.data_type.BATTERY,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 155,
                    y: 385,
                    w: 155,
                    h: 82,
                    type: hmUI.data_type.WEATHER_CURRENT,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
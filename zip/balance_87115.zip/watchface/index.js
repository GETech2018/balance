﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_fat_burning_current_text_font = ''
        let normal_heart_rate_text_font = ''
        let normal_temperature_current_text_font = ''
        let normal_distance_current_text_font = ''
        let normal_hrv_current_text_font = ''
        let normal_calorie_current_text_font = ''
        let normal_stress_current_text_font = ''
        let normal_step_current_text_font = ''
        let normal_battery_current_text_font = ''
        let normal_day_text_font = ''
        let normal_month_text_font = ''
        let normal_year_text_font = ''
        let normal_time_hour_text_font = ''
        let normal_timerTimeUpdate = undefined;
        let normal_time_minute_text_font = ''
        let normal_time_second_text_font = ''
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            // FontName: Perfect DOS VGA 437.ttf; FontSize: 25; Cache: full
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 30,
              h: 30,
              text_size: 25,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Perfect DOS VGA 437.ttf',
              color: 0xFF000000,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.NONE,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: Perfect DOS VGA 437 Win.ttf; FontSize: 22; Cache: full
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 26,
              h: 26,
              text_size: 22,
              char_space: 3,
              line_space: 0,
              font: 'fonts/Perfect DOS VGA 437 Win.ttf',
              color: 0xFF000000,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.NONE,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: Perfect DOS VGA 437 Win.ttf; FontSize: 24
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 501,
              h: 28,
              text_size: 24,
              char_space: 3,
              line_space: 0,
              font: 'fonts/Perfect DOS VGA 437 Win.ttf',
              color: 0xFF000000,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: Perfect DOS VGA 437.ttf; FontSize: 22; Cache: full
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 26,
              h: 26,
              text_size: 22,
              char_space: 5,
              line_space: 0,
              font: 'fonts/Perfect DOS VGA 437.ttf',
              color: 0xFF000000,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.NONE,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: Perfect DOS VGA 437.ttf; FontSize: 23
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 444,
              h: 28,
              text_size: 23,
              char_space: 2,
              line_space: 0,
              font: 'fonts/Perfect DOS VGA 437.ttf',
              color: 0xFF000000,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: Perfect DOS VGA 437.ttf; FontSize: 24
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 501,
              h: 28,
              text_size: 24,
              char_space: 3,
              line_space: 0,
              font: 'fonts/Perfect DOS VGA 437.ttf',
              color: 0xFF000000,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'BIOS_BG.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_fat_burning_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 359,
              y: 248,
              w: 150,
              h: 39,
              text_size: 25,
              char_space: 0,
              font: 'fonts/Perfect DOS VGA 437.ttf',
              color: 0xFF000000,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              unit_type: 1,
              type: hmUI.data_type.FAT_BURNING,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 269,
              y: 377,
              w: 150,
              h: 30,
              text_size: 22,
              char_space: 3,
              font: 'fonts/Perfect DOS VGA 437 Win.ttf',
              color: 0xFF000000,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              unit_type: 1,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 269,
              y: 357,
              w: 150,
              h: 30,
              text_size: 24,
              char_space: 3,
              font: 'fonts/Perfect DOS VGA 437 Win.ttf',
              color: 0xFF000000,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              unit_type: 1,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 269,
              y: 334,
              w: 150,
              h: 30,
              text_size: 22,
              char_space: 5,
              font: 'fonts/Perfect DOS VGA 437.ttf',
              color: 0xFF000000,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              unit_type: 1,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_hrv_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 360,
              y: 295,
              w: 150,
              h: 30,
              text_size: 25,
              char_space: 3,
              font: 'fonts/Perfect DOS VGA 437.ttf',
              color: 0xFF000000,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              unit_type: 1,
              type: hmUI.data_type.HRV,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 359,
              y: 272,
              w: 150,
              h: 30,
              text_size: 25,
              char_space: 1,
              font: 'fonts/Perfect DOS VGA 437.ttf',
              color: 0xFF000000,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 360,
              y: 225,
              w: 150,
              h: 30,
              text_size: 25,
              char_space: 2,
              font: 'fonts/Perfect DOS VGA 437.ttf',
              color: 0xFF000000,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STRESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 360,
              y: 204,
              w: 150,
              h: 30,
              text_size: 25,
              char_space: 4,
              font: 'fonts/Perfect DOS VGA 437.ttf',
              color: 0xFF000000,
              line_space: 1,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 360,
              y: 181,
              w: 150,
              h: 30,
              text_size: 23,
              char_space: 2,
              font: 'fonts/Perfect DOS VGA 437.ttf',
              color: 0xFF000000,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              unit_type: 1,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function() {
              time_update(true);
            });

            normal_day_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 378,
              y: 157,
              w: 150,
              h: 30,
              text_size: 25,
              char_space: 3,
              font: 'fonts/Perfect DOS VGA 437.ttf',
              color: 0xFF000000,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_month_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 334,
              y: 158,
              w: 152,
              h: 32,
              text_size: 24,
              char_space: 3,
              font: 'fonts/Perfect DOS VGA 437.ttf',
              color: 0xFF000000,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_year_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 287,
              y: 157,
              w: 150,
              h: 30,
              text_size: 25,
              char_space: 2,
              font: 'fonts/Perfect DOS VGA 437.ttf',
              color: 0xFF000000,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            normal_time_hour_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 287,
              y: 128,
              w: 150,
              h: 30,
              text_size: 25,
              char_space: 3,
              font: 'fonts/Perfect DOS VGA 437.ttf',
              color: 0xFF000000,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_time_minute_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 337,
              y: 129,
              w: 150,
              h: 30,
              text_size: 24,
              char_space: 2,
              font: 'fonts/Perfect DOS VGA 437.ttf',
              color: 0xFF000000,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_time_second_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 379,
              y: 129,
              w: 150,
              h: 30,
              text_size: 25,
              char_space: 2,
              font: 'fonts/Perfect DOS VGA 437.ttf',
              color: 0xFF000000,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            //#region time_update
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              console.log('day font');
              if (updateHour) {
                let normal_dayStr = timeSensor.day.toString();
                normal_dayStr = normal_dayStr.padStart(2, '0');
                normal_day_text_font.setProperty(hmUI.prop.TEXT, normal_dayStr );
              };

              console.log('month font');
              if (updateHour) {
                let normal_monthStr = timeSensor.month.toString();
                normal_monthStr = normal_monthStr.padStart(2, '0');
                normal_month_text_font.setProperty(hmUI.prop.TEXT, normal_monthStr );
              };

              console.log('year font');
              if (updateHour) {
                let normal_yearStr = (timeSensor.year % 100).toString();
                normal_year_text_font.setProperty(hmUI.prop.TEXT, normal_yearStr );
              };

              console.log('hour font');
              if (updateHour) {
                let normal_hourStr = format_hour.toString();
                normal_hourStr = normal_hourStr.padStart(2, '0');
                normal_time_hour_text_font.setProperty(hmUI.prop.TEXT, normal_hourStr );
              };

              console.log('minute font');
              if (updateMinute) {
                let normal_minuteStr = minute.toString();
                normal_minuteStr = normal_minuteStr.padStart(2, '0');
                normal_time_minute_text_font.setProperty(hmUI.prop.TEXT, normal_minuteStr );
              };

              console.log('second font');
                let normal_secondStr = second.toString();
                normal_secondStr = normal_secondStr.padStart(2, '0');
                normal_time_second_text_font.setProperty(hmUI.prop.TEXT, normal_secondStr );
            };

            //#endregion
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                time_update(true, true);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerTimeUpdate) {
                    normal_timerTimeUpdate = timer.createTimer(0, 1000, (function (option) {
                      let updateHour = timeSensor.minute == 0 && timeSensor.second < 2;
                      let updateMinute = timeSensor.second < 2;
                      time_update(updateHour, updateMinute);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerTimeUpdate) {
                  timer.stopTimer(normal_timerTimeUpdate);
                  normal_timerTimeUpdate = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
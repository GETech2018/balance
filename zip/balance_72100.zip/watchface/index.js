try {
    (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;

        var __$$module$$__ = __$$app$$__.current;
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        /*
         * huamiOS bundle tool v1.0.17
         * Copyright © Huami. All Rights Reserved
         */
        'use strict';

        console.log("----->>>current");
        console.log(__$$hmAppManager$$__.currentApp.pid);
        console.log(__$$hmAppManager$$__.currentApp.current);


        const {
            width: deviceWidth
        } = hmSetting.getDeviceInfo();

        function px(num) {
            return num * (480 / 454);
        }

        const WIDGET_LEFT_ID = 101;
        const WIDGET_TOP_ID = 102;
        const WIDGET_BOTTOM_ID = 103;

        const WIDGET_BG_ID = 106;
        const WIDGET_TOP = 1;
        const WIDGET_LEFT = 2;
        const WIDGET_BOTTOM = 3;

        const WIDGET_EDIT_SIZE = 145;
        const WIDGET_TIPS_WIDTH = 104;
        const ROOTPATH = "images/";
        const WIDGET_BG_PATH = ROOTPATH + "widget/bg/";
        const WIDGET_ICON_PATH = ROOTPATH + "widget/icon/";
        const WIDGET_POINTER_PATH = ROOTPATH + "widget/pointer.png";
        const WIDGET_FONT_ARRAY = [
            ROOTPATH + "widget/font/number_0.png",
            ROOTPATH + "widget/font/number_1.png",
            ROOTPATH + "widget/font/number_2.png",
            ROOTPATH + "widget/font/number_3.png",
            ROOTPATH + "widget/font/number_4.png",
            ROOTPATH + "widget/font/number_5.png",
            ROOTPATH + "widget/font/number_6.png",
            ROOTPATH + "widget/font/number_7.png",
            ROOTPATH + "widget/font/number_8.png",
            ROOTPATH + "widget/font/number_9.png",
        ];
        const pointPath = ROOTPATH + "pointer/";
        const widgetPreview = ROOTPATH + "widget_preview/";
        const TIPS_ROOT = ROOTPATH + "tips/";

        const WIDGET_TIPS_PATH = TIPS_ROOT + "bg_tips.png";
        const BGROOT = ROOTPATH + "bg_edit/";
        let select = null;

        let editBg = null;
        let topWidget = null;
        let leftWidget = null;
        let bottomWidget = null;
        let mask = null;

        let pointer;
        let week = null;
        let day = null;


        const logger = DeviceRuntimeCore.HmLogger.getLogger("sanjiao");
        __$$module$$__.module = DeviceRuntimeCore.Page({
            parseWidgetConfig(editType) {
                let config = {
                    bgPath: null, //背景图
                    iconPath: null, //图标
                    dataType: null, //数据类型
                    nonePath: ROOTPATH + "img/invalid.png", //无数据的图片
                    unitEnPath: null, //单位
                    unitScPath: null,
                    unitTcPath: null,
                    dot_image: null,
                    negative_image: null,
                    startAngle: -180, //指针开始角度
                    endAngle: 180, //指针结束角度
                };
                switch (editType) {
                    case hmUI.edit_type.STEP:
                        config.bgPath = "steps_bg.png";
                        config.nonePath = null; //无数据时显示 0 ;
                        config.dataType = hmUI.data_type.STEP;
                        break;
                    case hmUI.edit_type.CAL:
                        config.bgPath = "kcal_bg.png";
                        config.nonePath = null; //无数据时显示 0 ;
                        config.dataType = hmUI.data_type.CAL;
                        break;
                    case hmUI.edit_type.PAI_WEEKLY:
                        config.bgPath = "pai_bg.png";
                        config.nonePath = null; //无数据时显示 0 ;
                        config.dataType = hmUI.data_type.PAI_WEEKLY;
                        break;
                    case hmUI.edit_type.DISTANCE:
                        config.bgPath = "dist_bg.png";
                        config.dataType = hmUI.data_type.DISTANCE;
                        config.dot_image = ROOTPATH + "img/dot.png"; //小数点图片
                        break;
                    case hmUI.edit_type.KPA:
                        config.bgPath = "kpa_bg.png";
                        config.dataType = hmUI.data_type.KPA;
                        break;
                    case hmUI.edit_type.BATTERY:
                        config.bgPath = "power_bg.png";
                        config.dataType = hmUI.data_type.BATTERY;
                        break;
                    case hmUI.edit_type.STAND:
                        config.bgPath = "stand_bg.png";
                        config.dot_image = ROOTPATH + "img/line.png"; //小数点图片
                        config.nonePath = null; //无数据时显示 0 ;
                        config.dataType = hmUI.data_type.STAND;
                        break;
                    case hmUI.edit_type.SPO2:
                        config.bgPath = "spo2_bg.png";
                        config.dataType = hmUI.data_type.SPO2;
                        break;
                    case hmUI.edit_type.WIND:
                        config.bgPath = "wind_bg.png";
                        config.dataType = hmUI.data_type.WIND;
                        break;
                    case hmUI.edit_type.HUMIDITY:
                        config.bgPath = "rh_bg.png";
                        config.unitEnPath = ROOTPATH + "img/per.png"; //单位
                        config.unitScPath = ROOTPATH + "img/per.png"; //单位
                        config.unitTcPath = ROOTPATH + "img/per.png"; //单位
                        config.dataType = hmUI.data_type.HUMIDITY;
                        break;
                    case hmUI.edit_type.UVI:
                        config.bgPath = "uvi_bg.png";
                        config.dataType = hmUI.data_type.UVI;
                        break;
                    case hmUI.edit_type.TEMPERATURE:
                        //TODO
                        config.bgPath = "temp_bg.png";
                        config.unitEnPath = ROOTPATH + "img/degree.png"; //单位
                        config.unitScPath = ROOTPATH + "img/degree.png"; //单位
                        config.unitTcPath = ROOTPATH + "img/degree.png"; //单位
                        config.negative_image = ROOTPATH + "img/minus.png"; //单位
                        config.dataType = hmUI.data_type.WEATHER_CURRENT;
                        break;
                    case hmUI.edit_type.HEART:
                        //TODO
                        config.bgPath = "bpm_bg.png";
                        config.dataType = hmUI.data_type.HEART;
                        break;
                    default:

                        return config;
                }
                if (config.bgPath != null) {
                    config.bgPath = WIDGET_BG_PATH + config.bgPath;
                }
                // if (config.iconPath != null) {
                //     config.iconPath = WIDGET_ICON_PATH + config.iconPath;
                // }
                return config;
            },
            drawWidget(widgetType, editType) {
                let bgX = 0;
                let bgY = 0;
                switch (widgetType) {
                    case WIDGET_TOP:
                        bgX = px(158);
                        bgY = px(49);
                        break;
                    case WIDGET_LEFT:
                        bgX = px(45);
                        bgY = px(158);
                        break;
                    case WIDGET_BOTTOM:
                        bgX = px(159);
                        bgY = px(267);
                        break;
                    default:
                        return;
                }
                const bgSize = px(138);
                const iconX = bgX + px(51);
                const iconY = bgY + px(17);
                const textX = bgX + 3;
                const textY = bgY + px(32); //
                const textWidth = px(134); // 16
                const textHeight = px(34); //  22
                const iconSize = px(32);
                const config = this.parseWidgetConfig(editType);
                if (config.bgPath == null) {
                    return;
                }
                // if (config.iconPath == null) {

                //     return;
                // }
                if (config.dataType == null) {
                    return;
                }
                //widgetbg
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: bgX,
                    y: bgY,
                    w: bgSize,
                    h: bgSize,
                    src: config.bgPath,
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT
                });

                let dataProp = {
                    x: textX,
                    y: textY,
                    w: textWidth,
                    h: textHeight,
                    align_h: hmUI.align.CENTER_H,
                    type: config.dataType,
                    h_space: 1,
                    font_array: WIDGET_FONT_ARRAY,
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT
                };
                if (config.unitEnPath != null) {
                    dataProp.unit_en = config.unitEnPath;
                }
                if (config.unitScPath != null) {
                    dataProp.unit_sc = config.unitScPath;
                }
                if (config.unitTcPath != null) {
                    dataProp.unit_tc = config.unitTcPath;
                }
                if (config.nonePath != null) {
                    dataProp.invalid_image = config.nonePath;
                }
                if (config.negative_image != null) {
                    dataProp.negative_image = config.negative_image;
                }
                if (config.dot_image != null) {
                    dataProp.dot_image = config.dot_image;
                }
                //数据
                hmUI.createWidget(hmUI.widget.TEXT_IMG, dataProp);
                //指针
                if (editType == hmUI.edit_type.DISTANCE) {
                    config.dataType = hmUI.data_type.STEP;
                }
                hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                    center_x: bgX + bgSize / 2,
                    center_y: bgY + bgSize / 2,
                    x: px(9),
                    y: px(60),
                    src: WIDGET_POINTER_PATH,
                    type: config.dataType,
                    start_angle: config.startAngle,
                    end_angle: config.endAngle,
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT
                });
            },
            init_view() {
                let fontArray = [
                    ROOTPATH + "date/date_0.png",
                    ROOTPATH + "date/date_1.png",
                    ROOTPATH + "date/date_2.png",
                    ROOTPATH + "date/date_3.png",
                    ROOTPATH + "date/date_4.png",
                    ROOTPATH + "date/date_5.png",
                    ROOTPATH + "date/date_6.png",
                    ROOTPATH + "date/date_7.png",
                    ROOTPATH + "date/date_8.png",
                    ROOTPATH + "date/date_9.png",
                ];

                select = ROOTPATH + "select/";

                editBg = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_BG, {
                    edit_id: WIDGET_BG_ID,
                    x: 0,
                    y: 0,
                    bg_config: [{
                        id: 1,
                        preview: BGROOT + "bg_edit_1.png",
                        path: BGROOT + "preview_1.png"
                    },
                    {
                        id: 2,
                        preview: BGROOT + "bg_edit_2.png",
                        path: BGROOT + "preview_2.png"
                    },
                    {
                        id: 3,
                        preview: BGROOT + "bg_edit_3.png",
                        path: BGROOT + "preview_3.png"
                    },
                    ],
                    count: 3,
                    default_id: 1,
                    fg: BGROOT + "fg.png",
                    tips_x: Math.floor(px(160)),
                    tips_y: px(406),
                    tips_bg: TIPS_ROOT + "bg_tips.png",
                    tips_width: px(132),
                    tips_margin: 10,
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT
                });


                let widgetOptionalArray = [{
                    type: hmUI.edit_type.STEP,
                    preview: widgetPreview + "step.png"
                },
                {
                    type: hmUI.edit_type.CAL,
                    preview: widgetPreview + "kcal.png"
                },
                {
                    type: hmUI.edit_type.PAI_WEEKLY,
                    preview: widgetPreview + "pai.png"
                },
                {
                    type: hmUI.edit_type.DISTANCE,
                    preview: widgetPreview + "dist.png"
                },
                {
                    type: hmUI.edit_type.WIND,
                    preview: widgetPreview + "wind.png"
                },
                {
                    type: hmUI.edit_type.BATTERY,
                    preview: widgetPreview + "power.png"
                },
                {
                    type: hmUI.edit_type.STAND,
                    preview: widgetPreview + "stand.png"
                },
                {
                    type: hmUI.edit_type.SPO2,
                    preview: widgetPreview + "spo2.png"
                },
                {
                    type: hmUI.edit_type.TEMPERATURE,
                    preview: widgetPreview + "temp.png"
                },
                {
                    type: hmUI.edit_type.HUMIDITY,
                    preview: widgetPreview + "rh.png"
                },
                {
                    type: hmUI.edit_type.UVI,
                    preview: widgetPreview + "uvi.png"
                },
                {
                    type: hmUI.edit_type.HEART,
                    preview: widgetPreview + "bpm.png"
                },

                ];
                let edit_list_config = {
                    title_font_size: 34,  // 标题字号的大小
                    title_align_h: hmUI.align.CENTER_H,  //标题位置样式(左对齐，居中，右对齐)
                    list_item_vspace: 8, // 列表子元素的行间距
                    list_tips_text_font_size: 32, //子元素的字号大小
                    list_tips_text_align_h: hmUI.align.LEFT, //子元素位置样式(左对齐，居中，右对齐)
                };

                let groupX = px(152);
                let groupY = px(43);
                topWidget = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {//上组件
                    edit_id: WIDGET_TOP_ID,
                    x: groupX,
                    y: groupY,
                    w: px(148),
                    h: px(148),
                    select_image: select + "select.png",
                    un_select_image: select + "unselect.png",
                    default_type: hmUI.edit_type.BATTERY,
                    optional_types: widgetOptionalArray,
                    count: widgetOptionalArray.length,
                    tips_BG: WIDGET_TIPS_PATH,

                    tips_x: px(8),
                    tips_y: px(7) - groupY,
                    tips_width: px(132),
                    tips_margin: 10,
                    select_list: edit_list_config,
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT
                });
                let editType = topWidget.getProperty(hmUI.prop.CURRENT_TYPE);
                this.drawWidget(WIDGET_TOP, editType);






                groupX = px(40);
                groupY = px(154);
                leftWidget = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
                    edit_id: WIDGET_LEFT_ID,
                    x: groupX,
                    y: groupY,

                    w: px(148),
                    h: px(148),
                    select_image: select + "select.png",
                    un_select_image: select + "unselect.png",
                    default_type: hmUI.edit_type.HEART,
                    optional_types: widgetOptionalArray,
                    count: widgetOptionalArray.length,
                    tips_BG: WIDGET_TIPS_PATH,

                    tips_x: px(8),
                    tips_y: px(116) - groupY,

                    tips_width: px(132),
                    tips_margin: 10,
                    select_list: edit_list_config,
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT
                });
                let editType1 = leftWidget.getProperty(hmUI.prop.CURRENT_TYPE);
                this.drawWidget(WIDGET_LEFT, editType1);


                groupX = px(155);
                groupY = px(262);

                bottomWidget = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
                    edit_id: WIDGET_BOTTOM_ID,
                    x: groupX,
                    y: groupY,

                    w: px(148),
                    h: px(148),
                    select_image: select + "select.png",
                    un_select_image: select + "unselect.png",
                    default_type: hmUI.edit_type.STEP,
                    optional_types: widgetOptionalArray,
                    count: widgetOptionalArray.length,
                    tips_BG: WIDGET_TIPS_PATH,

                    tips_x: Math.floor(px(8)),
                    tips_y: px(223) - groupY,

                    tips_width: px(132),
                    tips_margin: 10,
                    select_list: edit_list_config,
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT
                });
                let editType2 = bottomWidget.getProperty(hmUI.prop.CURRENT_TYPE);
                this.drawWidget(WIDGET_BOTTOM, editType2);




                let weekArray = [
                    ROOTPATH + "week/week_1.png",
                    ROOTPATH + "week/week_2.png",
                    ROOTPATH + "week/week_3.png",
                    ROOTPATH + "week/week_4.png",
                    ROOTPATH + "week/week_5.png",
                    ROOTPATH + "week/week_6.png",
                    ROOTPATH + "week/week_7.png",
                ];
                week = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
                    x: px(294),
                    y: px(215),
                    week_tc: weekArray,
                    week_sc: weekArray,
                    week_en: weekArray,
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT
                });
                day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
                    day_startX: px(369),
                    day_startY: px(217),
                    day_zero: true,
                    day_en_array: fontArray,
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT
                });




                const centerXValue = 240;
                const centerYValue = 240;
                const pointerConfig = [{
                    id: 1,
                    hour: {
                        centerX: centerXValue,
                        centerY: centerYValue,
                        posX: 51 / 2,
                        posY: 240,
                        path: pointPath + "h-1.png",
                    },
                    minute: {
                        centerX: centerXValue,
                        centerY: centerYValue,
                        posX: 51 / 2,
                        posY: 240,
                        path: pointPath + "m-1.png",
                    },
                    second: {
                        centerX: centerXValue,
                        centerY: centerYValue,
                        posX: 29 / 2,
                        posY: 240,
                        path: pointPath + "s-1.png",
                    },
                    preview: pointPath + "hand_1_p.png",
                },
                {
                    id: 2,
                    hour: {
                        centerX: centerXValue,
                        centerY: centerYValue,
                        posX: 51 / 2,
                        posY: 240,
                        path: pointPath + "h-2.png",
                    },
                    minute: {
                        centerX: centerXValue,
                        centerY: centerYValue,
                        posX: 51 / 2,
                        posY: 240,
                        path: pointPath + "m-2.png",
                    },
                    preview: pointPath + "hand_2_p.png",
                    // second: secondProp,  样式 2 无秒针
                },
                {
                    id: 3,
                    hour: {
                        centerX: centerXValue,
                        centerY: centerYValue,
                        posX: 51 / 2,
                        posY: 240,
                        path: pointPath + "h-3.png",
                    },
                    minute: {
                        centerX: centerXValue,
                        centerY: centerYValue,
                        posX: 51 / 2,
                        posY: 240,
                        path: pointPath + "m-3.png",
                    },
                    second: {
                        centerX: centerXValue,
                        centerY: centerYValue,
                        posX: 29 / 2,
                        posY: 240,
                        path: pointPath + "s-3.png",
                    },
                    preview: pointPath + "hand_3_p.png",
                },
                ];

                let pointerEdit = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_POINTER, {
                    edit_id: 120,
                    x: 0,
                    y: 0,
                    config: pointerConfig,
                    count: pointerConfig.length,
                    default_id: 1,
                    fg: BGROOT + "fg.png",
                    tips_x: Math.floor(px(160)),
                    tips_y: px(406),
                    tips_bg: TIPS_ROOT + "bg_tips.png",
                    tips_width: px(132),
                    tips_margin: 10

                });
                const screenType = hmSetting.getScreenType();
                const aodModel = screenType == hmSetting.screen_type.AOD;
                const pointerProp = pointerEdit.getProperty(hmUI.prop.CURRENT_CONFIG, !aodModel);
                pointer = hmUI.createWidget(hmUI.widget.TIME_POINTER, pointerProp);

                mask = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_FG_MASK, {
                    x: 0,
                    y: 0,
                    src: ROOTPATH + "mask70.png",
                    show_level: hmUI.show_level.ONLY_EDIT,
                });


                function fn(type) {  //跳转部分
                    const groupJump = {};
                    switch (type) {
                        case hmUI.edit_type.HEART:
                            groupJump.type = hmUI.data_type.HEART;
                            break;
                        case hmUI.edit_type.STEP:
                            groupJump.type = hmUI.data_type.STEP;
                            break;
                        case hmUI.edit_type.UVI:
                            groupJump.type = hmUI.data_type.UVI;
                            break;
                        case hmUI.edit_type.WEATHER:
                            groupJump.type = hmUI.data_type.WEATHER;
                            break;
                        case hmUI.edit_type.HUMIDITY:
                            groupJump.type = hmUI.data_type.HUMIDITY;
                            break;
                        case hmUI.edit_type.PAI_WEEKLY:
                            groupJump.type = hmUI.data_type.PAI_WEEKLY;
                            break;
                        case hmUI.edit_type.BATTERY:
                            groupJump.type = hmUI.data_type.BATTERY;
                            break;
                        case hmUI.edit_type.DISTANCE:
                            groupJump.type = hmUI.data_type.DISTANCE;
                            break;
                        case hmUI.edit_type.STAND:
                            groupJump.type = hmUI.data_type.STAND;
                            break;
                        case hmUI.edit_type.SPO2:
                            groupJump.type = hmUI.data_type.SPO2;
                            break;
                        case hmUI.edit_type.TEMPERATURE:
                            groupJump.type = hmUI.data_type.WEATHER_CURRENT;
                            break;
                        case hmUI.edit_type.CAL:
                            groupJump.type = hmUI.data_type.CAL;
                            break;
                        case hmUI.edit_type.UVI:
                            groupJump.type = hmUI.data_type.UVI;
                            break;
                        case hmUI.edit_type.WIND:
                            groupJump.type = hmUI.data_type.WIND;
                            break;
                        case hmUI.edit_type.FAT_BURN:
                            groupJump.type = hmUI.data_type.FAT_BURNING;
                            break;
                    }
                    return groupJump.type;
                }
                function jumpApp(x, y, type, w = 100, h = 100) {
                    hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                        x, y, w, h, type,//type必写 跳转的action
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });
                }
                //-----------------跳转应用执行----------------
                jumpApp(190, 74, fn(editType));
                jumpApp(71, 190, fn(editType1));
                jumpApp(190, 304, fn(editType2));

            },

            onInit() {
                console.log('index page.js on init invoke');

                this.init_view();
            },

            onReady() {
                console.log('index page.js on ready invoke');
            },

            onShow() {
                console.log('index page.js on show invoke');
            },

            onHide() {
                console.log('index page.js on hide invoke');
            },

            onDestory() {
                console.log('index page.js on destory invoke');
            },
        });
        /*
         * end js
         */
    })();
} catch (e) {
    console.log(e);
}
﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (()=>{
        //dynamic modify start

        const lang = DeviceRuntimeCore.HmUtils.getLanguage()
        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_fat_burning_pointer_progress_img_pointer = ''
        let normal_fat_burning_current_text_img = ''
        let normal_fat_burning_current_separator_img = ''
        let normal_stand_pointer_progress_img_pointer = ''
        let normal_stand_target_text_img = ''
        let normal_stand_current_text_img = ''
        let normal_stand_current_separator_img = ''
        let normal_stress_pointer_progress_img_pointer = ''
        let normal_stress_text_text_img = ''
        let normal_stress_text_separator_img = ''
        let normal_heart_rate_pointer_progress_img_pointer = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_text_separator_img = ''
        let normal_calorie_pointer_progress_img_pointer = ''
        let normal_calorie_current_text_img = ''
        let normal_calorie_current_separator_img = ''
        let normal_step_pointer_progress_img_pointer = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_date_img_date_month_img = ''
		let normal_date_img_date_month_img_1 = ''
        let normal_date_img_date_week_img = ''
		let normal_date_img_date_week_img_1 = ''
        let normal_date_img_date_day = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg_img = ''
        let idle_battery_pointer_progress_img_pointer = ''
        let idle_battery_text_text_img = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_day = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let normal_step_jumpable_img_click = ''
        let normal_cal_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_stand_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_stress_jumpable_img_click = ''
        let normal_fatBurning_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
		
		let cc = 0
		
		let element_index = 0; 
        let element_count = 6;
		
		function click_PLUS() {
			element_index = (element_index + 1) % element_count;
			apply_content_switch();
		}
		
		function click_MINUS() {
			if (element_index == 0) {
			element_index = element_count - 1;
				} else {
			element_index = (element_index - 1) % element_count;
				}	
			apply_content_switch();
		}

		function apply_content_switch() {

			  normal_step_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, element_index == 0);
			  normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, element_index == 0);
			  normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, element_index == 0);
			  normal_step_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, element_index == 0);

              normal_calorie_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, element_index == 1);
			  normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, element_index == 1);
			  normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, element_index == 1);
			  normal_cal_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, element_index == 1);
			  
			  normal_heart_rate_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, element_index == 2);
			  normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, element_index == 2);
			  normal_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, element_index == 2);
			  normal_heart_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, element_index == 2);
			  
			  normal_stress_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, element_index == 3);
			  normal_stress_text_text_img.setProperty(hmUI.prop.VISIBLE, element_index == 3);
			  normal_stress_text_separator_img.setProperty(hmUI.prop.VISIBLE, element_index == 3);
			  normal_stress_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, element_index == 3);
			  
			  normal_stand_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, element_index == 4);
			  normal_stand_target_text_img.setProperty(hmUI.prop.VISIBLE, element_index == 4);
			  normal_stand_current_text_img.setProperty(hmUI.prop.VISIBLE, element_index == 4);
			  normal_stand_current_separator_img.setProperty(hmUI.prop.VISIBLE, element_index == 4);
			  normal_stand_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, element_index == 4);
			  
			  normal_fat_burning_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, element_index == 5);
			  normal_fat_burning_current_text_img.setProperty(hmUI.prop.VISIBLE, element_index == 5);
			  normal_fat_burning_current_separator_img.setProperty(hmUI.prop.VISIBLE, element_index == 5);
			  normal_fatBurning_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, element_index == 5);
        };
		
		let btn_zona1 = ''
        let zona1_num = 0
        let zona1_all = 1
		
		function click_zona1() {
		  zona1_num = (zona1_num + 1) % (zona1_all + 1);
          if (zona1_num == 0) {		
		    normal_date_img_date_month_img.setProperty(hmUI.prop.VISIBLE, true);
            normal_date_img_date_week_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_date_img_date_month_img_1.setProperty(hmUI.prop.VISIBLE, false);
			normal_date_img_date_week_img_1.setProperty(hmUI.prop.VISIBLE, false);
		    hmUI.showToast({
            });
          };
		  
		 if (zona1_num == 1) {
			normal_date_img_date_month_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_date_img_date_week_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_date_img_date_month_img_1.setProperty(hmUI.prop.VISIBLE, true);
			normal_date_img_date_week_img_1.setProperty(hmUI.prop.VISIBLE, true);
		    hmUI.showToast({
            });
          };
        }


        //dynamic modify end
        const e = __$$hmAppManager$$__.currentApp;
        const o = e.current
          , {px: i} = (new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(e,o)),
        e.__globals__)
          , n = Logger.getLogger("watchface6");
        o.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'A100_086.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 127,
              y: 226,
              src: 'bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 325,
              y: 226,
              src: 'clock.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_fat_burning_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'A100_097.png',
              center_x: 240,
              center_y: 360,
              x: 10,
              y: 64,
              start_angle: -135,
              end_angle: 135,
              invalid_visible: false,
              type: hmUI.data_type.FAT_BURNING,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_fat_burning_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 200,
              y: 345,
              font_array: ["A100_020.png","A100_021.png","A100_022.png","A100_023.png","A100_024.png","A100_025.png","A100_026.png","A100_027.png","A100_028.png","A100_029.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.FAT_BURNING,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_fat_burning_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 229,
              y: 390,
              src: 'A100_050.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'A100_097.png',
              center_x: 240,
              center_y: 360,
              x: 10,
              y: 64,
              start_angle: -135,
              end_angle: 135,
              invalid_visible: false,
              type: hmUI.data_type.STAND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_target_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 242,
              y: 348,
              font_array: ["A100_034.png","A100_035.png","A100_036.png","A100_037.png","A100_038.png","A100_039.png","A100_040.png","A100_041.png","A100_042.png","A100_043.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STAND_TARGET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 154,
              y: 348,
              font_array: ["A100_034.png","A100_035.png","A100_036.png","A100_037.png","A100_038.png","A100_039.png","A100_040.png","A100_041.png","A100_042.png","A100_043.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'A100_044.png',
              unit_tc: 'A100_044.png',
              unit_en: 'A100_044.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STAND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 228,
              y: 390,
              src: 'A100_049.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'A100_097.png',
              center_x: 240,
              center_y: 360,
              x: 10,
              y: 64,
              start_angle: -135,
              end_angle: 135,
              invalid_visible: false,
              type: hmUI.data_type.STRESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 202,
              y: 344,
              font_array: ["A100_020.png","A100_021.png","A100_022.png","A100_023.png","A100_024.png","A100_025.png","A100_026.png","A100_027.png","A100_028.png","A100_029.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STRESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 229,
              y: 390,
              src: 'A100_048.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'A100_097.png',
              center_x: 240,
              center_y: 360,
              x: 10,
              y: 64,
              start_angle: -135,
              end_angle: 135,
              invalid_visible: false,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 201,
              y: 345,
              font_array: ["A100_020.png","A100_021.png","A100_022.png","A100_023.png","A100_024.png","A100_025.png","A100_026.png","A100_027.png","A100_028.png","A100_029.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 229,
              y: 390,
              src: 'A100_047.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'A100_097.png',
              center_x: 240,
              center_y: 360,
              x: 10,
              y: 64,
              start_angle: -135,
              end_angle: 135,
              invalid_visible: false,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 201,
              y: 348,
              font_array: ["A100_034.png","A100_035.png","A100_036.png","A100_037.png","A100_038.png","A100_039.png","A100_040.png","A100_041.png","A100_042.png","A100_043.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 229,
              y: 390,
              src: 'A100_046.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'A100_097.png',
              center_x: 240,
              center_y: 360,
              x: 10,
              y: 64,
              start_angle: -135,
              end_angle: 135,
              invalid_visible: false,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 191,
              y: 348,
              font_array: ["A100_034.png","A100_035.png","A100_036.png","A100_037.png","A100_038.png","A100_039.png","A100_040.png","A100_041.png","A100_042.png","A100_043.png"],
              padding: false,
              h_space: -1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 229,
              y: 390,
              src: 'A100_045.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 190,
              month_startY: 175,
              month_sc_array: ["m_0.png","m_1.png","m_2.png","m_3.png","m_4.png","m_5.png","m_6.png","m_7.png","m_8.png","m_9.png","m_10.png","m_11.png"],
              month_tc_array: ["m_0.png","m_1.png","m_2.png","m_3.png","m_4.png","m_5.png","m_6.png","m_7.png","m_8.png","m_9.png","m_10.png","m_11.png"],
              month_en_array: ["m_0.png","m_1.png","m_2.png","m_3.png","m_4.png","m_5.png","m_6.png","m_7.png","m_8.png","m_9.png","m_10.png","m_11.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			normal_date_img_date_month_img_1 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 190,
              month_startY: 173,
              month_sc_array: ["mru_0.png","mru_1.png","mru_2.png","mru_3.png","mru_4.png","mru_5.png","mru_6.png","mru_7.png","mru_8.png","mru_9.png","mru_10.png","mru_11.png"],
              month_tc_array: ["mru_0.png","mru_1.png","mru_2.png","mru_3.png","mru_4.png","mru_5.png","mru_6.png","mru_7.png","mru_8.png","mru_9.png","mru_10.png","mru_11.png"],
              month_en_array: ["mru_0.png","mru_1.png","mru_2.png","mru_3.png","mru_4.png","mru_5.png","mru_6.png","mru_7.png","mru_8.png","mru_9.png","mru_10.png","mru_11.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 205,
              y: 140,
              week_en: ["week_0.png","week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png"],
              week_tc: ["week_0.png","week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png"],
              week_sc: ["week_0.png","week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			normal_date_img_date_week_img_1 = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 205,
              y: 140,
              week_en: ["weekru_0.png","weekru_1.png","weekru_2.png","weekru_3.png","weekru_4.png","weekru_5.png","weekru_6.png"],
              week_tc: ["weekru_0.png","weekru_1.png","weekru_2.png","weekru_3.png","weekru_4.png","weekru_5.png","weekru_6.png"],
              week_sc: ["weekru_0.png","weekru_1.png","weekru_2.png","weekru_3.png","weekru_4.png","weekru_5.png","weekru_6.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 216,
              day_startY: 105,
              day_sc_array: ["A100_010.png","A100_011.png","A100_012.png","A100_013.png","A100_014.png","A100_015.png","A100_016.png","A100_017.png","A100_018.png","A100_019.png"],
              day_tc_array: ["A100_010.png","A100_011.png","A100_012.png","A100_013.png","A100_014.png","A100_015.png","A100_016.png","A100_017.png","A100_018.png","A100_019.png"],
              day_en_array: ["A100_010.png","A100_011.png","A100_012.png","A100_013.png","A100_014.png","A100_015.png","A100_016.png","A100_017.png","A100_018.png","A100_019.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'A100_051.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 10,
              hour_posY: 114,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'A100_052.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 19,
              minute_posY: 186,
              minute_cover_path: 'A100_054.png',
              minute_cover_x: 220,
              minute_cover_y: 221,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'A100_053.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 14,
              second_posY: 209,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'A100_087.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'A100_097.png',
              center_x: 240,
              center_y: 360,
              x: 10,
              y: 64,
              start_angle: -135,
              end_angle: 135,
              invalid_visible: false,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 205,
              y: 346,
              font_array: ["A100_010.png","A100_011.png","A100_012.png","A100_013.png","A100_014.png","A100_015.png","A100_016.png","A100_017.png","A100_018.png","A100_019.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });
			
			let dmonth=["m_0.png","m_1.png","m_2.png","m_3.png","m_4.png","m_5.png","m_6.png","m_7.png","m_8.png","m_9.png","m_10.png","m_11.png"]
			if(lang=='ru-RU'){
				dmonth=["mru_0.png","mru_1.png","mru_2.png","mru_3.png","mru_4.png","mru_5.png","mru_6.png","mru_7.png","mru_8.png","mru_9.png","mru_10.png","mru_11.png"]
			}
            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 190,
              month_startY: 175,
              month_sc_array: ["m_0.png","m_1.png","m_2.png","m_3.png","m_4.png","m_5.png","m_6.png","m_7.png","m_8.png","m_9.png","m_10.png","m_11.png"],
              month_tc_array: ["m_0.png","m_1.png","m_2.png","m_3.png","m_4.png","m_5.png","m_6.png","m_7.png","m_8.png","m_9.png","m_10.png","m_11.png"],
              month_en_array: dmonth,
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });
			
			let dned=["week_0.png","week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png"]
			if(lang=='ru-RU'){
				dned=["weekru_0.png","weekru_1.png","weekru_2.png","weekru_3.png","weekru_4.png","weekru_5.png","weekru_6.png"]
			}
            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 205,
              y: 143,
              week_en: dned,
              week_tc: ["week_0.png","week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png"],
              week_sc: ["week_0.png","week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 216,
              day_startY: 110,
              day_sc_array: ["A100_010.png","A100_011.png","A100_012.png","A100_013.png","A100_014.png","A100_015.png","A100_016.png","A100_017.png","A100_018.png","A100_019.png"],
              day_tc_array: ["A100_010.png","A100_011.png","A100_012.png","A100_013.png","A100_014.png","A100_015.png","A100_016.png","A100_017.png","A100_018.png","A100_019.png"],
              day_en_array: ["A100_010.png","A100_011.png","A100_012.png","A100_013.png","A100_014.png","A100_015.png","A100_016.png","A100_017.png","A100_018.png","A100_019.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'A100_051.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 10,
              hour_posY: 114,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'A100_052.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 19,
              minute_posY: 186,
              minute_cover_path: 'A100_057.png',
              minute_cover_x: 220,
              minute_cover_y: 221,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 202,
              y: 325,
              w: 75,
              h: 75,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_cal_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 202,
              y: 325,
              w: 75,
              h: 75,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 202,
              y: 325,
              w: 75,
              h: 75,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 202,
              y: 325,
              w: 75,
              h: 75,
              type: hmUI.data_type.STAND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            btn_zona1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 192,
              y: 105,
              text: '',
              w: 100,
              h: 90,
              normal_src: 'Empty.png',
              press_src: 'Empty.png',
              click_func: () => {
				click_zona1();
             },
			  longpress_func: () => {
             hmApp.startApp({ url: "ScheduleCalScreen", native: true });
             },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btn_zona1.setProperty(hmUI.prop.VISIBLE, true);
			normal_date_img_date_month_img_1.setProperty(hmUI.prop.VISIBLE, false);
			normal_date_img_date_week_img_1.setProperty(hmUI.prop.VISIBLE, false);

            normal_stress_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 202,
              y: 325,
              w: 75,
              h: 75,
              type: hmUI.data_type.STRESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_fatBurning_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 202,
              y: 325,
              w: 75,
              h: 75,
              type: hmUI.data_type.FAT_BURNING,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 300,
              y: 337,
              w: 60,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                click_PLUS();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 120,
              y: 337,
              w: 60,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                click_MINUS();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button
			
			if (cc ==0 ){
			  
			  normal_calorie_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			  normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			  normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			  normal_cal_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);

              normal_heart_rate_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			  normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			  normal_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			  normal_heart_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
			  
			  normal_stress_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			  normal_stress_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			  normal_stress_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			  normal_stress_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
			  
			  normal_stand_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			  normal_stand_target_text_img.setProperty(hmUI.prop.VISIBLE, false);
			  normal_stand_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			  normal_stand_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			  normal_stand_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
			  
			  normal_fat_burning_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			  normal_fat_burning_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			  normal_fat_burning_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			  normal_fatBurning_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
			cc = 1;
			}


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
﻿/*
** Watch_Face_Editor tool
** watchface js version v2.1.1
** Copyright © SashaCX75. All Rights Reserved
*/

try {
(() => {
    //start of ignored block
    const __$$app$$__ = __$$hmAppManager$$__.currentApp;
    function getApp() {
        return __$$app$$__.app;
    }
    function getCurrentPage() {
        return __$$app$$__.current && __$$app$$__.current.module;
    }
    const __$$module$$__ = __$$app$$__.current;
    const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
    const {px} = __$$app$$__.__globals__;
    //const logger = Logger.getLogger('watchface_SashaCX75');
    const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
    //end of ignored block

    //dynamic modify start
    let btn_bezel = ''
    let bezel_num = 1
    let bezel_all = 7  
    let btn_bezel1 = ''
    let bezel_num1 = 1
    let bezel_all1 = 7  
    let bezel_num2 = 1
    let bezel_all2 = 3     
    let element_index = 1;  // Selected element index
    let element_count = 2;  // Number of elements          
    
    let normal_background_bg_img = ''
    let normal_analog_clock_pro_second_pointerR_img = ''
    let normal_image_img = ''
    let normal_system_disconnect_img = ''
    let normal_system_clock_img = ''
    let normal_moon_icon_img = ''
    let normal_altimeter_icon_img = ''
    let normal_step_icon_img = ''
    let normal_step_image_progress_img_level = ''
    let normal_step_current_text_font = ''
    let normal_weather_image_progress_img_level = ''
    let normal_temperature_current_text_font = ''
    let normal_heart_rate_text_font = ''
    let normal_battery_image_progress_img_level = ''
    let normal_battery_current_text_font = ''
    let normal_dow_text_font = ''
    let normal_DOW_Array = ['Пнд', 'Втр', 'Срд', 'Чтв', 'Птн', 'Сбт', 'Вск'];
    let normal_day_text_font = ''
    let normal_analog_clock_pro_hour_pointer_img = ''
    let normal_analog_clock_pro_minute_pointer_img = ''
    let normal_analog_clock_pro_second_pointer_img = ''
    let normal_timerUpdateSec = undefined;
    let idle_background_bg_img = ''
    let idle_image_img = ''
    let idle_analog_clock_pro_hour_pointer_img = ''
    let idle_analog_clock_pro_minute_pointer_img = ''
    let normal_step_jumpable_img_click = ''
    let normal_heart_jumpable_img_click = ''
    let normal_battery_jumpable_img_click = ''
    let normal_temperature_jumpable_img_click = ''
    let normal_countdown_jumpable_img_click = ''
    let normal_stopwatch_jumpable_img_click = ''
    let normal_alarm_jumpable_img_click = ''
    let normal_sleep_jumpable_img_click = ''
    let Button_1 = ''
    let timeSensor = '';


    //dynamic modify end

    __$$module$$__.module = DeviceRuntimeCore.WatchFace({
        init_view() {
            //dynamic modify start
        function click_Bezel() {
          if(bezel_num>=bezel_all) {bezel_num=1;}
          else { bezel_num=bezel_num+1;}
          hmUI.showToast({text: "Цвет " + parseInt(bezel_num) });
            normal_background_bg_img.setProperty(hmUI.prop.SRC, "osn_" + parseInt(bezel_num) + ".png");
            normal_altimeter_icon_img.setProperty(hmUI.prop.SRC, "osnActiv_" + parseInt(bezel_num) + ".png");

        } 

        function click_Bezel1() {
          if(bezel_num1>=bezel_all1) {bezel_num1=1;}
          else { bezel_num1=bezel_num1+1;}
          hmUI.showToast({text: "Стрелки " + parseInt(bezel_num1) });
            normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.SRC, "hour_" + parseInt(bezel_num1) + ".png");
            normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.SRC, "minn_" + parseInt(bezel_num1) + ".png");

        }      

        function click_Bezel2() {
          if(bezel_num2>=bezel_all2) {bezel_num2=1;}
          else { bezel_num2=bezel_num2+1;}
          hmUI.showToast({text: "Безель " + parseInt(bezel_num2) });
            normal_image_img.setProperty(hmUI.prop.SRC, "zapl_" + parseInt(bezel_num2) + ".png");
            normal_moon_icon_img.setProperty(hmUI.prop.SRC, "zapl_centr_" + parseInt(bezel_num2) + ".png");

        }         
        
        //click zona     

        function click_btn() {  // Function to enable and disable the visibility of elements
          element_index++;
          if(element_index > element_count) element_index = 1;                    
          normal_moon_icon_img.setProperty(hmUI.prop.VISIBLE, element_index == 1);
          normal_altimeter_icon_img.setProperty(hmUI.prop.VISIBLE, element_index == 2);
          normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, element_index == 2);
          normal_step_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, element_index == 2);
          normal_step_current_text_font.setProperty(hmUI.prop.VISIBLE, element_index == 2);
          normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, element_index == 2);
          normal_temperature_current_text_font.setProperty(hmUI.prop.VISIBLE, element_index == 2);
          normal_heart_rate_text_font.setProperty(hmUI.prop.VISIBLE, element_index == 2);
          normal_battery_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, element_index == 2);
          normal_battery_current_text_font.setProperty(hmUI.prop.VISIBLE, element_index == 2);
          normal_dow_text_font.setProperty(hmUI.prop.VISIBLE, element_index == 2);
          normal_day_text_font.setProperty(hmUI.prop.VISIBLE, element_index == 2);              

          if (element_index == 1) {
            hmUI.showToast({text: 'Вид 1'});
          };
          if (element_index == 2) {
            hmUI.showToast({text: 'Вид 2'});
          };
        };


        //end click zona               
            
        // FontName: Netflix.ttf; FontSize: 45
        hmUI.createWidget(hmUI.widget.TEXT, {
          x: 478,
          y: 478,
          w: 471,
          h: 60,
          text_size: 45,
          char_space: 0,
          line_space: 0,
          font: 'fonts/Netflix.ttf',
          color: 0xFFFFFFFF,
          align_h: hmUI.align.CENTER_H,
          align_v: hmUI.align.TOP,
          text_style: hmUI.text_style.ELLIPSIS,
          text: "0123456789 _-.,:;`'%°\\/",
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        // FontName: Netflix.ttf; FontSize: 24
        hmUI.createWidget(hmUI.widget.TEXT, {
          x: 478,
          y: 478,
          w: 262,
          h: 32,
          text_size: 24,
          char_space: 0,
          line_space: 0,
          font: 'fonts/Netflix.ttf',
          color: 0xFFFFFFFF,
          align_h: hmUI.align.CENTER_H,
          align_v: hmUI.align.TOP,
          text_style: hmUI.text_style.ELLIPSIS,
          text: "0123456789 _-.,:;`'%°\\/",
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        // FontName: Netflix.ttf; FontSize: 30
        hmUI.createWidget(hmUI.widget.TEXT, {
          x: 478,
          y: 478,
          w: 310,
          h: 39,
          text_size: 30,
          char_space: 0,
          line_space: 0,
          font: 'fonts/Netflix.ttf',
          color: 0xFFFFFFFF,
          align_h: hmUI.align.CENTER_H,
          align_v: hmUI.align.TOP,
          text_style: hmUI.text_style.ELLIPSIS,
          text: "0123456789 _-.,:;`'%°\\/",
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        // FontName: Netflix.ttf; FontSize: 35
        hmUI.createWidget(hmUI.widget.TEXT, {
          x: 478,
          y: 478,
          w: 361,
          h: 45,
          text_size: 35,
          char_space: 0,
          line_space: 0,
          font: 'fonts/Netflix.ttf',
          color: 0xFFFFFFFF,
          align_h: hmUI.align.CENTER_H,
          align_v: hmUI.align.TOP,
          text_style: hmUI.text_style.ELLIPSIS,
          text: "0123456789 _-.,:;`'%°\\/",
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        // FontName: Netflix.ttf; FontSize: 30; Cache: full
        hmUI.createWidget(hmUI.widget.TEXT, {
          x: 478,
          y: 478,
          w: 36,
          h: 36,
          text_size: 30,
          char_space: 0,
          line_space: 0,
          font: 'fonts/Netflix.ttf',
          color: 0xFFFFFFFF,
          align_h: hmUI.align.LEFT,
          align_v: hmUI.align.TOP,
          text_style: hmUI.text_style.NONE,
          text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІ Їґєії _-.,:;`'%°\\/",
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        const deviceInfo = hmSetting.getDeviceInfo();

        console.log('Watch_Face.ScreenNormal');
        normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          w: 480,
          h: 480,
          src: 'osn_1.png',
          show_level: hmUI.show_level.ONLY_NORMAL,
        });


        normal_analog_clock_pro_second_pointerR_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          w: deviceInfo.width,
          h: deviceInfo.height,
          pos_x: 240 - 240,
          pos_y: 240 - 239,
          center_x: 240,
          center_y: 240,
          src: 'sekk_centr.png',
          angle: 0,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });            

        normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          src: 'zapl_1.png',
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
          x: 0,
          y: 0,
          src: 'bt_off.png',
          type: hmUI.system_status.DISCONNECT,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_system_disconnect_img.setAlpha(150);

        normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
          x: 122,
          y: 121,
          src: 'alarm.png',
          type: hmUI.system_status.CLOCK,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_system_clock_img.setAlpha(150);

        normal_moon_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          src: 'zapl_centr_1.png',
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        normal_moon_icon_img.setProperty(hmUI.prop.VISIBLE, false);  // Disable element display 

        normal_altimeter_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          src: 'osnActiv_1.png',
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        normal_altimeter_icon_img.setProperty(hmUI.prop.VISIBLE, false);  // Disable element display 

        normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          src: 'zapl_activ.png',
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, false);  // Disable element display

        normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
          x: 0,
          y: 0,
          image_array: ["shag_0.png","shag_1.png","shag_2.png","shag_3.png","shag_4.png","shag_5.png","shag_6.png","shag_7.png","shag_8.png","shag_9.png","shag_10.png","shag_11.png","shag_12.png"],
          image_length: 13,
          type: hmUI.data_type.STEP,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        normal_step_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);  // Disable element display

        normal_step_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
          x: 223,
          y: 333,
          w: 180,
          h: 55,
          text_size: 45,
          char_space: 0,
          font: 'fonts/Netflix.ttf',
          color: 0xFFFFFFFF,
          line_space: 0,
          align_v: hmUI.align.TOP,
          text_style: hmUI.text_style.ELLIPSIS,
          align_h: hmUI.align.CENTER_H,
          type: hmUI.data_type.STEP,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        normal_step_current_text_font.setProperty(hmUI.prop.VISIBLE, false);  // Disable element display

        normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
          x: 270,
          y: 265,
          image_array: ["0090.png","0091.png","0092.png","0093.png","0094.png","0095.png","0096.png","0097.png","0098.png","0099.png","0100.png","0101.png","0102.png","0103.png","0104.png","0105.png","0106.png","0107.png","0108.png","0109.png","0110.png","0111.png","0112.png","0113.png","0114.png","0115.png","0116.png","0117.png","0118.png"],
          image_length: 29,
          type: hmUI.data_type.WEATHER_CURRENT,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);  // Disable element display

        normal_temperature_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
          x: 240,
          y: 268,
          w: 150,
          h: 30,
          text_size: 24,
          char_space: 0,
          font: 'fonts/Netflix.ttf',
          color: 0xFFFFFFFF,
          line_space: 0,
          align_v: hmUI.align.TOP,
          text_style: hmUI.text_style.ELLIPSIS,
          align_h: hmUI.align.CENTER_H,
          unit_type: 1,
          type: hmUI.data_type.WEATHER_CURRENT,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        normal_temperature_current_text_font.setProperty(hmUI.prop.VISIBLE, false);  // Disable element display

        normal_heart_rate_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
          x: 227,
          y: 388,
          w: 150,
          h: 50,
          text_size: 30,
          char_space: 0,
          font: 'fonts/Netflix.ttf',
          color: 0xFFFFFFFF,
          line_space: 0,
          align_v: hmUI.align.TOP,
          text_style: hmUI.text_style.ELLIPSIS,
          align_h: hmUI.align.CENTER_H,
          type: hmUI.data_type.HEART,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        normal_heart_rate_text_font.setProperty(hmUI.prop.VISIBLE, false);  // Disable element display

        normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
          x: 0,
          y: 0,
          image_array: ["zar_0.png","zar_1.png","zar_2.png","zar_3.png","zar_4.png","zar_5.png","zar_6.png","zar_7.png","zar_8.png","zar_9.png","zar_10.png"],
          image_length: 11,
          type: hmUI.data_type.BATTERY,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        normal_battery_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);  // Disable element display

        normal_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
          x: 305,
          y: 227,
          w: 150,
          h: 50,
          text_size: 35,
          char_space: 0,
          font: 'fonts/Netflix.ttf',
          color: 0xFFFFFFFF,
          line_space: 0,
          align_v: hmUI.align.TOP,
          text_style: hmUI.text_style.ELLIPSIS,
          align_h: hmUI.align.CENTER_H,
          type: hmUI.data_type.BATTERY,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        normal_battery_current_text_font.setProperty(hmUI.prop.VISIBLE, false);  // Disable element display

        if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
        timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function() {
          time_update(true);
        });

        normal_dow_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
          x: 299,
          y: 295,
          w: 150,
          h: 50,
          text_size: 30,
          char_space: 0,
          font: 'fonts/Netflix.ttf',
          color: 0xFFFFFFFF,
          line_space: 0,
          align_v: hmUI.align.TOP,
          text_style: hmUI.text_style.ELLIPSIS,
          align_h: hmUI.align.LEFT,
          // unit_string: Пнд, Втр, Срд, Чтв, Птн, Сбт, Вск,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        normal_dow_text_font.setProperty(hmUI.prop.VISIBLE, false);  // Disable element display

        normal_day_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
          x: 133,
          y: 295,
          w: 150,
          h: 50,
          text_size: 30,
          char_space: 0,
          font: 'fonts/Netflix.ttf',
          color: 0xFFFFFFFF,
          line_space: 0,
          align_v: hmUI.align.TOP,
          text_style: hmUI.text_style.ELLIPSIS,
          align_h: hmUI.align.RIGHT,
          // padding: true,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        normal_day_text_font.setProperty(hmUI.prop.VISIBLE, false);  // Disable element display

        timeSensor.addEventListener(timeSensor.event.MINUTEEND, function() {
          let updateHour = timeSensor.minute == 0;

          time_update(updateHour, true);
        });

        normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          w: deviceInfo.width,
          h: deviceInfo.height,
          pos_x: 240 - 19,
          pos_y: 240 - 135,
          center_x: 240,
          center_y: 240,
          src: 'hour_1.png',
          angle: 0,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          w: deviceInfo.width,
          h: deviceInfo.height,
          pos_x: 240 - 33,
          pos_y: 240 - 215,
          center_x: 240,
          center_y: 240,
          src: 'minn_1.png',
          angle: 0,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          w: deviceInfo.width,
          h: deviceInfo.height,
          pos_x: 240 - 18,
          pos_y: 240 - 224,
          center_x: 240,
          center_y: 240,
          src: 'sekk_1.png',
          angle: 0,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        let screenType = hmSetting.getScreenType();

        console.log('Watch_Face.ScreenAOD');
        idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          w: 480,
          h: 480,
          src: 'osn_AOD.png',
          show_level: hmUI.show_level.ONLY_AOD,
        });

        idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          src: 'zapl_AOD.png',
          show_level: hmUI.show_level.ONLY_AOD,
        });

        idle_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          w: deviceInfo.width,
          h: deviceInfo.height,
          pos_x: 240 - 19,
          pos_y: 240 - 135,
          center_x: 240,
          center_y: 240,
          src: 'hour_6.png',
          angle: 0,
          show_level: hmUI.show_level.ONLY_AOD,
        });

        idle_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          w: deviceInfo.width,
          h: deviceInfo.height,
          pos_x: 240 - 33,
          pos_y: 240 - 215,
          center_x: 240,
          center_y: 240,
          src: 'minn_6.png',
          angle: 0,
          show_level: hmUI.show_level.ONLY_AOD,
        });
        console.log('Watch_Face.Shortcuts');

        normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
          x: 266,
          y: 328,
          w: 100,
          h: 46,
          type: hmUI.data_type.STEP,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
          x: 266,
          y: 380,
          w: 100,
          h: 44,
          type: hmUI.data_type.HEART,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
          x: 351,
          y: 212,
          w: 60,
          h: 60,
          type: hmUI.data_type.BATTERY,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
          x: 280,
          y: 257,
          w: 66,
          h: 35,
          type: hmUI.data_type.WEATHER_CURRENT,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
          x: 61,
          y: 295,
          w: 60,
          h: 60,
          type: hmUI.data_type.COUNT_DOWN,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
          x: 125,
          y: 358,
          w: 60,
          h: 60,
          type: hmUI.data_type.STOP_WATCH,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
          x: 55,
          y: 121,
          w: 60,
          h: 60,
          type: hmUI.data_type.ALARM_CLOCK,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_sleep_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
          x: 119,
          y: 59,
          w: 60,
          h: 60,
          type: hmUI.data_type.SLEEP,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        console.log('Watch_Face.Buttons');
        Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
          x: 266,
          y: 295,
          w: 100,
          h: 29,
          text: '',
          color: 0xFFFF8C00,
          text_size: 25,
          press_src: 'clean.png',
          normal_src: 'clean.png',
          click_func: (button_widget) => {
            hmApp.startApp({url: 'ScheduleCalScreen', native: true });
          }, // end func
          show_level: hmUI.show_level.ONLY_NORMAL,
        }); // end button

        btn_bezel = hmUI.createWidget(hmUI.widget.BUTTON, {
          x: 46,
          y: 212,
          text: '',
          w: 60,
          h: 60,
          normal_src: 'clean.png',
          press_src: 'clean.png',
          click_func: () => {
           click_Bezel();
           
          },
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        btn_bezel.setProperty(hmUI.prop.VISIBLE, true);      
        
        btn_bezel1 = hmUI.createWidget(hmUI.widget.BUTTON, {
          x: 205,
          y: 212,
          text: '',
          w: 60,
          h: 60,
          normal_src: 'clean.png',
          press_src: 'clean.png',
          click_func: () => {
           click_Bezel1();
           
          },
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        btn_bezel1.setProperty(hmUI.prop.VISIBLE, true);     

        btn_bezel2 = hmUI.createWidget(hmUI.widget.BUTTON, {
          x: 358,
          y: 127,
          text: '',
          w: 60,
          h: 60,
          normal_src: 'clean.png',
          press_src: 'clean.png',
          click_func: () => {
           click_Bezel2();
           
          },
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        btn_bezel1.setProperty(hmUI.prop.VISIBLE, true);          
        
        // Button to switch elements. This block should be after all blocks with display elements.
        hmUI.createWidget(hmUI.widget.BUTTON, {
          x: 419,  // x coordinate of the button
          y: 208,  // y coordinate of the button
          text: '',
          w: 60,  // button width
          h: 60,  // button height
          normal_src: 'clean.png',  // transparent image
          press_src: 'clean.png',  // transparent image
          show_level: hmUI.show_level.ONLY_NORMAL,
          click_func: () => {
            click_btn();
          }
        });
        // end button             

        //#region time_update
        function time_update(updateHour = false, updateMinute = false) {
          console.log('time_update()');
          let hour = timeSensor.hour;
          let minute = timeSensor.minute;
          let second = timeSensor.second;
          let format_hour = timeSensor.format_hour;

          console.log('day of week font');
          if (updateHour) {
            let normal_DOW_Str = normal_DOW_Array[timeSensor.week-1];
            normal_dow_text_font.setProperty(hmUI.prop.TEXT, normal_DOW_Str );
          };

          console.log('day font');
          if (updateHour) {
            let normal_dayStr = timeSensor.day.toString();
            normal_dayStr = normal_dayStr.padStart(2, '0');
            normal_day_text_font.setProperty(hmUI.prop.TEXT, normal_dayStr );
          };

          if (updateMinute) { // Hour Pointer
            let normal_hour = hour;
            let normal_fullAngle_hour = 360;
            if (normal_hour > 11) normal_hour -= 12;
            let normal_angle_hour = 0 + normal_fullAngle_hour*normal_hour/12 + (normal_fullAngle_hour/12)*minute/60;
            if (normal_analog_clock_pro_hour_pointer_img) normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_hour);
          };

          if (updateMinute) { // Minute Pointer
            let normal_fullAngle_minute = 360;
            let normal_angle_minute = 0 + normal_fullAngle_minute*minute/60;
            if (normal_analog_clock_pro_minute_pointer_img) normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_minute);
          };

          // Second Pointer (original, clockwise)
          let normal_fullAngle_second = 360;
          let normal_angle_second = 0 + normal_fullAngle_second*second/60;
          if (normal_analog_clock_pro_second_pointer_img) normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_second);

          // Second Pointer Reverse (counter-clockwise, synced)
          let reverse_angle = (360 - normal_angle_second) % 360;
          if (normal_analog_clock_pro_second_pointerR_img) normal_analog_clock_pro_second_pointerR_img.setProperty(hmUI.prop.ANGLE, reverse_angle);

          if (updateMinute) { // Hour Pointer
            let idle_hour = hour;
            let idle_fullAngle_hour = 360;
            if (idle_hour > 11) idle_hour -= 12;
            let idle_angle_hour = 0 + idle_fullAngle_hour*idle_hour/12 + (idle_fullAngle_hour/12)*minute/60;
            if (idle_analog_clock_pro_hour_pointer_img) idle_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.ANGLE, idle_angle_hour);
          };

          if (updateMinute) { // Minute Pointer
            let idle_fullAngle_minute = 360;
            let idle_angle_minute = 0 + idle_fullAngle_minute*minute/60;
            if (idle_analog_clock_pro_minute_pointer_img) idle_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.ANGLE, idle_angle_minute);
          };

        };

        //#endregion
        const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
          resume_call: (function () {
            console.log('resume_call()');
            time_update(true, true);
            if (screenType == hmSetting.screen_type.WATCHFACE) {
              if (!normal_timerUpdateSec) {
                let animDelay = timeSensor.utc % 1000;
                let animRepeat = 1000;
                normal_timerUpdateSec = timer.createTimer(animDelay, animRepeat, (function (option) {
                  time_update(false, false);
                }));  // end timer 
              };  // end timer check
            };  // end screenType


          }),
          pause_call: (function () {
            console.log('pause_call()');
            if (normal_timerUpdateSec) {
              timer.stopTimer(normal_timerUpdateSec);
              normal_timerUpdateSec = undefined;
            }

          }),
        });

            //dynamic modify end
        },
        onInit() {
            logger.log('index page.js on init invoke');
        },
        build() {
            this.init_view();
            logger.log('index page.js on ready invoke');
        },
        onDestroy() {
            logger.log('index page.js on destroy invoke');
        }
    });
    ;
})();
} catch (e) {
console.log('Mini Program Error', e);
e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
;
}
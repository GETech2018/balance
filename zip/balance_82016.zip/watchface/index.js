﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js
		let screenType = hmSetting.getScreenType();
        let colornumber_main = 1
        let totalcolors_main = 16
		let battstring = 'batt1.png'
		let secstring = 'hands_sec1.png'
		let colorstring = '0xFFFF8000'
		let savedScoreAOD = ''
		
		function click_COLOR() {
            if(colornumber_main>=totalcolors_main) {
            colornumber_main=1;
                }
            else {
                colornumber_main=colornumber_main+1;
            }
			if ( colornumber_main == 1) { 
				battstring = 'batt1.png'
				secstring = 'hands_sec1.png'
				colorstring = '0xFFFF8000'
				hmUI.showToast({text: 'O R A N G E'});
			}
			if ( colornumber_main == 2) {
				battstring = 'batt2.png'
				secstring = 'hands_sec2.png'
				colorstring = '0xFF008080'
				hmUI.showToast({text: 'T E A L'});
			}
			if ( colornumber_main == 3) {
				battstring = 'batt3.png'
				secstring = 'hands_sec3.png'
				colorstring = '0xFF808000'
				hmUI.showToast({text: 'O L I V E'});
			}
			if ( colornumber_main == 4) {
				battstring = 'batt4.png'
				secstring = 'hands_sec4.png'
				colorstring = '0xFF800000'
				hmUI.showToast({text: 'M A R O O N'});
			}
			if ( colornumber_main == 5) {
				battstring = 'batt5.png'
				secstring = 'hands_sec5.png'
				colorstring = '0xFF00FFFF'
				hmUI.showToast({text: 'A Q U A'});
			}
			if ( colornumber_main == 6) {
				battstring = 'batt6.png'
				secstring = 'hands_sec6.png'
				colorstring = '0xFF008000'
				hmUI.showToast({text: 'G R E E N'});
			}
			if ( colornumber_main == 7) {
				battstring = 'batt7.png'
				secstring = 'hands_sec7.png'
				colorstring = '0xFFFF0000'
				hmUI.showToast({text: 'R E D'});
			}
			if ( colornumber_main == 8) {
				battstring = 'batt8.png'
				secstring = 'hands_sec8.png'
				colorstring = '0xFFFFFF00'
				hmUI.showToast({text: 'Y E L L O W'});
			}
			if ( colornumber_main == 9) {
				battstring = 'batt9.png'
				secstring = 'hands_sec9.png'
				colorstring = '0xFFBFFF00'
				hmUI.showToast({text: 'L I M E'});
			}
			if ( colornumber_main == 10) {
				battstring = 'batt10.png'
				secstring = 'hands_sec10.png'
				colorstring = '0xFFA020F0'
				hmUI.showToast({text: 'P U R P L E'});
			}
			if ( colornumber_main == 11) {
				battstring = 'batt11.png'
				secstring = 'hands_sec11.png'
				colorstring = '0xFF0000FF'
				hmUI.showToast({text: 'B L U E'});
			}
			if ( colornumber_main == 12) {
				battstring = 'batt12.png'
				secstring = 'hands_sec12.png'
				colorstring = '0xFFFF00FF'
				hmUI.showToast({text: 'F U C H S I A'});
			}
			if ( colornumber_main == 13) {
				battstring = 'batt13.png'
				secstring = 'hands_sec13.png'
				colorstring = '0xFFA5694F'
				hmUI.showToast({text: 'S E P I A'});
			}
			if ( colornumber_main == 14) {
				battstring = 'batt14.png'
				secstring = 'hands_sec14.png'
				colorstring = '0xFFFFBF00'
				hmUI.showToast({text: 'A M B E R'});
			}
			if ( colornumber_main == 15) {
				battstring = 'batt15.png'
				secstring = 'hands_sec15.png'
				colorstring = '0xFFC0C0C0'
				hmUI.showToast({text: 'S I L V E R'});
			}
			if ( colornumber_main == 16) {
				battstring = 'batt16.png'
				secstring = 'hands_sec16.png'
				colorstring = '0xFFFFFFFF'
				hmUI.showToast({text: 'W H I T E'});
			}
			if ( colornumber_main <= 16) { 
			
            normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.MORE, {
              second_path: secstring,
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 240,
              second_posY: 240,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			normal_battery_pointer_progress_img_pointer.setProperty(hmUI.prop.MORE, {
              src: battstring,
              center_x: 240,
              center_y: 240,
              x: 240,
              y: 240,
              start_angle: 30,
              end_angle: -30,
              invalid_visible: false,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			normal_background_bg.setProperty(hmUI.prop.MORE, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: colorstring,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			}
			
			hmFS.SysProSetInt('userScore', colornumber_main);
            console.log(savedScoreAOD);   
			
			normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.SRC, "hands_hour" + parseInt(colornumber_main) + ".png");
			normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.SRC, "hands_min" + parseInt(colornumber_main) + ".png");
			normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.SRC, "hands_sec" + parseInt(colornumber_main) + ".png");
//			normal_battery_pointer_progress_img_pointer.setProperty(hmUI.prop.SRC, "batt" + parseInt(colornumber_main) + ".png");
			normal_stand_icon_img.setProperty(hmUI.prop.SRC, "hybrid" + parseInt(colornumber_main) + ".png");
		}
		
		let bgnumber = 1
        let totalbg = 2
		let savedScoreBG = ''
		
		function click_BG() {
            if(bgnumber>=totalbg) {
            bgnumber=1;
                }
            else {
                bgnumber=bgnumber+1;
            }
			hmFS.SysProSetInt('userBG', bgnumber);
            console.log(savedScoreBG);   
			
			normal_image_img.setProperty(hmUI.prop.SRC, "bg" + parseInt(bgnumber) + ".png");
		}
		
		let animnumber_1 = 1
        let total_anim = 2

        function click_MENU() {
            if(animnumber_1==total_anim) {
            animnumber_1=1;
                UpdateanimOne();
                }
            else {
                animnumber_1=animnumber_1+1;
                if(animnumber_1==2) {
                  UpdateanimTwo();
                }
            }
        }

        function UpdateanimOne(){
				normal_stress_icon_img.setProperty(hmUI.prop.VISIBLE, false);
				Button_10.setProperty(hmUI.prop.VISIBLE, false);
				Button_11.setProperty(hmUI.prop.VISIBLE, false);
        }

        function UpdateanimTwo(){
				 normal_stress_icon_img.setProperty(hmUI.prop.VISIBLE, true);
				 Button_10.setProperty(hmUI.prop.VISIBLE, true);
				 Button_11.setProperty(hmUI.prop.VISIBLE, true);
        }
		
		let hybnumber = 1
        let total_hyb = 2
		
		function click_HYBRID() {
            if(hybnumber==total_hyb) {
            hybnumber=1;
                UpdatehybOne();
                }
            else {
                hybnumber=hybnumber+1;
                if(hybnumber==2) {
                  UpdatehybTwo();
                }
            }
        }

        function UpdatehybOne(){
			normal_digital_clock_img_time.setProperty(hmUI.prop.VISIBLE, false);
			normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_temperature_low_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_temperature_high_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
			normal_date_img_date_month_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_stand_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			Button_1.setProperty(hmUI.prop.VISIBLE, false);
			Button_2.setProperty(hmUI.prop.VISIBLE, false);
			Button_3.setProperty(hmUI.prop.VISIBLE, false);
			Button_4.setProperty(hmUI.prop.VISIBLE, false);
			Button_5.setProperty(hmUI.prop.VISIBLE, false);
			Button_6.setProperty(hmUI.prop.VISIBLE, false);
			Button_7.setProperty(hmUI.prop.VISIBLE, false);
			Button_8.setProperty(hmUI.prop.VISIBLE, false);
			Button_9.setProperty(hmUI.prop.VISIBLE, false);
			Button_13.setProperty(hmUI.prop.VISIBLE, true);
        }

        function UpdatehybTwo(){
			normal_digital_clock_img_time.setProperty(hmUI.prop.VISIBLE, true);
			normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_temperature_low_text_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_temperature_high_text_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);
			normal_date_img_date_month_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_stand_icon_img.setProperty(hmUI.prop.VISIBLE, true);
			Button_1.setProperty(hmUI.prop.VISIBLE, true);
			Button_2.setProperty(hmUI.prop.VISIBLE, true);
			Button_3.setProperty(hmUI.prop.VISIBLE, true);
			Button_4.setProperty(hmUI.prop.VISIBLE, true);
			Button_5.setProperty(hmUI.prop.VISIBLE, true);
			Button_6.setProperty(hmUI.prop.VISIBLE, true);
			Button_7.setProperty(hmUI.prop.VISIBLE, true);
			Button_8.setProperty(hmUI.prop.VISIBLE, true);
			Button_9.setProperty(hmUI.prop.VISIBLE, true);
			Button_13.setProperty(hmUI.prop.VISIBLE, false);
        }
		
		let elementnumber_1 = 1
        let total_elemente = 3

        function click_HANDS() {
            if(elementnumber_1==total_elemente) {
            elementnumber_1=1;
                UpdateElementeOne();
                }
            else {
                elementnumber_1=elementnumber_1+1;
                if(elementnumber_1==2) {
                  UpdateElementeTwo();
                }
				if(elementnumber_1==3) {
                  UpdateElementeThree();
                }
            }
            if(elementnumber_1==1) hmUI.showToast({text: 'NORMAL SEC'});
            if(elementnumber_1==2) hmUI.showToast({text: 'SMOOTH SEC'});
			if(elementnumber_1==3) hmUI.showToast({text: 'NO SEC HAND'});
        }

        function UpdateElementeOne(){
                normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, true);
				normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.VISIBLE, false);
        }

        function UpdateElementeTwo(){
				normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, false);
				normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.VISIBLE, true);
        }
		
		function UpdateElementeThree(){
				normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, false);
				normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.VISIBLE, false);
        }
		
        // end user_functions.js

        let normal_background_bg = ''
        let normal_date_img_date_week_img = ''
        let normal_image_img = ''
        let normal_date_img_date_day = ''
        let normal_battery_pointer_progress_img_pointer = ''
        let normal_system_disconnect_img = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_analog_clock_pro_hour_pointer_img = ''
        let normal_analog_clock_pro_minute_pointer_img = ''
        let normal_timerUpdateSec = undefined;
        let normal_analog_clock_pro_second_pointer_img = ''
        let normal_timerUpdateSecSmooth = undefined;
        let normal_spo2_icon_img = ''
        let normal_stand_icon_img = ''
        let normal_date_img_date_month_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_high_text_img = ''
        let normal_temperature_low_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_digital_clock_img_time = ''
        let normal_stress_icon_img = ''
        let idle_background_bg = ''
        let idle_date_img_date_week_img = ''
        let idle_image_img = ''
        let idle_date_img_date_day = ''
        let idle_battery_pointer_progress_img_pointer = ''
        let idle_battery_icon_img = ''
        let idle_system_disconnect_img = ''
        let idle_analog_clock_pro_hour_pointer_img = ''
        let idle_analog_clock_pro_minute_pointer_img = ''
        let idle_spo2_icon_img = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let Button_7 = ''
        let Button_8 = ''
        let Button_9 = ''
        let Button_10 = ''
        let Button_11 = ''
        let Button_12 = ''
        let Button_13 = ''
        let timeSensor = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFFFF8000',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 327,
              y: 221,
              week_en: ["wd1.png","wd2.png","wd3.png","wd4.png","wd5.png","wd6.png","wd7.png"],
              week_tc: ["wd1.png","wd2.png","wd3.png","wd4.png","wd5.png","wd6.png","wd7.png"],
              week_sc: ["wd1.png","wd2.png","wd3.png","wd4.png","wd5.png","wd6.png","wd7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'bg1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 400,
              day_startY: 226,
              day_sc_array: ["day_00.png","day_01.png","day_02.png","day_03.png","day_04.png","day_05.png","day_06.png","day_07.png","day_08.png","day_09.png"],
              day_tc_array: ["day_00.png","day_01.png","day_02.png","day_03.png","day_04.png","day_05.png","day_06.png","day_07.png","day_08.png","day_09.png"],
              day_en_array: ["day_00.png","day_01.png","day_02.png","day_03.png","day_04.png","day_05.png","day_06.png","day_07.png","day_08.png","day_09.png"],
              day_zero: 1,
              day_space: -2,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'batt1.png',
              center_x: 240,
              center_y: 240,
              x: 240,
              y: 240,
              start_angle: 30,
              end_angle: -30,
              invalid_visible: false,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 228,
              y: 138,
              src: 'st_bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hand_hour.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 240,
              hour_posY: 239,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'hand_min.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 240,
              minute_posY: 239,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'hands_sec1.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 240,
              second_posY: 239,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const deviceInfo = hmSetting.getDeviceInfo();
            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.MINUTEEND, function() {
              let updateHour = timeSensor.minute == 0;

              time_update(updateHour, true);
            });

            // normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'hands_hour1.png',
              // center_x: 240,
              // center_y: 240,
              // x: 240,
              // y: 239,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.hour,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 240,
              pos_y: 240 - 239,
              center_x: 240,
              center_y: 240,
              src: 'hands_hour1.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            // normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'hands_min1.png',
              // center_x: 240,
              // center_y: 240,
              // x: 240,
              // y: 239,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.minute,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 240,
              pos_y: 240 - 239,
              center_x: 240,
              center_y: 240,
              src: 'hands_min1.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'hands_sec1.png',
              // center_x: 240,
              // center_y: 240,
              // x: 240,
              // y: 239,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 240,
              pos_y: 240 - 239,
              center_x: 240,
              center_y: 240,
              src: 'hands_sec1.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_smooth_second = hmUI.createWidget(hmUI.widget.SMOOTH_SECOND, {
              // type: 2,
              // fps: 15,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_spo2_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'hands_top.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'hybrid1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 330,
              month_startY: 310,
              month_sc_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_tc_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_en_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 94,
              y: 310,
              image_array: ["weatherl_00.png","weatherl_01.png","weatherl_02.png","weatherl_03.png","weatherl_04.png","weatherl_05.png","weatherl_06.png","weatherl_07.png","weatherl_08.png","weatherl_09.png","weatherl_10.png","weatherl_11.png","weatherl_12.png","weatherl_13.png","weatherl_14.png","weatherl_15.png","weatherl_16.png","weatherl_17.png","weatherl_18.png","weatherl_19.png","weatherl_20.png","weatherl_21.png","weatherl_22.png","weatherl_23.png","weatherl_24.png","weatherl_25.png","weatherl_26.png","weatherl_27.png","weatherl_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 128,
              y: 267,
              font_array: ["day_00.png","day_01.png","day_02.png","day_03.png","day_04.png","day_05.png","day_06.png","day_07.png","day_08.png","day_09.png"],
              padding: false,
              h_space: -1,
              negative_image: 'day_10.png',
              invalid_image: 'day_11.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 64,
              y: 267,
              font_array: ["day_00.png","day_01.png","day_02.png","day_03.png","day_04.png","day_05.png","day_06.png","day_07.png","day_08.png","day_09.png"],
              padding: false,
              h_space: -1,
              negative_image: 'day_10.png',
              invalid_image: 'day_11.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 68,
              y: 215,
              font_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              padding: false,
              h_space: -1,
              unit_sc: 'num_13.png',
              unit_tc: 'num_13.png',
              unit_en: 'num_13.png',
              imperial_unit_sc: 'num_14.png',
              imperial_unit_tc: 'num_14.png',
              imperial_unit_en: 'num_14.png',
              negative_image: 'num_11.png',
              invalid_image: 'num_12.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const temperatureUnit = hmSetting.getTemperatureUnit();
            //start of ignored block
            if (temperatureUnit == 1) {
              normal_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
                x: 68,
                y: 215,
                font_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
                padding: false,
                h_space: -1,
                unit_sc: 'num_14.png',
                unit_tc: 'num_14.png',
                unit_en: 'num_14.png',
                imperial_unit_sc: 'num_13.png',
                imperial_unit_tc: 'num_13.png',
                imperial_unit_en: 'num_13.png',
                negative_image: 'num_11.png',
                invalid_image: 'num_12.png',
                align_h: hmUI.align.CENTER_H,
                type: hmUI.data_type.WEATHER_CURRENT,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
            };
            //end of ignored block

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 75,
              y: 144,
              font_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'num_15.png',
              unit_tc: 'num_15.png',
              unit_en: 'num_15.png',
              imperial_unit_sc: 'num_16.png',
              imperial_unit_tc: 'num_16.png',
              imperial_unit_en: 'num_16.png',
              dot_image: 'num_10.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 243,
              y: 176,
              font_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              padding: false,
              h_space: -2,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 264,
              y: 130,
              font_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              padding: false,
              h_space: -2,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 188,
              y: 78,
              font_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 240,
              hour_startY: 240,
              hour_array: ["time_00.png","time_01.png","time_02.png","time_03.png","time_04.png","time_05.png","time_06.png","time_07.png","time_08.png","time_09.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 308,
              minute_startY: 240,
              minute_array: ["time_00.png","time_01.png","time_02.png","time_03.png","time_04.png","time_05.png","time_06.png","time_07.png","time_08.png","time_09.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'menu.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFFC0C0C0',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 327,
              y: 221,
              week_en: ["wd1.png","wd2.png","wd3.png","wd4.png","wd5.png","wd6.png","wd7.png"],
              week_tc: ["wd1.png","wd2.png","wd3.png","wd4.png","wd5.png","wd6.png","wd7.png"],
              week_sc: ["wd1.png","wd2.png","wd3.png","wd4.png","wd5.png","wd6.png","wd7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'bg1.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 400,
              day_startY: 226,
              day_sc_array: ["day_00.png","day_01.png","day_02.png","day_03.png","day_04.png","day_05.png","day_06.png","day_07.png","day_08.png","day_09.png"],
              day_tc_array: ["day_00.png","day_01.png","day_02.png","day_03.png","day_04.png","day_05.png","day_06.png","day_07.png","day_08.png","day_09.png"],
              day_en_array: ["day_00.png","day_01.png","day_02.png","day_03.png","day_04.png","day_05.png","day_06.png","day_07.png","day_08.png","day_09.png"],
              day_zero: 1,
              day_space: -2,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'batt16.png',
              center_x: 240,
              center_y: 240,
              x: 240,
              y: 240,
              start_angle: 30,
              end_angle: -30,
              invalid_visible: false,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'aod.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 228,
              y: 138,
              src: 'st_bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'hands_hour1.png',
              // center_x: 240,
              // center_y: 240,
              // x: 240,
              // y: 239,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.hour,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });


            idle_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 240,
              pos_y: 240 - 239,
              center_x: 240,
              center_y: 240,
              src: 'hands_hour1.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'hands_min1.png',
              // center_x: 240,
              // center_y: 240,
              // x: 240,
              // y: 239,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.minute,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });


            idle_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 240,
              pos_y: 240 - 239,
              center_x: 240,
              center_y: 240,
              src: 'hands_min1.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_spo2_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'hands_top.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 85,
              y: 300,
              w: 60,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'BaroAltimeterScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 80,
              y: 215,
              w: 80,
              h: 80,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'WeatherScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 115,
              y: 60,
              w: 70,
              h: 70,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'SportListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 100,
              y: 140,
              w: 100,
              h: 45,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'SportStatusScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 190,
              y: 70,
              w: 100,
              h: 45,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'activityAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 260,
              y: 175,
              w: 100,
              h: 45,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PAI_app_Screen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_7 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 260,
              y: 125,
              w: 100,
              h: 45,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'heart_app_Screen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_8 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 330,
              y: 300,
              w: 70,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_9 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 300,
              y: 230,
              w: 70,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'StopWatchScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_10 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 250,
              y: 70,
              w: 100,
              h: 100,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                				click_COLOR();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_11 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 130,
              y: 70,
              w: 100,
              h: 100,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                				click_BG();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_12 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 190,
              y: 330,
              w: 100,
              h: 100,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                				click_HYBRID();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_13 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 190,
              y: 190,
              w: 100,
              h: 100,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                				click_MENU();
              }, // end func
              longpress_func: (button_widget) => {
                				click_HANDS();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            console.log('user_script_end.js');
            // start user_script_end.js
			let cc = 0
			if (cc ==0 ){
			normal_stress_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_digital_clock_img_time.setProperty(hmUI.prop.VISIBLE, false);
			normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_temperature_low_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_temperature_high_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
			normal_date_img_date_month_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_stand_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.VISIBLE, false);
			Button_1.setProperty(hmUI.prop.VISIBLE, false);
			Button_2.setProperty(hmUI.prop.VISIBLE, false);
			Button_3.setProperty(hmUI.prop.VISIBLE, false);
			Button_4.setProperty(hmUI.prop.VISIBLE, false);
			Button_5.setProperty(hmUI.prop.VISIBLE, false);
			Button_6.setProperty(hmUI.prop.VISIBLE, false);
			Button_7.setProperty(hmUI.prop.VISIBLE, false);
			Button_8.setProperty(hmUI.prop.VISIBLE, false);
			Button_9.setProperty(hmUI.prop.VISIBLE, false);
			Button_10.setProperty(hmUI.prop.VISIBLE, false);
			Button_11.setProperty(hmUI.prop.VISIBLE, false);
			cc = 1;
			}
            // end user_script_end.js

            //start of ignored block
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              if (updateHour) {
                let normal_hour = hour;
                let normal_fullAngle_hour = 360;
                if (normal_hour > 11) normal_hour -= 12;
                let normal_angle_hour = 0 + normal_fullAngle_hour*normal_hour/12 + (normal_fullAngle_hour/12)*minute/60;
                if (normal_analog_clock_pro_hour_pointer_img) normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_hour);
              };

              if (updateMinute) {
                let normal_fullAngle_minute = 360;
                let normal_angle_minute = 0 + normal_fullAngle_minute*(minute + second/60)/60;
                if (normal_analog_clock_pro_minute_pointer_img) normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_minute);
              };

              let normal_fullAngle_second = 360;
              let normal_angle_second = 0 + normal_fullAngle_second*(second + (timeSensor.utc % 1000)/1000)/60;
              if (normal_analog_clock_pro_second_pointer_img) normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_second);

              if (updateHour) {
                let idle_hour = hour;
                let idle_fullAngle_hour = 360;
                if (idle_hour > 11) idle_hour -= 12;
                let idle_angle_hour = 0 + idle_fullAngle_hour*idle_hour/12 + (idle_fullAngle_hour/12)*minute/60;
                if (idle_analog_clock_pro_hour_pointer_img) idle_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.ANGLE, idle_angle_hour);
              };

              if (updateMinute) {
                let idle_fullAngle_minute = 360;
                let idle_angle_minute = 0 + idle_fullAngle_minute*minute/60;
                if (idle_analog_clock_pro_minute_pointer_img) idle_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.ANGLE, idle_angle_minute);
              };

            };

            //end of ignored block
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                time_update(true, true);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSec) {
                    let animDelay = timeSensor.utc % 1000;
                    let animRepeat = 1000;
                    normal_timerUpdateSec = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, true);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSecSmooth) {
                    let animDelay = 0;
                    let animRepeat = 1000/15;
                    normal_timerUpdateSecSmooth = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, false);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


                console.log('resume_call.js');
                // start resume_call.js
			idle_image_img.setProperty(hmUI.prop.SRC, "bg" + hmFS.SysProGetInt('userBG') + ".png");
			idle_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.SRC, "hands_hour" + hmFS.SysProGetInt('userScore') + ".png");
			idle_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.SRC, "hands_min" + hmFS.SysProGetInt('userScore') + ".png");
                // end resume_call.js

              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerUpdateSec) {
                  timer.stopTimer(normal_timerUpdateSec);
                  normal_timerUpdateSec = undefined;
                }
                if (normal_timerUpdateSecSmooth) {
                  timer.stopTimer(normal_timerUpdateSecSmooth);
                  normal_timerUpdateSecSmooth = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
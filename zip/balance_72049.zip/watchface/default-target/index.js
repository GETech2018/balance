try {
    (() => {
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface6');
        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 480,
                    h: 480,
                    src: '4.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    hour_zero: 1,
                    hour_startX: 110,
                    hour_startY: 215,
                    hour_array: [
                        '5.png',
                        '6.png',
                        '7.png',
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png',
                        '12.png',
                        '13.png',
                        '14.png'
                    ],
                    hour_space: 8,
                    hour_align: hmUI.align.LEFT,
                    minute_zero: 1,
                    minute_startX: 262,
                    minute_startY: 215,
                    minute_array: [
                        '5.png',
                        '6.png',
                        '7.png',
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png',
                        '12.png',
                        '13.png',
                        '14.png'
                    ],
                    minute_space: 8,
                    minute_align: hmUI.align.LEFT,
                    minute_follow: 0,
                    second_zero: 1,
                    second_startX: 94,
                    second_startY: 87,
                    second_array: [
                        '15.png',
                        '16.png',
                        '17.png',
                        '18.png',
                        '19.png',
                        '20.png',
                        '21.png',
                        '22.png',
                        '23.png',
                        '24.png'
                    ],
                    second_space: 2,
                    second_align: hmUI.align.LEFT,
                    second_follow: 0,
                    am_x: 37,
                    am_y: 216,
                    am_en_path: '25.png',
                    pm_x: 37,
                    pm_y: 216,
                    pm_en_path: '26.png',
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_DATE, {
                    month_startX: 397,
                    month_startY: 217,
                    month_sc_array: [
                        '27.png',
                        '28.png',
                        '29.png',
                        '30.png',
                        '31.png',
                        '32.png',
                        '33.png',
                        '34.png',
                        '35.png',
                        '36.png'
                    ],
                    month_tc_array: [
                        '27.png',
                        '28.png',
                        '29.png',
                        '30.png',
                        '31.png',
                        '32.png',
                        '33.png',
                        '34.png',
                        '35.png',
                        '36.png'
                    ],
                    month_en_array: [
                        '27.png',
                        '28.png',
                        '29.png',
                        '30.png',
                        '31.png',
                        '32.png',
                        '33.png',
                        '34.png',
                        '35.png',
                        '36.png'
                    ],
                    month_align: hmUI.align.LEFT,
                    month_zero: 1,
                    month_follow: 0,
                    month_space: 0,
                    month_is_character: false,
                    day_startX: 397,
                    day_startY: 262,
                    day_sc_array: [
                        '37.png',
                        '38.png',
                        '39.png',
                        '40.png',
                        '41.png',
                        '42.png',
                        '43.png',
                        '44.png',
                        '45.png',
                        '46.png'
                    ],
                    day_tc_array: [
                        '37.png',
                        '38.png',
                        '39.png',
                        '40.png',
                        '41.png',
                        '42.png',
                        '43.png',
                        '44.png',
                        '45.png',
                        '46.png'
                    ],
                    day_en_array: [
                        '37.png',
                        '38.png',
                        '39.png',
                        '40.png',
                        '41.png',
                        '42.png',
                        '43.png',
                        '44.png',
                        '45.png',
                        '46.png'
                    ],
                    day_align: hmUI.align.LEFT,
                    day_zero: 1,
                    day_follow: 0,
                    day_space: 0,
                    day_is_character: false,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_WEEK, {
                    x: 23,
                    y: 181,
                    week_en: [
                        '54.png',
                        '55.png',
                        '56.png',
                        '57.png',
                        '58.png',
                        '59.png',
                        '60.png'
                    ],
                    week_tc: [
                        '61.png',
                        '62.png',
                        '63.png',
                        '64.png',
                        '65.png',
                        '66.png',
                        '67.png'
                    ],
                    week_sc: [
                        '68.png',
                        '69.png',
                        '70.png',
                        '71.png',
                        '72.png',
                        '73.png',
                        '74.png'
                    ],
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                    x: 305,
                    y: 403,
                    image_array: [
                        '75.png',
                        '76.png',
                        '77.png',
                        '78.png',
                        '79.png',
                        '80.png',
                        '81.png',
                        '82.png',
                        '83.png',
                        '84.png',
                        '85.png',
                        '86.png',
                        '87.png',
                        '88.png',
                        '89.png',
                        '90.png',
                        '91.png',
                        '92.png',
                        '93.png',
                        '94.png',
                        '95.png',
                        '96.png',
                        '97.png',
                        '98.png',
                        '99.png',
                        '100.png',
                        '101.png',
                        '102.png',
                        '103.png'
                    ],
                    image_length: 29,
                    type: hmUI.data_type.WEATHER_CURRENT,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                    x: 243,
                    y: 56,
                    image_array: [
                        '104.png',
                        '105.png',
                        '106.png',
                        '107.png',
                        '108.png',
                        '109.png'
                    ],
                    image_length: 6,
                    type: hmUI.data_type.HEART,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 258,
                    y: 113,
                    type: hmUI.data_type.HEART,
                    font_array: [
                        '110.png',
                        '111.png',
                        '112.png',
                        '113.png',
                        '114.png',
                        '115.png',
                        '116.png',
                        '117.png',
                        '118.png',
                        '119.png'
                    ],
                    align_h: hmUI.align.RIGHT,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    invalid_image: '120.png',
                    padding: true,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 218,
                    y: 349,
                    type: hmUI.data_type.CAL,
                    font_array: [
                        '122.png',
                        '123.png',
                        '124.png',
                        '125.png',
                        '126.png',
                        '127.png',
                        '128.png',
                        '129.png',
                        '130.png',
                        '131.png'
                    ],
                    align_h: hmUI.align.LEFT,
                    h_space: 1,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    invalid_image: '132.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 84,
                    y: 348,
                    type: hmUI.data_type.STEP,
                    font_array: [
                        '134.png',
                        '135.png',
                        '136.png',
                        '137.png',
                        '138.png',
                        '139.png',
                        '140.png',
                        '141.png',
                        '142.png',
                        '143.png'
                    ],
                    align_h: hmUI.align.LEFT,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    invalid_image: '144.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 341,
                    y: 349,
                    type: hmUI.data_type.DISTANCE,
                    font_array: [
                        '146.png',
                        '147.png',
                        '148.png',
                        '149.png',
                        '150.png',
                        '151.png',
                        '152.png',
                        '153.png',
                        '154.png',
                        '155.png'
                    ],
                    align_h: hmUI.align.LEFT,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    dot_image: '157.png',
                    invalid_image: '156.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 124,
                    y: 420,
                    type: hmUI.data_type.BATTERY,
                    font_array: [
                        '159.png',
                        '160.png',
                        '161.png',
                        '162.png',
                        '163.png',
                        '164.png',
                        '165.png',
                        '166.png',
                        '167.png',
                        '168.png'
                    ],
                    align_h: hmUI.align.LEFT,
                    h_space: 1,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    unit_sc: '170.png',
                    unit_tc: '170.png',
                    unit_en: '170.png',
                    invalid_image: '169.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 221,
                    y: 420,
                    type: hmUI.data_type.WEATHER_CURRENT,
                    font_array: [
                        '172.png',
                        '173.png',
                        '174.png',
                        '175.png',
                        '176.png',
                        '177.png',
                        '178.png',
                        '179.png',
                        '180.png',
                        '181.png'
                    ],
                    align_h: hmUI.align.LEFT,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    unit_sc: '184.png',
                    unit_tc: '184.png',
                    unit_en: '184.png',
                    negative_image: '183.png',
                    invalid_image: '182.png',
                    padding: false,
                    isCharacter: false
                });
                hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                    hour_centerX: 136,
                    hour_centerY: 114,
                    hour_posX: 3,
                    hour_posY: 57,
                    hour_path: '187.png',
                    hour_cover_path: '186.png',
                    hour_cover_x: 127,
                    hour_cover_y: 105,
                    minute_centerX: 136,
                    minute_centerY: 114,
                    minute_posX: 3,
                    minute_posY: 57,
                    minute_path: '188.png',
                    minute_cover_x: 0,
                    minute_cover_y: 0,
                    second_centerX: 136,
                    second_centerY: 114,
                    second_posX: 3,
                    second_posY: 57,
                    second_path: '189.png',
                    second_cover_x: 0,
                    second_cover_y: 0,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 480,
                    h: 480,
                    src: '190.png',
                    show_level: hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    hour_zero: 1,
                    hour_startX: 110,
                    hour_startY: 215,
                    hour_array: [
                        '5.png',
                        '6.png',
                        '7.png',
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png',
                        '12.png',
                        '13.png',
                        '14.png'
                    ],
                    hour_space: 8,
                    hour_align: hmUI.align.LEFT,
                    minute_zero: 1,
                    minute_startX: 262,
                    minute_startY: 215,
                    minute_array: [
                        '5.png',
                        '6.png',
                        '7.png',
                        '8.png',
                        '9.png',
                        '10.png',
                        '11.png',
                        '12.png',
                        '13.png',
                        '14.png'
                    ],
                    minute_space: 8,
                    minute_align: hmUI.align.LEFT,
                    minute_follow: 0,
                    am_x: 37,
                    am_y: 216,
                    am_en_path: '191.png',
                    pm_x: 37,
                    pm_y: 216,
                    pm_en_path: '192.png',
                    enable: false,
                    show_level: hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 239,
                    y: 246,
                    w: 12,
                    h: 41,
                    src: '193.png',
                    show_level: hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 235,
                    y: 50,
                    w: 150,
                    h: 110,
                    src: '121.png',
                    type: hmUI.data_type.HEART,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 203,
                    y: 310,
                    w: 100,
                    h: 65,
                    src: '133.png',
                    type: hmUI.data_type.CAL,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 77,
                    y: 312,
                    w: 111,
                    h: 71,
                    src: '145.png',
                    type: hmUI.data_type.STEP,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 320,
                    y: 314,
                    w: 90,
                    h: 64,
                    src: '158.png',
                    type: hmUI.data_type.DISTANCE,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 109,
                    y: 387,
                    w: 90,
                    h: 63,
                    src: '171.png',
                    type: hmUI.data_type.BATTERY,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 204,
                    y: 378,
                    w: 159,
                    h: 80,
                    src: '185.png',
                    type: hmUI.data_type.WEATHER_CURRENT,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
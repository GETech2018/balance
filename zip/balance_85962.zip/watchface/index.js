﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_text_separator_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_high_text_img = ''
        let normal_temperature_low_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_date_img_date_week_img = ''
        let normal_distance_text_text_img = ''
        let normal_distance_text_separator_img = ''
        let normal_calorie_current_text_img = ''
        let normal_calorie_current_separator_img = ''
        let normal_date_img_date_day = ''
        let normal_hour_TextRotate = new Array(2);
        let normal_hour_TextRotate_ASCIIARRAY = new Array(10);
        let normal_hour_TextRotate_img_width = 71;
        let normal_hour_TextRotate_unit = null;
        let normal_hour_TextRotate_unit_width = 36;
        let normal_timerTextUpdate = undefined;
        let normal_minute_TextRotate = new Array(2);
        let normal_minute_TextRotate_ASCIIARRAY = new Array(10);
        let normal_minute_TextRotate_img_width = 71;
        let normal_second_TextRotate = new Array(2);
        let normal_second_TextRotate_ASCIIARRAY = new Array(10);
        let normal_second_TextRotate_img_width = 37;
        let idle_background_bg = ''
        let idle_image_img = ''
        let idle_battery_text_text_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_day = ''
        let idle_hour_TextRotate = new Array(2);
        let idle_hour_TextRotate_ASCIIARRAY = new Array(10);
        let idle_hour_TextRotate_img_width = 71;
        let idle_hour_TextRotate_unit = null;
        let idle_hour_TextRotate_unit_width = 36;
        let idle_timerTextUpdate = undefined;
        let idle_minute_TextRotate = new Array(2);
        let idle_minute_TextRotate_ASCIIARRAY = new Array(10);
        let idle_minute_TextRotate_img_width = 71;
        let normal_cal_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let Button_7 = ''
        let Button_8 = ''
        let Button_9 = ''
        let Button_10 = ''
        let Button_11 = ''
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 274,
              y: 397,
              font_array: ["num_37_b_00.png","num_37_b_01.png","num_37_b_02.png","num_37_b_03.png","num_37_b_04.png","num_37_b_05.png","num_37_b_06.png","num_37_b_07.png","num_37_b_08.png","num_37_b_09.png"],
              padding: false,
              h_space: -5,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 235,
              y: 399,
              src: 'step.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 158,
              y: 397,
              font_array: ["num_37_b_00.png","num_37_b_01.png","num_37_b_02.png","num_37_b_03.png","num_37_b_04.png","num_37_b_05.png","num_37_b_06.png","num_37_b_07.png","num_37_b_08.png","num_37_b_09.png"],
              padding: false,
              h_space: -5,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 118,
              y: 399,
              src: 'heart.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 96,
              y: 325,
              src: 'bt_off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 22,
              y: 224,
              src: 'alarm_on.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 261,
              y: 320,
              font_array: ["num_43_w_01.png","num_43_w_02.png","num_43_w_03.png","num_43_w_04.png","num_43_w_05.png","num_43_w_06.png","num_43_w_07.png","num_43_w_08.png","num_43_w_09.png","num_43_w_10.png"],
              padding: false,
              h_space: -5,
              angle: -5,
              unit_sc: 'num_43_w_00.png',
              unit_tc: 'num_43_w_00.png',
              unit_en: 'num_43_w_00.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 384,
              y: 325,
              image_array: ["bat_01.png","bat_02.png","bat_03.png","bat_04.png","bat_05.png","bat_06.png","bat_07.png","bat_08.png","bat_09.png","bat_10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 60,
              y: 112,
              image_array: ["weather_0.png","weather_1.png","weather_2.png","weather_3.png","weather_4.png","weather_5.png","weather_6.png","weather_7.png","weather_8.png","weather_9.png","weather_10.png","weather_11.png","weather_12.png","weather_13.png","weather_14.png","weather_15.png","weather_16.png","weather_17.png","weather_18.png","weather_19.png","weather_20.png","weather_21.png","weather_22.png","weather_23.png","weather_24.png","weather_25.png","weather_26.png","weather_27.png","weather_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 255,
              y: 98,
              font_array: ["num_37_01.png","num_37_02.png","num_37_03.png","num_37_04.png","num_37_05.png","num_37_06.png","num_37_07.png","num_37_08.png","num_37_09.png","num_37_10.png"],
              padding: false,
              h_space: -5,
              unit_sc: 'num_37_00.png',
              unit_tc: 'num_37_00.png',
              unit_en: 'num_37_00.png',
              negative_image: 'num_37_11.png',
              invalid_image: 'num_37_12.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 255,
              y: 129,
              font_array: ["num_37_01.png","num_37_02.png","num_37_03.png","num_37_04.png","num_37_05.png","num_37_06.png","num_37_07.png","num_37_08.png","num_37_09.png","num_37_10.png"],
              padding: false,
              h_space: -5,
              unit_sc: 'num_37_00.png',
              unit_tc: 'num_37_00.png',
              unit_en: 'num_37_00.png',
              negative_image: 'num_37_11.png',
              invalid_image: 'num_37_12.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 109,
              y: 107,
              font_array: ["num_59_00.png","num_59_01.png","num_59_02.png","num_59_03.png","num_59_04.png","num_59_05.png","num_59_06.png","num_59_07.png","num_59_08.png","num_59_09.png"],
              padding: false,
              h_space: -5,
              unit_sc: 'num_59_11.png',
              unit_tc: 'num_59_11.png',
              unit_en: 'num_59_11.png',
              negative_image: 'num_59_10.png',
              invalid_image: 'num_59_12.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 106,
              y: 148,
              week_en: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              week_tc: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              week_sc: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 273,
              y: 49,
              font_array: ["num_37_b_00.png","num_37_b_01.png","num_37_b_02.png","num_37_b_03.png","num_37_b_04.png","num_37_b_05.png","num_37_b_06.png","num_37_b_07.png","num_37_b_08.png","num_37_b_09.png"],
              padding: false,
              h_space: -6,
              dot_image: 'num_37_b_10.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 245,
              y: 51,
              src: 'dist.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 152,
              y: 49,
              font_array: ["num_37_b_00.png","num_37_b_01.png","num_37_b_02.png","num_37_b_03.png","num_37_b_04.png","num_37_b_05.png","num_37_b_06.png","num_37_b_07.png","num_37_b_08.png","num_37_b_09.png"],
              padding: false,
              h_space: -6,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 108,
              y: 48,
              src: 'cal.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 372,
              day_startY: 159,
              day_sc_array: ["data_00.png","data_01.png","data_02.png","data_03.png","data_04.png","data_05.png","data_06.png","data_07.png","data_08.png","data_09.png"],
              day_tc_array: ["data_00.png","data_01.png","data_02.png","data_03.png","data_04.png","data_05.png","data_06.png","data_07.png","data_08.png","data_09.png"],
              day_en_array: ["data_00.png","data_01.png","data_02.png","data_03.png","data_04.png","data_05.png","data_06.png","data_07.png","data_08.png","data_09.png"],
              day_zero: 1,
              day_space: -4,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_hour_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 131,
              // y: 225,
              // font_array: ["time_00.png","time_01.png","time_02.png","time_03.png","time_04.png","time_05.png","time_06.png","time_07.png","time_08.png","time_09.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: -11,
              // angle: -6,
              // unit_en: 'time_10.png',
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.HOUR,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_hour_TextRotate_ASCIIARRAY[0] = 'time_00.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[1] = 'time_01.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[2] = 'time_02.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[3] = 'time_03.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[4] = 'time_04.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[5] = 'time_05.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[6] = 'time_06.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[7] = 'time_07.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[8] = 'time_08.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[9] = 'time_09.png';  // set of images with numbers

            //#region TextRotate
            for (let i = 0; i < 2; i++) {
              normal_hour_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 131,
                center_y: 225,
                pos_x: 131,
                pos_y: 225,
                angle: -6,
                src: 'time_00.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_hour_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_hour_TextRotate_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              center_x: 131,
              center_y: 225,
              pos_x: 131,
              pos_y: 225,
              angle: -6,
              src: 'time_10.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_hour_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
            //#endregion

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            let screenType = hmSetting.getScreenType();
            // normal_minute_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 212,
              // y: 215,
              // font_array: ["time_00.png","time_01.png","time_02.png","time_03.png","time_04.png","time_05.png","time_06.png","time_07.png","time_08.png","time_09.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: -11,
              // angle: -6,
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.MINUTE,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_minute_TextRotate_ASCIIARRAY[0] = 'time_00.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[1] = 'time_01.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[2] = 'time_02.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[3] = 'time_03.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[4] = 'time_04.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[5] = 'time_05.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[6] = 'time_06.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[7] = 'time_07.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[8] = 'time_08.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[9] = 'time_09.png';  // set of images with numbers

            //#region TextRotate
            for (let i = 0; i < 2; i++) {
              normal_minute_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 212,
                center_y: 215,
                pos_x: 212,
                pos_y: 215,
                angle: -6,
                src: 'time_00.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_minute_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //#endregion

            // normal_second_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 345,
              // y: 254,
              // font_array: ["num_62_00.png","num_62_01.png","num_62_02.png","num_62_03.png","num_62_04.png","num_62_05.png","num_62_06.png","num_62_07.png","num_62_08.png","num_62_09.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: -7,
              // angle: -6,
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.SECOND,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_second_TextRotate_ASCIIARRAY[0] = 'num_62_00.png';  // set of images with numbers
            normal_second_TextRotate_ASCIIARRAY[1] = 'num_62_01.png';  // set of images with numbers
            normal_second_TextRotate_ASCIIARRAY[2] = 'num_62_02.png';  // set of images with numbers
            normal_second_TextRotate_ASCIIARRAY[3] = 'num_62_03.png';  // set of images with numbers
            normal_second_TextRotate_ASCIIARRAY[4] = 'num_62_04.png';  // set of images with numbers
            normal_second_TextRotate_ASCIIARRAY[5] = 'num_62_05.png';  // set of images with numbers
            normal_second_TextRotate_ASCIIARRAY[6] = 'num_62_06.png';  // set of images with numbers
            normal_second_TextRotate_ASCIIARRAY[7] = 'num_62_07.png';  // set of images with numbers
            normal_second_TextRotate_ASCIIARRAY[8] = 'num_62_08.png';  // set of images with numbers
            normal_second_TextRotate_ASCIIARRAY[9] = 'num_62_09.png';  // set of images with numbers

            //#region TextRotate
            for (let i = 0; i < 2; i++) {
              normal_second_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 345,
                center_y: 254,
                pos_x: 345,
                pos_y: 254,
                angle: -6,
                src: 'num_62_00.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_second_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //#endregion


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 7,
              src: 'bg_aod.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 261,
              y: 320,
              font_array: ["num_43_w_01.png","num_43_w_02.png","num_43_w_03.png","num_43_w_04.png","num_43_w_05.png","num_43_w_06.png","num_43_w_07.png","num_43_w_08.png","num_43_w_09.png","num_43_w_10.png"],
              padding: false,
              h_space: -5,
              angle: -5,
              unit_sc: 'num_43_w_00.png',
              unit_tc: 'num_43_w_00.png',
              unit_en: 'num_43_w_00.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 106,
              y: 148,
              week_en: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              week_tc: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              week_sc: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 372,
              day_startY: 159,
              day_sc_array: ["data_00.png","data_01.png","data_02.png","data_03.png","data_04.png","data_05.png","data_06.png","data_07.png","data_08.png","data_09.png"],
              day_tc_array: ["data_00.png","data_01.png","data_02.png","data_03.png","data_04.png","data_05.png","data_06.png","data_07.png","data_08.png","data_09.png"],
              day_en_array: ["data_00.png","data_01.png","data_02.png","data_03.png","data_04.png","data_05.png","data_06.png","data_07.png","data_08.png","data_09.png"],
              day_zero: 1,
              day_space: -4,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_hour_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 131,
              // y: 225,
              // font_array: ["time_aod_00.png","time_aod_01.png","time_aod_02.png","time_aod_03.png","time_aod_04.png","time_aod_05.png","time_aod_06.png","time_aod_07.png","time_aod_08.png","time_aod_09.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: -11,
              // angle: -6,
              // unit_en: 'time_aod_10.png',
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.HOUR,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_hour_TextRotate_ASCIIARRAY[0] = 'time_aod_00.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[1] = 'time_aod_01.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[2] = 'time_aod_02.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[3] = 'time_aod_03.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[4] = 'time_aod_04.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[5] = 'time_aod_05.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[6] = 'time_aod_06.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[7] = 'time_aod_07.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[8] = 'time_aod_08.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[9] = 'time_aod_09.png';  // set of images with numbers

            //#region TextRotate
            for (let i = 0; i < 2; i++) {
              idle_hour_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 131,
                center_y: 225,
                pos_x: 131,
                pos_y: 225,
                angle: -6,
                src: 'time_aod_00.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_hour_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            idle_hour_TextRotate_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              center_x: 131,
              center_y: 225,
              pos_x: 131,
              pos_y: 225,
              angle: -6,
              src: 'time_aod_10.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            idle_hour_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
            //#endregion

            // idle_minute_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 212,
              // y: 215,
              // font_array: ["time_aod_00.png","time_aod_01.png","time_aod_02.png","time_aod_03.png","time_aod_04.png","time_aod_05.png","time_aod_06.png","time_aod_07.png","time_aod_08.png","time_aod_09.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: -11,
              // angle: -6,
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.MINUTE,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_minute_TextRotate_ASCIIARRAY[0] = 'time_aod_00.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[1] = 'time_aod_01.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[2] = 'time_aod_02.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[3] = 'time_aod_03.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[4] = 'time_aod_04.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[5] = 'time_aod_05.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[6] = 'time_aod_06.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[7] = 'time_aod_07.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[8] = 'time_aod_08.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[9] = 'time_aod_09.png';  // set of images with numbers

            //#region TextRotate
            for (let i = 0; i < 2; i++) {
              idle_minute_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 212,
                center_y: 215,
                pos_x: 212,
                pos_y: 215,
                angle: -6,
                src: 'time_aod_00.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_minute_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //#endregion
            console.log('Watch_Face.Shortcuts');

            normal_cal_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 131,
              y: 32,
              w: 100,
              h: 60,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 261,
              y: 32,
              w: 100,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '1_null.png',
              normal_src: '1_null.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'CompassScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 112,
              y: 96,
              w: 100,
              h: 70,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '1_null.png',
              normal_src: '1_null.png',
              click_func: (button_widget) => {
                hmApp.startApp({ appid: 1051195, url: 'page/index', params: { from_wf: true} });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 250,
              y: 96,
              w: 80,
              h: 70,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '1_null.png',
              normal_src: '1_null.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'TideScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 373,
              y: 146,
              w: 80,
              h: 80,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '1_null.png',
              normal_src: '1_null.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 94,
              y: 226,
              w: 80,
              h: 80,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '1_null.png',
              normal_src: '1_null.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'CountdownAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 240,
              y: 211,
              w: 80,
              h: 80,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '1_null.png',
              normal_src: '1_null.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PhoneHomeScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_7 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 344,
              y: 236,
              w: 70,
              h: 70,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '1_null.png',
              normal_src: '1_null.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'StopWatchScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_8 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 280,
              y: 307,
              w: 80,
              h: 70,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '1_null.png',
              normal_src: '1_null.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'Settings_batteryManagerScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_9 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 121,
              y: 379,
              w: 100,
              h: 70,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '1_null.png',
              normal_src: '1_null.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'heart_app_Screen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_10 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 244,
              y: 379,
              w: 120,
              h: 70,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '1_null.png',
              normal_src: '1_null.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'activityAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_11 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 0,
              y: 197,
              w: 75,
              h: 80,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '1_null.png',
              normal_src: '1_null.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'AlarmInfoScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            //#region text_update
            function text_update() {
              console.log('text_update()');

              console.log('update text rotate hour_TIME');
              let valueHour = timeSensor.format_hour;
              let normal_hour_rotate_string = parseInt(valueHour).toString();
              normal_hour_rotate_string = normal_hour_rotate_string.padStart(2, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_hour_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_hour_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
                if (valueHour != null && valueHour != undefined && isFinite(valueHour) && normal_hour_rotate_string.length > 0 && normal_hour_rotate_string.length <= 2) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let normal_hour_TextRotate_posOffset = normal_hour_TextRotate_img_width * normal_hour_rotate_string.length;
                  normal_hour_TextRotate_posOffset = normal_hour_TextRotate_posOffset + -11 * (normal_hour_rotate_string.length - 1);
                  img_offset -= normal_hour_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_hour_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_hour_TextRotate[index].setProperty(hmUI.prop.POS_X, 131 + img_offset);
                      normal_hour_TextRotate[index].setProperty(hmUI.prop.SRC, normal_hour_TextRotate_ASCIIARRAY[charCode]);
                      normal_hour_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_hour_TextRotate_img_width + -11;
                      index++;
                    };  // end if digit
                  };  // end char of string
                  normal_hour_TextRotate_unit.setProperty(hmUI.prop.POS_X, 131 + img_offset);
                  normal_hour_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite

              };

              console.log('update text rotate minute_TIME');
              let valueMinute = timeSensor.minute;
              let normal_minute_rotate_string = parseInt(valueMinute).toString();
              normal_minute_rotate_string = normal_minute_rotate_string.padStart(2, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_minute_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueMinute != null && valueMinute != undefined && isFinite(valueMinute) && normal_minute_rotate_string.length > 0 && normal_minute_rotate_string.length <= 2) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of normal_minute_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_minute_TextRotate[index].setProperty(hmUI.prop.POS_X, 212 + img_offset);
                      normal_minute_TextRotate[index].setProperty(hmUI.prop.SRC, normal_minute_TextRotate_ASCIIARRAY[charCode]);
                      normal_minute_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_minute_TextRotate_img_width + -11;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate second_TIME');
              let valueSecond = timeSensor.second;
              let normal_second_rotate_string = parseInt(valueSecond).toString();
              normal_second_rotate_string = normal_second_rotate_string.padStart(2, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_second_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueSecond != null && valueSecond != undefined && isFinite(valueSecond) && normal_second_rotate_string.length > 0 && normal_second_rotate_string.length <= 2) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of normal_second_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_second_TextRotate[index].setProperty(hmUI.prop.POS_X, 345 + img_offset);
                      normal_second_TextRotate[index].setProperty(hmUI.prop.SRC, normal_second_TextRotate_ASCIIARRAY[charCode]);
                      normal_second_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_second_TextRotate_img_width + -7;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate hour_TIME');
              let idle_hour_rotate_string = parseInt(valueHour).toString();
              idle_hour_rotate_string = idle_hour_rotate_string.padStart(2, '0');

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  idle_hour_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                idle_hour_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
                if (valueHour != null && valueHour != undefined && isFinite(valueHour) && idle_hour_rotate_string.length > 0 && idle_hour_rotate_string.length <= 2) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let idle_hour_TextRotate_posOffset = idle_hour_TextRotate_img_width * idle_hour_rotate_string.length;
                  idle_hour_TextRotate_posOffset = idle_hour_TextRotate_posOffset + -11 * (idle_hour_rotate_string.length - 1);
                  img_offset -= idle_hour_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of idle_hour_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_hour_TextRotate[index].setProperty(hmUI.prop.POS_X, 131 + img_offset);
                      idle_hour_TextRotate[index].setProperty(hmUI.prop.SRC, idle_hour_TextRotate_ASCIIARRAY[charCode]);
                      idle_hour_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_hour_TextRotate_img_width + -11;
                      index++;
                    };  // end if digit
                  };  // end char of string
                  idle_hour_TextRotate_unit.setProperty(hmUI.prop.POS_X, 131 + img_offset);
                  idle_hour_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite

              };

              console.log('update text rotate minute_TIME');
              let idle_minute_rotate_string = parseInt(valueMinute).toString();
              idle_minute_rotate_string = idle_minute_rotate_string.padStart(2, '0');

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  idle_minute_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueMinute != null && valueMinute != undefined && isFinite(valueMinute) && idle_minute_rotate_string.length > 0 && idle_minute_rotate_string.length <= 2) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of idle_minute_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_minute_TextRotate[index].setProperty(hmUI.prop.POS_X, 212 + img_offset);
                      idle_minute_TextRotate[index].setProperty(hmUI.prop.SRC, idle_minute_TextRotate_ASCIIARRAY[charCode]);
                      idle_minute_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_minute_TextRotate_img_width + -11;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

            };

            //#endregion
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                text_update();
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerTextUpdate) {
                    normal_timerTextUpdate = timer.createTimer(0, 1000, (function (option) {
                      text_update();
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.AOD) {
                  if (!idle_timerTextUpdate) {
                    idle_timerTextUpdate = timer.createTimer(0, 1000, (function (option) {
                      text_update();
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerTextUpdate) {
                  timer.stopTimer(normal_timerTextUpdate);
                  normal_timerTextUpdate = undefined;
                }
                if (idle_timerTextUpdate) {
                  timer.stopTimer(idle_timerTextUpdate);
                  idle_timerTextUpdate = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
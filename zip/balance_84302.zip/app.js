App({
  globalData: {},
  onCreate(options) {
  },

  onDestroy(options) {
  }
})
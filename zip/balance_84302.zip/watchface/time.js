import * as hmUI from '@zos/ui';
import { Time } from '@zos/sensor';
import { launchApp, SYSTEM_APP_CALENDAR, SYSTEM_APP_WORLD_CLOCK } from "@zos/router";

let time_group = null;
let seconds_timer = null;
let time = new Time();
let seconds_widget = null;
let secs_to_level_map = [[55, 13], [50, 12], [45, 11], [40, 10], [35, 9], [30, 8], [25, 7], [20, 6], [15, 5], [10, 4], [5, 3], [0, 2]];
let seconds_images = ['seconds/seconds-blank.png', 'seconds/seconds-00.png', 'seconds/seconds-05.png', 'seconds/seconds-10.png', 'seconds/seconds-15.png', 'seconds/seconds-20.png', 'seconds/seconds-25.png', 'seconds/seconds-30.png', 'seconds/seconds-35.png', 'seconds/seconds-40.png', 'seconds/seconds-45.png', 'seconds/seconds-50.png', 'seconds/seconds-55.png'];
let secs_param = {
    x: 177,
    y: 79,
    image_array: seconds_images,
    image_length: 13,
    level: 1,
    show_level: hmUI.show_level.ONLY_NORMAL,
};

export function buildView() {

	time_group = hmUI.createWidget(hmUI.widget.GROUP, {});
	time_group.setProperty(hmUI.prop.VISIBLE, false);

    // background

    time_group.createWidget(hmUI.widget.IMG, {
        x: 0,
        y: 0,
        w: 480,
        h: 480,
        src: 'background-time.png',
        show_level: hmUI.show_level.ONLY_NORMAL,
    });

	// setup seconds widget
	seconds_widget = time_group.createWidget(hmUI.widget.IMG_LEVEL, secs_param);

	//setTimeout(updateSecondsDisplay, 1000);

    // setup time hours/mins
    const timeDigits = ['nums/orange/numbers-95-0.png', 'nums/orange/numbers-95-1.png', 'nums/orange/numbers-95-2.png', 'nums/orange/numbers-95-3.png', 'nums/orange/numbers-95-4.png', 'nums/orange/numbers-95-5.png', 'nums/orange/numbers-95-6.png', 'nums/orange/numbers-95-7.png', 'nums/orange/numbers-95-8.png', 'nums/orange/numbers-95-9.png'];
    time_group.createWidget(hmUI.widget.IMG_TIME, {
        hour_zero: 1,
        hour_startX: 238,
        hour_startY: 141,
        hour_array: timeDigits,
        hour_align: hmUI.align.RIGHT,
        hour_space: 2,
        minute_zero: 1,
        minute_startX: 238,
        minute_startY: 245,
        minute_array: timeDigits,
        minute_align: hmUI.align.RIGHT,
        minute_space: 2,
        show_level: hmUI.show_level.ONLY_NORMAL
    });

    // setup day number
    const dayNumbers = ['nums/purple/numbers-34-0.png', 'nums/purple/numbers-34-1.png', 'nums/purple/numbers-34-2.png', 'nums/purple/numbers-34-3.png', 'nums/purple/numbers-34-4.png', 'nums/purple/numbers-34-5.png', 'nums/purple/numbers-34-6.png', 'nums/purple/numbers-34-7.png', 'nums/purple/numbers-34-8.png', 'nums/purple/numbers-34-9.png'];
    time_group.createWidget(hmUI.widget.IMG_DATE, {
        day_startX: 221,
        day_startY: 352,
        day_align: hmUI.align.RIGHT,
        day_space: 2,
        day_zero: 1,
        day_en_array: dayNumbers,
        show_level: hmUI.show_level.ONLY_NORMAL,
    });

    // setup month
    const months = ['month/month-jan.png', 'month/month-feb.png', 'month/month-mar.png', 'month/month-apr.png', 'month/month-may.png', 'month/month-jun.png', 'month/month-jul.png', 'month/month-aug.png', 'month/month-sep.png', 'month/month-oct.png', 'month/month-nov.png', 'month/month-dec.png'];
    time_group.createWidget(hmUI.widget.IMG_DATE, {
        month_startX: 200,
        month_startY: 393,
        month_align: hmUI.align.RIGHT,
        month_en_array: months,
        show_level: hmUI.show_level.ONLY_NORMAL,
    });

    // setup day-of-week
    const dow = ['dow/dow-mon.png', 'dow/dow-tue.png', 'dow/dow-wed.png', 'dow/dow-thu.png', 'dow/dow-fri.png', 'dow/dow-sat.png', 'dow/dow-sun.png'];
    time_group.createWidget(hmUI.widget.IMG_WEEK, {
        x: 198,
        y: 435,
        align: hmUI.align.RIGHT,
        week_en: dow,
        show_level: hmUI.show_level.ONLY_NORMAL,
    });

    // hotspots

    time_group.createWidget(hmUI.widget.BUTTON, {
        x: 158,
        y: 142,
        w: 300,
        h: 195,
        press_src: 'blank-10.png',
        normal_src: 'blank-10.png',
        text: '',
        color: 0xffff8c00,
        show_level: hmUI.show_level.ONLY_NORMAL,
        click_func: () => {
            launchApp({
                appId: SYSTEM_APP_WORLD_CLOCK,
                native: true
            });
        }
    });

    time_group.createWidget(hmUI.widget.BUTTON, {
        x: 196,
        y: 353,
        w: 177,
        h: 116,
        press_src: 'blank-10.png',
        normal_src: 'blank-10.png',
        text: '',
        color: 0xffff8c00,
        show_level: hmUI.show_level.ONLY_NORMAL,
        click_func: () => {
            launchApp({
                appId: SYSTEM_APP_CALENDAR,
                native: true
            });
        }
    });    

    // *** AOD ***

    // setup AOD time hours/mins
    const aodTimeDigits = ['nums/white/numbers-95-0.png', 'nums/white/numbers-95-1.png', 'nums/white/numbers-95-2.png', 'nums/white/numbers-95-3.png', 'nums/white/numbers-95-4.png', 'nums/white/numbers-95-5.png', 'nums/white/numbers-95-6.png', 'nums/white/numbers-95-7.png', 'nums/white/numbers-95-8.png', 'nums/white/numbers-95-9.png'];
    time_group.createWidget(hmUI.widget.IMG_TIME, {
        hour_zero: 1,
        hour_startX: 238,
        hour_startY: 141,
        hour_array: aodTimeDigits,
        hour_align: hmUI.align.RIGHT,
        hour_space: 2,
        minute_zero: 1,
        minute_startX: 238,
        minute_startY: 245,
        minute_array: aodTimeDigits,
        minute_align: hmUI.align.RIGHT,
        minute_space: 2,
        show_level: hmUI.show_level.ONLY_AOD,
    });
}

const updateSecondsDisplay = function() {
    const secs = time.getSeconds();
    let level = 1;
    for (let i = 0; i < secs_to_level_map.length; i++) {
        if (secs >= secs_to_level_map[i][0]) {
            level = secs_to_level_map[i][1];
            break;
        }
    }
    secs_param.level = level;
    seconds_widget.setProperty(hmUI.prop.MORE, secs_param);
    seconds_timer = setTimeout(updateSecondsDisplay, 1000);
}

export function show() {
    seconds_timer = setTimeout(updateSecondsDisplay, 1000);
    time_group.setProperty(hmUI.prop.VISIBLE, true);
}

export function hide() {
    clearTimeout(seconds_timer);
    time_group.setProperty(hmUI.prop.VISIBLE, false);
}
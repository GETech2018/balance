import * as time from "./time.js";
import * as weather from "./weather.js";
import * as science from "./science.js";
import * as fitness from "./fitness.js";
import * as hmUI from '@zos/ui';

export function buildView() {

	let mode = 1;

    hmUI.createWidget(hmUI.widget.IMG, {
        x: 0,
        y: 0,
        w: 480,
        h: 480,
        src: 'background-common.png',
        show_level: hmUI.show_level.ONLY_NORMAL,
    });

	time.buildView();
	weather.buildView();
	science.buildView();
	fitness.buildView();

	let showMode = function() {
		if (mode < 1 || mode > 4) {
			mode = 1;
		}
		switch (mode) {
			case 1:
				time.show();
				science.hide();
				break;
			case 2:
				weather.show();
				time.hide();
				break;
			case 3:
				fitness.show();
				weather.hide();
				break;
			case 4:
				science.show();
				fitness.hide()
				break;
		}
	};

	const button = hmUI.createWidget(hmUI.widget.BUTTON, {
		text: '',
		x: 0,
		y: 352,
		w: 128,
		h: 125,
		normal_src: 'blank-10.png',
		press_src: 'blank-10.png',
		color: 0xffff8c00,
		show_level: hmUI.show_level.ONLY_NORMAL,
		click_func: () => {
			mode++;
			showMode(mode);
		}
	});

	const powerDigits = ['nums/black/numbers-40-0.png', 'nums/black/numbers-40-1.png', 'nums/black/numbers-40-2.png', 'nums/black/numbers-40-3.png', 'nums/black/numbers-40-4.png', 'nums/black/numbers-40-5.png', 'nums/black/numbers-40-6.png', 'nums/black/numbers-40-7.png', 'nums/black/numbers-40-8.png', 'nums/black/numbers-40-9.png'];
	hmUI.createWidget(hmUI.widget.TEXT_IMG, {
		x: 74,
		y: 68,
		w: 52,
		h: 39,
		font_array: powerDigits,
		type: hmUI.data_type.BATTERY,
		align_h: hmUI.align.CENTER_H,
		show_level: hmUI.show_level.ONLY_NORMAL
	});	

	// hotspots

	hmUI.createWidget(hmUI.widget.IMG_CLICK, {
		x: 44,
		y: 59,
		w: 100,
		h: 62,
		type: hmUI.data_type.BATTERY,
		show_level: hmUI.show_level.ONLY_NORMAL,
	});

	showMode(mode);
}

import * as hmUI from '@zos/ui';

export function buildView(group) {

    // setup time hours/mins
    const timeDigits = ['nums/purple/numbers-38-0.png', 'nums/purple/numbers-38-1.png', 'nums/purple/numbers-38-2.png', 'nums/purple/numbers-38-3.png', 'nums/purple/numbers-38-4.png', 'nums/purple/numbers-38-5.png', 'nums/purple/numbers-38-6.png', 'nums/purple/numbers-38-7.png', 'nums/purple/numbers-38-8.png', 'nums/purple/numbers-38-9.png'];
    group.createWidget(hmUI.widget.IMG_TIME, {
        hour_zero: 1,
        hour_startX: 218,
        hour_startY: 85,
        hour_array: timeDigits,
        hour_align: hmUI.align.RIGHT,
        hour_space: 2,
        hour_unit_en: 'nums/purple/numbers-38-colon.png',
        hour_unit_sc: 'nums/purple/numbers-38-colon.png',
        hour_unit_tc: 'nums/purple/numbers-38-colon.png',
        minute_follow: 1,
        minute_zero: 1,
        minute_array: timeDigits,
        minute_align: hmUI.align.RIGHT,
        minute_space: 2,
        show_level: hmUI.show_level.ONLY_NORMAL
    });
}

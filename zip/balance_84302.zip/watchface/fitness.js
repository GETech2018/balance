import * as hmUI from '@zos/ui';
import * as timeWidget from "./time-widget.js";

let fitness_group = null;

export function buildView() {

    fitness_group = hmUI.createWidget(hmUI.widget.GROUP, {
        x: 0,
        y: 0
    });
    fitness_group.setProperty(hmUI.prop.VISIBLE, false);

    // background

    fitness_group.createWidget(hmUI.widget.IMG, {
        x: 0,
        y: 0,
        w: 480,
        h: 480,
        src: 'background-fitness.png',
        show_level: hmUI.show_level.ONLY_NORMAL,
    });

    // build the small time view
    timeWidget.buildView(fitness_group);

    // move number
    const meter_digits = ['nums/creme/numbers-32-0.png', 'nums/creme/numbers-32-1.png', 'nums/creme/numbers-32-2.png', 'nums/creme/numbers-32-3.png', 'nums/creme/numbers-32-4.png', 'nums/creme/numbers-32-5.png', 'nums/creme/numbers-32-6.png', 'nums/creme/numbers-32-7.png', 'nums/creme/numbers-32-8.png', 'nums/creme/numbers-32-9.png'];
    fitness_group.createWidget(hmUI.widget.TEXT_IMG, {
        x: 180,
        y: 141,
        w: 55,
        font_array: meter_digits,
        type: hmUI.data_type.CAL,
        h_space: 0,
        align_h: hmUI.align.RIGHT,
        show_level: hmUI.show_level.ONLY_NORMAL,
    });

    // move meter
    let move_meter_steps = [];
    let move_x = [];
    let move_y = [];
    for (let i = 0; i < 15; i++) {
        move_meter_steps.push('fitness/segment-red.png');
        move_x.push(310 + (i * 10));
        move_y.push(141);
    }
    fitness_group.createWidget(hmUI.widget.IMG_PROGRESS, {
        x: move_x,
        y: move_y,
        image_array: move_meter_steps,
        image_length: move_meter_steps.length,
        type: hmUI.data_type.CAL,
        how_level: hmUI.show_level.ONLY_NORMAL,
    });

    // burn numbers
    fitness_group.createWidget(hmUI.widget.TEXT_IMG, {
        x: 180,
        y: 179,
        w: 55,
        font_array: meter_digits,
        type: hmUI.data_type.FAT_BURNING,
        h_space: 0,
        align_h: hmUI.align.RIGHT,
        show_level: hmUI.show_level.ONLY_NORMAL,
    });

    // burn meter
    let burn_meter_steps = [];
    let burn_x = [];
    let burn_y = [];
    for (let i = 0; i < 15; i++) {
        burn_meter_steps.push('fitness/segment-green.png');
        burn_x.push(310 + (i * 10));
        burn_y.push(179);
    }
    fitness_group.createWidget(hmUI.widget.IMG_PROGRESS, {
        x: burn_x,
        y: burn_y,
        image_array: burn_meter_steps,
        image_length: burn_meter_steps.length,
        type: hmUI.data_type.FAT_BURNING,
        how_level: hmUI.show_level.ONLY_NORMAL,
    });

    // stand numbers
    fitness_group.createWidget(hmUI.widget.TEXT_IMG, {
        x: 180,
        y: 217,
        w: 55,
        font_array: meter_digits,
        type: hmUI.data_type.STAND,
        h_space: 0,
        align_h: hmUI.align.RIGHT,
        show_level: hmUI.show_level.ONLY_NORMAL,
    });

    // stand meter
    let stand_meter_steps = [];
    let stand_x = [];
    let stand_y = [];
    for (let i = 0; i < 15; i++) {
        stand_meter_steps.push('fitness/segment-blue.png');
        stand_x.push(310 + (i * 10));
        stand_y.push(217);
    }
    fitness_group.createWidget(hmUI.widget.IMG_PROGRESS, {
        x: stand_x,
        y: stand_y,
        image_array: stand_meter_steps,
        image_length: stand_meter_steps.length,
        type: hmUI.data_type.STAND,
        how_level: hmUI.show_level.ONLY_NORMAL,
    });

    // PAI numbers (daily)
    fitness_group.createWidget(hmUI.widget.TEXT_IMG, {
        x: 180,
        y: 255,
        w: 55,
        font_array: meter_digits,
        type: hmUI.data_type.PAI_DAILY,
        h_space: 0,
        align_h: hmUI.align.RIGHT,
        show_level: hmUI.show_level.ONLY_NORMAL,
    });

    // PAI meter (week)
    let pai_meter_steps = [];
    let pai_x = [];
    let pai_y = [];
    for (let i = 0; i < 15; i++) {
        pai_meter_steps.push('fitness/segment-orange.png');
        pai_x.push(310 + (i * 10));
        pai_y.push(255);
    }
    fitness_group.createWidget(hmUI.widget.IMG_PROGRESS, {
        x: pai_x,
        y: pai_y,
        image_array: pai_meter_steps,
        image_length: pai_meter_steps.length,
        type: hmUI.data_type.PAI_WEEKLY,
        how_level: hmUI.show_level.ONLY_NORMAL,
    });

    // miles/distance
    const distance_digits = ['nums/orange/numbers-32-0.png', 'nums/orange/numbers-32-1.png', 'nums/orange/numbers-32-2.png', 'nums/orange/numbers-32-3.png', 'nums/orange/numbers-32-4.png', 'nums/orange/numbers-32-5.png', 'nums/orange/numbers-32-6.png', 'nums/orange/numbers-32-7.png', 'nums/orange/numbers-32-8.png', 'nums/orange/numbers-32-9.png'];
    fitness_group.createWidget(hmUI.widget.TEXT_IMG, {
        x: 200,
        y: 305,
        w: 100,
        font_array: distance_digits,
        dot_image: 'nums/orange/numbers-32-dot.png',
        type: hmUI.data_type.DISTANCE,
        h_space: 0,
        align_h: hmUI.align.RIGHT,
        show_level: hmUI.show_level.ONLY_NORMAL,
    });

    // steps
    fitness_group.createWidget(hmUI.widget.TEXT_IMG, {
        x: 200,
        y: 353,
        w: 100,
        font_array: distance_digits,
        dot_image: 'nums/orange/numbers-32-dot.png',
        type: hmUI.data_type.STEP,
        h_space: 0,
        align_h: hmUI.align.RIGHT,
        show_level: hmUI.show_level.ONLY_NORMAL,
    });

    // heart beat
    fitness_group.createWidget(hmUI.widget.TEXT_IMG, {
        x: 200,
        y: 401,
        w: 100,
        font_array: distance_digits,
        dot_image: 'nums/orange/numbers-32-dot.png',
        type: hmUI.data_type.HEART,
        h_space: 0,
        align_h: hmUI.align.RIGHT,
        show_level: hmUI.show_level.ONLY_NORMAL,
    });

    fitness_group.createWidget(hmUI.widget.IMG_CLICK, {
        x: 213,
        y: 395,
        w: 243,
        h: 80,
        type: hmUI.data_type.HEART,
        show_level: hmUI.show_level.ONLY_NORMAL,
    });

    fitness_group.createWidget(hmUI.widget.IMG_CLICK, {
        x: 193,
        y: 346,
        w: 262,
        h: 46,
        type: hmUI.data_type.STEP,
        show_level: hmUI.show_level.ONLY_NORMAL,
    });

    fitness_group.createWidget(hmUI.widget.IMG_CLICK, {
        x: 193,
        y: 298,
        w: 281,
        h: 46,
        type: hmUI.data_type.DISTANCE,
        show_level: hmUI.show_level.ONLY_NORMAL,
    });

    fitness_group.createWidget(hmUI.widget.IMG_CLICK, {
        x: 142,
        y: 254,
        w: 341,
        h: 49,
        type: hmUI.data_type.PAI_DAILY,
        show_level: hmUI.show_level.ONLY_NORMAL,
    });

    fitness_group.createWidget(hmUI.widget.IMG_CLICK, {
        x: 140,
        y: 214,
        w: 341,
        h: 38,
        type: hmUI.data_type.STAND,
        show_level: hmUI.show_level.ONLY_NORMAL,
    });

    fitness_group.createWidget(hmUI.widget.IMG_CLICK, {
        x: 140,
        y: 176,
        w: 341,
        h: 38,
        type: hmUI.data_type.FAT_BURNING,
        show_level: hmUI.show_level.ONLY_NORMAL,
    });

    fitness_group.createWidget(hmUI.widget.IMG_CLICK, {
        x: 140,
        y: 138,
        w: 341,
        h: 38,
        type: hmUI.data_type.CAL,
        show_level: hmUI.show_level.ONLY_NORMAL,
    });
}

export function show() {
    fitness_group.setProperty(hmUI.prop.VISIBLE, true);
}

export function hide() {
    fitness_group.setProperty(hmUI.prop.VISIBLE, false);
}
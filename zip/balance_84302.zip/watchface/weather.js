import * as hmUI from '@zos/ui';
import * as timeWidget from "./time-widget.js";
import { getTemperatureUnit, TEMPERATURE_UNIT_CENTIGRADE } from '@zos/settings';

let weather_group = null;
let temp_unit = null;
let temp_unit_widget = null;

function getTempUnitParams() {
    let src = temp_unit == TEMPERATURE_UNIT_CENTIGRADE ? 'weather/temp-scale-c.png' : 'weather/temp-scale-f.png';
    let params = {
        x: 301,
        y: 255,
        src: src,
        show_level: hmUI.show_level.ONLY_NORMAL,
    };

    return params;
}

export function buildView() {

	weather_group = hmUI.createWidget(hmUI.widget.GROUP, {});
	weather_group.setProperty(hmUI.prop.VISIBLE, false);
    temp_unit = getTemperatureUnit();

    // background

    weather_group.createWidget(hmUI.widget.IMG, {
        x: 0,
        y: 0,
        w: 480,
        h: 480,
        src: 'background-weather.png',
        show_level: hmUI.show_level.ONLY_NORMAL,
    });

    // current weather conditions
    const weather_conditions = ['weather/weather-0.png', 'weather/weather-1.png', 'weather/weather-2.png', 'weather/weather-3.png', 'weather/weather-4.png', 'weather/weather-5.png', 'weather/weather-6.png', 'weather/weather-7.png', 'weather/weather-8.png', 'weather/weather-9.png', 'weather/weather-10.png', 'weather/weather-11.png', 'weather/weather-12.png', 'weather/weather-13.png', 'weather/weather-14.png', 'weather/weather-15.png', 'weather/weather-16.png', 'weather/weather-17.png', 'weather/weather-18.png', 'weather/weather-19.png', 'weather/weather-20.png', 'weather/weather-21.png', 'weather/weather-22.png', 'weather/weather-23.png', 'weather/weather-24.png', 'weather/weather-25.png', 'weather/weather-26.png', 'weather/weather-27.png', 'weather/weather-28.png'];
    weather_group.createWidget(hmUI.widget.IMG_LEVEL, {
        x: 185,
        y: 139,
        image_array: weather_conditions,
        image_length: 29,
        type: hmUI.data_type.WEATHER_CURRENT,
        show_level: hmUI.show_level.ONLY_NORMAL,
    });

    // current temp
    const cur_temp_digits = ['nums/orange/numbers-59-0.png', 'nums/orange/numbers-59-1.png', 'nums/orange/numbers-59-2.png', 'nums/orange/numbers-59-3.png', 'nums/orange/numbers-59-4.png', 'nums/orange/numbers-59-5.png', 'nums/orange/numbers-59-6.png', 'nums/orange/numbers-59-7.png', 'nums/orange/numbers-59-8.png', 'nums/orange/numbers-59-9.png'];
    weather_group.createWidget(hmUI.widget.TEXT_IMG, {
        x: 149,
        y: 238,
        w: 105,
        font_array: cur_temp_digits,
        type: hmUI.data_type.WEATHER_CURRENT,
        h_space: 0,
        align_h: hmUI.align.RIGHT,
        negative_image: 'nums/orange/numbers-59-negative.png',
        show_level: hmUI.show_level.ONLY_NORMAL,
    });

    // high temp
    const range_temp_digits = ['nums/purple/numbers-32-0.png', 'nums/purple/numbers-32-1.png', 'nums/purple/numbers-32-2.png', 'nums/purple/numbers-32-3.png', 'nums/purple/numbers-32-4.png', 'nums/purple/numbers-32-5.png', 'nums/purple/numbers-32-6.png', 'nums/purple/numbers-32-7.png', 'nums/purple/numbers-32-8.png', 'nums/purple/numbers-32-9.png'];
    weather_group.createWidget(hmUI.widget.TEXT_IMG, {
        x: 378,
        y: 207,
        font_array: range_temp_digits,
        type: hmUI.data_type.WEATHER_HIGH,
        h_space: 0,
        align_h: hmUI.align.LEFT,
        unit_sc: 'nums/purple/numbers-32-degree.png',
        unit_en: 'nums/purple/numbers-32-degree.png',
        unit_tc: 'nums/purple/numbers-32-degree.png',
        imperial_unit_sc: 'nums/purple/numbers-32-degree.png',
        imperial_unit_en: 'nums/purple/numbers-32-degree.png',
        imperial_unit_tc: 'nums/purple/numbers-32-degree.png',
        negative_image: 'nums/purple/numbers-32-negative.png',
        show_level: hmUI.show_level.ONLY_NORMAL,
    });

    // low temp
    weather_group.createWidget(hmUI.widget.TEXT_IMG, {
        x: 378,
        y: 295,
        font_array: range_temp_digits,
        type: hmUI.data_type.WEATHER_LOW,
        h_space: 0,
        align_h: hmUI.align.LEFT,
        unit_sc: 'nums/purple/numbers-32-degree.png',
        unit_en: 'nums/purple/numbers-32-degree.png',
        unit_tc: 'nums/purple/numbers-32-degree.png',
        imperial_unit_sc: 'nums/purple/numbers-32-degree.png',
        imperial_unit_en: 'nums/purple/numbers-32-degree.png',
        imperial_unit_tc: 'nums/purple/numbers-32-degree.png',
        negative_image: 'nums/purple/numbers-32-negative.png',
    });

    // humidity
    const humidity_digits = ['nums/magenta/numbers-26-0.png', 'nums/magenta/numbers-26-1.png', 'nums/magenta/numbers-26-2.png', 'nums/magenta/numbers-26-3.png', 'nums/magenta/numbers-26-4.png', 'nums/magenta/numbers-26-5.png', 'nums/magenta/numbers-26-6.png', 'nums/magenta/numbers-26-7.png', 'nums/magenta/numbers-26-8.png', 'nums/magenta/numbers-26-9.png']; 
    weather_group.createWidget(hmUI.widget.TEXT_IMG, {
        x: 180,
        y: 366,
        w: 210,
        font_array: humidity_digits,
        type: hmUI.data_type.HUMIDITY,
        h_space: 0,
        align_h: hmUI.align.CENTER_H,
        unit_sc: 'nums/magenta/numbers-26-percent.png',
        unit_en: 'nums/magenta/numbers-26-percent.png',
        unit_tc: 'nums/magenta/numbers-26-percent.png',
        imperial_unit_sc: 'nums/magenta/numbers-26-percent.png',
        imperial_unit_en: 'nums/magenta/numbers-26-percent.png',
        imperial_unit_tc: 'nums/magenta/numbers-26-percent.png',
        show_level: hmUI.show_level.ONLY_NORMAL,
    });

    // humidity meter
    let humidity_meter_steps = [];
    let humidity_x = [];
    let humidity_y = [];
    for (let i = 0; i < 30; i++) {
        humidity_meter_steps.push('weather/humidity-step.png');
        humidity_x.push(180 + (i * 7));
        humidity_y.push(399);
    }
    weather_group.createWidget(hmUI.widget.IMG_PROGRESS, {
        x: humidity_x,
        y: humidity_y,
        image_array: humidity_meter_steps,
        image_length: humidity_meter_steps.length,
        type: hmUI.data_type.HUMIDITY,
        how_level: hmUI.show_level.ONLY_NORMAL,
    });

    // temperature unit/scale
    let temp_unit_params = getTempUnitParams();
    temp_unit_widget = weather_group.createWidget(hmUI.widget.IMG, temp_unit_params);

    // build the small time view
    timeWidget.buildView(weather_group);

    // hotspots

    weather_group.createWidget(hmUI.widget.IMG_CLICK, {
        x: 159,
        y: 185,
        w: 328,
        h: 160,
        type: hmUI.data_type.WEATHER_CURRENT,
        show_level: hmUI.show_level.ONLY_NORMAL,
    });
}

function updateTempScale() {
    
    let new_temp_unit = getTemperatureUnit();

    if (temp_unit != new_temp_unit) {
        temp_unit = new_temp_unit;
        let temp_unit_params = getTempUnitParams();
        temp_unit_widget.setProperty(hmUI.prop.MORE, temp_unit_params);
    }
}

export function show() {
    updateTempScale();
    weather_group.setProperty(hmUI.prop.VISIBLE, true);
}

export function hide() {
    weather_group.setProperty(hmUI.prop.VISIBLE, false);
}
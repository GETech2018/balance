import * as hmUI from '@zos/ui';
import * as timeWidget from "./time-widget.js";
//import { Compass } from '@zos/sensor';
import { getDistanceUnit, DISTANCE_UNIT_METRIC } from '@zos/settings';

let science_group = null;
//let compass = null;
let distance_unit = null;
let wind_force_widget = null;

function getWindowForceWidgetParams() {

    let font_array = distance_unit == DISTANCE_UNIT_METRIC
        ? ['wind/kph/wind-force-0.png', 'wind/kph/wind-force-1.png', 'wind/kph/wind-force-2.png', 'wind/kph/wind-force-3.png', 'wind/kph/wind-force-4.png', 'wind/kph/wind-force-5.png', 'wind/kph/wind-force-6.png', 'wind/kph/wind-force-7.png', 'wind/kph/wind-force-8.png', 'wind/kph/wind-force-9.png', 'wind/kph/wind-force-10.png', 'wind/kph/wind-force-11.png', 'wind/kph/wind-force-12.png']
        : ['wind/mph/wind-force-0.png', 'wind/mph/wind-force-1.png', 'wind/mph/wind-force-2.png', 'wind/mph/wind-force-3.png', 'wind/mph/wind-force-4.png', 'wind/mph/wind-force-5.png', 'wind/mph/wind-force-6.png', 'wind/mph/wind-force-7.png', 'wind/mph/wind-force-8.png', 'wind/mph/wind-force-9.png', 'wind/mph/wind-force-10.png', 'wind/mph/wind-force-11.png', 'wind/mph/wind-force-12.png'];

    let params = {
        x: 264,
        y: 324,
        w: 79,
        font_array: font_array,
        type: hmUI.data_type.WIND,
        h_space: 0,
        align_h: hmUI.align.RIGHT,
        show_level: hmUI.show_level.ONLY_NORMAL,
    };

    return params;
}

export function buildView() {

    distance_unit = getDistanceUnit();
    science_group = hmUI.createWidget(hmUI.widget.GROUP, {});
    science_group.setProperty(hmUI.prop.VISIBLE, false);
    //compass = new Compass();

    // background

    science_group.createWidget(hmUI.widget.IMG, {
        x: 0,
        y: 0,
        w: 480,
        h: 480,
        src: 'background-science.png',
        show_level: hmUI.show_level.ONLY_NORMAL,
    });

    // compass

    /*
    let compassChanged = function() {
        if (compass.getStatus()) {
            console.log('dir: ', compass.getDirection());
            console.log('angle: ', compass.getDirectionAngle());
        }
    }

    compass.onChange(compassChanged);
    */

    // wind direction
    const wind_dirs = ['wind/wind-n.png','wind/wind-ne.png', 'wind/wind-e.png', 'wind/wind-se.png', 'wind/wind-s.png', 'wind/wind-sw.png', 'wind/wind-w.png', 'wind/wind-nw.png']; 
    science_group.createWidget(hmUI.widget.IMG_LEVEL, {
        x: 145,
        y: 142,
        image_array: wind_dirs,
        image_length: 8,
        type: hmUI.data_type.WIND_DIRECTION,
        show_level: hmUI.show_level.ONLY_NORMAL,
    });

    // wind speed
    let window_force_params = getWindowForceWidgetParams();
    wind_force_widget = science_group.createWidget(hmUI.widget.TEXT_IMG, window_force_params);

    // altitude
    const altitude_digits = ['nums/tomato/numbers-28-0.png', 'nums/tomato/numbers-28-1.png', 'nums/tomato/numbers-28-2.png', 'nums/tomato/numbers-28-3.png', 'nums/tomato/numbers-28-4.png', 'nums/tomato/numbers-28-5.png', 'nums/tomato/numbers-28-6.png', 'nums/tomato/numbers-28-7.png', 'nums/tomato/numbers-28-8.png', 'nums/tomato/numbers-28-9.png'];
    science_group.createWidget(hmUI.widget.TEXT_IMG, {
        x: 217,
        y: 377,
        w: 72,
        font_array: altitude_digits,
        type: hmUI.data_type.ALTITUDE,
        h_space: 0,
        align_h: hmUI.align.RIGHT,
        show_level: hmUI.show_level.ONLY_NORMAL,
    });

    // air pressure
    let pressure_digits = ['nums/lilac/numbers-28-0.png', 'nums/lilac/numbers-28-1.png', 'nums/lilac/numbers-28-2.png', 'nums/lilac/numbers-28-3.png', 'nums/lilac/numbers-28-4.png', 'nums/lilac/numbers-28-5.png', 'nums/lilac/numbers-28-6.png', 'nums/lilac/numbers-28-7.png', 'nums/lilac/numbers-28-8.png', 'nums/lilac/numbers-28-9.png'];
    science_group.createWidget(hmUI.widget.TEXT_IMG, {
        x: 172,
        y: 425,
        w: 50,
        font_array: pressure_digits,
        type: hmUI.data_type.ALTIMETER,
        h_space: 0,
        align_h: hmUI.align.RIGHT,
        show_level: hmUI.show_level.ONLY_NORMAL,
    });

    // build the small time view
    timeWidget.buildView(science_group);

    // hotspots
    
    science_group.createWidget(hmUI.widget.IMG_CLICK, {
        x: 150,
        y: 146,
        w: 320,
        h: 327,
        type: hmUI.data_type.WEATHER_CURRENT,
        show_level: hmUI.show_level.ONLY_NORMAL,
    });
}

function updateDistanceScale() {
    
    let new_distance_scale = getDistanceUnit();

    if (distance_unit != new_distance_scale) {
        distance_unit = new_distance_scale;
        let wind_force_params = getWindowForceWidgetParams();
        wind_force_widget.setProperty(hmUI.prop.MORE, wind_force_params);
    }
}

export function show() {
    c//ompass.start();
    updateDistanceScale();
    science_group.setProperty(hmUI.prop.VISIBLE, true);
}

export function hide() {
    science_group.setProperty(hmUI.prop.VISIBLE, false);
    //compass.stop();
}
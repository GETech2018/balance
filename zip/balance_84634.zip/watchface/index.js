﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js


let time24 = hmSensor.createSensor(hmSensor.id.TIME);
let normal_24Hcheck =''

function check24h(){
if (time24.is24Hour){
normal_24Hcheck.setProperty(hmUI.prop.VISIBLE, true);
}

if (!time24.is24Hour){
normal_24Hcheck.setProperty(hmUI.prop.VISIBLE, false);
}

}

      // Start background change
        let elementnumber_1 = 1
        let total_elemente = 2

        function click_switch_Step_Distance() {
            if(elementnumber_1==total_elemente) {
            elementnumber_1=1;
                UpdateElementeOne();
                }
            else {
                elementnumber_1=elementnumber_1+1;
                if(elementnumber_1==2) {
                  UpdateElementeTwo();
                }

            }
          //  if(elementnumber_1==1) hmUI.showToast({text: 'Steps'});
          //  if(elementnumber_1==2) hmUI.showToast({text: 'Distance'});
        }

        //Steps
        function UpdateElementeOne(){
        normal_distance_icon_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, true);

        }

        //Distance
        function UpdateElementeTwo(){
        normal_distance_icon_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        }


//////////////////////////////////////////////////////////////////////////////////////////////////
        let deviceInfoA = hmSetting.getDeviceInfo();

        // Start color change
         let colornumber = 1
        let totalcolors = 6
        let namecolor = ''

        function click_Color() {
            if(colornumber>=totalcolors) {
            colornumber=1;
                }
            else {
                colornumber=colornumber+1;
            }

if ( colornumber == 1) { namecolor = "YELLOW"}
if ( colornumber == 2) { namecolor = "GREEN"}
if ( colornumber == 3) { namecolor = "BLUE"}
if ( colornumber == 4) { namecolor = "ORANGE"}
if ( colornumber == 5) { namecolor = "RED"}
if ( colornumber == 6) { namecolor = "WHITE"}
hmUI.showToast({text: namecolor });

             //hmUI.showToast({text: "color " + parseInt(colornumber) });
             normal_background_bg_img.setProperty(hmUI.prop.SRC, "bg" + parseInt(colornumber) + ".png");
             normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.SRC, "Hand_S" + parseInt(colornumber) + ".png");

            normal_system_clock_img.setProperty(hmUI.prop.MORE, {
              x: deviceInfoA.width / 480 * 371,
              y: deviceInfoA.height / 480 * 383,
              src: "System_Alarm" + parseInt(colornumber) + ".png",
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
   const result = hmSetting.setScreenOff()                       
        }

/////////////////////////////////////////////////////////////////////////////////////////////////
        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_sun_current_text_img = ''
        let normal_sun_current_separator_img = ''
        let normal_wind_direction_image_progress_img_level = ''
        let normal_wind_text_text_img = ''
        let normal_humidity_text_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_high_text_img = ''
        let normal_temperature_low_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_calorie_current_text_img = ''
        let normal_distance_icon_img = ''
        let normal_distance_text_text_img = ''
        let normal_step_linear_scale = ''
        let normal_step_icon_img = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_text_separator_img = ''
        let normal_battery_circle_scale = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time_second = ''
        let normal_digital_clock_img_time_minute = ''
        let normal_digital_clock_minute_separator_img = ''
        let normal_digital_clock_img_time_hour = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_analog_clock_pro_second_pointer_img = ''
        let normal_timerUpdateSecSmooth = undefined;
        let idle_battery_text_text_img = ''
        let idle_digital_clock_img_time_minute = ''
        let idle_digital_clock_minute_separator_img = ''
        let idle_digital_clock_img_time_hour = ''
        let idle_digital_clock_hour_separator_img = ''
        let normal_step_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_moon_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 250,
              y: 437,
              src: 'System_BT_OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 371,
              y: 383,
              src: 'System_Alarm1.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 365,
              y: 66,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 111,
              y: 292,
              font_array: ["TempLH_0.png","TempLH_1.png","TempLH_2.png","TempLH_3.png","TempLH_4.png","TempLH_5.png","TempLH_6.png","TempLH_7.png","TempLH_8.png","TempLH_9.png"],
              padding: false,
              h_space: 0,
              invalid_image: 'SS_dot.png',
              dot_image: 'SS_dot.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 74,
              y: 294,
              src: 'icon_SS.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_direction_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 214,
              y: 262,
              image_array: ["Wind_d_1.png","Wind_d_2.png","Wind_d_3.png","Wind_d_4.png","Wind_d_5.png","Wind_d_6.png","Wind_d_7.png","Wind_d_8.png"],
              image_length: 8,
              type: hmUI.data_type.WIND_DIRECTION,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 182,
              y: 261,
              font_array: ["Hum_0.png","Hum_1.png","Hum_2.png","Hum_3.png","Hum_4.png","Hum_5.png","Hum_6.png","Hum_7.png","Hum_8.png","Hum_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WIND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 86,
              y: 261,
              font_array: ["Hum_0.png","Hum_1.png","Hum_2.png","Hum_3.png","Hum_4.png","Hum_5.png","Hum_6.png","Hum_7.png","Hum_8.png","Hum_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'hum_unit.png',
              unit_tc: 'hum_unit.png',
              unit_en: 'hum_unit.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('user_script.js');
            // start user_script.js
           const deviceInfo1 = hmSetting.getDeviceInfo();
            normal_24Hcheck = hmUI.createWidget(hmUI.widget.IMG, {
              x: deviceInfo1.width / 480 * 251,
              y: deviceInfo1.height / 480 * 107,
              src: 'Clock_24H.png',
            show_level: hmUI.show_level.ALL,

            });
check24h()
            // end user_script.js

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 62,
              y: 156,
              image_array: ["Weather_01.png","Weather_02.png","Weather_03.png","Weather_04.png","Weather_05.png","Weather_06.png","Weather_07.png","Weather_08.png","Weather_09.png","Weather_10.png","Weather_11.png","Weather_12.png","Weather_13.png","Weather_14.png","Weather_15.png","Weather_16.png","Weather_17.png","Weather_18.png","Weather_19.png","Weather_20.png","Weather_21.png","Weather_22.png","Weather_23.png","Weather_24.png","Weather_25.png","Weather_26.png","Weather_27.png","Weather_28.png","Weather_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 184,
              y: 226,
              font_array: ["TempLH_0.png","TempLH_1.png","TempLH_2.png","TempLH_3.png","TempLH_4.png","TempLH_5.png","TempLH_6.png","TempLH_7.png","TempLH_8.png","TempLH_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Temp_unit.png',
              unit_tc: 'Temp_unit.png',
              unit_en: 'Temp_unit.png',
              imperial_unit_sc: 'Temp_unit.png',
              imperial_unit_tc: 'Temp_unit.png',
              imperial_unit_en: 'Temp_unit.png',
              negative_image: 'TempLH_error.png',
              invalid_image: 'TempLH_error.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const temperatureUnit = hmSetting.getTemperatureUnit();
            //start of ignored block
            if (temperatureUnit == 1) {
              normal_temperature_high_text_img.setProperty(hmUI.prop.MORE, {
                x: 184,
                y: 226,
                font_array: ["TempLH_0.png","TempLH_1.png","TempLH_2.png","TempLH_3.png","TempLH_4.png","TempLH_5.png","TempLH_6.png","TempLH_7.png","TempLH_8.png","TempLH_9.png"],
                padding: false,
                h_space: 0,
                unit_sc: 'Temp_unit.png',
                unit_tc: 'Temp_unit.png',
                unit_en: 'Temp_unit.png',
                imperial_unit_sc: 'Temp_unit.png',
                imperial_unit_tc: 'Temp_unit.png',
                imperial_unit_en: 'Temp_unit.png',
                negative_image: 'TempLH_error.png',
                invalid_image: 'TempLH_error.png',
                align_h: hmUI.align.CENTER_H,
                type: hmUI.data_type.WEATHER_HIGH,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
            };
            //end of ignored block

            normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 115,
              y: 226,
              font_array: ["TempLH_0.png","TempLH_1.png","TempLH_2.png","TempLH_3.png","TempLH_4.png","TempLH_5.png","TempLH_6.png","TempLH_7.png","TempLH_8.png","TempLH_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Temp_unit.png',
              unit_tc: 'Temp_unit.png',
              unit_en: 'Temp_unit.png',
              imperial_unit_sc: 'Temp_unit.png',
              imperial_unit_tc: 'Temp_unit.png',
              imperial_unit_en: 'Temp_unit.png',
              negative_image: 'TempLH_error.png',
              invalid_image: 'TempLH_error.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            //start of ignored block
            if (temperatureUnit == 1) {
              normal_temperature_low_text_img.setProperty(hmUI.prop.MORE, {
                x: 115,
                y: 226,
                font_array: ["TempLH_0.png","TempLH_1.png","TempLH_2.png","TempLH_3.png","TempLH_4.png","TempLH_5.png","TempLH_6.png","TempLH_7.png","TempLH_8.png","TempLH_9.png"],
                padding: false,
                h_space: 0,
                unit_sc: 'Temp_unit.png',
                unit_tc: 'Temp_unit.png',
                unit_en: 'Temp_unit.png',
                imperial_unit_sc: 'Temp_unit.png',
                imperial_unit_tc: 'Temp_unit.png',
                imperial_unit_en: 'Temp_unit.png',
                negative_image: 'TempLH_error.png',
                invalid_image: 'TempLH_error.png',
                align_h: hmUI.align.CENTER_H,
                type: hmUI.data_type.WEATHER_LOW,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
            };
            //end of ignored block

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 131,
              y: 168,
              font_array: ["Batt_0.png","Batt_1.png","Batt_2.png","Batt_3.png","Batt_4.png","Batt_5.png","Batt_6.png","Batt_7.png","Batt_8.png","Batt_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'TempC.png',
              unit_tc: 'TempC.png',
              unit_en: 'TempC.png',
              imperial_unit_sc: 'TempF.png',
              imperial_unit_tc: 'TempF.png',
              imperial_unit_en: 'TempF.png',
              negative_image: 'Temp_Error.png',
              invalid_image: 'Temp_Error.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            //start of ignored block
            if (temperatureUnit == 1) {
              normal_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
                x: 131,
                y: 168,
                font_array: ["Batt_0.png","Batt_1.png","Batt_2.png","Batt_3.png","Batt_4.png","Batt_5.png","Batt_6.png","Batt_7.png","Batt_8.png","Batt_9.png"],
                padding: false,
                h_space: 0,
                unit_sc: 'TempF.png',
                unit_tc: 'TempF.png',
                unit_en: 'TempF.png',
                imperial_unit_sc: 'TempC.png',
                imperial_unit_tc: 'TempC.png',
                imperial_unit_en: 'TempC.png',
                negative_image: 'Temp_Error.png',
                invalid_image: 'Temp_Error.png',
                align_h: hmUI.align.CENTER_H,
                type: hmUI.data_type.WEATHER_CURRENT,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
            };
            //end of ignored block

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 115,
              y: 118,
              font_array: ["Batt_0.png","Batt_1.png","Batt_2.png","Batt_3.png","Batt_4.png","Batt_5.png","Batt_6.png","Batt_7.png","Batt_8.png","Batt_9.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 348,
              y: 326,
              week_en: ["Week1.png","Week2.png","Week3.png","Week4.png","Week5.png","Week6.png","Week7.png"],
              week_tc: ["Week1.png","Week2.png","Week3.png","Week4.png","Week5.png","Week6.png","Week7.png"],
              week_sc: ["Week1.png","Week2.png","Week3.png","Week4.png","Week5.png","Week6.png","Week7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 264,
              day_startY: 336,
              day_sc_array: ["Batt_0.png","Batt_1.png","Batt_2.png","Batt_3.png","Batt_4.png","Batt_5.png","Batt_6.png","Batt_7.png","Batt_8.png","Batt_9.png"],
              day_tc_array: ["Batt_0.png","Batt_1.png","Batt_2.png","Batt_3.png","Batt_4.png","Batt_5.png","Batt_6.png","Batt_7.png","Batt_8.png","Batt_9.png"],
              day_en_array: ["Batt_0.png","Batt_1.png","Batt_2.png","Batt_3.png","Batt_4.png","Batt_5.png","Batt_6.png","Batt_7.png","Batt_8.png","Batt_9.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 177,
              y: 391,
              font_array: ["Batt_0.png","Batt_1.png","Batt_2.png","Batt_3.png","Batt_4.png","Batt_5.png","Batt_6.png","Batt_7.png","Batt_8.png","Batt_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 120,
              y: 47,
              src: 'BG_Distance.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 178,
              y: 72,
              font_array: ["TempLH_0.png","TempLH_1.png","TempLH_2.png","TempLH_3.png","TempLH_4.png","TempLH_5.png","TempLH_6.png","TempLH_7.png","TempLH_8.png","TempLH_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Dis_KM.png',
              unit_tc: 'Dis_KM.png',
              unit_en: 'Dis_KM.png',
              imperial_unit_sc: 'Dis_Mi.png',
              imperial_unit_tc: 'Dis_Mi.png',
              imperial_unit_en: 'Dis_Mi.png',
              dot_image: 'Dis_dot.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            if (screenType != hmSetting.screen_type.AOD) {
              normal_step_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);

            normal_step_linear_scale.setAlpha(181);
            };

            // normal_step_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 184,
              // start_y: 19,
              // color: 0xFF000000,
              // lenght: 112,
              // line_width: 24,
              // line_cap: Flat,
              // vertical: False,
              // mirror: False,
              // inversion: True,
              // alpha: 181,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 120,
              y: 47,
              src: 'BG_Steps.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 174,
              y: 63,
              font_array: ["Batt_0.png","Batt_1.png","Batt_2.png","Batt_3.png","Batt_4.png","Batt_5.png","Batt_6.png","Batt_7.png","Batt_8.png","Batt_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 177,
              y: 17,
              src: 'Top_Step.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 104,
              y: 334,
              font_array: ["Batt_0.png","Batt_1.png","Batt_2.png","Batt_3.png","Batt_4.png","Batt_5.png","Batt_6.png","Batt_7.png","Batt_8.png","Batt_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Batt_unit.png',
              unit_tc: 'Batt_unit.png',
              unit_en: 'Batt_unit.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 66,
              src: 'Top_Battery.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 240,
              // center_y: 240,
              // start_angle: 223,
              // end_angle: 316,
              // radius: 233,
              // line_width: 9,
              // line_cap: Flat,
              // color: 0xFF000000,
              // mirror: False,
              // inversion: True,
              // alpha: 181,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 240,
              center_y: 240,
              start_angle: 316,
              end_angle: 223,
              radius: 229,
              line_width: 9,
              corner_flag: 3,
              color: 0xFF000000,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_circle_scale.setAlpha(181);
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 251,
              am_y: 107,
              am_sc_path: 'Clock_AM.png',
              am_en_path: 'Clock_AM.png',
              pm_x: 251,
              pm_y: 107,
              pm_sc_path: 'Clock_PM.png',
              pm_en_path: 'Clock_PM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_second = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              second_startX: 362,
              second_startY: 115,
              second_array: ["Time_S_0.png","Time_S_1.png","Time_S_2.png","Time_S_3.png","Time_S_4.png","Time_S_5.png","Time_S_6.png","Time_S_7.png","Time_S_8.png","Time_S_9.png"],
              second_zero: 1,
              second_space: 1,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 276,
              minute_startY: 247,
              minute_array: ["Time_M_0.png","Time_M_1.png","Time_M_2.png","Time_M_3.png","Time_M_4.png","Time_M_5.png","Time_M_6.png","Time_M_7.png","Time_M_8.png","Time_M_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_minute_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 258,
              y: 232,
              src: 'Top_minute.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 276,
              hour_startY: 168,
              hour_array: ["Time_0.png","Time_1.png","Time_2.png","Time_3.png","Time_4.png","Time_5.png","Time_6.png","Time_7.png","Time_8.png","Time_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 271,
              y: 155,
              src: 'Top_Hour.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const deviceInfo = hmSetting.getDeviceInfo();
            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'Hand_S1.png',
              // center_x: 240,
              // center_y: 240,
              // x: 60,
              // y: 241,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 60,
              pos_y: 240 - 241,
              center_x: 240,
              center_y: 240,
              src: 'Hand_S1.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_smooth_second = hmUI.createWidget(hmUI.widget.SMOOTH_SECOND, {
              // type: 2,
              // fps: 15,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });



            console.log('Watch_Face.ScreenAOD');

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 211,
              y: 454,
              font_array: ["Hum_0.png","Hum_1.png","Hum_2.png","Hum_3.png","Hum_4.png","Hum_5.png","Hum_6.png","Hum_7.png","Hum_8.png","Hum_9.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'hum_unit.png',
              unit_tc: 'hum_unit.png',
              unit_en: 'hum_unit.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 159,
              minute_startY: 247,
              minute_array: ["Time_0.png","Time_1.png","Time_2.png","Time_3.png","Time_4.png","Time_5.png","Time_6.png","Time_7.png","Time_8.png","Time_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_minute_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 162,
              y: 232,
              src: 'Top_minute.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 157,
              hour_startY: 168,
              hour_array: ["Time_0.png","Time_1.png","Time_2.png","Time_3.png","Time_4.png","Time_5.png","Time_6.png","Time_7.png","Time_8.png","Time_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 160,
              y: 155,
              src: 'Top_Hour.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 191,
              y: 53,
              w: 162,
              h: 46,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 122,
              y: 111,
              w: 113,
              h: 38,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 125,
              y: 380,
              w: 55,
              h: 47,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 73,
              y: 290,
              w: 176,
              h: 25,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 362,
              y: 60,
              w: 59,
              h: 42,
              type: hmUI.data_type.MOON_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 145,
              y: 169,
              w: 96,
              h: 72,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 66,
              y: 106,
              w: 46,
              h: 44,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 354,
              y: 111,
              w: 80,
              h: 42,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 315,
              y: 172,
              w: 83,
              h: 57,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 360,
              y: 376,
              w: 46,
              h: 55,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 72,
              y: 330,
              w: 168,
              h: 37,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PowerSaveHintScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 350,
              y: 327,
              w: 87,
              h: 44,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 442,
              y: 208,
              w: 39,
              h: 62,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'Settings_homeScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 188,
              y: 433,
              w: 62,
              h: 47,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                // change color style
click_Color()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 113,
              y: 50,
              w: 66,
              h: 52,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                //switch Steps / Distance
click_switch_Step_Distance()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            //start of ignored block
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              let normal_fullAngle_second = 360;
              let normal_angle_second = 0 + normal_fullAngle_second*(second + (timeSensor.utc % 1000)/1000)/60;
              if (normal_analog_clock_pro_second_pointer_img) normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_second);

            };

            //end of ignored block
            function scale_call() {
              console.log('scale_call()');

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_ls_normal_step = 1 - progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_linear_scale
                  // initial parameters
                  let start_x_normal_step = 296;
                  let start_y_normal_step = 19;
                  let lenght_ls_normal_step = -112;
                  let line_width_ls_normal_step = 24;
                  let color_ls_normal_step = 0xFF000000;
                  
                  // calculated parameters
                  let start_x_normal_step_draw = start_x_normal_step;
                  let start_y_normal_step_draw = start_y_normal_step;
                  lenght_ls_normal_step = lenght_ls_normal_step * progress_ls_normal_step;
                  let lenght_ls_normal_step_draw = lenght_ls_normal_step;
                  let line_width_ls_normal_step_draw = line_width_ls_normal_step;
                  if (lenght_ls_normal_step < 0){
                    lenght_ls_normal_step_draw = -lenght_ls_normal_step;
                    start_x_normal_step_draw = start_x_normal_step - lenght_ls_normal_step_draw;
                  };
                  
                  normal_step_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_step_draw,
                    y: start_y_normal_step_draw,
                    w: lenght_ls_normal_step_draw,
                    h: line_width_ls_normal_step_draw,
                    color: color_ls_normal_step,
                  });
                };

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_cs_normal_battery = 1 - progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_battery * 100);
                  if (normal_battery_circle_scale) {
                    normal_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 240,
                      center_y: 240,
                      start_angle: 316,
                      end_angle: 223,
                      radius: 229,
                      line_width: 9,
                      corner_flag: 3,
                      color: 0xFF000000,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                time_update(true, true);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSecSmooth) {
                    let animDelay = 0;
                    let animRepeat = 1000/15;
                    normal_timerUpdateSecSmooth = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, false);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


                console.log('resume_call.js');
                // start resume_call.js

 check24h()
                // end resume_call.js

              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerUpdateSecSmooth) {
                  timer.stopTimer(normal_timerUpdateSecSmooth);
                  normal_timerUpdateSecSmooth = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
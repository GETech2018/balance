﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_dow_text_font = ''
        let normal_DOW_Array = ['ПНД', 'ВТР', 'СРД', 'ЧТВ', 'ПТН', 'СБТ', 'ВСК'];
        let normal_day_text_font = ''
        let normal_battery_icon_img = ''
        let normal_battery_current_text_font = ''
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_text_font = ''
        let normal_step_icon_img = ''
        let normal_step_current_text_font = ''
        let normal_digital_clock_img_time_hour = ''
        let normal_digital_clock_img_time_second = ''
        let normal_digital_clock_second_separator_img = ''
        let normal_digital_clock_img_time_minute = ''
        let idle_background_bg_img = ''
        let idle_digital_clock_img_time = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let Button_7 = ''
        let Button_8 = ''
        let Button_Switch_BG = ''

        let backgroundIndex = 0;
        let backgroundList = ['bg_1.png', 'bg_2.png', 'bg_3.png', 'bg_4.png'];
        let backgroundToastList = ['Фон %s', 'Фон %s', 'Фон %s', 'Фон %s'];
        const watchfaceId = hmApp.packageInfo().watchfaceId;
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            // FontName: GoogleSans-Medium.ttf; FontSize: 26; Cache: full
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 31,
              h: 31,
              text_size: 26,
              char_space: 0,
              line_space: 0,
              font: 'fonts/GoogleSans-Medium.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.RIGHT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: GoogleSans-Medium.ttf; FontSize: 28
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 430,
              h: 43,
              text_size: 28,
              char_space: 1,
              line_space: 0,
              font: 'fonts/GoogleSans-Medium.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            //#region SwitchBackground
            console.log('SwitchBackground');
            function switchBackground() {
              backgroundIndex++;
              if (backgroundIndex >= backgroundList.length) backgroundIndex = 0;
              hmFS.SysProSetInt(`backgroundIndex_${watchfaceId}`, backgroundIndex);
              let toastText = backgroundToastList[backgroundIndex].replace('%s', `${backgroundIndex + 1}`);
              if (toastText.length > 0) hmUI.showToast({text: toastText});
              normal_background_bg_img.setProperty(hmUI.prop.SRC, backgroundList[backgroundIndex]);
            };
            //#endregion

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function() {
              time_update(true);
            });

            normal_dow_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 144,
              y: 313,
              w: 104,
              h: 32,
              text_size: 26,
              char_space: 0,
              font: 'fonts/GoogleSans-Medium.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.RIGHT,
              // unit_string: ПНД, ВТР, СРД, ЧТВ, ПТН, СБТ, ВСК,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_day_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 254,
              y: 311,
              w: 42,
              h: 30,
              text_size: 28,
              char_space: 1,
              font: 'fonts/GoogleSans-Medium.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 322,
              y: 343,
              src: 'power.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 315,
              y: 383,
              w: 58,
              h: 30,
              text_size: 26,
              char_space: 1,
              font: 'fonts/GoogleSans-Medium.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              unit_type: 1,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 109,
              y: 316,
              src: 'heart.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 98,
              y: 359,
              w: 60,
              h: 30,
              text_size: 26,
              char_space: 1,
              font: 'fonts/GoogleSans-Medium.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 211,
              y: 359,
              src: 'step.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 193,
              y: 404,
              w: 76,
              h: 30,
              text_size: 26,
              char_space: 0,
              font: 'fonts/GoogleSans-Medium.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 21,
              hour_startY: 163,
              hour_array: ["time_h_00.png","time_h_01.png","time_h_02.png","time_h_03.png","time_h_04.png","time_h_05.png","time_h_06.png","time_h_07.png","time_h_08.png","time_h_09.png"],
              hour_zero: 1,
              hour_space: -2,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_second = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              second_startX: 293,
              second_startY: 226,
              second_array: ["time_m_00.png","time_m_01.png","time_m_02.png","time_m_03.png","time_m_04.png","time_m_05.png","time_m_06.png","time_m_07.png","time_m_08.png","time_m_09.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_second_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 287,
              y: 227,
              src: 'ten5.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 293,
              minute_startY: 154,
              minute_array: ["time_m_00.png","time_m_01.png","time_m_02.png","time_m_03.png","time_m_04.png","time_m_05.png","time_m_06.png","time_m_07.png","time_m_08.png","time_m_09.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg_aod.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 21,
              hour_startY: 163,
              hour_array: ["time_h_00.png","time_h_01.png","time_h_02.png","time_h_03.png","time_h_04.png","time_h_05.png","time_h_06.png","time_h_07.png","time_h_08.png","time_h_09.png"],
              hour_zero: 1,
              hour_space: -2,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 293,
              minute_startY: 154,
              minute_array: ["time_m_00.png","time_m_01.png","time_m_02.png","time_m_03.png","time_m_04.png","time_m_05.png","time_m_06.png","time_m_07.png","time_m_08.png","time_m_09.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 186,
              y: 361,
              w: 90,
              h: 90,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '1empty_icon.png',
              normal_src: '1empty_icon.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'activityAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 82,
              y: 313,
              w: 90,
              h: 90,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '1empty_icon.png',
              normal_src: '1empty_icon.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'heart_app_Screen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 295,
              y: 339,
              w: 90,
              h: 90,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '1empty_icon.png',
              normal_src: '1empty_icon.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'Settings_batteryManagerScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 160,
              y: 180,
              w: 100,
              h: 100,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '1empty_icon.png',
              normal_src: '1empty_icon.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'CountdownAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 35,
              y: 180,
              w: 100,
              h: 100,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '1empty_icon.png',
              normal_src: '1empty_icon.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PhoneHomeScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 323,
              y: 239,
              w: 100,
              h: 80,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '1empty_icon.png',
              normal_src: '1empty_icon.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'StopWatchScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_7 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 323,
              y: 157,
              w: 100,
              h: 80,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '1empty_icon.png',
              normal_src: '1empty_icon.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'AlarmInfoScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_8 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 189,
              y: 290,
              w: 100,
              h: 66,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '1empty_icon.png',
              normal_src: '1empty_icon.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            console.log('Watch_Face.SwitchBackground');
            // Button_Switch_BG = hmUI.createWidget(hmUI.widget.SwitchBackground, {
              // x: 90,
              // y: 84,
              // w: 300,
              // h: 60,
              // text: '',
              // color: 0xFFFF8C00,
              // text_size: 25,
              // press_src: '1empty_icon.png',
              // normal_src: '1empty_icon.png',
              // bg_list: bg_1|bg_2|bg_3|bg_4,
              // toast_list: Фон %s|Фон %s|Фон %s|Фон %s,
              // use_crown: False,
              // use_in_AOD: False,
              // vibro: False,
            // });

            Button_Switch_BG = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 90,
              y: 84,
              w: 300,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '1empty_icon.png',
              normal_src: '1empty_icon.png',
              click_func: (button_widget) => {
                switchBackground();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            let screenType = hmSetting.getScreenType();
            //#region time_update
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              console.log('day of week font');
              if (updateHour) {
                let normal_DOW_Str = normal_DOW_Array[timeSensor.week-1];
                normal_dow_text_font.setProperty(hmUI.prop.TEXT, normal_DOW_Str );
              };

              console.log('day font');
              if (updateHour) {
                let normal_dayStr = timeSensor.day.toString();
                normal_dayStr = normal_dayStr.padStart(2, '0');
                normal_day_text_font.setProperty(hmUI.prop.TEXT, normal_dayStr );
              };

            };

            //#endregion
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                time_update(true, true);

                //SwitchBackground
                if (hmFS.SysProGetInt(`backgroundIndex_${watchfaceId}`) === undefined) {
                  backgroundIndex = 0;
                  hmFS.SysProSetInt(`backgroundIndex_${watchfaceId}`, backgroundIndex);
                } else {
                  backgroundIndex = hmFS.SysProGetInt(`backgroundIndex_${watchfaceId}`);
                };
                if (screenType == hmSetting.screen_type.WATCHFACE && normal_background_bg_img) normal_background_bg_img.setProperty(hmUI.prop.SRC, backgroundList[backgroundIndex]);
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (()=>{
        //dynamic modify start

        const lang = DeviceRuntimeCore.HmUtils.getLanguage()
        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_calorie_pointer_progress_img_pointer = ''
        let normal_step_pointer_progress_img_pointer = ''
        let normal_battery_pointer_progress_img_pointer = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg_img = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let normal_stress_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
		
		let batteryInfo_click = ''
		
		const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
		const step = hmSensor.createSensor(hmSensor.id.STEP);
		const calorie = hmSensor.createSensor(hmSensor.id.CALORIE);
		
		let valueBattery = ''
        let valueStep = ''
		let valueCalorie = ''
		
		
		let btn_bezel = ''
        let bezel_num = 1
        let bezel_all = 6
     
        function click_Bezel() {
            if(bezel_num>=bezel_all) {bezel_num=1;}
            else { bezel_num=bezel_num+1;}
            hmUI.showToast({text: "<BackGround> " + parseInt(bezel_num) });
            normal_background_bg_img.setProperty(hmUI.prop.SRC, "bg_" + parseInt(bezel_num) + ".png");
        normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.MORE, {
                   hour_path: `h_${bezel_num}.png`,
                    hour_centerX: 240,
                    hour_centerY: 240,
                    hour_posX: 57,
                    hour_posY: 225,
                    show_level: hmUI.show_level.ONLY_NORMAL,
            } );
        normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.MORE, {
              minute_path: `m_${bezel_num}.png`,
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 57,
              minute_posY: 225,
              show_level: hmUI.show_level.ONLY_NORMAL,
              } );
               }


        //dynamic modify end
        const e = __$$hmAppManager$$__.currentApp;
        const o = e.current
          , {px: i} = (new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(e,o)),
        e.__globals__)
          , n = Logger.getLogger("watchface6");
        o.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 335,
              y: 327,
              src: 'bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 335,
              y: 125,
              src: 'alarms.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			let dned=["week_0.png","week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png"]
			if(lang=='ru-RU'){
				dned=["weekru_0.png","weekru_1.png","weekru_2.png","weekru_3.png","weekru_4.png","weekru_5.png","weekru_6.png"]
			}
            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 326,
              y: 190,
              week_en: dned,
              week_tc: ["week_0.png","week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png"],
              week_sc: ["week_0.png","week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			let dmonth=["month_0.png","month_1.png","month_2.png","month_3.png","month_4.png","month_5.png","month_6.png","month_7.png","month_8.png","month_9.png","month_10.png","month_11.png"]
			if(lang=='ru-RU'){
				dmonth=["monthru_0.png","monthru_1.png","monthru_2.png","monthru_3.png","monthru_4.png","monthru_5.png","monthru_6.png","monthru_7.png","monthru_8.png","monthru_9.png","monthru_10.png","monthru_11.png"]
			}
            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 326,
              month_startY: 273,
              month_sc_array: ["month_0.png","month_1.png","month_2.png","month_3.png","month_4.png","month_5.png","month_6.png","month_7.png","month_8.png","month_9.png","month_10.png","month_11.png"],
              month_tc_array: ["month_0.png","month_1.png","month_2.png","month_3.png","month_4.png","month_5.png","month_6.png","month_7.png","month_8.png","month_9.png","month_10.png","month_11.png"],
              month_en_array: dmonth,
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 326,
              day_startY: 220,
              day_sc_array: ["bigNum_0.png","bigNum_1.png","bigNum_2.png","bigNum_3.png","bigNum_4.png","bigNum_5.png","bigNum_6.png","bigNum_7.png","bigNum_8.png","bigNum_9.png"],
              day_tc_array: ["bigNum_0.png","bigNum_1.png","bigNum_2.png","bigNum_3.png","bigNum_4.png","bigNum_5.png","bigNum_6.png","bigNum_7.png","bigNum_8.png","bigNum_9.png"],
              day_en_array: ["bigNum_0.png","bigNum_1.png","bigNum_2.png","bigNum_3.png","bigNum_4.png","bigNum_5.png","bigNum_6.png","bigNum_7.png","bigNum_8.png","bigNum_9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'point_batt.png',
              center_x: 126,
              center_y: 240,
              x: 59,
              y: 60,
              start_angle: -117,
              end_angle: -65,
              invalid_visible: false,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'progress.png',
              center_x: 126,
              center_y: 240,
              x: 59,
              y: 60,
              start_angle: -224,
              end_angle: 42,
              invalid_visible: false,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'point_batt.png',
              center_x: 240,
              center_y: 330,
              x: 59,
              y: 60,
              start_angle: 73,
              end_angle: -73,
              invalid_visible: false,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'h_1.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 57,
              hour_posY: 225,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'm_1.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 57,
              minute_posY: 225,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 's_1.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 57,
              second_posY: 224,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'aods.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'h_1.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 57,
              hour_posY: 225,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'm_1.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 57,
              minute_posY: 225,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');
			
			function get_values (){
              valueBattery = battery.current; 
              valueStep = step.current;
		      valueCalorie = calorie.current;
          
            }

            btn_bezel = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 203,
              y: 203,
              text: '',
              w: 75,
              h: 75,
              normal_src: 'Empty.png',
              press_src: 'Empty.png',
              click_func: () => {
                  click_Bezel();
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btn_bezel.setProperty(hmUI.prop.VISIBLE, true);

            hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 313,
              y: 195, 
              text: '',
              w: 70, 
              h: 80, 
              normal_src: 'Empty.png',
              press_src: 'Empty.png',
               click_func: () => {
              hmApp.startApp({ url: 'ScheduleCalScreen', native: true });
              },
               longpress_func: () => {
              hmApp.startApp({ url: 'todoListScreen', native: true });
              },
                show_level: hmUI.show_level.ONLY_NORMAL,
            });

            batteryInfo_click = hmUI.createWidget(hmUI.widget.BUTTON, {
          x: 200,
          y: 305,
          w: 80,
          h: 80,
          text: '',
          normal_src: 'Empty.png',
          press_src: 'Empty.png',
          click_func: () => {
            get_values();
			hmUI.showToast({ text: 'Battery is ' + valueBattery + ' %' });
          },
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

            stepInfo_click = hmUI.createWidget(hmUI.widget.BUTTON, {
          x: 80,
          y: 195,
          w: 100,
          h: 100,
          text: '',
          normal_src: 'Empty.png',
          press_src: 'Empty.png',
          click_func: () => {
            get_values();
			hmUI.showToast({ text: 'Step is ' + valueStep + '' + '\n' + 'Calorie is ' + valueCalorie + '' });
          },
          show_level: hmUI.show_level.ONLY_NORMAL,
        });


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
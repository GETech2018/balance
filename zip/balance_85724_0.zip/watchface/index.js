﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_lock_img = ''
        let normal_system_dnd_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_distance_TextRotate = new Array(5);
        let normal_distance_TextRotate_ASCIIARRAY = new Array(10);
        let normal_distance_TextRotate_img_width = 15;
        let normal_distance_TextRotate_dot_width = 8;
        let normal_heart_rate_TextRotate = new Array(3);
        let normal_heart_rate_TextRotate_ASCIIARRAY = new Array(10);
        let normal_heart_rate_TextRotate_img_width = 15;
        let normal_calorie_TextRotate = new Array(4);
        let normal_calorie_TextRotate_ASCIIARRAY = new Array(10);
        let normal_calorie_TextRotate_img_width = 15;
        let normal_step_TextRotate = new Array(5);
        let normal_step_TextRotate_ASCIIARRAY = new Array(10);
        let normal_step_TextRotate_img_width = 15;
        let normal_battery_text_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_temperature_high_text_font = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_low_text_font = ''
        let normal_month_name_font = ''
        let normal_Month_Array = ['ENE', 'FEB', 'MAR', 'ABR', 'MAY', 'JUN', 'JUL', 'AGO', 'SEP', 'OCT', 'NOV', 'DIC', ];
        let normal_date_img_date_day = ''
        let normal_dow_text_font = ''
        let normal_DOW_Array = ['LUN', 'MAR', 'MIE', 'JUE', 'VIE', 'SAB', 'DOM'];
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_battery_text_text_img = ''
        let idle_month_name_font = ''
        let idle_Month_Array = ['ENE', 'FEB', 'MAR', 'ABR', 'MAY', 'JUN', 'JUL', 'AGO', 'SEP', 'OCT', 'NOV', 'DIC', ];
        let idle_date_img_date_day = ''
        let idle_dow_text_font = ''
        let idle_DOW_Array = ['LUN', 'MAR', 'MIE', 'JUE', 'VIE', 'SAB', 'DOM'];
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_minute_separator_img = ''
        let normal_battery_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            // FontName: Oswald-Medium.ttf; FontSize: 19
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 244,
              h: 38,
              text_size: 19,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Oswald-Medium.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: Oswald-Medium.ttf; FontSize: 52; Cache: full
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 62,
              h: 62,
              text_size: 52,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Oswald-Medium.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.NONE,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: '0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 270,
              y: 5,
              src: 'can11.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 138,
              y: 19,
              src: 'nom4.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 208,
              y: 2,
              src: 'bt14.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 327,
              y: 433,
              src: 'alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_distance_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 344,
              // y: 144,
              // font_array: ["b013.png","b014.png","b015.png","b016.png","b017.png","b018.png","b019.png","b020.png","b021.png","b022.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 5,
              // angle: -90,
              // dot_image: 'point.png',
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.DISTANCE,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_distance_TextRotate_ASCIIARRAY[0] = 'b013.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[1] = 'b014.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[2] = 'b015.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[3] = 'b016.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[4] = 'b017.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[5] = 'b018.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[6] = 'b019.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[7] = 'b020.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[8] = 'b021.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[9] = 'b022.png';  // set of images with numbers

            //#region TextRotate
            for (let i = 0; i < 5; i++) {
              normal_distance_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 344,
                center_y: 144,
                pos_x: 344,
                pos_y: 144,
                angle: -90,
                src: 'b013.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_distance_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            const mileageUnit = hmSetting.getMileageUnit();            //#endregion
            
            const distance = hmSensor.createSensor(hmSensor.id.DISTANCE);
            distance.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });
            
            function toDegree (radian) {
              return radian * (180 / Math.PI);
            };

            // normal_heart_rate_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 136,
              // y: 144,
              // font_array: ["0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 5,
              // angle: -90,
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_heart_rate_TextRotate_ASCIIARRAY[0] = '0013.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[1] = '0014.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[2] = '0015.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[3] = '0016.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[4] = '0017.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[5] = '0018.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[6] = '0019.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[7] = '0020.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[8] = '0021.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[9] = '0022.png';  // set of images with numbers

            //#region TextRotate
            for (let i = 0; i < 3; i++) {
              normal_heart_rate_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 136,
                center_y: 144,
                pos_x: 136,
                pos_y: 144,
                angle: -90,
                src: '0013.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_heart_rate_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //#endregion
            
            const heart_rate = hmSensor.createSensor(hmSensor.id.HEART);
            heart_rate.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            // normal_calorie_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 271,
              // y: 144,
              // font_array: ["b013.png","b014.png","b015.png","b016.png","b017.png","b018.png","b019.png","b020.png","b021.png","b022.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 5,
              // angle: -90,
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_calorie_TextRotate_ASCIIARRAY[0] = 'b013.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[1] = 'b014.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[2] = 'b015.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[3] = 'b016.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[4] = 'b017.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[5] = 'b018.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[6] = 'b019.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[7] = 'b020.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[8] = 'b021.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[9] = 'b022.png';  // set of images with numbers

            //#region TextRotate
            for (let i = 0; i < 4; i++) {
              normal_calorie_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 271,
                center_y: 144,
                pos_x: 271,
                pos_y: 144,
                angle: -90,
                src: 'b013.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_calorie_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //#endregion
            
            const calorie = hmSensor.createSensor(hmSensor.id.CALORIE);
            calorie.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            // normal_step_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 207,
              // y: 144,
              // font_array: ["0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 5,
              // angle: -90,
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_step_TextRotate_ASCIIARRAY[0] = '0013.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[1] = '0014.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[2] = '0015.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[3] = '0016.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[4] = '0017.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[5] = '0018.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[6] = '0019.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[7] = '0020.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[8] = '0021.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[9] = '0022.png';  // set of images with numbers

            //#region TextRotate
            for (let i = 0; i < 5; i++) {
              normal_step_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 207,
                center_y: 144,
                pos_x: 207,
                pos_y: 144,
                angle: -90,
                src: '0013.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_step_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //#endregion
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 395,
              y: 159,
              font_array: ["0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png"],
              padding: false,
              h_space: 0,
              unit_sc: '0053.png',
              unit_tc: '0053.png',
              unit_en: '0053.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 37,
              y: 160,
              font_array: ["0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png"],
              padding: false,
              h_space: 0,
              unit_sc: '0034.png',
              unit_tc: '0034.png',
              unit_en: '0034.png',
              negative_image: '0033.png',
              invalid_image: '0025.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 76,
              y: 173,
              w: 52,
              h: 31,
              text_size: 19,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Oswald-Medium.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 36,
              y: 69,
              image_array: ["cl67.png","cl68.png","cl69.png","cl70.png","cl71.png","cl72.png","cl73.png","cl74.png","cl75.png","cl76.png","cl77.png","cl78.png","cl79.png","cl80.png","cl81.png","cl82.png","cl83.png","cl84.png","cl85.png","cl86.png","cl87.png","cl88.png","cl89.png","cl90.png","cl91.png","cl92.png","cl93.png","cl94.png","cl95.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 1,
              y: 173,
              w: 52,
              h: 31,
              text_size: 19,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Oswald-Medium.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function() {
              time_update(true);
            });

            normal_month_name_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 38,
              y: 313,
              w: 103,
              h: 72,
              text_size: 52,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Oswald-Medium.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              // unit_string: ENE, FEB, MAR, ABR, MAY, JUN, JUL, AGO, SEP, OCT, NOV, DIC,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 71,
              day_startY: 287,
              day_sc_array: ["0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png"],
              day_tc_array: ["0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png"],
              day_en_array: ["0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_dow_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 38,
              y: 216,
              w: 103,
              h: 72,
              text_size: 52,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Oswald-Medium.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              // unit_string: LUN, MAR, MIE, JUE, VIE, SAB, DOM,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 438,
              am_y: 240,
              am_sc_path: 'H1.png',
              am_en_path: 'H1.png',
              pm_x: 438,
              pm_y: 240,
              pm_sc_path: 'H2.png',
              pm_en_path: 'H2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 163,
              hour_startY: 237,
              hour_array: ["mb0.png","mb1.png","mb2.png","mb3.png","mb4.png","mb5.png","mb6.png","mb7.png","mb8.png","mb9.png"],
              hour_zero: 1,
              hour_space: 16,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 301,
              minute_startY: 237,
              minute_array: ["mbl0.png","mbl1.png","mbl2.png","mbl3.png","mbl4.png","mbl5.png","mbl6.png","mbl7.png","mbl8.png","mbl9.png"],
              minute_zero: 1,
              minute_space: 16,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 437,
              second_startY: 283,
              second_array: ["0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 227,
              y: 0,
              src: 'bt14.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 228,
              y: 403,
              src: 'alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 209,
              y: 443,
              font_array: ["0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png"],
              padding: false,
              h_space: 0,
              unit_sc: '0053.png',
              unit_tc: '0053.png',
              unit_en: '0053.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_month_name_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 38,
              y: 313,
              w: 103,
              h: 72,
              text_size: 52,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Oswald-Medium.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              // unit_string: ENE, FEB, MAR, ABR, MAY, JUN, JUL, AGO, SEP, OCT, NOV, DIC,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 71,
              day_startY: 287,
              day_sc_array: ["0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png"],
              day_tc_array: ["0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png"],
              day_en_array: ["0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_dow_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 38,
              y: 216,
              w: 103,
              h: 72,
              text_size: 52,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Oswald-Medium.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              // unit_string: LUN, MAR, MIE, JUE, VIE, SAB, DOM,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 438,
              am_y: 240,
              am_sc_path: 'H1.png',
              am_en_path: 'H1.png',
              pm_x: 438,
              pm_y: 240,
              pm_sc_path: 'H2.png',
              pm_en_path: 'H2.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 163,
              hour_startY: 237,
              hour_array: ["mb0.png","mb1.png","mb2.png","mb3.png","mb4.png","mb5.png","mb6.png","mb7.png","mb8.png","mb9.png"],
              hour_zero: 1,
              hour_space: 16,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 301,
              minute_startY: 237,
              minute_array: ["mb0.png","mb1.png","mb2.png","mb3.png","mb4.png","mb5.png","mb6.png","mb7.png","mb8.png","mb9.png"],
              minute_zero: 1,
              minute_space: 16,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_minute_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 279,
              y: 249,
              src: 'Puntos.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 0,
              // disconneсnt_toast_text: BT DESC.,
              // conneсnt_vibrate_type: 0,
              // conneсnt_toast_text: BT CONEC.,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              console.log('checkConnection()');
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  hmUI.showToast({text: "BT DESC."});
                  vibro(0);
                }
                if(status) {
                  hmUI.showToast({text: "BT CONEC."});
                  vibro(0);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              if (scene != 1) timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function
            console.log('Watch_Face.Shortcuts');

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 398,
              y: 82,
              w: 72,
              h: 115,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 13,
              y: 81,
              w: 103,
              h: 62,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 325,
              y: 430,
              w: 41,
              h: 41,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 16,
              y: 150,
              w: 98,
              h: 52,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 260,
              y: 59,
              w: 52,
              h: 134,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 128,
              y: 84,
              w: 52,
              h: 103,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 196,
              y: 42,
              w: 52,
              h: 155,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 128,
              y: 431,
              w: 62,
              h: 41,
              text: '',
              color: 0xFFFF8C00,
              text_size: 26,
              press_src: 'transparent.png',
              normal_src: 'transparent.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PhoneHomeScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 197,
              y: 431,
              w: 52,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 26,
              press_src: 'transparent.png',
              normal_src: 'transparent.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'FindPhoneScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 259,
              y: 431,
              w: 57,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 26,
              press_src: 'transparent.png',
              normal_src: 'transparent.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'AppListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 15,
              y: 231,
              w: 134,
              h: 155,
              text: '',
              color: 0xFFFF8C00,
              text_size: 26,
              press_src: 'transparent.png',
              normal_src: 'transparent.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 166,
              y: 231,
              w: 265,
              h: 160,
              text: '',
              color: 0xFFFF8C00,
              text_size: 26,
              press_src: 'transparent.png',
              normal_src: 'transparent.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'WorldClockScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            let screenType = hmSetting.getScreenType();
            //#region time_update
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              console.log('month font');
              if (updateHour) {
                let normal_Month_Str = normal_Month_Array[timeSensor.month-1];
                normal_month_name_font.setProperty(hmUI.prop.TEXT, normal_Month_Str );
              };

              console.log('day of week font');
              if (updateHour) {
                let normal_DOW_Str = normal_DOW_Array[timeSensor.week-1];
                normal_dow_text_font.setProperty(hmUI.prop.TEXT, normal_DOW_Str );
              };

              console.log('month font');
              if (updateHour) {
                let idle_Month_Str = idle_Month_Array[timeSensor.month-1];
                idle_month_name_font.setProperty(hmUI.prop.TEXT, idle_Month_Str );
              };

              console.log('day of week font');
              if (updateHour) {
                let idle_DOW_Str = idle_DOW_Array[timeSensor.week-1];
                idle_dow_text_font.setProperty(hmUI.prop.TEXT, idle_DOW_Str );
              };

            };

            //#endregion
            //#region text_update
            function text_update() {
              console.log('text_update()');

              console.log('update text rotate DISTANCE');
              let distanceCurrent = distance.current;
              let normal_distance_rotate_string = (distanceCurrent / 1000).toFixed(2);
              if (mileageUnit == 1) normal_distance_rotate_string = (0.621371 * distanceCurrent / 1000).toFixed(2);

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  normal_distance_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (distanceCurrent != null && distanceCurrent != undefined && isFinite(distanceCurrent) && normal_distance_rotate_string.length > 0 && normal_distance_rotate_string.length <= 5) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of normal_distance_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_distance_TextRotate[index].setProperty(hmUI.prop.POS_X, 344 + img_offset);
                      normal_distance_TextRotate[index].setProperty(hmUI.prop.SRC, normal_distance_TextRotate_ASCIIARRAY[charCode]);
                      normal_distance_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_distance_TextRotate_img_width + 5;
                      index++;
                    }  // end if digit
                    else { 
                      normal_distance_TextRotate[index].setProperty(hmUI.prop.POS_X, 344 + img_offset);
                      normal_distance_TextRotate[index].setProperty(hmUI.prop.SRC, 'point.png');
                      normal_distance_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_distance_TextRotate_dot_width + 5;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate heart_rate_HEART');
              let valueHeartRate = heart_rate.last;
              let normal_heart_rate_rotate_string = parseInt(valueHeartRate).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  normal_heart_rate_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueHeartRate != null && valueHeartRate != undefined && isFinite(valueHeartRate) && normal_heart_rate_rotate_string.length > 0 && normal_heart_rate_rotate_string.length <= 3) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of normal_heart_rate_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_heart_rate_TextRotate[index].setProperty(hmUI.prop.POS_X, 136 + img_offset);
                      normal_heart_rate_TextRotate[index].setProperty(hmUI.prop.SRC, normal_heart_rate_TextRotate_ASCIIARRAY[charCode]);
                      normal_heart_rate_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_heart_rate_TextRotate_img_width + 5;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate calorie_CALORIE');
              let valueCalories = calorie.current;
              let normal_calorie_rotate_string = parseInt(valueCalories).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 4; i++) {  // hide all symbols
                  normal_calorie_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueCalories != null && valueCalories != undefined && isFinite(valueCalories) && normal_calorie_rotate_string.length > 0 && normal_calorie_rotate_string.length <= 4) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of normal_calorie_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 4) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_calorie_TextRotate[index].setProperty(hmUI.prop.POS_X, 271 + img_offset);
                      normal_calorie_TextRotate[index].setProperty(hmUI.prop.SRC, normal_calorie_TextRotate_ASCIIARRAY[charCode]);
                      normal_calorie_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_calorie_TextRotate_img_width + 5;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate step_STEP');
              let valueStep = step.current;
              let normal_step_rotate_string = parseInt(valueStep).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  normal_step_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueStep != null && valueStep != undefined && isFinite(valueStep) && normal_step_rotate_string.length > 0 && normal_step_rotate_string.length <= 5) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of normal_step_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_step_TextRotate[index].setProperty(hmUI.prop.POS_X, 207 + img_offset);
                      normal_step_TextRotate[index].setProperty(hmUI.prop.SRC, normal_step_TextRotate_ASCIIARRAY[charCode]);
                      normal_step_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_step_TextRotate_img_width + 5;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

            };

            //#endregion
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                time_update(true, true);
                text_update();
                checkConnection();
                stopVibro();

              }),
              pause_call: (function () {
                console.log('pause_call()');
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg = ''
        let normal_battery_circle_scale = ''
        let normal_battery_icon_img = ''
        let normal_battery_current_text_font = ''
        let normal_battery_pointer_progress_img_pointer = ''
        let normal_altimeter_icon_img = ''
        let normal_altitude_target_text_font = ''
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_text_font = ''
        let normal_sun_icon_img = ''
        let normal_sun_high_text_font = ''
        let normal_sun_low_text_font = ''
        let normal_temperature_icon_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_high_text_font = ''
        let normal_temperature_low_text_font = ''
        let normal_temperature_current_text_font = ''
        let normal_month_name_font = ''
        let normal_Month_Array = ['GENNAIO', 'FEBBRAIO', 'MARZO', 'APRILE', 'MAGGIO', 'GIUGNO', 'LUGLIO', 'AGOSTO', 'SETTEMBRE', 'OTTOBRE', 'NOVEMBRE', 'DICEMBRE', ];
        let normal_dow_text_font = ''
        let normal_DOW_Array = ['LUN', 'MAR', 'MER', 'GIO', 'VEN', 'SAB', 'DOM'];
        let normal_day_text_font = ''
        let normal_step_linear_scale = ''
        let normal_step_current_text_font = ''
        let normal_image_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg = ''
        let idle_battery_circle_scale = ''
        let idle_battery_icon_img = ''
        let idle_battery_current_text_font = ''
        let idle_battery_pointer_progress_img_pointer = ''
        let idle_altimeter_icon_img = ''
        let idle_altitude_target_text_font = ''
        let idle_heart_rate_icon_img = ''
        let idle_heart_rate_text_font = ''
        let idle_sun_icon_img = ''
        let idle_sun_high_text_font = ''
        let idle_sun_low_text_font = ''
        let idle_temperature_icon_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_temperature_high_text_font = ''
        let idle_temperature_low_text_font = ''
        let idle_temperature_current_text_font = ''
        let idle_month_name_font = ''
        let idle_Month_Array = ['GENNAIO', 'FEBBRAIO', 'MARZO', 'APRILE', 'MAGGIO', 'GIUGNO', 'LUGLIO', 'AGOSTO', 'SETTEMBRE', 'OTTOBRE', 'NOVEMBRE', 'DICEMBRE', ];
        let idle_dow_text_font = ''
        let idle_DOW_Array = ['LUN', 'MAR', 'MER', 'GIO', 'VEN', 'SAB', 'DOM'];
        let idle_day_text_font = ''
        let idle_step_linear_scale = ''
        let idle_step_current_text_font = ''
        let idle_image_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_digital_clock_img_time = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            // FontName: +Casio Logo - Copy.ttf; FontSize: 28
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 507,
              h: 36,
              text_size: 28,
              char_space: 1,
              line_space: 0,
              font: 'fonts/+Casio Logo - Copy.ttf',
              color: 0xFF000000,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: +Casio Logo - Copy.ttf; FontSize: 30
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 574,
              h: 38,
              text_size: 30,
              char_space: 2,
              line_space: 0,
              font: 'fonts/+Casio Logo - Copy.ttf',
              color: 0xFF000000,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: BabelSans-Bold.ttf; FontSize: 30
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 391,
              h: 40,
              text_size: 30,
              char_space: 2,
              line_space: 0,
              font: 'fonts/BabelSans-Bold.ttf',
              color: 0xFF000000,
              align_h: hmUI.align.RIGHT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: +Casio Logo - Copy.ttf; FontSize: 33
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 567,
              h: 43,
              text_size: 33,
              char_space: 0,
              line_space: 0,
              font: 'fonts/+Casio Logo - Copy.ttf',
              color: 0xFF000000,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: BabelSans-Bold.ttf; FontSize: 20; Cache: full
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 24,
              h: 24,
              text_size: 20,
              char_space: 1,
              line_space: 0,
              font: 'fonts/BabelSans-Bold.ttf',
              color: 0xFF000000,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.NONE,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: +Casio Logo - Copy.ttf; FontSize: 30; Cache: full
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 36,
              h: 36,
              text_size: 30,
              char_space: 1,
              line_space: 0,
              font: 'fonts/+Casio Logo - Copy.ttf',
              color: 0xFF000000,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.NONE,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: +Casio Logo - Copy.ttf; FontSize: 29
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 496,
              h: 37,
              text_size: 29,
              char_space: 0,
              line_space: 0,
              font: 'fonts/+Casio Logo - Copy.ttf',
              color: 0xFF000000,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFF808080',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 240,
              // center_y: 240,
              // start_angle: 208,
              // end_angle: 332,
              // radius: 203,
              // line_width: 14,
              // line_cap: Rounded,
              // color: 0xFF000000,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            let screenType = hmSetting.getScreenType();
            normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 240,
              center_y: 240,
              start_angle: 208,
              end_angle: 332,
              radius: 196,
              line_width: 14,
              corner_flag: 0,
              color: 0xFF000000,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'LOG2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 333,
              y: 370,
              w: 150,
              h: 40,
              text_size: 28,
              char_space: 1,
              line_space: 0,
              font: 'fonts/+Casio Logo - Copy.ttf',
              color: 0xFF000000,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              padding: true,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'ind-batteria.png',
              center_x: 240,
              center_y: 240,
              x: 30,
              y: 240,
              start_angle: 210,
              end_angle: 330,
              invalid_visible: false,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 337,
              y: 296,
              src: 'ico-altezza.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altitude_target_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 362,
              y: 289,
              w: 100,
              h: 40,
              text_size: 30,
              char_space: 2,
              line_space: 0,
              font: 'fonts/+Casio Logo - Copy.ttf',
              color: 0xFF000000,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.ALTITUDE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 335,
              y: 333,
              src: 'ico-cuore.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 371,
              y: 328,
              w: 100,
              h: 40,
              text_size: 30,
              char_space: 0,
              line_space: 0,
              font: 'fonts/+Casio Logo - Copy.ttf',
              color: 0xFF000000,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              padding: true,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 179,
              y: 38,
              src: 'ico-albatra.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 207,
              y: 23,
              w: 150,
              h: 30,
              text_size: 30,
              char_space: 0,
              line_space: 0,
              font: 'fonts/+Casio Logo - Copy.ttf',
              color: 0xFF000000,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 207,
              y: 50,
              w: 150,
              h: 30,
              text_size: 30,
              char_space: 0,
              line_space: 0,
              font: 'fonts/+Casio Logo - Copy.ttf',
              color: 0xFF000000,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 390,
              y: 164,
              src: 'ico-temp.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 349,
              y: 66,
              image_array: ["w_0.png","w_1.png","w_2.png","w_3.png","w_4.png","w_5.png","w_6.png","w_7.png","w_8.png","w_9.png","w_10.png","w_11.png","w_12.png","w_13.png","w_14.png","w_15.png","w_16.png","w_17.png","w_18.png","w_19.png","w_20.png","w_21.png","w_22.png","w_23.png","w_24.png","w_25.png","w_26.png","w_27.png","w_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 370,
              y: 163,
              w: 100,
              h: 30,
              text_size: 30,
              char_space: 2,
              line_space: 0,
              font: 'fonts/BabelSans-Bold.ttf',
              color: 0xFF000000,
              align_h: hmUI.align.RIGHT,
              align_v: hmUI.align.TOP,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 337,
              y: 163,
              w: 100,
              h: 30,
              text_size: 30,
              char_space: 2,
              line_space: 0,
              font: 'fonts/BabelSans-Bold.ttf',
              color: 0xFF000000,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 341,
              y: 125,
              w: 100,
              h: 40,
              text_size: 33,
              char_space: 0,
              line_space: 0,
              font: 'fonts/+Casio Logo - Copy.ttf',
              color: 0xFF000000,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function() {
              time_update(true);
            });

            normal_month_name_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 165,
              y: 436,
              w: 150,
              h: 30,
              text_size: 20,
              char_space: 1,
              line_space: 0,
              font: 'fonts/BabelSans-Bold.ttf',
              color: 0xFF000000,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              // unit_string: GENNAIO,FEBBRAIO,MARZO,APRILE,MAGGIO,GIUGNO,LUGLIO,AGOSTO,SETTEMBRE,OTTOBRE,NOVEMBRE,DICEMBRE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_dow_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 229,
              y: 406,
              w: 100,
              h: 30,
              text_size: 30,
              char_space: 1,
              line_space: 0,
              font: 'fonts/+Casio Logo - Copy.ttf',
              color: 0xFF000000,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              // unit_string: LUN,MAR,MER,GIO,VEN,SAB,DOM,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_day_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 182,
              y: 406,
              w: 100,
              h: 40,
              text_size: 30,
              char_space: 0,
              line_space: 0,
              font: 'fonts/+Casio Logo - Copy.ttf',
              color: 0xFF000000,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (screenType != hmSetting.screen_type.AOD) {
              normal_step_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // normal_step_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 338,
              // start_y: 257,
              // color: 0xFF000000,
              // lenght: 135,
              // line_width: 17,
              // line_cap: Rounded,
              // vertical: False,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_step_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 339,
              y: 223,
              w: 130,
              h: 40,
              text_size: 33,
              char_space: 1,
              line_space: 0,
              font: 'fonts/+Casio Logo - Copy.ttf',
              color: 0xFF000000,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              padding: true,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'LOG3.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 100,
              y: 223,
              src: 'ico-blt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 338,
              y: 409,
              src: 'ico-alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 170,
              hour_startY: 89,
              hour_array: ["big-00.png","big-01.png","big-02.png","big-03.png","big-04.png","big-05.png","big-06.png","big-07.png","big-08.png","big-09.png"],
              hour_zero: 1,
              hour_space: 6,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 170,
              minute_startY: 193,
              minute_array: ["big-00.png","big-01.png","big-02.png","big-03.png","big-04.png","big-05.png","big-06.png","big-07.png","big-08.png","big-09.png"],
              minute_zero: 1,
              minute_space: 6,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 170,
              second_startY: 298,
              second_array: ["bigs-00.png","bigs-01.png","bigs-02.png","bigs-03.png","bigs-04.png","bigs-05.png","bigs-06.png","bigs-07.png","bigs-08.png","bigs-09.png"],
              second_zero: 1,
              second_space: 6,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFF808080',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 240,
              // center_y: 240,
              // start_angle: 208,
              // end_angle: 332,
              // radius: 203,
              // line_width: 14,
              // line_cap: Rounded,
              // color: 0xFF000000,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 240,
              center_y: 240,
              start_angle: 208,
              end_angle: 332,
              radius: 196,
              line_width: 14,
              corner_flag: 0,
              color: 0xFF000000,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'LOG2.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 333,
              y: 368,
              w: 150,
              h: 30,
              text_size: 29,
              char_space: 0,
              line_space: 0,
              font: 'fonts/+Casio Logo - Copy.ttf',
              color: 0xFF000000,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              padding: true,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'ind-batteria.png',
              center_x: 240,
              center_y: 240,
              x: 30,
              y: 240,
              start_angle: 210,
              end_angle: 330,
              invalid_visible: false,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_altimeter_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 337,
              y: 296,
              src: 'ico-altezza.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_altitude_target_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 362,
              y: 289,
              w: 100,
              h: 40,
              text_size: 30,
              char_space: 2,
              line_space: 0,
              font: 'fonts/+Casio Logo - Copy.ttf',
              color: 0xFF000000,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.ALTITUDE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 335,
              y: 333,
              src: 'ico-cuore.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 371,
              y: 328,
              w: 100,
              h: 40,
              text_size: 30,
              char_space: 0,
              line_space: 0,
              font: 'fonts/+Casio Logo - Copy.ttf',
              color: 0xFF000000,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              padding: true,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_sun_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 179,
              y: 38,
              src: 'ico-albatra.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_sun_high_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 207,
              y: 23,
              w: 150,
              h: 30,
              text_size: 30,
              char_space: 0,
              line_space: 0,
              font: 'fonts/+Casio Logo - Copy.ttf',
              color: 0xFF000000,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_sun_low_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 207,
              y: 50,
              w: 150,
              h: 30,
              text_size: 30,
              char_space: 0,
              line_space: 0,
              font: 'fonts/+Casio Logo - Copy.ttf',
              color: 0xFF000000,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 390,
              y: 164,
              src: 'ico-temp.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 349,
              y: 66,
              image_array: ["w_0.png","w_1.png","w_2.png","w_3.png","w_4.png","w_5.png","w_6.png","w_7.png","w_8.png","w_9.png","w_10.png","w_11.png","w_12.png","w_13.png","w_14.png","w_15.png","w_16.png","w_17.png","w_18.png","w_19.png","w_20.png","w_21.png","w_22.png","w_23.png","w_24.png","w_25.png","w_26.png","w_27.png","w_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_high_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 370,
              y: 164,
              w: 100,
              h: 30,
              text_size: 30,
              char_space: 2,
              line_space: 0,
              font: 'fonts/BabelSans-Bold.ttf',
              color: 0xFF000000,
              align_h: hmUI.align.RIGHT,
              align_v: hmUI.align.TOP,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_low_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 337,
              y: 163,
              w: 100,
              h: 30,
              text_size: 30,
              char_space: 2,
              line_space: 0,
              font: 'fonts/BabelSans-Bold.ttf',
              color: 0xFF000000,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 341,
              y: 125,
              w: 100,
              h: 40,
              text_size: 33,
              char_space: 0,
              line_space: 0,
              font: 'fonts/+Casio Logo - Copy.ttf',
              color: 0xFF000000,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_month_name_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 165,
              y: 436,
              w: 150,
              h: 30,
              text_size: 20,
              char_space: 1,
              line_space: 0,
              font: 'fonts/BabelSans-Bold.ttf',
              color: 0xFF000000,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              // unit_string: GENNAIO,FEBBRAIO,MARZO,APRILE,MAGGIO,GIUGNO,LUGLIO,AGOSTO,SETTEMBRE,OTTOBRE,NOVEMBRE,DICEMBRE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_dow_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 229,
              y: 406,
              w: 100,
              h: 30,
              text_size: 30,
              char_space: 1,
              line_space: 0,
              font: 'fonts/+Casio Logo - Copy.ttf',
              color: 0xFF000000,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              // unit_string: LUN,MAR,MER,GIO,VEN,SAB,DOM,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_day_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 182,
              y: 406,
              w: 100,
              h: 40,
              text_size: 30,
              char_space: 0,
              line_space: 0,
              font: 'fonts/+Casio Logo - Copy.ttf',
              color: 0xFF000000,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              // padding: true,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            if (screenType == hmSetting.screen_type.AOD) {
              idle_step_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // idle_step_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 338,
              // start_y: 257,
              // color: 0xFF000000,
              // lenght: 135,
              // line_width: 17,
              // line_cap: Flat,
              // vertical: False,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_step_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 339,
              y: 223,
              w: 130,
              h: 40,
              text_size: 33,
              char_space: 1,
              line_space: 0,
              font: 'fonts/+Casio Logo - Copy.ttf',
              color: 0xFF000000,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              padding: true,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'LOG3.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 100,
              y: 223,
              src: 'ico-blt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 338,
              y: 409,
              src: 'ico-alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 170,
              hour_startY: 89,
              hour_array: ["big-00.png","big-01.png","big-02.png","big-03.png","big-04.png","big-05.png","big-06.png","big-07.png","big-08.png","big-09.png"],
              hour_zero: 1,
              hour_space: 6,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 170,
              minute_startY: 193,
              minute_array: ["big-00.png","big-01.png","big-02.png","big-03.png","big-04.png","big-05.png","big-06.png","big-07.png","big-08.png","big-09.png"],
              minute_zero: 1,
              minute_space: 6,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 170,
              second_startY: 298,
              second_array: ["bigs-00.png","bigs-01.png","bigs-02.png","bigs-03.png","bigs-04.png","bigs-05.png","bigs-06.png","bigs-07.png","bigs-08.png","bigs-09.png"],
              second_zero: 1,
              second_space: 6,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 80,
              y: 140,
              w: 80,
              h: 80,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'NULL.png',
              normal_src: 'NULL.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'AppListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 80,
              y: 261,
              w: 80,
              h: 80,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'NULL.png',
              normal_src: 'NULL.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'SportListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 200,
              y: 400,
              w: 80,
              h: 80,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'NULL.png',
              normal_src: 'NULL.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            //start of ignored block
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              console.log('month font');
              if (updateHour) {
                let normal_Month_Str = normal_Month_Array[timeSensor.month-1];
                normal_month_name_font.setProperty(hmUI.prop.TEXT, normal_Month_Str );
              };

              console.log('day of week font');
              if (updateHour) {
                let normal_DOW_Str = normal_DOW_Array[timeSensor.week-1];
                normal_dow_text_font.setProperty(hmUI.prop.TEXT, normal_DOW_Str );
              };

              console.log('day font');
              if (updateHour) {
                let normal_dayStr = timeSensor.day.toString();
                normal_dayStr = normal_dayStr.padStart(2, '0');
                normal_day_text_font.setProperty(hmUI.prop.TEXT, normal_dayStr );
              };

              console.log('month font');
              if (updateHour) {
                let idle_Month_Str = idle_Month_Array[timeSensor.month-1];
                idle_month_name_font.setProperty(hmUI.prop.TEXT, idle_Month_Str );
              };

              console.log('day of week font');
              if (updateHour) {
                let idle_DOW_Str = idle_DOW_Array[timeSensor.week-1];
                idle_dow_text_font.setProperty(hmUI.prop.TEXT, idle_DOW_Str );
              };

              console.log('day font');
              if (updateHour) {
                let idle_dayStr = timeSensor.day.toString();
                idle_dayStr = idle_dayStr.padStart(2, '0');
                idle_day_text_font.setProperty(hmUI.prop.TEXT, idle_dayStr );
              };

            };

            //end of ignored block
            function scale_call() {
              console.log('scale_call()');

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_cs_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_battery * 100);
                  if (normal_battery_circle_scale) {
                    normal_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 240,
                      center_y: 240,
                      start_angle: 208,
                      end_angle: 332,
                      radius: 196,
                      line_width: 14,
                      corner_flag: 0,
                      color: 0xFF000000,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_ls_normal_step = progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_linear_scale
                  // initial parameters
                  let start_x_normal_step = 338;
                  let start_y_normal_step = 257;
                  let lenght_ls_normal_step = 135;
                  let line_width_ls_normal_step = 17;
                  let color_ls_normal_step = 0xFF000000;
                  
                  // calculated parameters
                  let start_x_normal_step_draw = start_x_normal_step;
                  let start_y_normal_step_draw = start_y_normal_step;
                  lenght_ls_normal_step = lenght_ls_normal_step * progress_ls_normal_step;
                  let lenght_ls_normal_step_draw = lenght_ls_normal_step;
                  let line_width_ls_normal_step_draw = line_width_ls_normal_step;
                  if (lenght_ls_normal_step < 0){
                    lenght_ls_normal_step_draw = -lenght_ls_normal_step;
                    start_x_normal_step_draw = start_x_normal_step - lenght_ls_normal_step_draw;
                  };
                  
                  normal_step_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_step_draw,
                    y: start_y_normal_step_draw,
                    w: lenght_ls_normal_step_draw,
                    h: line_width_ls_normal_step_draw,
                    radius: 8,
                    color: color_ls_normal_step,
                  });
                };

                console.log('update scales BATTERY');
                let progress_cs_idle_battery = progressBattery;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_battery_circle_scale_circle_scale
                  let level = Math.round(progress_cs_idle_battery * 100);
                  if (idle_battery_circle_scale) {
                    idle_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 240,
                      center_y: 240,
                      start_angle: 208,
                      end_angle: 332,
                      radius: 196,
                      line_width: 14,
                      corner_flag: 0,
                      color: 0xFF000000,
                      show_level: hmUI.show_level.ONLY_AOD,
                      level: level,
                    });
                  };
                };

                console.log('update scales STEP');
                let progress_ls_idle_step = progressStep;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_step_linear_scale
                  // initial parameters
                  let start_x_idle_step = 338;
                  let start_y_idle_step = 257;
                  let lenght_ls_idle_step = 135;
                  let line_width_ls_idle_step = 17;
                  let color_ls_idle_step = 0xFF000000;
                  
                  // calculated parameters
                  let start_x_idle_step_draw = start_x_idle_step;
                  let start_y_idle_step_draw = start_y_idle_step;
                  lenght_ls_idle_step = lenght_ls_idle_step * progress_ls_idle_step;
                  let lenght_ls_idle_step_draw = lenght_ls_idle_step;
                  let line_width_ls_idle_step_draw = line_width_ls_idle_step;
                  if (lenght_ls_idle_step < 0){
                    lenght_ls_idle_step_draw = -lenght_ls_idle_step;
                    start_x_idle_step_draw = start_x_idle_step - lenght_ls_idle_step_draw;
                  };
                  
                  idle_step_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_idle_step_draw,
                    y: start_y_idle_step_draw,
                    w: lenght_ls_idle_step_draw,
                    h: line_width_ls_idle_step_draw,
                    color: color_ls_idle_step,
                  });
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                time_update(true, true);
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg = ''
        let normal_stress_icon_img = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_battery_icon_img = ''
        let normal_battery_text_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_distance_text_separator_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_text_separator_img = ''
        let normal_calorie_current_text_img = ''
        let normal_calorie_current_separator_img = ''
        let normal_digital_clock_img_time_minute = ''
        let normal_digital_clock_img_time_second = ''
        let normal_digital_clock_second_separator_img = ''
        let normal_digital_clock_img_time_hour = ''
        let normal_temperature_icon_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_pai_icon_img = ''
        let idle_background_bg = ''
        let idle_stress_icon_img = ''
        let idle_digital_clock_img_time_minute = ''
        let idle_digital_clock_img_time_second = ''
        let idle_digital_clock_second_separator_img = ''
        let idle_digital_clock_img_time_hour = ''
        let idle_digital_clock_hour_separator_img = ''
        let idle_pai_icon_img = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFFC0C0C0',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: -672,
              y: 140,
              src: 'Picture2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 43,
              y: 269,
              font_array: ["wtats_greece_gold_4_0001.png","wtats_greece_gold_4_0002.png","wtats_greece_gold_4_0003.png","wtats_greece_gold_4_0004.png","wtats_greece_gold_4_0005.png","wtats_greece_gold_4_0006.png","wtats_greece_gold_4_0007.png","wtats_greece_gold_4_0008.png","wtats_greece_gold_4_0009.png","wtats_greece_gold_4_0010.png"],
              padding: false,
              h_space: -2,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 130,
              y: 267,
              src: 'ztats_greece_gold_4_0001.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 127,
              y: 392,
              src: 'ztats_greece_gold_4_0005.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 68,
              y: 391,
              font_array: ["wtats_greece_gold_4_0001.png","wtats_greece_gold_4_0002.png","wtats_greece_gold_4_0003.png","wtats_greece_gold_4_0004.png","wtats_greece_gold_4_0005.png","wtats_greece_gold_4_0006.png","wtats_greece_gold_4_0007.png","wtats_greece_gold_4_0008.png","wtats_greece_gold_4_0009.png","wtats_greece_gold_4_0010.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 52,
              y: 330,
              font_array: ["wtats_greece_gold_4_0001.png","wtats_greece_gold_4_0002.png","wtats_greece_gold_4_0003.png","wtats_greece_gold_4_0004.png","wtats_greece_gold_4_0005.png","wtats_greece_gold_4_0006.png","wtats_greece_gold_4_0007.png","wtats_greece_gold_4_0008.png","wtats_greece_gold_4_0009.png","wtats_greece_gold_4_0010.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 129,
              y: 329,
              src: 'ztats_greece_gold_4_0003.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 68,
              y: 361,
              font_array: ["wtats_greece_gold_4_0001.png","wtats_greece_gold_4_0002.png","wtats_greece_gold_4_0003.png","wtats_greece_gold_4_0004.png","wtats_greece_gold_4_0005.png","wtats_greece_gold_4_0006.png","wtats_greece_gold_4_0007.png","wtats_greece_gold_4_0008.png","wtats_greece_gold_4_0009.png","wtats_greece_gold_4_0010.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 131,
              y: 361,
              src: 'ztats_greece_gold_4_0004.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 54,
              y: 299,
              font_array: ["wtats_greece_gold_4_0001.png","wtats_greece_gold_4_0002.png","wtats_greece_gold_4_0003.png","wtats_greece_gold_4_0004.png","wtats_greece_gold_4_0005.png","wtats_greece_gold_4_0006.png","wtats_greece_gold_4_0007.png","wtats_greece_gold_4_0008.png","wtats_greece_gold_4_0009.png","wtats_greece_gold_4_0010.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 130,
              y: 295,
              src: 'ztats_greece_gold_4_0002.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 248,
              minute_startY: 136,
              minute_array: ["greece_gold_28_0001.png","greece_gold_28_0002.png","greece_gold_28_0003.png","greece_gold_28_0004.png","greece_gold_28_0005.png","greece_gold_28_0006.png","greece_gold_28_0007.png","greece_gold_28_0008.png","greece_gold_28_0009.png","greece_gold_28_0010.png"],
              minute_zero: 1,
              minute_space: -5,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_second = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              second_startX: 200,
              second_startY: 229,
              second_array: ["s-greece_gold_28_0001.png","s-greece_gold_28_0002.png","s-greece_gold_28_0003.png","s-greece_gold_28_0004.png","s-greece_gold_28_0005.png","s-greece_gold_28_0006.png","s-greece_gold_28_0007.png","s-greece_gold_28_0008.png","s-greece_gold_28_0009.png","s-greece_gold_28_0010.png"],
              second_zero: 1,
              second_space: -80,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_second_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: -271,
              y: -89,
              src: 'Picture1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 65,
              hour_startY: -4,
              hour_array: ["greece_white_28_0001.png","greece_white_28_0002.png","greece_white_28_0003.png","greece_white_28_0004.png","greece_white_28_0005.png","greece_white_28_0006.png","greece_white_28_0007.png","greece_white_28_0008.png","greece_white_28_0009.png","greece_white_28_0010.png"],
              hour_zero: 1,
              hour_space: -4,
              hour_angle: 0,
              hour_align: hmUI.align.RIGHT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 205,
              y: 0,
              src: 'icon_Picture - Grey.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 295,
              y: -91,
              font_array: ["stats_greece_white_28_0001.png","stats_greece_white_28_0002.png","stats_greece_white_28_0003.png","stats_greece_white_28_0004.png","stats_greece_white_28_0005.png","stats_greece_white_28_0006.png","stats_greece_white_28_0007.png","stats_greece_white_28_0008.png","stats_greece_white_28_0009.png","stats_greece_white_28_0010.png"],
              padding: false,
              h_space: -1,
              unit_sc: 'ztat_weat_icon (1).png',
              unit_tc: 'ztat_weat_icon (1).png',
              unit_en: 'ztat_weat_icon (1).png',
              negative_image: 'ztat_weat_icon (2).png',
              invalid_image: '0122 - Copy.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 143,
              y: 22,
              image_array: ["0097.png","0098.png","0099.png","0100.png","0101.png","0102.png","0103.png","0104.png","0105.png","0106.png","0107.png","0108.png","0109.png","0110.png","0111.png","0112.png","0113.png","0114.png","0115.png","0116.png","0117.png","0118.png","0119.png","0120.png","0121.png","0122.png","0123.png","0124.png","0125.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 316,
              day_startY: 36,
              day_sc_array: ["stats_greece_white_28_0001.png","stats_greece_white_28_0002.png","stats_greece_white_28_0003.png","stats_greece_white_28_0004.png","stats_greece_white_28_0005.png","stats_greece_white_28_0006.png","stats_greece_white_28_0007.png","stats_greece_white_28_0008.png","stats_greece_white_28_0009.png","stats_greece_white_28_0010.png"],
              day_tc_array: ["stats_greece_white_28_0001.png","stats_greece_white_28_0002.png","stats_greece_white_28_0003.png","stats_greece_white_28_0004.png","stats_greece_white_28_0005.png","stats_greece_white_28_0006.png","stats_greece_white_28_0007.png","stats_greece_white_28_0008.png","stats_greece_white_28_0009.png","stats_greece_white_28_0010.png"],
              day_en_array: ["stats_greece_white_28_0001.png","stats_greece_white_28_0002.png","stats_greece_white_28_0003.png","stats_greece_white_28_0004.png","stats_greece_white_28_0005.png","stats_greece_white_28_0006.png","stats_greece_white_28_0007.png","stats_greece_white_28_0008.png","stats_greece_white_28_0009.png","stats_greece_white_28_0010.png"],
              day_zero: 1,
              day_space: -2,
              day_align: hmUI.align.RIGHT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 274,
              y: 23,
              week_en: ["day_greece_white_28_0001.png","day_greece_white_28_0002.png","day_greece_white_28_0003.png","day_greece_white_28_0004.png","day_greece_white_28_0005.png","day_greece_white_28_0006.png","day_greece_white_28_0007.png"],
              week_tc: ["day_greece_white_28_0001.png","day_greece_white_28_0002.png","day_greece_white_28_0003.png","day_greece_white_28_0004.png","day_greece_white_28_0005.png","day_greece_white_28_0006.png","day_greece_white_28_0007.png"],
              week_sc: ["day_greece_white_28_0001.png","day_greece_white_28_0002.png","day_greece_white_28_0003.png","day_greece_white_28_0004.png","day_greece_white_28_0005.png","day_greece_white_28_0006.png","day_greece_white_28_0007.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: -48,
              y: -45,
              src: 'Picture2-Ring239.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFFC0C0C0',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_stress_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: -672,
              y: 140,
              src: 'Picture2.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 248,
              minute_startY: 136,
              minute_array: ["greece_gold_28_0001.png","greece_gold_28_0002.png","greece_gold_28_0003.png","greece_gold_28_0004.png","greece_gold_28_0005.png","greece_gold_28_0006.png","greece_gold_28_0007.png","greece_gold_28_0008.png","greece_gold_28_0009.png","greece_gold_28_0010.png"],
              minute_zero: 1,
              minute_space: -5,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_second = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              second_startX: 200,
              second_startY: 229,
              second_array: ["s-greece_gold_28_0001.png","s-greece_gold_28_0002.png","s-greece_gold_28_0003.png","s-greece_gold_28_0004.png","s-greece_gold_28_0005.png","s-greece_gold_28_0006.png","s-greece_gold_28_0007.png","s-greece_gold_28_0008.png","s-greece_gold_28_0009.png","s-greece_gold_28_0010.png"],
              second_zero: 1,
              second_space: -80,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_second_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: -271,
              y: -89,
              src: 'Picture1.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 65,
              hour_startY: -4,
              hour_array: ["greece_white_28_0001.png","greece_white_28_0002.png","greece_white_28_0003.png","greece_white_28_0004.png","greece_white_28_0005.png","greece_white_28_0006.png","greece_white_28_0007.png","greece_white_28_0008.png","greece_white_28_0009.png","greece_white_28_0010.png"],
              hour_zero: 1,
              hour_space: -4,
              hour_angle: 0,
              hour_align: hmUI.align.RIGHT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: -278,
              y: -90,
              src: 'AOB Overlay.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_pai_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: -48,
              y: -45,
              src: 'Picture2-Ring239.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
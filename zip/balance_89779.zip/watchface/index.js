﻿    /*
    ** Watch_Face_Editor tool v 18.1
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_fat_burning_icon_img = ''
        let normal_stress_icon_img = ''
        let normal_date_img_date_month_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_date_img_date_week_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_step_current_text_img = ''
        let normal_date_img_date_day = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_digital_clock_img_time = ''
        let normal_image_img = ''
        let idle_background_bg_img = ''
        let idle_date_img_date_month_img = ''
        let idle_battery_icon_img = ''
        let idle_battery_text_text_img = ''
        let idle_stress_icon_img = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_week_img = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''
        let idle_analog_clock_pro_second_pointer_img = ''
        let idle_timerUpdateSec = undefined;
        let idle_image_img = ''
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg004.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_fat_burning_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 353,
              y: 332,
              src: 'aloff6.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 102,
              y: 332,
              src: 'btoff3.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 199,
              month_startY: 60,
              month_sc_array: ["mon01_80x24.png","mon02_80x24.png","mon03_80x24.png","mon04_80x24.png","mon05_80x24.png","mon06_80x24.png","mon07_80x24.png","mon08_80x24.png","mon09_80x24.png","mon10_80x24.png","mon11_80x24.png","mon12_80x24.png"],
              month_tc_array: ["mon01_80x24.png","mon02_80x24.png","mon03_80x24.png","mon04_80x24.png","mon05_80x24.png","mon06_80x24.png","mon07_80x24.png","mon08_80x24.png","mon09_80x24.png","mon10_80x24.png","mon11_80x24.png","mon12_80x24.png"],
              month_en_array: ["mon01_80x24.png","mon02_80x24.png","mon03_80x24.png","mon04_80x24.png","mon05_80x24.png","mon06_80x24.png","mon07_80x24.png","mon08_80x24.png","mon09_80x24.png","mon10_80x24.png","mon11_80x24.png","mon12_80x24.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 102,
              y: 332,
              src: 'btoff2.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 353,
              y: 332,
              src: 'al2.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 148,
              y: 35,
              week_en: ["0155.png","0156.png","0157.png","0158.png","0159.png","0160.png","0161.png"],
              week_tc: ["0155.png","0156.png","0157.png","0158.png","0159.png","0160.png","0161.png"],
              week_sc: ["0155.png","0156.png","0157.png","0158.png","0159.png","0160.png","0161.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 160,
              y: 379,
              image_array: ["0122_161x43.png","0123_161x43.png","0124_161x43.png","0125_161x43.png","0126_161x43.png","0127_161x43.png","0128_161x43.png","0129_161x43.png","0130_161x43.png","0131_161x43.png","0132_161x43.png","0133_161x43.png","0134_161x43.png","0135_161x43.png","0136_161x43.png","0137_161x43.png","0138_161x43.png","0139_161x43.png","0140_161x43.png","0141_161x43.png","0142_161x43.png","0143_161x43.png","0144_161x43.png","0145_161x43.png","0146_161x43.png","0147_161x43.png","0148_161x43.png"],
              image_length: 27,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 148,
              y: 301,
              font_array: ["0052_35x29.png","0053_35x29.png","0054_35x29.png","0055_35x29.png","0056_35x29.png","0057_35x29.png","0058_35x29.png","0059_35x29.png","0060_35x29.png","0061_35x29.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 214,
              day_startY: 97,
              day_sc_array: ["0062_25x20.png","0063_25x20.png","0064_25x20.png","0065_25x20.png","0066_25x20.png","0067_25x20.png","0068_25x20.png","0069_25x20.png","0070_25x20.png","0071_25x20.png"],
              day_tc_array: ["0062_25x20.png","0063_25x20.png","0064_25x20.png","0065_25x20.png","0066_25x20.png","0067_25x20.png","0068_25x20.png","0069_25x20.png","0070_25x20.png","0071_25x20.png"],
              day_en_array: ["0062_25x20.png","0063_25x20.png","0064_25x20.png","0065_25x20.png","0066_25x20.png","0067_25x20.png","0068_25x20.png","0069_25x20.png","0070_25x20.png","0071_25x20.png"],
              day_zero: 1,
              day_space: 2,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 335,
              y: 128,
              image_array: ["0093_38x27.png","0094_38x27.png","0095_38x27.png","0096_38x27.png","0097_38x27.png","0098_38x27.png","0099_38x27.png","0100_38x27.png","0101_38x27.png","0102_38x27.png","0103_38x27.png","0104_38x27.png","0105_38x27.png","0106_38x27.png","0107_38x27.png","0108_38x27.png","0109_38x27.png","0110_38x27.png","0111_38x27.png","0112_38x27.png","0113_38x27.png","0114_38x27.png","0115_38x27.png","0116_38x27.png","0117_38x27.png","0118_38x27.png","0119_38x27.png","0120_38x27.png","0121_38x27.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 315,
              y: 164,
              font_array: ["0072_20x16.png","0073_20x16.png","0074_20x16.png","0075_20x16.png","0076_20x16.png","0077_20x16.png","0078_20x16.png","0079_20x16.png","0080_20x16.png","0081_20x16.png"],
              padding: false,
              h_space: 2,
              unit_sc: '0082_11x16.png',
              unit_tc: '0082_11x16.png',
              unit_en: '0082_11x16.png',
              negative_image: '0084_11x16.png',
              invalid_image: '0084_11x16.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 94,
              y: 144,
              font_array: ["0023_27x38.png","0024_27x38.png","0025_27x38.png","0026_27x38.png","0027_27x38.png","0028_27x38.png","0029_27x38.png","0030_27x38.png","0031_27x38.png","0032_27x38.png"],
              padding: false,
              h_space: 4,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 74,
              hour_startY: 202,
              hour_array: ["0003_56x80.png","0004_56x80.png","0005_56x80.png","0006_56x80.png","0007_56x80.png","0008_56x80.png","0009_56x80.png","0010_56x80.png","0011_56x80.png","0012_56x80.png"],
              hour_zero: 1,
              hour_space: 7,
              hour_angle: 0,
              hour_align: hmUI.align.RIGHT,

              minute_startX: 221,
              minute_startY: 202,
              minute_array: ["0003_56x80.png","0004_56x80.png","0005_56x80.png","0006_56x80.png","0007_56x80.png","0008_56x80.png","0009_56x80.png","0010_56x80.png","0011_56x80.png","0012_56x80.png"],
              minute_zero: 1,
              minute_space: 7,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 354,
              second_startY: 244,
              second_array: ["0023_27x38.png","0024_27x38.png","0025_27x38.png","0026_27x38.png","0027_27x38.png","0028_27x38.png","0029_27x38.png","0030_27x38.png","0031_27x38.png","0032_27x38.png"],
              second_zero: 1,
              second_space: 6,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'bg_fill_10.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg005.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 280,
              month_startY: 141,
              month_sc_array: ["0180.png","0181.png","0182.png","0183.png","0184.png","0185.png","0186.png","0187.png","0188.png","0189.png","0190.png","0191.png"],
              month_tc_array: ["0180.png","0181.png","0182.png","0183.png","0184.png","0185.png","0186.png","0187.png","0188.png","0189.png","0190.png","0191.png"],
              month_en_array: ["0180.png","0181.png","0182.png","0183.png","0184.png","0185.png","0186.png","0187.png","0188.png","0189.png","0190.png","0191.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 223,
              y: 337,
              src: 'zar.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 208,
              y: 381,
              font_array: ["MF_Medium_0.png","MF_Medium_1.png","MF_Medium_2.png","MF_Medium_3.png","MF_Medium_4.png","MF_Medium_5.png","MF_Medium_6.png","MF_Medium_7.png","MF_Medium_8.png","MF_Medium_9.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'MF_Medium_Perc.png',
              unit_tc: 'MF_Medium_Perc.png',
              unit_en: 'MF_Medium_Perc.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_stress_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 210,
              y: 65,
              src: 'logo.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 214,
              day_startY: 138,
              day_sc_array: ["0381.png","0382.png","0383.png","0384.png","0385.png","0386.png","0387.png","0388.png","0389.png","0390.png"],
              day_tc_array: ["0381.png","0382.png","0383.png","0384.png","0385.png","0386.png","0387.png","0388.png","0389.png","0390.png"],
              day_en_array: ["0381.png","0382.png","0383.png","0384.png","0385.png","0386.png","0387.png","0388.png","0389.png","0390.png"],
              day_zero: 1,
              day_space: 2,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 113,
              y: 137,
              week_en: ["dw1.png","dw2.png","dw3.png","dw4.png","dw5.png","dw6.png","dw7.png"],
              week_tc: ["dw1.png","dw2.png","dw3.png","dw4.png","dw5.png","dw6.png","dw7.png"],
              week_sc: ["dw1.png","dw2.png","dw3.png","dw4.png","dw5.png","dw6.png","dw7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 104,
              hour_startY: 199,
              hour_array: ["0013_56x80.png","0014_56x80.png","0015_56x80.png","0016_56x80.png","0017_56x80.png","0018_56x80.png","0019_56x80.png","0020_56x80.png","0021_56x80.png","0022_56x80.png"],
              hour_zero: 1,
              hour_space: 7,
              hour_angle: 0,
              hour_align: hmUI.align.RIGHT,

              minute_startX: 258,
              minute_startY: 199,
              minute_array: ["0013_56x80.png","0014_56x80.png","0015_56x80.png","0016_56x80.png","0017_56x80.png","0018_56x80.png","0019_56x80.png","0020_56x80.png","0021_56x80.png","0022_56x80.png"],
              minute_zero: 1,
              minute_space: 7,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 232,
              y: 199,
              src: '0092_17x80.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            const deviceInfo = hmSetting.getDeviceInfo();
            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            // idle_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'sec7.png',
              // center_x: 240,
              // center_y: 240,
              // x: 25,
              // y: 250,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });


            idle_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 25,
              pos_y: 240 - 250,
              center_x: 240,
              center_y: 240,
              src: 'sec7.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            let screenType = hmSetting.getScreenType();
            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 50,
              y: 54,
              src: 'mask380.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            //#region time_update
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              // Second Pointer
              let idle_fullAngle_second = 360;
              let idle_angle_second = 0 + idle_fullAngle_second*second/60;
              if (idle_analog_clock_pro_second_pointer_img) idle_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, idle_angle_second);

            };

            //#endregion
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                time_update(true, true);
                if (screenType == hmSetting.screen_type.AOD) {
                  if (!idle_timerUpdateSec) {
                    let animDelay = timeSensor.utc % 1000;
                    let animRepeat = 1000;
                    idle_timerUpdateSec = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, false);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (idle_timerUpdateSec) {
                  timer.stopTimer(idle_timerUpdateSec);
                  idle_timerUpdateSec = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
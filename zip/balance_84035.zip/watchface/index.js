﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

       // switch info.
        let elementnumber_1 = 1
        let total_elemente = 3
        let cc = 0

        function click_elemente() {
            if(elementnumber_1==total_elemente) {
            elementnumber_1=1;
                UpdateElementeOne();
                }
            else {
                elementnumber_1=elementnumber_1+1;
                if(elementnumber_1==2) {
                  UpdateElementeTwo();
                }
                if(elementnumber_1==3) {
                  UpdateElementeThree();
                }

            }
            if(elementnumber_1==1) hmUI.showToast({text: 'STEPS'});
            if(elementnumber_1==2) hmUI.showToast({text: 'DISTANCE'});
            if(elementnumber_1==3) hmUI.showToast({text: 'CALORIES'});
        }

        //STEPS
        function UpdateElementeOne(){

        normal_calorie_circle_scale.setProperty(hmUI.prop.VISIBLE, false);
        normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_step_circle_scale.setProperty(hmUI.prop.VISIBLE, true);
        normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_step_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
        normal_pai_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);

        }

        //DISTANCE
        function UpdateElementeTwo(){

        normal_calorie_circle_scale.setProperty(hmUI.prop.VISIBLE, false);
        normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_step_circle_scale.setProperty(hmUI.prop.VISIBLE, true);
        normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_step_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
        normal_pai_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        }

        //CALORIES

        function UpdateElementeThree(){

        normal_calorie_circle_scale.setProperty(hmUI.prop.VISIBLE, true);
        normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_step_circle_scale.setProperty(hmUI.prop.VISIBLE, false);
        normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_step_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_pai_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
        }
        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_calorie_circle_scale = ''
        let normal_calorie_current_text_img = ''
        let normal_calorie_current_separator_img = ''
        let normal_distance_text_text_img = ''
        let normal_distance_text_separator_img = ''
        let normal_step_circle_scale = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_moon_image_progress_img_level = ''
        let normal_city_name_text = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_system_dnd_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_spo2_text_text_img = ''
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_circle_scale = ''
        let normal_heart_rate_text_text_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time_second = ''
        let normal_digital_clock_img_time_minute = ''
        let normal_digital_clock_minute_separator_img = ''
        let normal_digital_clock_img_time_hour = ''
        let normal_digital_clock_hour_separator_img = ''
        let idle_background_bg_img = ''
        let idle_step_circle_scale = ''
        let idle_step_current_text_img = ''
        let idle_step_current_separator_img = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_day = ''
        let idle_moon_image_progress_img_level = ''
        let idle_city_name_text = ''
        let idle_weather_image_progress_img_level = ''
        let idle_temperature_current_text_img = ''
        let idle_system_dnd_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_battery_text_text_img = ''
        let idle_battery_image_progress_img_level = ''
        let idle_spo2_icon_img = ''
        let idle_spo2_text_text_img = ''
        let idle_heart_rate_icon_img = ''
        let idle_heart_rate_circle_scale = ''
        let idle_heart_rate_text_text_img = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time_minute = ''
        let idle_digital_clock_minute_separator_img = ''
        let idle_digital_clock_img_time_hour = ''
        let idle_digital_clock_hour_separator_img = ''
        let normal_step_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_Switch_BG = ''

        let backgroundIndex = 0;
        let backgroundList = ['a_neo1.png', 'a_neo2.png', 'a_neo3.png', 'a_neo4.png', 'a_neo5.png', 'a_neo6.png'];
        let backgroundToastList = ['RED', 'BLUE', 'ORANGE', 'LEMON', 'GREEN', 'GRAY'];
        const watchfaceId = hmApp.packageInfo().watchfaceId;


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            //start of ignored block
            console.log('SwitchBackground');
            function switchBackground() {
              backgroundIndex++;
              if (backgroundIndex >= backgroundList.length) backgroundIndex = 0;
              hmFS.SysProSetInt(`backgroundIndex_${watchfaceId}`, backgroundIndex);
              let toastText = backgroundToastList[backgroundIndex].replace('%s', `${backgroundIndex + 1}`);
              if (toastText.length > 0) hmUI.showToast({text: toastText});
              normal_background_bg_img.setProperty(hmUI.prop.SRC, backgroundList[backgroundIndex]);
            };
            //end of ignored block

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'a_neo1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_cal_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 132,
              // center_y: 107,
              // start_angle: 270,
              // end_angle: 451,
              // radius: 63,
              // line_width: 10,
              // line_cap: Flat,
              // color: 0xFF454545,
              // mirror: False,
              // inversion: True,
              // alpha: 181,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            let screenType = hmSetting.getScreenType();
            normal_calorie_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 132,
              center_y: 107,
              start_angle: 451,
              end_angle: 270,
              radius: 58,
              line_width: 10,
              corner_flag: 3,
              color: 0xFF454545,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_circle_scale.setAlpha(181);
            
            const calorie = hmSensor.createSensor(hmSensor.id.CALORIE);
            calorie.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 220,
              y: 65,
              font_array: ["Heart_Font_01.png","Heart_Font_02.png","Heart_Font_03.png","Heart_Font_04.png","Heart_Font_05.png","Heart_Font_06.png","Heart_Font_07.png","Heart_Font_08.png","Heart_Font_09.png","Heart_Font_10.png"],
              padding: false,
              h_space: 5,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 106,
              y: 72,
              src: 'icon_cal.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 220,
              y: 64,
              font_array: ["Heart_Font_01.png","Heart_Font_02.png","Heart_Font_03.png","Heart_Font_04.png","Heart_Font_05.png","Heart_Font_06.png","Heart_Font_07.png","Heart_Font_08.png","Heart_Font_09.png","Heart_Font_10.png"],
              padding: false,
              h_space: 5,
              unit_sc: 'Dis_KM.png',
              unit_tc: 'Dis_KM.png',
              unit_en: 'Dis_KM.png',
              imperial_unit_sc: 'Dis_MI.png',
              imperial_unit_tc: 'Dis_MI.png',
              imperial_unit_en: 'Dis_MI.png',
              dot_image: 'Dis_symbo_dot.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 104,
              y: 72,
              src: 'icon_dis.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 132,
              // center_y: 107,
              // start_angle: 270,
              // end_angle: 451,
              // radius: 63,
              // line_width: 10,
              // line_cap: Flat,
              // color: 0xFF454545,
              // mirror: False,
              // inversion: True,
              // alpha: 181,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 132,
              center_y: 107,
              start_angle: 451,
              end_angle: 270,
              radius: 58,
              line_width: 10,
              corner_flag: 3,
              color: 0xFF454545,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_circle_scale.setAlpha(181);
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 220,
              y: 65,
              font_array: ["Heart_Font_01.png","Heart_Font_02.png","Heart_Font_03.png","Heart_Font_04.png","Heart_Font_05.png","Heart_Font_06.png","Heart_Font_07.png","Heart_Font_08.png","Heart_Font_09.png","Heart_Font_10.png"],
              padding: false,
              h_space: 5,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 104,
              y: 72,
              src: 'icon_Step.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 202,
              month_startY: 286,
              month_sc_array: ["Month_icon_01.png","Month_icon_02.png","Month_icon_03.png","Month_icon_04.png","Month_icon_05.png","Month_icon_06.png","Month_icon_07.png","Month_icon_08.png","Month_icon_09.png","Month_icon_10.png","Month_icon_11.png","Month_icon_12.png"],
              month_tc_array: ["Month_icon_01.png","Month_icon_02.png","Month_icon_03.png","Month_icon_04.png","Month_icon_05.png","Month_icon_06.png","Month_icon_07.png","Month_icon_08.png","Month_icon_09.png","Month_icon_10.png","Month_icon_11.png","Month_icon_12.png"],
              month_en_array: ["Month_icon_01.png","Month_icon_02.png","Month_icon_03.png","Month_icon_04.png","Month_icon_05.png","Month_icon_06.png","Month_icon_07.png","Month_icon_08.png","Month_icon_09.png","Month_icon_10.png","Month_icon_11.png","Month_icon_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 43,
              y: 286,
              week_en: ["Week_icon_01.png","Week_icon_02.png","Week_icon_03.png","Week_icon_04.png","Week_icon_05.png","Week_icon_06.png","Week_icon_07.png"],
              week_tc: ["Week_icon_01.png","Week_icon_02.png","Week_icon_03.png","Week_icon_04.png","Week_icon_05.png","Week_icon_06.png","Week_icon_07.png"],
              week_sc: ["Week_icon_01.png","Week_icon_02.png","Week_icon_03.png","Week_icon_04.png","Week_icon_05.png","Week_icon_06.png","Week_icon_07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 146,
              day_startY: 283,
              day_sc_array: ["Heart_Font_01.png","Heart_Font_02.png","Heart_Font_03.png","Heart_Font_04.png","Heart_Font_05.png","Heart_Font_06.png","Heart_Font_07.png","Heart_Font_08.png","Heart_Font_09.png","Heart_Font_10.png"],
              day_tc_array: ["Heart_Font_01.png","Heart_Font_02.png","Heart_Font_03.png","Heart_Font_04.png","Heart_Font_05.png","Heart_Font_06.png","Heart_Font_07.png","Heart_Font_08.png","Heart_Font_09.png","Heart_Font_10.png"],
              day_en_array: ["Heart_Font_01.png","Heart_Font_02.png","Heart_Font_03.png","Heart_Font_04.png","Heart_Font_05.png","Heart_Font_06.png","Heart_Font_07.png","Heart_Font_08.png","Heart_Font_09.png","Heart_Font_10.png"],
              day_zero: 1,
              day_space: 5,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 371,
              y: 120,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 337,
              y: 143,
              w: 95,
              h: 27,
              text_size: 20,
              char_space: 0,
              line_space: 0,
              color: 0xFF000000,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 207,
              y: 125,
              image_array: ["Weather_icon_01.png","Weather_icon_02.png","Weather_icon_03.png","Weather_icon_04.png","Weather_icon_05.png","Weather_icon_06.png","Weather_icon_07.png","Weather_icon_08.png","Weather_icon_09.png","Weather_icon_10.png","Weather_icon_11.png","Weather_icon_12.png","Weather_icon_13.png","Weather_icon_14.png","Weather_icon_15.png","Weather_icon_16.png","Weather_icon_17.png","Weather_icon_18.png","Weather_icon_19.png","Weather_icon_20.png","Weather_icon_21.png","Weather_icon_22.png","Weather_icon_23.png","Weather_icon_24.png","Weather_icon_25.png","Weather_icon_26.png","Weather_icon_27.png","Weather_icon_28.png","Weather_icon_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 250,
              y: 124,
              font_array: ["Heart_Font_01.png","Heart_Font_02.png","Heart_Font_03.png","Heart_Font_04.png","Heart_Font_05.png","Heart_Font_06.png","Heart_Font_07.png","Heart_Font_08.png","Heart_Font_09.png","Heart_Font_10.png"],
              padding: false,
              h_space: 4,
              unit_sc: 'Weather_symbo_01.png',
              unit_tc: 'Weather_symbo_01.png',
              unit_en: 'Weather_symbo_01.png',
              imperial_unit_sc: 'Weather_symbo_01.png',
              imperial_unit_tc: 'Weather_symbo_01.png',
              imperial_unit_en: 'Weather_symbo_01.png',
              negative_image: 'Weather_symbo_02.png',
              invalid_image: 'Weather_symbo_02.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const temperatureUnit = hmSetting.getTemperatureUnit();
            //start of ignored block
            if (temperatureUnit == 1) {
              normal_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
                x: 250,
                y: 124,
                font_array: ["Heart_Font_01.png","Heart_Font_02.png","Heart_Font_03.png","Heart_Font_04.png","Heart_Font_05.png","Heart_Font_06.png","Heart_Font_07.png","Heart_Font_08.png","Heart_Font_09.png","Heart_Font_10.png"],
                padding: false,
                h_space: 4,
                unit_sc: 'Weather_symbo_01.png',
                unit_tc: 'Weather_symbo_01.png',
                unit_en: 'Weather_symbo_01.png',
                imperial_unit_sc: 'Weather_symbo_01.png',
                imperial_unit_tc: 'Weather_symbo_01.png',
                imperial_unit_en: 'Weather_symbo_01.png',
                negative_image: 'Weather_symbo_02.png',
                invalid_image: 'Weather_symbo_02.png',
                align_h: hmUI.align.CENTER_H,
                type: hmUI.data_type.WEATHER_CURRENT,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
            };
            //end of ignored block

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 147,
              y: 380,
              src: 'System_DND.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 115,
              y: 385,
              src: 'System_BT_OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 92,
              y: 389,
              src: 'System_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 109,
              y: 351,
              font_array: ["Batt_Font_01.png","Batt_Font_02.png","Batt_Font_03.png","Batt_Font_04.png","Batt_Font_05.png","Batt_Font_06.png","Batt_Font_07.png","Batt_Font_08.png","Batt_Font_09.png","Batt_Font_10.png"],
              padding: false,
              h_space: 3,
              unit_sc: 'Battery_symbo.png',
              unit_tc: 'Battery_symbo.png',
              unit_en: 'Battery_symbo.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 90,
              y: 346,
              image_array: ["Batt_icon_01.png","Batt_icon_02.png","Batt_icon_03.png","Batt_icon_04.png","Batt_icon_05.png","Batt_icon_06.png","Batt_icon_07.png","Batt_icon_08.png","Batt_icon_09.png","Batt_icon_10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 216,
              y: 345,
              font_array: ["Batt_Font_01.png","Batt_Font_02.png","Batt_Font_03.png","Batt_Font_04.png","Batt_Font_05.png","Batt_Font_06.png","Batt_Font_07.png","Batt_Font_08.png","Batt_Font_09.png","Batt_Font_10.png"],
              padding: false,
              h_space: 3,
              unit_sc: 'Battery_symbo.png',
              unit_tc: 'Battery_symbo.png',
              unit_en: 'Battery_symbo.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 171,
              y: 14,
              src: 'AmazfitLogo.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_heart_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 347,
              // center_y: 372,
              // start_angle: 90,
              // end_angle: 270,
              // radius: 63,
              // line_width: 10,
              // line_cap: Flat,
              // color: 0xFF454545,
              // mirror: False,
              // inversion: True,
              // alpha: 181,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_heart_rate_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 347,
              center_y: 372,
              start_angle: 270,
              end_angle: 90,
              radius: 58,
              line_width: 10,
              corner_flag: 3,
              color: 0xFF454545,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_circle_scale.setAlpha(181);
            
            const heart_rate = hmSensor.createSensor(hmSensor.id.HEART);
            heart_rate.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 188,
              y: 377,
              font_array: ["Heart_Font_01.png","Heart_Font_02.png","Heart_Font_03.png","Heart_Font_04.png","Heart_Font_05.png","Heart_Font_06.png","Heart_Font_07.png","Heart_Font_08.png","Heart_Font_09.png","Heart_Font_10.png"],
              padding: false,
              h_space: 5,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 331,
              am_y: 280,
              am_sc_path: 'Clock_AM.png',
              am_en_path: 'Clock_AM.png',
              pm_x: 331,
              pm_y: 280,
              pm_sc_path: 'Clock_PM.png',
              pm_en_path: 'Clock_PM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_second = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              second_startX: 300,
              second_startY: 193,
              second_array: ["Time_Font_01.png","Time_Font_02.png","Time_Font_03.png","Time_Font_04.png","Time_Font_05.png","Time_Font_06.png","Time_Font_07.png","Time_Font_08.png","Time_Font_09.png","Time_Font_10.png"],
              second_zero: 1,
              second_space: 7,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 178,
              minute_startY: 193,
              minute_array: ["Time_Font_01.png","Time_Font_02.png","Time_Font_03.png","Time_Font_04.png","Time_Font_05.png","Time_Font_06.png","Time_Font_07.png","Time_Font_08.png","Time_Font_09.png","Time_Font_10.png"],
              minute_zero: 1,
              minute_space: 7,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_minute_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 276,
              y: 202,
              src: 'Time_Dot.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 59,
              hour_startY: 193,
              hour_array: ["Time_Font_01.png","Time_Font_02.png","Time_Font_03.png","Time_Font_04.png","Time_Font_05.png","Time_Font_06.png","Time_Font_07.png","Time_Font_08.png","Time_Font_09.png","Time_Font_10.png"],
              hour_zero: 1,
              hour_space: 7,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 155,
              y: 202,
              src: 'Time_Dot.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'a_neo6.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 132,
              // center_y: 107,
              // start_angle: 270,
              // end_angle: 451,
              // radius: 63,
              // line_width: 10,
              // line_cap: Flat,
              // color: 0xFF454545,
              // mirror: False,
              // inversion: True,
              // alpha: 181,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 132,
              center_y: 107,
              start_angle: 451,
              end_angle: 270,
              radius: 58,
              line_width: 10,
              corner_flag: 3,
              color: 0xFF454545,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_circle_scale.setAlpha(181);

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 220,
              y: 65,
              font_array: ["Heart_Font_01.png","Heart_Font_02.png","Heart_Font_03.png","Heart_Font_04.png","Heart_Font_05.png","Heart_Font_06.png","Heart_Font_07.png","Heart_Font_08.png","Heart_Font_09.png","Heart_Font_10.png"],
              padding: false,
              h_space: 5,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 104,
              y: 72,
              src: 'icon_Step.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 202,
              month_startY: 286,
              month_sc_array: ["Month_icon_01.png","Month_icon_02.png","Month_icon_03.png","Month_icon_04.png","Month_icon_05.png","Month_icon_06.png","Month_icon_07.png","Month_icon_08.png","Month_icon_09.png","Month_icon_10.png","Month_icon_11.png","Month_icon_12.png"],
              month_tc_array: ["Month_icon_01.png","Month_icon_02.png","Month_icon_03.png","Month_icon_04.png","Month_icon_05.png","Month_icon_06.png","Month_icon_07.png","Month_icon_08.png","Month_icon_09.png","Month_icon_10.png","Month_icon_11.png","Month_icon_12.png"],
              month_en_array: ["Month_icon_01.png","Month_icon_02.png","Month_icon_03.png","Month_icon_04.png","Month_icon_05.png","Month_icon_06.png","Month_icon_07.png","Month_icon_08.png","Month_icon_09.png","Month_icon_10.png","Month_icon_11.png","Month_icon_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 43,
              y: 286,
              week_en: ["Week_icon_01.png","Week_icon_02.png","Week_icon_03.png","Week_icon_04.png","Week_icon_05.png","Week_icon_06.png","Week_icon_07.png"],
              week_tc: ["Week_icon_01.png","Week_icon_02.png","Week_icon_03.png","Week_icon_04.png","Week_icon_05.png","Week_icon_06.png","Week_icon_07.png"],
              week_sc: ["Week_icon_01.png","Week_icon_02.png","Week_icon_03.png","Week_icon_04.png","Week_icon_05.png","Week_icon_06.png","Week_icon_07.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 146,
              day_startY: 283,
              day_sc_array: ["Heart_Font_01.png","Heart_Font_02.png","Heart_Font_03.png","Heart_Font_04.png","Heart_Font_05.png","Heart_Font_06.png","Heart_Font_07.png","Heart_Font_08.png","Heart_Font_09.png","Heart_Font_10.png"],
              day_tc_array: ["Heart_Font_01.png","Heart_Font_02.png","Heart_Font_03.png","Heart_Font_04.png","Heart_Font_05.png","Heart_Font_06.png","Heart_Font_07.png","Heart_Font_08.png","Heart_Font_09.png","Heart_Font_10.png"],
              day_en_array: ["Heart_Font_01.png","Heart_Font_02.png","Heart_Font_03.png","Heart_Font_04.png","Heart_Font_05.png","Heart_Font_06.png","Heart_Font_07.png","Heart_Font_08.png","Heart_Font_09.png","Heart_Font_10.png"],
              day_zero: 1,
              day_space: 5,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 371,
              y: 120,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 337,
              y: 143,
              w: 95,
              h: 27,
              text_size: 20,
              char_space: 0,
              line_space: 0,
              color: 0xFF000000,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 207,
              y: 125,
              image_array: ["Weather_icon_01.png","Weather_icon_02.png","Weather_icon_03.png","Weather_icon_04.png","Weather_icon_05.png","Weather_icon_06.png","Weather_icon_07.png","Weather_icon_08.png","Weather_icon_09.png","Weather_icon_10.png","Weather_icon_11.png","Weather_icon_12.png","Weather_icon_13.png","Weather_icon_14.png","Weather_icon_15.png","Weather_icon_16.png","Weather_icon_17.png","Weather_icon_18.png","Weather_icon_19.png","Weather_icon_20.png","Weather_icon_21.png","Weather_icon_22.png","Weather_icon_23.png","Weather_icon_24.png","Weather_icon_25.png","Weather_icon_26.png","Weather_icon_27.png","Weather_icon_28.png","Weather_icon_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 250,
              y: 124,
              font_array: ["Heart_Font_01.png","Heart_Font_02.png","Heart_Font_03.png","Heart_Font_04.png","Heart_Font_05.png","Heart_Font_06.png","Heart_Font_07.png","Heart_Font_08.png","Heart_Font_09.png","Heart_Font_10.png"],
              padding: false,
              h_space: 4,
              unit_sc: 'Weather_symbo_01.png',
              unit_tc: 'Weather_symbo_01.png',
              unit_en: 'Weather_symbo_01.png',
              imperial_unit_sc: 'Weather_symbo_01.png',
              imperial_unit_tc: 'Weather_symbo_01.png',
              imperial_unit_en: 'Weather_symbo_01.png',
              negative_image: 'Weather_symbo_02.png',
              invalid_image: 'Weather_symbo_02.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            //start of ignored block
            if (temperatureUnit == 1) {
              idle_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
                x: 250,
                y: 124,
                font_array: ["Heart_Font_01.png","Heart_Font_02.png","Heart_Font_03.png","Heart_Font_04.png","Heart_Font_05.png","Heart_Font_06.png","Heart_Font_07.png","Heart_Font_08.png","Heart_Font_09.png","Heart_Font_10.png"],
                padding: false,
                h_space: 4,
                unit_sc: 'Weather_symbo_01.png',
                unit_tc: 'Weather_symbo_01.png',
                unit_en: 'Weather_symbo_01.png',
                imperial_unit_sc: 'Weather_symbo_01.png',
                imperial_unit_tc: 'Weather_symbo_01.png',
                imperial_unit_en: 'Weather_symbo_01.png',
                negative_image: 'Weather_symbo_02.png',
                invalid_image: 'Weather_symbo_02.png',
                align_h: hmUI.align.CENTER_H,
                type: hmUI.data_type.WEATHER_CURRENT,
                show_level: hmUI.show_level.ONLY_AOD,
              });
            };
            //end of ignored block

            idle_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 147,
              y: 380,
              src: 'System_DND.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 115,
              y: 385,
              src: 'System_BT_OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 92,
              y: 389,
              src: 'System_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 109,
              y: 351,
              font_array: ["Batt_Font_01.png","Batt_Font_02.png","Batt_Font_03.png","Batt_Font_04.png","Batt_Font_05.png","Batt_Font_06.png","Batt_Font_07.png","Batt_Font_08.png","Batt_Font_09.png","Batt_Font_10.png"],
              padding: false,
              h_space: 3,
              unit_sc: 'Battery_symbo.png',
              unit_tc: 'Battery_symbo.png',
              unit_en: 'Battery_symbo.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 90,
              y: 346,
              image_array: ["Batt_icon_01.png","Batt_icon_02.png","Batt_icon_03.png","Batt_icon_04.png","Batt_icon_05.png","Batt_icon_06.png","Batt_icon_07.png","Batt_icon_08.png","Batt_icon_09.png","Batt_icon_10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_spo2_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 295,
              y: 203,
              src: 'AOD_icon.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_spo2_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 216,
              y: 345,
              font_array: ["Batt_Font_01.png","Batt_Font_02.png","Batt_Font_03.png","Batt_Font_04.png","Batt_Font_05.png","Batt_Font_06.png","Batt_Font_07.png","Batt_Font_08.png","Batt_Font_09.png","Batt_Font_10.png"],
              padding: false,
              h_space: 3,
              unit_sc: 'Battery_symbo.png',
              unit_tc: 'Battery_symbo.png',
              unit_en: 'Battery_symbo.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 171,
              y: 14,
              src: 'AmazfitLogo.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_heart_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 347,
              // center_y: 372,
              // start_angle: 90,
              // end_angle: 270,
              // radius: 63,
              // line_width: 10,
              // line_cap: Flat,
              // color: 0xFF454545,
              // mirror: False,
              // inversion: True,
              // alpha: 181,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_heart_rate_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 347,
              center_y: 372,
              start_angle: 270,
              end_angle: 90,
              radius: 58,
              line_width: 10,
              corner_flag: 3,
              color: 0xFF454545,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_circle_scale.setAlpha(181);

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 188,
              y: 377,
              font_array: ["Heart_Font_01.png","Heart_Font_02.png","Heart_Font_03.png","Heart_Font_04.png","Heart_Font_05.png","Heart_Font_06.png","Heart_Font_07.png","Heart_Font_08.png","Heart_Font_09.png","Heart_Font_10.png"],
              padding: false,
              h_space: 5,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 331,
              am_y: 280,
              am_sc_path: 'Clock_AM.png',
              am_en_path: 'Clock_AM.png',
              pm_x: 331,
              pm_y: 280,
              pm_sc_path: 'Clock_PM.png',
              pm_en_path: 'Clock_PM.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 178,
              minute_startY: 193,
              minute_array: ["Time_Font_01.png","Time_Font_02.png","Time_Font_03.png","Time_Font_04.png","Time_Font_05.png","Time_Font_06.png","Time_Font_07.png","Time_Font_08.png","Time_Font_09.png","Time_Font_10.png"],
              minute_zero: 1,
              minute_space: 7,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_minute_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 274,
              y: 202,
              src: 'Time_Dot.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 59,
              hour_startY: 193,
              hour_array: ["Time_Font_01.png","Time_Font_02.png","Time_Font_03.png","Time_Font_04.png","Time_Font_05.png","Time_Font_06.png","Time_Font_07.png","Time_Font_08.png","Time_Font_09.png","Time_Font_10.png"],
              hour_zero: 1,
              hour_space: 7,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 155,
              y: 202,
              src: 'Time_Dot.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 218,
              y: 63,
              w: 161,
              h: 42,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 307,
              y: 342,
              w: 83,
              h: 67,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 219,
              y: 61,
              w: 162,
              h: 43,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 348,
              y: 123,
              w: 78,
              h: 43,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 211,
              y: 123,
              w: 110,
              h: 42,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 181,
              y: 341,
              w: 91,
              h: 42,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 296,
              y: 189,
              w: 90,
              h: 75,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 140,
              y: 193,
              w: 39,
              h: 70,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 86,
              y: 383,
              w: 78,
              h: 38,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 92,
              y: 67,
              w: 81,
              h: 82,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                // Switch info.( Steps,Distance,Calories )
click_elemente()

              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 84,
              y: 341,
              w: 81,
              h: 37,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PowerSaveHintScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 45,
              y: 279,
              w: 240,
              h: 48,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 171,
              y: 14,
              w: 129,
              h: 34,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'SportListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            console.log('Watch_Face.SwitchBackground');
            // Button_Switch_BG = hmUI.createWidget(hmUI.widget.SwitchBackground, {
              // x: 194,
              // y: 432,
              // w: 92,
              // h: 35,
              // text: '',
              // color: 0xFFFF8C00,
              // text_size: 25,
              // press_src: 'color2.png',
              // normal_src: 'color1.png',
              // bg_list: a_neo1|a_neo2|a_neo3|a_neo4|a_neo5|a_neo6,
              // toast_list: RED|BLUE|ORANGE|LEMON|GREEN|GRAY,
              // use_crown: False,
              // use_in_AOD: False,
              // vibro: False,
            // });

            Button_Switch_BG = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 194,
              y: 432,
              w: 92,
              h: 35,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'color2.png',
              normal_src: 'color1.png',
              click_func: (button_widget) => {
                switchBackground();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            console.log('user_script_end.js');
            // start user_script_end.js

if (cc==0){
UpdateElementeOne()
cc=1
}
            // end user_script_end.js

            function scale_call() {
              console.log('scale_call()');

                console.log('update scales CALORIE');
                
                let valueCalories = calorie.current;
                let targetCalories = calorie.target;
                let progressCalories = valueCalories/targetCalories;
                if (progressCalories > 1) progressCalories = 1;
                let progress_cs_normal_calorie = 1 - progressCalories;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_calorie_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_calorie * 100);
                  if (normal_calorie_circle_scale) {
                    normal_calorie_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 132,
                      center_y: 107,
                      start_angle: 451,
                      end_angle: 270,
                      radius: 58,
                      line_width: 10,
                      corner_flag: 3,
                      color: 0xFF454545,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_cs_normal_step = 1 - progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_step * 100);
                  if (normal_step_circle_scale) {
                    normal_step_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 132,
                      center_y: 107,
                      start_angle: 451,
                      end_angle: 270,
                      radius: 58,
                      line_width: 10,
                      corner_flag: 3,
                      color: 0xFF454545,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

              console.log('Weather city name');
              let weatherData = weatherSensor.getForecastWeather();
              normal_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

                console.log('update scales HEART');
                
                let valueHeartRate = heart_rate.last;
                let targetHeartRate = 179;
                let progressHeartRate = (valueHeartRate - 71)/(targetHeartRate - 71);
                if (progressHeartRate < 0) progressHeartRate = 0;
                if (progressHeartRate > 1) progressHeartRate = 1;
                let progress_cs_normal_heart_rate = 1 - progressHeartRate;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_heart_rate_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_heart_rate * 100);
                  if (normal_heart_rate_circle_scale) {
                    normal_heart_rate_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 347,
                      center_y: 372,
                      start_angle: 270,
                      end_angle: 90,
                      radius: 58,
                      line_width: 10,
                      corner_flag: 3,
                      color: 0xFF454545,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales STEP');
                let progress_cs_idle_step = 1 - progressStep;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_step_circle_scale_circle_scale
                  let level = Math.round(progress_cs_idle_step * 100);
                  if (idle_step_circle_scale) {
                    idle_step_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 132,
                      center_y: 107,
                      start_angle: 451,
                      end_angle: 270,
                      radius: 58,
                      line_width: 10,
                      corner_flag: 3,
                      color: 0xFF454545,
                      show_level: hmUI.show_level.ONLY_AOD,
                      level: level,
                    });
                  };
                };

              console.log('Weather city name');
              idle_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

                console.log('update scales HEART');
                let progress_cs_idle_heart_rate = 1 - progressHeartRate;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_heart_rate_circle_scale_circle_scale
                  let level = Math.round(progress_cs_idle_heart_rate * 100);
                  if (idle_heart_rate_circle_scale) {
                    idle_heart_rate_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 347,
                      center_y: 372,
                      start_angle: 270,
                      end_angle: 90,
                      radius: 58,
                      line_width: 10,
                      corner_flag: 3,
                      color: 0xFF454545,
                      show_level: hmUI.show_level.ONLY_AOD,
                      level: level,
                    });
                  };
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();

                //SwitchBackground
                if (hmFS.SysProGetInt(`backgroundIndex_${watchfaceId}`) === undefined) {
                  backgroundIndex = 0;
                  hmFS.SysProSetInt(`backgroundIndex_${watchfaceId}`, backgroundIndex);
                } else {
                  backgroundIndex = hmFS.SysProGetInt(`backgroundIndex_${watchfaceId}`);
                };
                if (screenType == hmSetting.screen_type.WATCHFACE && normal_background_bg_img) normal_background_bg_img.setProperty(hmUI.prop.SRC, backgroundList[backgroundIndex]);
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
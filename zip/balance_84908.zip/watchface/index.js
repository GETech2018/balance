﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_heart_rate_text_font = ''
        let normal_calorie_current_text_font = ''
        let normal_battery_current_text_font = ''
        let normal_battery_image_progress_img_level = ''
        let normal_distance_current_text_font = ''
        let normal_step_icon_img = ''
        let normal_step_current_text_font = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_font = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_time_second_text_font = ''
        let normal_timerTimeUpdate = undefined;
        let idle_background_bg = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_day = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''
        let idle_time_second_text_font = ''
        let idle_timerTimeUpdate = undefined;
        let normal_step_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: '00000.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 148,
              y: 42,
              src: 'bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 114,
              y: 43,
              src: 'ALARM.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 61,
              y: 339,
              w: 150,
              h: 30,
              text_size: 18,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 377,
              y: 339,
              w: 150,
              h: 46,
              text_size: 18,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 166,
              y: 396,
              w: 150,
              h: 50,
              text_size: 27,
              char_space: 0,
              line_space: 0,
              color: 0xFFFF80C0,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 98,
              y: 405,
              image_array: ["EN-00.png","EN-01.png","EN-02.png","EN-03.png","EN-04.png","EN-05.png","EN-06.png","EN-07.png","EN-08.png","EN-09.png","EN-10.png","EN-11.png","EN-12.png"],
              image_length: 13,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 256,
              y: 331,
              w: 150,
              h: 49,
              text_size: 29,
              char_space: 0,
              line_space: 0,
              color: 0xFFFF80C0,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 208,
              y: 328,
              src: 'walk2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 59,
              y: 331,
              w: 150,
              h: 49,
              text_size: 29,
              char_space: 0,
              line_space: 0,
              color: 0xFFFF80C0,
              align_h: hmUI.align.RIGHT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 193,
              y: 0,
              image_array: ["METEO01.png","METEO02.png","METEO03.png","METEO04.png","METEO05.png","METEO06.png","METEO07.png","METEO08.png","METEO09.png","METEO10.png","METEO11.png","METEO12.png","METEO13.png","METEO14.png","METEO15.png","METEO16.png","METEO17.png","METEO18.png","METEO19.png","METEO20.png","METEO21.png","METEO22.png","METEO23.png","METEO24.png","METEO25.png","METEO26.png","METEO27.png","METEO28.png","METEO29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 244,
              y: 28,
              w: 150,
              h: 49,
              text_size: 31,
              char_space: 0,
              line_space: 0,
              color: 0xFFFF80C0,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 284,
              month_startY: 114,
              month_sc_array: ["MO-01.png","MO-02.png","MO-03.png","MO-04.png","MO-05.png","MO-06.png","MO-07.png","MO-08.png","MO-09.png","MO-10.png","MO-11.png","MO-12.png"],
              month_tc_array: ["MO-01.png","MO-02.png","MO-03.png","MO-04.png","MO-05.png","MO-06.png","MO-07.png","MO-08.png","MO-09.png","MO-10.png","MO-11.png","MO-12.png"],
              month_en_array: ["MO-01.png","MO-02.png","MO-03.png","MO-04.png","MO-05.png","MO-06.png","MO-07.png","MO-08.png","MO-09.png","MO-10.png","MO-11.png","MO-12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 51,
              y: 113,
              week_en: ["J-01.png","J-02.png","J-03.png","J-04.png","J-05.png","J-06.png","J-07.png"],
              week_tc: ["J-01.png","J-02.png","J-03.png","J-04.png","J-05.png","J-06.png","J-07.png"],
              week_sc: ["J-01.png","J-02.png","J-03.png","J-04.png","J-05.png","J-06.png","J-07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 198,
              day_startY: 107,
              day_sc_array: ["CHIF_00.png","CHIF_01.png","CHIF_02.png","CHIF_03.png","CHIF_04.png","CHIF_05.png","CHIF_06.png","CHIF_07.png","CHIF_08.png","CHIF_09.png"],
              day_tc_array: ["CHIF_00.png","CHIF_01.png","CHIF_02.png","CHIF_03.png","CHIF_04.png","CHIF_05.png","CHIF_06.png","CHIF_07.png","CHIF_08.png","CHIF_09.png"],
              day_en_array: ["CHIF_00.png","CHIF_01.png","CHIF_02.png","CHIF_03.png","CHIF_04.png","CHIF_05.png","CHIF_06.png","CHIF_07.png","CHIF_08.png","CHIF_09.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 22,
              hour_startY: 182,
              hour_array: ["RAYURES00.png","RAYURES01.png","RAYURES02.png","RAYURES03.png","RAYURES04.png","RAYURES05.png","RAYURES06.png","RAYURES07.png","RAYURES08.png","RAYURES09.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 269,
              minute_startY: 182,
              minute_array: ["RAYURES00.png","RAYURES01.png","RAYURES02.png","RAYURES03.png","RAYURES04.png","RAYURES05.png","RAYURES06.png","RAYURES07.png","RAYURES08.png","RAYURES09.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 195,
              y: 168,
              src: 'RAYURES10.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            let screenType = hmSetting.getScreenType();
            normal_time_second_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 158,
              y: 273,
              w: 150,
              h: 45,
              text_size: 27,
              char_space: 0,
              line_space: 0,
              color: 0xFFFF80C0,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFF390039',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 290,
              month_startY: 114,
              month_sc_array: ["MO-01.png","MO-02.png","MO-03.png","MO-04.png","MO-05.png","MO-06.png","MO-07.png","MO-08.png","MO-09.png","MO-10.png","MO-11.png","MO-12.png"],
              month_tc_array: ["MO-01.png","MO-02.png","MO-03.png","MO-04.png","MO-05.png","MO-06.png","MO-07.png","MO-08.png","MO-09.png","MO-10.png","MO-11.png","MO-12.png"],
              month_en_array: ["MO-01.png","MO-02.png","MO-03.png","MO-04.png","MO-05.png","MO-06.png","MO-07.png","MO-08.png","MO-09.png","MO-10.png","MO-11.png","MO-12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 48,
              y: 113,
              week_en: ["J-01.png","J-02.png","J-03.png","J-04.png","J-05.png","J-06.png","J-07.png"],
              week_tc: ["J-01.png","J-02.png","J-03.png","J-04.png","J-05.png","J-06.png","J-07.png"],
              week_sc: ["J-01.png","J-02.png","J-03.png","J-04.png","J-05.png","J-06.png","J-07.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 199,
              day_startY: 106,
              day_sc_array: ["CHIF_00.png","CHIF_01.png","CHIF_02.png","CHIF_03.png","CHIF_04.png","CHIF_05.png","CHIF_06.png","CHIF_07.png","CHIF_08.png","CHIF_09.png"],
              day_tc_array: ["CHIF_00.png","CHIF_01.png","CHIF_02.png","CHIF_03.png","CHIF_04.png","CHIF_05.png","CHIF_06.png","CHIF_07.png","CHIF_08.png","CHIF_09.png"],
              day_en_array: ["CHIF_00.png","CHIF_01.png","CHIF_02.png","CHIF_03.png","CHIF_04.png","CHIF_05.png","CHIF_06.png","CHIF_07.png","CHIF_08.png","CHIF_09.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 22,
              hour_startY: 182,
              hour_array: ["RAYURES00.png","RAYURES01.png","RAYURES02.png","RAYURES03.png","RAYURES04.png","RAYURES05.png","RAYURES06.png","RAYURES07.png","RAYURES08.png","RAYURES09.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 269,
              minute_startY: 182,
              minute_array: ["RAYURES00.png","RAYURES01.png","RAYURES02.png","RAYURES03.png","RAYURES04.png","RAYURES05.png","RAYURES06.png","RAYURES07.png","RAYURES08.png","RAYURES09.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 195,
              y: 168,
              src: 'RAYURES10.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_time_second_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 158,
              y: 273,
              w: 150,
              h: 45,
              text_size: 27,
              char_space: 0,
              line_space: 0,
              color: 0xFFFF80C0,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              // padding: true,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 137,
              y: 328,
              w: 200,
              h: 50,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 101,
              y: 32,
              w: 50,
              h: 50,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            //start of ignored block
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              console.log('second font');
                let normal_secondStr = second.toString();
                normal_secondStr = normal_secondStr.padStart(2, '0');
                normal_time_second_text_font.setProperty(hmUI.prop.TEXT, normal_secondStr );
              console.log('second font');
                let idle_secondStr = second.toString();
                idle_secondStr = idle_secondStr.padStart(2, '0');
                idle_time_second_text_font.setProperty(hmUI.prop.TEXT, idle_secondStr );
            };

            //end of ignored block
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                time_update(true, true);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerTimeUpdate) {
                    normal_timerTimeUpdate = timer.createTimer(0, 1000, (function (option) {
                      let updateHour = timeSensor.minute == 0 && timeSensor.second < 2;
                      let updateMinute = timeSensor.second < 2;
                      time_update(updateHour, updateMinute);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.AOD) {
                  if (!idle_timerTimeUpdate) {
                    idle_timerTimeUpdate = timer.createTimer(0, 1000, (function (option) {
                      let updateHour = timeSensor.minute == 0 && timeSensor.second < 2;
                      let updateMinute = timeSensor.second < 2;
                      time_update(updateHour, updateMinute);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerTimeUpdate) {
                  timer.stopTimer(normal_timerTimeUpdate);
                  normal_timerTimeUpdate = undefined;
                }
                if (idle_timerTimeUpdate) {
                  timer.stopTimer(idle_timerTimeUpdate);
                  idle_timerTimeUpdate = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
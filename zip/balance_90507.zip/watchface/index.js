try {
    ((() => {
        const {beforeModuleCreate = () => {
            }, afterModuleCreate = () => {
            }} = DeviceRuntimeCore.LifeCycle;
        beforeModuleCreate();
        const {beforePageCreate = () => {
            }, afterPageCreate = () => {
            }} = DeviceRuntimeCore.LifeCycle;
        beforePageCreate();
        const __$$G$$__ = __$$hmAppManager$$__.currentApp.current.__globals__.__$$G$$__;
        !function (context) {
            with (context) {
                const __$$RQR$$__ = __$$R$$__;
                const ui = __$$RQR$$__('@zos/ui');
                const app = __$$RQR$$__('@zos/app');
                const sensor = __$$RQR$$__('@zos/sensor');
                const storage = __$$RQR$$__('@zos/storage');
                const router = __$$RQR$$__('@zos/router');
                const settings = __$$RQR$$__('@zos/settings');
                const _interopDefaultCompat = e => e && typeof e === 'object' && 'default' in e ? e : { default: e };
                const ui__default = _interopDefaultCompat(ui);
                const R = {
                    'glyphs': {
                        'cream-190': {
                            '0': {
                                'src': 'cream-190/0.png',
                                'w': 112,
                                'h': 146
                            },
                            '1': {
                                'src': 'cream-190/1.png',
                                'w': 112,
                                'h': 146
                            },
                            '2': {
                                'src': 'cream-190/2.png',
                                'w': 112,
                                'h': 146
                            },
                            '3': {
                                'src': 'cream-190/3.png',
                                'w': 112,
                                'h': 146
                            },
                            '4': {
                                'src': 'cream-190/4.png',
                                'w': 112,
                                'h': 146
                            },
                            '5': {
                                'src': 'cream-190/5.png',
                                'w': 112,
                                'h': 146
                            },
                            '6': {
                                'src': 'cream-190/6.png',
                                'w': 112,
                                'h': 146
                            },
                            '7': {
                                'src': 'cream-190/7.png',
                                'w': 112,
                                'h': 146
                            },
                            '8': {
                                'src': 'cream-190/8.png',
                                'w': 112,
                                'h': 146
                            },
                            '9': {
                                'src': 'cream-190/9.png',
                                'w': 112,
                                'h': 146
                            },
                            '.': {
                                'src': 'cream-190/dot.png',
                                'w': 12,
                                'h': 146
                            },
                            '-': {
                                'src': 'cream-190/minus.png',
                                'w': 61,
                                'h': 146
                            }
                        },
                        'cream-64': {
                            '0': {
                                'src': 'cream-64/0.png',
                                'w': 40,
                                'h': 49
                            },
                            '1': {
                                'src': 'cream-64/1.png',
                                'w': 40,
                                'h': 49
                            },
                            '2': {
                                'src': 'cream-64/2.png',
                                'w': 40,
                                'h': 49
                            },
                            '3': {
                                'src': 'cream-64/3.png',
                                'w': 40,
                                'h': 49
                            },
                            '4': {
                                'src': 'cream-64/4.png',
                                'w': 40,
                                'h': 49
                            },
                            '5': {
                                'src': 'cream-64/5.png',
                                'w': 40,
                                'h': 49
                            },
                            '6': {
                                'src': 'cream-64/6.png',
                                'w': 40,
                                'h': 49
                            },
                            '7': {
                                'src': 'cream-64/7.png',
                                'w': 40,
                                'h': 49
                            },
                            '8': {
                                'src': 'cream-64/8.png',
                                'w': 40,
                                'h': 49
                            },
                            '9': {
                                'src': 'cream-64/9.png',
                                'w': 40,
                                'h': 49
                            },
                            '.': {
                                'src': 'cream-64/dot.png',
                                'w': 12,
                                'h': 49
                            },
                            '-': {
                                'src': 'cream-64/minus.png',
                                'w': 21,
                                'h': 49
                            }
                        },
                        'cream-56': {
                            '0': {
                                'src': 'cream-56/0.png',
                                'w': 35,
                                'h': 43
                            },
                            '1': {
                                'src': 'cream-56/1.png',
                                'w': 35,
                                'h': 43
                            },
                            '2': {
                                'src': 'cream-56/2.png',
                                'w': 35,
                                'h': 43
                            },
                            '3': {
                                'src': 'cream-56/3.png',
                                'w': 35,
                                'h': 43
                            },
                            '4': {
                                'src': 'cream-56/4.png',
                                'w': 35,
                                'h': 43
                            },
                            '5': {
                                'src': 'cream-56/5.png',
                                'w': 35,
                                'h': 43
                            },
                            '6': {
                                'src': 'cream-56/6.png',
                                'w': 35,
                                'h': 43
                            },
                            '7': {
                                'src': 'cream-56/7.png',
                                'w': 35,
                                'h': 43
                            },
                            '8': {
                                'src': 'cream-56/8.png',
                                'w': 35,
                                'h': 43
                            },
                            '9': {
                                'src': 'cream-56/9.png',
                                'w': 35,
                                'h': 43
                            },
                            '.': {
                                'src': 'cream-56/dot.png',
                                'w': 12,
                                'h': 43
                            },
                            '-': {
                                'src': 'cream-56/minus.png',
                                'w': 18,
                                'h': 43
                            }
                        },
                        'cream-52': {
                            '0': {
                                'src': 'cream-52/48.png',
                                'w': 31,
                                'h': 39
                            },
                            '1': {
                                'src': 'cream-52/49.png',
                                'w': 31,
                                'h': 37
                            },
                            '2': {
                                'src': 'cream-52/50.png',
                                'w': 31,
                                'h': 38
                            },
                            '3': {
                                'src': 'cream-52/51.png',
                                'w': 31,
                                'h': 39
                            },
                            '4': {
                                'src': 'cream-52/52.png',
                                'w': 31,
                                'h': 37
                            },
                            '5': {
                                'src': 'cream-52/53.png',
                                'w': 31,
                                'h': 38
                            },
                            '6': {
                                'src': 'cream-52/54.png',
                                'w': 31,
                                'h': 39
                            },
                            '7': {
                                'src': 'cream-52/55.png',
                                'w': 31,
                                'h': 37
                            },
                            '8': {
                                'src': 'cream-52/56.png',
                                'w': 31,
                                'h': 39
                            },
                            '9': {
                                'src': 'cream-52/57.png',
                                'w': 31,
                                'h': 38
                            },
                            '%': {
                                'src': 'cream-52/37.png',
                                'w': 50,
                                'h': 39
                            },
                            '-': {
                                'src': 'cream-52/45.png',
                                'w': 17,
                                'h': 18
                            }
                        },
                        'gold-190': {
                            '0': {
                                'src': 'gold-190/0.png',
                                'w': 112,
                                'h': 146
                            },
                            '1': {
                                'src': 'gold-190/1.png',
                                'w': 112,
                                'h': 146
                            },
                            '2': {
                                'src': 'gold-190/2.png',
                                'w': 112,
                                'h': 146
                            },
                            '3': {
                                'src': 'gold-190/3.png',
                                'w': 112,
                                'h': 146
                            },
                            '4': {
                                'src': 'gold-190/4.png',
                                'w': 112,
                                'h': 146
                            },
                            '5': {
                                'src': 'gold-190/5.png',
                                'w': 112,
                                'h': 146
                            },
                            '6': {
                                'src': 'gold-190/6.png',
                                'w': 112,
                                'h': 146
                            },
                            '7': {
                                'src': 'gold-190/7.png',
                                'w': 112,
                                'h': 146
                            },
                            '8': {
                                'src': 'gold-190/8.png',
                                'w': 112,
                                'h': 146
                            },
                            '9': {
                                'src': 'gold-190/9.png',
                                'w': 112,
                                'h': 146
                            },
                            '.': {
                                'src': 'gold-190/dot.png',
                                'w': 12,
                                'h': 146
                            },
                            '-': {
                                'src': 'gold-190/minus.png',
                                'w': 61,
                                'h': 146
                            }
                        },
                        'gold-64': {
                            '0': {
                                'src': 'gold-64/0.png',
                                'w': 40,
                                'h': 49
                            },
                            '1': {
                                'src': 'gold-64/1.png',
                                'w': 40,
                                'h': 49
                            },
                            '2': {
                                'src': 'gold-64/2.png',
                                'w': 40,
                                'h': 49
                            },
                            '3': {
                                'src': 'gold-64/3.png',
                                'w': 40,
                                'h': 49
                            },
                            '4': {
                                'src': 'gold-64/4.png',
                                'w': 40,
                                'h': 49
                            },
                            '5': {
                                'src': 'gold-64/5.png',
                                'w': 40,
                                'h': 49
                            },
                            '6': {
                                'src': 'gold-64/6.png',
                                'w': 40,
                                'h': 49
                            },
                            '7': {
                                'src': 'gold-64/7.png',
                                'w': 40,
                                'h': 49
                            },
                            '8': {
                                'src': 'gold-64/8.png',
                                'w': 40,
                                'h': 49
                            },
                            '9': {
                                'src': 'gold-64/9.png',
                                'w': 40,
                                'h': 49
                            },
                            '.': {
                                'src': 'gold-64/dot.png',
                                'w': 12,
                                'h': 49
                            },
                            '-': {
                                'src': 'gold-64/minus.png',
                                'w': 21,
                                'h': 49
                            }
                        },
                        'gold-56': {
                            '0': {
                                'src': 'gold-56/0.png',
                                'w': 35,
                                'h': 43
                            },
                            '1': {
                                'src': 'gold-56/1.png',
                                'w': 35,
                                'h': 43
                            },
                            '2': {
                                'src': 'gold-56/2.png',
                                'w': 35,
                                'h': 43
                            },
                            '3': {
                                'src': 'gold-56/3.png',
                                'w': 35,
                                'h': 43
                            },
                            '4': {
                                'src': 'gold-56/4.png',
                                'w': 35,
                                'h': 43
                            },
                            '5': {
                                'src': 'gold-56/5.png',
                                'w': 35,
                                'h': 43
                            },
                            '6': {
                                'src': 'gold-56/6.png',
                                'w': 35,
                                'h': 43
                            },
                            '7': {
                                'src': 'gold-56/7.png',
                                'w': 35,
                                'h': 43
                            },
                            '8': {
                                'src': 'gold-56/8.png',
                                'w': 35,
                                'h': 43
                            },
                            '9': {
                                'src': 'gold-56/9.png',
                                'w': 35,
                                'h': 43
                            },
                            '.': {
                                'src': 'gold-56/dot.png',
                                'w': 12,
                                'h': 43
                            },
                            '-': {
                                'src': 'gold-56/minus.png',
                                'w': 18,
                                'h': 43
                            }
                        },
                        'gold-52': {
                            '0': {
                                'src': 'gold-52/48.png',
                                'w': 31,
                                'h': 39
                            },
                            '1': {
                                'src': 'gold-52/49.png',
                                'w': 31,
                                'h': 37
                            },
                            '2': {
                                'src': 'gold-52/50.png',
                                'w': 31,
                                'h': 38
                            },
                            '3': {
                                'src': 'gold-52/51.png',
                                'w': 31,
                                'h': 39
                            },
                            '4': {
                                'src': 'gold-52/52.png',
                                'w': 31,
                                'h': 37
                            },
                            '5': {
                                'src': 'gold-52/53.png',
                                'w': 31,
                                'h': 38
                            },
                            '6': {
                                'src': 'gold-52/54.png',
                                'w': 31,
                                'h': 39
                            },
                            '7': {
                                'src': 'gold-52/55.png',
                                'w': 31,
                                'h': 37
                            },
                            '8': {
                                'src': 'gold-52/56.png',
                                'w': 31,
                                'h': 39
                            },
                            '9': {
                                'src': 'gold-52/57.png',
                                'w': 31,
                                'h': 38
                            },
                            '%': {
                                'src': 'gold-52/37.png',
                                'w': 50,
                                'h': 39
                            },
                            '-': {
                                'src': 'gold-52/45.png',
                                'w': 17,
                                'h': 18
                            }
                        },
                        'silver-190': {
                            '0': {
                                'src': 'silver-190/0.png',
                                'w': 112,
                                'h': 146
                            },
                            '1': {
                                'src': 'silver-190/1.png',
                                'w': 112,
                                'h': 146
                            },
                            '2': {
                                'src': 'silver-190/2.png',
                                'w': 112,
                                'h': 146
                            },
                            '3': {
                                'src': 'silver-190/3.png',
                                'w': 112,
                                'h': 146
                            },
                            '4': {
                                'src': 'silver-190/4.png',
                                'w': 112,
                                'h': 146
                            },
                            '5': {
                                'src': 'silver-190/5.png',
                                'w': 112,
                                'h': 146
                            },
                            '6': {
                                'src': 'silver-190/6.png',
                                'w': 112,
                                'h': 146
                            },
                            '7': {
                                'src': 'silver-190/7.png',
                                'w': 112,
                                'h': 146
                            },
                            '8': {
                                'src': 'silver-190/8.png',
                                'w': 112,
                                'h': 146
                            },
                            '9': {
                                'src': 'silver-190/9.png',
                                'w': 112,
                                'h': 146
                            },
                            '.': {
                                'src': 'silver-190/dot.png',
                                'w': 12,
                                'h': 146
                            },
                            '-': {
                                'src': 'silver-190/minus.png',
                                'w': 61,
                                'h': 146
                            }
                        },
                        'silver-64': {
                            '0': {
                                'src': 'silver-64/0.png',
                                'w': 40,
                                'h': 49
                            },
                            '1': {
                                'src': 'silver-64/1.png',
                                'w': 40,
                                'h': 49
                            },
                            '2': {
                                'src': 'silver-64/2.png',
                                'w': 40,
                                'h': 49
                            },
                            '3': {
                                'src': 'silver-64/3.png',
                                'w': 40,
                                'h': 49
                            },
                            '4': {
                                'src': 'silver-64/4.png',
                                'w': 40,
                                'h': 49
                            },
                            '5': {
                                'src': 'silver-64/5.png',
                                'w': 40,
                                'h': 49
                            },
                            '6': {
                                'src': 'silver-64/6.png',
                                'w': 40,
                                'h': 49
                            },
                            '7': {
                                'src': 'silver-64/7.png',
                                'w': 40,
                                'h': 49
                            },
                            '8': {
                                'src': 'silver-64/8.png',
                                'w': 40,
                                'h': 49
                            },
                            '9': {
                                'src': 'silver-64/9.png',
                                'w': 40,
                                'h': 49
                            },
                            '.': {
                                'src': 'silver-64/dot.png',
                                'w': 12,
                                'h': 49
                            },
                            '-': {
                                'src': 'silver-64/minus.png',
                                'w': 21,
                                'h': 49
                            }
                        },
                        'silver-56': {
                            '0': {
                                'src': 'silver-56/0.png',
                                'w': 35,
                                'h': 43
                            },
                            '1': {
                                'src': 'silver-56/1.png',
                                'w': 35,
                                'h': 43
                            },
                            '2': {
                                'src': 'silver-56/2.png',
                                'w': 35,
                                'h': 43
                            },
                            '3': {
                                'src': 'silver-56/3.png',
                                'w': 35,
                                'h': 43
                            },
                            '4': {
                                'src': 'silver-56/4.png',
                                'w': 35,
                                'h': 43
                            },
                            '5': {
                                'src': 'silver-56/5.png',
                                'w': 35,
                                'h': 43
                            },
                            '6': {
                                'src': 'silver-56/6.png',
                                'w': 35,
                                'h': 43
                            },
                            '7': {
                                'src': 'silver-56/7.png',
                                'w': 35,
                                'h': 43
                            },
                            '8': {
                                'src': 'silver-56/8.png',
                                'w': 35,
                                'h': 43
                            },
                            '9': {
                                'src': 'silver-56/9.png',
                                'w': 35,
                                'h': 43
                            },
                            '.': {
                                'src': 'silver-56/dot.png',
                                'w': 12,
                                'h': 43
                            },
                            '-': {
                                'src': 'silver-56/minus.png',
                                'w': 18,
                                'h': 43
                            }
                        },
                        'silver-52': {
                            '0': {
                                'src': 'silver-52/48.png',
                                'w': 31,
                                'h': 39
                            },
                            '1': {
                                'src': 'silver-52/49.png',
                                'w': 31,
                                'h': 37
                            },
                            '2': {
                                'src': 'silver-52/50.png',
                                'w': 31,
                                'h': 38
                            },
                            '3': {
                                'src': 'silver-52/51.png',
                                'w': 31,
                                'h': 39
                            },
                            '4': {
                                'src': 'silver-52/52.png',
                                'w': 31,
                                'h': 37
                            },
                            '5': {
                                'src': 'silver-52/53.png',
                                'w': 31,
                                'h': 38
                            },
                            '6': {
                                'src': 'silver-52/54.png',
                                'w': 31,
                                'h': 39
                            },
                            '7': {
                                'src': 'silver-52/55.png',
                                'w': 31,
                                'h': 37
                            },
                            '8': {
                                'src': 'silver-52/56.png',
                                'w': 31,
                                'h': 39
                            },
                            '9': {
                                'src': 'silver-52/57.png',
                                'w': 31,
                                'h': 38
                            },
                            '%': {
                                'src': 'silver-52/37.png',
                                'w': 50,
                                'h': 39
                            },
                            '-': {
                                'src': 'silver-52/45.png',
                                'w': 17,
                                'h': 18
                            }
                        }
                    },
                    'words': {
                        'gold-30-ArtIst': {
                            'src': 'words/0.png',
                            'w': 79,
                            'h': 23
                        },
                        'cream-34-MON': {
                            'src': 'words/1.png',
                            'w': 89,
                            'h': 25
                        },
                        'cream-34-TUE': {
                            'src': 'words/2.png',
                            'w': 65,
                            'h': 25
                        },
                        'cream-34-WED': {
                            'src': 'words/3.png',
                            'w': 79,
                            'h': 25
                        },
                        'cream-34-THU': {
                            'src': 'words/4.png',
                            'w': 72,
                            'h': 25
                        },
                        'cream-34-FRI': {
                            'src': 'words/5.png',
                            'w': 54,
                            'h': 25
                        },
                        'cream-34-SAT': {
                            'src': 'words/6.png',
                            'w': 62,
                            'h': 25
                        },
                        'cream-34-SUN': {
                            'src': 'words/7.png',
                            'w': 74,
                            'h': 25
                        },
                        'cream-40-JAN': {
                            'src': 'words/8.png',
                            'w': 80,
                            'h': 38
                        },
                        'cream-40-FEB': {
                            'src': 'words/9.png',
                            'w': 71,
                            'h': 29
                        },
                        'cream-40-MAR': {
                            'src': 'words/10.png',
                            'w': 96,
                            'h': 29
                        },
                        'cream-40-APR': {
                            'src': 'words/11.png',
                            'w': 82,
                            'h': 29
                        },
                        'cream-40-MAY': {
                            'src': 'words/12.png',
                            'w': 92,
                            'h': 29
                        },
                        'cream-40-JUN': {
                            'src': 'words/13.png',
                            'w': 81,
                            'h': 38
                        },
                        'cream-40-JUL': {
                            'src': 'words/14.png',
                            'w': 71,
                            'h': 38
                        },
                        'cream-40-AUG': {
                            'src': 'words/15.png',
                            'w': 89,
                            'h': 30
                        },
                        'cream-40-SEP': {
                            'src': 'words/16.png',
                            'w': 71,
                            'h': 30
                        },
                        'cream-40-OCT': {
                            'src': 'words/17.png',
                            'w': 82,
                            'h': 30
                        },
                        'cream-40-NOV': {
                            'src': 'words/18.png',
                            'w': 93,
                            'h': 30
                        },
                        'cream-40-DEC': {
                            'src': 'words/19.png',
                            'w': 78,
                            'h': 30
                        },
                        'gold-82-1': {
                            'src': 'words/20.png',
                            'w': 48,
                            'h': 59
                        },
                        'gold-82-2': {
                            'src': 'words/21.png',
                            'w': 48,
                            'h': 60
                        },
                        'gold-82-3': {
                            'src': 'words/22.png',
                            'w': 48,
                            'h': 61
                        },
                        'gold-82-4': {
                            'src': 'words/23.png',
                            'w': 48,
                            'h': 59
                        },
                        'gold-82-5': {
                            'src': 'words/24.png',
                            'w': 48,
                            'h': 60
                        },
                        'gold-82-6': {
                            'src': 'words/25.png',
                            'w': 48,
                            'h': 61
                        },
                        'gold-82-7': {
                            'src': 'words/26.png',
                            'w': 48,
                            'h': 59
                        },
                        'gold-82-8': {
                            'src': 'words/27.png',
                            'w': 48,
                            'h': 61
                        },
                        'gold-82-9': {
                            'src': 'words/28.png',
                            'w': 48,
                            'h': 60
                        },
                        'gold-82-10': {
                            'src': 'words/29.png',
                            'w': 96,
                            'h': 61
                        },
                        'gold-82-11': {
                            'src': 'words/30.png',
                            'w': 96,
                            'h': 59
                        },
                        'gold-82-12': {
                            'src': 'words/31.png',
                            'w': 96,
                            'h': 60
                        },
                        'gold-82-13': {
                            'src': 'words/32.png',
                            'w': 96,
                            'h': 61
                        },
                        'gold-82-14': {
                            'src': 'words/33.png',
                            'w': 96,
                            'h': 59
                        },
                        'gold-82-15': {
                            'src': 'words/34.png',
                            'w': 96,
                            'h': 60
                        },
                        'gold-82-16': {
                            'src': 'words/35.png',
                            'w': 96,
                            'h': 61
                        },
                        'gold-82-17': {
                            'src': 'words/36.png',
                            'w': 96,
                            'h': 59
                        },
                        'gold-82-18': {
                            'src': 'words/37.png',
                            'w': 96,
                            'h': 61
                        },
                        'gold-82-19': {
                            'src': 'words/38.png',
                            'w': 96,
                            'h': 60
                        },
                        'gold-82-20': {
                            'src': 'words/39.png',
                            'w': 96,
                            'h': 61
                        },
                        'gold-82-21': {
                            'src': 'words/40.png',
                            'w': 96,
                            'h': 60
                        },
                        'gold-82-22': {
                            'src': 'words/41.png',
                            'w': 96,
                            'h': 60
                        },
                        'gold-82-23': {
                            'src': 'words/42.png',
                            'w': 96,
                            'h': 61
                        },
                        'gold-82-24': {
                            'src': 'words/43.png',
                            'w': 96,
                            'h': 60
                        },
                        'gold-82-25': {
                            'src': 'words/44.png',
                            'w': 96,
                            'h': 61
                        },
                        'gold-82-26': {
                            'src': 'words/45.png',
                            'w': 96,
                            'h': 61
                        },
                        'gold-82-27': {
                            'src': 'words/46.png',
                            'w': 96,
                            'h': 60
                        },
                        'gold-82-28': {
                            'src': 'words/47.png',
                            'w': 96,
                            'h': 61
                        },
                        'gold-82-29': {
                            'src': 'words/48.png',
                            'w': 96,
                            'h': 61
                        },
                        'gold-82-30': {
                            'src': 'words/49.png',
                            'w': 96,
                            'h': 61
                        },
                        'gold-82-31': {
                            'src': 'words/50.png',
                            'w': 96,
                            'h': 61
                        },
                        'cream-33-HR': {
                            'src': 'words/51.png',
                            'w': 48,
                            'h': 24
                        },
                        'cream-33-\xB0C': {
                            'src': 'words/52.png',
                            'w': 36,
                            'h': 25
                        },
                        'cream-33-\xB0F': {
                            'src': 'words/53.png',
                            'w': 32,
                            'h': 24
                        },
                        'cream-33-%': {
                            'src': 'words/54.png',
                            'w': 32,
                            'h': 25
                        },
                        'cream-33-Bft': {
                            'src': 'words/55.png',
                            'w': 51,
                            'h': 26
                        },
                        'cream-30-km': {
                            'src': 'words/56.png',
                            'w': 50,
                            'h': 23
                        },
                        'cream-30-mi': {
                            'src': 'words/57.png',
                            'w': 40,
                            'h': 24
                        },
                        'cream-30-kcal': {
                            'src': 'words/58.png',
                            'w': 64,
                            'h': 23
                        },
                        'cream-30-hPa': {
                            'src': 'words/59.png',
                            'w': 58,
                            'h': 23
                        },
                        'cream-128-DE': {
                            'src': 'words/60.png',
                            'w': 165,
                            'h': 92
                        },
                        'cream-128-MO': {
                            'src': 'words/61.png',
                            'w': 226,
                            'h': 94
                        },
                        'cream-30-ArtIst': {
                            'src': 'words/62.png',
                            'w': 79,
                            'h': 23
                        },
                        'cream-82-1': {
                            'src': 'words/63.png',
                            'w': 48,
                            'h': 59
                        },
                        'cream-82-2': {
                            'src': 'words/64.png',
                            'w': 48,
                            'h': 60
                        },
                        'cream-82-3': {
                            'src': 'words/65.png',
                            'w': 48,
                            'h': 61
                        },
                        'cream-82-4': {
                            'src': 'words/66.png',
                            'w': 48,
                            'h': 59
                        },
                        'cream-82-5': {
                            'src': 'words/67.png',
                            'w': 48,
                            'h': 60
                        },
                        'cream-82-6': {
                            'src': 'words/68.png',
                            'w': 48,
                            'h': 61
                        },
                        'cream-82-7': {
                            'src': 'words/69.png',
                            'w': 48,
                            'h': 59
                        },
                        'cream-82-8': {
                            'src': 'words/70.png',
                            'w': 48,
                            'h': 61
                        },
                        'cream-82-9': {
                            'src': 'words/71.png',
                            'w': 48,
                            'h': 60
                        },
                        'cream-82-10': {
                            'src': 'words/72.png',
                            'w': 96,
                            'h': 61
                        },
                        'cream-82-11': {
                            'src': 'words/73.png',
                            'w': 96,
                            'h': 59
                        },
                        'cream-82-12': {
                            'src': 'words/74.png',
                            'w': 96,
                            'h': 60
                        },
                        'cream-82-13': {
                            'src': 'words/75.png',
                            'w': 96,
                            'h': 61
                        },
                        'cream-82-14': {
                            'src': 'words/76.png',
                            'w': 96,
                            'h': 59
                        },
                        'cream-82-15': {
                            'src': 'words/77.png',
                            'w': 96,
                            'h': 60
                        },
                        'cream-82-16': {
                            'src': 'words/78.png',
                            'w': 96,
                            'h': 61
                        },
                        'cream-82-17': {
                            'src': 'words/79.png',
                            'w': 96,
                            'h': 59
                        },
                        'cream-82-18': {
                            'src': 'words/80.png',
                            'w': 96,
                            'h': 61
                        },
                        'cream-82-19': {
                            'src': 'words/81.png',
                            'w': 96,
                            'h': 60
                        },
                        'cream-82-20': {
                            'src': 'words/82.png',
                            'w': 96,
                            'h': 61
                        },
                        'cream-82-21': {
                            'src': 'words/83.png',
                            'w': 96,
                            'h': 60
                        },
                        'cream-82-22': {
                            'src': 'words/84.png',
                            'w': 96,
                            'h': 60
                        },
                        'cream-82-23': {
                            'src': 'words/85.png',
                            'w': 96,
                            'h': 61
                        },
                        'cream-82-24': {
                            'src': 'words/86.png',
                            'w': 96,
                            'h': 60
                        },
                        'cream-82-25': {
                            'src': 'words/87.png',
                            'w': 96,
                            'h': 61
                        },
                        'cream-82-26': {
                            'src': 'words/88.png',
                            'w': 96,
                            'h': 61
                        },
                        'cream-82-27': {
                            'src': 'words/89.png',
                            'w': 96,
                            'h': 60
                        },
                        'cream-82-28': {
                            'src': 'words/90.png',
                            'w': 96,
                            'h': 61
                        },
                        'cream-82-29': {
                            'src': 'words/91.png',
                            'w': 96,
                            'h': 61
                        },
                        'cream-82-30': {
                            'src': 'words/92.png',
                            'w': 96,
                            'h': 61
                        },
                        'cream-82-31': {
                            'src': 'words/93.png',
                            'w': 96,
                            'h': 61
                        },
                        'gold-128-DE': {
                            'src': 'words/94.png',
                            'w': 165,
                            'h': 92
                        },
                        'gold-128-MO': {
                            'src': 'words/95.png',
                            'w': 226,
                            'h': 94
                        },
                        'silver-128-DE': {
                            'src': 'words/96.png',
                            'w': 165,
                            'h': 92
                        },
                        'silver-128-MO': {
                            'src': 'words/97.png',
                            'w': 226,
                            'h': 94
                        }
                    },
                    'themes': [
                        {
                            'name': 'cream',
                            'main': 'cream',
                            'accent': 'gold',
                            'label': 'cream',
                            'separator': {
                                'src': 't0-separator.png',
                                'w': 64,
                                'h': 22
                            },
                            'rule': {
                                'src': 't0-rule.png',
                                'w': 27,
                                'h': 2
                            },
                            'logo': {
                                'src': 'words/0.png',
                                'w': 79,
                                'h': 23
                            },
                            'weeks': [
                                {
                                    'src': 'words/1.png',
                                    'w': 89,
                                    'h': 25
                                },
                                {
                                    'src': 'words/2.png',
                                    'w': 65,
                                    'h': 25
                                },
                                {
                                    'src': 'words/3.png',
                                    'w': 79,
                                    'h': 25
                                },
                                {
                                    'src': 'words/4.png',
                                    'w': 72,
                                    'h': 25
                                },
                                {
                                    'src': 'words/5.png',
                                    'w': 54,
                                    'h': 25
                                },
                                {
                                    'src': 'words/6.png',
                                    'w': 62,
                                    'h': 25
                                },
                                {
                                    'src': 'words/7.png',
                                    'w': 74,
                                    'h': 25
                                }
                            ],
                            'months': [
                                {
                                    'src': 'words/8.png',
                                    'w': 80,
                                    'h': 38
                                },
                                {
                                    'src': 'words/9.png',
                                    'w': 71,
                                    'h': 29
                                },
                                {
                                    'src': 'words/10.png',
                                    'w': 96,
                                    'h': 29
                                },
                                {
                                    'src': 'words/11.png',
                                    'w': 82,
                                    'h': 29
                                },
                                {
                                    'src': 'words/12.png',
                                    'w': 92,
                                    'h': 29
                                },
                                {
                                    'src': 'words/13.png',
                                    'w': 81,
                                    'h': 38
                                },
                                {
                                    'src': 'words/14.png',
                                    'w': 71,
                                    'h': 38
                                },
                                {
                                    'src': 'words/15.png',
                                    'w': 89,
                                    'h': 30
                                },
                                {
                                    'src': 'words/16.png',
                                    'w': 71,
                                    'h': 30
                                },
                                {
                                    'src': 'words/17.png',
                                    'w': 82,
                                    'h': 30
                                },
                                {
                                    'src': 'words/18.png',
                                    'w': 93,
                                    'h': 30
                                },
                                {
                                    'src': 'words/19.png',
                                    'w': 78,
                                    'h': 30
                                }
                            ],
                            'days': [
                                null,
                                {
                                    'src': 'words/20.png',
                                    'w': 48,
                                    'h': 59
                                },
                                {
                                    'src': 'words/21.png',
                                    'w': 48,
                                    'h': 60
                                },
                                {
                                    'src': 'words/22.png',
                                    'w': 48,
                                    'h': 61
                                },
                                {
                                    'src': 'words/23.png',
                                    'w': 48,
                                    'h': 59
                                },
                                {
                                    'src': 'words/24.png',
                                    'w': 48,
                                    'h': 60
                                },
                                {
                                    'src': 'words/25.png',
                                    'w': 48,
                                    'h': 61
                                },
                                {
                                    'src': 'words/26.png',
                                    'w': 48,
                                    'h': 59
                                },
                                {
                                    'src': 'words/27.png',
                                    'w': 48,
                                    'h': 61
                                },
                                {
                                    'src': 'words/28.png',
                                    'w': 48,
                                    'h': 60
                                },
                                {
                                    'src': 'words/29.png',
                                    'w': 96,
                                    'h': 61
                                },
                                {
                                    'src': 'words/30.png',
                                    'w': 96,
                                    'h': 59
                                },
                                {
                                    'src': 'words/31.png',
                                    'w': 96,
                                    'h': 60
                                },
                                {
                                    'src': 'words/32.png',
                                    'w': 96,
                                    'h': 61
                                },
                                {
                                    'src': 'words/33.png',
                                    'w': 96,
                                    'h': 59
                                },
                                {
                                    'src': 'words/34.png',
                                    'w': 96,
                                    'h': 60
                                },
                                {
                                    'src': 'words/35.png',
                                    'w': 96,
                                    'h': 61
                                },
                                {
                                    'src': 'words/36.png',
                                    'w': 96,
                                    'h': 59
                                },
                                {
                                    'src': 'words/37.png',
                                    'w': 96,
                                    'h': 61
                                },
                                {
                                    'src': 'words/38.png',
                                    'w': 96,
                                    'h': 60
                                },
                                {
                                    'src': 'words/39.png',
                                    'w': 96,
                                    'h': 61
                                },
                                {
                                    'src': 'words/40.png',
                                    'w': 96,
                                    'h': 60
                                },
                                {
                                    'src': 'words/41.png',
                                    'w': 96,
                                    'h': 60
                                },
                                {
                                    'src': 'words/42.png',
                                    'w': 96,
                                    'h': 61
                                },
                                {
                                    'src': 'words/43.png',
                                    'w': 96,
                                    'h': 60
                                },
                                {
                                    'src': 'words/44.png',
                                    'w': 96,
                                    'h': 61
                                },
                                {
                                    'src': 'words/45.png',
                                    'w': 96,
                                    'h': 61
                                },
                                {
                                    'src': 'words/46.png',
                                    'w': 96,
                                    'h': 60
                                },
                                {
                                    'src': 'words/47.png',
                                    'w': 96,
                                    'h': 61
                                },
                                {
                                    'src': 'words/48.png',
                                    'w': 96,
                                    'h': 61
                                },
                                {
                                    'src': 'words/49.png',
                                    'w': 96,
                                    'h': 61
                                },
                                {
                                    'src': 'words/50.png',
                                    'w': 96,
                                    'h': 61
                                }
                            ],
                            'units': {
                                'HR': {
                                    'src': 'words/51.png',
                                    'w': 48,
                                    'h': 24
                                },
                                '\xB0C': {
                                    'src': 'words/52.png',
                                    'w': 36,
                                    'h': 25
                                },
                                '\xB0F': {
                                    'src': 'words/53.png',
                                    'w': 32,
                                    'h': 24
                                },
                                '%': {
                                    'src': 'words/54.png',
                                    'w': 32,
                                    'h': 25
                                },
                                'Bft': {
                                    'src': 'words/55.png',
                                    'w': 51,
                                    'h': 26
                                },
                                'km': {
                                    'src': 'words/56.png',
                                    'w': 50,
                                    'h': 23
                                },
                                'mi': {
                                    'src': 'words/57.png',
                                    'w': 40,
                                    'h': 24
                                },
                                'kcal': {
                                    'src': 'words/58.png',
                                    'w': 64,
                                    'h': 23
                                },
                                'hPa': {
                                    'src': 'words/59.png',
                                    'w': 58,
                                    'h': 23
                                }
                            },
                            'de': {
                                'src': 'words/60.png',
                                'w': 165,
                                'h': 92
                            },
                            'mo': {
                                'src': 'words/61.png',
                                'w': 226,
                                'h': 94
                            }
                        },
                        {
                            'name': 'gold',
                            'main': 'gold',
                            'accent': 'cream',
                            'label': 'cream',
                            'separator': {
                                'src': 't1-separator.png',
                                'w': 64,
                                'h': 22
                            },
                            'rule': {
                                'src': 't1-rule.png',
                                'w': 27,
                                'h': 2
                            },
                            'logo': {
                                'src': 'words/62.png',
                                'w': 79,
                                'h': 23
                            },
                            'weeks': [
                                {
                                    'src': 'words/1.png',
                                    'w': 89,
                                    'h': 25
                                },
                                {
                                    'src': 'words/2.png',
                                    'w': 65,
                                    'h': 25
                                },
                                {
                                    'src': 'words/3.png',
                                    'w': 79,
                                    'h': 25
                                },
                                {
                                    'src': 'words/4.png',
                                    'w': 72,
                                    'h': 25
                                },
                                {
                                    'src': 'words/5.png',
                                    'w': 54,
                                    'h': 25
                                },
                                {
                                    'src': 'words/6.png',
                                    'w': 62,
                                    'h': 25
                                },
                                {
                                    'src': 'words/7.png',
                                    'w': 74,
                                    'h': 25
                                }
                            ],
                            'months': [
                                {
                                    'src': 'words/8.png',
                                    'w': 80,
                                    'h': 38
                                },
                                {
                                    'src': 'words/9.png',
                                    'w': 71,
                                    'h': 29
                                },
                                {
                                    'src': 'words/10.png',
                                    'w': 96,
                                    'h': 29
                                },
                                {
                                    'src': 'words/11.png',
                                    'w': 82,
                                    'h': 29
                                },
                                {
                                    'src': 'words/12.png',
                                    'w': 92,
                                    'h': 29
                                },
                                {
                                    'src': 'words/13.png',
                                    'w': 81,
                                    'h': 38
                                },
                                {
                                    'src': 'words/14.png',
                                    'w': 71,
                                    'h': 38
                                },
                                {
                                    'src': 'words/15.png',
                                    'w': 89,
                                    'h': 30
                                },
                                {
                                    'src': 'words/16.png',
                                    'w': 71,
                                    'h': 30
                                },
                                {
                                    'src': 'words/17.png',
                                    'w': 82,
                                    'h': 30
                                },
                                {
                                    'src': 'words/18.png',
                                    'w': 93,
                                    'h': 30
                                },
                                {
                                    'src': 'words/19.png',
                                    'w': 78,
                                    'h': 30
                                }
                            ],
                            'days': [
                                null,
                                {
                                    'src': 'words/63.png',
                                    'w': 48,
                                    'h': 59
                                },
                                {
                                    'src': 'words/64.png',
                                    'w': 48,
                                    'h': 60
                                },
                                {
                                    'src': 'words/65.png',
                                    'w': 48,
                                    'h': 61
                                },
                                {
                                    'src': 'words/66.png',
                                    'w': 48,
                                    'h': 59
                                },
                                {
                                    'src': 'words/67.png',
                                    'w': 48,
                                    'h': 60
                                },
                                {
                                    'src': 'words/68.png',
                                    'w': 48,
                                    'h': 61
                                },
                                {
                                    'src': 'words/69.png',
                                    'w': 48,
                                    'h': 59
                                },
                                {
                                    'src': 'words/70.png',
                                    'w': 48,
                                    'h': 61
                                },
                                {
                                    'src': 'words/71.png',
                                    'w': 48,
                                    'h': 60
                                },
                                {
                                    'src': 'words/72.png',
                                    'w': 96,
                                    'h': 61
                                },
                                {
                                    'src': 'words/73.png',
                                    'w': 96,
                                    'h': 59
                                },
                                {
                                    'src': 'words/74.png',
                                    'w': 96,
                                    'h': 60
                                },
                                {
                                    'src': 'words/75.png',
                                    'w': 96,
                                    'h': 61
                                },
                                {
                                    'src': 'words/76.png',
                                    'w': 96,
                                    'h': 59
                                },
                                {
                                    'src': 'words/77.png',
                                    'w': 96,
                                    'h': 60
                                },
                                {
                                    'src': 'words/78.png',
                                    'w': 96,
                                    'h': 61
                                },
                                {
                                    'src': 'words/79.png',
                                    'w': 96,
                                    'h': 59
                                },
                                {
                                    'src': 'words/80.png',
                                    'w': 96,
                                    'h': 61
                                },
                                {
                                    'src': 'words/81.png',
                                    'w': 96,
                                    'h': 60
                                },
                                {
                                    'src': 'words/82.png',
                                    'w': 96,
                                    'h': 61
                                },
                                {
                                    'src': 'words/83.png',
                                    'w': 96,
                                    'h': 60
                                },
                                {
                                    'src': 'words/84.png',
                                    'w': 96,
                                    'h': 60
                                },
                                {
                                    'src': 'words/85.png',
                                    'w': 96,
                                    'h': 61
                                },
                                {
                                    'src': 'words/86.png',
                                    'w': 96,
                                    'h': 60
                                },
                                {
                                    'src': 'words/87.png',
                                    'w': 96,
                                    'h': 61
                                },
                                {
                                    'src': 'words/88.png',
                                    'w': 96,
                                    'h': 61
                                },
                                {
                                    'src': 'words/89.png',
                                    'w': 96,
                                    'h': 60
                                },
                                {
                                    'src': 'words/90.png',
                                    'w': 96,
                                    'h': 61
                                },
                                {
                                    'src': 'words/91.png',
                                    'w': 96,
                                    'h': 61
                                },
                                {
                                    'src': 'words/92.png',
                                    'w': 96,
                                    'h': 61
                                },
                                {
                                    'src': 'words/93.png',
                                    'w': 96,
                                    'h': 61
                                }
                            ],
                            'units': {
                                'HR': {
                                    'src': 'words/51.png',
                                    'w': 48,
                                    'h': 24
                                },
                                '\xB0C': {
                                    'src': 'words/52.png',
                                    'w': 36,
                                    'h': 25
                                },
                                '\xB0F': {
                                    'src': 'words/53.png',
                                    'w': 32,
                                    'h': 24
                                },
                                '%': {
                                    'src': 'words/54.png',
                                    'w': 32,
                                    'h': 25
                                },
                                'Bft': {
                                    'src': 'words/55.png',
                                    'w': 51,
                                    'h': 26
                                },
                                'km': {
                                    'src': 'words/56.png',
                                    'w': 50,
                                    'h': 23
                                },
                                'mi': {
                                    'src': 'words/57.png',
                                    'w': 40,
                                    'h': 24
                                },
                                'kcal': {
                                    'src': 'words/58.png',
                                    'w': 64,
                                    'h': 23
                                },
                                'hPa': {
                                    'src': 'words/59.png',
                                    'w': 58,
                                    'h': 23
                                }
                            },
                            'de': {
                                'src': 'words/94.png',
                                'w': 165,
                                'h': 92
                            },
                            'mo': {
                                'src': 'words/95.png',
                                'w': 226,
                                'h': 94
                            }
                        },
                        {
                            'name': 'silver',
                            'main': 'silver',
                            'accent': 'gold',
                            'label': 'cream',
                            'separator': {
                                'src': 't2-separator.png',
                                'w': 64,
                                'h': 22
                            },
                            'rule': {
                                'src': 't2-rule.png',
                                'w': 27,
                                'h': 2
                            },
                            'logo': {
                                'src': 'words/0.png',
                                'w': 79,
                                'h': 23
                            },
                            'weeks': [
                                {
                                    'src': 'words/1.png',
                                    'w': 89,
                                    'h': 25
                                },
                                {
                                    'src': 'words/2.png',
                                    'w': 65,
                                    'h': 25
                                },
                                {
                                    'src': 'words/3.png',
                                    'w': 79,
                                    'h': 25
                                },
                                {
                                    'src': 'words/4.png',
                                    'w': 72,
                                    'h': 25
                                },
                                {
                                    'src': 'words/5.png',
                                    'w': 54,
                                    'h': 25
                                },
                                {
                                    'src': 'words/6.png',
                                    'w': 62,
                                    'h': 25
                                },
                                {
                                    'src': 'words/7.png',
                                    'w': 74,
                                    'h': 25
                                }
                            ],
                            'months': [
                                {
                                    'src': 'words/8.png',
                                    'w': 80,
                                    'h': 38
                                },
                                {
                                    'src': 'words/9.png',
                                    'w': 71,
                                    'h': 29
                                },
                                {
                                    'src': 'words/10.png',
                                    'w': 96,
                                    'h': 29
                                },
                                {
                                    'src': 'words/11.png',
                                    'w': 82,
                                    'h': 29
                                },
                                {
                                    'src': 'words/12.png',
                                    'w': 92,
                                    'h': 29
                                },
                                {
                                    'src': 'words/13.png',
                                    'w': 81,
                                    'h': 38
                                },
                                {
                                    'src': 'words/14.png',
                                    'w': 71,
                                    'h': 38
                                },
                                {
                                    'src': 'words/15.png',
                                    'w': 89,
                                    'h': 30
                                },
                                {
                                    'src': 'words/16.png',
                                    'w': 71,
                                    'h': 30
                                },
                                {
                                    'src': 'words/17.png',
                                    'w': 82,
                                    'h': 30
                                },
                                {
                                    'src': 'words/18.png',
                                    'w': 93,
                                    'h': 30
                                },
                                {
                                    'src': 'words/19.png',
                                    'w': 78,
                                    'h': 30
                                }
                            ],
                            'days': [
                                null,
                                {
                                    'src': 'words/20.png',
                                    'w': 48,
                                    'h': 59
                                },
                                {
                                    'src': 'words/21.png',
                                    'w': 48,
                                    'h': 60
                                },
                                {
                                    'src': 'words/22.png',
                                    'w': 48,
                                    'h': 61
                                },
                                {
                                    'src': 'words/23.png',
                                    'w': 48,
                                    'h': 59
                                },
                                {
                                    'src': 'words/24.png',
                                    'w': 48,
                                    'h': 60
                                },
                                {
                                    'src': 'words/25.png',
                                    'w': 48,
                                    'h': 61
                                },
                                {
                                    'src': 'words/26.png',
                                    'w': 48,
                                    'h': 59
                                },
                                {
                                    'src': 'words/27.png',
                                    'w': 48,
                                    'h': 61
                                },
                                {
                                    'src': 'words/28.png',
                                    'w': 48,
                                    'h': 60
                                },
                                {
                                    'src': 'words/29.png',
                                    'w': 96,
                                    'h': 61
                                },
                                {
                                    'src': 'words/30.png',
                                    'w': 96,
                                    'h': 59
                                },
                                {
                                    'src': 'words/31.png',
                                    'w': 96,
                                    'h': 60
                                },
                                {
                                    'src': 'words/32.png',
                                    'w': 96,
                                    'h': 61
                                },
                                {
                                    'src': 'words/33.png',
                                    'w': 96,
                                    'h': 59
                                },
                                {
                                    'src': 'words/34.png',
                                    'w': 96,
                                    'h': 60
                                },
                                {
                                    'src': 'words/35.png',
                                    'w': 96,
                                    'h': 61
                                },
                                {
                                    'src': 'words/36.png',
                                    'w': 96,
                                    'h': 59
                                },
                                {
                                    'src': 'words/37.png',
                                    'w': 96,
                                    'h': 61
                                },
                                {
                                    'src': 'words/38.png',
                                    'w': 96,
                                    'h': 60
                                },
                                {
                                    'src': 'words/39.png',
                                    'w': 96,
                                    'h': 61
                                },
                                {
                                    'src': 'words/40.png',
                                    'w': 96,
                                    'h': 60
                                },
                                {
                                    'src': 'words/41.png',
                                    'w': 96,
                                    'h': 60
                                },
                                {
                                    'src': 'words/42.png',
                                    'w': 96,
                                    'h': 61
                                },
                                {
                                    'src': 'words/43.png',
                                    'w': 96,
                                    'h': 60
                                },
                                {
                                    'src': 'words/44.png',
                                    'w': 96,
                                    'h': 61
                                },
                                {
                                    'src': 'words/45.png',
                                    'w': 96,
                                    'h': 61
                                },
                                {
                                    'src': 'words/46.png',
                                    'w': 96,
                                    'h': 60
                                },
                                {
                                    'src': 'words/47.png',
                                    'w': 96,
                                    'h': 61
                                },
                                {
                                    'src': 'words/48.png',
                                    'w': 96,
                                    'h': 61
                                },
                                {
                                    'src': 'words/49.png',
                                    'w': 96,
                                    'h': 61
                                },
                                {
                                    'src': 'words/50.png',
                                    'w': 96,
                                    'h': 61
                                }
                            ],
                            'units': {
                                'HR': {
                                    'src': 'words/51.png',
                                    'w': 48,
                                    'h': 24
                                },
                                '\xB0C': {
                                    'src': 'words/52.png',
                                    'w': 36,
                                    'h': 25
                                },
                                '\xB0F': {
                                    'src': 'words/53.png',
                                    'w': 32,
                                    'h': 24
                                },
                                '%': {
                                    'src': 'words/54.png',
                                    'w': 32,
                                    'h': 25
                                },
                                'Bft': {
                                    'src': 'words/55.png',
                                    'w': 51,
                                    'h': 26
                                },
                                'km': {
                                    'src': 'words/56.png',
                                    'w': 50,
                                    'h': 23
                                },
                                'mi': {
                                    'src': 'words/57.png',
                                    'w': 40,
                                    'h': 24
                                },
                                'kcal': {
                                    'src': 'words/58.png',
                                    'w': 64,
                                    'h': 23
                                },
                                'hPa': {
                                    'src': 'words/59.png',
                                    'w': 58,
                                    'h': 23
                                }
                            },
                            'de': {
                                'src': 'words/96.png',
                                'w': 165,
                                'h': 92
                            },
                            'mo': {
                                'src': 'words/97.png',
                                'w': 226,
                                'h': 94
                            }
                        }
                    ],
                    'audit': [
                        {
                            'text': 'ArtIst',
                            'font_size': 30,
                            'letter_heights': {
                                's': 17,
                                't': 21,
                                'A': 22,
                                'r': 17,
                                'I': 22
                            },
                            'src': 'words/0.png'
                        },
                        {
                            'text': 'MON',
                            'font_size': 34,
                            'letter_heights': {
                                'M': 24,
                                'N': 24,
                                'O': 25
                            },
                            'src': 'words/1.png'
                        },
                        {
                            'text': 'TUE',
                            'font_size': 34,
                            'letter_heights': {
                                'E': 24,
                                'U': 25,
                                'T': 24
                            },
                            'src': 'words/2.png'
                        },
                        {
                            'text': 'WED',
                            'font_size': 34,
                            'letter_heights': {
                                'D': 24,
                                'E': 24,
                                'W': 24
                            },
                            'src': 'words/3.png'
                        },
                        {
                            'text': 'THU',
                            'font_size': 34,
                            'letter_heights': {
                                'U': 25,
                                'H': 24,
                                'T': 24
                            },
                            'src': 'words/4.png'
                        },
                        {
                            'text': 'FRI',
                            'font_size': 34,
                            'letter_heights': {
                                'R': 24,
                                'I': 24,
                                'F': 24
                            },
                            'src': 'words/5.png'
                        },
                        {
                            'text': 'SAT',
                            'font_size': 34,
                            'letter_heights': {
                                'A': 24,
                                'S': 25,
                                'T': 24
                            },
                            'src': 'words/6.png'
                        },
                        {
                            'text': 'SUN',
                            'font_size': 34,
                            'letter_heights': {
                                'S': 25,
                                'N': 24,
                                'U': 25
                            },
                            'src': 'words/7.png'
                        },
                        {
                            'text': 'JAN',
                            'font_size': 40,
                            'letter_heights': {
                                'A': 29,
                                'J': 38,
                                'N': 29
                            },
                            'src': 'words/8.png'
                        },
                        {
                            'text': 'FEB',
                            'font_size': 40,
                            'letter_heights': {
                                'B': 29,
                                'E': 29,
                                'F': 29
                            },
                            'src': 'words/9.png'
                        },
                        {
                            'text': 'MAR',
                            'font_size': 40,
                            'letter_heights': {
                                'A': 29,
                                'M': 29,
                                'R': 29
                            },
                            'src': 'words/10.png'
                        },
                        {
                            'text': 'APR',
                            'font_size': 40,
                            'letter_heights': {
                                'A': 29,
                                'R': 29,
                                'P': 29
                            },
                            'src': 'words/11.png'
                        },
                        {
                            'text': 'MAY',
                            'font_size': 40,
                            'letter_heights': {
                                'A': 29,
                                'M': 29,
                                'Y': 29
                            },
                            'src': 'words/12.png'
                        },
                        {
                            'text': 'JUN',
                            'font_size': 40,
                            'letter_heights': {
                                'J': 38,
                                'N': 29,
                                'U': 29
                            },
                            'src': 'words/13.png'
                        },
                        {
                            'text': 'JUL',
                            'font_size': 40,
                            'letter_heights': {
                                'J': 38,
                                'L': 29,
                                'U': 29
                            },
                            'src': 'words/14.png'
                        },
                        {
                            'text': 'AUG',
                            'font_size': 40,
                            'letter_heights': {
                                'A': 29,
                                'U': 29,
                                'G': 30
                            },
                            'src': 'words/15.png'
                        },
                        {
                            'text': 'SEP',
                            'font_size': 40,
                            'letter_heights': {
                                'S': 30,
                                'E': 29,
                                'P': 29
                            },
                            'src': 'words/16.png'
                        },
                        {
                            'text': 'OCT',
                            'font_size': 40,
                            'letter_heights': {
                                'C': 30,
                                'O': 30,
                                'T': 29
                            },
                            'src': 'words/17.png'
                        },
                        {
                            'text': 'NOV',
                            'font_size': 40,
                            'letter_heights': {
                                'N': 29,
                                'V': 29,
                                'O': 30
                            },
                            'src': 'words/18.png'
                        },
                        {
                            'text': 'DEC',
                            'font_size': 40,
                            'letter_heights': {
                                'D': 29,
                                'E': 29,
                                'C': 30
                            },
                            'src': 'words/19.png'
                        },
                        {
                            'text': '1',
                            'font_size': 82,
                            'letter_heights': { '1': 59 },
                            'src': 'words/20.png'
                        },
                        {
                            'text': '2',
                            'font_size': 82,
                            'letter_heights': { '2': 60 },
                            'src': 'words/21.png'
                        },
                        {
                            'text': '3',
                            'font_size': 82,
                            'letter_heights': { '3': 60 },
                            'src': 'words/22.png'
                        },
                        {
                            'text': '4',
                            'font_size': 82,
                            'letter_heights': { '4': 59 },
                            'src': 'words/23.png'
                        },
                        {
                            'text': '5',
                            'font_size': 82,
                            'letter_heights': { '5': 59 },
                            'src': 'words/24.png'
                        },
                        {
                            'text': '6',
                            'font_size': 82,
                            'letter_heights': { '6': 60 },
                            'src': 'words/25.png'
                        },
                        {
                            'text': '7',
                            'font_size': 82,
                            'letter_heights': { '7': 59 },
                            'src': 'words/26.png'
                        },
                        {
                            'text': '8',
                            'font_size': 82,
                            'letter_heights': { '8': 60 },
                            'src': 'words/27.png'
                        },
                        {
                            'text': '9',
                            'font_size': 82,
                            'letter_heights': { '9': 60 },
                            'src': 'words/28.png'
                        },
                        {
                            'text': '10',
                            'font_size': 82,
                            'letter_heights': {
                                '0': 60,
                                '1': 59
                            },
                            'src': 'words/29.png'
                        },
                        {
                            'text': '11',
                            'font_size': 82,
                            'letter_heights': { '1': 59 },
                            'src': 'words/30.png'
                        },
                        {
                            'text': '12',
                            'font_size': 82,
                            'letter_heights': {
                                '2': 60,
                                '1': 59
                            },
                            'src': 'words/31.png'
                        },
                        {
                            'text': '13',
                            'font_size': 82,
                            'letter_heights': {
                                '3': 60,
                                '1': 59
                            },
                            'src': 'words/32.png'
                        },
                        {
                            'text': '14',
                            'font_size': 82,
                            'letter_heights': {
                                '4': 59,
                                '1': 59
                            },
                            'src': 'words/33.png'
                        },
                        {
                            'text': '15',
                            'font_size': 82,
                            'letter_heights': {
                                '5': 59,
                                '1': 59
                            },
                            'src': 'words/34.png'
                        },
                        {
                            'text': '16',
                            'font_size': 82,
                            'letter_heights': {
                                '6': 60,
                                '1': 59
                            },
                            'src': 'words/35.png'
                        },
                        {
                            'text': '17',
                            'font_size': 82,
                            'letter_heights': {
                                '7': 59,
                                '1': 59
                            },
                            'src': 'words/36.png'
                        },
                        {
                            'text': '18',
                            'font_size': 82,
                            'letter_heights': {
                                '8': 60,
                                '1': 59
                            },
                            'src': 'words/37.png'
                        },
                        {
                            'text': '19',
                            'font_size': 82,
                            'letter_heights': {
                                '9': 60,
                                '1': 59
                            },
                            'src': 'words/38.png'
                        },
                        {
                            'text': '20',
                            'font_size': 82,
                            'letter_heights': {
                                '2': 60,
                                '0': 60
                            },
                            'src': 'words/39.png'
                        },
                        {
                            'text': '21',
                            'font_size': 82,
                            'letter_heights': {
                                '2': 60,
                                '1': 59
                            },
                            'src': 'words/40.png'
                        },
                        {
                            'text': '22',
                            'font_size': 82,
                            'letter_heights': { '2': 60 },
                            'src': 'words/41.png'
                        },
                        {
                            'text': '23',
                            'font_size': 82,
                            'letter_heights': {
                                '3': 60,
                                '2': 60
                            },
                            'src': 'words/42.png'
                        },
                        {
                            'text': '24',
                            'font_size': 82,
                            'letter_heights': {
                                '4': 59,
                                '2': 60
                            },
                            'src': 'words/43.png'
                        },
                        {
                            'text': '25',
                            'font_size': 82,
                            'letter_heights': {
                                '5': 59,
                                '2': 60
                            },
                            'src': 'words/44.png'
                        },
                        {
                            'text': '26',
                            'font_size': 82,
                            'letter_heights': {
                                '6': 60,
                                '2': 60
                            },
                            'src': 'words/45.png'
                        },
                        {
                            'text': '27',
                            'font_size': 82,
                            'letter_heights': {
                                '7': 59,
                                '2': 60
                            },
                            'src': 'words/46.png'
                        },
                        {
                            'text': '28',
                            'font_size': 82,
                            'letter_heights': {
                                '8': 60,
                                '2': 60
                            },
                            'src': 'words/47.png'
                        },
                        {
                            'text': '29',
                            'font_size': 82,
                            'letter_heights': {
                                '9': 60,
                                '2': 60
                            },
                            'src': 'words/48.png'
                        },
                        {
                            'text': '30',
                            'font_size': 82,
                            'letter_heights': {
                                '3': 60,
                                '0': 60
                            },
                            'src': 'words/49.png'
                        },
                        {
                            'text': '31',
                            'font_size': 82,
                            'letter_heights': {
                                '3': 60,
                                '1': 59
                            },
                            'src': 'words/50.png'
                        },
                        {
                            'text': 'HR',
                            'font_size': 33,
                            'letter_heights': {
                                'R': 24,
                                'H': 24
                            },
                            'src': 'words/51.png'
                        },
                        {
                            'text': '\xB0C',
                            'font_size': 33,
                            'letter_heights': { 'C': 24 },
                            'src': 'words/52.png'
                        },
                        {
                            'text': '\xB0F',
                            'font_size': 33,
                            'letter_heights': { 'F': 24 },
                            'src': 'words/53.png'
                        },
                        {
                            'text': '%',
                            'font_size': 33,
                            'letter_heights': {},
                            'src': 'words/54.png'
                        },
                        {
                            'text': 'Bft',
                            'font_size': 33,
                            'letter_heights': {
                                'B': 24,
                                'f': 25,
                                't': 22
                            },
                            'src': 'words/55.png'
                        },
                        {
                            'text': 'km',
                            'font_size': 30,
                            'letter_heights': {
                                'm': 17,
                                'k': 23
                            },
                            'src': 'words/56.png'
                        },
                        {
                            'text': 'mi',
                            'font_size': 30,
                            'letter_heights': {
                                'i': 21,
                                'm': 17
                            },
                            'src': 'words/57.png'
                        },
                        {
                            'text': 'kcal',
                            'font_size': 30,
                            'letter_heights': {
                                'c': 17,
                                'l': 23,
                                'k': 23,
                                'a': 17
                            },
                            'src': 'words/58.png'
                        },
                        {
                            'text': 'hPa',
                            'font_size': 30,
                            'letter_heights': {
                                'P': 22,
                                'h': 23,
                                'a': 17
                            },
                            'src': 'words/59.png'
                        },
                        {
                            'text': 'DE',
                            'font_size': 128,
                            'letter_heights': {
                                'D': 92,
                                'E': 92
                            },
                            'src': 'words/60.png'
                        },
                        {
                            'text': 'MO',
                            'font_size': 128,
                            'letter_heights': {
                                'M': 92,
                                'O': 94
                            },
                            'src': 'words/61.png'
                        },
                        {
                            'text': 'ArtIst',
                            'font_size': 30,
                            'letter_heights': {
                                's': 17,
                                't': 21,
                                'A': 22,
                                'r': 17,
                                'I': 22
                            },
                            'src': 'words/62.png'
                        },
                        {
                            'text': '1',
                            'font_size': 82,
                            'letter_heights': { '1': 59 },
                            'src': 'words/63.png'
                        },
                        {
                            'text': '2',
                            'font_size': 82,
                            'letter_heights': { '2': 60 },
                            'src': 'words/64.png'
                        },
                        {
                            'text': '3',
                            'font_size': 82,
                            'letter_heights': { '3': 60 },
                            'src': 'words/65.png'
                        },
                        {
                            'text': '4',
                            'font_size': 82,
                            'letter_heights': { '4': 59 },
                            'src': 'words/66.png'
                        },
                        {
                            'text': '5',
                            'font_size': 82,
                            'letter_heights': { '5': 59 },
                            'src': 'words/67.png'
                        },
                        {
                            'text': '6',
                            'font_size': 82,
                            'letter_heights': { '6': 60 },
                            'src': 'words/68.png'
                        },
                        {
                            'text': '7',
                            'font_size': 82,
                            'letter_heights': { '7': 59 },
                            'src': 'words/69.png'
                        },
                        {
                            'text': '8',
                            'font_size': 82,
                            'letter_heights': { '8': 60 },
                            'src': 'words/70.png'
                        },
                        {
                            'text': '9',
                            'font_size': 82,
                            'letter_heights': { '9': 60 },
                            'src': 'words/71.png'
                        },
                        {
                            'text': '10',
                            'font_size': 82,
                            'letter_heights': {
                                '0': 60,
                                '1': 59
                            },
                            'src': 'words/72.png'
                        },
                        {
                            'text': '11',
                            'font_size': 82,
                            'letter_heights': { '1': 59 },
                            'src': 'words/73.png'
                        },
                        {
                            'text': '12',
                            'font_size': 82,
                            'letter_heights': {
                                '2': 60,
                                '1': 59
                            },
                            'src': 'words/74.png'
                        },
                        {
                            'text': '13',
                            'font_size': 82,
                            'letter_heights': {
                                '3': 60,
                                '1': 59
                            },
                            'src': 'words/75.png'
                        },
                        {
                            'text': '14',
                            'font_size': 82,
                            'letter_heights': {
                                '4': 59,
                                '1': 59
                            },
                            'src': 'words/76.png'
                        },
                        {
                            'text': '15',
                            'font_size': 82,
                            'letter_heights': {
                                '5': 59,
                                '1': 59
                            },
                            'src': 'words/77.png'
                        },
                        {
                            'text': '16',
                            'font_size': 82,
                            'letter_heights': {
                                '6': 60,
                                '1': 59
                            },
                            'src': 'words/78.png'
                        },
                        {
                            'text': '17',
                            'font_size': 82,
                            'letter_heights': {
                                '7': 59,
                                '1': 59
                            },
                            'src': 'words/79.png'
                        },
                        {
                            'text': '18',
                            'font_size': 82,
                            'letter_heights': {
                                '8': 60,
                                '1': 59
                            },
                            'src': 'words/80.png'
                        },
                        {
                            'text': '19',
                            'font_size': 82,
                            'letter_heights': {
                                '9': 60,
                                '1': 59
                            },
                            'src': 'words/81.png'
                        },
                        {
                            'text': '20',
                            'font_size': 82,
                            'letter_heights': {
                                '2': 60,
                                '0': 60
                            },
                            'src': 'words/82.png'
                        },
                        {
                            'text': '21',
                            'font_size': 82,
                            'letter_heights': {
                                '2': 60,
                                '1': 59
                            },
                            'src': 'words/83.png'
                        },
                        {
                            'text': '22',
                            'font_size': 82,
                            'letter_heights': { '2': 60 },
                            'src': 'words/84.png'
                        },
                        {
                            'text': '23',
                            'font_size': 82,
                            'letter_heights': {
                                '3': 60,
                                '2': 60
                            },
                            'src': 'words/85.png'
                        },
                        {
                            'text': '24',
                            'font_size': 82,
                            'letter_heights': {
                                '4': 59,
                                '2': 60
                            },
                            'src': 'words/86.png'
                        },
                        {
                            'text': '25',
                            'font_size': 82,
                            'letter_heights': {
                                '5': 59,
                                '2': 60
                            },
                            'src': 'words/87.png'
                        },
                        {
                            'text': '26',
                            'font_size': 82,
                            'letter_heights': {
                                '6': 60,
                                '2': 60
                            },
                            'src': 'words/88.png'
                        },
                        {
                            'text': '27',
                            'font_size': 82,
                            'letter_heights': {
                                '7': 59,
                                '2': 60
                            },
                            'src': 'words/89.png'
                        },
                        {
                            'text': '28',
                            'font_size': 82,
                            'letter_heights': {
                                '8': 60,
                                '2': 60
                            },
                            'src': 'words/90.png'
                        },
                        {
                            'text': '29',
                            'font_size': 82,
                            'letter_heights': {
                                '9': 60,
                                '2': 60
                            },
                            'src': 'words/91.png'
                        },
                        {
                            'text': '30',
                            'font_size': 82,
                            'letter_heights': {
                                '3': 60,
                                '0': 60
                            },
                            'src': 'words/92.png'
                        },
                        {
                            'text': '31',
                            'font_size': 82,
                            'letter_heights': {
                                '3': 60,
                                '1': 59
                            },
                            'src': 'words/93.png'
                        },
                        {
                            'text': 'DE',
                            'font_size': 128,
                            'letter_heights': {
                                'D': 92,
                                'E': 92
                            },
                            'src': 'words/94.png'
                        },
                        {
                            'text': 'MO',
                            'font_size': 128,
                            'letter_heights': {
                                'M': 92,
                                'O': 94
                            },
                            'src': 'words/95.png'
                        },
                        {
                            'text': 'DE',
                            'font_size': 128,
                            'letter_heights': {
                                'D': 92,
                                'E': 92
                            },
                            'src': 'words/96.png'
                        },
                        {
                            'text': 'MO',
                            'font_size': 128,
                            'letter_heights': {
                                'M': 92,
                                'O': 94
                            },
                            'src': 'words/97.png'
                        }
                    ],
                    'aod': [
                        {
                            'kind': 'IMG_TIME',
                            'props': {
                                'hour_startX': 131,
                                'hour_startY': 162,
                                'hour_zero': 1,
                                'hour_array': [
                                    'aod0.png',
                                    'aod1.png',
                                    'aod2.png',
                                    'aod3.png',
                                    'aod4.png',
                                    'aod5.png',
                                    'aod6.png',
                                    'aod7.png',
                                    'aod8.png',
                                    'aod9.png'
                                ],
                                'minute_startX': 249,
                                'minute_startY': 162,
                                'minute_follow': 0,
                                'minute_zero': 1,
                                'minute_array': [
                                    'aod0.png',
                                    'aod1.png',
                                    'aod2.png',
                                    'aod3.png',
                                    'aod4.png',
                                    'aod5.png',
                                    'aod6.png',
                                    'aod7.png',
                                    'aod8.png',
                                    'aod9.png'
                                ]
                            }
                        },
                        {
                            'kind': 'IMG',
                            'props': {
                                'src': 'aodcolon.png',
                                'x': 232,
                                'y': 162
                            }
                        },
                        {
                            'kind': 'IMG_WEEK',
                            'props': {
                                'x': 198,
                                'y': 252,
                                'week_en': [
                                    'aod-week-0.png',
                                    'aod-week-1.png',
                                    'aod-week-2.png',
                                    'aod-week-3.png',
                                    'aod-week-4.png',
                                    'aod-week-5.png',
                                    'aod-week-6.png'
                                ],
                                'week_sc': [
                                    'aod-week-0.png',
                                    'aod-week-1.png',
                                    'aod-week-2.png',
                                    'aod-week-3.png',
                                    'aod-week-4.png',
                                    'aod-week-5.png',
                                    'aod-week-6.png'
                                ],
                                'week_tc': [
                                    'aod-week-0.png',
                                    'aod-week-1.png',
                                    'aod-week-2.png',
                                    'aod-week-3.png',
                                    'aod-week-4.png',
                                    'aod-week-5.png',
                                    'aod-week-6.png'
                                ]
                            }
                        },
                        {
                            'kind': 'IMG_DATE',
                            'props': {
                                'day_startX': 159,
                                'day_startY': 294,
                                'day_zero': 1,
                                'day_follow': 0,
                                'day_space': 0,
                                'day_align': 1,
                                'day_en_array': [
                                    'aod-date-0.png',
                                    'aod-date-1.png',
                                    'aod-date-2.png',
                                    'aod-date-3.png',
                                    'aod-date-4.png',
                                    'aod-date-5.png',
                                    'aod-date-6.png',
                                    'aod-date-7.png',
                                    'aod-date-8.png',
                                    'aod-date-9.png'
                                ],
                                'day_sc_array': [
                                    'aod-date-0.png',
                                    'aod-date-1.png',
                                    'aod-date-2.png',
                                    'aod-date-3.png',
                                    'aod-date-4.png',
                                    'aod-date-5.png',
                                    'aod-date-6.png',
                                    'aod-date-7.png',
                                    'aod-date-8.png',
                                    'aod-date-9.png'
                                ],
                                'day_tc_array': [
                                    'aod-date-0.png',
                                    'aod-date-1.png',
                                    'aod-date-2.png',
                                    'aod-date-3.png',
                                    'aod-date-4.png',
                                    'aod-date-5.png',
                                    'aod-date-6.png',
                                    'aod-date-7.png',
                                    'aod-date-8.png',
                                    'aod-date-9.png'
                                ],
                                'month_startX': 206,
                                'month_startY': 294,
                                'month_zero': 1,
                                'month_follow': 0,
                                'month_space': 0,
                                'month_align': 1,
                                'month_en_array': [
                                    'aod-date-0.png',
                                    'aod-date-1.png',
                                    'aod-date-2.png',
                                    'aod-date-3.png',
                                    'aod-date-4.png',
                                    'aod-date-5.png',
                                    'aod-date-6.png',
                                    'aod-date-7.png',
                                    'aod-date-8.png',
                                    'aod-date-9.png'
                                ],
                                'month_sc_array': [
                                    'aod-date-0.png',
                                    'aod-date-1.png',
                                    'aod-date-2.png',
                                    'aod-date-3.png',
                                    'aod-date-4.png',
                                    'aod-date-5.png',
                                    'aod-date-6.png',
                                    'aod-date-7.png',
                                    'aod-date-8.png',
                                    'aod-date-9.png'
                                ],
                                'month_tc_array': [
                                    'aod-date-0.png',
                                    'aod-date-1.png',
                                    'aod-date-2.png',
                                    'aod-date-3.png',
                                    'aod-date-4.png',
                                    'aod-date-5.png',
                                    'aod-date-6.png',
                                    'aod-date-7.png',
                                    'aod-date-8.png',
                                    'aod-date-9.png'
                                ],
                                'year_startX': 253,
                                'year_startY': 294,
                                'year_zero': 1,
                                'year_follow': 0,
                                'year_space': 0,
                                'year_align': 1,
                                'year_en_array': [
                                    'aod-date-0.png',
                                    'aod-date-1.png',
                                    'aod-date-2.png',
                                    'aod-date-3.png',
                                    'aod-date-4.png',
                                    'aod-date-5.png',
                                    'aod-date-6.png',
                                    'aod-date-7.png',
                                    'aod-date-8.png',
                                    'aod-date-9.png'
                                ],
                                'year_sc_array': [
                                    'aod-date-0.png',
                                    'aod-date-1.png',
                                    'aod-date-2.png',
                                    'aod-date-3.png',
                                    'aod-date-4.png',
                                    'aod-date-5.png',
                                    'aod-date-6.png',
                                    'aod-date-7.png',
                                    'aod-date-8.png',
                                    'aod-date-9.png'
                                ],
                                'year_tc_array': [
                                    'aod-date-0.png',
                                    'aod-date-1.png',
                                    'aod-date-2.png',
                                    'aod-date-3.png',
                                    'aod-date-4.png',
                                    'aod-date-5.png',
                                    'aod-date-6.png',
                                    'aod-date-7.png',
                                    'aod-date-8.png',
                                    'aod-date-9.png'
                                ]
                            }
                        },
                        {
                            'kind': 'IMG',
                            'props': {
                                'src': 'aod-slash.png',
                                'x': 192,
                                'y': 294
                            }
                        },
                        {
                            'kind': 'IMG',
                            'props': {
                                'src': 'aod-slash.png',
                                'x': 240,
                                'y': 294
                            }
                        }
                    ]
                };
                var __defProp = Object.defineProperty;
                var __defProps = Object.defineProperties;
                var __getOwnPropDescs = Object.getOwnPropertyDescriptors;
                var __getOwnPropSymbols = Object.getOwnPropertySymbols;
                var __hasOwnProp = Object.prototype.hasOwnProperty;
                var __propIsEnum = Object.prototype.propertyIsEnumerable;
                var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, {
                    enumerable: true,
                    configurable: true,
                    writable: true,
                    value
                }) : obj[key] = value;
                var __spreadValues = (a, b) => {
                    for (var prop in b || (b = {}))
                        if (__hasOwnProp.call(b, prop))
                            __defNormalProp(a, prop, b[prop]);
                    if (__getOwnPropSymbols)
                        for (var prop of __getOwnPropSymbols(b)) {
                            if (__propIsEnum.call(b, prop))
                                __defNormalProp(a, prop, b[prop]);
                        }
                    return a;
                };
                var __spreadProps = (a, b) => __defProps(a, __getOwnPropDescs(b));
                const N = ui__default.default.show_level.ONLY_NORMAL, A = ui__default.default.show_level.ONLY_AOD;
                const safe = f => {
                    try {
                        return f();
                    } catch (e) {
                        return void 0;
                    }
                };
                const KEY = 'artist-kintsugi-trial-v1', PREF = 'artist-kintsugi-prefs-v1';
                let cleanup = () => {
                };
                __$$module$$__.module = WatchFace({
                    build() {
                        cleanup();
                        const create = (kind, p, level = N) => {
                            var _a;
                            const w = ui__default.default.createWidget(kind, __spreadProps(__spreadValues({}, p), { show_level: level }));
                            if (![
                                    ui__default.default.widget.BUTTON,
                                    ui__default.default.widget.IMG_CLICK,
                                    ui__default.default.widget.WIDGET_DELEGATE
                                ].includes(kind))
                                (_a = w.setEnable) == null ? void 0 : _a.call(w, false);
                            return w;
                        };
                        const show = (w, v) => w && w.setProperty(ui__default.default.prop.VISIBLE, !!v);
                        const img = (src, x, y) => create(ui__default.default.widget.IMG, {
                            src,
                            x,
                            y
                        });
                        create(ui__default.default.widget.FILL_RECT, {
                            x: 0,
                            y: 0,
                            w: 480,
                            h: 480,
                            color: 0
                        }, A);
                        for (const w of R.aod)
                            create(ui__default.default.widget[w.kind], w.props, A);
                        if (app.getScene() === app.SCENE_AOD)
                            return;
                        const store = safe(() => new storage.LocalStorage());
                        const saved = safe(() => store.getItem(PREF)) || {};
                        const bounded = (v, n) => Number.isInteger(v) && v >= 0 && v < n ? v : 0;
                        let theme = bounded(saved.theme, 3), small = bounded(saved.small, 4), bottom = bounded(saved.bottom, 4), awake = false, dead = false, timer = null, expired = false, registered = false;
                        const persist = () => safe(() => store.setItem(PREF, {
                            theme,
                            small,
                            bottom
                        }));
                        let trial = safe(() => store.getItem(KEY));
                        if (!trial || !Number.isFinite(trial.started) || !Number.isFinite(trial.last)) {
                            const n = Date.now();
                            trial = {
                                started: n,
                                last: n,
                                expired: false
                            };
                            try {
                                store.setItem(KEY, trial);
                            } catch (e) {
                                trial.expired = true;
                            }
                        }
                        function check() {
                            const n = Date.now(), old = trial.expired;
                            trial.expired = !!old || n < trial.last - 5000 || n - trial.started >= 1800000;
                            if (old !== trial.expired || n - trial.last >= 60000) {
                                trial.last = Math.max(n, trial.last);
                                safe(() => store.setItem(KEY, trial));
                            }
                            return trial.expired;
                        }
                        const battery = safe(() => new sensor.Battery()), step = safe(() => new sensor.Step()), barometer = safe(() => new sensor.Barometer()), time = safe(() => new sensor.Time());
                        img('background.png', 0, 0);
                        const imageSlot = () => {
                            const w = img('cream-64/0.png', 0, 0);
                            show(w, false);
                            return (item, cx, cy) => {
                                show(w, !!item);
                                if (item)
                                    w.setProperty(ui__default.default.prop.MORE, {
                                        src: item.src,
                                        x: Math.round(cx - item.w / 2),
                                        y: Math.round(cy - item.h / 2)
                                    });
                            };
                        };
                        function textSlot(cx, cy) {
                            const pool = [];
                            return (s, f) => {
                                const parts = [...s].map(c => {
                                    var _a;
                                    return (_a = R.glyphs[f]) == null ? void 0 : _a[c];
                                }).filter(Boolean);
                                let x = Math.round(cx - parts.reduce((a, p) => a + p.w, 0) / 2);
                                pool.forEach(w => show(w, false));
                                parts.forEach((p, i) => {
                                    if (!pool[i])
                                        pool[i] = img(p.src, 0, 0);
                                    pool[i].setProperty(ui__default.default.prop.MORE, {
                                        src: p.src,
                                        x,
                                        y: Math.round(cy - p.h / 2)
                                    });
                                    show(pool[i], true);
                                    x += p.w;
                                });
                            };
                        }
                        const weekday = imageSlot(), day = imageSlot(), month = imageSlot(), logo = imageSlot(), separator = imageSlot(), de = imageSlot(), mo = imageSlot(), unit = imageSlot(), bottomUnit = imageSlot(), smallIcon = imageSlot(), shoe = imageSlot();
                        const charge = textSlot(394, 262), bottomText = textSlot(276, 420), smallZero = textSlot(373, 359);
                        const rules = [
                            img('t0-rule.png', 173, 456),
                            img('t0-rule.png', 278, 456)
                        ];
                        const nums = f => Array.from({ length: 10 }, (_, i) => R.glyphs[f][i].src);
                        const clocks = R.themes.map(t => create(ui__default.default.widget.IMG_TIME, {
                            hour_startX: 64,
                            hour_startY: 55,
                            hour_zero: 1,
                            hour_space: 0,
                            hour_array: nums(t.main + '-190'),
                            minute_startX: 64,
                            minute_startY: 224,
                            minute_follow: 0,
                            minute_zero: 1,
                            minute_space: 0,
                            minute_array: nums(t.main + '-190')
                        }));
                        img('battery-outline.png', 345, 202);
                        const fill = create(ui__default.default.widget.FILL_RECT, {
                            x: 351,
                            y: 208,
                            w: 1,
                            h: 20,
                            color: 15384665
                        });
                        const native = (type, f, x, y, w, h) => ui__default.default.data_type[type] === void 0 ? null : create(ui__default.default.widget.TEXT_IMG, {
                            x,
                            y,
                            w,
                            h,
                            type: ui__default.default.data_type[type],
                            font_array: nums(f),
                            dot_image: R.glyphs[f]['.'].src,
                            negative_image: R.glyphs[f]['-'].src,
                            invalid_image: R.glyphs[f]['-'].src,
                            h_space: 0,
                            align_h: ui__default.default.align.CENTER_H
                        });
                        const smallTypes = [
                            'HEART',
                            'WEATHER_CURRENT',
                            'HUMIDITY',
                            'WIND'
                        ];
                        const nativeSmall = R.themes.map(t => smallTypes.map(k => native(k, t.accent + '-64', 301, 335, 144, 49)));
                        const nativeBottom = R.themes.map(t => [
                            null,
                            native('DISTANCE', t.main + '-64', 184, 396, 184, 49),
                            native('CAL', t.main + '-64', 184, 396, 184, 49),
                            null
                        ]);
                        const pending = new Set();
                        const clearTaps = () => {
                            pending.forEach(clearTimeout);
                            pending.clear();
                        };
                        const open = id => {
                            if (awake && !check())
                                safe(() => router.launchApp({
                                    appId: id,
                                    native: true
                                }));
                        };
                        function button(x, y, w, h, fn) {
                            return create(ui__default.default.widget.BUTTON, {
                                x,
                                y,
                                w,
                                h,
                                text: '',
                                normal_src: `hit-${ w }-${ h }.png`,
                                press_src: `hit-${ w }-${ h }.png`,
                                click_func: () => {
                                    if (awake && !check())
                                        fn();
                                    else
                                        refresh();
                                }
                            });
                        }
                        function double(x, y, w, h, single, second) {
                            let id = null, last = 0;
                            button(x, y, w, h, () => {
                                const n = Date.now();
                                if (id !== null && pending.has(id) && n - last <= 330) {
                                    clearTimeout(id);
                                    pending.delete(id);
                                    id = null;
                                    second();
                                    return;
                                }
                                last = n;
                                id = setTimeout(() => {
                                    pending.delete(id);
                                    id = null;
                                    if (awake && !check())
                                        single();
                                }, 330);
                                pending.add(id);
                            });
                        }
                        const batteryTap = ui__default.default.data_type.BATTERY === void 0 ? null : create(ui__default.default.widget.IMG_CLICK, {
                            src: 'hit-125-92.png',
                            x: 335,
                            y: 200,
                            w: 125,
                            h: 92,
                            type: ui__default.default.data_type.BATTERY
                        });
                        function refresh() {
                            if (dead || !awake)
                                return;
                            expired = check();
                            const t = R.themes[theme], d = new Date();
                            clocks.forEach((w, i) => show(w, !expired && theme === i));
                            de(expired ? t.de : null, 176, 128);
                            mo(expired ? t.mo : null, 176, 297);
                            separator(t.separator, 181, 217);
                            logo(t.logo, 239, 455);
                            rules.forEach(w => w.setProperty(ui__default.default.prop.SRC, t.rule.src));
                            weekday(t.weeks[(d.getDay() + 6) % 7], 359, 76);
                            day(t.days[d.getDate()], 369, 120);
                            month(t.months[d.getMonth()], 369, 165);
                            const bat = safe(() => battery.getCurrent()), valid = Number.isFinite(bat) && bat >= 0 && bat <= 100;
                            charge(expired ? '00%' : valid ? Math.round(bat) + '%' : '--%', t.label + '-52');
                            show(batteryTap, !expired);
                            const width = expired ? 0 : valid ? Math.round(77 * bat / 100) : 0;
                            fill.setProperty(ui__default.default.prop.MORE, {
                                x: 351,
                                y: 208,
                                w: Math.max(1, width),
                                h: 20,
                                color: bat <= 20 ? 16008517 : 15384665
                            });
                            show(fill, width > 0);
                            const degrees = safe(() => settings.getTemperatureUnit()) === settings.TEMPERATURE_UNIT_FAHRENHEIT ? '\xB0F' : '\xB0C', distance = safe(() => settings.getDistanceUnit()) === settings.DISTANCE_UNIT_IMPERIAL ? 'mi' : 'km';
                            const names = [
                                    'heart',
                                    'temp',
                                    'hum',
                                    'wind'
                                ], units = [
                                    'HR',
                                    degrees,
                                    '%',
                                    'Bft'
                                ];
                            smallIcon({
                                src: t.label + '-' + names[small] + '.png',
                                w: 32,
                                h: small === 0 ? 30 : 32
                            }, 356, 314);
                            unit(t.units[units[small]], 407, 315);
                            nativeSmall.forEach((ws, i) => ws.forEach((w, j) => show(w, !expired && i === theme && j === small)));
                            smallZero(expired ? '00' : nativeSmall[theme][small] ? '' : '--', t.accent + '-64');
                            const bUnits = [
                                '',
                                distance,
                                'kcal',
                                'hPa'
                            ];
                            bottomUnit(bottom ? t.units[bUnits[bottom]] : null, 153, 419);
                            shoe(bottom === 0 ? {
                                src: t.label + '-shoe.png',
                                w: 65,
                                h: 40
                            } : null, 153.5, 418);
                            nativeBottom.forEach((ws, i) => ws.forEach((w, j) => show(w, !expired && i === theme && j === bottom)));
                            let text = '';
                            if (expired)
                                text = '00';
                            else if (bottom === 0) {
                                const n = safe(() => step.getCurrent());
                                text = Number.isFinite(n) && n >= 0 && n <= 99999 ? String(Math.round(n)) : '--';
                            } else if (bottom === 3) {
                                const n = safe(() => barometer.getAirPressure());
                                text = Number.isFinite(n) && n > 0 && n <= 1200 ? String(Math.round(n)) : '--';
                            } else if (!nativeBottom[theme][bottom])
                                text = '--';
                            bottomText(text, t.main + '-' + (text.length > 4 && !text.includes('.') ? 56 : 64));
                            if (expired) {
                                clearTaps();
                                stopTimer();
                            }
                        }
                        function stopTimer() {
                            if (timer !== null) {
                                clearInterval(timer);
                                timer = null;
                            }
                        }
                        function pause() {
                            awake = false;
                            clearTaps();
                            stopTimer();
                            if (registered) {
                                for (const sensor of [
                                        battery,
                                        step,
                                        barometer
                                    ])
                                    safe(() => sensor.offChange(refresh));
                                safe(() => time.offPerMinute(refresh));
                                registered = false;
                            }
                            {
                                check();
                                trial.last = Math.max(trial.last, Date.now());
                                safe(() => store.setItem(KEY, trial));
                            }
                        }
                        function resume() {
                            if (dead)
                                return;
                            pause();
                            awake = true;
                            refresh();
                            if (!expired) {
                                for (const sensor of [
                                        battery,
                                        step,
                                        barometer
                                    ])
                                    safe(() => sensor.onChange(refresh));
                                safe(() => time.onPerMinute(refresh));
                                registered = true;
                                timer = setInterval(refresh, 1000);
                            }
                        }
                        button(64, 55, 224, 146, () => open(router.SYSTEM_APP_ALARM));
                        button(64, 224, 224, 146, () => open(router.SYSTEM_APP_ALARM));
                        button(315, 53, 150, 140, () => open(router.SYSTEM_APP_CALENDAR));
                        double(308, 294, 145, 100, () => {
                            small = (small + 1) % 4;
                            persist();
                            refresh();
                        }, () => open(small === 0 ? router.SYSTEM_APP_HR : router.SYSTEM_APP_WEATHER));
                        double(110, 391, 280, 54, () => {
                            bottom = (bottom + 1) % 4;
                            persist();
                            refresh();
                        }, () => open(bottom === 3 ? router.SYSTEM_APP_ALTIMETER : router.SYSTEM_APP_STATUS));
                        button(164, 440, 150, 36, () => {
                            theme = (theme + 1) % 3;
                            persist();
                            refresh();
                        });
                        create(ui__default.default.widget.WIDGET_DELEGATE, {
                            pause_call: pause,
                            resume_call: resume
                        });
                        cleanup = () => {
                            pause();
                            dead = true;
                            cleanup = () => {
                            };
                        };
                        resume();
                    },
                    onDestroy() {
                        cleanup();
                    }
                });
                ;
            }
        }.bind(__$$G$$__)(__$$G$$__);
        afterPageCreate();
        afterModuleCreate();
        ;
    })());
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
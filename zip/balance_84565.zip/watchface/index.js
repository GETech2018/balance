﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

//#region functions

function read_pressure() {
    console.log("read_pressure()");
    const file_name_alt = "../../../baro_altim/pressure.dat";
    const [fs_stat, err] = hmFS.stat(file_name_alt);
    if (err == 0) {
      let file_size = fs_stat.size;
      const len = file_size / 4;
      console.log(`size_alt: ${file_size}, lenght: ${len}`)
      const fh = hmFS.open(file_name_alt, hmFS.O_RDONLY)
  
      let array_buffer = new Float32Array(len);
      hmFS.read(fh, array_buffer.buffer, 0, file_size);
      hmFS.close(fh);
      console.log(`value ${array_buffer[array_buffer.length -1]}`);
      return array_buffer;
    } else {
      console.log('err:', err)
    }
    return null;
  }
  
  function getPressureValue(pressure_array) {
    console.log("getPressureValue()");
    if(pressure_array == null || pressure_array == undefined || pressure_array.length == 0) return 0;
    let start_index = pressure_array.length - 1;
    let end_index = start_index - 30*3; // 3 часа
    if(end_index < 0) end_index = 0;
    for (let index = start_index; index >= end_index; index--) {
      if(pressure_array[index] != 0) return parseInt(pressure_array[index] / 100);
    }
    return 0;
  }
  
  function changesPressure(pressure_array) {
    console.log("changesPressure()");
    if(pressure_array == null || pressure_array == undefined || pressure_array.length == 0) return 0;
    let start_index = pressure_array.length - 1;
    let end_index = start_index - 30*3; // 3 часа
    let value = pressure_array[start_index];
    let result = 0;
    if(end_index < 0) end_index = 0;
    for (let index = start_index; index >= end_index; index--) {
      let element = pressure_array[index];
      if(element != 0) {
        if(Math.abs(value - element) > 10) { // учитываем только если разниза больше 0,1 hPa
          value = value - element;
          console.log(`element = ${element}`);
          console.log(`pressere_changes = ${value}`);
          return value;
        }
      }
    }
    return result;
  }
  
  function hPa_To_mmHg(hPa_value = 0) {
    let mmHg = Math.round(hPa_value * 0.750064);
    return mmHg;
  }
  //#endregion
  
        let text_pressere;
        //
        let btn_bezel = ''
        let bezel_num = 1
        let bezel_all = 6
        let element_index = 1;  // Selected element index
        let element_count = 2;  // Number of elements        
        // 
  
        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_wind_direction_image_progress_img_level = ''
        let normal_wind_text_text_img = ''
        let normal_wind_text_separator_img = ''
        let normal_humidity_text_text_img = ''
        let normal_humidity_text_separator_img = ''
        let normal_day_TextCircle = new Array(2);
        let normal_day_TextCircle_ASCIIARRAY = new Array(10);
        let normal_day_TextCircle_img_width = 23;
        let normal_day_TextCircle_img_height = 31;
        let normal_timerTextUpdate = undefined;
        let normal_date_img_date_month = ''
        let normal_date_img_date_week_img = ''
        let normal_calorie_icon_img = ''
        let normal_calorie_circle_scale = ''
        let normal_calorie_current_text_font = ''
        let normal_step_circle_scale = ''
        let normal_step_current_text_font = ''
        let normal_heart_rate_circle_scale = ''
        let normal_heart_rate_text_font = ''
        let normal_battery_circle_scale = ''
        let normal_battery_image_progress_img_level = ''
        let normal_battery_current_text_font = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_image_img = ''
        let normal_city_name_text = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_TextCircle = new Array(4);
        let normal_temperature_current_TextCircle_ASCIIARRAY = new Array(10);
        let normal_temperature_current_TextCircle_img_width = 23;
        let normal_temperature_current_TextCircle_img_height = 31;
        let normal_temperature_current_TextCircle_unit = null;
        let normal_temperature_current_TextCircle_unit_width = 23;
        let normal_temperature_current_TextCircle_dot_width = 23;
        let normal_temperature_current_TextCircle_error_img_width = 23;
        let normal_analog_clock_pro_second_pointer_img = ''
        let normal_timerUpdateSec = undefined;
        let normal_timerUpdateSecSmooth = undefined;
        let normal_digital_clock_img_time = ''
        let idle_background_bg = ''
        let idle_calorie_icon_img = ''
        let idle_calorie_circle_scale = ''
        let idle_calorie_current_text_font = ''
        let idle_step_circle_scale = ''
        let idle_step_current_text_font = ''
        let idle_heart_rate_circle_scale = ''
        let idle_heart_rate_text_font = ''
        let idle_battery_circle_scale = ''
        let idle_battery_current_text_font = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_image_img = ''
        let idle_digital_clock_img_time = ''
        let idle_pai_icon_img = ''
        let normal_step_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_battery_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_fatBurning_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let timeSensor = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
            //

            function click_Bezel() {
              if(bezel_num>=bezel_all) {bezel_num=1;}
              else { bezel_num=bezel_num+1;}
              hmUI.showToast({text: "Цвет " + parseInt(bezel_num) });
                normal_background_bg_img.setProperty(hmUI.prop.SRC, "osn_" + parseInt(bezel_num) + ".png");
            } 

            //                     
                
            // FontName: GoogleSans-Regular.ttf; FontSize: 35
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 464,
              h: 52,
              text_size: 35,
              char_space: 0,
              line_space: 0,
              font: 'fonts/GoogleSans-Regular.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: GoogleSans-Regular.ttf; FontSize: 22
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 307,
              h: 34,
              text_size: 22,
              char_space: 0,
              line_space: 0,
              font: 'fonts/GoogleSans-Regular.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: GoogleSans-Regular.ttf; FontSize: 35; Cache: full
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 42,
              h: 42,
              text_size: 35,
              char_space: 0,
              line_space: 0,
              font: 'fonts/GoogleSans-Regular.ttf',
              color: 0xFF000000,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.NONE,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'osn_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('user_script.js');
            // start user_script.js


            text_pressere = hmUI.createWidget(hmUI.widget.TEXT);
            text_pressere.setProperty(hmUI.prop.MORE, {
              x: 10,
              y: 10,
              w: 460,
              h: 460,                            
              text_size: 35,
              font: 'fonts/GoogleSans-Regular.ttf',
              color: 0xFF000000,              
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              text: "--",
              char_space: 0,
              start_angle: -37,
              end_angle: 183,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            //
  

            // end user_script.js

            normal_wind_direction_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 0,
              y: 0,
              image_array: ["wind_0.png","wind_1.png","wind_2.png","wind_3.png","wind_4.png","wind_5.png","wind_6.png","wind_7.png"],
              image_length: 8,
              type: hmUI.data_type.WIND_DIRECTION,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 407,
              y: 315,
              font_array: ["data_0.png","data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png"],
              padding: false,
              h_space: 0,
              angle: -67,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WIND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 1,
              y: -4,
              src: 'data_ms.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 19,
              y: 267,
              font_array: ["data_0.png","data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png"],
              padding: false,
              h_space: 0,
              angle: 74,
              unit_sc: 'clean.png',
              unit_tc: 'clean.png',
              unit_en: 'clean.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 30,
              y: 279,
              src: 'data_pr.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_day_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 240,
              // circle_center_Y: 240,
              // font_array: ["data_0.png","data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png"],
              // radius: 191,
              // angle: -72,
              // char_space_angle: 0,
              // zero: false,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.DAY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_day_TextCircle_ASCIIARRAY[0] = 'data_0.png';  // set of images with numbers
            normal_day_TextCircle_ASCIIARRAY[1] = 'data_1.png';  // set of images with numbers
            normal_day_TextCircle_ASCIIARRAY[2] = 'data_2.png';  // set of images with numbers
            normal_day_TextCircle_ASCIIARRAY[3] = 'data_3.png';  // set of images with numbers
            normal_day_TextCircle_ASCIIARRAY[4] = 'data_4.png';  // set of images with numbers
            normal_day_TextCircle_ASCIIARRAY[5] = 'data_5.png';  // set of images with numbers
            normal_day_TextCircle_ASCIIARRAY[6] = 'data_6.png';  // set of images with numbers
            normal_day_TextCircle_ASCIIARRAY[7] = 'data_7.png';  // set of images with numbers
            normal_day_TextCircle_ASCIIARRAY[8] = 'data_8.png';  // set of images with numbers
            normal_day_TextCircle_ASCIIARRAY[9] = 'data_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              normal_day_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 240,
                center_y: 240,
                pos_x: 240 - normal_day_TextCircle_img_width / 2,
                pos_y: 240 - 222,
                src: 'data_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_day_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            let screenType = hmSetting.getScreenType();            
            function toDegree (radian) {
              return radian * (180 / Math.PI);
            };

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 0,
              month_startY: 0,
              month_sc_array: ["mon_0.png","mon_1.png","mon_2.png","mon_3.png","mon_4.png","mon_5.png","mon_6.png","mon_7.png","mon_8.png","mon_9.png"],
              month_tc_array: ["mon_0.png","mon_1.png","mon_2.png","mon_3.png","mon_4.png","mon_5.png","mon_6.png","mon_7.png","mon_8.png","mon_9.png"],
              month_en_array: ["mon_0.png","mon_1.png","mon_2.png","mon_3.png","mon_4.png","mon_5.png","mon_6.png","mon_7.png","mon_8.png","mon_9.png"],
              month_zero: 0,
              month_space: 0,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 0,
              y: 0,
              week_en: ["day_0.png","day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png"],
              week_tc: ["day_0.png","day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png"],
              week_sc: ["day_0.png","day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'zapl_2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_cal_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 239,
              // center_y: 239,
              // start_angle: -160,
              // end_angle: 57,
              // radius: 109,
              // line_width: 15,
              // line_cap: Rounded,
              // color: 0xFFA5AD05,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_calorie_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 239,
              center_y: 239,
              start_angle: -160,
              end_angle: 57,
              radius: 102,
              line_width: 15,
              corner_flag: 0,
              color: 0xFFA5AD05,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const calorie = hmSensor.createSensor(hmSensor.id.CALORIE);
            calorie.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_calorie_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 250,
              y: 313,
              w: 150,
              h: 50,
              text_size: 35,
              char_space: 0,
              line_space: 0,
              font: 'fonts/GoogleSans-Regular.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 240,
              // center_y: 240,
              // start_angle: -148,
              // end_angle: 37,
              // radius: 81,
              // line_width: 14,
              // line_cap: Rounded,
              // color: 0xFF137499,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 240,
              center_y: 240,
              start_angle: -148,
              end_angle: 37,
              radius: 74,
              line_width: 14,
              corner_flag: 0,
              color: 0xFF137499,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_step_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 250,
              y: 281,
              w: 150,
              h: 50,
              text_size: 35,
              char_space: 0,
              line_space: 0,
              font: 'fonts/GoogleSans-Regular.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_heart_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 240,
              // center_y: 240,
              // start_angle: -164,
              // end_angle: 63,
              // radius: 142,
              // line_width: 19,
              // line_cap: Rounded,
              // color: 0xFFB50000,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_heart_rate_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 240,
              center_y: 240,
              start_angle: -164,
              end_angle: 63,
              radius: 133,
              line_width: 19,
              corner_flag: 0,
              color: 0xFFB50000,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const heart_rate = hmSensor.createSensor(hmSensor.id.HEART);
            heart_rate.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_heart_rate_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 250,
              y: 346,
              w: 150,
              h: 50,
              text_size: 35,
              char_space: 0,
              line_space: 0,
              font: 'fonts/GoogleSans-Regular.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 239,
              // center_y: 239,
              // start_angle: -168,
              // end_angle: 71,
              // radius: 176,
              // line_width: 23,
              // line_cap: Rounded,
              // color: 0xFF117403,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 239,
              center_y: 239,
              start_angle: -168,
              end_angle: 71,
              radius: 165,
              line_width: 23,
              corner_flag: 0,
              color: 0xFF117403,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 210,
              y: 386,
              image_array: ["bt_0.png","bt_1.png","bt_2.png","bt_3.png","bt_4.png","bt_5.png","bt_6.png","bt_7.png","bt_8.png","bt_9.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 166,
              y: 386,
              w: 150,
              h: 30,
              text_size: 22,
              char_space: 0,
              line_space: 0,
              font: 'fonts/GoogleSans-Regular.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 4,
              y: 0,
              src: 'bt_off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 5,
              y: -1,
              src: 'alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'zapl_3.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

            
            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT);
            normal_city_name_text.setProperty(hmUI.prop.MORE, {
              x: 10,
              y: 10,
              w: 460,
              h: 460,
              text_size: 35,
              char_space: 0,
              //line_space: 0,
              font: 'fonts/GoogleSans-Regular.ttf',
              color: 0xFF000000,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "--",              
              start_angle: -108,
              end_angle: 112,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 0,
              y: 0,
              image_array: ["weather_0.png","weather_1.png","weather_2.png","weather_3.png","weather_4.png","weather_5.png","weather_6.png","weather_7.png","weather_8.png","weather_9.png","weather_10.png","weather_11.png","weather_12.png","weather_13.png","weather_14.png","weather_15.png","weather_16.png","weather_17.png","weather_18.png","weather_19.png","weather_20.png","weather_21.png","weather_22.png","weather_23.png","weather_24.png","weather_25.png","weather_26.png","weather_27.png","weather_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_temperature_current_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 240,
              // circle_center_Y: 240,
              // font_array: ["data_0.png","data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png"],
              // radius: 223,
              // angle: -135,
              // char_space_angle: 0,
              // unit: 'data_cel.png',
              // dot_image: 'data_mn.png',
              // error_image: 'data_zn.png',
              // zero: false,
              // reverse_direction: true,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.WEATHER_CURRENT,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_temperature_current_TextCircle_ASCIIARRAY[0] = 'data_0.png';  // set of images with numbers
            normal_temperature_current_TextCircle_ASCIIARRAY[1] = 'data_1.png';  // set of images with numbers
            normal_temperature_current_TextCircle_ASCIIARRAY[2] = 'data_2.png';  // set of images with numbers
            normal_temperature_current_TextCircle_ASCIIARRAY[3] = 'data_3.png';  // set of images with numbers
            normal_temperature_current_TextCircle_ASCIIARRAY[4] = 'data_4.png';  // set of images with numbers
            normal_temperature_current_TextCircle_ASCIIARRAY[5] = 'data_5.png';  // set of images with numbers
            normal_temperature_current_TextCircle_ASCIIARRAY[6] = 'data_6.png';  // set of images with numbers
            normal_temperature_current_TextCircle_ASCIIARRAY[7] = 'data_7.png';  // set of images with numbers
            normal_temperature_current_TextCircle_ASCIIARRAY[8] = 'data_8.png';  // set of images with numbers
            normal_temperature_current_TextCircle_ASCIIARRAY[9] = 'data_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 4; i++) {
              normal_temperature_current_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 240,
                center_y: 240,
                pos_x: 240 - normal_temperature_current_TextCircle_img_width / 2,
                pos_y: 240 + 192,
                src: 'data_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_temperature_current_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_temperature_current_TextCircle_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              center_x: 240,
              center_y: 240,
              pos_x: 240 - normal_temperature_current_TextCircle_unit_width / 2,
              pos_y: 240 + 192,
              src: 'data_cel.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_temperature_current_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block

            const deviceInfo = hmSetting.getDeviceInfo();
            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);               
            // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'sek_1.png',
              // center_x: 239,
              // center_y: 239,
              // x: 240,
              // y: 239,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 239 - 240,
              pos_y: 239 - 239,
              center_x: 239,
              center_y: 239,
              src: 'sek_1.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            // normal_analog_clock_pro_smooth_second = hmUI.createWidget(hmUI.widget.SMOOTH_SECOND, {
              // type: 2,
              // fps: 15,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // }); 
            normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.VISIBLE, false);  // Disable element display  
              

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 81,
              hour_startY: 189,
              hour_array: ["H_0.png","H_1.png","H_2.png","H_3.png","H_4.png","H_5.png","H_6.png","H_7.png","H_8.png","H_9.png"],
              hour_zero: 1,
              hour_space: 1,
              hour_angle: 0,
              hour_align: hmUI.align.RIGHT,

              minute_startX: 249,
              minute_startY: 189,
              minute_array: ["M_0.png","M_1.png","M_2.png","M_3.png","M_4.png","M_5.png","M_6.png","M_7.png","M_8.png","M_9.png"],
              minute_zero: 1,
              minute_space: 1,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: -79,
              second_startY: 190,
              second_array: ["sekk_0.png","sekk_1.png","sekk_2.png","sekk_3.png","sekk_4.png","sekk_5.png","sekk_6.png","sekk_7.png","sekk_8.png","sekk_9.png"],
              second_zero: 0,
              second_space: 291,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFF50010F',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'zapl_2.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_cal_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 239,
              // center_y: 239,
              // start_angle: -160,
              // end_angle: 57,
              // radius: 109,
              // line_width: 15,
              // line_cap: Rounded,
              // color: 0xFF808080,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_calorie_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 239,
              center_y: 239,
              start_angle: -160,
              end_angle: 57,
              radius: 102,
              line_width: 15,
              corner_flag: 0,
              color: 0xFF808080,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 250,
              y: 313,
              w: 150,
              h: 50,
              text_size: 35,
              char_space: 0,
              line_space: 0,
              font: 'fonts/GoogleSans-Regular.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 240,
              // center_y: 240,
              // start_angle: -148,
              // end_angle: 39,
              // radius: 81,
              // line_width: 14,
              // line_cap: Rounded,
              // color: 0xFF808080,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 240,
              center_y: 240,
              start_angle: -148,
              end_angle: 39,
              radius: 74,
              line_width: 14,
              corner_flag: 0,
              color: 0xFF808080,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 250,
              y: 281,
              w: 150,
              h: 50,
              text_size: 35,
              char_space: 0,
              line_space: 0,
              font: 'fonts/GoogleSans-Regular.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_heart_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 240,
              // center_y: 240,
              // start_angle: -164,
              // end_angle: 63,
              // radius: 142,
              // line_width: 19,
              // line_cap: Rounded,
              // color: 0xFF808080,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_heart_rate_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 240,
              center_y: 240,
              start_angle: -164,
              end_angle: 63,
              radius: 133,
              line_width: 19,
              corner_flag: 0,
              color: 0xFF808080,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 250,
              y: 346,
              w: 150,
              h: 50,
              text_size: 35,
              char_space: 0,
              line_space: 0,
              font: 'fonts/GoogleSans-Regular.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 239,
              // center_y: 239,
              // start_angle: -168,
              // end_angle: 70,
              // radius: 176,
              // line_width: 22,
              // line_cap: Rounded,
              // color: 0xFF808080,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 239,
              center_y: 239,
              start_angle: -168,
              end_angle: 70,
              radius: 165,
              line_width: 22,
              corner_flag: 0,
              color: 0xFF808080,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 166,
              y: 386,
              w: 150,
              h: 30,
              text_size: 22,
              char_space: 0,
              line_space: 0,
              font: 'fonts/GoogleSans-Regular.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 45,
              y: -24,
              src: 'bt_off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: -7,
              y: -1,
              src: 'alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'zapl_aod2.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 81,
              hour_startY: 189,
              hour_array: ["H_0.png","H_1.png","H_2.png","H_3.png","H_4.png","H_5.png","H_6.png","H_7.png","H_8.png","H_9.png"],
              hour_zero: 1,
              hour_space: 1,
              hour_angle: 0,
              hour_align: hmUI.align.RIGHT,

              minute_startX: 249,
              minute_startY: 189,
              minute_array: ["H_0.png","H_1.png","H_2.png","H_3.png","H_4.png","H_5.png","H_6.png","H_7.png","H_8.png","H_9.png"],
              minute_zero: 1,
              minute_space: 1,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_pai_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 231,
              y: 190,
              src: 'sekk_0.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 219,
              y: 284,
              w: 100,
              h: 32,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 217,
              y: 354,
              w: 100,
              h: 29,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 215,
              y: 386,
              w: 63,
              h: 41,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 340,
              y: 320,
              w: 49,
              h: 48,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 284,
              y: 208,
              w: 87,
              h: 62,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 361,
              y: 280,
              w: 47,
              h: 38,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_fatBurning_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 220,
              y: 318,
              w: 100,
              h: 34,
              type: hmUI.data_type.FAT_BURNING,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 112,
              y: 205,
              w: 86,
              h: 61,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'clean.png',
              normal_src: 'clean.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'FlashLightScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 223,
              y: 206,
              w: 36,
              h: 63,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'clean.png',
              normal_src: 'clean.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'SportListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            //start of ignored block
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              let normal_fullAngle_second = 360;
              let normal_angle_second = 0 + normal_fullAngle_second*(second + (timeSensor.utc % 1000)/1000)/60;
              if (normal_analog_clock_pro_second_pointer_img) normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_second);

            };

            //end of ignored block
            //start of ignored block
            function text_update() {
              console.log('text_update()');

              console.log('update text circle day_TIME');
              let valueDay = timeSensor.day;
              let normal_day_circle_string = parseInt(valueDay).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_day_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = -72;
                if (valueDay != null && valueDay != undefined && isFinite(valueDay) && normal_day_circle_string.length > 0 && normal_day_circle_string.length <= 2) {  // display data if it was possible to get it
                  let normal_day_TextCircle_img_angle = 0;
                  let normal_day_TextCircle_dot_img_angle = 0;
                  normal_day_TextCircle_img_angle = toDegree(Math.atan2(normal_day_TextCircle_img_width/2, 191));
                  // alignment = CENTER_H
                  let normal_day_TextCircle_angleOffset = normal_day_TextCircle_img_angle * (normal_day_circle_string.length - 1);
                  char_Angle -= normal_day_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_day_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += normal_day_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_day_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_day_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - normal_day_TextCircle_img_width / 2);
                      normal_day_TextCircle[index].setProperty(hmUI.prop.SRC, normal_day_TextCircle_ASCIIARRAY[charCode]);
                      normal_day_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_day_TextCircle_img_angle;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };
              let weatherData = weatherSensor.getForecastWeather();
              let temperature_current_temp = -100;
              if (weatherSensor.current != undefined && weatherSensor.current != 'undefined') {
                temperature_current_temp = weatherSensor.current;
              }; // end currentWeather;

              console.log('update text circle temperature_current_currentWeather');
              let temperatureCurrent = undefined;
              let normal_temperature_current_circle_string = undefined;
              if (temperature_current_temp > -100) {
                temperatureCurrent = 0;
                normal_temperature_current_circle_string = String(temperature_current_temp)
              };

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 4; i++) {  // hide all symbols
                  normal_temperature_current_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_temperature_current_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
                let char_Angle = 45;
                if (temperatureCurrent != null && temperatureCurrent != undefined && isFinite(temperatureCurrent) && normal_temperature_current_circle_string.length > 0 && normal_temperature_current_circle_string.length <= 4) {  // display data if it was possible to get it
                  let normal_temperature_current_TextCircle_img_angle = 0;
                  let normal_temperature_current_TextCircle_dot_img_angle = 0;
                  let normal_temperature_current_TextCircle_unit_angle = 0;
                  normal_temperature_current_TextCircle_img_angle = toDegree(Math.atan2(normal_temperature_current_TextCircle_img_width/2, 223));
                  normal_temperature_current_TextCircle_dot_img_angle = toDegree(Math.atan2(normal_temperature_current_TextCircle_dot_width/2, 223));
                  normal_temperature_current_TextCircle_unit_angle = toDegree(Math.atan2(normal_temperature_current_TextCircle_unit_width/2, 223));
                  // alignment = CENTER_H
                  let normal_temperature_current_TextCircle_angleOffset = normal_temperature_current_TextCircle_img_angle * (normal_temperature_current_circle_string.length - 1);
                  normal_temperature_current_TextCircle_angleOffset = normal_temperature_current_TextCircle_angleOffset + (normal_temperature_current_TextCircle_img_angle + normal_temperature_current_TextCircle_unit_angle + 0) / 2;
                  normal_temperature_current_TextCircle_angleOffset = -normal_temperature_current_TextCircle_angleOffset;
                  char_Angle -= normal_temperature_current_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_temperature_current_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 4) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= normal_temperature_current_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_temperature_current_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_temperature_current_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - normal_temperature_current_TextCircle_img_width / 2);
                      normal_temperature_current_TextCircle[index].setProperty(hmUI.prop.SRC, normal_temperature_current_TextCircle_ASCIIARRAY[charCode]);
                      normal_temperature_current_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= normal_temperature_current_TextCircle_img_angle;
                      index++;
                    }  // end if digit
                    else { 
                      if (!firstSymbol) char_Angle -= normal_temperature_current_TextCircle_dot_img_angle; 
                      firstSymbol = false;
                      normal_temperature_current_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_temperature_current_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - normal_temperature_current_TextCircle_dot_width / 2);
                      normal_temperature_current_TextCircle[index].setProperty(hmUI.prop.SRC, 'data_mn.png');
                      normal_temperature_current_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= normal_temperature_current_TextCircle_dot_img_angle;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                  char_Angle -= normal_temperature_current_TextCircle_unit_angle;
                  normal_temperature_current_TextCircle_unit.setProperty(hmUI.prop.ANGLE, char_Angle);
                  normal_temperature_current_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite
                else {
                  normal_temperature_current_TextCircle[0].setProperty(hmUI.prop.ANGLE, char_Angle);
                  normal_temperature_current_TextCircle[0].setProperty(hmUI.prop.POS_X, 240 - normal_temperature_current_TextCircle_error_img_width / 2);
                  normal_temperature_current_TextCircle[0].setProperty(hmUI.prop.SRC, 'data_zn.png');
                  normal_temperature_current_TextCircle[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

            };

            //end of ignored block
            function scale_call() {
              console.log('scale_call()');

                console.log('update scales CALORIE');
                
                let valueCalories = calorie.current;
                let targetCalories = calorie.target;
                let progressCalories = valueCalories/targetCalories;
                if (progressCalories > 1) progressCalories = 1;
                let progress_cs_normal_calorie = progressCalories;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_calorie_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_calorie * 100);
                  if (normal_calorie_circle_scale) {
                    normal_calorie_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 239,
                      center_y: 239,
                      start_angle: -160,
                      end_angle: 57,
                      radius: 102,
                      line_width: 15,
                      corner_flag: 0,
                      color: 0xFFA5AD05,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_cs_normal_step = progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_step * 100);
                  if (normal_step_circle_scale) {
                    normal_step_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 240,
                      center_y: 240,
                      start_angle: -148,
                      end_angle: 37,
                      radius: 74,
                      line_width: 14,
                      corner_flag: 0,
                      color: 0xFF137499,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales HEART');
                
                let valueHeartRate = heart_rate.last;
                let targetHeartRate = 179;
                let progressHeartRate = (valueHeartRate - 71)/(targetHeartRate - 71);
                if (progressHeartRate < 0) progressHeartRate = 0;
                if (progressHeartRate > 1) progressHeartRate = 1;
                let progress_cs_normal_heart_rate = progressHeartRate;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_heart_rate_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_heart_rate * 100);
                  if (normal_heart_rate_circle_scale) {
                    normal_heart_rate_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 240,
                      center_y: 240,
                      start_angle: -164,
                      end_angle: 63,
                      radius: 133,
                      line_width: 19,
                      corner_flag: 0,
                      color: 0xFFB50000,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_cs_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_battery * 100);
                  if (normal_battery_circle_scale) {
                    normal_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 239,
                      center_y: 239,
                      start_angle: -168,
                      end_angle: 71,
                      radius: 165,
                      line_width: 23,
                      corner_flag: 0,
                      color: 0xFF117403,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

              console.log('Weather city name');
              let weatherData = weatherSensor.getForecastWeather();
              normal_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

                console.log('update scales CALORIE');
                let progress_cs_idle_calorie = progressCalories;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_calorie_circle_scale_circle_scale
                  let level = Math.round(progress_cs_idle_calorie * 100);
                  if (idle_calorie_circle_scale) {
                    idle_calorie_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 239,
                      center_y: 239,
                      start_angle: -160,
                      end_angle: 57,
                      radius: 102,
                      line_width: 15,
                      corner_flag: 0,
                      color: 0xFF808080,
                      show_level: hmUI.show_level.ONLY_AOD,
                      level: level,
                    });
                  };
                };

                console.log('update scales STEP');
                let progress_cs_idle_step = progressStep;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_step_circle_scale_circle_scale
                  let level = Math.round(progress_cs_idle_step * 100);
                  if (idle_step_circle_scale) {
                    idle_step_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 240,
                      center_y: 240,
                      start_angle: -148,
                      end_angle: 39,
                      radius: 74,
                      line_width: 14,
                      corner_flag: 0,
                      color: 0xFF808080,
                      show_level: hmUI.show_level.ONLY_AOD,
                      level: level,
                    });
                  };
                };

                console.log('update scales HEART');
                let progress_cs_idle_heart_rate = progressHeartRate;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_heart_rate_circle_scale_circle_scale
                  let level = Math.round(progress_cs_idle_heart_rate * 100);
                  if (idle_heart_rate_circle_scale) {
                    idle_heart_rate_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 240,
                      center_y: 240,
                      start_angle: -164,
                      end_angle: 63,
                      radius: 133,
                      line_width: 19,
                      corner_flag: 0,
                      color: 0xFF808080,
                      show_level: hmUI.show_level.ONLY_AOD,
                      level: level,
                    });
                  };
                };

                console.log('update scales BATTERY');
                let progress_cs_idle_battery = progressBattery;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_battery_circle_scale_circle_scale
                  let level = Math.round(progress_cs_idle_battery * 100);
                  if (idle_battery_circle_scale) {
                    idle_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 239,
                      center_y: 239,
                      start_angle: -168,
                      end_angle: 70,
                      radius: 165,
                      line_width: 22,
                      corner_flag: 0,
                      color: 0xFF808080,
                      show_level: hmUI.show_level.ONLY_AOD,
                      level: level,
                    });
                  };
                };

            };
            //click zona     

            function click_btn() {  // Function to enable and disable the visibility of elements
              element_index++;
              if(element_index > element_count) element_index = 1;
              normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.VISIBLE, element_index == 2);              
                                                                                                                
              if (element_index == 1) {
                hmUI.showToast({text: 'Вид 1'});
              };
              if (element_index == 2) {
                hmUI.showToast({text: 'Вид 2'});
              };
            };


            //end click zona
            // Button to switch elements. This block should be after all blocks with display elements.
            hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 430,  // x coordinate of the button
              y: 210,  // y coordinate of the button
              text: '',
              w: 50,  // button width
              h: 50,  // button height
              normal_src: 'clean.png',  // transparent image
              press_src: 'clean.png',  // transparent image
              show_level: hmUI.show_level.ONLY_NORMAL,
              click_func: () => {
                click_btn();
              }
            });
            // end button 
            //
            btn_bezel = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 405,
              y: 110,
              text: '',
              w: 50,
              h: 50,
              normal_src: 'clean.png',
              press_src: 'clean.png',
              click_func: () => {
               click_Bezel();
               
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btn_bezel.setProperty(hmUI.prop.VISIBLE, true);

            // 
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                time_update(true, true);
                text_update();
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerTextUpdate) {
                    normal_timerTextUpdate = timer.createTimer(0, 1000, (function (option) {
                      text_update();
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSecSmooth) {
                    let animDelay = 0;
                    let animRepeat = 1000/15;
                    normal_timerUpdateSecSmooth = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, false);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


                console.log('resume_call.js');
                // start resume_call.js

let pressure_array = read_pressure();
let value = getPressureValue(pressure_array);
value = hPa_To_mmHg(value);
let value_str = value == 0 ? "--" : value + " ";
text_pressere.setProperty(hmUI.prop.TEXT, value_str);
//
            
                // end resume_call.js

              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerTextUpdate) {
                  timer.stopTimer(normal_timerTextUpdate);
                  normal_timerTextUpdate = undefined;
                }
                if (normal_timerUpdateSec) {
                  timer.stopTimer(normal_timerUpdateSec);
                  normal_timerUpdateSec = undefined;
                }
                if (normal_timerUpdateSecSmooth) {
                  timer.stopTimer(normal_timerUpdateSecSmooth);
                  normal_timerUpdateSecSmooth = undefined;
                }                   

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
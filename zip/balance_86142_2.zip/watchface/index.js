﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg = ''
        let normal_image_img = ''
        let normal_pai_icon_img = ''
        let normal_distance_icon_img = ''
        let normal_step_linear_scale = ''
        let normal_step_current_text_font = ''
        let normal_battery_current_text_font = ''
        let normal_heart_rate_text_font = ''
        let normal_date_img_date_month_img = ''
        let normal_system_clock_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg = ''
        let idle_image_img = ''
        let idle_pai_icon_img = ''
        let idle_step_linear_scale = ''
        let idle_step_current_text_font = ''
        let idle_battery_current_text_font = ''
        let idle_heart_rate_text_font = ''
        let idle_date_img_date_month_img = ''
        let idle_system_clock_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_temperature_current_text_img = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_week_img = ''
        let idle_digital_clock_img_time = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let Button_7 = ''
        let Button_8 = ''
        let Button_9 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            // FontName: FIHover-Display.ttf; FontSize: 23
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 476,
              h: 31,
              text_size: 23,
              char_space: 5,
              line_space: 0,
              font: 'fonts/FIHover-Display.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: FIHover-Display.ttf; FontSize: 28
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 496,
              h: 38,
              text_size: 28,
              char_space: 3,
              line_space: 0,
              font: 'fonts/FIHover-Display.ttf',
              color: 0xFF00FF00,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.BOTTOM,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: CreatoDisplay_BoldItalic.ttf; FontSize: 25
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 510,
              h: 33,
              text_size: 25,
              char_space: 6,
              line_space: 0,
              font: 'fonts/CreatoDisplay_BoldItalic.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: -36,
              y: 34,
              src: 'Batt_rotate.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'Sq_Base.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'wind.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            if (screenType != hmSetting.screen_type.AOD) {
              normal_step_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);

            normal_step_linear_scale.setAlpha(150);
            };

            // normal_step_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 44,
              // start_y: 307,
              // color: 0xFF000000,
              // lenght: 392,
              // line_width: 22,
              // line_cap: Flat,
              // vertical: False,
              // mirror: False,
              // inversion: True,
              // alpha: 150,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_step_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 434,
              y: -328,
              w: 1128,
              h: 1128,
              text_size: 23,
              char_space: 5,
              font: 'fonts/FIHover-Display.ttf',
              color: 0xFFFFFFFF,
              // use_text_circle: true,
              start_angle: 264,
              end_angle: 274,
              mode: 1,
              // radius: 564,
              align_h: hmUI.align.LEFT,
              padding: true,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 167,
              y: 445,
              w: 150,
              h: 30,
              text_size: 28,
              char_space: 3,
              font: 'fonts/FIHover-Display.ttf',
              color: 0xFF00FF00,
              line_space: 0,
              align_v: hmUI.align.BOTTOM,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              padding: true,
              unit_type: 1,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 4,
              y: -139,
              w: 776,
              h: 776,
              text_size: 25,
              char_space: 6,
              font: 'fonts/CreatoDisplay_BoldItalic.ttf',
              color: 0xFFFFFFFF,
              // use_text_circle: true,
              start_angle: 259,
              end_angle: 284,
              mode: 0,
              // radius: 388,
              align_h: hmUI.align.CENTER_H,
              padding: true,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 27,
              month_startY: 13,
              month_sc_array: ["A_month_1.png","A_month_2.png","A_month_3.png","A_month_4.png","A_month_5.png","A_month_6.png","A_month_7.png","A_month_8.png","A_month_9.png","A_month_10.png","A_month_11.png","A_month_12.png"],
              month_tc_array: ["A_month_1.png","A_month_2.png","A_month_3.png","A_month_4.png","A_month_5.png","A_month_6.png","A_month_7.png","A_month_8.png","A_month_9.png","A_month_10.png","A_month_11.png","A_month_12.png"],
              month_en_array: ["A_month_1.png","A_month_2.png","A_month_3.png","A_month_4.png","A_month_5.png","A_month_6.png","A_month_7.png","A_month_8.png","A_month_9.png","A_month_10.png","A_month_11.png","A_month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 64,
              y: 339,
              src: '0164(1).png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 279,
              y: 341,
              image_array: ["0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png","0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png","0050.png","0051.png","0052.png","0053.png","0054.png","0055.png","0056.png","0057.png","0058.png","0059.png","0060.png","0061.png","0062.png","0063.png","0064.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 103,
              y: 368,
              font_array: ["A_TEMP_num_0.png","A_TEMP_num_1.png","A_TEMP_num_2.png","A_TEMP_num_3.png","A_TEMP_num_4.png","A_TEMP_num_5.png","A_TEMP_num_6.png","A_TEMP_num_7.png","A_TEMP_num_8.png","A_TEMP_num_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'A_TEMP_num_degree.png',
              unit_tc: 'A_TEMP_num_degree.png',
              unit_en: 'A_TEMP_num_degree.png',
              negative_image: 'A_TEMP_num_minus.png',
              invalid_image: 'A_TEMP_num_minus.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 267,
              day_startY: 56,
              day_sc_array: ["A_DAY_num_0.png","A_DAY_num_1.png","A_DAY_num_2.png","A_DAY_num_3.png","A_DAY_num_4.png","A_DAY_num_5.png","A_DAY_num_6.png","A_DAY_num_7.png","A_DAY_num_8.png","A_DAY_num_9.png"],
              day_tc_array: ["A_DAY_num_0.png","A_DAY_num_1.png","A_DAY_num_2.png","A_DAY_num_3.png","A_DAY_num_4.png","A_DAY_num_5.png","A_DAY_num_6.png","A_DAY_num_7.png","A_DAY_num_8.png","A_DAY_num_9.png"],
              day_en_array: ["A_DAY_num_0.png","A_DAY_num_1.png","A_DAY_num_2.png","A_DAY_num_3.png","A_DAY_num_4.png","A_DAY_num_5.png","A_DAY_num_6.png","A_DAY_num_7.png","A_DAY_num_8.png","A_DAY_num_9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 38,
              y: 22,
              week_en: ["A_WD_1.png","A_WD_2.png","A_WD_3.png","A_WD_4.png","A_WD_5.png","A_WD_6.png","A_WD_7.png"],
              week_tc: ["A_WD_1.png","A_WD_2.png","A_WD_3.png","A_WD_4.png","A_WD_5.png","A_WD_6.png","A_WD_7.png"],
              week_sc: ["A_WD_1.png","A_WD_2.png","A_WD_3.png","A_WD_4.png","A_WD_5.png","A_WD_6.png","A_WD_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 82,
              hour_startY: 189,
              hour_array: ["A_HOURM_num_0.png","A_HOURM_num_1.png","A_HOURM_num_2.png","A_HOURM_num_3.png","A_HOURM_num_4.png","A_HOURM_num_5.png","A_HOURM_num_6.png","A_HOURM_num_7.png","A_HOURM_num_8.png","A_HOURM_num_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_unit_sc: 'A_HOURM_num_colon.png',
              hour_unit_tc: 'A_HOURM_num_colon.png',
              hour_unit_en: 'A_HOURM_num_colon.png',
              hour_align: hmUI.align.RIGHT,

              minute_startX: 0,
              minute_startY: 0,
              minute_array: ["A_HOURM_num_0.png","A_HOURM_num_1.png","A_HOURM_num_2.png","A_HOURM_num_3.png","A_HOURM_num_4.png","A_HOURM_num_5.png","A_HOURM_num_6.png","A_HOURM_num_7.png","A_HOURM_num_8.png","A_HOURM_num_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 1,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: -36,
              y: 34,
              src: 'Batt_rotate.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_pai_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'Sq_Base.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            if (screenType == hmSetting.screen_type.AOD) {
              idle_step_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);

            idle_step_linear_scale.setAlpha(150);
            };

            // idle_step_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 44,
              // start_y: 307,
              // color: 0xFF000000,
              // lenght: 392,
              // line_width: 22,
              // line_cap: Flat,
              // vertical: False,
              // mirror: False,
              // inversion: True,
              // alpha: 150,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_step_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 434,
              y: -328,
              w: 1128,
              h: 1128,
              text_size: 23,
              char_space: 5,
              font: 'fonts/FIHover-Display.ttf',
              color: 0xFFFFFFFF,
              // use_text_circle: true,
              start_angle: 264,
              end_angle: 274,
              mode: 1,
              // radius: 564,
              align_h: hmUI.align.LEFT,
              padding: true,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 167,
              y: 445,
              w: 150,
              h: 30,
              text_size: 28,
              char_space: 3,
              font: 'fonts/FIHover-Display.ttf',
              color: 0xFF00FF00,
              line_space: 0,
              align_v: hmUI.align.BOTTOM,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              padding: true,
              unit_type: 1,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 4,
              y: -139,
              w: 776,
              h: 776,
              text_size: 25,
              char_space: 6,
              font: 'fonts/CreatoDisplay_BoldItalic.ttf',
              color: 0xFFFFFFFF,
              // use_text_circle: true,
              start_angle: 259,
              end_angle: 284,
              mode: 0,
              // radius: 388,
              align_h: hmUI.align.CENTER_H,
              padding: true,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 27,
              month_startY: 13,
              month_sc_array: ["A_month_1.png","A_month_2.png","A_month_3.png","A_month_4.png","A_month_5.png","A_month_6.png","A_month_7.png","A_month_8.png","A_month_9.png","A_month_10.png","A_month_11.png","A_month_12.png"],
              month_tc_array: ["A_month_1.png","A_month_2.png","A_month_3.png","A_month_4.png","A_month_5.png","A_month_6.png","A_month_7.png","A_month_8.png","A_month_9.png","A_month_10.png","A_month_11.png","A_month_12.png"],
              month_en_array: ["A_month_1.png","A_month_2.png","A_month_3.png","A_month_4.png","A_month_5.png","A_month_6.png","A_month_7.png","A_month_8.png","A_month_9.png","A_month_10.png","A_month_11.png","A_month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 64,
              y: 339,
              src: '0164(1).png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 279,
              y: 341,
              image_array: ["0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png","0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png","0050.png","0051.png","0052.png","0053.png","0054.png","0055.png","0056.png","0057.png","0058.png","0059.png","0060.png","0061.png","0062.png","0063.png","0064.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 103,
              y: 368,
              font_array: ["A_TEMP_num_0.png","A_TEMP_num_1.png","A_TEMP_num_2.png","A_TEMP_num_3.png","A_TEMP_num_4.png","A_TEMP_num_5.png","A_TEMP_num_6.png","A_TEMP_num_7.png","A_TEMP_num_8.png","A_TEMP_num_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'A_TEMP_num_degree.png',
              unit_tc: 'A_TEMP_num_degree.png',
              unit_en: 'A_TEMP_num_degree.png',
              negative_image: 'A_TEMP_num_minus.png',
              invalid_image: 'A_TEMP_num_minus.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 267,
              day_startY: 56,
              day_sc_array: ["A_DAY_num_0.png","A_DAY_num_1.png","A_DAY_num_2.png","A_DAY_num_3.png","A_DAY_num_4.png","A_DAY_num_5.png","A_DAY_num_6.png","A_DAY_num_7.png","A_DAY_num_8.png","A_DAY_num_9.png"],
              day_tc_array: ["A_DAY_num_0.png","A_DAY_num_1.png","A_DAY_num_2.png","A_DAY_num_3.png","A_DAY_num_4.png","A_DAY_num_5.png","A_DAY_num_6.png","A_DAY_num_7.png","A_DAY_num_8.png","A_DAY_num_9.png"],
              day_en_array: ["A_DAY_num_0.png","A_DAY_num_1.png","A_DAY_num_2.png","A_DAY_num_3.png","A_DAY_num_4.png","A_DAY_num_5.png","A_DAY_num_6.png","A_DAY_num_7.png","A_DAY_num_8.png","A_DAY_num_9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 38,
              y: 22,
              week_en: ["A_WD_1.png","A_WD_2.png","A_WD_3.png","A_WD_4.png","A_WD_5.png","A_WD_6.png","A_WD_7.png"],
              week_tc: ["A_WD_1.png","A_WD_2.png","A_WD_3.png","A_WD_4.png","A_WD_5.png","A_WD_6.png","A_WD_7.png"],
              week_sc: ["A_WD_1.png","A_WD_2.png","A_WD_3.png","A_WD_4.png","A_WD_5.png","A_WD_6.png","A_WD_7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 82,
              hour_startY: 189,
              hour_array: ["A_HOURM_num_0.png","A_HOURM_num_1.png","A_HOURM_num_2.png","A_HOURM_num_3.png","A_HOURM_num_4.png","A_HOURM_num_5.png","A_HOURM_num_6.png","A_HOURM_num_7.png","A_HOURM_num_8.png","A_HOURM_num_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_unit_sc: 'A_HOURM_num_colon.png',
              hour_unit_tc: 'A_HOURM_num_colon.png',
              hour_unit_en: 'A_HOURM_num_colon.png',
              hour_align: hmUI.align.RIGHT,

              minute_startX: 0,
              minute_startY: 0,
              minute_array: ["A_HOURM_num_0.png","A_HOURM_num_1.png","A_HOURM_num_2.png","A_HOURM_num_3.png","A_HOURM_num_4.png","A_HOURM_num_5.png","A_HOURM_num_6.png","A_HOURM_num_7.png","A_HOURM_num_8.png","A_HOURM_num_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 1,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 0,
              // disconneсnt_toast_text: RUSH OFF,
              // conneсnt_vibrate_type: 0,
              // conneсnt_toast_text: RUSH ON,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              console.log('checkConnection()');
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  hmUI.showToast({text: "RUSH OFF"});
                  vibro(0);
                }
                if(status) {
                  hmUI.showToast({text: "RUSH ON"});
                  vibro(0);
                }
              });
            }

            // end vibration when connecting or disconnecting
            //#region vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              if (scene != 1) timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            //#endregion

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 60,
              y: 0,
              w: 360,
              h: 167,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'O_Empty.png',
              normal_src: 'O_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 4,
              y: 180,
              w: 40,
              h: 150,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'O_Empty.png',
              normal_src: 'O_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'heart_app_Screen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 434,
              y: 180,
              w: 40,
              h: 150,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'O_Empty.png',
              normal_src: 'O_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'activityAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 282,
              y: 344,
              w: 80,
              h: 80,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'O_Empty.png',
              normal_src: 'O_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'WeatherScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 133,
              y: 344,
              w: 80,
              h: 80,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'O_Empty.png',
              normal_src: 'O_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'TideScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 200,
              y: 433,
              w: 80,
              h: 46,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'O_Empty.png',
              normal_src: 'O_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'Settings_batteryManagerScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_7 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 60,
              y: 332,
              w: 40,
              h: 46,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'O_Empty.png',
              normal_src: 'O_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'AlarmInfoScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_8 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 129,
              y: 202,
              w: 80,
              h: 80,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'O_Empty.png',
              normal_src: 'O_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'StopWatchScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_9 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 260,
              y: 202,
              w: 80,
              h: 80,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'O_Empty.png',
              normal_src: 'O_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({ appid: 1057409, url: 'page/index' });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            function scale_call() {
              console.log('scale_call()');

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_ls_normal_step = 1 - progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_linear_scale
                  // initial parameters
                  let start_x_normal_step = 436;
                  let start_y_normal_step = 307;
                  let lenght_ls_normal_step = -392;
                  let line_width_ls_normal_step = 22;
                  let color_ls_normal_step = 0xFF000000;
                  
                  // calculated parameters
                  let start_x_normal_step_draw = start_x_normal_step;
                  let start_y_normal_step_draw = start_y_normal_step;
                  lenght_ls_normal_step = lenght_ls_normal_step * progress_ls_normal_step;
                  let lenght_ls_normal_step_draw = lenght_ls_normal_step;
                  let line_width_ls_normal_step_draw = line_width_ls_normal_step;
                  if (lenght_ls_normal_step < 0){
                    lenght_ls_normal_step_draw = -lenght_ls_normal_step;
                    start_x_normal_step_draw = start_x_normal_step - lenght_ls_normal_step_draw;
                  };
                  
                  normal_step_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_step_draw,
                    y: start_y_normal_step_draw,
                    w: lenght_ls_normal_step_draw,
                    h: line_width_ls_normal_step_draw,
                    color: color_ls_normal_step,
                  });
                };

                console.log('update scales STEP');
                let progress_ls_idle_step = 1 - progressStep;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_step_linear_scale
                  // initial parameters
                  let start_x_idle_step = 436;
                  let start_y_idle_step = 307;
                  let lenght_ls_idle_step = -392;
                  let line_width_ls_idle_step = 22;
                  let color_ls_idle_step = 0xFF000000;
                  
                  // calculated parameters
                  let start_x_idle_step_draw = start_x_idle_step;
                  let start_y_idle_step_draw = start_y_idle_step;
                  lenght_ls_idle_step = lenght_ls_idle_step * progress_ls_idle_step;
                  let lenght_ls_idle_step_draw = lenght_ls_idle_step;
                  let line_width_ls_idle_step_draw = line_width_ls_idle_step;
                  if (lenght_ls_idle_step < 0){
                    lenght_ls_idle_step_draw = -lenght_ls_idle_step;
                    start_x_idle_step_draw = start_x_idle_step - lenght_ls_idle_step_draw;
                  };
                  
                  idle_step_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_idle_step_draw,
                    y: start_y_idle_step_draw,
                    w: lenght_ls_idle_step_draw,
                    h: line_width_ls_idle_step_draw,
                    color: color_ls_idle_step,
                  });
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                checkConnection();
                stopVibro();

              }),
              pause_call: (function () {
                console.log('pause_call()');
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
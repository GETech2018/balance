﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_hour_TextRotate = new Array(2);
        let normal_hour_TextRotate_ASCIIARRAY = new Array(10);
        let normal_hour_TextRotate_img_width = 52;
        let normal_hour_TextRotate_unit = null;
        let normal_hour_TextRotate_unit_width = 22;
        let normal_timerTextUpdate = undefined;
        let normal_minute_TextRotate = new Array(2);
        let normal_minute_TextRotate_ASCIIARRAY = new Array(10);
        let normal_minute_TextRotate_img_width = 52;
        let normal_date_img_date_week_img = ''
        let normal_battery_TextRotate = new Array(3);
        let normal_battery_TextRotate_ASCIIARRAY = new Array(10);
        let normal_battery_TextRotate_img_width = 26;
        let normal_step_TextRotate = new Array(5);
        let normal_step_TextRotate_ASCIIARRAY = new Array(10);
        let normal_step_TextRotate_img_width = 26;
        let normal_heart_rate_TextRotate = new Array(3);
        let normal_heart_rate_TextRotate_ASCIIARRAY = new Array(10);
        let normal_heart_rate_TextRotate_img_width = 26;
        let normal_day_TextRotate = new Array(2);
        let normal_day_TextRotate_ASCIIARRAY = new Array(10);
        let normal_day_TextRotate_img_width = 26;
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_TextRotate = new Array(4);
        let normal_temperature_current_TextRotate_ASCIIARRAY = new Array(10);
        let normal_temperature_current_TextRotate_img_width = 26;
        let normal_temperature_current_TextRotate_dot_width = 26;
        let normal_temperature_current_TextRotate_error_img_width = 26;
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let idle_background_bg_img = ''
        let idle_image_img = ''
        let idle_hour_TextRotate = new Array(2);
        let idle_hour_TextRotate_ASCIIARRAY = new Array(10);
        let idle_hour_TextRotate_img_width = 52;
        let idle_hour_TextRotate_unit = null;
        let idle_hour_TextRotate_unit_width = 22;
        let idle_timerTextUpdate = undefined;
        let idle_minute_TextRotate = new Array(2);
        let idle_minute_TextRotate_ASCIIARRAY = new Array(10);
        let idle_minute_TextRotate_img_width = 52;
        let idle_date_img_date_week_img = ''
        let idle_battery_TextRotate = new Array(3);
        let idle_battery_TextRotate_ASCIIARRAY = new Array(10);
        let idle_battery_TextRotate_img_width = 26;
        let idle_step_TextRotate = new Array(5);
        let idle_step_TextRotate_ASCIIARRAY = new Array(10);
        let idle_step_TextRotate_img_width = 26;
        let idle_heart_rate_TextRotate = new Array(3);
        let idle_heart_rate_TextRotate_ASCIIARRAY = new Array(10);
        let idle_heart_rate_TextRotate_img_width = 26;
        let idle_day_TextRotate = new Array(2);
        let idle_day_TextRotate_ASCIIARRAY = new Array(10);
        let idle_day_TextRotate_img_width = 26;
        let idle_weather_image_progress_img_level = ''
        let idle_temperature_current_TextRotate = new Array(4);
        let idle_temperature_current_TextRotate_ASCIIARRAY = new Array(10);
        let idle_temperature_current_TextRotate_img_width = 26;
        let idle_temperature_current_TextRotate_dot_width = 26;
        let idle_temperature_current_TextRotate_error_img_width = 26;
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_hour_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 340,
              // y: 96,
              // font_array: ["H_0.png","H_1.png","H_2.png","H_3.png","H_4.png","H_5.png","H_6.png","H_7.png","H_8.png","H_9.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: -4,
              // angle: 12,
              // unit_en: 'H_10.png',
              // align_h: hmUI.align.RIGHT,
              // type: hmUI.data_type.HOUR,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_hour_TextRotate_ASCIIARRAY[0] = 'H_0.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[1] = 'H_1.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[2] = 'H_2.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[3] = 'H_3.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[4] = 'H_4.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[5] = 'H_5.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[6] = 'H_6.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[7] = 'H_7.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[8] = 'H_8.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[9] = 'H_9.png';  // set of images with numbers

            //#region TextRotate
            for (let i = 0; i < 2; i++) {
              normal_hour_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 340,
                center_y: 96,
                pos_x: 340,
                pos_y: 96,
                angle: 12,
                src: 'H_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_hour_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_hour_TextRotate_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              center_x: 340,
              center_y: 96,
              pos_x: 340,
              pos_y: 96,
              angle: 12,
              src: 'H_10.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_hour_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
            //#endregion

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            let screenType = hmSetting.getScreenType();
            // normal_minute_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 358,
              // y: 101,
              // font_array: ["H_0.png","H_1.png","H_2.png","H_3.png","H_4.png","H_5.png","H_6.png","H_7.png","H_8.png","H_9.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: -4,
              // angle: 12,
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.MINUTE,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_minute_TextRotate_ASCIIARRAY[0] = 'H_0.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[1] = 'H_1.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[2] = 'H_2.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[3] = 'H_3.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[4] = 'H_4.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[5] = 'H_5.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[6] = 'H_6.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[7] = 'H_7.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[8] = 'H_8.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[9] = 'H_9.png';  // set of images with numbers

            //#region TextRotate
            for (let i = 0; i < 2; i++) {
              normal_minute_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 358,
                center_y: 101,
                pos_x: 358,
                pos_y: 101,
                angle: 12,
                src: 'H_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_minute_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //#endregion

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 119,
              y: 380,
              week_en: ["week_0.png","week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png"],
              week_tc: ["week_0.png","week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png"],
              week_sc: ["week_0.png","week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_battery_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 138,
              // y: 48,
              // font_array: ["dig_a_0.png","dig_a_1.png","dig_a_2.png","dig_a_3.png","dig_a_4.png","dig_a_5.png","dig_a_6.png","dig_a_7.png","dig_a_8.png","dig_a_9.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: -4,
              // angle: -10,
              // align_h: hmUI.align.RIGHT,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_battery_TextRotate_ASCIIARRAY[0] = 'dig_a_0.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[1] = 'dig_a_1.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[2] = 'dig_a_2.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[3] = 'dig_a_3.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[4] = 'dig_a_4.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[5] = 'dig_a_5.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[6] = 'dig_a_6.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[7] = 'dig_a_7.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[8] = 'dig_a_8.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[9] = 'dig_a_9.png';  // set of images with numbers

            //#region TextRotate
            for (let i = 0; i < 3; i++) {
              normal_battery_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 138,
                center_y: 48,
                pos_x: 138,
                pos_y: 48,
                angle: -10,
                src: 'dig_a_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_battery_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //#endregion
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            // normal_step_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 73,
              // y: 273,
              // font_array: ["dig_a_0.png","dig_a_1.png","dig_a_2.png","dig_a_3.png","dig_a_4.png","dig_a_5.png","dig_a_6.png","dig_a_7.png","dig_a_8.png","dig_a_9.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: -4,
              // angle: -7,
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_step_TextRotate_ASCIIARRAY[0] = 'dig_a_0.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[1] = 'dig_a_1.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[2] = 'dig_a_2.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[3] = 'dig_a_3.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[4] = 'dig_a_4.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[5] = 'dig_a_5.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[6] = 'dig_a_6.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[7] = 'dig_a_7.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[8] = 'dig_a_8.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[9] = 'dig_a_9.png';  // set of images with numbers

            //#region TextRotate
            for (let i = 0; i < 5; i++) {
              normal_step_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 73,
                center_y: 273,
                pos_x: 73,
                pos_y: 273,
                angle: -7,
                src: 'dig_a_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_step_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //#endregion
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            // normal_heart_rate_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 59,
              // y: 167,
              // font_array: ["dig_a_0.png","dig_a_1.png","dig_a_2.png","dig_a_3.png","dig_a_4.png","dig_a_5.png","dig_a_6.png","dig_a_7.png","dig_a_8.png","dig_a_9.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: -4,
              // angle: 4,
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_heart_rate_TextRotate_ASCIIARRAY[0] = 'dig_a_0.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[1] = 'dig_a_1.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[2] = 'dig_a_2.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[3] = 'dig_a_3.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[4] = 'dig_a_4.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[5] = 'dig_a_5.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[6] = 'dig_a_6.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[7] = 'dig_a_7.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[8] = 'dig_a_8.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[9] = 'dig_a_9.png';  // set of images with numbers

            //#region TextRotate
            for (let i = 0; i < 3; i++) {
              normal_heart_rate_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 59,
                center_y: 167,
                pos_x: 59,
                pos_y: 167,
                angle: 4,
                src: 'dig_a_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_heart_rate_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //#endregion
            
            const heart_rate = hmSensor.createSensor(hmSensor.id.HEART);
            heart_rate.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            // normal_day_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 279,
              // y: 428,
              // font_array: ["dig_a_0.png","dig_a_1.png","dig_a_2.png","dig_a_3.png","dig_a_4.png","dig_a_5.png","dig_a_6.png","dig_a_7.png","dig_a_8.png","dig_a_9.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: 7,
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.DAY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_day_TextRotate_ASCIIARRAY[0] = 'dig_a_0.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[1] = 'dig_a_1.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[2] = 'dig_a_2.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[3] = 'dig_a_3.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[4] = 'dig_a_4.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[5] = 'dig_a_5.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[6] = 'dig_a_6.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[7] = 'dig_a_7.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[8] = 'dig_a_8.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[9] = 'dig_a_9.png';  // set of images with numbers

            //#region TextRotate
            for (let i = 0; i < 2; i++) {
              normal_day_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 279,
                center_y: 428,
                pos_x: 279,
                pos_y: 428,
                angle: 7,
                src: 'dig_a_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_day_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //#endregion

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 371,
              y: 293,
              image_array: ["w_0.png","w_1.png","w_2.png","w_3.png","w_4.png","w_5.png","w_6.png","w_7.png","w_8.png","w_9.png","w_10.png","w_11.png","w_12.png","w_13.png","w_14.png","w_15.png","w_16.png","w_17.png","w_18.png","w_19.png","w_20.png","w_21.png","w_22.png","w_23.png","w_24.png","w_25.png","w_26.png","w_27.png","w_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_temperature_current_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 404,
              // y: 251,
              // font_array: ["dig_a_0.png","dig_a_1.png","dig_a_2.png","dig_a_3.png","dig_a_4.png","dig_a_5.png","dig_a_6.png","dig_a_7.png","dig_a_8.png","dig_a_9.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: -4,
              // angle: 8,
              // negative_image: 'dig_a_10.png',
              // invalid_image: 'dig_a_10.png',
              // dot_image: 'dig_a_10.png',
              // align_h: hmUI.align.RIGHT,
              // type: hmUI.data_type.WEATHER_CURRENT,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_temperature_current_TextRotate_ASCIIARRAY[0] = 'dig_a_0.png';  // set of images with numbers
            normal_temperature_current_TextRotate_ASCIIARRAY[1] = 'dig_a_1.png';  // set of images with numbers
            normal_temperature_current_TextRotate_ASCIIARRAY[2] = 'dig_a_2.png';  // set of images with numbers
            normal_temperature_current_TextRotate_ASCIIARRAY[3] = 'dig_a_3.png';  // set of images with numbers
            normal_temperature_current_TextRotate_ASCIIARRAY[4] = 'dig_a_4.png';  // set of images with numbers
            normal_temperature_current_TextRotate_ASCIIARRAY[5] = 'dig_a_5.png';  // set of images with numbers
            normal_temperature_current_TextRotate_ASCIIARRAY[6] = 'dig_a_6.png';  // set of images with numbers
            normal_temperature_current_TextRotate_ASCIIARRAY[7] = 'dig_a_7.png';  // set of images with numbers
            normal_temperature_current_TextRotate_ASCIIARRAY[8] = 'dig_a_8.png';  // set of images with numbers
            normal_temperature_current_TextRotate_ASCIIARRAY[9] = 'dig_a_9.png';  // set of images with numbers

            //#region TextRotate
            for (let i = 0; i < 4; i++) {
              normal_temperature_current_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 404,
                center_y: 251,
                pos_x: 404,
                pos_y: 251,
                angle: 8,
                src: 'dig_a_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_temperature_current_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //#endregion
            const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 281,
              y: 290,
              src: 'stat_BT.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 290,
              y: 36,
              src: 'stat_AL.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_hour_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 340,
              // y: 96,
              // font_array: ["H_0.png","H_1.png","H_2.png","H_3.png","H_4.png","H_5.png","H_6.png","H_7.png","H_8.png","H_9.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: -4,
              // angle: 12,
              // unit_en: 'H_10.png',
              // align_h: hmUI.align.RIGHT,
              // type: hmUI.data_type.HOUR,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_hour_TextRotate_ASCIIARRAY[0] = 'H_0.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[1] = 'H_1.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[2] = 'H_2.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[3] = 'H_3.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[4] = 'H_4.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[5] = 'H_5.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[6] = 'H_6.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[7] = 'H_7.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[8] = 'H_8.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[9] = 'H_9.png';  // set of images with numbers

            //#region TextRotate
            for (let i = 0; i < 2; i++) {
              idle_hour_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 340,
                center_y: 96,
                pos_x: 340,
                pos_y: 96,
                angle: 12,
                src: 'H_0.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_hour_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            idle_hour_TextRotate_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              center_x: 340,
              center_y: 96,
              pos_x: 340,
              pos_y: 96,
              angle: 12,
              src: 'H_10.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            idle_hour_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
            //#endregion

            // idle_minute_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 358,
              // y: 101,
              // font_array: ["H_0.png","H_1.png","H_2.png","H_3.png","H_4.png","H_5.png","H_6.png","H_7.png","H_8.png","H_9.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: -4,
              // angle: 12,
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.MINUTE,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_minute_TextRotate_ASCIIARRAY[0] = 'H_0.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[1] = 'H_1.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[2] = 'H_2.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[3] = 'H_3.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[4] = 'H_4.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[5] = 'H_5.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[6] = 'H_6.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[7] = 'H_7.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[8] = 'H_8.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[9] = 'H_9.png';  // set of images with numbers

            //#region TextRotate
            for (let i = 0; i < 2; i++) {
              idle_minute_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 358,
                center_y: 101,
                pos_x: 358,
                pos_y: 101,
                angle: 12,
                src: 'H_0.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_minute_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //#endregion

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 119,
              y: 380,
              week_en: ["week_0.png","week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png"],
              week_tc: ["week_0.png","week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png"],
              week_sc: ["week_0.png","week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_battery_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 138,
              // y: 48,
              // font_array: ["dig_a_0.png","dig_a_1.png","dig_a_2.png","dig_a_3.png","dig_a_4.png","dig_a_5.png","dig_a_6.png","dig_a_7.png","dig_a_8.png","dig_a_9.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: -4,
              // angle: -10,
              // align_h: hmUI.align.RIGHT,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_battery_TextRotate_ASCIIARRAY[0] = 'dig_a_0.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[1] = 'dig_a_1.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[2] = 'dig_a_2.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[3] = 'dig_a_3.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[4] = 'dig_a_4.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[5] = 'dig_a_5.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[6] = 'dig_a_6.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[7] = 'dig_a_7.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[8] = 'dig_a_8.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[9] = 'dig_a_9.png';  // set of images with numbers

            //#region TextRotate
            for (let i = 0; i < 3; i++) {
              idle_battery_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 138,
                center_y: 48,
                pos_x: 138,
                pos_y: 48,
                angle: -10,
                src: 'dig_a_0.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_battery_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //#endregion

            // idle_step_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 73,
              // y: 273,
              // font_array: ["dig_a_0.png","dig_a_1.png","dig_a_2.png","dig_a_3.png","dig_a_4.png","dig_a_5.png","dig_a_6.png","dig_a_7.png","dig_a_8.png","dig_a_9.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: -4,
              // angle: -7,
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_step_TextRotate_ASCIIARRAY[0] = 'dig_a_0.png';  // set of images with numbers
            idle_step_TextRotate_ASCIIARRAY[1] = 'dig_a_1.png';  // set of images with numbers
            idle_step_TextRotate_ASCIIARRAY[2] = 'dig_a_2.png';  // set of images with numbers
            idle_step_TextRotate_ASCIIARRAY[3] = 'dig_a_3.png';  // set of images with numbers
            idle_step_TextRotate_ASCIIARRAY[4] = 'dig_a_4.png';  // set of images with numbers
            idle_step_TextRotate_ASCIIARRAY[5] = 'dig_a_5.png';  // set of images with numbers
            idle_step_TextRotate_ASCIIARRAY[6] = 'dig_a_6.png';  // set of images with numbers
            idle_step_TextRotate_ASCIIARRAY[7] = 'dig_a_7.png';  // set of images with numbers
            idle_step_TextRotate_ASCIIARRAY[8] = 'dig_a_8.png';  // set of images with numbers
            idle_step_TextRotate_ASCIIARRAY[9] = 'dig_a_9.png';  // set of images with numbers

            //#region TextRotate
            for (let i = 0; i < 5; i++) {
              idle_step_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 73,
                center_y: 273,
                pos_x: 73,
                pos_y: 273,
                angle: -7,
                src: 'dig_a_0.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_step_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //#endregion

            // idle_heart_rate_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 59,
              // y: 167,
              // font_array: ["dig_a_0.png","dig_a_1.png","dig_a_2.png","dig_a_3.png","dig_a_4.png","dig_a_5.png","dig_a_6.png","dig_a_7.png","dig_a_8.png","dig_a_9.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: -4,
              // angle: 4,
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_heart_rate_TextRotate_ASCIIARRAY[0] = 'dig_a_0.png';  // set of images with numbers
            idle_heart_rate_TextRotate_ASCIIARRAY[1] = 'dig_a_1.png';  // set of images with numbers
            idle_heart_rate_TextRotate_ASCIIARRAY[2] = 'dig_a_2.png';  // set of images with numbers
            idle_heart_rate_TextRotate_ASCIIARRAY[3] = 'dig_a_3.png';  // set of images with numbers
            idle_heart_rate_TextRotate_ASCIIARRAY[4] = 'dig_a_4.png';  // set of images with numbers
            idle_heart_rate_TextRotate_ASCIIARRAY[5] = 'dig_a_5.png';  // set of images with numbers
            idle_heart_rate_TextRotate_ASCIIARRAY[6] = 'dig_a_6.png';  // set of images with numbers
            idle_heart_rate_TextRotate_ASCIIARRAY[7] = 'dig_a_7.png';  // set of images with numbers
            idle_heart_rate_TextRotate_ASCIIARRAY[8] = 'dig_a_8.png';  // set of images with numbers
            idle_heart_rate_TextRotate_ASCIIARRAY[9] = 'dig_a_9.png';  // set of images with numbers

            //#region TextRotate
            for (let i = 0; i < 3; i++) {
              idle_heart_rate_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 59,
                center_y: 167,
                pos_x: 59,
                pos_y: 167,
                angle: 4,
                src: 'dig_a_0.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_heart_rate_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //#endregion

            // idle_day_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 279,
              // y: 428,
              // font_array: ["dig_a_0.png","dig_a_1.png","dig_a_2.png","dig_a_3.png","dig_a_4.png","dig_a_5.png","dig_a_6.png","dig_a_7.png","dig_a_8.png","dig_a_9.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: 7,
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.DAY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_day_TextRotate_ASCIIARRAY[0] = 'dig_a_0.png';  // set of images with numbers
            idle_day_TextRotate_ASCIIARRAY[1] = 'dig_a_1.png';  // set of images with numbers
            idle_day_TextRotate_ASCIIARRAY[2] = 'dig_a_2.png';  // set of images with numbers
            idle_day_TextRotate_ASCIIARRAY[3] = 'dig_a_3.png';  // set of images with numbers
            idle_day_TextRotate_ASCIIARRAY[4] = 'dig_a_4.png';  // set of images with numbers
            idle_day_TextRotate_ASCIIARRAY[5] = 'dig_a_5.png';  // set of images with numbers
            idle_day_TextRotate_ASCIIARRAY[6] = 'dig_a_6.png';  // set of images with numbers
            idle_day_TextRotate_ASCIIARRAY[7] = 'dig_a_7.png';  // set of images with numbers
            idle_day_TextRotate_ASCIIARRAY[8] = 'dig_a_8.png';  // set of images with numbers
            idle_day_TextRotate_ASCIIARRAY[9] = 'dig_a_9.png';  // set of images with numbers

            //#region TextRotate
            for (let i = 0; i < 2; i++) {
              idle_day_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 279,
                center_y: 428,
                pos_x: 279,
                pos_y: 428,
                angle: 7,
                src: 'dig_a_0.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_day_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //#endregion

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 371,
              y: 293,
              image_array: ["w_0.png","w_1.png","w_2.png","w_3.png","w_4.png","w_5.png","w_6.png","w_7.png","w_8.png","w_9.png","w_10.png","w_11.png","w_12.png","w_13.png","w_14.png","w_15.png","w_16.png","w_17.png","w_18.png","w_19.png","w_20.png","w_21.png","w_22.png","w_23.png","w_24.png","w_25.png","w_26.png","w_27.png","w_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_temperature_current_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 404,
              // y: 251,
              // font_array: ["dig_a_0.png","dig_a_1.png","dig_a_2.png","dig_a_3.png","dig_a_4.png","dig_a_5.png","dig_a_6.png","dig_a_7.png","dig_a_8.png","dig_a_9.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: -4,
              // angle: 8,
              // negative_image: 'dig_a_10.png',
              // invalid_image: 'dig_a_10.png',
              // dot_image: 'dig_a_10.png',
              // align_h: hmUI.align.RIGHT,
              // type: hmUI.data_type.WEATHER_CURRENT,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_temperature_current_TextRotate_ASCIIARRAY[0] = 'dig_a_0.png';  // set of images with numbers
            idle_temperature_current_TextRotate_ASCIIARRAY[1] = 'dig_a_1.png';  // set of images with numbers
            idle_temperature_current_TextRotate_ASCIIARRAY[2] = 'dig_a_2.png';  // set of images with numbers
            idle_temperature_current_TextRotate_ASCIIARRAY[3] = 'dig_a_3.png';  // set of images with numbers
            idle_temperature_current_TextRotate_ASCIIARRAY[4] = 'dig_a_4.png';  // set of images with numbers
            idle_temperature_current_TextRotate_ASCIIARRAY[5] = 'dig_a_5.png';  // set of images with numbers
            idle_temperature_current_TextRotate_ASCIIARRAY[6] = 'dig_a_6.png';  // set of images with numbers
            idle_temperature_current_TextRotate_ASCIIARRAY[7] = 'dig_a_7.png';  // set of images with numbers
            idle_temperature_current_TextRotate_ASCIIARRAY[8] = 'dig_a_8.png';  // set of images with numbers
            idle_temperature_current_TextRotate_ASCIIARRAY[9] = 'dig_a_9.png';  // set of images with numbers

            //#region TextRotate
            for (let i = 0; i < 4; i++) {
              idle_temperature_current_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 404,
                center_y: 251,
                pos_x: 404,
                pos_y: 251,
                angle: 8,
                src: 'dig_a_0.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_temperature_current_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //#endregion

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 281,
              y: 290,
              src: 'stat_BT.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 290,
              y: 36,
              src: 'stat_AL.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            //#region text_update
            function text_update() {
              console.log('text_update()');

              console.log('update text rotate hour_TIME');
              let valueHour = timeSensor.format_hour;
              let normal_hour_rotate_string = parseInt(valueHour).toString();
              normal_hour_rotate_string = normal_hour_rotate_string.padStart(2, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_hour_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_hour_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
                if (valueHour != null && valueHour != undefined && isFinite(valueHour) && normal_hour_rotate_string.length > 0 && normal_hour_rotate_string.length <= 2) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = RIGHT
                  let normal_hour_TextRotate_posOffset = normal_hour_TextRotate_img_width * normal_hour_rotate_string.length;
                  normal_hour_TextRotate_posOffset = normal_hour_TextRotate_posOffset + -4 * (normal_hour_rotate_string.length - 1);
                  img_offset -= normal_hour_TextRotate_posOffset;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_hour_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_hour_TextRotate[index].setProperty(hmUI.prop.POS_X, 340 + img_offset);
                      normal_hour_TextRotate[index].setProperty(hmUI.prop.SRC, normal_hour_TextRotate_ASCIIARRAY[charCode]);
                      normal_hour_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_hour_TextRotate_img_width + -4;
                      index++;
                    };  // end if digit
                  };  // end char of string
                  normal_hour_TextRotate_unit.setProperty(hmUI.prop.POS_X, 340 + img_offset);
                  normal_hour_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite

              };

              console.log('update text rotate minute_TIME');
              let valueMinute = timeSensor.minute;
              let normal_minute_rotate_string = parseInt(valueMinute).toString();
              normal_minute_rotate_string = normal_minute_rotate_string.padStart(2, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_minute_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueMinute != null && valueMinute != undefined && isFinite(valueMinute) && normal_minute_rotate_string.length > 0 && normal_minute_rotate_string.length <= 2) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of normal_minute_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_minute_TextRotate[index].setProperty(hmUI.prop.POS_X, 358 + img_offset);
                      normal_minute_TextRotate[index].setProperty(hmUI.prop.SRC, normal_minute_TextRotate_ASCIIARRAY[charCode]);
                      normal_minute_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_minute_TextRotate_img_width + -4;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate battery_BATTERY');
              let valueBattery = battery.current;
              let normal_battery_rotate_string = parseInt(valueBattery).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  normal_battery_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueBattery != null && valueBattery != undefined && isFinite(valueBattery) && normal_battery_rotate_string.length > 0 && normal_battery_rotate_string.length <= 3) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = RIGHT
                  let normal_battery_TextRotate_posOffset = normal_battery_TextRotate_img_width * normal_battery_rotate_string.length;
                  normal_battery_TextRotate_posOffset = normal_battery_TextRotate_posOffset + -4 * (normal_battery_rotate_string.length - 1);
                  img_offset -= normal_battery_TextRotate_posOffset;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_battery_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_battery_TextRotate[index].setProperty(hmUI.prop.POS_X, 138 + img_offset);
                      normal_battery_TextRotate[index].setProperty(hmUI.prop.SRC, normal_battery_TextRotate_ASCIIARRAY[charCode]);
                      normal_battery_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_battery_TextRotate_img_width + -4;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate step_STEP');
              let valueStep = step.current;
              let normal_step_rotate_string = parseInt(valueStep).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  normal_step_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueStep != null && valueStep != undefined && isFinite(valueStep) && normal_step_rotate_string.length > 0 && normal_step_rotate_string.length <= 5) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let normal_step_TextRotate_posOffset = normal_step_TextRotate_img_width * normal_step_rotate_string.length;
                  normal_step_TextRotate_posOffset = normal_step_TextRotate_posOffset + -4 * (normal_step_rotate_string.length - 1);
                  img_offset -= normal_step_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_step_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_step_TextRotate[index].setProperty(hmUI.prop.POS_X, 73 + img_offset);
                      normal_step_TextRotate[index].setProperty(hmUI.prop.SRC, normal_step_TextRotate_ASCIIARRAY[charCode]);
                      normal_step_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_step_TextRotate_img_width + -4;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate heart_rate_HEART');
              let valueHeartRate = heart_rate.last;
              let normal_heart_rate_rotate_string = parseInt(valueHeartRate).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  normal_heart_rate_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueHeartRate != null && valueHeartRate != undefined && isFinite(valueHeartRate) && normal_heart_rate_rotate_string.length > 0 && normal_heart_rate_rotate_string.length <= 3) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let normal_heart_rate_TextRotate_posOffset = normal_heart_rate_TextRotate_img_width * normal_heart_rate_rotate_string.length;
                  normal_heart_rate_TextRotate_posOffset = normal_heart_rate_TextRotate_posOffset + -4 * (normal_heart_rate_rotate_string.length - 1);
                  img_offset -= normal_heart_rate_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_heart_rate_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_heart_rate_TextRotate[index].setProperty(hmUI.prop.POS_X, 59 + img_offset);
                      normal_heart_rate_TextRotate[index].setProperty(hmUI.prop.SRC, normal_heart_rate_TextRotate_ASCIIARRAY[charCode]);
                      normal_heart_rate_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_heart_rate_TextRotate_img_width + -4;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate day_TIME');
              let valueDay = timeSensor.day;
              let normal_day_rotate_string = parseInt(valueDay).toString();
              normal_day_rotate_string = normal_day_rotate_string.padStart(2, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_day_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueDay != null && valueDay != undefined && isFinite(valueDay) && normal_day_rotate_string.length > 0 && normal_day_rotate_string.length <= 2) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let normal_day_TextRotate_posOffset = normal_day_TextRotate_img_width * normal_day_rotate_string.length;
                  img_offset -= normal_day_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_day_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_day_TextRotate[index].setProperty(hmUI.prop.POS_X, 279 + img_offset);
                      normal_day_TextRotate[index].setProperty(hmUI.prop.SRC, normal_day_TextRotate_ASCIIARRAY[charCode]);
                      normal_day_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_day_TextRotate_img_width;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };
              let weatherData = weatherSensor.getForecastWeather();
              let temperature_current_temp = -100;
              if (weatherSensor.current != undefined && weatherSensor.current != 'undefined') {
                temperature_current_temp = weatherSensor.current;
              }; // end currentWeather;

              console.log('update text rotate temperature_current_currentWeather');
              let temperatureCurrent = undefined;
              let normal_temperature_current_rotate_string = undefined;
              if (temperature_current_temp > -100) {
                temperatureCurrent = 0;
                normal_temperature_current_rotate_string = String(temperature_current_temp)
              };

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 4; i++) {  // hide all symbols
                  normal_temperature_current_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (temperatureCurrent != null && temperatureCurrent != undefined && isFinite(temperatureCurrent) && normal_temperature_current_rotate_string.length > 0 && normal_temperature_current_rotate_string.length <= 4) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = RIGHT
                  let normal_temperature_current_TextRotate_posOffset = normal_temperature_current_TextRotate_img_width * normal_temperature_current_rotate_string.length;
                  normal_temperature_current_TextRotate_posOffset = normal_temperature_current_TextRotate_posOffset + -4 * (normal_temperature_current_rotate_string.length - 1);
                  img_offset -= normal_temperature_current_TextRotate_posOffset;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_temperature_current_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 4) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_temperature_current_TextRotate[index].setProperty(hmUI.prop.POS_X, 404 + img_offset);
                      normal_temperature_current_TextRotate[index].setProperty(hmUI.prop.SRC, normal_temperature_current_TextRotate_ASCIIARRAY[charCode]);
                      normal_temperature_current_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_temperature_current_TextRotate_img_width + -4;
                      index++;
                    }  // end if digit
                    else { 
                      normal_temperature_current_TextRotate[index].setProperty(hmUI.prop.POS_X, 404 + img_offset);
                      normal_temperature_current_TextRotate[index].setProperty(hmUI.prop.SRC, 'dig_a_10.png');
                      normal_temperature_current_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_temperature_current_TextRotate_dot_width + -4;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                }  // end isFinite
                else {
                  normal_temperature_current_TextRotate[0].setProperty(hmUI.prop.POS_X, 404 - normal_temperature_current_TextRotate_error_img_width / 2);
                  normal_temperature_current_TextRotate[0].setProperty(hmUI.prop.SRC, 'dig_a_10.png');
                  normal_temperature_current_TextRotate[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

              console.log('update text rotate hour_TIME');
              let idle_hour_rotate_string = parseInt(valueHour).toString();
              idle_hour_rotate_string = idle_hour_rotate_string.padStart(2, '0');

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  idle_hour_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                idle_hour_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
                if (valueHour != null && valueHour != undefined && isFinite(valueHour) && idle_hour_rotate_string.length > 0 && idle_hour_rotate_string.length <= 2) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = RIGHT
                  let idle_hour_TextRotate_posOffset = idle_hour_TextRotate_img_width * idle_hour_rotate_string.length;
                  idle_hour_TextRotate_posOffset = idle_hour_TextRotate_posOffset + -4 * (idle_hour_rotate_string.length - 1);
                  img_offset -= idle_hour_TextRotate_posOffset;
                  // alignment end
                  
                  let index = 0;
                  for (let char of idle_hour_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_hour_TextRotate[index].setProperty(hmUI.prop.POS_X, 340 + img_offset);
                      idle_hour_TextRotate[index].setProperty(hmUI.prop.SRC, idle_hour_TextRotate_ASCIIARRAY[charCode]);
                      idle_hour_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_hour_TextRotate_img_width + -4;
                      index++;
                    };  // end if digit
                  };  // end char of string
                  idle_hour_TextRotate_unit.setProperty(hmUI.prop.POS_X, 340 + img_offset);
                  idle_hour_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite

              };

              console.log('update text rotate minute_TIME');
              let idle_minute_rotate_string = parseInt(valueMinute).toString();
              idle_minute_rotate_string = idle_minute_rotate_string.padStart(2, '0');

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  idle_minute_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueMinute != null && valueMinute != undefined && isFinite(valueMinute) && idle_minute_rotate_string.length > 0 && idle_minute_rotate_string.length <= 2) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of idle_minute_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_minute_TextRotate[index].setProperty(hmUI.prop.POS_X, 358 + img_offset);
                      idle_minute_TextRotate[index].setProperty(hmUI.prop.SRC, idle_minute_TextRotate_ASCIIARRAY[charCode]);
                      idle_minute_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_minute_TextRotate_img_width + -4;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate battery_BATTERY');
              let idle_battery_rotate_string = parseInt(valueBattery).toString();

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  idle_battery_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueBattery != null && valueBattery != undefined && isFinite(valueBattery) && idle_battery_rotate_string.length > 0 && idle_battery_rotate_string.length <= 3) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = RIGHT
                  let idle_battery_TextRotate_posOffset = idle_battery_TextRotate_img_width * idle_battery_rotate_string.length;
                  idle_battery_TextRotate_posOffset = idle_battery_TextRotate_posOffset + -4 * (idle_battery_rotate_string.length - 1);
                  img_offset -= idle_battery_TextRotate_posOffset;
                  // alignment end
                  
                  let index = 0;
                  for (let char of idle_battery_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_battery_TextRotate[index].setProperty(hmUI.prop.POS_X, 138 + img_offset);
                      idle_battery_TextRotate[index].setProperty(hmUI.prop.SRC, idle_battery_TextRotate_ASCIIARRAY[charCode]);
                      idle_battery_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_battery_TextRotate_img_width + -4;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate step_STEP');
              let idle_step_rotate_string = parseInt(valueStep).toString();

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  idle_step_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueStep != null && valueStep != undefined && isFinite(valueStep) && idle_step_rotate_string.length > 0 && idle_step_rotate_string.length <= 5) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let idle_step_TextRotate_posOffset = idle_step_TextRotate_img_width * idle_step_rotate_string.length;
                  idle_step_TextRotate_posOffset = idle_step_TextRotate_posOffset + -4 * (idle_step_rotate_string.length - 1);
                  img_offset -= idle_step_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of idle_step_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_step_TextRotate[index].setProperty(hmUI.prop.POS_X, 73 + img_offset);
                      idle_step_TextRotate[index].setProperty(hmUI.prop.SRC, idle_step_TextRotate_ASCIIARRAY[charCode]);
                      idle_step_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_step_TextRotate_img_width + -4;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate heart_rate_HEART');
              let idle_heart_rate_rotate_string = parseInt(valueHeartRate).toString();

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  idle_heart_rate_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueHeartRate != null && valueHeartRate != undefined && isFinite(valueHeartRate) && idle_heart_rate_rotate_string.length > 0 && idle_heart_rate_rotate_string.length <= 3) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let idle_heart_rate_TextRotate_posOffset = idle_heart_rate_TextRotate_img_width * idle_heart_rate_rotate_string.length;
                  idle_heart_rate_TextRotate_posOffset = idle_heart_rate_TextRotate_posOffset + -4 * (idle_heart_rate_rotate_string.length - 1);
                  img_offset -= idle_heart_rate_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of idle_heart_rate_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_heart_rate_TextRotate[index].setProperty(hmUI.prop.POS_X, 59 + img_offset);
                      idle_heart_rate_TextRotate[index].setProperty(hmUI.prop.SRC, idle_heart_rate_TextRotate_ASCIIARRAY[charCode]);
                      idle_heart_rate_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_heart_rate_TextRotate_img_width + -4;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate day_TIME');
              let idle_day_rotate_string = parseInt(valueDay).toString();
              idle_day_rotate_string = idle_day_rotate_string.padStart(2, '0');

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  idle_day_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueDay != null && valueDay != undefined && isFinite(valueDay) && idle_day_rotate_string.length > 0 && idle_day_rotate_string.length <= 2) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let idle_day_TextRotate_posOffset = idle_day_TextRotate_img_width * idle_day_rotate_string.length;
                  img_offset -= idle_day_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of idle_day_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_day_TextRotate[index].setProperty(hmUI.prop.POS_X, 279 + img_offset);
                      idle_day_TextRotate[index].setProperty(hmUI.prop.SRC, idle_day_TextRotate_ASCIIARRAY[charCode]);
                      idle_day_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_day_TextRotate_img_width;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate temperature_current_currentWeather');
              let idle_temperature_current_rotate_string = undefined;
              if (temperature_current_temp > -100) {
                temperatureCurrent = 0;
                idle_temperature_current_rotate_string = String(temperature_current_temp)
              };

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 4; i++) {  // hide all symbols
                  idle_temperature_current_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (temperatureCurrent != null && temperatureCurrent != undefined && isFinite(temperatureCurrent) && idle_temperature_current_rotate_string.length > 0 && idle_temperature_current_rotate_string.length <= 4) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = RIGHT
                  let idle_temperature_current_TextRotate_posOffset = idle_temperature_current_TextRotate_img_width * idle_temperature_current_rotate_string.length;
                  idle_temperature_current_TextRotate_posOffset = idle_temperature_current_TextRotate_posOffset + -4 * (idle_temperature_current_rotate_string.length - 1);
                  img_offset -= idle_temperature_current_TextRotate_posOffset;
                  // alignment end
                  
                  let index = 0;
                  for (let char of idle_temperature_current_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 4) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_temperature_current_TextRotate[index].setProperty(hmUI.prop.POS_X, 404 + img_offset);
                      idle_temperature_current_TextRotate[index].setProperty(hmUI.prop.SRC, idle_temperature_current_TextRotate_ASCIIARRAY[charCode]);
                      idle_temperature_current_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_temperature_current_TextRotate_img_width + -4;
                      index++;
                    }  // end if digit
                    else { 
                      idle_temperature_current_TextRotate[index].setProperty(hmUI.prop.POS_X, 404 + img_offset);
                      idle_temperature_current_TextRotate[index].setProperty(hmUI.prop.SRC, 'dig_a_10.png');
                      idle_temperature_current_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_temperature_current_TextRotate_dot_width + -4;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                }  // end isFinite
                else {
                  idle_temperature_current_TextRotate[0].setProperty(hmUI.prop.POS_X, 404 - idle_temperature_current_TextRotate_error_img_width / 2);
                  idle_temperature_current_TextRotate[0].setProperty(hmUI.prop.SRC, 'dig_a_10.png');
                  idle_temperature_current_TextRotate[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

            };

            //#endregion
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                text_update();
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerTextUpdate) {
                    normal_timerTextUpdate = timer.createTimer(0, 1000, (function (option) {
                      text_update();
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.AOD) {
                  if (!idle_timerTextUpdate) {
                    idle_timerTextUpdate = timer.createTimer(0, 1000, (function (option) {
                      text_update();
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerTextUpdate) {
                  timer.stopTimer(normal_timerTextUpdate);
                  normal_timerTextUpdate = undefined;
                }
                if (idle_timerTextUpdate) {
                  timer.stopTimer(idle_timerTextUpdate);
                  idle_timerTextUpdate = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                heart_rate.removeEventListener(heart.event.CURRENT, hrCurrListener);
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
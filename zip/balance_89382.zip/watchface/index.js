﻿    /*
    ** Watch_Face_Editor tool v 18.0
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_image_img = ''
        let normal_sun_icon_img = ''
        let normal_sun_high_text_img = ''
        let normal_sun_low_text_img = ''
        let normal_temperature_icon_img = ''
        let normal_temperature_high_text_img = ''
        let normal_temperature_low_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_city_name_text = ''
        let normal_battery_text_text_img = ''
        let normal_battery_text_separator_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_digital_clock_minute_separator_img = ''
        let normal_calorie_current_text_img = ''
        let normal_calorie_current_separator_img = ''
        let normal_distance_text_text_img = ''
        let normal_distance_text_separator_img = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_step_icon_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_text_separator_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let idle_background_bg = ''
        let idle_digital_clock_img_time = ''
        let idle_second_TextRotate = new Array(2);
        let idle_second_TextRotate_ASCIIARRAY = new Array(10);
        let idle_second_TextRotate_img_width = 53;
        let idle_timerTextUpdate = undefined;
        let idle_image_img = ''
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: '00_compass_5.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 268,
              month_startY: 76,
              month_sc_array: ["34.png","35.png","36.png","37.png","38.png","39.png","40.png","41.png","42.png","43.png","44.png","45.png"],
              month_tc_array: ["34.png","35.png","36.png","37.png","38.png","39.png","40.png","41.png","42.png","43.png","44.png","45.png"],
              month_en_array: ["34.png","35.png","36.png","37.png","38.png","39.png","40.png","41.png","42.png","43.png","44.png","45.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 132,
              y: 76,
              week_en: ["46.png","47.png","48.png","49.png","50.png","51.png","52.png"],
              week_tc: ["46.png","47.png","48.png","49.png","50.png","51.png","52.png"],
              week_sc: ["46.png","47.png","48.png","49.png","50.png","51.png","52.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 224,
              day_startY: 84,
              day_sc_array: ["05_S_0.png","05_S_1.png","05_S_2.png","05_S_3.png","05_S_4.png","05_S_5.png","05_S_6.png","05_S_7.png","05_S_8.png","05_S_9.png"],
              day_tc_array: ["05_S_0.png","05_S_1.png","05_S_2.png","05_S_3.png","05_S_4.png","05_S_5.png","05_S_6.png","05_S_7.png","05_S_8.png","05_S_9.png"],
              day_en_array: ["05_S_0.png","05_S_1.png","05_S_2.png","05_S_3.png","05_S_4.png","05_S_5.png","05_S_6.png","05_S_7.png","05_S_8.png","05_S_9.png"],
              day_zero: 0,
              day_space: 4,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: '01_top_2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 40,
              y: 222,
              src: '0067.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 78,
              y: 202,
              font_array: ["05_S_0.png","05_S_1.png","05_S_2.png","05_S_3.png","05_S_4.png","05_S_5.png","05_S_6.png","05_S_7.png","05_S_8.png","05_S_9.png"],
              padding: false,
              h_space: 2,
              dot_image: '10_separator_S.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 78,
              y: 247,
              font_array: ["05_S_0.png","05_S_1.png","05_S_2.png","05_S_3.png","05_S_4.png","05_S_5.png","05_S_6.png","05_S_7.png","05_S_8.png","05_S_9.png"],
              padding: false,
              h_space: 2,
              dot_image: '10_separator_S.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 102,
              y: 88,
              src: '10_BT_ON.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 350,
              y: 144,
              font_array: ["05_S_0.png","05_S_1.png","05_S_2.png","05_S_3.png","05_S_4.png","05_S_5.png","05_S_6.png","05_S_7.png","05_S_8.png","05_S_9.png"],
              padding: false,
              h_space: 2,
              unit_sc: '10_degree.png',
              unit_tc: '10_degree.png',
              unit_en: '10_degree.png',
              negative_image: '10_dash_S.png',
              invalid_image: '10_empty.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 64,
              y: 144,
              font_array: ["05_S_0.png","05_S_1.png","05_S_2.png","05_S_3.png","05_S_4.png","05_S_5.png","05_S_6.png","05_S_7.png","05_S_8.png","05_S_9.png"],
              padding: false,
              h_space: 2,
              unit_sc: '10_degree.png',
              unit_tc: '10_degree.png',
              unit_en: '10_degree.png',
              negative_image: '10_dash_S.png',
              invalid_image: '10_empty.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 210,
              y: 144,
              font_array: ["05_S_0.png","05_S_1.png","05_S_2.png","05_S_3.png","05_S_4.png","05_S_5.png","05_S_6.png","05_S_7.png","05_S_8.png","05_S_9.png"],
              padding: false,
              h_space: 2,
              unit_sc: '10_degree.png',
              unit_tc: '10_degree.png',
              unit_en: '10_degree.png',
              negative_image: '10_dash_S.png',
              invalid_image: '32_null_bmp.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 130,
              y: 124,
              image_array: ["09_weather_01.png","09_weather_02.png","09_weather_03.png","09_weather_04.png","09_weather_05.png","09_weather_06.png","09_weather_07.png","09_weather_08.png","09_weather_09.png","09_weather_10.png","09_weather_11.png","09_weather_12.png","09_weather_13.png","09_weather_14.png","09_weather_15.png","09_weather_16.png","09_weather_17.png","09_weather_18.png","09_weather_19.png","09_weather_20.png","09_weather_21.png","09_weather_22.png","09_weather_23.png","09_weather_24.png","09_weather_25.png","09_weather_26.png","09_weather_27.png","09_weather_28.png","09_weather_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 175,
              y: 42,
              w: 130,
              h: 35,
              text_size: 22,
              char_space: 0,
              color: 0xFF9C9C9C,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.NONE,
              align_h: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 232,
              y: 298,
              font_array: ["05_S_0.png","05_S_1.png","05_S_2.png","05_S_3.png","05_S_4.png","05_S_5.png","05_S_6.png","05_S_7.png","05_S_8.png","05_S_9.png"],
              padding: false,
              h_space: 2,
              unit_sc: '0111.png',
              unit_tc: '0111.png',
              unit_en: '0111.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 194,
              y: 298,
              src: 'battery.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 276,
              y: 124,
              image_array: ["12_moon_01.png","12_moon_02.png","12_moon_03.png","12_moon_04.png","12_moon_05.png","12_moon_06.png","12_moon_07.png","12_moon_08.png","12_moon_09.png","12_moon_10.png","12_moon_11.png","12_moon_12.png","12_moon_13.png","12_moon_14.png","12_moon_15.png","12_moon_16.png","12_moon_17.png","12_moon_18.png","12_moon_19.png","12_moon_20.png","12_moon_21.png","12_moon_22.png","12_moon_23.png","12_moon_24.png","12_moon_25.png","12_moon_26.png","12_moon_27.png","12_moon_28.png","12_moon_29.png","12_moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 160,
              hour_startY: 201,
              hour_array: ["03_ss_0.png","03_ss_1.png","03_ss_2.png","03_ss_3.png","03_ss_4.png","03_ss_5.png","03_ss_6.png","03_ss_7.png","03_ss_8.png","03_ss_9.png"],
              hour_zero: 1,
              hour_space: 3,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 260,
              minute_startY: 201,
              minute_array: ["03_ss_0.png","03_ss_1.png","03_ss_2.png","03_ss_3.png","03_ss_4.png","03_ss_5.png","03_ss_6.png","03_ss_7.png","03_ss_8.png","03_ss_9.png"],
              minute_zero: 1,
              minute_space: 3,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 358,
              second_startY: 201,
              second_array: ["03_ss_0.png","03_ss_1.png","03_ss_2.png","03_ss_3.png","03_ss_4.png","03_ss_5.png","03_ss_6.png","03_ss_7.png","03_ss_8.png","03_ss_9.png"],
              second_zero: 1,
              second_space: 3,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 236,
              y: 178,
              src: '10_separator.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_minute_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 334,
              y: 178,
              src: '10_separator.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 132,
              y: 380,
              font_array: ["05_S_0.png","05_S_1.png","05_S_2.png","05_S_3.png","05_S_4.png","05_S_5.png","05_S_6.png","05_S_7.png","05_S_8.png","05_S_9.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 202,
              y: 380,
              src: 'cal.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 74,
              y: 298,
              font_array: ["05_S_0.png","05_S_1.png","05_S_2.png","05_S_3.png","05_S_4.png","05_S_5.png","05_S_6.png","05_S_7.png","05_S_8.png","05_S_9.png"],
              padding: false,
              h_space: 2,
              unit_sc: '32_km.png',
              unit_tc: '32_km.png',
              unit_en: '32_km.png',
              dot_image: '32_dot.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 102,
              y: 342,
              src: 'way.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 330,
              y: 298,
              font_array: ["05_S_0.png","05_S_1.png","05_S_2.png","05_S_3.png","05_S_4.png","05_S_5.png","05_S_6.png","05_S_7.png","05_S_8.png","05_S_9.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 342,
              y: 338,
              src: 'step.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 145,
              y: 344,
              src: '11_bat_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 145,
              y: 344,
              image_array: ["11_bat_1.png","11_bat_2.png","11_bat_3.png","11_bat_4.png","11_bat_5.png","11_bat_6.png","11_bat_7.png","11_bat_8.png","11_bat_9.png","11_bat_10.png"],
              image_length: 10,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 286,
              y: 380,
              font_array: ["05_S_0.png","05_S_1.png","05_S_2.png","05_S_3.png","05_S_4.png","05_S_5.png","05_S_6.png","05_S_7.png","05_S_8.png","05_S_9.png"],
              padding: false,
              h_space: 2,
              unit_sc: '32_pul.png',
              unit_tc: '32_pul.png',
              unit_en: '32_pul.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 244,
              y: 380,
              src: 'heart.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 102,
              y: 88,
              src: '10_BT_OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 356,
              y: 88,
              src: '10_AL_on.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 38,
              hour_startY: 178,
              hour_array: ["02_hhmm_0.png","02_hhmm_1.png","02_hhmm_2.png","02_hhmm_3.png","02_hhmm_4.png","02_hhmm_5.png","02_hhmm_6.png","02_hhmm_7.png","02_hhmm_8.png","02_hhmm_9.png"],
              hour_zero: 1,
              hour_space: 8,
              hour_angle: 0,
              hour_unit_sc: '10_separator.png',
              hour_unit_tc: '10_separator.png',
              hour_unit_en: '10_separator.png',
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 183,
              minute_startY: 178,
              minute_array: ["02_hhmm_0.png","02_hhmm_1.png","02_hhmm_2.png","02_hhmm_3.png","02_hhmm_4.png","02_hhmm_5.png","02_hhmm_6.png","02_hhmm_7.png","02_hhmm_8.png","02_hhmm_9.png"],
              minute_zero: 1,
              minute_space: 8,
              minute_angle: 0,
              minute_follow: 0,
              minute_unit_sc: '10_separator.png',
              minute_unit_tc: '10_separator.png',
              minute_unit_en: '10_separator.png',
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_second_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 330,
              // y: 178,
              // font_array: ["02_hhmm_0.png","02_hhmm_1.png","02_hhmm_2.png","02_hhmm_3.png","02_hhmm_4.png","02_hhmm_5.png","02_hhmm_6.png","02_hhmm_7.png","02_hhmm_8.png","02_hhmm_9.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: 8,
              // angle: 0,
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.SECOND,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_second_TextRotate_ASCIIARRAY[0] = '02_hhmm_0.png';  // set of images with numbers
            idle_second_TextRotate_ASCIIARRAY[1] = '02_hhmm_1.png';  // set of images with numbers
            idle_second_TextRotate_ASCIIARRAY[2] = '02_hhmm_2.png';  // set of images with numbers
            idle_second_TextRotate_ASCIIARRAY[3] = '02_hhmm_3.png';  // set of images with numbers
            idle_second_TextRotate_ASCIIARRAY[4] = '02_hhmm_4.png';  // set of images with numbers
            idle_second_TextRotate_ASCIIARRAY[5] = '02_hhmm_5.png';  // set of images with numbers
            idle_second_TextRotate_ASCIIARRAY[6] = '02_hhmm_6.png';  // set of images with numbers
            idle_second_TextRotate_ASCIIARRAY[7] = '02_hhmm_7.png';  // set of images with numbers
            idle_second_TextRotate_ASCIIARRAY[8] = '02_hhmm_8.png';  // set of images with numbers
            idle_second_TextRotate_ASCIIARRAY[9] = '02_hhmm_9.png';  // set of images with numbers

            //#region TextRotate
            for (let i = 0; i < 2; i++) {
              idle_second_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 330,
                center_y: 178,
                pos_x: 330,
                pos_y: 178,
                angle: 0,
                src: '02_hhmm_0.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_second_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //#endregion

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            let screenType = hmSetting.getScreenType();
            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: '01_top_2.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            //#region text_update
            function text_update() {
              console.log('text_update()');

              console.log('update text rotate second_TIME');
              let valueSecond = timeSensor.second;
              let idle_second_rotate_string = parseInt(valueSecond).toString();
              idle_second_rotate_string = idle_second_rotate_string.padStart(2, '0');

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  idle_second_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueSecond != null && valueSecond != undefined && isFinite(valueSecond) && idle_second_rotate_string.length > 0 && idle_second_rotate_string.length <= 2) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of idle_second_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_second_TextRotate[index].setProperty(hmUI.prop.POS_X, 330 + img_offset);
                      idle_second_TextRotate[index].setProperty(hmUI.prop.SRC, idle_second_TextRotate_ASCIIARRAY[charCode]);
                      idle_second_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_second_TextRotate_img_width + 8;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

            };

            //#endregion
            function scale_call() {
              console.log('scale_call()');

              console.log('Weather city name');
              let weatherData = weatherSensor.getForecastWeather();
              let normal_cityNameStr = weatherData.cityName;
              normal_city_name_text.setProperty(hmUI.prop.TEXT, normal_cityNameStr);

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                text_update();
                if (screenType == hmSetting.screen_type.AOD) {
                  if (!idle_timerTextUpdate) {
                    idle_timerTextUpdate = timer.createTimer(0, 1000, (function (option) {
                      text_update();
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (idle_timerTextUpdate) {
                  timer.stopTimer(idle_timerTextUpdate);
                  idle_timerTextUpdate = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
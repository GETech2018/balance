/*
** Facemaker bundle tool v0.0.3
* *huamiOS watchface js version v4.4.0.1
* *Copyright © Huami. All Rights Reserved
*/


try {
	(() => {
		var __$$app$$__ = __$$hmAppManager$$__.currentApp;
		var __$$module$$__ = __$$app$$__.current;

		//drink is a name,can modify
		var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

		'use strict';

		//dynamic modify start
		let normal_img0 = '';
		let normal_img1 = '';
		let normal_hour_imagecombo3 = '';
		let normal_minute_imagecombo4 = '';
		let normal_second_imagecombo5 = '';
		let normal_img6 = '';
		let normal_img7 = '';
		let normal_date_imagecombo9 = '';
		let normal_week_imageset10 = '';
		let normal_month_imageset11 = '';
		let normal_img12 = '';
		let normal_img13 = '';
		let normal_airpressure_imagecombo15 = '';
		let normal_heart_current_imagecombo17 = '';
		let normal_steps_imagecombo19 = '';
		let normal_sleep_imagecombo21 = new Array(4);
		let normal_sleep_imagecombo21_padding = false;
		let normal_sleep_imagecombo21_array = ['0078.png','0079.png','0080.png','0081.png','0082.png','0083.png','0084.png','0085.png','0086.png','0087.png','0088.png'];
		let normal_stress_imagecombo23 = '';
		let normal_battery_imagecombo25 = '';
		let normal_weather_imageset27 = '';
		let normal_weather_imageset28 = '';
		let normal_temperature_current_imagecombo29 = '';
		let normal_temperature_high_imagecombo30 = '';
		let normal_temperature_low_imagecombo31 = '';
		let normal_img32 = '';
		let normal_heart_shortcut35 = '';
		let normal_sleep_shortcut36 = '';
		let normal_steps_shortcut37 = '';
		let normal_stress_shortcut38 = '';
		let normal_alarm_shortcut39 = '';
		let normal_stopwatch_shortcut40 = '';
		let normal_calendar_shortcut41 = '';
		let normal_airpressure_shortcut42 = '';
		let normal_weather_shortcut43 = '';
		let idle_hour_imagecombo45 = '';
		let idle_minute_imagecombo46 = '';
		let idle_img47 = '';
		let idle_img48 = '';
		let idle_date_imagecombo50 = '';
		let idle_week_imageset51 = '';
		let idle_month_imageset52 = '';
		let idle_img53 = '';
		let idle_img54 = '';
		//dynamic modify end

		//not required
		const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

		__$$module$$__.module = DeviceRuntimeCore.WatchFace({
			init_view() {

				const sleepSensor = hmSensor.createSensor(hmSensor.id.SLEEP);
				let screenType = hmSetting.getScreenType();

				normal_img0 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 483,
					h: 480,
					src: '0002.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img1 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 201,
					y: 447,
					w: 33,
					h: 28,
					src: '0003.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_hour_imagecombo3 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					hour_startX: 31,
					hour_startY: 109,
					hour_array: ["0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png"],
					hour_zero: true,
					hour_space: 0,
					hour_align: hmUI.align.LEFT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_minute_imagecombo4 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					minute_startX: 193,
					minute_startY: 109,
					minute_array: ["0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png"],
					minute_zero: true,
					minute_space: 0,
					minute_align: hmUI.align.CENTER_H,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_second_imagecombo5 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					second_startX: 354,
					second_startY: 145,
					second_array: ["0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png","0023.png"],
					second_zero: true,
					second_space: 0,
					second_align: hmUI.align.CENTER_H,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img6 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 164,
					y: 97,
					w: 26,
					h: 129,
					src: '0024.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img7 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 23,
					y: 121,
					w: 316,
					h: 45,
					src: '0025.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_date_imagecombo9 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
					day_startX: 109,
					day_startY: 13,
					day_sc_array: ["0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png","0033.png","0034.png","0035.png"],
					day_tc_array: ["0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png","0033.png","0034.png","0035.png"],
					day_en_array: ["0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png","0033.png","0034.png","0035.png"],
					day_zero: true,
					day_space: -14,
					day_align: hmUI.align.CENTER_H,
					day_is_character: false,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_week_imageset10 = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
					x: 288,
					y: 37,
					week_en: ["0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png"],
					week_tc: ["0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png"],
					week_sc: ["0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png"],
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_month_imageset11 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
					month_startX: 213,
					month_startY: 37,
					month_sc_array: ["0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png","0050.png","0051.png","0052.png","0053.png","0054.png"],
					month_tc_array: ["0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png","0050.png","0051.png","0052.png","0053.png","0054.png"],
					month_en_array: ["0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png","0050.png","0051.png","0052.png","0053.png","0054.png"],
					month_is_character: true,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img12 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 277,
					y: 37,
					w: 10,
					h: 30,
					src: '0055.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img13 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 76,
					y: 1,
					w: 284,
					h: 113,
					src: '0056.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_airpressure_imagecombo15 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 293,
					y: 81,
					font_array: ["0057.png","0058.png","0059.png","0060.png","0061.png","0062.png","0063.png","0064.png","0065.png","0066.png"],
					padding: false,
					h_space: -2,
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.ALTIMETER,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_heart_current_imagecombo17 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 121,
					y: 401,
					font_array: ["0067.png","0068.png","0069.png","0070.png","0071.png","0072.png","0073.png","0074.png","0075.png","0076.png"],
					padding: false,
					h_space: -2,
					invalid_image: '0077.png',
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.HEART,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_steps_imagecombo19 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 61,
					y: 350,
					font_array: ["0078.png","0079.png","0080.png","0081.png","0082.png","0083.png","0084.png","0085.png","0086.png","0087.png"],
					padding: false,
					h_space: -2,
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.STEP,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				for (let i = 0; i < normal_sleep_imagecombo21.length; i++) {
					normal_sleep_imagecombo21[i] = hmUI.createWidget(hmUI.widget.IMG, {
						x: 39 + i * 21,
						y: 294,
						w: 21,
						h: 36,
						enable: false,
						show_level: hmUI.show_level.ONLY_NORMAL,
					})

				}

				normal_stress_imagecombo23 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 227,
					y: 448,
					font_array: ["0089.png","0090.png","0091.png","0092.png","0093.png","0094.png","0095.png","0096.png","0097.png","0098.png"],
					padding: false,
					h_space: -2,
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.STRESS,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_battery_imagecombo25 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 349,
					y: 251,
					font_array: ["0099.png","0100.png","0101.png","0102.png","0103.png","0104.png","0105.png","0106.png","0107.png","0108.png"],
					padding: false,
					h_space: -2,
					unit_sc: '0109.png',
					unit_tc: '0109.png',
					unit_en: '0109.png',
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.BATTERY,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_weather_imageset27 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
					x: 249,
					y: 315,
					image_array: ["0110.png","0111.png","0112.png","0113.png","0114.png","0115.png","0116.png","0115.png","0116.png","0117.png","0118.png","0119.png","0120.png","0121.png","0122.png","0123.png","0117.png","0124.png","0118.png","0125.png","0125.png","0118.png","0126.png","0127.png","0118.png","0128.png","0129.png","0130.png","0131.png"],
					image_length: 29,
					type: hmUI.data_type.WEATHER_CURRENT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_weather_imageset28 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
					x: 338,
					y: 318,
					image_array: ["0132.png","0133.png","0134.png","0135.png","0136.png","0137.png","0138.png","0139.png","0140.png","0141.png","0142.png","0143.png","0144.png","0145.png","0146.png","0147.png","0148.png","0149.png","0150.png","0151.png","0152.png","0153.png","0154.png","0155.png","0156.png","0157.png","0158.png","0159.png","0160.png"],
					image_length: 29,
					type: hmUI.data_type.WEATHER_CURRENT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_temperature_current_imagecombo29 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 186,
					y: 287,
					font_array: ["0161.png","0162.png","0163.png","0164.png","0165.png","0166.png","0167.png","0168.png","0169.png","0170.png"],
					padding: false,
					h_space: -3,
					unit_sc: ["0172.png"],
					unit_tc: ["0172.png"],
					unit_en: ["0172.png"],
					negative_image: ["0171.png"],
					invalid_image: ["0171.png"],
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.WEATHER_CURRENT,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_temperature_high_imagecombo30 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 326,
					y: 411,
					font_array: ["0173.png","0174.png","0175.png","0176.png","0177.png","0178.png","0179.png","0180.png","0181.png","0182.png"],
					padding: false,
					h_space: -1,
					unit_sc: ["0184.png"],
					unit_tc: ["0184.png"],
					unit_en: ["0184.png"],
					negative_image: ["0183.png"],
					invalid_image: ["0183.png"],
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.WEATHER_HIGH,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_temperature_low_imagecombo31 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 268,
					y: 411,
					font_array: ["0173.png","0174.png","0175.png","0176.png","0177.png","0178.png","0179.png","0180.png","0181.png","0182.png"],
					padding: false,
					h_space: -1,
					unit_sc: ["0184.png"],
					unit_tc: ["0184.png"],
					unit_en: ["0184.png"],
					negative_image: ["0183.png"],
					invalid_image: ["0183.png"],
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.WEATHER_LOW,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img32 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 321,
					y: 411,
					w: 13,
					h: 27,
					src: '0185.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_heart_shortcut35 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 109,
					y: 394,
					w: 100,
					h: 44,
					src: '',
					type: hmUI.data_type.HEART,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_sleep_shortcut36 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 49,
					y: 289,
					w: 100,
					h: 38,
					src: '',
					type: hmUI.data_type.SLEEP,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_steps_shortcut37 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 73,
					y: 349,
					w: 100,
					h: 39,
					src: '',
					type: hmUI.data_type.STEP,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_stress_shortcut38 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 193,
					y: 445,
					w: 100,
					h: 31,
					src: '',
					type: hmUI.data_type.STRESS,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_alarm_shortcut39 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 49,
					y: 133,
					w: 100,
					h: 100,
					src: '',
					type: hmUI.data_type.ALARM_CLOCK,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_stopwatch_shortcut40 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 205,
					y: 124,
					w: 100,
					h: 100,
					src: '',
					type: hmUI.data_type.STOP_WATCH,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_calendar_shortcut41 = hmUI.createWidget(hmUI.widget.BUTTON, {
					x: 121,
					y: 13,
					w: 100,
					h: 100,
					text: '',
					normal_src: '',
					press_src: '',
					click_func: () => {
						hmApp.startApp({ url: 'ScheduleCalScreen', native: true });
					},
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_airpressure_shortcut42 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 265,
					y: 73,
					w: 100,
					h: 38,
					src: '',
					type: hmUI.data_type.PRESSURE,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_weather_shortcut43 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 289,
					y: 325,
					w: 100,
					h: 100,
					src: '',
					type: hmUI.data_type.WEATHER_CURRENT,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				idle_hour_imagecombo45 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					hour_startX: 31,
					hour_startY: 109,
					hour_array: ["0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png"],
					hour_zero: true,
					hour_space: 0,
					hour_align: hmUI.align.LEFT,
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_minute_imagecombo46 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					minute_startX: 193,
					minute_startY: 109,
					minute_array: ["0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png"],
					minute_zero: true,
					minute_space: 0,
					minute_align: hmUI.align.CENTER_H,
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_img47 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 164,
					y: 97,
					w: 26,
					h: 129,
					src: '0024.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_img48 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 23,
					y: 121,
					w: 316,
					h: 45,
					src: '0025.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_date_imagecombo50 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
					day_startX: 109,
					day_startY: 13,
					day_sc_array: ["0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png","0033.png","0034.png","0035.png"],
					day_tc_array: ["0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png","0033.png","0034.png","0035.png"],
					day_en_array: ["0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png","0033.png","0034.png","0035.png"],
					day_zero: true,
					day_space: -14,
					day_align: hmUI.align.CENTER_H,
					day_is_character: false,
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_week_imageset51 = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
					x: 288,
					y: 37,
					week_en: ["0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png"],
					week_tc: ["0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png"],
					week_sc: ["0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png"],
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_month_imageset52 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
					month_startX: 213,
					month_startY: 37,
					month_sc_array: ["0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png","0050.png","0051.png","0052.png","0053.png","0054.png"],
					month_tc_array: ["0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png","0050.png","0051.png","0052.png","0053.png","0054.png"],
					month_en_array: ["0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png","0050.png","0051.png","0052.png","0053.png","0054.png"],
					month_is_character: true,
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_img53 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 277,
					y: 37,
					w: 10,
					h: 30,
					src: '0055.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_img54 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					src: '0186.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				function updateSleep() {
					let normal_sleep_imagecombo21_h = Math.floor(sleepSensor.getTotalTime() / 60).toString();
					let normal_sleep_imagecombo21_m = Math.floor(sleepSensor.getTotalTime() % 60).toString().padStart(2, '0');
					let normal_sleep_imagecombo21_current = (normal_sleep_imagecombo21_padding === true ? normal_sleep_imagecombo21_h.padStart(2, '0') : normal_sleep_imagecombo21_h) + ':' + normal_sleep_imagecombo21_m;
					let normal_sleep_imagecombo21_cp = (normal_sleep_imagecombo21_padding === true || normal_sleep_imagecombo21_h.length == 2) ? 2 : 1;
					for (let i = 0; i < normal_sleep_imagecombo21.length; i++) {
						if (i == normal_sleep_imagecombo21_cp) {
							normal_sleep_imagecombo21[i].setProperty(hmUI.prop.SRC, normal_sleep_imagecombo21_array[10]);
						} else {
							normal_sleep_imagecombo21[i].setProperty(hmUI.prop.SRC, normal_sleep_imagecombo21_array[normal_sleep_imagecombo21_current.toString().charAt(i)]);
						}
					}
				}

				sleepSensor.addEventListener(hmSensor.event.CHANGE, function() {
					updateSleep();
				});

				const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
					resume_call: (function () {
						updateSleep();
					}),
					pause_call: (function () {
					}),
				})
			},

		onInit() {
			console.log('index page.js on init invoke')
			this.init_view()
		},
		onReady() {
			console.log('index page.js on ready invoke')
		},
		onShow() {
			console.log('index page.js on show invoke')
		},
		onHide() {
			console.log('index page.js on hide invoke')
		},
		onDestroy() {
			console.log('index page.js on destroy invoke')
		},
	});	})()
} catch (e) {
	console.log(e)
}
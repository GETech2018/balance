﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js



        // Activity switch
        let elementnumber_2 = 1
        let total_elemente2 = 3

        function click_elemente2() {
            if(elementnumber_2==total_elemente2) {
            elementnumber_2=1;
                UpdateElemente2One();
                }
            else {
                elementnumber_2=elementnumber_2+1;
                if(elementnumber_2==2) {
                  UpdateElemente2Two();
                }
                if(elementnumber_2==3) {
                  UpdateElemente2Three();
                }

            }
            if(elementnumber_2==1) hmUI.showToast({text: 'STEP'});
            if(elementnumber_2==2) hmUI.showToast({text: 'DISTANCE'});
            if(elementnumber_2==3) hmUI.showToast({text: 'CALORIES'});
        }

        //STEP
        function UpdateElemente2One(){
        normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
        }

        //DISTANCE
        function UpdateElemente2Two(){
        normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
        }

        //CALORIES
        function UpdateElemente2Three(){
        normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
        }

// ON / OFF hand clock
        let normal_digital_clock_img_time_second2 = ''
        let idle_digital_clock_img_time_second2 = ''
        let btn_element_1 = ''
        let elementnumber_1 = 1
        let total_elemente = 2

        function click_elemente() {
            if(elementnumber_1==total_elemente) {
            elementnumber_1=1;
                UpdateElementeOne();
                }
            else {
                elementnumber_1=elementnumber_1+1;
                if(elementnumber_1==2) {
                  UpdateElementeTwo();
                }

            }
            if(elementnumber_1==1) hmUI.showToast({text: 'Hand clock ON'});
            if(elementnumber_1==2) hmUI.showToast({text: 'Handclock OFF'});
        }

        //Hand clock on
        function UpdateElementeOne(){

                normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.VISIBLE, true);
                normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.VISIBLE, true);


        }

        //hand clock off
        function UpdateElementeTwo(){
                normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.VISIBLE, false);
        }

 /////////////////////////////   end  on / off hand clock ////////////////////////


        // Start background change
        let btnbackground = ''
        let backgroundnumber = 1
        let totalpictures = 5

        function click_Background() {
            if(backgroundnumber==totalpictures) {
            backgroundnumber=1;
                UpdateBackgroundOne();
                }
            else {
                backgroundnumber=backgroundnumber+1;
                if(backgroundnumber==2) {
                  UpdateBackgroundTwo();
                }

               if(backgroundnumber==3) {
                  UpdateBackgroundThree();
                }


               if(backgroundnumber==4) {
                  UpdateBackgroundFour();
                }


               if(backgroundnumber==5) {
                  UpdateBackgroundFive();
                }

            }
            if(backgroundnumber==1) hmUI.showToast({text: 'Color Blue'});
            if(backgroundnumber==2) hmUI.showToast({text: 'Color Red'});
            if(backgroundnumber==3) hmUI.showToast({text: 'Color Yellow'});
            if(backgroundnumber==4) hmUI.showToast({text: 'Color Green'}); 
            if(backgroundnumber==5) hmUI.showToast({text: 'Black & White'}); 
        }

        ///////////////////////////////////////////////////////one
        function UpdateBackgroundOne(){
normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.SRC, "Hand_H" + parseInt(backgroundnumber) + ".png");
normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.SRC, "Hand_M" + parseInt(backgroundnumber) + ".png");

 normal_image_img.setProperty(hmUI.prop.SRC, "colorBlue.png");

normal_digital_clock_hour_separator_img.setProperty(hmUI.prop.SRC, "Time_Blue_Dot.png");
normal_digital_clock_minute_separator_img.setProperty(hmUI.prop.SRC, "Blue_Symbo.png");


            normal_heart_rate_pointer_progress_img_pointer.setProperty(hmUI.prop.MORE, {
              src: 'Pointer1.png',
              center_x: 240,
              center_y: 137,
              x: 29,
              y: 57,
              start_angle: 240,
              end_angle: 482,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            normal_date_img_date_week_img.setProperty(hmUI.prop.MORE, {
              x: 75,
              y: 179,
              week_en: ["Week_B_1.png","Week_B_2.png","Week_B_3.png","Week_B_4.png","Week_B_5.png","Week_B_6.png","Week_B_7.png"],
              week_tc: ["Week_B_1.png","Week_B_2.png","Week_B_3.png","Week_B_4.png","Week_B_5.png","Week_B_6.png","Week_B_7.png"],
              week_sc: ["Week_B_1.png","Week_B_2.png","Week_B_3.png","Week_B_4.png","Week_B_5.png","Week_B_6.png","Week_B_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            normal_step_current_text_img.setProperty(hmUI.prop.MORE, {
              x: 283,
              y: 271,
              font_array: ["Act_B_0.png","Act_B_1.png","Act_B_2.png","Act_B_3.png","Act_B_4.png","Act_B_5.png","Act_B_6.png","Act_B_7.png","Act_B_8.png","Act_B_9.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_second.setProperty(hmUI.prop.MORE, {
              second_startX: 0,
              second_startY: 0,
              second_array: ["Blue_S_0.png","Blue_S_1.png","Blue_S_2.png","Blue_S_3.png","Blue_S_4.png","Blue_S_5.png","0_Empty.png","0_Empty.png","0_Empty.png","0_Empty.png"],
              second_zero: 1,
              second_space: 222,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            normal_digital_clock_img_time_minute.setProperty(hmUI.prop.MORE, {
              minute_startX: 337,
              minute_startY: 341,
              minute_array: ["Time_Blue_0.png","Time_Blue_1.png","Time_Blue_2.png","Time_Blue_3.png","Time_Blue_4.png","Time_Blue_5.png","Time_Blue_6.png","Time_Blue_7.png","Time_Blue_8.png","Time_Blue_9.png"],
              minute_zero: 1,
              minute_space: 3,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_hour.setProperty(hmUI.prop.MORE, {
              hour_startX: 256,
              hour_startY: 341,
              hour_array: ["Time_Blue_0.png","Time_Blue_1.png","Time_Blue_2.png","Time_Blue_3.png","Time_Blue_4.png","Time_Blue_5.png","Time_Blue_6.png","Time_Blue_7.png","Time_Blue_8.png","Time_Blue_9.png"],
              hour_zero: 1,
              hour_space: 3,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


const result = hmSetting.setScreenOff()

        }

        /////////////////////////////////////////////////////two

        function UpdateBackgroundTwo(){
normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.SRC, "Hand_H" + parseInt(backgroundnumber) + ".png");
normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.SRC, "Hand_M" + parseInt(backgroundnumber) + ".png");


 normal_image_img.setProperty(hmUI.prop.SRC, "colorRED.png");


normal_digital_clock_hour_separator_img.setProperty(hmUI.prop.SRC, "Time_Red_Dot.png");
normal_digital_clock_minute_separator_img.setProperty(hmUI.prop.SRC, "Red_Symbo.png");



            normal_heart_rate_pointer_progress_img_pointer.setProperty(hmUI.prop.MORE, {
              src: 'Pointer2.png',
              center_x: 240,
              center_y: 137,
              x: 29,
              y: 57,
              start_angle: 240,
              end_angle: 482,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });



           normal_date_img_date_week_img.setProperty(hmUI.prop.MORE, {
              x: 75,
              y: 179,
              week_en: ["Week_R_1.png","Week_R_2.png","Week_R_3.png","Week_R_4.png","Week_R_5.png","Week_R_6.png","Week_R_7.png"],
              week_tc: ["Week_R_1.png","Week_R_2.png","Week_R_3.png","Week_R_4.png","Week_R_5.png","Week_R_6.png","Week_R_7.png"],
              week_sc: ["Week_R_1.png","Week_R_2.png","Week_R_3.png","Week_R_4.png","Week_R_5.png","Week_R_6.png","Week_R_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img.setProperty(hmUI.prop.MORE, {
              x: 283,
              y: 271,
              font_array: ["Act_R_0.png","Act_R_1.png","Act_R_2.png","Act_R_3.png","Act_R_4.png","Act_R_5.png","Act_R_6.png","Act_R_7.png","Act_R_8.png","Act_R_9.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            normal_digital_clock_img_time_second.setProperty(hmUI.prop.MORE, {
              second_startX: 0,
              second_startY: 0,
              second_array: ["Red_S_0.png","Red_S_1.png","Red_S_2.png","Red_S_3.png","Red_S_4.png","Red_S_5.png","0_Empty.png","0_Empty.png","0_Empty.png","0_Empty.png"],
              second_zero: 1,
              second_space: 222,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            normal_digital_clock_img_time_minute.setProperty(hmUI.prop.MORE, {
              minute_startX: 337,
              minute_startY: 341,
              minute_array: ["Time_Red_0.png","Time_Red_1.png","Time_Red_2.png","Time_Red_3.png","Time_Red_4.png","Time_Red_5.png","Time_Red_6.png","Time_Red_7.png","Time_Red_8.png","Time_Red_9.png"],
              minute_zero: 1,
              minute_space: 3,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_hour.setProperty(hmUI.prop.MORE, {
              hour_startX: 256,
              hour_startY: 341,
              hour_array: ["Time_Red_0.png","Time_Red_1.png","Time_Red_2.png","Time_Red_3.png","Time_Red_4.png","Time_Red_5.png","Time_Red_6.png","Time_Red_7.png","Time_Red_8.png","Time_Red_9.png"],
              hour_zero: 1,
              hour_space: 3,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

const result = hmSetting.setScreenOff()

        }




        /////////////////////////////////////////////////////Three

        function UpdateBackgroundThree(){
normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.SRC, "Hand_H" + parseInt(backgroundnumber) + ".png");
normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.SRC, "Hand_M" + parseInt(backgroundnumber) + ".png");


 normal_image_img.setProperty(hmUI.prop.SRC, "colorYellow.png");


normal_digital_clock_hour_separator_img.setProperty(hmUI.prop.SRC, "Time_Yellow_Dot.png");
normal_digital_clock_minute_separator_img.setProperty(hmUI.prop.SRC, "Yellow_Symbo.png");



            normal_heart_rate_pointer_progress_img_pointer.setProperty(hmUI.prop.MORE, {
              src: 'Pointer3.png',
              center_x: 240,
              center_y: 137,
              x: 29,
              y: 57,
              start_angle: 240,
              end_angle: 482,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });



           normal_date_img_date_week_img.setProperty(hmUI.prop.MORE, {
              x: 75,
              y: 179,
              week_en: ["Week_Y_1.png","Week_Y_2.png","Week_Y_3.png","Week_Y_4.png","Week_Y_5.png","Week_Y_6.png","Week_Y_7.png"],
              week_tc: ["Week_Y_1.png","Week_Y_2.png","Week_Y_3.png","Week_Y_4.png","Week_Y_5.png","Week_Y_6.png","Week_Y_7.png"],
              week_sc: ["Week_Y_1.png","Week_Y_2.png","Week_Y_3.png","Week_Y_4.png","Week_Y_5.png","Week_Y_6.png","Week_Y_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img.setProperty(hmUI.prop.MORE, {
              x: 283,
              y: 271,
              font_array: ["Act_Y_0.png","Act_Y_1.png","Act_Y_2.png","Act_Y_3.png","Act_Y_4.png","Act_Y_5.png","Act_Y_6.png","Act_Y_7.png","Act_Y_8.png","Act_Y_9.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            normal_digital_clock_img_time_second.setProperty(hmUI.prop.MORE, {
              second_startX: 0,
              second_startY: 0,
              second_array: ["Yellow_S_0.png","Yellow_S_1.png","Yellow_S_2.png","Yellow_S_3.png","Yellow_S_4.png","Yellow_S_5.png","0_Empty.png","0_Empty.png","0_Empty.png","0_Empty.png"],
              second_zero: 1,
              second_space: 222,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            normal_digital_clock_img_time_minute.setProperty(hmUI.prop.MORE, {
              minute_startX: 337,
              minute_startY: 341,
              minute_array: ["Time_Yellow_0.png","Time_Yellow_1.png","Time_Yellow_2.png","Time_Yellow_3.png","Time_Yellow_4.png","Time_Yellow_5.png","Time_Yellow_6.png","Time_Yellow_7.png","Time_Yellow_8.png","Time_Yellow_9.png"],
              minute_zero: 1,
              minute_space: 3,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_hour.setProperty(hmUI.prop.MORE, {
              hour_startX: 256,
              hour_startY: 341,
              hour_array: ["Time_Yellow_0.png","Time_Yellow_1.png","Time_Yellow_2.png","Time_Yellow_3.png","Time_Yellow_4.png","Time_Yellow_5.png","Time_Yellow_6.png","Time_Yellow_7.png","Time_Yellow_8.png","Time_Yellow_9.png"],
              hour_zero: 1,
              hour_space: 3,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


const result = hmSetting.setScreenOff()
        }

        /////////////////////////////////////////////////////Four

        function UpdateBackgroundFour(){
normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.SRC, "Hand_H" + parseInt(backgroundnumber) + ".png");
normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.SRC, "Hand_M" + parseInt(backgroundnumber) + ".png");


 normal_image_img.setProperty(hmUI.prop.SRC, "colorGreen.png");


normal_digital_clock_hour_separator_img.setProperty(hmUI.prop.SRC, "Time_Green_Dot.png");
normal_digital_clock_minute_separator_img.setProperty(hmUI.prop.SRC, "Green_Symbo.png");


            normal_heart_rate_pointer_progress_img_pointer.setProperty(hmUI.prop.MORE, {
              src: 'Pointer4.png',
              center_x: 240,
              center_y: 137,
              x: 29,
              y: 57,
              start_angle: 240,
              end_angle: 482,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });




           normal_date_img_date_week_img.setProperty(hmUI.prop.MORE, {
              x: 75,
              y: 179,
              week_en: ["Week_G_1.png","Week_G_2.png","Week_G_3.png","Week_G_4.png","Week_G_5.png","Week_G_6.png","Week_G_7.png"],
              week_tc: ["Week_G_1.png","Week_G_2.png","Week_G_3.png","Week_G_4.png","Week_G_5.png","Week_G_6.png","Week_G_7.png"],
              week_sc: ["Week_G_1.png","Week_G_2.png","Week_G_3.png","Week_G_4.png","Week_G_5.png","Week_G_6.png","Week_G_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img.setProperty(hmUI.prop.MORE, {
              x: 283,
              y: 271,
              font_array: ["Act_G_0.png","Act_G_1.png","Act_G_2.png","Act_G_3.png","Act_G_4.png","Act_G_5.png","Act_G_6.png","Act_G_7.png","Act_G_8.png","Act_G_9.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            normal_digital_clock_img_time_second.setProperty(hmUI.prop.MORE, {
              second_startX: 0,
              second_startY: 0,
              second_array: ["Green_S_0.png","Green_S_1.png","Green_S_2.png","Green_S_3.png","Green_S_4.png","Green_S_5.png","0_Empty.png","0_Empty.png","0_Empty.png","0_Empty.png"],
              second_zero: 1,
              second_space: 222,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            normal_digital_clock_img_time_minute.setProperty(hmUI.prop.MORE, {
              minute_startX: 337,
              minute_startY: 341,
              minute_array: ["Time_Green_0.png","Time_Green_1.png","Time_Green_2.png","Time_Green_3.png","Time_Green_4.png","Time_Green_5.png","Time_Green_6.png","Time_Green_7.png","Time_Green_8.png","Time_Green_9.png"],
              minute_zero: 1,
              minute_space: 3,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_hour.setProperty(hmUI.prop.MORE, {
              hour_startX: 256,
              hour_startY: 341,
              hour_array: ["Time_Green_0.png","Time_Green_1.png","Time_Green_2.png","Time_Green_3.png","Time_Green_4.png","Time_Green_5.png","Time_Green_6.png","Time_Green_7.png","Time_Green_8.png","Time_Green_9.png"],
              hour_zero: 1,
              hour_space: 3,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

const result = hmSetting.setScreenOff()

        }



        /////////////////////////////////////////////////////Five

        function UpdateBackgroundFive(){
normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.SRC, "Hand_H" + parseInt(backgroundnumber) + ".png");
normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.SRC, "Hand_M" + parseInt(backgroundnumber) + ".png");


 normal_image_img.setProperty(hmUI.prop.SRC, "colorBW.png");


normal_digital_clock_hour_separator_img.setProperty(hmUI.prop.SRC, "Time_BW_Dot.png");
normal_digital_clock_minute_separator_img.setProperty(hmUI.prop.SRC, "BW_Symbo.png");



            normal_heart_rate_pointer_progress_img_pointer.setProperty(hmUI.prop.MORE, {
              src: 'Pointer5.png',
              center_x: 240,
              center_y: 137,
              x: 29,
              y: 57,
              start_angle: 240,
              end_angle: 482,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });




           normal_date_img_date_week_img.setProperty(hmUI.prop.MORE, {
              x: 75,
              y: 179,
              week_en: ["Week_BW_1.png","Week_BW_2.png","Week_BW_3.png","Week_BW_4.png","Week_BW_5.png","Week_BW_6.png","Week_BW_7.png"],
              week_tc: ["Week_BW_1.png","Week_BW_2.png","Week_BW_3.png","Week_BW_4.png","Week_BW_5.png","Week_BW_6.png","Week_BW_7.png"],
              week_sc: ["Week_BW_1.png","Week_BW_2.png","Week_BW_3.png","Week_BW_4.png","Week_BW_5.png","Week_BW_6.png","Week_BW_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img.setProperty(hmUI.prop.MORE, {
              x: 283,
              y: 271,
              font_array: ["Act_BW_0.png","Act_BW_1.png","Act_BW_2.png","Act_BW_3.png","Act_BW_4.png","Act_BW_5.png","Act_BW_6.png","Act_BW_7.png","Act_BW_8.png","Act_BW_9.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            normal_digital_clock_img_time_second.setProperty(hmUI.prop.MORE, {
              second_startX: 0,
              second_startY: 0,
              second_array: ["BW_S_0.png","BW_S_1.png","BW_S_2.png","BW_S_3.png","BW_S_4.png","BW_S_5.png","0_Empty.png","0_Empty.png","0_Empty.png","0_Empty.png"],
              second_zero: 1,
              second_space: 222,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            normal_digital_clock_img_time_minute.setProperty(hmUI.prop.MORE, {
              minute_startX: 337,
              minute_startY: 341,
              minute_array: ["Time_BW_0.png","Time_BW_1.png","Time_BW_2.png","Time_BW_3.png","Time_BW_4.png","Time_BW_5.png","Time_BW_6.png","Time_BW_7.png","Time_BW_8.png","Time_BW_9.png"],
              minute_zero: 1,
              minute_space: 3,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_hour.setProperty(hmUI.prop.MORE, {
              hour_startX: 256,
              hour_startY: 341,
              hour_array: ["Time_BW_0.png","Time_BW_1.png","Time_BW_2.png","Time_BW_3.png","Time_BW_4.png","Time_BW_5.png","Time_BW_6.png","Time_BW_7.png","Time_BW_8.png","Time_BW_9.png"],
              hour_zero: 1,
              hour_space: 3,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

const result = hmSetting.setScreenOff()

        }
        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_moon_image_progress_img_level = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_week_img = ''
        let normal_heart_rate_pointer_progress_img_pointer = ''
        let normal_heart_rate_text_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_calorie_current_separator_img = ''
        let normal_distance_text_text_img = ''
        let normal_distance_text_separator_img = ''
        let normal_step_current_text_img = ''
        let normal_image_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time_second = ''
        let normal_digital_clock_img_time_minute = ''
        let normal_digital_clock_minute_separator_img = ''
        let normal_digital_clock_img_time_hour = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_analog_clock_pro_hour_pointer_img = ''
        let normal_analog_clock_pro_minute_pointer_img = ''
        let normal_timerUpdateSec = undefined;
        let normal_analog_clock_pro_second_pointer_img = ''
        let normal_timerUpdateSecSmooth = undefined;
        let idle_background_bg_img = ''
        let idle_system_clock_img = ''
        let idle_temperature_current_text_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_moon_image_progress_img_level = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_week_img = ''
        let idle_heart_rate_pointer_progress_img_pointer = ''
        let idle_heart_rate_text_text_img = ''
        let idle_step_current_text_img = ''
        let idle_image_img = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time_second = ''
        let idle_digital_clock_img_time_minute = ''
        let idle_digital_clock_minute_separator_img = ''
        let idle_digital_clock_img_time_hour = ''
        let idle_digital_clock_hour_separator_img = ''
        let idle_battery_text_text_img = ''
        let idle_battery_image_progress_img_level = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let timeSensor = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'main1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 178,
              y: 76,
              src: 'System_BT_OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 375,
              y: 372,
              src: 'System_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 330,
              y: 186,
              font_array: ["Bat_Font_0.png","Bat_Font_1.png","Bat_Font_2.png","Bat_Font_3.png","Bat_Font_4.png","Bat_Font_5.png","Bat_Font_6.png","Bat_Font_7.png","Bat_Font_8.png","Bat_Font_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'weather_symbo1.png',
              unit_tc: 'weather_symbo1.png',
              unit_en: 'weather_symbo1.png',
              negative_image: 'weather_symbo2.png',
              invalid_image: 'weather_symbo2.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 307,
              y: 191,
              image_array: ["weather_icon_01.png","weather_icon_02.png","weather_icon_03.png","weather_icon_04.png","weather_icon_05.png","weather_icon_06.png","weather_icon_07.png","weather_icon_08.png","weather_icon_09.png","weather_icon_10.png","weather_icon_11.png","weather_icon_12.png","weather_icon_13.png","weather_icon_14.png","weather_icon_15.png","weather_icon_16.png","weather_icon_17.png","weather_icon_18.png","weather_icon_19.png","weather_icon_20.png","weather_icon_21.png","weather_icon_22.png","weather_icon_23.png","weather_icon_24.png","weather_icon_25.png","weather_icon_26.png","weather_icon_27.png","weather_icon_28.png","weather_icon_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 224,
              y: 285,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 122,
              day_startY: 246,
              day_sc_array: ["Bat_Font_0.png","Bat_Font_1.png","Bat_Font_2.png","Bat_Font_3.png","Bat_Font_4.png","Bat_Font_5.png","Bat_Font_6.png","Bat_Font_7.png","Bat_Font_8.png","Bat_Font_9.png"],
              day_tc_array: ["Bat_Font_0.png","Bat_Font_1.png","Bat_Font_2.png","Bat_Font_3.png","Bat_Font_4.png","Bat_Font_5.png","Bat_Font_6.png","Bat_Font_7.png","Bat_Font_8.png","Bat_Font_9.png"],
              day_en_array: ["Bat_Font_0.png","Bat_Font_1.png","Bat_Font_2.png","Bat_Font_3.png","Bat_Font_4.png","Bat_Font_5.png","Bat_Font_6.png","Bat_Font_7.png","Bat_Font_8.png","Bat_Font_9.png"],
              day_zero: 0,
              day_space: 2,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 118,
              month_startY: 217,
              month_sc_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_tc_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_en_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 75,
              y: 179,
              week_en: ["Week_B_1.png","Week_B_2.png","Week_B_3.png","Week_B_4.png","Week_B_5.png","Week_B_6.png","Week_B_7.png"],
              week_tc: ["Week_B_1.png","Week_B_2.png","Week_B_3.png","Week_B_4.png","Week_B_5.png","Week_B_6.png","Week_B_7.png"],
              week_sc: ["Week_B_1.png","Week_B_2.png","Week_B_3.png","Week_B_4.png","Week_B_5.png","Week_B_6.png","Week_B_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'Pointer1.png',
              center_x: 240,
              center_y: 137,
              x: 29,
              y: 57,
              start_angle: 240,
              end_angle: 482,
              invalid_visible: false,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 210,
              y: 163,
              font_array: ["Bat_Font_0.png","Bat_Font_1.png","Bat_Font_2.png","Bat_Font_3.png","Bat_Font_4.png","Bat_Font_5.png","Bat_Font_6.png","Bat_Font_7.png","Bat_Font_8.png","Bat_Font_9.png"],
              padding: false,
              h_space: 0,
              invalid_image: 'Bat_Font_0.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 296,
              y: 271,
              font_array: ["Act_BW_0.png","Act_BW_1.png","Act_BW_2.png","Act_BW_3.png","Act_BW_4.png","Act_BW_5.png","Act_BW_6.png","Act_BW_7.png","Act_BW_8.png","Act_BW_9.png"],
              padding: false,
              h_space: 0,
              imperial_unit_sc: 'Dis_Mi.png',
              imperial_unit_tc: 'Dis_Mi.png',
              imperial_unit_en: 'Dis_Mi.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 294,
              y: 248,
              src: 'icon_CAL.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 284,
              y: 271,
              font_array: ["Act_BW_0.png","Act_BW_1.png","Act_BW_2.png","Act_BW_3.png","Act_BW_4.png","Act_BW_5.png","Act_BW_6.png","Act_BW_7.png","Act_BW_8.png","Act_BW_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Dis_KM.png',
              unit_tc: 'Dis_KM.png',
              unit_en: 'Dis_KM.png',
              imperial_unit_sc: 'Dis_Mi.png',
              imperial_unit_tc: 'Dis_Mi.png',
              imperial_unit_en: 'Dis_Mi.png',
              dot_image: 'Dis_dot.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 294,
              y: 248,
              src: 'icon_dis.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 283,
              y: 271,
              font_array: ["Act_B_0.png","Act_B_1.png","Act_B_2.png","Act_B_3.png","Act_B_4.png","Act_B_5.png","Act_B_6.png","Act_B_7.png","Act_B_8.png","Act_B_9.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'colorBlue.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 272,
              am_y: 315,
              am_sc_path: 'Clock_AM.png',
              am_en_path: 'Clock_AM.png',
              pm_x: 272,
              pm_y: 315,
              pm_sc_path: 'Clock_PM.png',
              pm_en_path: 'Clock_PM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_second = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              second_startX: 0,
              second_startY: 0,
              second_array: ["Blue_S_0.png","Blue_S_1.png","Blue_S_2.png","Blue_S_3.png","Blue_S_4.png","Blue_S_5.png","Blue_Symbo.png","BW_S_0.png","BW_S_1.png","BW_S_2.png"],
              second_zero: 1,
              second_space: 222,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 337,
              minute_startY: 341,
              minute_array: ["Time_Blue_0.png","Time_Blue_1.png","Time_Blue_2.png","Time_Blue_3.png","Time_Blue_4.png","Time_Blue_5.png","Time_Blue_6.png","Time_Blue_7.png","Time_Blue_8.png","Time_Blue_9.png"],
              minute_zero: 1,
              minute_space: 3,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_minute_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 257,
              y: 382,
              src: 'Blue_Symbo.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 256,
              hour_startY: 341,
              hour_array: ["Time_Blue_0.png","Time_Blue_1.png","Time_Blue_2.png","Time_Blue_3.png","Time_Blue_4.png","Time_Blue_5.png","Time_Blue_6.png","Time_Blue_7.png","Time_Blue_8.png","Time_Blue_9.png"],
              hour_zero: 1,
              hour_space: 3,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 326,
              y: 337,
              src: 'Time_Blue_Dot.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 253,
              y: 414,
              font_array: ["Bat_Font_0.png","Bat_Font_1.png","Bat_Font_2.png","Bat_Font_3.png","Bat_Font_4.png","Bat_Font_5.png","Bat_Font_6.png","Bat_Font_7.png","Bat_Font_8.png","Bat_Font_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Bat_Symbo1.png',
              unit_tc: 'Bat_Symbo1.png',
              unit_en: 'Bat_Symbo1.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 335,
              y: 382,
              image_array: ["Batt_icon_01.png","Batt_icon_02.png","Batt_icon_03.png","Batt_icon_04.png","Batt_icon_05.png","Batt_icon_06.png","Batt_icon_07.png"],
              image_length: 7,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('user_script.js');
            // start user_script.js
normal_digital_clock_img_time_second2 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              second_startX: -278,
              second_startY: 0,
              second_array: ["S_line_01.png","S_line_02.png","S_line_03.png","S_line_04.png","S_line_05.png","S_line_06.png","S_line_07.png","S_line_08.png","S_line_09.png","S_line_10.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            // end user_script.js

            const deviceInfo = hmSetting.getDeviceInfo();
            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.MINUTEEND, function() {
              let updateHour = timeSensor.minute == 0;

              time_update(updateHour, true);
            });

            // normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'Hand_H1.png',
              // center_x: 240,
              // center_y: 240,
              // x: 35,
              // y: 255,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.hour,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 35,
              pos_y: 240 - 255,
              center_x: 240,
              center_y: 240,
              src: 'Hand_H1.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            // normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'Hand_M1.png',
              // center_x: 240,
              // center_y: 240,
              // x: 35,
              // y: 274,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.minute,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 35,
              pos_y: 240 - 274,
              center_x: 240,
              center_y: 240,
              src: 'Hand_M1.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: '0_Empty.png',
              // center_x: 0,
              // center_y: 0,
              // x: 0,
              // y: 0,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 0 - 0,
              pos_y: 0 - 0,
              center_x: 0,
              center_y: 0,
              src: '0_Empty.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_smooth_second = hmUI.createWidget(hmUI.widget.SMOOTH_SECOND, {
              // type: 2,
              // fps: 15,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });



            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'main1.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 375,
              y: 372,
              src: 'System_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 330,
              y: 186,
              font_array: ["Bat_Font_0.png","Bat_Font_1.png","Bat_Font_2.png","Bat_Font_3.png","Bat_Font_4.png","Bat_Font_5.png","Bat_Font_6.png","Bat_Font_7.png","Bat_Font_8.png","Bat_Font_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'weather_symbo1.png',
              unit_tc: 'weather_symbo1.png',
              unit_en: 'weather_symbo1.png',
              negative_image: 'weather_symbo2.png',
              invalid_image: 'weather_symbo2.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 307,
              y: 191,
              image_array: ["weather_icon_01.png","weather_icon_02.png","weather_icon_03.png","weather_icon_04.png","weather_icon_05.png","weather_icon_06.png","weather_icon_07.png","weather_icon_08.png","weather_icon_09.png","weather_icon_10.png","weather_icon_11.png","weather_icon_12.png","weather_icon_13.png","weather_icon_14.png","weather_icon_15.png","weather_icon_16.png","weather_icon_17.png","weather_icon_18.png","weather_icon_19.png","weather_icon_20.png","weather_icon_21.png","weather_icon_22.png","weather_icon_23.png","weather_icon_24.png","weather_icon_25.png","weather_icon_26.png","weather_icon_27.png","weather_icon_28.png","weather_icon_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 224,
              y: 285,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 122,
              day_startY: 246,
              day_sc_array: ["Bat_Font_0.png","Bat_Font_1.png","Bat_Font_2.png","Bat_Font_3.png","Bat_Font_4.png","Bat_Font_5.png","Bat_Font_6.png","Bat_Font_7.png","Bat_Font_8.png","Bat_Font_9.png"],
              day_tc_array: ["Bat_Font_0.png","Bat_Font_1.png","Bat_Font_2.png","Bat_Font_3.png","Bat_Font_4.png","Bat_Font_5.png","Bat_Font_6.png","Bat_Font_7.png","Bat_Font_8.png","Bat_Font_9.png"],
              day_en_array: ["Bat_Font_0.png","Bat_Font_1.png","Bat_Font_2.png","Bat_Font_3.png","Bat_Font_4.png","Bat_Font_5.png","Bat_Font_6.png","Bat_Font_7.png","Bat_Font_8.png","Bat_Font_9.png"],
              day_zero: 0,
              day_space: 2,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 118,
              month_startY: 217,
              month_sc_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_tc_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_en_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 75,
              y: 179,
              week_en: ["Week_BW_1.png","Week_BW_2.png","Week_BW_3.png","Week_BW_4.png","Week_BW_5.png","Week_BW_6.png","Week_BW_7.png"],
              week_tc: ["Week_BW_1.png","Week_BW_2.png","Week_BW_3.png","Week_BW_4.png","Week_BW_5.png","Week_BW_6.png","Week_BW_7.png"],
              week_sc: ["Week_BW_1.png","Week_BW_2.png","Week_BW_3.png","Week_BW_4.png","Week_BW_5.png","Week_BW_6.png","Week_BW_7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'Pointer5.png',
              center_x: 240,
              center_y: 137,
              x: 29,
              y: 57,
              start_angle: 240,
              end_angle: 482,
              invalid_visible: false,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 210,
              y: 163,
              font_array: ["Bat_Font_0.png","Bat_Font_1.png","Bat_Font_2.png","Bat_Font_3.png","Bat_Font_4.png","Bat_Font_5.png","Bat_Font_6.png","Bat_Font_7.png","Bat_Font_8.png","Bat_Font_9.png"],
              padding: false,
              h_space: 0,
              invalid_image: 'Bat_Font_0.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 283,
              y: 271,
              font_array: ["Act_BW_0.png","Act_BW_1.png","Act_BW_2.png","Act_BW_3.png","Act_BW_4.png","Act_BW_5.png","Act_BW_6.png","Act_BW_7.png","Act_BW_8.png","Act_BW_9.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'colorBW.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 272,
              am_y: 315,
              am_sc_path: 'Clock_AM.png',
              am_en_path: 'Clock_AM.png',
              pm_x: 272,
              pm_y: 315,
              pm_sc_path: 'Clock_PM.png',
              pm_en_path: 'Clock_PM.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_second = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              second_startX: 0,
              second_startY: 0,
              second_array: ["BW_S_0.png","BW_S_1.png","BW_S_2.png","BW_S_3.png","BW_S_4.png","BW_S_5.png","BW_Symbo.png","Clock_AM.png","Clock_PM.png","colorBlue.png"],
              second_zero: 1,
              second_space: 222,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 337,
              minute_startY: 341,
              minute_array: ["Time_BW_0.png","Time_BW_1.png","Time_BW_2.png","Time_BW_3.png","Time_BW_4.png","Time_BW_5.png","Time_BW_6.png","Time_BW_7.png","Time_BW_8.png","Time_BW_9.png"],
              minute_zero: 1,
              minute_space: 3,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_minute_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 257,
              y: 382,
              src: 'BW_Symbo.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 256,
              hour_startY: 341,
              hour_array: ["Time_BW_0.png","Time_BW_1.png","Time_BW_2.png","Time_BW_3.png","Time_BW_4.png","Time_BW_5.png","Time_BW_6.png","Time_BW_7.png","Time_BW_8.png","Time_BW_9.png"],
              hour_zero: 1,
              hour_space: 3,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 326,
              y: 337,
              src: 'Time_BW_Dot.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 253,
              y: 414,
              font_array: ["Bat_Font_0.png","Bat_Font_1.png","Bat_Font_2.png","Bat_Font_3.png","Bat_Font_4.png","Bat_Font_5.png","Bat_Font_6.png","Bat_Font_7.png","Bat_Font_8.png","Bat_Font_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Bat_Symbo1.png',
              unit_tc: 'Bat_Symbo1.png',
              unit_en: 'Bat_Symbo1.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 335,
              y: 382,
              image_array: ["Batt_icon_01.png","Batt_icon_02.png","Batt_icon_03.png","Batt_icon_04.png","Batt_icon_05.png","Batt_icon_06.png","Batt_icon_07.png"],
              image_length: 7,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            console.log('user_script_beforeShortcuts.js');
            // start user_script_beforeShortcuts.js

idle_digital_clock_img_time_second2 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
               second_startX: -278,
              second_startY: 0,
              second_array: ["S_line_01.png","S_line_02.png","S_line_03.png","S_line_04.png","S_line_05.png","S_line_06.png","S_line_07.png","S_line_08.png","S_line_09.png","S_line_10.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            // end user_script_beforeShortcuts.js
            console.log('Watch_Face.Shortcuts');

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 336,
              y: 340,
              w: 35,
              h: 29,
              src: '0_Empty.png',
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 258,
              y: 341,
              w: 32,
              h: 29,
              src: '0_Empty.png',
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 375,
              y: 374,
              w: 59,
              h: 95,
              src: '0_Empty.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 222,
              y: 283,
              w: 35,
              h: 38,
              src: '0_Empty.png',
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 311,
              y: 179,
              w: 78,
              h: 41,
              src: '0_Empty.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 214,
              y: 87,
              w: 55,
              h: 38,
              src: '0_Empty.png',
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 209,
              y: 159,
              w: 67,
              h: 35,
              src: '0_Empty.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 286,
              y: 270,
              w: 98,
              h: 29,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 160,
              y: 364,
              w: 77,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'SportListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 101,
              y: 326,
              w: 47,
              h: 53,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                //color
                click_Background()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 213,
              y: 216,
              w: 54,
              h: 53,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                //hand
                click_elemente()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 256,
              y: 387,
              w: 67,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PowerSaveHintScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 105,
              y: 201,
              w: 72,
              h: 78,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 285,
              y: 233,
              w: 103,
              h: 31,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                //activity
click_elemente2()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            console.log('user_script_end.js');
            // start user_script_end.js

let cc=0
if ( cc == 0 ) {
UpdateElemente2One()
cc = 1
}

            // end user_script_end.js

            //start of ignored block
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              if (updateHour) {
                let normal_hour = hour;
                let normal_fullAngle_hour = 360;
                if (normal_hour > 11) normal_hour -= 12;
                let normal_angle_hour = 0 + normal_fullAngle_hour*normal_hour/12 + (normal_fullAngle_hour/12)*minute/60;
                if (normal_analog_clock_pro_hour_pointer_img) normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_hour);
              };

              if (updateMinute) {
                let normal_fullAngle_minute = 360;
                let normal_angle_minute = 0 + normal_fullAngle_minute*(minute + second/60)/60;
                if (normal_analog_clock_pro_minute_pointer_img) normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_minute);
              };

              let normal_fullAngle_second = 360;
              let normal_angle_second = 0 + normal_fullAngle_second*(second + (timeSensor.utc % 1000)/1000)/60;
              if (normal_analog_clock_pro_second_pointer_img) normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_second);

            };

            //end of ignored block
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                time_update(true, true);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSec) {
                    let animDelay = timeSensor.utc % 1000;
                    let animRepeat = 1000;
                    normal_timerUpdateSec = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, true);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSecSmooth) {
                    let animDelay = 0;
                    let animRepeat = 1000/15;
                    normal_timerUpdateSecSmooth = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, false);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerUpdateSec) {
                  timer.stopTimer(normal_timerUpdateSec);
                  normal_timerUpdateSec = undefined;
                }
                if (normal_timerUpdateSecSmooth) {
                  timer.stopTimer(normal_timerUpdateSecSmooth);
                  normal_timerUpdateSecSmooth = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
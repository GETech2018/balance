﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_battery_icon_img = ''
        let normal_battery_TextCircle = new Array(3);
        let normal_battery_TextCircle_ASCIIARRAY = new Array(10);
        let normal_battery_TextCircle_img_width = 14;
        let normal_battery_TextCircle_img_height = 24;
        let normal_battery_TextCircle_unit = null;
        let normal_battery_TextCircle_unit_width = 20;
        let normal_battery_TextCircle_error_img_width = 22;
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_TextCircle = new Array(3);
        let normal_heart_rate_TextCircle_ASCIIARRAY = new Array(10);
        let normal_heart_rate_TextCircle_img_width = 14;
        let normal_heart_rate_TextCircle_img_height = 24;
        let normal_heart_rate_TextCircle_error_img_width = 22;
        let normal_date_img_date_day = ''
        let normal_step_current_text_img = ''
        let normal_analog_clock_pro_hour_pointer_img = ''
        let normal_analog_clock_pro_minute_pointer_img = ''
        let normal_timerUpdateSec = undefined;
        let normal_analog_clock_pro_second_pointer_img = ''
        let normal_timerUpdateSecSmooth = undefined;
        let lastTime = 0;
        let normal_analog_clock_pro_second_cover_pointer_img = ''
        let normal_image_img = ''
        let normal_motion_animation_img_1 = '';
        let normal_motion_animation_paramX_1 = null;
        let normal_motion_animation_paramY_1 = null;
        let normal_motion_animation_lastTime_1 = 0;
        let timer_anim_motion_1;
        let timer_anim_motion_1_mirror = false;
        let normal_motion_animation_paramX_1_mirror = null;
        let normal_motion_animation_paramY_1_mirror = null;
        let normal_motion_animation_count_1 = 0;
        let normal_motion_animation_img_2 = '';
        let normal_motion_animation_paramX_2 = null;
        let normal_motion_animation_paramY_2 = null;
        let normal_motion_animation_lastTime_2 = 0;
        let timer_anim_motion_2;
        let timer_anim_motion_2_mirror = false;
        let normal_motion_animation_paramX_2_mirror = null;
        let normal_motion_animation_paramY_2_mirror = null;
        let normal_motion_animation_count_2 = 0;
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let idle_background_bg_img = ''
        let idle_battery_icon_img = ''
        let idle_battery_TextCircle = new Array(3);
        let idle_battery_TextCircle_ASCIIARRAY = new Array(10);
        let idle_battery_TextCircle_img_width = 14;
        let idle_battery_TextCircle_img_height = 24;
        let idle_battery_TextCircle_unit = null;
        let idle_battery_TextCircle_unit_width = 20;
        let idle_battery_TextCircle_error_img_width = 22;
        let idle_heart_rate_icon_img = ''
        let idle_heart_rate_TextCircle = new Array(3);
        let idle_heart_rate_TextCircle_ASCIIARRAY = new Array(10);
        let idle_heart_rate_TextCircle_img_width = 14;
        let idle_heart_rate_TextCircle_img_height = 24;
        let idle_heart_rate_TextCircle_error_img_width = 22;
        let idle_date_img_date_day = ''
        let idle_step_current_text_img = ''
        let idle_analog_clock_pro_hour_pointer_img = ''
        let idle_analog_clock_pro_minute_pointer_img = ''
        let idle_analog_clock_pro_minute_cover_pointer_img = ''
        let idle_image_img = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let Button_7 = ''
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 394,
              y: 368,
              src: '2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_battery_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 240,
              // circle_center_Y: 240,
              // font_array: ["bat_00.png","bat_01.png","bat_02.png","bat_03.png","bat_04.png","bat_05.png","bat_06.png","bat_07.png","bat_08.png","bat_09.png"],
              // radius: 234,
              // angle: 122,
              // char_space_angle: 0,
              // unit: 'bat_10.png',
              // error_image: 'bat_11.png',
              // zero: false,
              // reverse_direction: true,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: LEFT,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_battery_TextCircle_ASCIIARRAY[0] = 'bat_00.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[1] = 'bat_01.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[2] = 'bat_02.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[3] = 'bat_03.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[4] = 'bat_04.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[5] = 'bat_05.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[6] = 'bat_06.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[7] = 'bat_07.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[8] = 'bat_08.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[9] = 'bat_09.png';  // set of images with numbers

            //#region TextCircle
            for (let i = 0; i < 3; i++) {
              normal_battery_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 240,
                center_y: 240,
                pos_x: 240 - normal_battery_TextCircle_img_width / 2,
                pos_y: 240 + 210,
                src: 'bat_00.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_battery_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_battery_TextCircle_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              center_x: 240,
              center_y: 240,
              pos_x: 240 - normal_battery_TextCircle_unit_width / 2,
              pos_y: 240 + 210,
              src: 'bat_10.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_battery_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
            //#endregion
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });
            
            function toDegree (radian) {
              return radian * (180 / Math.PI);
            };

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 314,
              y: 430,
              src: '1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_heart_rate_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 240,
              // circle_center_Y: 240,
              // font_array: ["bat_00.png","bat_01.png","bat_02.png","bat_03.png","bat_04.png","bat_05.png","bat_06.png","bat_07.png","bat_08.png","bat_09.png"],
              // radius: 234,
              // angle: 150,
              // char_space_angle: 0,
              // error_image: 'bat_11.png',
              // zero: false,
              // reverse_direction: true,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: LEFT,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_heart_rate_TextCircle_ASCIIARRAY[0] = 'bat_00.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[1] = 'bat_01.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[2] = 'bat_02.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[3] = 'bat_03.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[4] = 'bat_04.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[5] = 'bat_05.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[6] = 'bat_06.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[7] = 'bat_07.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[8] = 'bat_08.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[9] = 'bat_09.png';  // set of images with numbers

            //#region TextCircle
            for (let i = 0; i < 3; i++) {
              normal_heart_rate_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 240,
                center_y: 240,
                pos_x: 240 - normal_heart_rate_TextCircle_img_width / 2,
                pos_y: 240 + 210,
                src: 'bat_00.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_heart_rate_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //#endregion
            
            const heart_rate = hmSensor.createSensor(hmSensor.id.HEART);
            heart_rate.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 332,
              day_startY: 316,
              day_sc_array: ["data_w_00.png","data_w_01.png","data_w_02.png","data_w_03.png","data_w_04.png","data_w_05.png","data_w_06.png","data_w_07.png","data_w_08.png","data_w_09.png"],
              day_tc_array: ["data_w_00.png","data_w_01.png","data_w_02.png","data_w_03.png","data_w_04.png","data_w_05.png","data_w_06.png","data_w_07.png","data_w_08.png","data_w_09.png"],
              day_en_array: ["data_w_00.png","data_w_01.png","data_w_02.png","data_w_03.png","data_w_04.png","data_w_05.png","data_w_06.png","data_w_07.png","data_w_08.png","data_w_09.png"],
              day_zero: 1,
              day_space: -3,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 186,
              y: 430,
              font_array: ["data_00.png","data_01.png","data_02.png","data_03.png","data_04.png","data_05.png","data_06.png","data_07.png","data_08.png","data_09.png"],
              padding: false,
              h_space: -3,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const deviceInfo = hmSetting.getDeviceInfo();
            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.MINUTEEND, function() {
              let updateHour = timeSensor.minute == 0;

              time_update(updateHour, true);
            });

            // normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'h.png',
              // center_x: 240,
              // center_y: 240,
              // x: 40,
              // y: 238,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.hour,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 40,
              pos_y: 240 - 238,
              center_x: 240,
              center_y: 240,
              src: 'h.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            // normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'm.png',
              // center_x: 240,
              // center_y: 240,
              // x: 40,
              // y: 247,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.minute,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 40,
              pos_y: 240 - 247,
              center_x: 240,
              center_y: 240,
              src: 'm.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 's.png',
              // center_x: 240,
              // center_y: 240,
              // x: 40,
              // y: 243,
              // start_angle: 0,
              // end_angle: 360,
              // cover_path: 'top2.png',
              // cover_x: 0,
              // cover_y: 0,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 40,
              pos_y: 240 - 243,
              center_x: 240,
              center_y: 240,
              src: 's.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            function startSecAnim(sec, animDuration) {
              const secAnim = {
                anim_steps: [{
                  anim_rate: 'linear',
                  anim_duration: animDuration,
                  anim_from: sec,
                  anim_to: sec + (360*(animDuration*6/1000))/360,
                  anim_key: 'angle',
                }],
                anim_fps: 17,
                anim_auto_start: 1,
                anim_repeat: 0,
                anim_auto_destroy: 1,
              }
              normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANIM, secAnim);
            }
            normal_analog_clock_pro_second_cover_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'top2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_smooth_second = hmUI.createWidget(hmUI.widget.SMOOTH_SECOND, {
              // type: 4,
              // fps: 17,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'top1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_motion_animation_img_1 = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 479,
              h: 479,
              pos_x: 125,
              pos_y: 173,
              src: 'animation/eye.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_motion_animation_paramX_1 = {
              anim_steps: [{
                anim_rate: 'linear',
                anim_duration: 2000,
                anim_from: 125,
                anim_to: 145,
                anim_key: "pos_x",
              }],
              anim_fps: 30,
              anim_auto_start: 1,
              anim_repeat: 0,
              anim_auto_destroy: 1,
            };

            normal_motion_animation_paramY_1 = {
              anim_steps: [{
                anim_rate: 'linear',
                anim_duration: 2000,
                anim_from: 173,
                anim_to: 190,
                anim_key: "pos_y",
              }],
              anim_fps: 30,
              anim_auto_start: 1,
              anim_repeat: 0,
              anim_auto_destroy: 1,
            };

            let now = hmSensor.createSensor(hmSensor.id.TIME);

            normal_motion_animation_paramX_1_mirror = {
              anim_steps: [{
                anim_rate: 'linear',
                anim_duration: 2000,
                anim_from: 145,
                anim_to: 125,
                anim_key: "pos_x",
              }],
              anim_fps: 30,
              anim_auto_start: 1,
              anim_repeat: 0,
              anim_auto_destroy: 1,
            };

            normal_motion_animation_paramY_1_mirror = {
              anim_steps: [{
                anim_rate: 'linear',
                anim_duration: 2000,
                anim_from: 190,
                anim_to: 173,
                anim_key: "pos_y",
              }],
              anim_fps: 30,
              anim_auto_start: 1,
              anim_repeat: 0,
              anim_auto_destroy: 1,
            };

            function anim_motion_1_mirror() {
              normal_motion_animation_img_1.setProperty(hmUI.prop.ANIM, normal_motion_animation_paramX_1_mirror);
              normal_motion_animation_img_1.setProperty(hmUI.prop.ANIM, normal_motion_animation_paramY_1_mirror);
              normal_motion_animation_lastTime_1 = now.utc;
              normal_motion_animation_count_1 = normal_motion_animation_count_1 - 1;
              if(normal_motion_animation_count_1 < -1) normal_motion_animation_count_1 = - 1;
              if(normal_motion_animation_count_1 == 0) stop_anim_motion_1();
            }; // end animation_mirror callback function

            function anim_motion_1_complete_call() {
              normal_motion_animation_img_1.setProperty(hmUI.prop.ANIM, normal_motion_animation_paramX_1);
              normal_motion_animation_img_1.setProperty(hmUI.prop.ANIM, normal_motion_animation_paramY_1);
                normal_motion_animation_lastTime_1 = now.utc;
            }; // end animation callback function
            
            function stop_anim_motion_1() {
              if (timer_anim_motion_1) {
                timer.stopTimer(timer_anim_motion_1);
                timer_anim_motion_1 = undefined;
              };
            }; // end stop_anim_motion function

            // normal_motion_anime_1 = hmUI.createWidget(hmUI.widget.Motion_Animation, {
              // x_start: 125,
              // y_start: 173,
              // x_end: 145,
              // y_end: 190,
              // src: 'eye.png',
              // anim_fps: 30,
              // anim_duration: 2000,
              // repeat_count: 0,
              // anim_two_sides: True,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_motion_animation_img_2 = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 479,
              h: 479,
              pos_x: 246,
              pos_y: 153,
              src: 'animation/eye.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_motion_animation_paramX_2 = {
              anim_steps: [{
                anim_rate: 'linear',
                anim_duration: 2000,
                anim_from: 246,
                anim_to: 265,
                anim_key: "pos_x",
              }],
              anim_fps: 30,
              anim_auto_start: 1,
              anim_repeat: 0,
              anim_auto_destroy: 1,
            };

            normal_motion_animation_paramY_2 = {
              anim_steps: [{
                anim_rate: 'linear',
                anim_duration: 2000,
                anim_from: 153,
                anim_to: 170,
                anim_key: "pos_y",
              }],
              anim_fps: 30,
              anim_auto_start: 1,
              anim_repeat: 0,
              anim_auto_destroy: 1,
            };

            normal_motion_animation_paramX_2_mirror = {
              anim_steps: [{
                anim_rate: 'linear',
                anim_duration: 2000,
                anim_from: 265,
                anim_to: 246,
                anim_key: "pos_x",
              }],
              anim_fps: 30,
              anim_auto_start: 1,
              anim_repeat: 0,
              anim_auto_destroy: 1,
            };

            normal_motion_animation_paramY_2_mirror = {
              anim_steps: [{
                anim_rate: 'linear',
                anim_duration: 2000,
                anim_from: 170,
                anim_to: 153,
                anim_key: "pos_y",
              }],
              anim_fps: 30,
              anim_auto_start: 1,
              anim_repeat: 0,
              anim_auto_destroy: 1,
            };

            function anim_motion_2_mirror() {
              normal_motion_animation_img_2.setProperty(hmUI.prop.ANIM, normal_motion_animation_paramX_2_mirror);
              normal_motion_animation_img_2.setProperty(hmUI.prop.ANIM, normal_motion_animation_paramY_2_mirror);
              normal_motion_animation_lastTime_2 = now.utc;
              normal_motion_animation_count_2 = normal_motion_animation_count_2 - 1;
              if(normal_motion_animation_count_2 < -1) normal_motion_animation_count_2 = - 1;
              if(normal_motion_animation_count_2 == 0) stop_anim_motion_2();
            }; // end animation_mirror callback function

            function anim_motion_2_complete_call() {
              normal_motion_animation_img_2.setProperty(hmUI.prop.ANIM, normal_motion_animation_paramX_2);
              normal_motion_animation_img_2.setProperty(hmUI.prop.ANIM, normal_motion_animation_paramY_2);
                normal_motion_animation_lastTime_2 = now.utc;
            }; // end animation callback function
            
            function stop_anim_motion_2() {
              if (timer_anim_motion_2) {
                timer.stopTimer(timer_anim_motion_2);
                timer_anim_motion_2 = undefined;
              };
            }; // end stop_anim_motion function

            // normal_motion_anime_2 = hmUI.createWidget(hmUI.widget.Motion_Animation, {
              // x_start: 246,
              // y_start: 153,
              // x_end: 265,
              // y_end: 170,
              // src: 'eye.png',
              // anim_fps: 30,
              // anim_duration: 2000,
              // repeat_count: 0,
              // anim_two_sides: True,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 221,
              y: 207,
              src: 'bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 213,
              y: 316,
              src: 'alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg_aod.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 392,
              y: 371,
              src: '2.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_battery_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 240,
              // circle_center_Y: 240,
              // font_array: ["aod_bat_00.png","aod_bat_01.png","aod_bat_02.png","aod_bat_03.png","aod_bat_04.png","aod_bat_05.png","aod_bat_06.png","aod_bat_07.png","aod_bat_08.png","aod_bat_09.png"],
              // radius: 234,
              // angle: 123,
              // char_space_angle: 0,
              // unit: 'aod_bat_10.png',
              // error_image: 'aod_bat_11.png',
              // zero: false,
              // reverse_direction: true,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: LEFT,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_battery_TextCircle_ASCIIARRAY[0] = 'aod_bat_00.png';  // set of images with numbers
            idle_battery_TextCircle_ASCIIARRAY[1] = 'aod_bat_01.png';  // set of images with numbers
            idle_battery_TextCircle_ASCIIARRAY[2] = 'aod_bat_02.png';  // set of images with numbers
            idle_battery_TextCircle_ASCIIARRAY[3] = 'aod_bat_03.png';  // set of images with numbers
            idle_battery_TextCircle_ASCIIARRAY[4] = 'aod_bat_04.png';  // set of images with numbers
            idle_battery_TextCircle_ASCIIARRAY[5] = 'aod_bat_05.png';  // set of images with numbers
            idle_battery_TextCircle_ASCIIARRAY[6] = 'aod_bat_06.png';  // set of images with numbers
            idle_battery_TextCircle_ASCIIARRAY[7] = 'aod_bat_07.png';  // set of images with numbers
            idle_battery_TextCircle_ASCIIARRAY[8] = 'aod_bat_08.png';  // set of images with numbers
            idle_battery_TextCircle_ASCIIARRAY[9] = 'aod_bat_09.png';  // set of images with numbers

            //#region TextCircle
            for (let i = 0; i < 3; i++) {
              idle_battery_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 240,
                center_y: 240,
                pos_x: 240 - idle_battery_TextCircle_img_width / 2,
                pos_y: 240 + 210,
                src: 'aod_bat_00.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_battery_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            idle_battery_TextCircle_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              center_x: 240,
              center_y: 240,
              pos_x: 240 - idle_battery_TextCircle_unit_width / 2,
              pos_y: 240 + 210,
              src: 'aod_bat_10.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            idle_battery_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
            //#endregion

            idle_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 314,
              y: 430,
              src: '1.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_heart_rate_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 240,
              // circle_center_Y: 240,
              // font_array: ["aod_bat_00.png","aod_bat_01.png","aod_bat_02.png","aod_bat_03.png","aod_bat_04.png","aod_bat_05.png","aod_bat_06.png","aod_bat_07.png","aod_bat_08.png","aod_bat_09.png"],
              // radius: 234,
              // angle: 150,
              // char_space_angle: 0,
              // error_image: 'aod_bat_11.png',
              // zero: false,
              // reverse_direction: true,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: LEFT,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_heart_rate_TextCircle_ASCIIARRAY[0] = 'aod_bat_00.png';  // set of images with numbers
            idle_heart_rate_TextCircle_ASCIIARRAY[1] = 'aod_bat_01.png';  // set of images with numbers
            idle_heart_rate_TextCircle_ASCIIARRAY[2] = 'aod_bat_02.png';  // set of images with numbers
            idle_heart_rate_TextCircle_ASCIIARRAY[3] = 'aod_bat_03.png';  // set of images with numbers
            idle_heart_rate_TextCircle_ASCIIARRAY[4] = 'aod_bat_04.png';  // set of images with numbers
            idle_heart_rate_TextCircle_ASCIIARRAY[5] = 'aod_bat_05.png';  // set of images with numbers
            idle_heart_rate_TextCircle_ASCIIARRAY[6] = 'aod_bat_06.png';  // set of images with numbers
            idle_heart_rate_TextCircle_ASCIIARRAY[7] = 'aod_bat_07.png';  // set of images with numbers
            idle_heart_rate_TextCircle_ASCIIARRAY[8] = 'aod_bat_08.png';  // set of images with numbers
            idle_heart_rate_TextCircle_ASCIIARRAY[9] = 'aod_bat_09.png';  // set of images with numbers

            //#region TextCircle
            for (let i = 0; i < 3; i++) {
              idle_heart_rate_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 240,
                center_y: 240,
                pos_x: 240 - idle_heart_rate_TextCircle_img_width / 2,
                pos_y: 240 + 210,
                src: 'aod_bat_00.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_heart_rate_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //#endregion

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 332,
              day_startY: 316,
              day_sc_array: ["data_w_00.png","data_w_01.png","data_w_02.png","data_w_03.png","data_w_04.png","data_w_05.png","data_w_06.png","data_w_07.png","data_w_08.png","data_w_09.png"],
              day_tc_array: ["data_w_00.png","data_w_01.png","data_w_02.png","data_w_03.png","data_w_04.png","data_w_05.png","data_w_06.png","data_w_07.png","data_w_08.png","data_w_09.png"],
              day_en_array: ["data_w_00.png","data_w_01.png","data_w_02.png","data_w_03.png","data_w_04.png","data_w_05.png","data_w_06.png","data_w_07.png","data_w_08.png","data_w_09.png"],
              day_zero: 1,
              day_space: -3,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 186,
              y: 430,
              font_array: ["data_w_00.png","data_w_01.png","data_w_02.png","data_w_03.png","data_w_04.png","data_w_05.png","data_w_06.png","data_w_07.png","data_w_08.png","data_w_09.png"],
              padding: false,
              h_space: -3,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'h.png',
              // center_x: 240,
              // center_y: 240,
              // x: 40,
              // y: 238,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.hour,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });


            idle_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 40,
              pos_y: 240 - 238,
              center_x: 240,
              center_y: 240,
              src: 'h.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'm.png',
              // center_x: 240,
              // center_y: 240,
              // x: 40,
              // y: 247,
              // start_angle: 0,
              // end_angle: 360,
              // cover_path: 'top3.png',
              // cover_x: 0,
              // cover_y: 0,
              // type: hmUI.data_type.minute,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });


            idle_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 40,
              pos_y: 240 - 247,
              center_x: 240,
              center_y: 240,
              src: 'm.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_pro_minute_cover_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'top3.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'top4.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 132,
              y: 176,
              w: 80,
              h: 80,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'null.png',
              normal_src: 'null.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'CountdownAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 253,
              y: 157,
              w: 80,
              h: 80,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'null.png',
              normal_src: 'null.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'StopWatchScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 318,
              y: 298,
              w: 70,
              h: 70,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'null.png',
              normal_src: 'null.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 389,
              y: 315,
              w: 76,
              h: 70,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'null.png',
              normal_src: 'null.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'Settings_batteryManagerScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 310,
              y: 389,
              w: 78,
              h: 70,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'null.png',
              normal_src: 'null.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'heart_app_Screen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 190,
              y: 392,
              w: 100,
              h: 80,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'null.png',
              normal_src: 'null.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'activityAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_7 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 200,
              y: 294,
              w: 100,
              h: 70,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'null.png',
              normal_src: 'null.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'AlarmInfoScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            //#region time_update
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              if (updateMinute) {
                let normal_hour = hour;
                let normal_fullAngle_hour = 360;
                if (normal_hour > 11) normal_hour -= 12;
                let normal_angle_hour = 0 + normal_fullAngle_hour*normal_hour/12 + (normal_fullAngle_hour/12)*minute/60;
                if (normal_analog_clock_pro_hour_pointer_img) normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_hour);
              };

                let normal_fullAngle_minute = 360;
                let normal_angle_minute = 0 + normal_fullAngle_minute*(minute + second/60)/60;
                if (normal_analog_clock_pro_minute_pointer_img) normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_minute);
              if (updateMinute) {
                let idle_hour = hour;
                let idle_fullAngle_hour = 360;
                if (idle_hour > 11) idle_hour -= 12;
                let idle_angle_hour = 0 + idle_fullAngle_hour*idle_hour/12 + (idle_fullAngle_hour/12)*minute/60;
                if (idle_analog_clock_pro_hour_pointer_img) idle_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.ANGLE, idle_angle_hour);
              };

              if (updateMinute) {
                let idle_fullAngle_minute = 360;
                let idle_angle_minute = 0 + idle_fullAngle_minute*minute/60;
                if (idle_analog_clock_pro_minute_pointer_img) idle_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.ANGLE, idle_angle_minute);
              };

            };

            //#endregion
            //#region text_update
            function text_update() {
              console.log('text_update()');

              console.log('update text circle battery_BATTERY');
              let valueBattery = battery.current;
              let normal_battery_circle_string = parseInt(valueBattery).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  normal_battery_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_battery_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
                let char_Angle = 302;
                if (valueBattery != null && valueBattery != undefined && isFinite(valueBattery) && normal_battery_circle_string.length > 0 && normal_battery_circle_string.length <= 3) {  // display data if it was possible to get it
                  let normal_battery_TextCircle_img_angle = 0;
                  let normal_battery_TextCircle_dot_img_angle = 0;
                  let normal_battery_TextCircle_unit_angle = 0;
                  normal_battery_TextCircle_img_angle = toDegree(Math.atan2(normal_battery_TextCircle_img_width/2, 234));
                  normal_battery_TextCircle_unit_angle = toDegree(Math.atan2(normal_battery_TextCircle_unit_width/2, 234));
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_battery_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= normal_battery_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_battery_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_battery_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - normal_battery_TextCircle_img_width / 2);
                      normal_battery_TextCircle[index].setProperty(hmUI.prop.SRC, normal_battery_TextCircle_ASCIIARRAY[charCode]);
                      normal_battery_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= normal_battery_TextCircle_img_angle;
                      index++;
                    };  // end if digit
                  };  // end char of string
                  char_Angle -= normal_battery_TextCircle_unit_angle;
                  normal_battery_TextCircle_unit.setProperty(hmUI.prop.ANGLE, char_Angle);
                  normal_battery_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite
                else {
                  normal_battery_TextCircle[0].setProperty(hmUI.prop.ANGLE, char_Angle);
                  normal_battery_TextCircle[0].setProperty(hmUI.prop.POS_X, 240 - normal_battery_TextCircle_error_img_width / 2);
                  normal_battery_TextCircle[0].setProperty(hmUI.prop.SRC, 'bat_11.png');
                  normal_battery_TextCircle[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

              console.log('update text circle heart_rate_HEART');
              let valueHeartRate = heart_rate.last;
              let normal_heart_rate_circle_string = parseInt(valueHeartRate).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  normal_heart_rate_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = 330;
                if (valueHeartRate != null && valueHeartRate != undefined && isFinite(valueHeartRate) && normal_heart_rate_circle_string.length > 0 && normal_heart_rate_circle_string.length <= 3) {  // display data if it was possible to get it
                  let normal_heart_rate_TextCircle_img_angle = 0;
                  let normal_heart_rate_TextCircle_dot_img_angle = 0;
                  normal_heart_rate_TextCircle_img_angle = toDegree(Math.atan2(normal_heart_rate_TextCircle_img_width/2, 234));
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_heart_rate_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= normal_heart_rate_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_heart_rate_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_heart_rate_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - normal_heart_rate_TextCircle_img_width / 2);
                      normal_heart_rate_TextCircle[index].setProperty(hmUI.prop.SRC, normal_heart_rate_TextCircle_ASCIIARRAY[charCode]);
                      normal_heart_rate_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= normal_heart_rate_TextCircle_img_angle;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite
                else {
                  normal_heart_rate_TextCircle[0].setProperty(hmUI.prop.ANGLE, char_Angle);
                  normal_heart_rate_TextCircle[0].setProperty(hmUI.prop.POS_X, 240 - normal_heart_rate_TextCircle_error_img_width / 2);
                  normal_heart_rate_TextCircle[0].setProperty(hmUI.prop.SRC, 'bat_11.png');
                  normal_heart_rate_TextCircle[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

              console.log('update text circle battery_BATTERY');
              let idle_battery_circle_string = parseInt(valueBattery).toString();

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  idle_battery_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                idle_battery_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
                let char_Angle = 303;
                if (valueBattery != null && valueBattery != undefined && isFinite(valueBattery) && idle_battery_circle_string.length > 0 && idle_battery_circle_string.length <= 3) {  // display data if it was possible to get it
                  let idle_battery_TextCircle_img_angle = 0;
                  let idle_battery_TextCircle_dot_img_angle = 0;
                  let idle_battery_TextCircle_unit_angle = 0;
                  idle_battery_TextCircle_img_angle = toDegree(Math.atan2(idle_battery_TextCircle_img_width/2, 234));
                  idle_battery_TextCircle_unit_angle = toDegree(Math.atan2(idle_battery_TextCircle_unit_width/2, 234));
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of idle_battery_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= idle_battery_TextCircle_img_angle;
                      firstSymbol = false;
                      idle_battery_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      idle_battery_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - idle_battery_TextCircle_img_width / 2);
                      idle_battery_TextCircle[index].setProperty(hmUI.prop.SRC, idle_battery_TextCircle_ASCIIARRAY[charCode]);
                      idle_battery_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= idle_battery_TextCircle_img_angle;
                      index++;
                    };  // end if digit
                  };  // end char of string
                  char_Angle -= idle_battery_TextCircle_unit_angle;
                  idle_battery_TextCircle_unit.setProperty(hmUI.prop.ANGLE, char_Angle);
                  idle_battery_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite
                else {
                  idle_battery_TextCircle[0].setProperty(hmUI.prop.ANGLE, char_Angle);
                  idle_battery_TextCircle[0].setProperty(hmUI.prop.POS_X, 240 - idle_battery_TextCircle_error_img_width / 2);
                  idle_battery_TextCircle[0].setProperty(hmUI.prop.SRC, 'aod_bat_11.png');
                  idle_battery_TextCircle[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

              console.log('update text circle heart_rate_HEART');
              let idle_heart_rate_circle_string = parseInt(valueHeartRate).toString();

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  idle_heart_rate_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = 330;
                if (valueHeartRate != null && valueHeartRate != undefined && isFinite(valueHeartRate) && idle_heart_rate_circle_string.length > 0 && idle_heart_rate_circle_string.length <= 3) {  // display data if it was possible to get it
                  let idle_heart_rate_TextCircle_img_angle = 0;
                  let idle_heart_rate_TextCircle_dot_img_angle = 0;
                  idle_heart_rate_TextCircle_img_angle = toDegree(Math.atan2(idle_heart_rate_TextCircle_img_width/2, 234));
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of idle_heart_rate_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= idle_heart_rate_TextCircle_img_angle;
                      firstSymbol = false;
                      idle_heart_rate_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      idle_heart_rate_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - idle_heart_rate_TextCircle_img_width / 2);
                      idle_heart_rate_TextCircle[index].setProperty(hmUI.prop.SRC, idle_heart_rate_TextCircle_ASCIIARRAY[charCode]);
                      idle_heart_rate_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= idle_heart_rate_TextCircle_img_angle;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite
                else {
                  idle_heart_rate_TextCircle[0].setProperty(hmUI.prop.ANGLE, char_Angle);
                  idle_heart_rate_TextCircle[0].setProperty(hmUI.prop.POS_X, 240 - idle_heart_rate_TextCircle_error_img_width / 2);
                  idle_heart_rate_TextCircle[0].setProperty(hmUI.prop.SRC, 'aod_bat_11.png');
                  idle_heart_rate_TextCircle[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

            };

            //#endregion
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                time_update(true, true);
                text_update();
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSec) {
                    let animDelay = timeSensor.utc % 1000;
                    let animRepeat = 1000;
                    normal_timerUpdateSec = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, true);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                let secAngle = 0 + (360*6)*(timeSensor.second + ((timeSensor.utc % 1000) / 1000))/360;
                normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, secAngle);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSecSmooth) {
                    let duration = 0;
                    let animDuration = 5000;
                    if (timeSensor.second > 55) animDuration = 1000*(60.1 - (timeSensor.second - (timeSensor.utc % 1000) / 1000));
                    let diffTime = timeSensor.utc - lastTime;
                    if (diffTime < animDuration) duration = animDuration - diffTime;
                    normal_timerUpdateSecSmooth = timer.createTimer(duration, animDuration, (function (option) {
                      lastTime = timeSensor.utc;
                      secAngle = 0 + (360*6)*(timeSensor.second + ((timeSensor.utc % 1000) / 1000))/360;
                      startSecAnim(secAngle, animDuration);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


                let nawAnimationTime = now.utc;;
                
                let delay_anim_motion_1 = 0;
                let repeat_anim_motion_1 = 2000;
                delay_anim_motion_1 = repeat_anim_motion_1 - (nawAnimationTime - normal_motion_animation_lastTime_1);
                if(delay_anim_motion_1 < 0) delay_anim_motion_1 = 0; 
                if((nawAnimationTime - normal_motion_animation_lastTime_1) > repeat_anim_motion_1*2) {
                  normal_motion_animation_count_1 = 0;
                  timer_anim_motion_1_mirror = false;
                };

                if (!timer_anim_motion_1) {
                  timer_anim_motion_1 = timer.createTimer(delay_anim_motion_1, repeat_anim_motion_1, (function (option) {
                    if(timer_anim_motion_1_mirror) {
                      anim_motion_1_mirror()
                    } else {
                      anim_motion_1_complete_call()
                    };
                    timer_anim_motion_1_mirror = !timer_anim_motion_1_mirror;
                  })); // end timer create
                };
                
                let delay_anim_motion_2 = 0;
                let repeat_anim_motion_2 = 2000;
                delay_anim_motion_2 = repeat_anim_motion_2 - (nawAnimationTime - normal_motion_animation_lastTime_2);
                if(delay_anim_motion_2 < 0) delay_anim_motion_2 = 0; 
                if((nawAnimationTime - normal_motion_animation_lastTime_2) > repeat_anim_motion_2*2) {
                  normal_motion_animation_count_2 = 0;
                  timer_anim_motion_2_mirror = false;
                };

                if (!timer_anim_motion_2) {
                  timer_anim_motion_2 = timer.createTimer(delay_anim_motion_2, repeat_anim_motion_2, (function (option) {
                    if(timer_anim_motion_2_mirror) {
                      anim_motion_2_mirror()
                    } else {
                      anim_motion_2_complete_call()
                    };
                    timer_anim_motion_2_mirror = !timer_anim_motion_2_mirror;
                  })); // end timer create
                };

              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerUpdateSec) {
                  timer.stopTimer(normal_timerUpdateSec);
                  normal_timerUpdateSec = undefined;
                }
                if (normal_timerUpdateSecSmooth) {
                  timer.stopTimer(normal_timerUpdateSecSmooth);
                  normal_timerUpdateSecSmooth = undefined;
                }
                stop_anim_motion_1();
                stop_anim_motion_2();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
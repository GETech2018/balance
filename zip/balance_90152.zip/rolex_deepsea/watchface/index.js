import * as hmUI from '@zos/ui'

// NRX-0001 ... NRX-0010 = dígitos 0 ... 9
const DIGITS = ['NRX-0001.png','NRX-0002.png','NRX-0003.png','NRX-0004.png','NRX-0005.png',
                'NRX-0006.png','NRX-0007.png','NRX-0008.png','NRX-0009.png','NRX-0010.png']

const NORMAL = hmUI.show_level.ONLY_NORMAL
const AOD = hmUI.show_level.ONLY_AOD

const CX = 240
const CY = 240

WatchFace({
  build() {
    // ---------- Fondo ----------
    hmUI.createWidget(hmUI.widget.IMG, {
      x: 0, y: 0, w: 480, h: 480,
      src: 'Rolex_deepsea_BLUE_4.png',
      show_level: NORMAL
    })
    // Reposo (AOD): fondo negro con marcas luminosas
    hmUI.createWidget(hmUI.widget.IMG, {
      x: 0, y: 0, w: 480, h: 480,
      src: 'Tics_Fosf_RX.png',
      show_level: AOD
    })

    // ---------- Día del mes, centrado en la ventanilla (solo modo normal) ----------
    //hmUI.createWidget(hmUI.widget.TEXT_IMG, {
    //  x: 382, y: 226, w: 46, h: 27,
    //  type: hmUI.data_type.DAY,
    //  font_array: DIGITS,
    //  h_space: -10,
    //  align_h: hmUI.align.CENTER_H,
    //  show_level: NORMAL
    //})
hmUI.createWidget(hmUI.widget.IMG_DATE, {
      day_startX: 382, day_startY: 226,
      day_sc_array: DIGITS, day_tc_array: DIGITS, day_en_array: DIGITS,
      day_zero: 1, day_space: -10,
      day_align: hmUI.align.LEFT,
      day_is_character: false,
      show_level: BOTH
    })








    // ---------- Agujas (modo normal) ----------
    hmUI.createWidget(hmUI.widget.TIME_POINTER, {
      hour_path: '0012.png', hour_centerX: CX, hour_centerY: CY, hour_posX: 33, hour_posY: 141,
      show_level: NORMAL
    })
    hmUI.createWidget(hmUI.widget.TIME_POINTER, {
      minute_path: '0013.png', minute_centerX: CX, minute_centerY: CY, minute_posX: 23, minute_posY: 215,
      show_level: NORMAL
    })
    hmUI.createWidget(hmUI.widget.TIME_POINTER, {
      second_path: '0014.png', second_centerX: CX, second_centerY: CY, second_posX: 24, second_posY: 223,
      second_cover_path: 'AG005.png', second_cover_x: 235, second_cover_y: 236,
      show_level: NORMAL
    })

    // ---------- Agujas (AOD, sin segundero) ----------
    hmUI.createWidget(hmUI.widget.TIME_POINTER, {
      hour_path: 'AOD0032.png', hour_centerX: CX, hour_centerY: CY, hour_posX: 27, hour_posY: 143,
      show_level: AOD
    })
    hmUI.createWidget(hmUI.widget.TIME_POINTER, {
      minute_path: 'AOD0033.png', minute_centerX: CX, minute_centerY: CY, minute_posX: 18, minute_posY: 220,
      show_level: AOD
    })
  }
})

﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_battery_pointer_progress_img_pointer = ''
        let editableTimePointers = ''
        let normal_step_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_battery_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_altitude_jumpable_img_click = ''
        let Button_Switch_BG = ''

        let backgroundIndex = 0;
        let backgroundList = ['101-Quad_3-6_NoBez1.png', '102-Quad_3-6_Bez1.png', '103-Quad_3-6._NoBez2.png', '104-Quad_3-6_Bez2.png', '105-Quad_2-4_NoBez.png', '106-Quad_2-4_Bez2.png'];
        let backgroundToastList = ['Background %s', 'Sfondo %s', 'Sfondo %s', 'Sfondo %s', 'Sfondo %s', 'Sfondo %s'];
        const watchfaceId = hmApp.packageInfo().watchfaceId;


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            //start of ignored block
            console.log('SwitchBackground');
            function switchBackground() {
              backgroundIndex++;
              if (backgroundIndex >= backgroundList.length) backgroundIndex = 0;
              hmFS.SysProSetInt(`backgroundIndex_${watchfaceId}`, backgroundIndex);
              let toastText = backgroundToastList[backgroundIndex].replace('%s', `${backgroundIndex + 1}`);
              if (toastText.length > 0) hmUI.showToast({text: toastText});
              normal_background_bg_img.setProperty(hmUI.prop.SRC, backgroundList[backgroundIndex]);
            };
            //end of ignored block

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: '101-Quad_3-6_NoBez1.png',
              show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 310,
              y: 110,
              src: 'btoff.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 130,
              y: 110,
              src: 'alarm1.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: '0056.png',
              center_x: 240,
              center_y: 240,
              x: 21,
              y: 240,
              start_angle: 0,
              end_angle: 300,
              invalid_visible: false,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ElementEditablePointers');

            const pointerEdit = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_POINTER, {
              edit_id: 1003,
              x: 0,
              y: 0,
              config: [
                {
                  id: 1,
                  second: {
                    centerX: 240,
                    centerY: 240,
                    posX: 8,
                    posY: 234,
                    path: 'hand01_s.png',
                  },
                  hour: {
                    centerX: 240,
                    centerY: 240,
                    posX: 27,
                    posY: 156,
                    path: 'hand01_h.png',
                  },
                  minute: {
                    centerX: 240,
                    centerY: 240,
                    posX: 27,
                    posY: 236,
                    path: 'hand01_m.png',
                  },
                  preview: 'pointer_edit_1_preview.png',
                },
                {
                  id: 2,
                  second: {
                    centerX: 240,
                    centerY: 240,
                    posX: 240,
                    posY: 240,
                    path: 'hand02_s.png',
                  },
                  hour: {
                    centerX: 240,
                    centerY: 240,
                    posX: 240,
                    posY: 240,
                    path: 'hand02_h.png',
                  },
                  minute: {
                    centerX: 240,
                    centerY: 240,
                    posX: 240,
                    posY: 240,
                    path: 'hand02_m.png',
                  },
                  preview: 'pointer_edit_2_preview.png',
                },
                {
                  id: 3,
                  second: {
                    centerX: 240,
                    centerY: 240,
                    posX: 240,
                    posY: 240,
                    path: 'hand03_s.png',
                  },
                  hour: {
                    centerX: 240,
                    centerY: 240,
                    posX: 240,
                    posY: 240,
                    path: 'hand03_h.png',
                  },
                  minute: {
                    centerX: 240,
                    centerY: 240,
                    posX: 240,
                    posY: 240,
                    path: 'hand03_m.png',
                  },
                  preview: 'pointer_edit_3_preview.png',
                },
                {
                  id: 4,
                  second: {
                    centerX: 240,
                    centerY: 240,
                    posX: 240,
                    posY: 240,
                    path: 'hand04_s.png',
                  },
                  hour: {
                    centerX: 240,
                    centerY: 240,
                    posX: 240,
                    posY: 240,
                    path: 'hand04_h.png',
                  },
                  minute: {
                    centerX: 240,
                    centerY: 240,
                    posX: 240,
                    posY: 240,
                    path: 'hand04_m.png',
                  },
                  preview: 'pointer_edit_4_preview.png',
                },
                {
                  id: 5,
                  second: {
                    centerX: 240,
                    centerY: 240,
                    posX: 240,
                    posY: 240,
                    path: 'hand07_s.png',
                  },
                  hour: {
                    centerX: 240,
                    centerY: 240,
                    posX: 240,
                    posY: 240,
                    path: 'hand07_h.png',
                  },
                  minute: {
                    centerX: 240,
                    centerY: 240,
                    posX: 240,
                    posY: 240,
                    path: 'hand07_m.png',
                  },
                  preview: 'pointer_edit_5_preview.png',
                },
                {
                  id: 6,
                  second: {
                    centerX: 240,
                    centerY: 240,
                    posX: 240,
                    posY: 240,
                    path: 'hand08_s.png',
                  },
                  hour: {
                    centerX: 240,
                    centerY: 240,
                    posX: 240,
                    posY: 240,
                    path: 'hand08_h.png',
                  },
                  minute: {
                    centerX: 240,
                    centerY: 240,
                    posX: 240,
                    posY: 240,
                    path: 'hand08_m.png',
                  },
                  preview: 'pointer_edit_6_preview.png',
                },
                {
                  id: 7,
                  second: {
                    centerX: 240,
                    centerY: 240,
                    posX: 20,
                    posY: 222,
                    path: 'hand09_s.png',
                  },
                  hour: {
                    centerX: 240,
                    centerY: 240,
                    posX: 28,
                    posY: 147,
                    path: 'hand09_h.png',
                  },
                  minute: {
                    centerX: 240,
                    centerY: 240,
                    posX: 26,
                    posY: 217,
                    path: 'hand09_m.png',
                  },
                  preview: 'pointer_edit_7_preview.png',
                },
                {
                  id: 8,
                  second: {
                    centerX: 240,
                    centerY: 240,
                    posX: 42,
                    posY: 240,
                    path: 'hand10_s.png',
                  },
                  hour: {
                    centerX: 240,
                    centerY: 240,
                    posX: 41,
                    posY: 240,
                    path: 'hand10_h.png',
                  },
                  minute: {
                    centerX: 240,
                    centerY: 240,
                    posX: 41,
                    posY: 240,
                    path: 'hand10_m.png',
                  },
                  preview: 'pointer_edit_8_preview.png',
                },
              ],
              count: 8,
              default_id: 1,
              fg: '.png',
              tips_x: 0,
              tips_y: 0,
              tips_bg: '.png',
            });
            const screenTypeForETP = hmSetting.getScreenType();
            const aodModel = screenTypeForETP == hmSetting.screen_type.AOD;
            const pointerProp = pointerEdit.getProperty(hmUI.prop.CURRENT_CONFIG, !aodModel);
            editableTimePointers = hmUI.createWidget(hmUI.widget.TIME_POINTER, pointerProp);
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 190,
              y: 360,
              w: 100,
              h: 120,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 0,
              y: 200,
              w: 120,
              h: 80,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 4,
              y: 290,
              w: 100,
              h: 100,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 190,
              y: 0,
              w: 100,
              h: 80,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 190,
              y: 290,
              w: 100,
              h: 70,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 4,
              y: 90,
              w: 100,
              h: 100,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 380,
              y: 90,
              w: 100,
              h: 100,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 190,
              y: 80,
              w: 100,
              h: 90,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altitude_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 360,
              y: 200,
              w: 120,
              h: 80,
              type: hmUI.data_type.ALTITUDE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.SwitchBackground');
            // Button_Switch_BG = hmUI.createWidget(hmUI.widget.SwitchBackground, {
              // x: 200,
              // y: 200,
              // w: 80,
              // h: 80,
              // text: '',
              // color: 0xFFFF8C00,
              // text_size: 25,
              // press_src: 'null.png',
              // normal_src: 'null.png',
              // bg_list: 101-Quad_3-6_NoBez1|102-Quad_3-6_Bez1|103-Quad_3-6._NoBez2|104-Quad_3-6_Bez2|105-Quad_2-4_NoBez|106-Quad_2-4_Bez2,
              // toast_list: Background %s|Sfondo %s|Sfondo %s|Sfondo %s|Sfondo %s|Sfondo %s,
              // use_crown: False,
              // use_in_AOD: False,
              // vibro: False,
            // });

            Button_Switch_BG = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 200,
              y: 200,
              w: 80,
              h: 80,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'null.png',
              normal_src: 'null.png',
              click_func: (button_widget) => {
                switchBackground();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            let screenType = hmSetting.getScreenType();
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');

                //SwitchBackground
                if (hmFS.SysProGetInt(`backgroundIndex_${watchfaceId}`) === undefined) {
                  backgroundIndex = 0;
                  hmFS.SysProSetInt(`backgroundIndex_${watchfaceId}`, backgroundIndex);
                } else {
                  backgroundIndex = hmFS.SysProGetInt(`backgroundIndex_${watchfaceId}`);
                };
                if (screenType == hmSetting.screen_type.WATCHFACE && normal_background_bg_img) normal_background_bg_img.setProperty(hmUI.prop.SRC, backgroundList[backgroundIndex]);
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
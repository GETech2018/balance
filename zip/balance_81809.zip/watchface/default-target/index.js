try {
    ((() => {
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        let normal$_$component_0$_$component = '';
        const logger = Logger.getLogger('watchface');
        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 480,
                    h: 480,
                    src: '2.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$component_0$_$component = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
                    edit_id: 1,
                    x: 0,
                    y: 0,
                    w: 480,
                    h: 480,
                    select_image: '3.png',
                    un_select_image: '4.png',
                    default_type: hmUI.edit_type.DATE,
                    optional_types: [
                        {
                            'type': hmUI.edit_type.DATE,
                            'preview': '6.png'
                        },
                        {
                            'type': hmUI.edit_type.BATTERY,
                            'preview': '7.png'
                        },
                        {
                            'type': hmUI.edit_type.CAL,
                            'preview': '8.png'
                        },
                        {
                            'type': hmUI.edit_type.HEART,
                            'preview': '9.png'
                        }
                    ],
                    count: 4,
                    tips_BG: '5.png',
                    tips_x: 270,
                    tips_y: 89,
                    tips_width: 50,
                    tips_margin: 0
                });
                editType = normal$_$component_0$_$component.getProperty(hmUI.prop.CURRENT_TYPE);
                switch (editType) {
                case hmUI.edit_type.STEP:
                    break;
                case hmUI.edit_type.BATTERY:
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 213,
                        y: 85,
                        type: hmUI.data_type.BATTERY,
                        font_array: [
                            '10.png',
                            '11.png',
                            '12.png',
                            '13.png',
                            '14.png',
                            '15.png',
                            '16.png',
                            '17.png',
                            '18.png',
                            '19.png'
                        ],
                        align_h: hmUI.align.CENTER_H,
                        h_space: -16,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        padding: false,
                        isCharacter: false
                    });
                    break;
                case hmUI.edit_type.HEART:
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 213,
                        y: 85,
                        type: hmUI.data_type.HEART,
                        font_array: [
                            '10.png',
                            '11.png',
                            '12.png',
                            '13.png',
                            '14.png',
                            '15.png',
                            '16.png',
                            '17.png',
                            '18.png',
                            '19.png'
                        ],
                        align_h: hmUI.align.CENTER_H,
                        h_space: -16,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        invalid_image: '20.png',
                        padding: false,
                        isCharacter: false
                    });
                    break;
                case hmUI.edit_type.CAL:
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 207,
                        y: 85,
                        type: hmUI.data_type.CAL,
                        font_array: [
                            '10.png',
                            '11.png',
                            '12.png',
                            '13.png',
                            '14.png',
                            '15.png',
                            '16.png',
                            '17.png',
                            '18.png',
                            '19.png'
                        ],
                        align_h: hmUI.align.CENTER_H,
                        h_space: -16,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        padding: false,
                        isCharacter: false
                    });
                    break;
                case hmUI.edit_type.PAI_DAILY:
                    break;
                case hmUI.edit_type.DISTANCE:
                    break;
                case hmUI.edit_type.AQI:
                    break;
                case hmUI.edit_type.HUMIDITY:
                    break;
                case hmUI.edit_type.ALTIMETER:
                    break;
                case hmUI.edit_type.STRESS:
                    break;
                case hmUI.edit_type.WIND:
                    break;
                case hmUI.edit_type.SPO2:
                    break;
                case hmUI.edit_type.TRAINING_LOAD:
                    break;
                case hmUI.edit_type.VO2MAX:
                    break;
                case hmUI.edit_type.UVI:
                    break;
                case hmUI.edit_type.DATE:
                    hmUI.createWidget(hmUI.widget.IMG_DATE, {
                        day_startX: 219,
                        day_startY: 85,
                        day_sc_array: [
                            '10.png',
                            '11.png',
                            '12.png',
                            '13.png',
                            '14.png',
                            '15.png',
                            '16.png',
                            '17.png',
                            '18.png',
                            '19.png'
                        ],
                        day_tc_array: [
                            '10.png',
                            '11.png',
                            '12.png',
                            '13.png',
                            '14.png',
                            '15.png',
                            '16.png',
                            '17.png',
                            '18.png',
                            '19.png'
                        ],
                        day_en_array: [
                            '10.png',
                            '11.png',
                            '12.png',
                            '13.png',
                            '14.png',
                            '15.png',
                            '16.png',
                            '17.png',
                            '18.png',
                            '19.png'
                        ],
                        day_align: hmUI.align.CENTER_H,
                        day_zero: 0,
                        day_follow: 0,
                        day_space: -16,
                        day_is_character: false,
                        enable: false,
                        show_level: hmUI.show_level.ONLY_NORMAL
                    });
                    break;
                case hmUI.edit_type.WEEK:
                    break;
                case hmUI.edit_type.WEATHER:
                    break;
                case hmUI.edit_type.TEMPERATURE:
                    break;
                case hmUI.edit_type.SUN:
                    break;
                }
                hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_MASK, {
                    x: 0,
                    y: 0,
                    w: 480,
                    h: 480,
                    src: '21.png',
                    show_level: hmUI.show_level.ONLY_EDIT
                });
                hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                    hour_centerX: 240,
                    hour_centerY: 240,
                    hour_posX: 240,
                    hour_posY: 240,
                    hour_path: '22.png',
                    hour_cover_x: 0,
                    hour_cover_y: 0,
                    minute_centerX: 240,
                    minute_centerY: 240,
                    minute_posX: 240,
                    minute_posY: 240,
                    minute_path: '23.png',
                    minute_cover_x: 0,
                    minute_cover_y: 0,
                    second_centerX: 240,
                    second_centerY: 240,
                    second_posX: 240,
                    second_posY: 240,
                    second_path: '24.png',
                    second_cover_x: 0,
                    second_cover_y: 0,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    src: '25.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_FG_MASK, {
                    x: 0,
                    y: 0,
                    w: 480,
                    h: 480,
                    src: '26.png',
                    show_level: hmUI.show_level.ONLY_EDIT
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 480,
                    h: 480,
                    src: '27.png',
                    show_level: hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    hour_val: new Date().getHours(),
                    hour_zero: 1,
                    hour_startX: 172,
                    hour_startY: 75,
                    hour_array: [
                        '28.png',
                        '29.png',
                        '30.png',
                        '31.png',
                        '32.png',
                        '33.png',
                        '34.png',
                        '35.png',
                        '36.png',
                        '37.png'
                    ],
                    hour_space: -16,
                    hour_unit_sc: '38.png',
                    hour_unit_tc: '38.png',
                    hour_unit_en: '38.png',
                    hour_align: hmUI.align.CENTER_H,
                    minute_val: new Date().getMinutes(),
                    minute_zero: 1,
                    minute_startX: 245,
                    minute_startY: 75,
                    minute_array: [
                        '28.png',
                        '29.png',
                        '30.png',
                        '31.png',
                        '32.png',
                        '33.png',
                        '34.png',
                        '35.png',
                        '36.png',
                        '37.png'
                    ],
                    minute_space: -16,
                    minute_align: hmUI.align.CENTER_H,
                    minute_follow: 0,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_AOD
                });
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })());
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
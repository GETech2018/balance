﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_stand_current_text_img = ''
        let normal_stand_current_separator_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_text_separator_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_step_icon_img = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_battery_icon_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_text_separator_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_date_img_date_week_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let normal_analog_clock_time_pointer_smooth_second = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_day = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let normal_step_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_battery_jumpable_img_click = ''
        let normal_stand_jumpable_img_click = ''
        let Button_1 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'clock_face_(12).png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 323,
              y: 202,
              src: 'Bluetooth_off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 108,
              y: 202,
              src: 'Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 195,
              y: 382,
              font_array: ["Small_digit_01.png","Small_digit_02.png","Small_digit_03.png","Small_digit_04.png","Small_digit_05.png","Small_digit_06.png","Small_digit_07.png","Small_digit_08.png","Small_digit_09.png","Small_digit_10.png"],
              padding: true,
              h_space: -10,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STAND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 190,
              y: 415,
              src: 'Stand.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 391,
              y: 240,
              font_array: ["Small_amber_digit_01.png","Small_amber_digit_02.png","Small_amber_digit_03.png","Small_amber_digit_04.png","Small_amber_digit_05.png","Small_amber_digit_06.png","Small_amber_digit_07.png","Small_amber_digit_08.png","Small_amber_digit_09.png","Small_amber_digit_10.png"],
              padding: false,
              h_space: -10,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 388,
              y: 202,
              src: 'BPM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 21,
              month_startY: 202,
              month_sc_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_tc_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_en_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 33,
              day_startY: 240,
              day_sc_array: ["Small_amber_digit_01.png","Small_amber_digit_02.png","Small_amber_digit_03.png","Small_amber_digit_04.png","Small_amber_digit_05.png","Small_amber_digit_06.png","Small_amber_digit_07.png","Small_amber_digit_08.png","Small_amber_digit_09.png","Small_amber_digit_10.png"],
              day_tc_array: ["Small_amber_digit_01.png","Small_amber_digit_02.png","Small_amber_digit_03.png","Small_amber_digit_04.png","Small_amber_digit_05.png","Small_amber_digit_06.png","Small_amber_digit_07.png","Small_amber_digit_08.png","Small_amber_digit_09.png","Small_amber_digit_10.png"],
              day_en_array: ["Small_amber_digit_01.png","Small_amber_digit_02.png","Small_amber_digit_03.png","Small_amber_digit_04.png","Small_amber_digit_05.png","Small_amber_digit_06.png","Small_amber_digit_07.png","Small_amber_digit_08.png","Small_amber_digit_09.png","Small_amber_digit_10.png"],
              day_zero: 1,
              day_space: -10,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'Steps_Prog_100.png',
              // alpha: 100,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img.setAlpha(100);

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 186,
              y: 330,
              font_array: ["Small_amber_digit_01.png","Small_amber_digit_02.png","Small_amber_digit_03.png","Small_amber_digit_04.png","Small_amber_digit_05.png","Small_amber_digit_06.png","Small_amber_digit_07.png","Small_amber_digit_08.png","Small_amber_digit_09.png","Small_amber_digit_10.png"],
              padding: false,
              h_space: -10,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 147,
              y: 335,
              src: 'Steps.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 0,
              y: 0,
              image_array: ["Steps_Prog_10.png","Steps_Prog_20.png","Steps_Prog_30.png","Steps_Prog_40.png","Steps_Prog_50.png","Steps_Prog_60.png","Steps_Prog_70.png","Steps_Prog_80.png","Steps_Prog_90.png","Steps_Prog_100.png"],
              image_length: 10,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'progress_100.png',
              // alpha: 100,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img.setAlpha(100);

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 196,
              y: 112,
              font_array: ["Small_amber_digit_01.png","Small_amber_digit_02.png","Small_amber_digit_03.png","Small_amber_digit_04.png","Small_amber_digit_05.png","Small_amber_digit_06.png","Small_amber_digit_07.png","Small_amber_digit_08.png","Small_amber_digit_09.png","Small_amber_digit_10.png"],
              padding: false,
              h_space: -10,
              unit_sc: 'Percent.png',
              unit_tc: 'Percent.png',
              unit_en: 'Percent.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 147,
              y: 117,
              src: 'Bolt_white.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 0,
              y: 0,
              image_array: ["progress_10.png","progress_20.png","progress_30.png","progress_40.png","progress_50.png","progress_60.png","progress_70.png","progress_80.png","progress_90.png","progress_100.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 0,
              y: 0,
              week_en: ["Day_01.png","Day_02.png","Day_03.png","Day_04.png","Day_05.png","Day_06.png","Day_07.png"],
              week_tc: ["Day_01.png","Day_02.png","Day_03.png","Day_04.png","Day_05.png","Day_06.png","Day_07.png"],
              week_sc: ["Day_01.png","Day_02.png","Day_03.png","Day_04.png","Day_05.png","Day_06.png","Day_07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 108,
              am_y: 264,
              am_sc_path: 'DT_AM.png',
              am_en_path: 'DT_AM.png',
              pm_x: 108,
              pm_y: 264,
              pm_sc_path: 'DT_PM.png',
              pm_en_path: 'DT_PM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 151,
              hour_startY: 162,
              hour_array: ["digit_01.png","digit_02.png","digit_03.png","digit_04.png","digit_05.png","digit_06.png","digit_07.png","digit_08.png","digit_09.png","digit_10.png"],
              hour_zero: 1,
              hour_space: -21,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 309,
              minute_startY: 247,
              minute_array: ["Min_digit_01.png","Min_digit_02.png","Min_digit_03.png","Min_digit_04.png","Min_digit_05.png","Min_digit_06.png","Min_digit_07.png","Min_digit_08.png","Min_digit_09.png","Min_digit_10.png"],
              minute_zero: 1,
              minute_space: -12,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'Sec.png',
              // center_x: 240,
              // center_y: 240,
              // x: 240,
              // y: 240,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_time_pointer_smooth_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'Sec.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 240,
              second_posY: 240,
              fresh_frequency: 30,
              fresh_freqency: 30,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_smooth_second = hmUI.createWidget(hmUI.widget.SMOOTH_SECOND, {
              // type: 3,
              // fps: 30,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });



            console.log('Watch_Face.ScreenAOD');

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 167,
              month_startY: 139,
              month_sc_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_tc_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_en_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 241,
              day_startY: 139,
              day_sc_array: ["Small_amber_digit_01.png","Small_amber_digit_02.png","Small_amber_digit_03.png","Small_amber_digit_04.png","Small_amber_digit_05.png","Small_amber_digit_06.png","Small_amber_digit_07.png","Small_amber_digit_08.png","Small_amber_digit_09.png","Small_amber_digit_10.png"],
              day_tc_array: ["Small_amber_digit_01.png","Small_amber_digit_02.png","Small_amber_digit_03.png","Small_amber_digit_04.png","Small_amber_digit_05.png","Small_amber_digit_06.png","Small_amber_digit_07.png","Small_amber_digit_08.png","Small_amber_digit_09.png","Small_amber_digit_10.png"],
              day_en_array: ["Small_amber_digit_01.png","Small_amber_digit_02.png","Small_amber_digit_03.png","Small_amber_digit_04.png","Small_amber_digit_05.png","Small_amber_digit_06.png","Small_amber_digit_07.png","Small_amber_digit_08.png","Small_amber_digit_09.png","Small_amber_digit_10.png"],
              day_zero: 1,
              day_space: -10,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 108,
              am_y: 264,
              am_sc_path: 'DT_AM.png',
              am_en_path: 'DT_AM.png',
              pm_x: 108,
              pm_y: 264,
              pm_sc_path: 'DT_PM.png',
              pm_en_path: 'DT_PM.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 151,
              hour_startY: 162,
              hour_array: ["digit_01.png","digit_02.png","digit_03.png","digit_04.png","digit_05.png","digit_06.png","digit_07.png","digit_08.png","digit_09.png","digit_10.png"],
              hour_zero: 1,
              hour_space: -21,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 309,
              minute_startY: 247,
              minute_array: ["Min_digit_01.png","Min_digit_02.png","Min_digit_03.png","Min_digit_04.png","Min_digit_05.png","Min_digit_06.png","Min_digit_07.png","Min_digit_08.png","Min_digit_09.png","Min_digit_10.png"],
              minute_zero: 1,
              minute_space: -12,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 188,
              y: 273,
              w: 103,
              h: 103,
              src: '0_empty.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 377,
              y: 193,
              w: 103,
              h: 103,
              src: '0_empty.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 188,
              y: 0,
              w: 103,
              h: 103,
              src: '0_empty.png',
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 188,
              y: 377,
              w: 103,
              h: 103,
              src: '0_empty.png',
              type: hmUI.data_type.STAND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 0,
              y: 193,
              w: 103,
              h: 103,
              text: '',
              color: 0xFFFF8C00,
              text_size: 26,
              press_src: '0_empty.png',
              normal_src: '0_empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
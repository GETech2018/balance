﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

        let image_list = [
            'img_1.png',
            'img_2.png',
            'img_3.png',
			'img_4.png',
            'img_5.png',
			'img_6.png',
			'img_7.png',
			'img_8.png',
			'img_9.png',
			
        ];
        let image_index = 0;

        function image_switching() {
            image_index++;
            if (image_index >= image_list.length) image_index = 0;
            normal_image_img.setProperty(hmUI.prop.SRC, image_list[image_index]);
        }
        // end user_functions.js

        let editBg = ''
        let normal_system_lock_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_image_img = ''
        let normal_battery_current_text_font = ''
        let normal_step_current_text_font = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let idle_system_lock_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_image_img = ''
        let idle_battery_current_text_font = ''
        let idle_step_current_text_font = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_week_img = ''
        let editableTimePointers = ''
        let Button_1 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            editBg = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_BG, {
              edit_id: 1002,
              x: 0,
              y: 0,
              // w: 480,
              // h: 480,
              // AOD_show: True,
              bg_config: [
                { id: 1, preview: 'bg_edit_1_preview.png', path: 'bg_1.png' },
                { id: 2, preview: 'bg_edit_2_preview.png', path: 'bg_2.png' },
                { id: 3, preview: 'bg_edit_3_preview.png', path: 'bg_3.png' },
              ],
              count: 3,
              default_id: 1,
              fg: '.png',
              tips_bg: 'ic_1.png',
              tips_x: 240,
              tips_y: 240,
            });

            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 406,
              y: 272,
              src: 'st_2.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 198,
              y: 282,
              src: 'st_1.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 406,
              y: 188,
              src: 'st_3.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'img_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 215,
              y: 170,
              w: 51,
              h: 28,
              text_size: 22,
              char_space: 0,
              line_space: 0,
              color: 0xFFEDD987,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 197,
              y: 294,
              w: 82,
              h: 30,
              text_size: 24,
              char_space: 0,
              line_space: 0,
              color: 0xFFEDD987,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 406,
              day_startY: 228,
              day_sc_array: ["dd_01.png","dd_02.png","dd_03.png","dd_04.png","dd_05.png","dd_06.png","dd_07.png","dd_08.png","dd_09.png","dd_10.png"],
              day_tc_array: ["dd_01.png","dd_02.png","dd_03.png","dd_04.png","dd_05.png","dd_06.png","dd_07.png","dd_08.png","dd_09.png","dd_10.png"],
              day_en_array: ["dd_01.png","dd_02.png","dd_03.png","dd_04.png","dd_05.png","dd_06.png","dd_07.png","dd_08.png","dd_09.png","dd_10.png"],
              day_zero: 0,
              day_space: 1,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 348,
              y: 228,
              week_en: ["wk_1.png","wk_2.png","wk_3.png","wk_4.png","wk_5.png","wk_6.png","wk_7.png"],
              week_tc: ["wk_1.png","wk_2.png","wk_3.png","wk_4.png","wk_5.png","wk_6.png","wk_7.png"],
              week_sc: ["wk_1.png","wk_2.png","wk_3.png","wk_4.png","wk_5.png","wk_6.png","wk_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');

            idle_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 406,
              y: 272,
              src: 'st_2.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 198,
              y: 282,
              src: 'st_1.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 406,
              y: 188,
              src: 'st_3.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'img_1.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 215,
              y: 170,
              w: 51,
              h: 28,
              text_size: 22,
              char_space: 0,
              line_space: 0,
              color: 0xFFEDD987,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 197,
              y: 294,
              w: 82,
              h: 30,
              text_size: 24,
              char_space: 0,
              line_space: 0,
              color: 0xFFEDD987,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 406,
              day_startY: 228,
              day_sc_array: ["dd_01.png","dd_02.png","dd_03.png","dd_04.png","dd_05.png","dd_06.png","dd_07.png","dd_08.png","dd_09.png","dd_10.png"],
              day_tc_array: ["dd_01.png","dd_02.png","dd_03.png","dd_04.png","dd_05.png","dd_06.png","dd_07.png","dd_08.png","dd_09.png","dd_10.png"],
              day_en_array: ["dd_01.png","dd_02.png","dd_03.png","dd_04.png","dd_05.png","dd_06.png","dd_07.png","dd_08.png","dd_09.png","dd_10.png"],
              day_zero: 0,
              day_space: 1,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 348,
              y: 228,
              week_en: ["wk_1.png","wk_2.png","wk_3.png","wk_4.png","wk_5.png","wk_6.png","wk_7.png"],
              week_tc: ["wk_1.png","wk_2.png","wk_3.png","wk_4.png","wk_5.png","wk_6.png","wk_7.png"],
              week_sc: ["wk_1.png","wk_2.png","wk_3.png","wk_4.png","wk_5.png","wk_6.png","wk_7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.ElementEditablePointers');

            const pointerEdit = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_POINTER, {
              edit_id: 1003,
              x: 0,
              y: 0,
              config: [
                {
                  id: 1,
                  second: {
                    centerX: 240,
                    centerY: 240,
                    posX: 12,
                    posY: 238,
                    path: 'sh_2.png',
                  },
                  hour: {
                    centerX: 240,
                    centerY: 240,
                    posX: 17,
                    posY: 152,
                    path: 'hh_1.png',
                  },
                  minute: {
                    centerX: 240,
                    centerY: 240,
                    posX: 14,
                    posY: 216,
                    path: 'mh_1.png',
                  },
                  preview: 'pointer_edit_1_preview.png',
                },
                {
                  id: 2,
                  second: {
                    centerX: 240,
                    centerY: 240,
                    posX: 12,
                    posY: 216,
                    path: 'sh_1.png',
                  },
                  hour: {
                    centerX: 240,
                    centerY: 240,
                    posX: 17,
                    posY: 152,
                    path: 'hh_2.png',
                  },
                  minute: {
                    centerX: 240,
                    centerY: 240,
                    posX: 14,
                    posY: 216,
                    path: 'mh_2.png',
                  },
                  preview: 'pointer_edit_2_preview.png',
                },
                {
                  id: 3,
                  second: {
                    centerX: 240,
                    centerY: 240,
                    posX: 12,
                    posY: 238,
                    path: 'sh_2.png',
                  },
                  hour: {
                    centerX: 240,
                    centerY: 240,
                    posX: 25,
                    posY: 177,
                    path: 'hh_3.png',
                  },
                  minute: {
                    centerX: 240,
                    centerY: 240,
                    posX: 20,
                    posY: 220,
                    path: 'mh_3.png',
                  },
                  preview: 'pointer_edit_3_preview.png',
                },
                {
                  id: 4,
                  second: {
                    centerX: 240,
                    centerY: 240,
                    posX: 12,
                    posY: 216,
                    path: 'sh_1.png',
                  },
                  hour: {
                    centerX: 240,
                    centerY: 240,
                    posX: 25,
                    posY: 177,
                    path: 'hh_4.png',
                  },
                  minute: {
                    centerX: 240,
                    centerY: 240,
                    posX: 20,
                    posY: 220,
                    path: 'mh_4.png',
                  },
                  preview: 'pointer_edit_4_preview.png',
                },
              ],
              count: 4,
              default_id: 1,
              fg: 'ic_2.png',
              tips_x: 240,
              tips_y: 240,
              tips_bg: 'ic_1.png',
            });
            const pointerProp = pointerEdit.getProperty(hmUI.prop.CURRENT_CONFIG, true);
            editableTimePointers = hmUI.createWidget(hmUI.widget.TIME_POINTER, pointerProp);

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 30,
              y: 190,
              w: 100,
              h: 100,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'ic_1.png',
              normal_src: 'ic_1.png',
              click_func: (button_widget) => {
                image_switching()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
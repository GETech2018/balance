﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_humidity_text_text_img = ''
        let normal_humidity_text_separator_img = ''
        let normal_calorie_current_text_img = ''
        let normal_calorie_current_separator_img = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_distance_text_text_img = ''
        let normal_distance_text_separator_img = ''
        let normal_stand_current_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_moon_image_progress_img_level = ''
        let normal_group_ForecastWeather = ''
        let normal_forecast_date_week_img = new Array(5);
        let normal_forecast_date_week_img_array = ['wd1.png', 'wd2.png', 'wd3.png', 'wd4.png', 'wd5.png', 'wd6.png', 'wd7.png'];
        let normal_forecast_high_low_text_img = new Array(5);
        let normal_forecast_image_progress_img_level = new Array(5);
        let normal_forecast_image_array = ['weatherl_00.png', 'weatherl_01.png', 'weatherl_02.png', 'weatherl_03.png', 'weatherl_04.png', 'weatherl_05.png', 'weatherl_06.png', 'weatherl_07.png', 'weatherl_08.png', 'weatherl_09.png', 'weatherl_10.png', 'weatherl_11.png', 'weatherl_12.png', 'weatherl_13.png', 'weatherl_14.png', 'weatherl_15.png', 'weatherl_16.png', 'weatherl_17.png', 'weatherl_18.png', 'weatherl_19.png', 'weatherl_20.png', 'weatherl_21.png', 'weatherl_22.png', 'weatherl_23.png', 'weatherl_24.png', 'weatherl_25.png', 'weatherl_26.png', 'weatherl_27.png', 'weatherl_28.png'];
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_date_img_date_month_img = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_day = ''
        let idle_battery_text_text_img = ''
        let idle_battery_image_progress_img_level = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_digital_clock_img_time = ''
        let idle_analog_clock_pro_second_pointer_img = ''
        let idle_timerUpdateSec = undefined;
        let normal_stopwatch_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let timeSensor = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'md2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 352,
              y: 152,
              font_array: ["c0.png","c1.png","c2.png","c3.png","c4.png","c5.png","c6.png","c7.png","c8.png","c9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'PER.png',
              unit_tc: 'PER.png',
              unit_en: 'PER.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 363,
              y: 184,
              src: 'LHU.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 131,
              y: 95,
              font_array: ["c0.png","c1.png","c2.png","c3.png","c4.png","c5.png","c6.png","c7.png","c8.png","c9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 88,
              y: 95,
              src: 'l_2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 153,
              y: 47,
              font_array: ["c0.png","c1.png","c2.png","c3.png","c4.png","c5.png","c6.png","c7.png","c8.png","c9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 116,
              y: 49,
              src: 'l_4.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 9,
              y: 6,
              image_array: ["STE1.png","STE2.png","STE3.png","STE4.png","STE5.png","STE6.png","STE7.png"],
              image_length: 7,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 282,
              y: 47,
              font_array: ["c0.png","c1.png","c2.png","c3.png","c4.png","c5.png","c6.png","c7.png","c8.png","c9.png"],
              padding: false,
              h_space: 0,
              dot_image: 'PUNTO.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 251,
              y: 45,
              src: 'l_3.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 299,
              y: 95,
              font_array: ["c0.png","c1.png","c2.png","c3.png","c4.png","c5.png","c6.png","c7.png","c8.png","c9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'HRS.png',
              unit_tc: 'HRS.png',
              unit_en: 'HRS.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STAND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 208,
              y: 162,
              font_array: ["c0.png","c1.png","c2.png","c3.png","c4.png","c5.png","c6.png","c7.png","c8.png","c9.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 236,
              y: 436,
              week_en: ["P1.png","P2.png","P3.png","P4.png","P5.png","P6.png","P7.png"],
              week_tc: ["P1.png","P2.png","P3.png","P4.png","P5.png","P6.png","P7.png"],
              week_sc: ["P1.png","P2.png","P3.png","P4.png","P5.png","P6.png","P7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 176,
              day_startY: 422,
              day_sc_array: ["secondi72.png","secondi73.png","secondi74.png","secondi75.png","secondi76.png","secondi77.png","secondi78.png","secondi79.png","secondi80.png","secondi81.png"],
              day_tc_array: ["secondi72.png","secondi73.png","secondi74.png","secondi75.png","secondi76.png","secondi77.png","secondi78.png","secondi79.png","secondi80.png","secondi81.png"],
              day_en_array: ["secondi72.png","secondi73.png","secondi74.png","secondi75.png","secondi76.png","secondi77.png","secondi78.png","secondi79.png","secondi80.png","secondi81.png"],
              day_zero: 1,
              day_space: -6,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 52,
              y: 332,
              image_array: ["moon_1.png","Moon_01.png","moon_2.png","Moon_02.png","moon_3.png","Moon_03.png","moon_4.png","Moon_04.png","moon_5.png","Moon_05.png","moon_6.png","Moon_06.png","moon_7.png","Moon_07.png","moon_8.png","Moon_08.png","moon_9.png","Moon_09.png","moon_10.png","moon_11.png","moon_12.png","moon_13.png","moon_14.png","moon_15.png","moon_16.png","moon_17.png","moon_18.png","moon_19.png","moon_20.png","moon_21.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();            
            // normal_Weather_FewDays = hmUI.createWidget(hmUI.widget.FewDays, {
              // x: 42,
              // y: 234,
              // ColumnWidth: 71,
              // DaysCount: 5,
            // });
            
            normal_group_ForecastWeather = hmUI.createWidget(hmUI.widget.GROUP, {
              x: 42,
              y: 234,
              h: 0,
              w: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_forecast_date_week_img = normal_group_ForecastWeather.createWidget(hmUI.widget.IMG_LEVEL_Options, {
              // x: 65,
              // y: 38,
              // image_array: ["wd1.png","wd2.png","wd3.png","wd4.png","wd5.png","wd6.png","wd7.png"],
              // image_length: 7,
              // type: hmUI.data_type.forecast_date_week_img,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            //start of ignored block
            if (screenType == hmSetting.screen_type.WATCHFACE) {
              for (let i = 0; i < 5; i++) {
                normal_forecast_date_week_img[i] = normal_group_ForecastWeather.createWidget(hmUI.widget.IMG, {
                  x: 65 + i*71,
                  y: 38,
                  src: normal_forecast_date_week_img_array[0],
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
              };
            };
            //end of ignored block

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            // normal_forecast_high_low_text_img = normal_group_ForecastWeather.createWidget(hmUI.widget.TEXT_IMG_Options, {
              // x: 67,
              // y: -27,
              // font_array: ["small_00.png","small_01.png","small_02.png","small_03.png","small_04.png","small_05.png","small_06.png","small_07.png","small_08.png","small_09.png"],
              // padding: false,
              // h_space: -5,
              // negative_image: 'small_11.png',
              // dot_image: 'small_11.png',
              // separator_image: 'small_10.png',
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.forecast_high_low_text_img,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            //start of ignored block
            if (screenType == hmSetting.screen_type.WATCHFACE) {
              for (let i = 0; i < 5; i++) {
                normal_forecast_high_low_text_img[i] = normal_group_ForecastWeather.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 67 + i*71,
                  y: -27,
                  font_array: ["small_00.png","small_01.png","small_02.png","small_03.png","small_04.png","small_05.png","small_06.png","small_07.png","small_08.png","small_09.png"],
                  padding: false,
                  h_space: -5,
                  negative_image: 'small_11.png',
                  dot_image: 'small_10.png',
                  align_h: hmUI.align.CENTER_H,
                  // type: hmUI.data_type.FORECAST_NUMBER_MAX,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
              };
            };
            //end of ignored block

            // normal_forecast_image_progress_img_level = normal_group_ForecastWeather.createWidget(hmUI.widget.IMG_LEVEL_Options, {
              // x: 77,
              // y: -8,
              // image_array: ["weatherl_00.png","weatherl_01.png","weatherl_02.png","weatherl_03.png","weatherl_04.png","weatherl_05.png","weatherl_06.png","weatherl_07.png","weatherl_08.png","weatherl_09.png","weatherl_10.png","weatherl_11.png","weatherl_12.png","weatherl_13.png","weatherl_14.png","weatherl_15.png","weatherl_16.png","weatherl_17.png","weatherl_18.png","weatherl_19.png","weatherl_20.png","weatherl_21.png","weatherl_22.png","weatherl_23.png","weatherl_24.png","weatherl_25.png","weatherl_26.png","weatherl_27.png","weatherl_28.png"],
              // image_length: 29,
              // type: hmUI.data_type.forecast_image,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            //start of ignored block
            if (screenType == hmSetting.screen_type.WATCHFACE) {
              for (let i = 0; i < 5; i++) {
                normal_forecast_image_progress_img_level[i] = normal_group_ForecastWeather.createWidget(hmUI.widget.IMG, {
                  x: 77 + i*71,
                  y: -8,
                  src: normal_forecast_image_array[25],
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
              };
            };
            //end of ignored block

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 49,
              y: 229,
              image_array: ["w_01.png","w_02.png","w_03.png","w_04.png","w_05.png","w_06.png","w_07.png","w_08.png","w_09.png","w_10.png","w_11.png","w_12.png","w_13.png","w_14.png","w_15.png","w_16.png","w_17.png","w_18.png","w_19.png","w_20.png","w_21.png","w_22.png","w_23.png","w_24.png","w_25.png","w_26.png","w_27.png","w_28.png","w_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 45,
              y: 208,
              font_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              padding: false,
              h_space: -3,
              negative_image: 'small_11.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 67,
              y: 151,
              font_array: ["c0.png","c1.png","c2.png","c3.png","c4.png","c5.png","c6.png","c7.png","c8.png","c9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'PER.png',
              unit_tc: 'PER.png',
              unit_en: 'PER.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 4,
              y: 5,
              image_array: ["BA1.png","BA2.png","BA3.png","BA4.png","BA5.png","BA6.png","BA7.png"],
              image_length: 7,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 103,
              month_startY: 302,
              month_sc_array: ["62.png","63.png","64.png","65.png","66.png","67.png","68.png","69.png","70.png","71.png","72.png","73.png"],
              month_tc_array: ["62.png","63.png","64.png","65.png","66.png","67.png","68.png","69.png","70.png","71.png","72.png","73.png"],
              month_en_array: ["62.png","63.png","64.png","65.png","66.png","67.png","68.png","69.png","70.png","71.png","72.png","73.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 101,
              hour_startY: 331,
              hour_array: ["22.png","23.png","24.png","25.png","26.png","27.png","28.png","29.png","30.png","31.png"],
              hour_zero: 1,
              hour_space: -33,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 234,
              minute_startY: 331,
              minute_array: ["22.png","23.png","24.png","25.png","26.png","27.png","28.png","29.png","30.png","31.png"],
              minute_zero: 1,
              minute_space: -29,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 367,
              second_startY: 340,
              second_array: ["12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png"],
              second_zero: 1,
              second_space: -13,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'aod_bg.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 206,
              y: 375,
              week_en: ["SE1.png","SE2.png","SE3.png","SE4.png","SE5.png","SE6.png","SE7.png"],
              week_tc: ["SE1.png","SE2.png","SE3.png","SE4.png","SE5.png","SE6.png","SE7.png"],
              week_sc: ["SE1.png","SE2.png","SE3.png","SE4.png","SE5.png","SE6.png","SE7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 210,
              day_startY: 328,
              day_sc_array: ["day_00.png","day_01.png","day_02.png","day_03.png","day_04.png","day_05.png","day_06.png","day_07.png","day_08.png","day_09.png"],
              day_tc_array: ["day_00.png","day_01.png","day_02.png","day_03.png","day_04.png","day_05.png","day_06.png","day_07.png","day_08.png","day_09.png"],
              day_en_array: ["day_00.png","day_01.png","day_02.png","day_03.png","day_04.png","day_05.png","day_06.png","day_07.png","day_08.png","day_09.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 204,
              y: 90,
              font_array: ["num_00.png","num_01.png","num_02.png","num_03.png","num_04.png","num_05.png","num_06.png","num_07.png","num_08.png","num_09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'num_10.png',
              unit_tc: 'num_10.png',
              unit_en: 'num_10.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 178,
              y: 139,
              image_array: ["INDICA139.png","INDICA140.png","INDICA141.png","INDICA142.png","INDICA143.png"],
              image_length: 5,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 373,
              y: 244,
              src: 'st_bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 372,
              y: 207,
              src: 'st_al.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 65,
              hour_startY: 157,
              hour_array: ["ore49.png","ore50.png","ore51.png","ore52.png","ore53.png","ore54.png","ore55.png","ore56.png","ore57.png","ore58.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 248,
              minute_startY: 174,
              minute_array: ["minuti59.png","minuti60.png","minuti61.png","minuti62.png","minuti63.png","minuti64.png","minuti65.png","minuti66.png","minuti67.png","minuti68.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            const deviceInfo = hmSetting.getDeviceInfo();
            // idle_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'hand_sec1.png',
              // center_x: 240,
              // center_y: 240,
              // x: 240,
              // y: 256,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });


            idle_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 240,
              pos_y: 240 - 256,
              center_x: 240,
              center_y: 240,
              src: 'hand_sec1.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 377,
              y: 343,
              w: 48,
              h: 40,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 124,
              y: 339,
              w: 100,
              h: 100,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 193,
              y: 109,
              w: 100,
              h: 100,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 118,
              y: 39,
              w: 100,
              h: 50,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);
            //start of ignored block
            function weather_few_days() {
              console.log('weather_few_days()');
              let weatherData = weatherSensor.getForecastWeather();
              let forecastData = weatherData.forecastData;

              for (let i = 0; i < 5; i++) {
                // DOW images
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  let dowIndex = timeSensor.week - 1;
                  dowIndex += i;
                  while (dowIndex >= 7) {dowIndex -= 7;}
                  normal_forecast_date_week_img[i].setProperty(hmUI.prop.SRC, normal_forecast_date_week_img_array[dowIndex]);
                };
              
                // Number_MaxMin
                let max_min_Temperature_img = '-';
                if (i < forecastData.count) {
                  max_min_Temperature_img = forecastData.data[i].high.toString();
                  max_min_Temperature_img += '.';
                  max_min_Temperature_img += forecastData.data[i].low.toString();
                };
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  normal_forecast_high_low_text_img[i].setProperty(hmUI.prop.TEXT, max_min_Temperature_img);
                };
                
                // Images
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  let weatherIndex = 25
                  if (i < forecastData.count) weatherIndex = forecastData.data[i].index;
                  normal_forecast_image_progress_img_level[i].setProperty(hmUI.prop.SRC, normal_forecast_image_array[weatherIndex]);
                };
              
              };  // end for

            };
            //end of ignored block

            //start of ignored block
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              let idle_fullAngle_second = 360;
              let idle_angle_second = 0 + idle_fullAngle_second*second/60;
              if (idle_analog_clock_pro_second_pointer_img) idle_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, idle_angle_second);

            };

            //end of ignored block
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                time_update(true, true);
                if (screenType == hmSetting.screen_type.AOD) {
                  if (!idle_timerUpdateSec) {
                    let animDelay = timeSensor.utc % 1000;
                    let animRepeat = 1000;
                    idle_timerUpdateSec = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, false);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


                weather_few_days();
              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (idle_timerUpdateSec) {
                  timer.stopTimer(idle_timerUpdateSec);
                  idle_timerUpdateSec = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
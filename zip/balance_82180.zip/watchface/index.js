﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block
		
		//dynamic modify start

 
        let normal_background_bg_img = ''
        let normal_system_lock_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_date_img_date_week_img = ''
		let normal_date_img_date_week_img_1 = ''
        let normal_date_img_date_month_img = ''
		let normal_date_img_date_month_img_1 = ''
        let normal_date_img_date_day = ''
        let normal_uvi_pointer_progress_img_pointer = ''
        let normal_aqi_current_text_img = ''
        let normal_altitude_target_separator_img = ''
        let normal_altimeter_text_text_img = ''
        let normal_altimeter_text_separator_img = ''
        let normal_wind_direction_image_progress_img_level = ''
        let normal_wind_text_text_img = ''
        let normal_humidity_text_text_img = ''
        let normal_humidity_text_separator_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_battery_circle_scale = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_step_current_text_img = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_second_separator_img = ''
        let idle_background_bg = ''
        let idle_digital_clock_img_time = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
		let icon_bg = ''
		
		let batteryInfo_click = ''
		
		const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
		
		let valueBattery = ''
		
		let btn_zona1 = ''
        let zona1_num = 0
        let zona1_all = 3
		
		function click_zona1() {
		  zona1_num = (zona1_num + 1) % (zona1_all + 1);
          if (zona1_num == 0) {		
		    normal_humidity_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
            normal_humidity_text_separator_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_wind_direction_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
			normal_wind_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_altimeter_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_altimeter_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_aqi_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_altitude_target_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		    hmUI.showToast({
            });
          };
		  
		 if (zona1_num == 1) {
			normal_humidity_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_humidity_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_wind_direction_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);
			normal_wind_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_altimeter_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_altimeter_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_aqi_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_altitude_target_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		    hmUI.showToast({
            });
          };
		  
		  if (zona1_num == 2) {
			normal_humidity_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_humidity_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_wind_direction_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
			normal_wind_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_altimeter_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_altimeter_text_separator_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_aqi_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_altitude_target_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		    hmUI.showToast({
            });
          };
		  
		  if (zona1_num == 3) {
			normal_humidity_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_humidity_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_wind_direction_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
			normal_wind_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_altimeter_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_altimeter_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_aqi_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_altitude_target_separator_img.setProperty(hmUI.prop.VISIBLE, true);
		    hmUI.showToast({
            });
          };
        }
		
		let btn_zona2 = ''
        let zona2_num = 0
        let zona2_all = 1
		
		function click_zona2() {
		  zona2_num = (zona2_num + 1) % (zona2_all + 1);
          if (zona2_num == 0) {		
		    normal_date_img_date_week_img.setProperty(hmUI.prop.VISIBLE, true);
            normal_date_img_date_month_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_date_img_date_week_img_1.setProperty(hmUI.prop.VISIBLE, false);
			normal_date_img_date_month_img_1.setProperty(hmUI.prop.VISIBLE, false);
		    hmUI.showToast({
            });
          };
		  
		 if (zona2_num == 1) {
			normal_date_img_date_week_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_date_img_date_month_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_date_img_date_week_img_1.setProperty(hmUI.prop.VISIBLE, true);
			normal_date_img_date_month_img_1.setProperty(hmUI.prop.VISIBLE, true);
		    hmUI.showToast({
            });
          };
        }
		
		let btn_bezel = ''
        let bezel_num = 1
        let bezel_all = 6
     
        function click_Bezel() {
            if(bezel_num>=bezel_all) {bezel_num=1;}
            else { bezel_num=bezel_num+1;}
            hmUI.showToast({text: "<BackGround> " + parseInt(bezel_num) });
            normal_background_bg_img.setProperty(hmUI.prop.SRC, "bg_" + parseInt(bezel_num) + ".png");
        }
		
		
		const curTime = hmSensor.createSensor(hmSensor.id.TIME);
		const weather = hmSensor.createSensor(hmSensor.id.WEATHER);
		let weatherData = weather.getForecastWeather();
		let forecastData = weatherData.forecastData;
		let sunData = weatherData.tideData;
		let today = '';
		let sunriseMins = '';
		let sunsetMins = '';
		let sunriseMins_def = 8 * 60;			
		let sunsetMins_def = 20 * 60;

		let curMins = '';
		
		let isDayBg = true;
		
		function autoToggleBg() {

			weatherData = weather.getForecastWeather();
			sunData = weatherData.tideData;
			if (sunData.count > 0){
				today = sunData.data[0];
				sunriseMins = today.sunrise.hour * 60 + today.sunrise.minute;
				sunsetMins = today.sunset.hour * 60 + today.sunset.minute;
			} else {
				sunriseMins = sunriseMins_def;
				sunsetMins = sunsetMins_def;
			}

			curMins = curTime.hour * 60 + curTime.minute;
			let isDayNow = (curMins >= sunriseMins) && (curMins < sunsetMins);
			
			if(isDayNow){
				if(!isDayBg){
					icon_bg.setProperty(hmUI.prop.SRC, "day.png");
					isDayBg = true;
				}
			} else {
				if(isDayBg){
					icon_bg.setProperty(hmUI.prop.SRC, "night.png");
					isDayBg = false;
				}
			}
		}
		
		
         let weatherArrayGrafik = [] 
         let weatherIconImgArrayGrafik = [] 
    		let weatherTxtImgArray = []
    		let weatherTxtImgArrayN = []
    		let pointred = new Array(6);
    		let pointblue = new Array(5);
    		let linered = new Array(6);
    		let lineblue = new Array(5);
    		let yArrH = new Array(6);
    		let yArrL = new Array(5);
    		let y_pogodaH = new Array(6);
    		let y_pogodaL = new Array(5);
    		let week_weater = ["MO", "TU", "WE", "TH", "FR", "SA", "SU"];
    		let week_weater_img = []
    		let day_weater_img = []
    		const ROOTPATH = "images/"
		 
  		      
    		for (var i = 0; i <= 28; i++) {
          weatherArrayGrafik.push(ROOTPATH + "Grafik/weather/" + i + ".png"); //0-28

    		}


    		          
    		function updateGrafik() {
				
//       weatherData = weather.getForecastWeather();
//       forecastData = weatherData.forecastData;
      // normal_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);
				
				
				
				
    			if (forecastData.count == 0) {
    				for (let i = 0; i < 6; i++) {
    					var invalidPath = "--";
            weatherIconImgArrayGrafik[i].setProperty(hmUI.prop.SRC, ROOTPATH + "Grafik/weather/25.png");

    				}
    			} else {
    				let weekDay = curTime.week - 1;
    				for (let i = 0; i < 6; i++) {
    					yArrH[i] = forecastData.data[i].high;
    					let element = forecastData.data[i];
    					let iconIndex = element.index;
            weatherIconImgArrayGrafik[i].setProperty(hmUI.prop.SRC, weatherArrayGrafik[iconIndex]);
    					let date = new Date(curTime.utc + 86400000 * i);
    					let data = date.getDate();
    					let week = week_weater[weekDay];
    					week_weater_img[i].setProperty(hmUI.prop.MORE, {
    						color: weekDay < 5 ? "0xFFFFFFFF" : "0xFFFF0000",
    						text: week,
    					});
    					day_weater_img[i].setProperty(hmUI.prop.MORE, {
    						color: weekDay < 5 ? "0xFFFFFFFF" : "0xFFFF0000",
    						text: data,
    					});
    					weekDay = (weekDay + 1) % 7;
    				}
    			}


    			for (let i = 0; i < 5; i++) {
    				yArrL[i] = forecastData.data[i].low;
    			}
    			let maxH = Math.max(...yArrH)
    			let maxL = Math.min(...yArrL)
    			var shag = 46;
    			var x0 = 119;
    			for (let i = 0; i < 6; i++) {
    				pointred[i].setProperty(hmUI.prop.MORE, {
    					x: 119 + shag * [i] - 5,
    					y: (yArrH[i] * (120 / (maxL - maxH)) + 169 - 27 - maxH * (120 / (maxL - maxH))) - 5,
    					w: 10,
    					h: 10,
    					start_angle: -90,
    					end_angle: 270,
    					color: 0xFFFF0000,
    					line_width: 10,
    				});
    			};

    			for (let i = 0; i < 5; i++) {
    				yyyyy1 = (yArrH[i] * (120 / (maxL - maxH)) + 169 - 27 - maxH * (120 / (maxL - maxH))) - 5,
    					yyyyy2 = (yArrH[i + 1] * (120 / (maxL - maxH)) + 169 - 27 - maxH * (120 / (maxL - maxH))) - 5,
    					linered[i].setProperty(hmUI.prop.MORE, {
    						x: 0,
    						y: 0,
    						w: 164 + shag * i,
    						h: 466,
    						pos_x: -31 + shag * i,
    						pos_y: yyyyy1 + 2,
    						center_x: 119 + shag * i,
    						center_y: yyyyy1,
    						angle: Math.atan((yyyyy2 - yyyyy1) / shag) * 180 / Math.PI,
						src: ROOTPATH + 'Grafik/line_red.png',
    					});
    			};
    			for (let i = 0; i < 5; i++) {
    				pointblue[i].setProperty(hmUI.prop.MORE, {
    					x: 119 + 23 + shag * [i] - 5,
    					y: (yArrL[i] * (120 / (maxL - maxH)) + 169 - 27 - maxH * (120 / (maxL - maxH))) - 5,
    					w: 10,
    					h: 10,
    					start_angle: -90,
    					end_angle: 270,
    					color: 0xFF00eaff,
    					line_width: 10,
    				});
    			};

    			for (let i = 0; i < 4; i++) {
    				yyyyy1 = (yArrL[i] * (120 / (maxL - maxH)) + 169 - 27 - maxH * (120 / (maxL - maxH))) - 5,
    					yyyyy2 = (yArrL[i + 1] * (120 / (maxL - maxH)) + 169 - 27 - maxH * (120 / (maxL - maxH))) - 5,
    					lineblue[i].setProperty(hmUI.prop.MORE, {
    						x: 0,
    						y: 0,
    						w: 164 + shag * i + 23,
    						h: 466,
    						pos_x: -31 + shag * i + 23,
    						pos_y: yyyyy1 + 2,
    						center_x: 119 + shag * i + 23,
    						center_y: yyyyy1,
    						angle: Math.atan((yyyyy2 - yyyyy1) / shag) * 180 / Math.PI,
						src: ROOTPATH + 'Grafik/line_blue.png',
    					});
    			};

    			for (let i = 0; i < 5; i++) {
    				pointblue[i].setProperty(hmUI.prop.MORE, {
    					x: 119 + 23 + shag * [i] - 5,
    					y: (yArrL[i] * (120 / (maxL - maxH)) + 169 - 27 - maxH * (120 / (maxL - maxH))) - 5,
    					w: 10,
    					h: 10,
    					start_angle: -90,
    					end_angle: 270,
    					color: 0xFF00eaff,
    					line_width: 10,
    				});
    			};

    			for (let i = 0; i < 6; i++) {
    				y_pogodaH[i] = (yArrH[i] * (120 / (maxL - maxH)) + 169 - 24 - maxH * (120 / (maxL - maxH))) - 5;
    				weatherTxtImgArray[i].setProperty(hmUI.prop.more, {
    					x: 96 - 5 + i * 45 * 1.02,
    					y: y_pogodaH[i] - 38, //120-7
    					w: 50,
    					h: 40,
    					color: "0xFFffffff",
    					text_size: 27,
    					text: yArrH[i],
    					text_style: hmUI.text_style.NONE,
    					align_h: hmUI.align.CENTER_H,
    					align_v: hmUI.align.CENTER_V,
    					show_level: hmUI.show_level.ONLY_NORMAL
    				});
    			}

    			for (let i = 0; i < 5; i++) {
    				y_pogodaL[i] = (yArrL[i] * (120 / (maxL - maxH)) + 169 - 24 - maxH * (120 / (maxL - maxH))) - 5;;
    				weatherTxtImgArrayN[i].setProperty(hmUI.prop.more, {
    					x: 96 - 5 + 23 + i * 45 * 1.02,
    					y: y_pogodaL[i] - 1, //120-7
    					w: 50,
    					h: 40,
    					color: "0xFFffffff",
    					text_size: 27,
    					text: yArrL[i],
    					text_style: hmUI.text_style.NONE,
    					align_h: hmUI.align.CENTER_H,
    					align_v: hmUI.align.CENTER_V,
    					show_level: hmUI.show_level.ONLY_NORMAL
    				});
    			}
    		}


        //dynamic modify end
        
		__$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			icon_bg = hmUI.createWidget(hmUI.widget.IMG, {
              x: 200,
              y: 428,
			  src: 'day.png',
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});
			
			autoToggleBg();

            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 270,
              y: 19,
              src: 'lock.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 228,
              y: 19,
              src: 'bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 185,
              y: 20,
              src: 'alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 36,
              y: 196,
              week_en: ["week_0.png","week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png"],
              week_tc: ["week_0.png","week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png"],
              week_sc: ["week_0.png","week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			normal_date_img_date_week_img_1 = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 36,
              y: 196,
              week_en: ["weekru_0.png","weekru_1.png","weekru_2.png","weekru_3.png","weekru_4.png","weekru_5.png","weekru_6.png"],
              week_tc: ["weekru_0.png","weekru_1.png","weekru_2.png","weekru_3.png","weekru_4.png","weekru_5.png","weekru_6.png"],
              week_sc: ["weekru_0.png","weekru_1.png","weekru_2.png","weekru_3.png","weekru_4.png","weekru_5.png","weekru_6.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 36,
              month_startY: 270,
              month_sc_array: ["month_0.png","month_1.png","month_2.png","month_3.png","month_4.png","month_5.png","month_6.png","month_7.png","month_8.png","month_9.png","month_10.png","month_11.png"],
              month_tc_array: ["month_0.png","month_1.png","month_2.png","month_3.png","month_4.png","month_5.png","month_6.png","month_7.png","month_8.png","month_9.png","month_10.png","month_11.png"],
              month_en_array: ["month_0.png","month_1.png","month_2.png","month_3.png","month_4.png","month_5.png","month_6.png","month_7.png","month_8.png","month_9.png","month_10.png","month_11.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			normal_date_img_date_month_img_1 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 36,
              month_startY: 270,
              month_sc_array: ["monthru_0.png","monthru_1.png","monthru_2.png","monthru_3.png","monthru_4.png","monthru_5.png","monthru_6.png","monthru_7.png","monthru_8.png","monthru_9.png","monthru_10.png","monthru_11.png"],
              month_tc_array: ["monthru_0.png","monthru_1.png","monthru_2.png","monthru_3.png","monthru_4.png","monthru_5.png","monthru_6.png","monthru_7.png","monthru_8.png","monthru_9.png","monthru_10.png","monthru_11.png"],
              month_en_array: ["monthru_0.png","monthru_1.png","monthru_2.png","monthru_3.png","monthru_4.png","monthru_5.png","monthru_6.png","monthru_7.png","monthru_8.png","monthru_9.png","monthru_10.png","monthru_11.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 40,
              day_startY: 226,
              day_sc_array: ["data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png","data_10.png"],
              day_tc_array: ["data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png","data_10.png"],
              day_en_array: ["data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png","data_10.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_uvi_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'dot.png',
              center_x: 377,
              center_y: 105,
              x: 7,
              y: 34,
              start_angle: 0,
              end_angle: 360,
              invalid_visible: false,
              type: hmUI.data_type.UVI,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_aqi_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 260,
              y: 118,
              font_array: ["data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png","data_10.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.AQI,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altitude_target_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 212,
              y: 119,
              src: 'free-icon-leaf-8384615.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 252,
              y: 118,
              font_array: ["data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png","data_10.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 210,
              y: 118,
              src: 'pb_list_icon_altitude.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_direction_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 209,
              y: 117,
              image_array: ["weather_icon_wind_1.png","weather_icon_wind_2.png","weather_icon_wind_3.png","weather_icon_wind_4.png","weather_icon_wind_5.png","weather_icon_wind_6.png","weather_icon_wind_7.png","weather_icon_wind_8.png"],
              image_length: 8,
              type: hmUI.data_type.WIND_DIRECTION,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 255,
              y: 119,
              font_array: ["data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png","data_10.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'ws.png',
              unit_tc: 'ws.png',
              unit_en: 'ws.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WIND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 255,
              y: 118,
              font_array: ["data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png","data_10.png"],
              padding: false,
              h_space: 0,
              unit_sc: '%.png',
              unit_tc: '%.png',
              unit_en: '%.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 207,
              y: 115,
              src: 'humidity.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 108,
              y: 65,
              image_array: ["w_1.png","w_2.png","w_3.png","w_4.png","w_5.png","w_6.png","w_7.png","w_8.png","w_9.png","w_10.png","w_11.png","w_12.png","w_13.png","w_14.png","w_15.png","w_16.png","w_17.png","w_18.png","w_19.png","w_20.png","w_21.png","w_22.png","w_23.png","w_24.png","w_25.png","w_26.png","w_27.png","w_28.png","w_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 260,
              y: 65,
              font_array: ["data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png","data_10.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'grad.png',
              unit_tc: 'grad.png',
              unit_en: 'grad.png',
              negative_image: 'minus.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 377,
              // center_y: 374,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 29,
              // line_width: 5,
              // line_cap: Flat,
              // color: 0xFF00D535,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            let screenType = hmSetting.getScreenType();
            normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 377,
              center_y: 374,
              start_angle: 0,
              end_angle: 360,
              radius: 27,
              line_width: 5,
              corner_flag: 3,
              color: 0xFF00D535,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 262,
              y: 385,
              font_array: ["data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png","data_10.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 205,
              y: 382,
              image_array: ["heart_0.png","heart_1.png","heart_2.png","heart_3.png","heart_4.png","heart_5.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 249,
              y: 335,
              font_array: ["data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png","data_10.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 86,
              hour_startY: 181,
              hour_array: ["time_0.png","time_1.png","time_2.png","time_3.png","time_4.png","time_5.png","time_6.png","time_7.png","time_8.png","time_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_unit_sc: 'colon.png',
              hour_unit_tc: 'colon.png',
              hour_unit_en: 'colon.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 250,
              minute_startY: 181,
              minute_array: ["time_0.png","time_1.png","time_2.png","time_3.png","time_4.png","time_5.png","time_6.png","time_7.png","time_8.png","time_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 398,
              second_startY: 226,
              second_array: ["data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png","data_10.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_second_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 393,
              y: 196,
              src: 'sec.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 86,
              hour_startY: 181,
              hour_array: ["time_0.png","time_1.png","time_2.png","time_3.png","time_4.png","time_5.png","time_6.png","time_7.png","time_8.png","time_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_unit_sc: 'colon.png',
              hour_unit_tc: 'colon.png',
              hour_unit_en: 'colon.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 250,
              minute_startY: 181,
              minute_array: ["time_0.png","time_1.png","time_2.png","time_3.png","time_4.png","time_5.png","time_6.png","time_7.png","time_8.png","time_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');
			
			function get_values (){
				valueBattery = battery.current; 
			}

			get_values ();
			
			battery.addEventListener(hmSensor.event.CHANGE, function () {
              get_values();
            });

            btn_bezel = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 115,
              y: 205,
              text: '',
              w: 75,
              h: 80,
              normal_src: 'Empty.png',
              press_src: 'Empty.png',
              click_func: () => {
                  click_Bezel();
                  vibro();
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btn_bezel.setProperty(hmUI.prop.VISIBLE, true);

            batteryInfo_click = hmUI.createWidget(hmUI.widget.BUTTON, {
          x: 345,
          y: 342,
          w: 65,
          h: 65,
          text: '',
          normal_src: 'Empty.png',
          press_src: 'Empty.png',
          click_func: () => {
            vibro();
			hmUI.showToast({ text: 'Battery is ' + valueBattery + ' %' });
          },
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 103,
              y: 63,
              w: 87,
              h: 85,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            btn_zona1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 220,
              y: 115,
              text: '',
              w: 90,
              h: 45,
              normal_src: 'Empty.png',
              press_src: 'Empty.png',
              click_func: () => {
				click_zona1();
                vibro();
				click_Vibrate();
             },
			  longpress_func: () => {
             hmApp.startApp({ url: "BaroAltimeterScreen", native: true });
             },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btn_zona1.setProperty(hmUI.prop.VISIBLE, true);
			normal_wind_direction_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
			normal_wind_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_altimeter_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_altimeter_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_aqi_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_altitude_target_separator_img.setProperty(hmUI.prop.VISIBLE, false);

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 250,
              y: 320,
              w: 80,
              h: 50,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if (scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro() {
              vibrate.stop();
              if (timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }
			
			function click_Pogoda_on() {
          groupPogoda.setProperty(hmUI.prop.VISIBLE, true);
         }

         function click_Pogoda_off() {
          groupPogoda.setProperty(hmUI.prop.VISIBLE, false);
         }

            // end vibrate function
			
			let gr_panels = hmUI.createWidget(hmUI.widget.GROUP, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
            });
            gr_panels.setProperty(hmUI.prop.VISIBLE, false);

            let gr_panels_fill = gr_panels.createWidget(hmUI.widget.FILL_RECT, {
              x: 70,
              y: 70,
              w: 466 - 140,
              h: 466 - 140,
              color: '0xAA211d1e',
              radius: 20,
              alpha: 220,
              show_level:

                hmUI.show_level.ONLY_NORMAL,
            });

            //кнопка 1
            gr_panels.createWidget(hmUI.widget.BUTTON, {
              x: 100,
              y: 100,
              w: 70,
              h: 70,
              text: '',
              normal_src: 'phone.png',
              press_src: 'phone.png',
              click_func: () => {
                vibro();
                hmApp.startApp({
                  appid: 1,
                  url: 'PhoneRecentCallScreen',
                  native: true
                });
                //запуск приложения 1

              },
              longpress_func: () => {
               hmApp.startApp({ url: "PhoneContactsScreen", native: true });
              },

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            //кнопка 2
            gr_panels.createWidget(hmUI.widget.BUTTON, {
              x: 200,
              y: 100,
              w: 70,
              h: 70,
              text: '',
              normal_src: 'music.png',
              press_src: 'music.png',
              click_func: () => {
                vibro();
                hmApp.startApp({
                  appid: 1,
                  url: 'LocalMusicScreen',
                  native: true
                });
                //запуск приложения 2

              },
              longpress_func: () => {
               hmApp.startApp({ url: "PhoneMusicCtrlScreen", native: true });

              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            //кнопка 3
            gr_panels.createWidget(hmUI.widget.BUTTON, {
              x: 300,
              y: 100,
              w: 70,
              h: 70,
              text: '',
              normal_src: 'voicememo.png',
              press_src: 'Empty.png',
              click_func: () => {
                vibro();
                hmApp.startApp({
                  appid: 1,
                  url: 'VoiceMemoScreen',
                  native: true
                });
                //запуск приложения 3

              },

              longpress_func: () => {

              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            gr_panels.createWidget(hmUI.widget.BUTTON, {
              x: 100,
              y: 200,
              w: 70,
              h: 70,
              text: '',
              normal_src: 'stopwatch.png',
              press_src: 'Empty.png',
              click_func: () => {
                vibro();
                hmApp.startApp({
                  appid: 1,
                  url: 'StopWatchScreen',
                  native: true
                });
                //запуск приложения 4

              },

              longpress_func: () => {

              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            gr_panels.createWidget(hmUI.widget.BUTTON, {
              x: 100,
              y: 300,
              w: 70,
              h: 70,
              text: '',
              normal_src: 'compass.png',
              press_src: 'Empty.png',
              click_func: () => {
                vibro();
                hmApp.startApp({
                  appid: 1,
                  url: 'CompassScreen',
                  native: true
                });
                //запуск приложения 5

              },

              longpress_func: () => {

              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            gr_panels.createWidget(hmUI.widget.BUTTON, {
              x: 200,
              y: 200,
              w: 70,
              h: 70,
              text: '',
              normal_src: 'countdown.png',
              press_src: 'Empty.png',
              click_func: () => {
                vibro();
                hmApp.startApp({
                  appid: 1,
                  url: 'CountdownAppScreen',
                  native: true
                });
                //запуск приложения 6

              },

              longpress_func: () => {

              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            gr_panels.createWidget(hmUI.widget.BUTTON, {
              x: 200,
              y: 300,
              w: 70,
              h: 70,
              text: '',
              normal_src: 'measurement.png',
              press_src: 'Empty.png',
              click_func: () => {
                vibro();
                hmApp.startApp({
                  appid: 1,
                  url: 'oneKeyAppScreen',
                  native: true
                });
                //запуск приложения 7

              },

              longpress_func: () => {

              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            gr_panels.createWidget(hmUI.widget.BUTTON, {
              x: 300,
              y: 300,
              w: 70,
              h: 70,
              text: '',
              normal_src: 'setting.png',
              press_src: 'setting.png',
              click_func: () => {
                vibro();
                hmApp.startApp({
                  appid: 1,
                  url: 'Settings_homeScreen',
                  native: true
                });
                //запуск приложения 8

              },

              longpress_func: () => {
               hmApp.startApp({ url: "Settings_batteryManagerScreen", native: true });
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            gr_panels.createWidget(hmUI.widget.BUTTON, {
              x: 300,
              y: 200,
              w: 70,
              h: 70,
              text: '',
              normal_src: 'sport.png',
              press_src: 'sport.png',
              click_func: () => {
                vibro();
                hmApp.startApp({
                  appid: 1,
                  url: 'SportListScreen',
                  native: true
                });
                //запуск приложения 9

              },

              longpress_func: () => {
               hmApp.startApp({ url: "SportRecordListScreen", native: true });
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            
            let panel_visible = false;
            
            gr_panels.createWidget(hmUI.widget.BUTTON, {
              x: 365,
              y: 55,
              w: 50,
              h: 50,
              radius: 25,
              text: 'X',
              normal_color: 0x992255,
              press_color: 0xfeb4a8,
              click_func: () => {

                vibro(24);
                panel_visible = !panel_visible;
                gr_panels.setProperty(hmUI.prop.VISIBLE, panel_visible);
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

           
            hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 103,
              y: 333,
              w: 80,
              h: 80,
              text: '',
              normal_src: 'Empty.png',
              press_src: 'Empty.png',
              click_func: () => {
                vibro();
                panel_visible = !panel_visible;
                gr_panels.setProperty(hmUI.prop.VISIBLE, panel_visible);
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			let gr_panel = hmUI.createWidget(hmUI.widget.GROUP, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
            });
            gr_panel.setProperty(hmUI.prop.VISIBLE, false);

            let gr_panel_fill = gr_panel.createWidget(hmUI.widget.FILL_RECT, {
              x: 70,
              y: 230,
              w: 466 - 140,
              h: 200 - 70,
              color: '0xAA211d1e',
              radius: 20,
              alpha: 220,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            gr_panel.createWidget(hmUI.widget.IMG, {
              x: 100,
              y: 230,
              src: 'HeartBg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            gr_panel.createWidget(hmUI.widget.GRADKIENT_POLYLINE, {
              x: 100,
              y: 275,
              w: 250,
              h: 63,
              line_color: 0xcc2124,
              line_width: 3,
              curve_style: true,
              type: hmUI.data_type.HEART
            });

            
            hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 254,
              y: 377,
              w: 75,
              h: 50,
              text: '',
              normal_src: 'Empty.png',
              press_src: 'Empty.png',
              click_func: () => {

                vibro(24);
                panel_visible = !panel_visible;
                gr_panel.setProperty(hmUI.prop.VISIBLE, panel_visible);
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			groupVremya = hmUI.createWidget(hmUI.widget.GROUP, {
           x: 0,
           y: 0,
           w: 466,
           h: 466,
          });//
			
			btn_str = groupVremya.createWidget(hmUI.widget.BUTTON, {
           x: 200, //x кнопки
           y: 433, //y кнопки
           text: '',
           w: 85, //ширина кнопки
           h: 50, //высота кнопки
           normal_src: 'Empty.png',
           press_src: 'Empty.png',
           click_func: () => {
            vibro();
            click_Pogoda_on();
           },
//           longpress_func: () => {
//            vibro();
//			   blok_btn_on();
//           },
           show_level: hmUI.show_level.ONLY_NORMAL,
          });
			
			groupPogoda = hmUI.createWidget(hmUI.widget.GROUP, {
           x: 0,
           y: 20,
           w: 466,
           h: 466,
          });

          // фон
          groupPogoda.createWidget(hmUI.widget.IMG, {
           x: 62,
           y: 71,
           w: 343,
           h: 323,
           src: ROOTPATH + 'Grafik/Grafik_bg.png',
           //alpha: 153,
           show_level: hmUI.show_level.ONLY_NORMAL,
          });


          for (var i = 0; i < 6; i++) {
           week_weater_img[i] = groupPogoda.createWidget(hmUI.widget.TEXT, {
            x: 93 + i * 46 * 1.0, //,107 + i * 45 * 1.02,
            y: 295 - 21 + 2,
            w: 50,
            h: 50,
            char_space: 0, //-1
            line_space: 0,
            color: "0xFFffffff",
            text: week_weater[i],
            text_size: 22,
            text_style: hmUI.text_style.NONE,
            align_h: hmUI.align.CENTER_H,
            align_v: hmUI.align.CENTER_V,
            show_level: hmUI.show_level.ONLY_NORMAL
           });

           hmUI.deleteWidget(day_weater_img[i]);

           day_weater_img[i] = groupPogoda.createWidget(hmUI.widget.TEXT, {
            x: 93 + i * 46 * 1.0, //,107 + i * 45 * 1.02,
            y: 295 - 21 + 2 + 20,
            w: 50,
            h: 50,
            char_space: 0, //-1
            line_space: 0,
            color: "0xFFffffff",
            text: 31,
            text_size: 22,
            text_style: hmUI.text_style.NONE,
            align_h: hmUI.align.CENTER_H,
            align_v: hmUI.align.CENTER_V,
            show_level: hmUI.show_level.ONLY_NORMAL
           });

           weatherIconImgArrayGrafik[i] = groupPogoda.createWidget(hmUI.widget.IMG, {
            x: 98 + i * 45 * 1.02,
            y: 78,
            w: 40,
            h: 40,
            // src: weatherArray[i],
            shortcut: true,
            show_level: hmUI.show_level.ONLY_NORMAL,
           });

          }


          for (var i = 0; i < 6; i++) {
           hmUI.deleteWidget(linered[i]);
           linered[i] = groupPogoda.createWidget(hmUI.widget.IMG);
           hmUI.deleteWidget(pointred[i]);
           pointred[i] = groupPogoda.createWidget(hmUI.widget.ARC);
           hmUI.deleteWidget(weatherTxtImgArray[i]);
           weatherTxtImgArray[i] = groupPogoda.createWidget(hmUI.widget.TEXT);
          }
          for (var i = 0; i < 5; i++) {
           hmUI.deleteWidget(lineblue[i]);
           lineblue[i] = groupPogoda.createWidget(hmUI.widget.IMG);
           hmUI.deleteWidget(pointblue[i]);
           pointblue[i] = groupPogoda.createWidget(hmUI.widget.ARC);
           hmUI.deleteWidget(weatherTxtImgArrayN[i]);
           weatherTxtImgArrayN[i] = groupPogoda.createWidget(hmUI.widget.TEXT);
          }
                    
                    
          btn_Pogoda_off = groupPogoda.createWidget(hmUI.widget.BUTTON, {
           x: 200, //x кнопки
           y: 433, //y кнопки
           text: '',
           w: 85, //ширина кнопки
           h: 50, //высота кнопки
           normal_src: 'Empty.png',
           press_src: 'Empty.png',
           click_func: () => {
            vibro(); //имя вызываемой функции
            click_Pogoda_off();
           },
           //           longpress_func: () => {
           //            vibro();
           //			   blok_btn_off();
           //           },
           show_level: hmUI.show_level.ONLY_NORMAL,
          });
		  groupPogoda.setProperty(hmUI.prop.VISIBLE, false);
		  
		  btn_zona2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 25,
              y: 190,
              text: '',
              w: 60,
              h: 100,
              normal_src: 'Empty.png',
              press_src: 'Empty.png',
              click_func: () => {
				click_zona2();
                vibro();
				click_Vibrate();
             },
			  longpress_func: () => {
             hmApp.startApp({ url: "ScheduleCalScreen", native: true });
             },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btn_zona2.setProperty(hmUI.prop.VISIBLE, true);
			normal_date_img_date_week_img_1.setProperty(hmUI.prop.VISIBLE, false);
			normal_date_img_date_month_img_1.setProperty(hmUI.prop.VISIBLE, false);
		  

            function scale_call() {
              console.log('scale_call()');

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_cs_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_battery * 100);
                  if (normal_battery_circle_scale) {
                    normal_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 377,
                      center_y: 374,
                      start_angle: 0,
                      end_angle: 360,
                      radius: 27,
                      line_width: 5,
                      corner_flag: 3,
                      color: 0xFF00D535,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                autoToggleBg();
				updateGrafik();
				scale_call();
              }),
			  
			pause_call: (function () {
				groupVremya.setProperty(hmUI.prop.VISIBLE, true);
                groupPogoda.setProperty(hmUI.prop.VISIBLE, false);

              }),
            });  

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
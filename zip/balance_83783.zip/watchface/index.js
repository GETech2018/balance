﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg = ''
        let normal_frame_animation_1 = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_month_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_text_separator_img = ''
        let normal_digital_clock_img_time = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_frame_animation_1 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
              x: 0,
              y: 0,
              anim_path: "animation",
              anim_ext: "png",
              anim_prefix: "anim1",
              anim_fps: 30,
              anim_size: 40,
              repeat_count: 0,
              anim_repeat: true,
              anim_status:hmUI.anim_status.START,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 390,
              y: 208,
              font_array: ["bat_num_0.png","bat_num_1.png","bat_num_2.png","bat_num_3.png","bat_num_4.png","bat_num_5.png","bat_num_6.png","bat_num_7.png","bat_num_8.png","bat_num_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'bat_percent.png',
              unit_tc: 'bat_percent.png',
              unit_en: 'bat_percent.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 381,
              y: 240,
              image_array: ["BATT (01).png","BATT (02).png","BATT (03).png","BATT (04).png","BATT (05).png","BATT (06).png","BATT (07).png","BATT (08).png"],
              image_length: 8,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 98,
              y: 361,
              week_en: ["Sem01.png","Sem02.png","Sem03.png","Sem04.png","Sem05.png","Sem06.png","Sem07.png"],
              week_tc: ["Sem01.png","Sem02.png","Sem03.png","Sem04.png","Sem05.png","Sem06.png","Sem07.png"],
              week_sc: ["Sem01.png","Sem02.png","Sem03.png","Sem04.png","Sem05.png","Sem06.png","Sem07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 186,
              month_startY: 401,
              month_sc_array: ["steps_num_0.png","steps_num_1.png","steps_num_2.png","steps_num_3.png","steps_num_4.png","steps_num_5.png","steps_num_6.png","steps_num_7.png","steps_num_8.png","steps_num_9.png"],
              month_tc_array: ["steps_num_0.png","steps_num_1.png","steps_num_2.png","steps_num_3.png","steps_num_4.png","steps_num_5.png","steps_num_6.png","steps_num_7.png","steps_num_8.png","steps_num_9.png"],
              month_en_array: ["steps_num_0.png","steps_num_1.png","steps_num_2.png","steps_num_3.png","steps_num_4.png","steps_num_5.png","steps_num_6.png","steps_num_7.png","steps_num_8.png","steps_num_9.png"],
              month_zero: 1,
              month_space: 2,
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 230,
              month_startY: 402,
              month_sc_array: ["ANN01.png","ANN02.png","ANN03.png","ANN04.png","ANN05.png","ANN06.png","ANN07.png","ANN08.png","ANN09.png","ANN10.png","ANN11.png","ANN12.png"],
              month_tc_array: ["ANN01.png","ANN02.png","ANN03.png","ANN04.png","ANN05.png","ANN06.png","ANN07.png","ANN08.png","ANN09.png","ANN10.png","ANN11.png","ANN12.png"],
              month_en_array: ["ANN01.png","ANN02.png","ANN03.png","ANN04.png","ANN05.png","ANN06.png","ANN07.png","ANN08.png","ANN09.png","ANN10.png","ANN11.png","ANN12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 43,
              y: 281,
              font_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 50,
              y: 243,
              src: 'CO.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 100,
              hour_startY: 200,
              hour_array: ["0002.png","0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 235,
              minute_startY: 200,
              minute_array: ["0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 369,
              second_startY: 310,
              second_array: ["steps_num_0.png","steps_num_1.png","steps_num_2.png","steps_num_3.png","steps_num_4.png","steps_num_5.png","steps_num_6.png","steps_num_7.png","steps_num_8.png","steps_num_9.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 49,
              y: 165,
              font_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'font_13.png',
              unit_tc: 'font_13.png',
              unit_en: 'font_13.png',
              negative_image: 'font_14.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 53,
              y: -10,
              image_array: ["WEA01.png","WEA02.png","WEA03.png","WEA04.png","WEA05.png","WEA06.png","WEA07.png","WEA08.png","WEA09.png","WEA10.png","WEA11.png","WEA12.png","WEA13.png","WEA14.png","WEA15.png","WEA16.png","WEA17.png","WEA18.png","WEA19.png","WEA20.png","WEA21.png","WEA22.png","WEA23.png","WEA24.png","WEA25.png","WEA26.png","WEA27.png","WEA28.png","WEA29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);

              }),
              pause_call: (function () {
                console.log('pause_call()');
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
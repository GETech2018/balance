﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_uvi_icon_img = ''
        let normal_uvi_text_text_img = ''
        let normal_spo2_text_text_img = ''
        let normal_spo2_text_separator_img = ''
        let normal_distance_text_text_img = ''
        let normal_distance_text_separator_img = ''
        let normal_step_icon_img = ''
        let normal_step_current_text_img = ''
        let normal_date_img_date_month = ''
        let normal_date_month_separator_img = ''
        let normal_date_img_date_day = ''
        let normal_temperature_current_text_img = ''
        let normal_temperature_current_separator_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_date_img_date_week_img = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_heart_rate_text_text_img = ''
        let normal_stress_image_progress_img_level = ''
        let normal_battery_icon_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_battery_image_progress_img_progress = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: '0001.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_uvi_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 170,
              y: 118,
              src: 'UV2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_uvi_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 162,
              y: 142,
              font_array: ["SMALL_(01).png","SMALL_(02).png","SMALL_(03).png","SMALL_(04).png","SMALL_(05).png","SMALL_(06).png","SMALL_(07).png","SMALL_(08).png","SMALL_(09).png","SMALL_(10).png"],
              padding: false,
              h_space: -1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.UVI,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 363,
              y: 341,
              font_array: ["SMALL (01).png","SMALL (02).png","SMALL (03).png","SMALL (04).png","SMALL (05).png","SMALL (06).png","SMALL (07).png","SMALL (08).png","SMALL (09).png","SMALL (10).png"],
              padding: false,
              h_space: 0,
              unit_sc: 'D (31).png',
              unit_tc: 'D (31).png',
              unit_en: 'D (31).png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 299,
              y: 333,
              src: 'spo2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 346,
              y: 302,
              font_array: ["SMALL (01).png","SMALL (02).png","SMALL (03).png","SMALL (04).png","SMALL (05).png","SMALL (06).png","SMALL (07).png","SMALL (08).png","SMALL (09).png","SMALL (10).png"],
              padding: false,
              h_space: 0,
              unit_sc: 'NUM2_(11).png',
              unit_tc: 'NUM2_(11).png',
              unit_en: 'NUM2_(11).png',
              dot_image: 'SMALL_(25).png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 302,
              y: 294,
              src: 'Km1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 298,
              y: 247,
              src: 'walk2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 364,
              y: 262,
              font_array: ["SMALL (01).png","SMALL (02).png","SMALL (03).png","SMALL (04).png","SMALL (05).png","SMALL (06).png","SMALL (07).png","SMALL (08).png","SMALL (09).png","SMALL (10).png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 239,
              month_startY: 22,
              month_sc_array: ["NUM2_(01).png","NUM2_(02).png","NUM2_(03).png","NUM2_(04).png","NUM2_(05).png","NUM2_(06).png","NUM2_(07).png","NUM2_(08).png","NUM2_(09).png","NUM2_(10).png"],
              month_tc_array: ["NUM2_(01).png","NUM2_(02).png","NUM2_(03).png","NUM2_(04).png","NUM2_(05).png","NUM2_(06).png","NUM2_(07).png","NUM2_(08).png","NUM2_(09).png","NUM2_(10).png"],
              month_en_array: ["NUM2_(01).png","NUM2_(02).png","NUM2_(03).png","NUM2_(04).png","NUM2_(05).png","NUM2_(06).png","NUM2_(07).png","NUM2_(08).png","NUM2_(09).png","NUM2_(10).png"],
              month_zero: 1,
              month_space: -3,
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_month_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 228,
              y: 22,
              src: 'NUM2_(00).png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 133,
              day_startY: 22,
              day_sc_array: ["NUM2_(01).png","NUM2_(02).png","NUM2_(03).png","NUM2_(04).png","NUM2_(05).png","NUM2_(06).png","NUM2_(07).png","NUM2_(08).png","NUM2_(09).png","NUM2_(10).png"],
              day_tc_array: ["NUM2_(01).png","NUM2_(02).png","NUM2_(03).png","NUM2_(04).png","NUM2_(05).png","NUM2_(06).png","NUM2_(07).png","NUM2_(08).png","NUM2_(09).png","NUM2_(10).png"],
              day_en_array: ["NUM2_(01).png","NUM2_(02).png","NUM2_(03).png","NUM2_(04).png","NUM2_(05).png","NUM2_(06).png","NUM2_(07).png","NUM2_(08).png","NUM2_(09).png","NUM2_(10).png"],
              day_zero: 1,
              day_space: -3,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 101,
              y: 193,
              font_array: ["SMALL_(01).png","SMALL_(02).png","SMALL_(03).png","SMALL_(04).png","SMALL_(05).png","SMALL_(06).png","SMALL_(07).png","SMALL_(08).png","SMALL_(09).png","SMALL_(10).png"],
              padding: false,
              h_space: 0,
              unit_sc: 'SMALL_(12).png',
              unit_tc: 'SMALL_(12).png',
              unit_en: 'SMALL_(12).png',
              negative_image: 'SMALL_(11).png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'SMALL_(25).png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 47,
              y: 109,
              image_array: ["Weather (01).png","Weather (02).png","Weather (03).png","Weather (04).png","Weather (05).png","Weather (06).png","Weather (07).png","Weather (08).png","Weather (09).png","Weather (10).png","Weather (11).png","Weather (12).png","Weather (13).png","Weather (14).png","Weather (15).png","Weather (16).png","Weather (17).png","Weather (18).png","Weather (19).png","Weather (20).png","Weather (21).png","Weather (22).png","Weather (23).png","Weather (24).png","Weather (25).png","Weather (26).png","Weather (27).png","Weather (28).png","Weather (29).png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 124,
              y: 76,
              week_en: ["weekday_01.png","weekday_02.png","weekday_03.png","weekday_04.png","weekday_05.png","weekday_06.png","weekday_07.png"],
              week_tc: ["weekday_01.png","weekday_02.png","weekday_03.png","weekday_04.png","weekday_05.png","weekday_06.png","weekday_07.png"],
              week_sc: ["weekday_01.png","weekday_02.png","weekday_03.png","weekday_04.png","weekday_05.png","weekday_06.png","weekday_07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 199,
              y: 109,
              image_array: ["HEART_(01).png","HEART_(02).png","HEART_(03).png","HEART_(04).png","HEART_(05).png","HEART_(06).png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 232,
              y: 161,
              font_array: ["SMALL (01).png","SMALL (02).png","SMALL (03).png","SMALL (04).png","SMALL (05).png","SMALL (06).png","SMALL (07).png","SMALL (08).png","SMALL (09).png","SMALL (10).png"],
              padding: false,
              h_space: -3,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 310,
              y: 109,
              image_array: ["Strss_(01).png","Strss_(02).png","Strss_(03).png","Strss_(04).png","Strss_(05).png","Strss_(06).png","Strss_(07).png","Strss_(08).png","Strss_(09).png","Strss_(10).png"],
              image_length: 10,
              type: hmUI.data_type.STRESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 28,
              y: 384,
              src: 'BAT_(00).png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 102,
              y: 400,
              image_array: ["BAT_(01).png","BAT_(02.png","BAT_(03).png","BAT_(04).png","BAT_(05).png","BAT_(06).png","BAT_(07).png","BAT_(08).png","BAT_(09).png","D (31).png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_progress = hmUI.createWidget(hmUI.widget.IMG_PROGRESS, {
              x: [220],
              y: [385],
              image_array: ["d120.png"],
              image_length: 1,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 44,
              hour_startY: 253,
              hour_array: ["NUM_00.png","NUM_01.png","NUM_02.png","NUM_03.png","NUM_04.png","NUM_05.png","NUM_06.png","NUM_07.png","NUM_08.png","NUM_09.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 173,
              minute_startY: 253,
              minute_array: ["NUM_00.png","NUM_01.png","NUM_02.png","NUM_03.png","NUM_04.png","NUM_05.png","NUM_06.png","NUM_07.png","NUM_08.png","NUM_09.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 141,
              second_startY: 354,
              second_array: ["SMALL (01).png","SMALL (02).png","SMALL (03).png","SMALL (04).png","SMALL (05).png","SMALL (06).png","SMALL (07).png","SMALL (08).png","SMALL (09).png","SMALL (10).png"],
              second_zero: 1,
              second_space: -2,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 134,
              y: 251,
              src: 'NUM_10.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
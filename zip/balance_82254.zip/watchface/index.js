﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

		let cc=0
		
		let element_index = 1;
        let element_count = 6;
		let button_content1 = ''
		let button_content2 = ''
		let button_content3 = ''
		let button_content4 = ''
		let button_content5 = ''
		let button_content6 = ''
		
		function SWITCH_CONTENT() {
        //    element_index++;
              if(element_index > element_count) element_index = 1;

              normal_fat_burning_icon_img.setProperty(hmUI.prop.VISIBLE, element_index == 1);
              normal_time_hour_text_font.setProperty(hmUI.prop.VISIBLE, element_index == 1);
			  normal_time_minute_text_font.setProperty(hmUI.prop.VISIBLE, element_index == 1);
			  normal_time_second_text_font.setProperty(hmUI.prop.VISIBLE, element_index == 1);
			  normal_digital_clock_img_time_AmPm.setProperty(hmUI.prop.VISIBLE, element_index == 1);

              normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, element_index == 2);
              normal_heart_rate_text_font.setProperty(hmUI.prop.VISIBLE, element_index == 2);
			  normal_spo2_current_text_font.setProperty(hmUI.prop.VISIBLE, element_index == 2);

              normal_battery_linear_scale.setProperty(hmUI.prop.VISIBLE, element_index == 3);
              normal_battery_icon_img.setProperty(hmUI.prop.VISIBLE, element_index == 3);
			  normal_battery_current_text_font.setProperty(hmUI.prop.VISIBLE, element_index == 3);
			  
			  normal_stand_icon_img.setProperty(hmUI.prop.VISIBLE, element_index == 4);
			  normal_year_text_font.setProperty(hmUI.prop.VISIBLE, element_index == 4);
			  normal_month_name_font.setProperty(hmUI.prop.VISIBLE, element_index == 4);
			  normal_dow_text_font.setProperty(hmUI.prop.VISIBLE, element_index == 4);
			  normal_day_text_font.setProperty(hmUI.prop.VISIBLE, element_index == 4);
			  
			  normal_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, element_index == 5);
			  normal_city_name_text.setProperty(hmUI.prop.VISIBLE, element_index == 5);
			  normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, element_index == 5);
			  normal_temperature_current_text_font.setProperty(hmUI.prop.VISIBLE, element_index == 5);
			  normal_temperature_high_text_font.setProperty(hmUI.prop.VISIBLE, element_index == 5);
			  normal_temperature_low_text_font.setProperty(hmUI.prop.VISIBLE, element_index == 5);
			  
			  normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, element_index == 6);
			  normal_calorie_current_text_font.setProperty(hmUI.prop.VISIBLE, element_index == 6);
			  normal_distance_current_text_font.setProperty(hmUI.prop.VISIBLE, element_index == 6);
			  normal_step_current_text_font.setProperty(hmUI.prop.VISIBLE, element_index == 6);
			  
        };
		
		function click_CONTENT1() {
            element_index=1;
			hmUI.showToast({text: 'T I M E'});
			SWITCH_CONTENT();
        }
		
		function click_CONTENT2() {
            element_index=2;
			hmUI.showToast({text: 'H E A R T'});
			SWITCH_CONTENT();
        }
		
		function click_CONTENT3() {
            element_index=3;
			hmUI.showToast({text: 'B A T T E R Y'});
			SWITCH_CONTENT();
        }
		
		function click_CONTENT4() {
            element_index=4;
			hmUI.showToast({text: 'D A T E'});
			SWITCH_CONTENT();
        }
		
		function click_CONTENT5() {
            element_index=5;
			hmUI.showToast({text: 'W E A T H E R'});
			SWITCH_CONTENT();
        }
		
		function click_CONTENT6() {
            element_index=6;
			hmUI.showToast({text: 'S T E P S'});
			SWITCH_CONTENT();
        }
		
		let colornumber_main = 1
		let totalcolors_main = 16
		let colorstring = '0xFFFF8000'
		let secstring = 'hand_sec1'
		let namecolor_main = ''
		let button_color1 = ''
		let button_color2 = ''
		let button_color3 = ''
		let button_color4 = ''
		let button_color5 = ''
		let button_color6 = ''
		let button_color7 = ''
		let button_color8 = ''
		let button_color9 = ''
		let button_color10 = ''
		let button_color11 = ''
		let button_color12 = ''
		let button_color13 = ''
		let button_color14 = ''
		let button_color15 = ''
		let button_color16 = ''
		
		function click_COLORSWITCH() {
			
			normal_stress_icon_img.setProperty(hmUI.prop.VISIBLE, true);
			button_color1.setProperty(hmUI.prop.VISIBLE, true);
			button_color2.setProperty(hmUI.prop.VISIBLE, true);
			button_color3.setProperty(hmUI.prop.VISIBLE, true);
			button_color4.setProperty(hmUI.prop.VISIBLE, true);
			button_color5.setProperty(hmUI.prop.VISIBLE, true);
			button_color6.setProperty(hmUI.prop.VISIBLE, true);
			button_color7.setProperty(hmUI.prop.VISIBLE, true);
			button_color8.setProperty(hmUI.prop.VISIBLE, true);
			button_color9.setProperty(hmUI.prop.VISIBLE, true);
			button_color10.setProperty(hmUI.prop.VISIBLE, true);
			button_color11.setProperty(hmUI.prop.VISIBLE, true);
			button_color12.setProperty(hmUI.prop.VISIBLE, true);
			button_color13.setProperty(hmUI.prop.VISIBLE, true);
			button_color14.setProperty(hmUI.prop.VISIBLE, true);
			button_color15.setProperty(hmUI.prop.VISIBLE, true);
			button_color16.setProperty(hmUI.prop.VISIBLE, true);
			button_content1.setProperty(hmUI.prop.VISIBLE, false);
			button_content2.setProperty(hmUI.prop.VISIBLE, false);
			button_content3.setProperty(hmUI.prop.VISIBLE, false);
			button_content4.setProperty(hmUI.prop.VISIBLE, false);
			button_content5.setProperty(hmUI.prop.VISIBLE, false);
			button_content6.setProperty(hmUI.prop.VISIBLE, false);
			Button_1.setProperty(hmUI.prop.VISIBLE, false);
            hmUI.showToast({text: 'CHOOSE YOUR BACKGROUND'});
        }

        function CHOOSE_COLOR(){
			
			if ( colornumber_main == 1) { 
				colorstring = '0xFFFF8000'
				secstring = "hand_sec" + parseInt(colornumber_main) + ".png"
			}
			if ( colornumber_main == 2) {
				colorstring = '0xFF008080'
				secstring = "hand_sec" + parseInt(colornumber_main) + ".png"
			}
			if ( colornumber_main == 3) {
				colorstring = '0xFF808000'
				secstring = "hand_sec" + parseInt(colornumber_main) + ".png"
			}
			if ( colornumber_main == 4) {
				colorstring = '0xFF800000'
				secstring = "hand_sec" + parseInt(colornumber_main) + ".png"
			}
			if ( colornumber_main == 5) {
				colorstring = '0xFF00FFFF'
				secstring = "hand_sec" + parseInt(colornumber_main) + ".png"
			}
			if ( colornumber_main == 6) {
				colorstring = '0xFF008000'
				secstring = "hand_sec" + parseInt(colornumber_main) + ".png"
			}
			if ( colornumber_main == 7) {
				colorstring = '0xFFFF0000'
				secstring = "hand_sec" + parseInt(colornumber_main) + ".png"
			}
			if ( colornumber_main == 8) {
				colorstring = '0xFFFFFF00'
				secstring = "hand_sec" + parseInt(colornumber_main) + ".png"
			}
			if ( colornumber_main == 9) {
				colorstring = '0xFFBFFF00'
				secstring = "hand_sec" + parseInt(colornumber_main) + ".png"
			}
			if ( colornumber_main == 10) {
				colorstring = '0xFFA020F0'
				secstring = "hand_sec" + parseInt(colornumber_main) + ".png"
			}
			if ( colornumber_main == 11) {
				colorstring = '0xFF0000FF'
				secstring = "hand_sec" + parseInt(colornumber_main) + ".png"
			}
			if ( colornumber_main == 12) {
				colorstring = '0xFFFF00FF'
				secstring = "hand_sec" + parseInt(colornumber_main) + ".png"
			}
			if ( colornumber_main == 13) {
				colorstring = '0xFFA5694F'
				secstring = "hand_sec" + parseInt(colornumber_main) + ".png"
			}
			if ( colornumber_main == 14) {
				colorstring = '0xFFFFBF00'
				secstring = "hand_sec" + parseInt(colornumber_main) + ".png"
			}
			if ( colornumber_main == 15) {
				colorstring = '0xFFC0C0C0'
				secstring = "hand_sec" + parseInt(colornumber_main) + ".png"
			}
			if ( colornumber_main == 16) {
				colorstring = '0xFFFFFFFF'
				secstring = "hand_sec" + parseInt(colornumber_main) + ".png"
			}
			if ( colornumber_main <= 16) { 
			
            normal_background_bg.setProperty(hmUI.prop.MORE, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: colorstring,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.MORE, {
              second_path: secstring,
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 240,
              second_posY: 240,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			}
			
			setTimeout(function(){
			normal_stress_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			button_color1.setProperty(hmUI.prop.VISIBLE, false);
			button_color2.setProperty(hmUI.prop.VISIBLE, false);
			button_color3.setProperty(hmUI.prop.VISIBLE, false);
			button_color4.setProperty(hmUI.prop.VISIBLE, false);
			button_color5.setProperty(hmUI.prop.VISIBLE, false);
			button_color6.setProperty(hmUI.prop.VISIBLE, false);
			button_color7.setProperty(hmUI.prop.VISIBLE, false);
			button_color8.setProperty(hmUI.prop.VISIBLE, false);
			button_color9.setProperty(hmUI.prop.VISIBLE, false);
			button_color10.setProperty(hmUI.prop.VISIBLE, false);
			button_color11.setProperty(hmUI.prop.VISIBLE, false);
			button_color12.setProperty(hmUI.prop.VISIBLE, false);
			button_color13.setProperty(hmUI.prop.VISIBLE, false);
			button_color14.setProperty(hmUI.prop.VISIBLE, false);
			button_color15.setProperty(hmUI.prop.VISIBLE, false);
			button_color16.setProperty(hmUI.prop.VISIBLE, false);
			button_content1.setProperty(hmUI.prop.VISIBLE, true);
			button_content2.setProperty(hmUI.prop.VISIBLE, true);
			button_content3.setProperty(hmUI.prop.VISIBLE, true);
			button_content4.setProperty(hmUI.prop.VISIBLE, true);
			button_content5.setProperty(hmUI.prop.VISIBLE, true);
			button_content6.setProperty(hmUI.prop.VISIBLE, true);
			Button_1.setProperty(hmUI.prop.VISIBLE, true);
			}, 1200);
		}
		
		function click_COLOR() {
            if(colornumber_main>=totalcolors_main) {
            colornumber_main=1;
                }
            else {
                colornumber_main=colornumber_main+1;
            }
			if ( colornumber_main == 1) { namecolor_main = "O R A N G E"
				colorstring = '0xFFFF8000'
				secstring = "hand_sec" + parseInt(colornumber_main) + ".png"
			}
			if ( colornumber_main == 2) { namecolor_main = "T E A L"
				colorstring = '0xFF008080'
				secstring = "hand_sec" + parseInt(colornumber_main) + ".png"
			}
			if ( colornumber_main == 3) { namecolor_main = "O L I V E"
				colorstring = '0xFF808000'
				secstring = "hand_sec" + parseInt(colornumber_main) + ".png"
			}
			if ( colornumber_main == 4) { namecolor_main = "M A R O O N"
				colorstring = '0xFF800000'
				secstring = "hand_sec" + parseInt(colornumber_main) + ".png"
			}
			if ( colornumber_main == 5) { namecolor_main = "A Q U A"
				colorstring = '0xFF00FFFF'
				secstring = "hand_sec" + parseInt(colornumber_main) + ".png"
			}
			if ( colornumber_main == 6) { namecolor_main = "G R E E N"
				colorstring = '0xFF008000'
				secstring = "hand_sec" + parseInt(colornumber_main) + ".png"
			}
			if ( colornumber_main == 7) { namecolor_main = "R E D"
				colorstring = '0xFFFF0000'
				secstring = "hand_sec" + parseInt(colornumber_main) + ".png"
			}
			if ( colornumber_main == 8) { namecolor_main = "Y E L L O W"
				colorstring = '0xFFFFFF00'
				secstring = "hand_sec" + parseInt(colornumber_main) + ".png"
			}
			if ( colornumber_main == 9) { namecolor_main = "L I M E"
				colorstring = '0xFFBFFF00'
				secstring = "hand_sec" + parseInt(colornumber_main) + ".png"
			}
			if ( colornumber_main == 10) { namecolor_main = "P U R P L E"
				colorstring = '0xFFA020F0'
				secstring = "hand_sec" + parseInt(colornumber_main) + ".png"
			}
			if ( colornumber_main == 11) { namecolor_main = "B L U E"
				colorstring = '0xFF0000FF'
				secstring = "hand_sec" + parseInt(colornumber_main) + ".png"
			}
			if ( colornumber_main == 12) { namecolor_main = "F U C H S I A"
				colorstring = '0xFFFF00FF'
				secstring = "hand_sec" + parseInt(colornumber_main) + ".png"
			}
			if ( colornumber_main == 13) { namecolor_main = "S E P I A"
				colorstring = '0xFFA5694F'
				secstring = "hand_sec" + parseInt(colornumber_main) + ".png"
			}
			if ( colornumber_main == 14) { namecolor_main = "A M B E R"
				colorstring = '0xFFFFBF00'
				secstring = "hand_sec" + parseInt(colornumber_main) + ".png"
			}
			if ( colornumber_main == 15) { namecolor_main = "S I L V E R"
				colorstring = '0xFFC0C0C0'
				secstring = "hand_sec" + parseInt(colornumber_main) + ".png"
			}
			if ( colornumber_main == 16) { namecolor_main = "W H I T E"
				colorstring = '0xFFFFFFFF'
				secstring = "hand_sec" + parseInt(colornumber_main) + ".png"
			}
			if ( colornumber_main <= 16) { 
			
            normal_background_bg.setProperty(hmUI.prop.MORE, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: colorstring,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.MORE, {
              second_path: secstring,
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 240,
              second_posY: 240,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			}
			hmUI.showToast({text: namecolor_main });
		}
		
		function click_COLOR1() {
            colornumber_main=1;
			hmUI.showToast({text: 'O R A N G E'});
			CHOOSE_COLOR();
        }
		
		function click_COLOR2() {
            colornumber_main=2;
			hmUI.showToast({text: 'T E A L'});
			CHOOSE_COLOR();
        }
		
		function click_COLOR3() {
            colornumber_main=3;
			hmUI.showToast({text: 'O L I V E'});
			CHOOSE_COLOR();
        }
		
		function click_COLOR4() {
            colornumber_main=4;
			hmUI.showToast({text: 'M A R O O N'});
			CHOOSE_COLOR();
        }
		
		function click_COLOR5() {
            colornumber_main=5;
			hmUI.showToast({text: 'A Q U A'});
			CHOOSE_COLOR();
        }
		
		function click_COLOR6() {
            colornumber_main=6;
			hmUI.showToast({text: 'G R E E N'});
			CHOOSE_COLOR();
        }
		
		function click_COLOR7() {
            colornumber_main=7;
			hmUI.showToast({text: 'R E D'});
			CHOOSE_COLOR();
        }
		
		function click_COLOR8() {
            colornumber_main=8;
			hmUI.showToast({text: 'Y E L L O W'});
			CHOOSE_COLOR();
        }
		
		function click_COLOR9() {
            colornumber_main=9;
			hmUI.showToast({text: 'L I M E'});
			CHOOSE_COLOR();
        }
		
		function click_COLOR10() {
            colornumber_main=10;
			hmUI.showToast({text: 'P U R P L E'});
			CHOOSE_COLOR();
        }
		
		function click_COLOR11() {
            colornumber_main=11;
			hmUI.showToast({text: 'B L U E'});
			CHOOSE_COLOR();
        }
		
		function click_COLOR12() {
            colornumber_main=12;
			hmUI.showToast({text: 'F U C H S I A'});
			CHOOSE_COLOR();
        }
		
		function click_COLOR13() {
            colornumber_main=13;
			hmUI.showToast({text: 'S E P I A'});
			CHOOSE_COLOR();
        }
		
		function click_COLOR14() {
            colornumber_main=14;
			hmUI.showToast({text: 'A M B E R'});
			CHOOSE_COLOR();
        }
		
		function click_COLOR15() {
            colornumber_main=15;
			hmUI.showToast({text: 'S I L V E R'});
			CHOOSE_COLOR();
        }
		
		function click_COLOR16() {
            colornumber_main=16;
			hmUI.showToast({text: 'W H I T E'});
			CHOOSE_COLOR();
        }
        // end user_functions.js

        let normal_background_bg = ''
        let normal_image_img = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_calorie_icon_img = ''
        let normal_calorie_current_text_font = ''
        let normal_distance_current_text_font = ''
        let normal_step_current_text_font = ''
        let normal_temperature_icon_img = ''
        let normal_city_name_text = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_high_text_font = ''
        let normal_temperature_low_text_font = ''
        let normal_temperature_current_text_font = ''
        let normal_stand_icon_img = ''
        let normal_year_text_font = ''
        let normal_month_name_font = ''
        let normal_Month_Array = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December', ];
        let normal_dow_text_font = ''
        let normal_DOW_Array = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
        let normal_day_text_font = ''
        let normal_battery_linear_scale = ''
        let normal_battery_icon_img = ''
        let normal_battery_current_text_font = ''
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_text_font = ''
        let normal_spo2_current_text_font = ''
        let normal_fat_burning_icon_img = ''
        let normal_time_hour_text_font = ''
        let normal_timerTimeUpdate = undefined;
        let normal_time_minute_text_font = ''
        let normal_time_second_text_font = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_stress_icon_img = ''
        let idle_background_bg_img = ''
        let idle_battery_current_text_font = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_time_hour_text_font = ''
        let idle_timerTimeUpdate = undefined;
        let idle_time_minute_text_font = ''
        let Button_1 = ''
        let timeSensor = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            // FontName: grid.ttf; FontSize: 32
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 602,
              h: 48,
              text_size: 32,
              char_space: 2,
              line_space: 0,
              font: 'fonts/grid.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: grid.ttf; FontSize: 32; Cache: full
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 38,
              h: 38,
              text_size: 32,
              char_space: 2,
              line_space: 0,
              font: 'fonts/grid.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: grid.ttf; FontSize: 60
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 1021,
              h: 91,
              text_size: 60,
              char_space: 0,
              line_space: 0,
              font: 'fonts/grid.ttf',
              color: 0xFFC0C0C0,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: grid.ttf; FontSize: 28; Cache: full
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 33,
              h: 33,
              text_size: 28,
              char_space: 0,
              line_space: 0,
              font: 'fonts/grid.ttf',
              color: 0xFF808080,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: grid.ttf; FontSize: 40
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 681,
              h: 60,
              text_size: 40,
              char_space: 0,
              line_space: 0,
              font: 'fonts/grid.ttf',
              color: 0xFFC0C0C0,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: grid.ttf; FontSize: 80
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 1357,
              h: 120,
              text_size: 80,
              char_space: 0,
              line_space: 0,
              font: 'fonts/grid.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: grid.ttf; FontSize: 30; Cache: full
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 36,
              h: 36,
              text_size: 30,
              char_space: 0,
              line_space: 0,
              font: 'fonts/grid.ttf',
              color: 0xFFC0C0C0,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: grid.ttf; FontSize: 38; Cache: full
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 45,
              h: 45,
              text_size: 38,
              char_space: 0,
              line_space: 0,
              font: 'fonts/grid.ttf',
              color: 0xFF808080,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: grid.ttf; FontSize: 120
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 2038,
              h: 180,
              text_size: 120,
              char_space: 0,
              line_space: 0,
              font: 'fonts/grid.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: grid.ttf; FontSize: 66
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 1122,
              h: 99,
              text_size: 66,
              char_space: 0,
              line_space: 0,
              font: 'fonts/grid.ttf',
              color: 0xFFC0C0C0,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: grid.ttf; FontSize: 48
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 876,
              h: 73,
              text_size: 48,
              char_space: 2,
              line_space: 0,
              font: 'fonts/grid.ttf',
              color: 0xFF000000,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: grid.ttf; FontSize: 42
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 774,
              h: 62,
              text_size: 42,
              char_space: 2,
              line_space: 0,
              font: 'fonts/grid.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFFFF8000',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'mask.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'hand_sec1.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 240,
              second_posY: 240,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'sym_step.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 190,
              y: 344,
              w: 100,
              h: 30,
              text_size: 32,
              char_space: 2,
              line_space: 0,
              font: 'fonts/grid.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 162,
              y: 270,
              w: 160,
              h: 30,
              text_size: 32,
              char_space: 2,
              line_space: 0,
              font: 'fonts/grid.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 138,
              y: 178,
              w: 214,
              h: 44,
              text_size: 60,
              char_space: 0,
              line_space: 0,
              font: 'fonts/grid.ttf',
              color: 0xFFC0C0C0,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'sym_weather.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 110,
              y: 250,
              w: 260,
              h: 32,
              text_size: 28,
              char_space: 0,
              line_space: 0,
              font: 'fonts/grid.ttf',
              color: 0xFF808080,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 208,
              y: 104,
              image_array: ["weatherd_00.png","weatherd_01.png","weatherd_02.png","weatherd_03.png","weatherd_04.png","weatherd_05.png","weatherd_06.png","weatherd_07.png","weatherd_08.png","weatherd_09.png","weatherd_10.png","weatherd_11.png","weatherd_12.png","weatherd_13.png","weatherd_14.png","weatherd_15.png","weatherd_16.png","weatherd_17.png","weatherd_18.png","weatherd_19.png","weatherd_20.png","weatherd_21.png","weatherd_22.png","weatherd_23.png","weatherd_24.png","weatherd_25.png","weatherd_26.png","weatherd_27.png","weatherd_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 251,
              y: 316,
              w: 100,
              h: 30,
              text_size: 40,
              char_space: 0,
              line_space: 0,
              font: 'fonts/grid.ttf',
              color: 0xFFC0C0C0,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 130,
              y: 316,
              w: 100,
              h: 30,
              text_size: 40,
              char_space: 0,
              line_space: 0,
              font: 'fonts/grid.ttf',
              color: 0xFFC0C0C0,
              align_h: hmUI.align.RIGHT,
              align_v: hmUI.align.CENTER_V,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 146,
              y: 170,
              w: 190,
              h: 62,
              text_size: 80,
              char_space: 0,
              line_space: 0,
              font: 'fonts/grid.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'sym_date.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function() {
              time_update(true);
            });

            normal_year_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 195,
              y: 350,
              w: 90,
              h: 20,
              text_size: 28,
              char_space: 0,
              line_space: 0,
              font: 'fonts/grid.ttf',
              color: 0xFF808080,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_month_name_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 126,
              y: 304,
              w: 230,
              h: 36,
              text_size: 30,
              char_space: 0,
              line_space: 0,
              font: 'fonts/grid.ttf',
              color: 0xFFC0C0C0,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              // unit_string: January, February, March, April, May, June, July, August, September, October, November, December,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_dow_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 107,
              y: 246,
              w: 270,
              h: 44,
              text_size: 38,
              char_space: 0,
              line_space: 0,
              font: 'fonts/grid.ttf',
              color: 0xFF808080,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              // unit_string: Monday, Tuesday, Wednesday, Thursday, Friday, Saturday, Sunday,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_day_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 140,
              y: 135,
              w: 200,
              h: 90,
              text_size: 120,
              char_space: 0,
              line_space: 0,
              font: 'fonts/grid.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            if (screenType != hmSetting.screen_type.AOD) {
              normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 174,
              // start_y: 213,
              // color: 0xFF808080,
              // lenght: 134,
              // line_width: 74,
              // line_cap: Flat,
              // vertical: False,
              // mirror: False,
              // inversion: True,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'sym_batt.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 142,
              y: 135,
              w: 200,
              h: 52,
              text_size: 66,
              char_space: 0,
              line_space: 0,
              font: 'fonts/grid.ttf',
              color: 0xFFC0C0C0,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'sym_heart.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 166,
              y: 190,
              w: 150,
              h: 36,
              text_size: 48,
              char_space: 2,
              line_space: 0,
              font: 'fonts/grid.ttf',
              color: 0xFF000000,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 164,
              y: 345,
              w: 150,
              h: 32,
              text_size: 42,
              char_space: 2,
              line_space: 0,
              font: 'fonts/grid.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_fat_burning_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'sym_time.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_time_hour_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 120,
              y: 130,
              w: 190,
              h: 100,
              text_size: 120,
              char_space: -5,
              line_space: 0,
              font: 'fonts/grid.ttf',
              color: 0xFFC0C0C0,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_time_minute_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 120,
              y: 246,
              w: 190,
              h: 100,
              text_size: 120,
              char_space: -5,
              line_space: 0,
              font: 'fonts/grid.ttf',
              color: 0xFF808080,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_time_second_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 313,
              y: 300,
              w: 50,
              h: 22,
              text_size: 30,
              char_space: 0,
              line_space: 0,
              font: 'fonts/grid.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 0,
              am_y: 0,
              am_sc_path: 'time_am.png',
              am_en_path: 'time_am.png',
              pm_x: 0,
              pm_y: 0,
              pm_sc_path: 'time_pm.png',
              pm_en_path: 'time_pm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'Theme_Picker.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'aod.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 313,
              y: 300,
              w: 50,
              h: 22,
              text_size: 30,
              char_space: 0,
              line_space: 0,
              font: 'fonts/grid.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 0,
              am_y: 0,
              am_sc_path: 'aod_am.png',
              am_en_path: 'aod_am.png',
              pm_x: 0,
              pm_y: 0,
              pm_sc_path: 'aod_pm.png',
              pm_en_path: 'aod_pm.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_time_hour_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 120,
              y: 130,
              w: 190,
              h: 100,
              text_size: 120,
              char_space: -5,
              line_space: 0,
              font: 'fonts/grid.ttf',
              color: 0xFFC0C0C0,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              // padding: true,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_time_minute_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 120,
              y: 246,
              w: 190,
              h: 100,
              text_size: 120,
              char_space: -5,
              line_space: 0,
              font: 'fonts/grid.ttf',
              color: 0xFF808080,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              // padding: true,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 190,
              y: 190,
              w: 100,
              h: 100,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                				click_COLOR();
              }, // end func
              longpress_func: (button_widget) => {
                				click_COLORSWITCH();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            console.log('user_script_end.js');
            // start user_script_end.js

			button_content1 = hmUI.createWidget(hmUI.widget.BUTTON, {
			  x: 155,
              y: 395,
              w: 170,
              h: 85,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                click_CONTENT1();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button
			
			button_content2 = hmUI.createWidget(hmUI.widget.BUTTON, {
			  x: 365,
              y: 245,
              w: 100,
              h: 200,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                click_CONTENT2();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button
			
			button_content3 = hmUI.createWidget(hmUI.widget.BUTTON, {
			  x: 365,
              y: 35,
              w: 100,
              h: 200,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                click_CONTENT3();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button
			
			button_content4 = hmUI.createWidget(hmUI.widget.BUTTON, {
			  x: 155,
              y: 0,
              w: 170,
              h: 85,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                click_CONTENT4();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button
			
			button_content5 = hmUI.createWidget(hmUI.widget.BUTTON, {
			  x: 15,
              y: 35,
              w: 100,
              h: 200,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                click_CONTENT5();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button
			
			button_content6 = hmUI.createWidget(hmUI.widget.BUTTON, {
			  x: 15,
              y: 245,
              w: 100,
              h: 200,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                click_CONTENT6();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button
			
			button_color1 = hmUI.createWidget(hmUI.widget.BUTTON, {
			  x: 95,
              y: 95,
              w: 65,
              h: 65,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                click_COLOR1();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button
			
			button_color2 = hmUI.createWidget(hmUI.widget.BUTTON, {
			  x: 170,
              y: 95,
              w: 65,
              h: 65,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                click_COLOR2();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button
			
			button_color3 = hmUI.createWidget(hmUI.widget.BUTTON, {
			  x: 245,
              y: 95,
              w: 65,
              h: 65,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                click_COLOR3();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button
			
			button_color4 = hmUI.createWidget(hmUI.widget.BUTTON, {
			  x: 320,
              y: 95,
              w: 65,
              h: 65,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                click_COLOR4();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button
			
			button_color5 = hmUI.createWidget(hmUI.widget.BUTTON, {
			  x: 95,
              y: 170,
              w: 65,
              h: 65,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                click_COLOR5();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button
			
			button_color6 = hmUI.createWidget(hmUI.widget.BUTTON, {
			  x: 170,
              y: 170,
              w: 65,
              h: 65,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                click_COLOR6();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button
			
			button_color7 = hmUI.createWidget(hmUI.widget.BUTTON, {
			  x: 245,
              y: 170,
              w: 65,
              h: 65,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                click_COLOR7();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button
			
			button_color8 = hmUI.createWidget(hmUI.widget.BUTTON, {
			  x: 320,
              y: 170,
              w: 65,
              h: 65,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                click_COLOR8();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button
			
			button_color9 = hmUI.createWidget(hmUI.widget.BUTTON, {
			  x: 95,
              y: 245,
              w: 65,
              h: 65,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                click_COLOR9();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button
			
			button_color10 = hmUI.createWidget(hmUI.widget.BUTTON, {
			  x: 170,
              y: 245,
              w: 65,
              h: 65,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                click_COLOR10();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button
			
			button_color11 = hmUI.createWidget(hmUI.widget.BUTTON, {
			  x: 245,
              y: 245,
              w: 65,
              h: 65,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                click_COLOR11();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button
			
			button_color12 = hmUI.createWidget(hmUI.widget.BUTTON, {
			  x: 320,
              y: 245,
              w: 65,
              h: 65,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                click_COLOR12();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button
			
			button_color13 = hmUI.createWidget(hmUI.widget.BUTTON, {
			  x: 95,
              y: 320,
              w: 65,
              h: 65,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                click_COLOR13();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button
			
			button_color14 = hmUI.createWidget(hmUI.widget.BUTTON, {
			  x: 170,
              y: 320,
              w: 65,
              h: 65,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                click_COLOR14();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button
			
			button_color15 = hmUI.createWidget(hmUI.widget.BUTTON, {
			  x: 245,
              y: 320,
              w: 65,
              h: 65,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                click_COLOR15();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button
			
			button_color16 = hmUI.createWidget(hmUI.widget.BUTTON, {
			  x: 320,
              y: 320,
              w: 65,
              h: 65,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                click_COLOR16();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button
			
			if(cc==0){
				if (screenType == hmSetting.screen_type.WATCHFACE) {
				normal_stress_icon_img.setProperty(hmUI.prop.VISIBLE, false);
				button_color1.setProperty(hmUI.prop.VISIBLE, false);
				button_color2.setProperty(hmUI.prop.VISIBLE, false);
				button_color3.setProperty(hmUI.prop.VISIBLE, false);
				button_color4.setProperty(hmUI.prop.VISIBLE, false);
				button_color5.setProperty(hmUI.prop.VISIBLE, false);
				button_color6.setProperty(hmUI.prop.VISIBLE, false);
				button_color7.setProperty(hmUI.prop.VISIBLE, false);
				button_color8.setProperty(hmUI.prop.VISIBLE, false);
				button_color9.setProperty(hmUI.prop.VISIBLE, false);
				button_color10.setProperty(hmUI.prop.VISIBLE, false);
				button_color11.setProperty(hmUI.prop.VISIBLE, false);
				button_color12.setProperty(hmUI.prop.VISIBLE, false);
				button_color13.setProperty(hmUI.prop.VISIBLE, false);
				button_color14.setProperty(hmUI.prop.VISIBLE, false);
				button_color15.setProperty(hmUI.prop.VISIBLE, false);
				button_color16.setProperty(hmUI.prop.VISIBLE, false);
			
				normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_heart_rate_text_font.setProperty(hmUI.prop.VISIBLE, false);
				normal_spo2_current_text_font.setProperty(hmUI.prop.VISIBLE, false);

				normal_battery_linear_scale.setProperty(hmUI.prop.VISIBLE, false);
				normal_battery_icon_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_battery_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
			  
				normal_stand_icon_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_year_text_font.setProperty(hmUI.prop.VISIBLE, false);
				normal_month_name_font.setProperty(hmUI.prop.VISIBLE, false);
				normal_dow_text_font.setProperty(hmUI.prop.VISIBLE, false);
				normal_day_text_font.setProperty(hmUI.prop.VISIBLE, false);
			
				normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_calorie_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
				normal_distance_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
				normal_step_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
			  
				normal_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_city_name_text.setProperty(hmUI.prop.VISIBLE, false);
				normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
				normal_temperature_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
				normal_temperature_high_text_font.setProperty(hmUI.prop.VISIBLE, false);
				normal_temperature_low_text_font.setProperty(hmUI.prop.VISIBLE, false);
				cc=1
				}
			}
            // end user_script_end.js

            //start of ignored block
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              console.log('year font');
              if (updateHour) {
                let normal_yearStr = timeSensor.year.toString();
                normal_year_text_font.setProperty(hmUI.prop.TEXT, normal_yearStr );
              };

              console.log('month font');
              if (updateHour) {
                let normal_Month_Str = normal_Month_Array[timeSensor.month-1];
                normal_month_name_font.setProperty(hmUI.prop.TEXT, normal_Month_Str );
              };

              console.log('day of week font');
              if (updateHour) {
                let normal_DOW_Str = normal_DOW_Array[timeSensor.week-1];
                normal_dow_text_font.setProperty(hmUI.prop.TEXT, normal_DOW_Str );
              };

              console.log('day font');
              if (updateHour) {
                let normal_dayStr = timeSensor.day.toString();
                normal_dayStr = normal_dayStr.padStart(2, '0');
                normal_day_text_font.setProperty(hmUI.prop.TEXT, normal_dayStr );
              };

              console.log('hour font');
              if (updateHour) {
                let normal_hourStr = format_hour.toString();
                normal_hourStr = normal_hourStr.padStart(2, '0');
                normal_time_hour_text_font.setProperty(hmUI.prop.TEXT, normal_hourStr );
              };

              console.log('minute font');
              if (updateMinute) {
                let normal_minuteStr = minute.toString();
                normal_minuteStr = normal_minuteStr.padStart(2, '0');
                normal_time_minute_text_font.setProperty(hmUI.prop.TEXT, normal_minuteStr );
              };

              console.log('second font');
                let normal_secondStr = second.toString();
                normal_secondStr = normal_secondStr.padStart(2, '0');
                normal_time_second_text_font.setProperty(hmUI.prop.TEXT, normal_secondStr );
              console.log('hour font');
              if (updateHour) {
                let idle_hourStr = format_hour.toString();
                idle_hourStr = idle_hourStr.padStart(2, '0');
                idle_time_hour_text_font.setProperty(hmUI.prop.TEXT, idle_hourStr );
              };

              console.log('minute font');
              if (updateMinute) {
                let idle_minuteStr = minute.toString();
                idle_minuteStr = idle_minuteStr.padStart(2, '0');
                idle_time_minute_text_font.setProperty(hmUI.prop.TEXT, idle_minuteStr );
              };

            };

            //end of ignored block
            function scale_call() {
              console.log('scale_call()');

              console.log('Weather city name');
              let weatherData = weatherSensor.getForecastWeather();
              normal_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_ls_normal_battery = 1 - progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_linear_scale
                  // initial parameters
                  let start_x_normal_battery = 308;
                  let start_y_normal_battery = 213;
                  let lenght_ls_normal_battery = -134;
                  let line_width_ls_normal_battery = 74;
                  let color_ls_normal_battery = 0xFF808080;
                  
                  // calculated parameters
                  let start_x_normal_battery_draw = start_x_normal_battery;
                  let start_y_normal_battery_draw = start_y_normal_battery;
                  lenght_ls_normal_battery = lenght_ls_normal_battery * progress_ls_normal_battery;
                  let lenght_ls_normal_battery_draw = lenght_ls_normal_battery;
                  let line_width_ls_normal_battery_draw = line_width_ls_normal_battery;
                  if (lenght_ls_normal_battery < 0){
                    lenght_ls_normal_battery_draw = -lenght_ls_normal_battery;
                    start_x_normal_battery_draw = start_x_normal_battery - lenght_ls_normal_battery_draw;
                  };
                  
                  normal_battery_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_battery_draw,
                    y: start_y_normal_battery_draw,
                    w: lenght_ls_normal_battery_draw,
                    h: line_width_ls_normal_battery_draw,
                    color: color_ls_normal_battery,
                  });
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                time_update(true, true);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerTimeUpdate) {
                    normal_timerTimeUpdate = timer.createTimer(0, 1000, (function (option) {
                      let updateHour = timeSensor.minute == 0;
                      let updateMinute = timeSensor.second < 2;
                      time_update(updateHour, updateMinute);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.AOD) {
                  if (!idle_timerTimeUpdate) {
                    idle_timerTimeUpdate = timer.createTimer(0, 1000, (function (option) {
                      let updateHour = timeSensor.minute == 0;
                      let updateMinute = timeSensor.second < 2;
                      time_update(updateHour, updateMinute);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerTimeUpdate) {
                  timer.stopTimer(normal_timerTimeUpdate);
                  normal_timerTimeUpdate = undefined;
                }
                if (idle_timerTimeUpdate) {
                  timer.stopTimer(idle_timerTimeUpdate);
                  idle_timerTimeUpdate = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
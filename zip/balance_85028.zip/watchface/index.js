﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg = ''
        let normal_image_img = ''
        let normal_battery_linear_scale = ''
        let normal_battery_icon_img = ''
        let normal_battery_TextRotate = new Array(3);
        let normal_battery_TextRotate_ASCIIARRAY = new Array(10);
        let normal_battery_TextRotate_img_width = 36;
        let normal_battery_TextRotate_unit = null;
        let normal_battery_TextRotate_unit_width = 42;
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_heart_rate_circle_scale = ''
        let normal_heart_rate_TextRotate = new Array(3);
        let normal_heart_rate_TextRotate_ASCIIARRAY = new Array(10);
        let normal_heart_rate_TextRotate_img_width = 36;
        let normal_step_TextRotate = new Array(5);
        let normal_step_TextRotate_ASCIIARRAY = new Array(10);
        let normal_step_TextRotate_img_width = 35;
        let normal_day_TextRotate = new Array(2);
        let normal_day_TextRotate_ASCIIARRAY = new Array(10);
        let normal_day_TextRotate_img_width = 36;
        let normal_timerTextUpdate = undefined;
        let normal_month_TextRotate = new Array(2);
        let normal_month_TextRotate_ASCIIARRAY = new Array(10);
        let normal_month_TextRotate_img_width = 36;
        let normal_hour_TextRotate = new Array(2);
        let normal_hour_TextRotate_ASCIIARRAY = new Array(10);
        let normal_hour_TextRotate_img_width = 94;
        let normal_minute_TextRotate = new Array(2);
        let normal_minute_TextRotate_ASCIIARRAY = new Array(10);
        let normal_minute_TextRotate_img_width = 94;
        let normal_date_img_date_week_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_TextRotate = new Array(4);
        let normal_temperature_current_TextRotate_ASCIIARRAY = new Array(10);
        let normal_temperature_current_TextRotate_img_width = 36;
        let normal_temperature_current_TextRotate_unit = null;
        let normal_temperature_current_TextRotate_unit_width = 61;
        let normal_temperature_current_TextRotate_dot_width = 24;
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_Switch_BG_Color = ''

        let bgColorIndex = 0;
        let bgColorList = [0xFFE3BD48, 0xFF57B733, 0xFF67B887, 0xFFB66834, 0xFF60AEBF, 0xFFC05F5F];
        let bgColorToastList = ['Фон %s', 'Фон %s', 'Фон %s', 'Фон %s', 'Фон %s', 'Фон %s'];
        const watchfaceId = hmApp.packageInfo().watchfaceId;
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            //start of ignored block
            console.log('SwitchBG_Color');
            function switchBG_Color() {
              bgColorIndex++;
              if (bgColorIndex >= bgColorList.length) bgColorIndex = 0;
              hmFS.SysProSetInt(`bgColorIndex_${watchfaceId}`, bgColorIndex);
              let toastText = bgColorToastList[bgColorIndex].replace('%s', `${bgColorIndex + 1}`);
              if (toastText.length > 0) hmUI.showToast({text: toastText});
              normal_background_bg.setProperty(hmUI.prop.COLOR, bgColorList[bgColorIndex]);
            };
            //end of ignored block

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFFE3BD48',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'Masc.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            if (screenType != hmSetting.screen_type.AOD) {
              normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 293,
              // start_y: 446,
              // color: 0xFF313024,
              // lenght: -52,
              // line_width: 50,
              // line_cap: Flat,
              // vertical: True,
              // mirror: False,
              // inversion: True,
              // alpha: 255,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
              scale_call();
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 285,
              y: 387,
              src: 'batic.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_battery_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 330,
              // y: 386,
              // font_array: ["d00.png","d001.png","d002.png","d003.png","d004.png","d005.png","d006.png","d007.png","d008.png","d009.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: -34,
              // unit_en: 'prc.png',
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_battery_TextRotate_ASCIIARRAY[0] = 'd00.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[1] = 'd001.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[2] = 'd002.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[3] = 'd003.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[4] = 'd004.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[5] = 'd005.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[6] = 'd006.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[7] = 'd007.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[8] = 'd008.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[9] = 'd009.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 3; i++) {
              normal_battery_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 330,
                center_y: 386,
                pos_x: 330,
                pos_y: 386,
                angle: -34,
                src: 'd00.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_battery_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_battery_TextRotate_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              center_x: 330,
              center_y: 386,
              pos_x: 330,
              pos_y: 386,
              angle: -34,
              src: 'prc.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_battery_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 17,
              y: 261,
              src: 'DISK.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 42,
              y: 247,
              src: 'ALARM.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_heart_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 240,
              // center_y: 240,
              // start_angle: 414,
              // end_angle: 350,
              // radius: 240,
              // line_width: 9,
              // line_cap: Rounded,
              // color: 0xFF2A2A2A,
              // mirror: False,
              // inversion: True,
              // alpha: 255,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_heart_rate_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 240,
              center_y: 240,
              start_angle: 350,
              end_angle: 414,
              radius: 236,
              line_width: 9,
              corner_flag: 0,
              color: 0xFF2A2A2A,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const heart_rate = hmSensor.createSensor(hmSensor.id.HEART);
            heart_rate.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
              scale_call();
            });

            // normal_heart_rate_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 344,
              // y: 91,
              // font_array: ["d00.png","d001.png","d002.png","d003.png","d004.png","d005.png","d006.png","d007.png","d008.png","d009.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: -34,
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_heart_rate_TextRotate_ASCIIARRAY[0] = 'd00.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[1] = 'd001.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[2] = 'd002.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[3] = 'd003.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[4] = 'd004.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[5] = 'd005.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[6] = 'd006.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[7] = 'd007.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[8] = 'd008.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[9] = 'd009.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 3; i++) {
              normal_heart_rate_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 344,
                center_y: 91,
                pos_x: 344,
                pos_y: 91,
                angle: -34,
                src: 'd00.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_heart_rate_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            // normal_step_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 170,
              // y: 317,
              // font_array: ["st00.png","st01.png","st02.png","st03.png","st04.png","st05.png","st06.png","st07.png","st08.png","st09.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: 55,
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_step_TextRotate_ASCIIARRAY[0] = 'st00.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[1] = 'st01.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[2] = 'st02.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[3] = 'st03.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[4] = 'st04.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[5] = 'st05.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[6] = 'st06.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[7] = 'st07.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[8] = 'st08.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[9] = 'st09.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              normal_step_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 170,
                center_y: 317,
                pos_x: 170,
                pos_y: 317,
                angle: 55,
                src: 'st00.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_step_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            // normal_day_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 87,
              // y: 96,
              // font_array: ["d00.png","d001.png","d002.png","d003.png","d004.png","d005.png","d006.png","d007.png","d008.png","d009.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: -34,
              // align_h: hmUI.align.RIGHT,
              // type: hmUI.data_type.DAY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_day_TextRotate_ASCIIARRAY[0] = 'd00.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[1] = 'd001.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[2] = 'd002.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[3] = 'd003.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[4] = 'd004.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[5] = 'd005.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[6] = 'd006.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[7] = 'd007.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[8] = 'd008.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[9] = 'd009.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              normal_day_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 87,
                center_y: 96,
                pos_x: 87,
                pos_y: 96,
                angle: -34,
                src: 'd00.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_day_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            // normal_month_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 118,
              // y: 79,
              // font_array: ["d00.png","d001.png","d002.png","d003.png","d004.png","d005.png","d006.png","d007.png","d008.png","d009.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: -34,
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.MONTH,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_month_TextRotate_ASCIIARRAY[0] = 'd00.png';  // set of images with numbers
            normal_month_TextRotate_ASCIIARRAY[1] = 'd001.png';  // set of images with numbers
            normal_month_TextRotate_ASCIIARRAY[2] = 'd002.png';  // set of images with numbers
            normal_month_TextRotate_ASCIIARRAY[3] = 'd003.png';  // set of images with numbers
            normal_month_TextRotate_ASCIIARRAY[4] = 'd004.png';  // set of images with numbers
            normal_month_TextRotate_ASCIIARRAY[5] = 'd005.png';  // set of images with numbers
            normal_month_TextRotate_ASCIIARRAY[6] = 'd006.png';  // set of images with numbers
            normal_month_TextRotate_ASCIIARRAY[7] = 'd007.png';  // set of images with numbers
            normal_month_TextRotate_ASCIIARRAY[8] = 'd008.png';  // set of images with numbers
            normal_month_TextRotate_ASCIIARRAY[9] = 'd009.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              normal_month_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 118,
                center_y: 79,
                pos_x: 118,
                pos_y: 79,
                angle: -34,
                src: 'd00.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_month_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            // normal_hour_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 59,
              // y: 186,
              // font_array: ["h000.png","h001.png","h002.png","h003.png","h004.png","h005.png","h006.png","h007.png","h008.png","h009.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: -1,
              // angle: -34,
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.HOUR,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_hour_TextRotate_ASCIIARRAY[0] = 'h000.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[1] = 'h001.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[2] = 'h002.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[3] = 'h003.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[4] = 'h004.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[5] = 'h005.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[6] = 'h006.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[7] = 'h007.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[8] = 'h008.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[9] = 'h009.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              normal_hour_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 59,
                center_y: 186,
                pos_x: 59,
                pos_y: 186,
                angle: -34,
                src: 'h000.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_hour_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            // normal_minute_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 206,
              // y: 286,
              // font_array: ["hm0.png","hm1.png","hm2.png","hm3.png","hm4.png","hm5.png","hm6.png","hm7.png","hm8.png","hm9.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: -1,
              // angle: -34,
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.MINUTE,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_minute_TextRotate_ASCIIARRAY[0] = 'hm0.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[1] = 'hm1.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[2] = 'hm2.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[3] = 'hm3.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[4] = 'hm4.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[5] = 'hm5.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[6] = 'hm6.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[7] = 'hm7.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[8] = 'hm8.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[9] = 'hm9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              normal_minute_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 206,
                center_y: 286,
                pos_x: 206,
                pos_y: 286,
                angle: -34,
                src: 'hm0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_minute_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 25,
              y: 268,
              week_en: ["n00.png","n01.png","n02.png","n03.png","n04.png","n05.png","n06.png"],
              week_tc: ["n00.png","n01.png","n02.png","n03.png","n04.png","n05.png","n06.png"],
              week_sc: ["n00.png","n01.png","n02.png","n03.png","n04.png","n05.png","n06.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 400,
              y: 127,
              image_array: ["0059.png","0060.png","0061.png","0062.png","0063.png","0064.png","0065.png","0066.png","0067.png","0068.png","0069.png","0070.png","0071.png","0072.png","0073.png","0074.png","0075.png","0076.png","0077.png","0078.png","0079.png","0080.png","0081.png","0082.png","0083.png","0084.png","0085.png","0086.png","0087.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_temperature_current_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 400,
              // y: 166,
              // font_array: ["d00.png","d001.png","d002.png","d003.png","d004.png","d005.png","d006.png","d007.png","d008.png","d009.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: 55,
              // unit_en: 'gr.png',
              // negative_image: 'min.png',
              // dot_image: 'min.png',
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.WEATHER_CURRENT,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_temperature_current_TextRotate_ASCIIARRAY[0] = 'd00.png';  // set of images with numbers
            normal_temperature_current_TextRotate_ASCIIARRAY[1] = 'd001.png';  // set of images with numbers
            normal_temperature_current_TextRotate_ASCIIARRAY[2] = 'd002.png';  // set of images with numbers
            normal_temperature_current_TextRotate_ASCIIARRAY[3] = 'd003.png';  // set of images with numbers
            normal_temperature_current_TextRotate_ASCIIARRAY[4] = 'd004.png';  // set of images with numbers
            normal_temperature_current_TextRotate_ASCIIARRAY[5] = 'd005.png';  // set of images with numbers
            normal_temperature_current_TextRotate_ASCIIARRAY[6] = 'd006.png';  // set of images with numbers
            normal_temperature_current_TextRotate_ASCIIARRAY[7] = 'd007.png';  // set of images with numbers
            normal_temperature_current_TextRotate_ASCIIARRAY[8] = 'd008.png';  // set of images with numbers
            normal_temperature_current_TextRotate_ASCIIARRAY[9] = 'd009.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 4; i++) {
              normal_temperature_current_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 400,
                center_y: 166,
                pos_x: 400,
                pos_y: 166,
                angle: 55,
                src: 'd00.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_temperature_current_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_temperature_current_TextRotate_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              center_x: 400,
              center_y: 166,
              pos_x: 400,
              pos_y: 166,
              angle: 55,
              src: 'gr.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_temperature_current_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block
            const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);



            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 259,
              y: 19,
              w: 147,
              h: 121,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'transparent_img.png',
              normal_src: 'transparent_img.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'heart_app_Screen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 78,
              y: 330,
              w: 147,
              h: 121,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'transparent_img.png',
              normal_src: 'transparent_img.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'activityAppScreen', native: true });
              }, // end func
              longpress_func: (button_widget) => {
                hmApp.startApp({url: 'SportListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 80,
              y: 122,
              w: 147,
              h: 121,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'transparent_img.png',
              normal_src: 'transparent_img.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'AlarmInfoScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 248,
              y: 228,
              w: 147,
              h: 121,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'transparent_img.png',
              normal_src: 'transparent_img.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'MusicCommonScreen', native: true });
              }, // end func
              longpress_func: (button_widget) => {
                hmApp.startApp({url: 'TomatoMainScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 388,
              y: 133,
              w: 147,
              h: 121,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'transparent_img.png',
              normal_src: 'transparent_img.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'WeatherScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            console.log('Watch_Face.SwitchBG_Color');
            // Button_Switch_BG_Color = hmUI.createWidget(hmUI.widget.SwitchBG_Color, {
              // x: 283,
              // y: 145,
              // w: 53,
              // h: 53,
              // text: '',
              // color: 0xFFFF8C00,
              // text_size: 24,
              // press_src: 'transparent_img.png',
              // normal_src: 'transparent_img.png',
              // color_list: 0xFFE3BD48|0xFF57B733|0xFF67B887|0xFFB66834|0xFF60AEBF|0xFFC05F5F,
              // toast_list: Фон %s|Фон %s|Фон %s|Фон %s|Фон %s|Фон %s,
              // use_crown: False,
              // use_in_AOD: False,
              // vibro: False,
            // });

            Button_Switch_BG_Color = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 283,
              y: 145,
              w: 53,
              h: 53,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'transparent_img.png',
              normal_src: 'transparent_img.png',
              click_func: (button_widget) => {
                switchBG_Color();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            //start of ignored block
            function text_update() {
              console.log('text_update()');

              console.log('update text rotate battery_BATTERY');
              let valueBattery = battery.current;
              let normal_battery_rotate_string = parseInt(valueBattery).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  normal_battery_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_battery_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
                if (valueBattery != null && valueBattery != undefined && isFinite(valueBattery) && normal_battery_rotate_string.length > 0 && normal_battery_rotate_string.length <= 3) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of normal_battery_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_battery_TextRotate[index].setProperty(hmUI.prop.POS_X, 330 + img_offset);
                      normal_battery_TextRotate[index].setProperty(hmUI.prop.SRC, normal_battery_TextRotate_ASCIIARRAY[charCode]);
                      normal_battery_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_battery_TextRotate_img_width;
                      index++;
                    };  // end if digit
                  };  // end char of string
                  normal_battery_TextRotate_unit.setProperty(hmUI.prop.POS_X, 330 + img_offset);
                  normal_battery_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite

              };

              console.log('update text rotate heart_rate_HEART');
              let valueHeartRate = heart_rate.last;
              let normal_heart_rate_rotate_string = parseInt(valueHeartRate).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  normal_heart_rate_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueHeartRate != null && valueHeartRate != undefined && isFinite(valueHeartRate) && normal_heart_rate_rotate_string.length > 0 && normal_heart_rate_rotate_string.length <= 3) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let normal_heart_rate_TextRotate_posOffset = normal_heart_rate_TextRotate_img_width * normal_heart_rate_rotate_string.length;
                  img_offset -= normal_heart_rate_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_heart_rate_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_heart_rate_TextRotate[index].setProperty(hmUI.prop.POS_X, 344 + img_offset);
                      normal_heart_rate_TextRotate[index].setProperty(hmUI.prop.SRC, normal_heart_rate_TextRotate_ASCIIARRAY[charCode]);
                      normal_heart_rate_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_heart_rate_TextRotate_img_width;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate step_STEP');
              let valueStep = step.current;
              let normal_step_rotate_string = parseInt(valueStep).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  normal_step_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueStep != null && valueStep != undefined && isFinite(valueStep) && normal_step_rotate_string.length > 0 && normal_step_rotate_string.length <= 5) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of normal_step_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_step_TextRotate[index].setProperty(hmUI.prop.POS_X, 170 + img_offset);
                      normal_step_TextRotate[index].setProperty(hmUI.prop.SRC, normal_step_TextRotate_ASCIIARRAY[charCode]);
                      normal_step_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_step_TextRotate_img_width;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate day_TIME');
              let valueDay = timeSensor.day;
              let normal_day_rotate_string = parseInt(valueDay).toString();
              normal_day_rotate_string = normal_day_rotate_string.padStart(2, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_day_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueDay != null && valueDay != undefined && isFinite(valueDay) && normal_day_rotate_string.length > 0 && normal_day_rotate_string.length <= 2) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = RIGHT
                  let normal_day_TextRotate_posOffset = normal_day_TextRotate_img_width * normal_day_rotate_string.length;
                  img_offset -= normal_day_TextRotate_posOffset;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_day_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_day_TextRotate[index].setProperty(hmUI.prop.POS_X, 87 + img_offset);
                      normal_day_TextRotate[index].setProperty(hmUI.prop.SRC, normal_day_TextRotate_ASCIIARRAY[charCode]);
                      normal_day_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_day_TextRotate_img_width;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate month_TIME');
              let valueMonth = timeSensor.month;
              let normal_month_rotate_string = parseInt(valueMonth).toString();
              normal_month_rotate_string = normal_month_rotate_string.padStart(2, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_month_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueMonth != null && valueMonth != undefined && isFinite(valueMonth) && normal_month_rotate_string.length > 0 && normal_month_rotate_string.length <= 2) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of normal_month_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_month_TextRotate[index].setProperty(hmUI.prop.POS_X, 118 + img_offset);
                      normal_month_TextRotate[index].setProperty(hmUI.prop.SRC, normal_month_TextRotate_ASCIIARRAY[charCode]);
                      normal_month_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_month_TextRotate_img_width;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate hour_TIME');
              let valueHour = timeSensor.format_hour;
              let normal_hour_rotate_string = parseInt(valueHour).toString();
              normal_hour_rotate_string = normal_hour_rotate_string.padStart(2, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_hour_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueHour != null && valueHour != undefined && isFinite(valueHour) && normal_hour_rotate_string.length > 0 && normal_hour_rotate_string.length <= 2) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of normal_hour_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_hour_TextRotate[index].setProperty(hmUI.prop.POS_X, 59 + img_offset);
                      normal_hour_TextRotate[index].setProperty(hmUI.prop.SRC, normal_hour_TextRotate_ASCIIARRAY[charCode]);
                      normal_hour_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_hour_TextRotate_img_width + -1;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate minute_TIME');
              let valueMinute = timeSensor.minute;
              let normal_minute_rotate_string = parseInt(valueMinute).toString();
              normal_minute_rotate_string = normal_minute_rotate_string.padStart(2, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_minute_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueMinute != null && valueMinute != undefined && isFinite(valueMinute) && normal_minute_rotate_string.length > 0 && normal_minute_rotate_string.length <= 2) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of normal_minute_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_minute_TextRotate[index].setProperty(hmUI.prop.POS_X, 206 + img_offset);
                      normal_minute_TextRotate[index].setProperty(hmUI.prop.SRC, normal_minute_TextRotate_ASCIIARRAY[charCode]);
                      normal_minute_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_minute_TextRotate_img_width + -1;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };
              let weatherData = weatherSensor.getForecastWeather();
              let temperature_current_temp = -100;
              if (weatherSensor.current != undefined && weatherSensor.current != 'undefined') {
                temperature_current_temp = weatherSensor.current;
              }; // end currentWeather;

              console.log('update text rotate temperature_current_currentWeather');
              let temperatureCurrent = undefined;
              let normal_temperature_current_rotate_string = undefined;
              if (temperature_current_temp > -100) {
                temperatureCurrent = 0;
                normal_temperature_current_rotate_string = String(temperature_current_temp)
              };

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 4; i++) {  // hide all symbols
                  normal_temperature_current_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_temperature_current_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
                if (temperatureCurrent != null && temperatureCurrent != undefined && isFinite(temperatureCurrent) && normal_temperature_current_rotate_string.length > 0 && normal_temperature_current_rotate_string.length <= 4) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of normal_temperature_current_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 4) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_temperature_current_TextRotate[index].setProperty(hmUI.prop.POS_X, 400 + img_offset);
                      normal_temperature_current_TextRotate[index].setProperty(hmUI.prop.SRC, normal_temperature_current_TextRotate_ASCIIARRAY[charCode]);
                      normal_temperature_current_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_temperature_current_TextRotate_img_width;
                      index++;
                    }  // end if digit
                    else { 
                      normal_temperature_current_TextRotate[index].setProperty(hmUI.prop.POS_X, 400 + img_offset);
                      normal_temperature_current_TextRotate[index].setProperty(hmUI.prop.SRC, 'min.png');
                      normal_temperature_current_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_temperature_current_TextRotate_dot_width;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                  normal_temperature_current_TextRotate_unit.setProperty(hmUI.prop.POS_X, 400 + img_offset);
                  normal_temperature_current_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite

              };

            };

            //end of ignored block
            function scale_call() {
              console.log('scale_call()');

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_ls_normal_battery = 1 - progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_linear_scale
                  // initial parameters
                  let start_x_normal_battery = 293;
                  let start_y_normal_battery = 394;
                  let lenght_ls_normal_battery = 52;
                  let line_width_ls_normal_battery = 50;
                  let color_ls_normal_battery = 0xFF313024;
                  
                  // calculated parameters
                  let start_x_normal_battery_draw = start_x_normal_battery;
                  let start_y_normal_battery_draw = start_y_normal_battery;
                  lenght_ls_normal_battery = lenght_ls_normal_battery * progress_ls_normal_battery;
                  let lenght_ls_normal_battery_draw = line_width_ls_normal_battery;
                  let line_width_ls_normal_battery_draw = lenght_ls_normal_battery;
                  if (lenght_ls_normal_battery < 0){
                    line_width_ls_normal_battery_draw = -lenght_ls_normal_battery;
                    start_y_normal_battery_draw = start_y_normal_battery_draw - line_width_ls_normal_battery_draw;
                  };
                  
                  normal_battery_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_battery_draw,
                    y: start_y_normal_battery_draw,
                    w: lenght_ls_normal_battery_draw,
                    h: line_width_ls_normal_battery_draw,
                    color: color_ls_normal_battery,
                  });
                };

                console.log('update scales HEART');
                
                let valueHeartRate = heart_rate.last;
                let targetHeartRate = 179;
                let progressHeartRate = (valueHeartRate - 71)/(targetHeartRate - 71);
                if (progressHeartRate < 0) progressHeartRate = 0;
                if (progressHeartRate > 1) progressHeartRate = 1;
                let progress_cs_normal_heart_rate = 1 - progressHeartRate;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_heart_rate_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_heart_rate * 100);
                  if (normal_heart_rate_circle_scale) {
                    normal_heart_rate_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 240,
                      center_y: 240,
                      start_angle: 350,
                      end_angle: 414,
                      radius: 236,
                      line_width: 9,
                      corner_flag: 0,
                      color: 0xFF2A2A2A,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                text_update();
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerTextUpdate) {
                    normal_timerTextUpdate = timer.createTimer(0, 1000, (function (option) {
                      text_update();
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


                //SwitchBgColor
                if (hmFS.SysProGetInt(`bgColorIndex_${watchfaceId}`) === undefined) {
                  bgColorIndex = 0;
                  hmFS.SysProSetInt(`bgColorIndex_${watchfaceId}`, bgColorIndex);
                } else {
                  bgColorIndex = hmFS.SysProGetInt(`bgColorIndex_${watchfaceId}`);
                };
                if (screenType == hmSetting.screen_type.WATCHFACE && normal_background_bg) normal_background_bg.setProperty(hmUI.prop.COLOR, bgColorList[bgColorIndex]);
              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerTextUpdate) {
                  timer.stopTimer(normal_timerTextUpdate);
                  normal_timerTextUpdate = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
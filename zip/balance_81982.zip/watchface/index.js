﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

// Start smooth on/off

        let elementnumber_1 = 1
        let total_elemente = 2

        function click_elemente() {
if(elementnumber_2==1){
            if(elementnumber_1==total_elemente) {
            elementnumber_1=1;
                UpdateElementeOne();
                }
            else {
                elementnumber_1=elementnumber_1+1;
                if(elementnumber_1==2) {
                  UpdateElementeTwo();
                }

            }
            if(elementnumber_1==1) hmUI.showToast({text: 'Smooth ON'});
            if(elementnumber_1==2) hmUI.showToast({text: 'Smooth OFF'});
        }

        //Smooth on
        function UpdateElementeOne(){
                normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, false);
                normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.VISIBLE, true);

        }

        //smooth off
        function UpdateElementeTwo(){
               normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, true);
                normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.VISIBLE, false);
        }
}

        // Start analog hand on/off

        let elementnumber_2 = 1
        let total_elemente2 = 2

        function click_elemente2() {
            if(elementnumber_2==total_elemente2) {
            elementnumber_2=1;
                UpdateElemente2One();
                }
            else {
                elementnumber_2=elementnumber_2+1;
                if(elementnumber_2==2) {
                  UpdateElemente2Two();
                }

            }
            if(elementnumber_2==1) hmUI.showToast({text: 'Hand clock ON'});
            if(elementnumber_2==2) hmUI.showToast({text: 'Hand clock OFF'});
        }

        //Hand clock on
        function UpdateElemente2One(){
   if(elementnumber_1==1){ normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, false);}
   if(elementnumber_1==1){normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.VISIBLE, true);}
   if(elementnumber_1==2){ normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, true);}
   if(elementnumber_1==2){normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.VISIBLE, false);}
        normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.VISIBLE, true);

        }

        //hand clock off
        function UpdateElemente2Two(){
        normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, false);
        normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.VISIBLE, false);


        }



        // Start color change
        let colornumber_main = 1
        let namecolor_main = ''

        function click_Color() {
if ( colornumber_main == 1) { namecolor_main = "YELLOW"}
if ( colornumber_main == 2) { namecolor_main = "GREEN"}
if ( colornumber_main == 3) { namecolor_main = "BLUE"}
if ( colornumber_main == 4) { namecolor_main = "RED"}
if ( colornumber_main == 5) { namecolor_main = "BLACK AND WHITE"}

hmUI.showToast({text: namecolor_main });
             //hmUI.showToast({text: "color " + parseInt(colornumber_main) });
normal_image_img.setProperty(hmUI.prop.SRC, "main" + parseInt(colornumber_main) + ".png");
setTimeout(function(){
image_top_img.setProperty(hmUI.prop.VISIBLE, false);

        Button_1.setProperty(hmUI.prop.VISIBLE, false);
        Button_2.setProperty(hmUI.prop.VISIBLE, false);
        Button_3.setProperty(hmUI.prop.VISIBLE, false);
        Button_4.setProperty(hmUI.prop.VISIBLE, false);
        Button_5.setProperty(hmUI.prop.VISIBLE, false);
        Button_6.setProperty(hmUI.prop.VISIBLE, true);
        Button_7.setProperty(hmUI.prop.VISIBLE, true);
        Button_8.setProperty(hmUI.prop.VISIBLE, true);
        Button_9.setProperty(hmUI.prop.VISIBLE, true);
        Button_10.setProperty(hmUI.prop.VISIBLE, true);
        Button_11.setProperty(hmUI.prop.VISIBLE, true);
        Button_12.setProperty(hmUI.prop.VISIBLE, true);
        normal_stopwatch_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
        normal_countdown_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
        normal_alarm_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
        normal_sunrise_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
        normal_temperature_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
        normal_pai_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
        normal_spo2_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
        normal_heart_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
        normal_step_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
      }, 1234);   
               
            
        }

function select_color(){
        Button_1.setProperty(hmUI.prop.VISIBLE, true);
        Button_2.setProperty(hmUI.prop.VISIBLE, true);
        Button_3.setProperty(hmUI.prop.VISIBLE, true);
        Button_4.setProperty(hmUI.prop.VISIBLE, true);
        Button_5.setProperty(hmUI.prop.VISIBLE, true);
        Button_6.setProperty(hmUI.prop.VISIBLE, false);
        Button_7.setProperty(hmUI.prop.VISIBLE, false);
        Button_8.setProperty(hmUI.prop.VISIBLE, false);
        Button_9.setProperty(hmUI.prop.VISIBLE, false);
        Button_10.setProperty(hmUI.prop.VISIBLE, false);
        Button_11.setProperty(hmUI.prop.VISIBLE, false);
        Button_12.setProperty(hmUI.prop.VISIBLE, false);
        normal_stopwatch_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_countdown_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_alarm_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_sunrise_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_temperature_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_pai_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_spo2_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_heart_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_step_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
image_top_img.setProperty(hmUI.prop.VISIBLE, true);
}
        // end user_functions.js

        let normal_background_bg = ''
        let normal_rotate_animation_img_1 = '';
        let normal_rotate_animation_param_1 = null;
        let normal_rotate_animation_lastTime_1 = 0;
        let timer_anim_rotate_1;
        let normal_rotate_animation_count_1 = 0;
        let normal_compass_direction_pointer_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_humidity_text_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_calorie_image_progress_img_level = ''
        let normal_step_current_text_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_image_img = ''
        let normal_wind_direction_image_progress_img_level = ''
        let normal_wind_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_battery_pointer_progress_img_pointer = ''
        let normal_heart_rate_TextCircle = new Array(3);
        let normal_heart_rate_TextCircle_ASCIIARRAY = new Array(10);
        let normal_heart_rate_TextCircle_img_width = 10;
        let normal_heart_rate_TextCircle_img_height = 16;
        let normal_heart_rate_TextCircle_error_img_width = 1;
        let normal_heart_rate_image_progress_img_level = ''
        let normal_heart_rate_pointer_progress_img_pointer = ''
        let normal_digital_clock_img_time_second = ''
        let normal_digital_clock_img_time_minute = ''
        let normal_digital_clock_img_time_hour = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_analog_clock_pro_hour_pointer_img = ''
        let normal_analog_clock_pro_minute_pointer_img = ''
        let normal_timerUpdateSec = undefined;
        let normal_analog_clock_pro_second_pointer_img = ''
        let normal_timerUpdateSecSmooth = undefined;
        let lastTime = 0;
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg_img = ''
        let idle_image_img = ''
        let idle_moon_image_progress_img_level = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_day = ''
        let idle_humidity_text_text_img = ''
        let idle_temperature_icon_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_temperature_current_text_img = ''
        let idle_distance_text_text_img = ''
        let idle_calorie_current_text_img = ''
        let idle_calorie_image_progress_img_level = ''
        let idle_step_current_text_img = ''
        let idle_step_image_progress_img_level = ''
        let idle_wind_direction_image_progress_img_level = ''
        let idle_wind_text_text_img = ''
        let idle_battery_image_progress_img_level = ''
        let idle_battery_pointer_progress_img_pointer = ''
        let idle_heart_rate_TextCircle = new Array(3);
        let idle_heart_rate_TextCircle_ASCIIARRAY = new Array(10);
        let idle_heart_rate_TextCircle_img_width = 10;
        let idle_heart_rate_TextCircle_img_height = 16;
        let idle_heart_rate_TextCircle_error_img_width = 1;
        let idle_heart_rate_image_progress_img_level = ''
        let idle_heart_rate_pointer_progress_img_pointer = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_digital_clock_img_time_second = ''
        let idle_digital_clock_img_time_minute = ''
        let idle_digital_clock_img_time_hour = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_analog_clock_time_pointer_second = ''
        let image_top_img = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let Button_7 = ''
        let Button_8 = ''
        let Button_9 = ''
        let Button_10 = ''
        let Button_11 = ''
        let Button_12 = ''
        let timeSensor = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFFB2B2B2',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_rotate_animation_img_1 = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 481,
              h: 481,
              pos_x: 61,
              pos_y: 61,
              center_x: 240,
              center_y: 240,
              angle: 360,
              src: 'animation/circle_0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_rotate_animation_param_1 = {
              anim_steps: [{
                anim_rate: 'linear',
                anim_duration: 10000,
                anim_from: 360,
                anim_to: 0,
                anim_key: "angle",
              }],
              anim_fps: 15,
              anim_auto_start: 1,
              anim_repeat: 1,
              anim_auto_destroy: 1,
            };

            let now = hmSensor.createSensor(hmSensor.id.TIME);

            function anim_rotate_1_complete_call() {
              normal_rotate_animation_img_1.setProperty(hmUI.prop.ANIM, normal_rotate_animation_param_1);
              normal_rotate_animation_lastTime_1 = now.utc;
              normal_rotate_animation_count_1 = normal_rotate_animation_count_1 - 1;
              if(normal_rotate_animation_count_1 < -1) normal_rotate_animation_count_1 = - 1;
              if(normal_rotate_animation_count_1 == 0) stop_anim_rotate_1();
            }; // end animation callback function
            
            function stop_anim_rotate_1() {
              if (timer_anim_rotate_1) {
                timer.stopTimer(timer_anim_rotate_1);
                timer_anim_rotate_1 = undefined;
              };
            }; // end stop_anim_rotate function

            // normal_rotate_anime_1 = hmUI.createWidget(hmUI.widget.Rotate_Animation, {
              // start_angle: 360,
              // end_angle: 0,
              // pos_x: 179,
              // pos_y: 179,
              // center_x: 240,
              // center_y: 240,
              // src: 'circle_0.png',
              // anim_fps: 15,
              // anim_duration: 10000,
              // repeat_count: 0,
              // anim_two_sides: False,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            const deviceInfo = hmSetting.getDeviceInfo();
            
            // normal_compass_custom_pointer_img = hmUI.createWidget(hmUI.widget.CUSTOM_POINTER, {
              // src: 'Compress_icon.png',
              // center_x: 282,
              // center_y: 341,
              // x: 12,
              // y: 12,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.COMPASS,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            //start of ignored block
            normal_compass_direction_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 282 - 12,
              pos_y: 341 - 12,
              center_x: 282,
              center_y: 341,
              src: 'Compress_icon.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            //end of ignored block

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 183,
              y: 329,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 198,
              y: 284,
              week_en: ["Week_01.png","Week_02.png","Week_03.png","Week_04.png","Week_05.png","Week_06.png","Week_07.png"],
              week_tc: ["Week_01.png","Week_02.png","Week_03.png","Week_04.png","Week_05.png","Week_06.png","Week_07.png"],
              week_sc: ["Week_01.png","Week_02.png","Week_03.png","Week_04.png","Week_05.png","Week_06.png","Week_07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 221,
              month_startY: 343,
              month_sc_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_tc_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_en_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 223,
              day_startY: 309,
              day_sc_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              day_tc_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              day_en_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 304,
              y: 283,
              font_array: ["ACT_B_0.png","ACT_B_1.png","ACT_B_2.png","ACT_B_3.png","ACT_B_4.png","ACT_B_5.png","ACT_B_6.png","ACT_B_7.png","ACT_B_8.png","ACT_B_9.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 355,
              y: 219,
              image_array: ["Weather_icon_01.png","Weather_icon_02.png","Weather_icon_03.png","Weather_icon_04.png","Weather_icon_05.png","Weather_icon_06.png","Weather_icon_07.png","Weather_icon_08.png","Weather_icon_09.png","Weather_icon_10.png","Weather_icon_11.png","Weather_icon_12.png","Weather_icon_13.png","Weather_icon_14.png","Weather_icon_15.png","Weather_icon_16.png","Weather_icon_17.png","Weather_icon_18.png","Weather_icon_19.png","Weather_icon_20.png","Weather_icon_21.png","Weather_icon_22.png","Weather_icon_23.png","Weather_icon_24.png","Weather_icon_25.png","Weather_icon_26.png","Weather_icon_27.png","Weather_icon_28.png","Weather_icon_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 359,
              y: 259,
              font_array: ["ACT_B_0.png","ACT_B_1.png","ACT_B_2.png","ACT_B_3.png","ACT_B_4.png","ACT_B_5.png","ACT_B_6.png","ACT_B_7.png","ACT_B_8.png","ACT_B_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Weather_symbol_1.png',
              unit_tc: 'Weather_symbol_1.png',
              unit_en: 'Weather_symbol_1.png',
              imperial_unit_sc: 'Weather_symbol_1.png',
              imperial_unit_tc: 'Weather_symbol_1.png',
              imperial_unit_en: 'Weather_symbol_1.png',
              negative_image: 'Weather_symbol_2.png',
              invalid_image: 'Weather_symbol_2.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const temperatureUnit = hmSetting.getTemperatureUnit();
            //start of ignored block
            if (temperatureUnit == 1) {
              normal_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
                x: 359,
                y: 259,
                font_array: ["ACT_B_0.png","ACT_B_1.png","ACT_B_2.png","ACT_B_3.png","ACT_B_4.png","ACT_B_5.png","ACT_B_6.png","ACT_B_7.png","ACT_B_8.png","ACT_B_9.png"],
                padding: false,
                h_space: 0,
                unit_sc: 'Weather_symbol_1.png',
                unit_tc: 'Weather_symbol_1.png',
                unit_en: 'Weather_symbol_1.png',
                imperial_unit_sc: 'Weather_symbol_1.png',
                imperial_unit_tc: 'Weather_symbol_1.png',
                imperial_unit_en: 'Weather_symbol_1.png',
                negative_image: 'Weather_symbol_2.png',
                invalid_image: 'Weather_symbol_2.png',
                align_h: hmUI.align.CENTER_H,
                type: hmUI.data_type.WEATHER_CURRENT,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
            };
            //end of ignored block

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 260,
              y: 81,
              font_array: ["ACT_B_0.png","ACT_B_1.png","ACT_B_2.png","ACT_B_3.png","ACT_B_4.png","ACT_B_5.png","ACT_B_6.png","ACT_B_7.png","ACT_B_8.png","ACT_B_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Dis_KM.png',
              unit_tc: 'Dis_KM.png',
              unit_en: 'Dis_KM.png',
              imperial_unit_sc: 'Dis_Mi.png',
              imperial_unit_tc: 'Dis_Mi.png',
              imperial_unit_en: 'Dis_Mi.png',
              dot_image: 'Dis_dot.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 172,
              y: 84,
              font_array: ["ACT_B_0.png","ACT_B_1.png","ACT_B_2.png","ACT_B_3.png","ACT_B_4.png","ACT_B_5.png","ACT_B_6.png","ACT_B_7.png","ACT_B_8.png","ACT_B_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 172,
              y: 45,
              image_array: ["Cal_progress_1.png","Cal_progress_2.png","Cal_progress_3.png","Cal_progress_4.png","Cal_progress_5.png"],
              image_length: 5,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 213,
              y: 100,
              font_array: ["ACT_B_0.png","ACT_B_1.png","ACT_B_2.png","ACT_B_3.png","ACT_B_4.png","ACT_B_5.png","ACT_B_6.png","ACT_B_7.png","ACT_B_8.png","ACT_B_9.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 209,
              y: 58,
              image_array: ["Step_progress_1.png","Step_progress_2.png","Step_progress_3.png","Step_progress_4.png","Step_progress_5.png"],
              image_length: 5,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'main1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_direction_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 253,
              y: 369,
              image_array: ["Wind_direction_1.png","Wind_direction_2.png","Wind_direction_3.png","Wind_direction_4.png","Wind_direction_5.png","Wind_direction_6.png","Wind_direction_7.png","Wind_direction_8.png"],
              image_length: 8,
              type: hmUI.data_type.WIND_DIRECTION,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 244,
              y: 382,
              font_array: ["ACT_B_0.png","ACT_B_1.png","ACT_B_2.png","ACT_B_3.png","ACT_B_4.png","ACT_B_5.png","ACT_B_6.png","ACT_B_7.png","ACT_B_8.png","ACT_B_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WIND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 77,
              y: 185,
              image_array: ["Batt_icon_01.png","Batt_icon_02.png","Batt_icon_03.png","Batt_icon_04.png","Batt_icon_05.png"],
              image_length: 5,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'Pointer_batt.png',
              center_x: 120,
              center_y: 240,
              x: 27,
              y: 47,
              start_angle: 214,
              end_angle: 391,
              invalid_visible: false,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_heart_rate_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 120,
              // circle_center_Y: 240,
              // font_array: ["Act_0.png","Act_1.png","Act_2.png","Act_3.png","Act_4.png","Act_5.png","Act_6.png","Act_7.png","Act_8.png","Act_9.png"],
              // radius: 74,
              // angle: 105,
              // char_space_angle: 4,
              // error_image: '0_Empty.png',
              // zero: false,
              // reverse_direction: true,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: LEFT,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_heart_rate_TextCircle_ASCIIARRAY[0] = 'Act_0.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[1] = 'Act_1.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[2] = 'Act_2.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[3] = 'Act_3.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[4] = 'Act_4.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[5] = 'Act_5.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[6] = 'Act_6.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[7] = 'Act_7.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[8] = 'Act_8.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[9] = 'Act_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 3; i++) {
              normal_heart_rate_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 120,
                center_y: 240,
                pos_x: 120 - normal_heart_rate_TextCircle_img_width / 2,
                pos_y: 240 + 58,
                src: 'Act_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_heart_rate_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            
            const heart_rate = hmSensor.createSensor(hmSensor.id.HEART);
            heart_rate.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });
            
            function toDegree (radian) {
              return radian * (180 / Math.PI);
            };

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 144,
              y: 239,
              image_array: ["Zone1.png","Zone2.png","Zone3.png","Zone4.png","Zone5.png","Zone6.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'Pointer_heart.png',
              center_x: 120,
              center_y: 240,
              x: 23,
              y: 66,
              start_angle: 180,
              end_angle: 124,
              invalid_visible: false,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_second = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              second_startX: 309,
              second_startY: 173,
              second_array: ["Time_S_0.png","Time_S_1.png","Time_S_2.png","Time_S_3.png","Time_S_4.png","Time_S_5.png","Time_S_6.png","Time_S_7.png","Time_S_8.png","Time_S_9.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 244,
              minute_startY: 135,
              minute_array: ["Time_0.png","Time_1.png","Time_2.png","Time_3.png","Time_4.png","Time_5.png","Time_6.png","Time_7.png","Time_8.png","Time_9.png"],
              minute_zero: 1,
              minute_space: -1,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 182,
              hour_startY: 135,
              hour_array: ["Time_0.png","Time_1.png","Time_2.png","Time_3.png","Time_4.png","Time_5.png","Time_6.png","Time_7.png","Time_8.png","Time_9.png"],
              hour_zero: 1,
              hour_space: -1,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 158,
              am_y: 121,
              am_sc_path: 'Clock_AM.png',
              am_en_path: 'Clock_AM.png',
              pm_x: 158,
              pm_y: 121,
              pm_sc_path: 'Clock_PM.png',
              pm_en_path: 'Clock_PM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 348,
              y: 349,
              src: 'System_BT_OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 169,
              y: 135,
              src: 'System_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.MINUTEEND, function() {
              let updateHour = timeSensor.minute == 0;

              time_update(updateHour, true);
            });

            // normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'Hand_H1.png',
              // center_x: 240,
              // center_y: 240,
              // x: 36,
              // y: 231,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.hour,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 36,
              pos_y: 240 - 231,
              center_x: 240,
              center_y: 240,
              src: 'Hand_H1.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            // normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'Hand_M1.png',
              // center_x: 240,
              // center_y: 240,
              // x: 36,
              // y: 231,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.minute,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 36,
              pos_y: 240 - 231,
              center_x: 240,
              center_y: 240,
              src: 'Hand_M1.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'Hand_S1.png',
              // center_x: 240,
              // center_y: 240,
              // x: 36,
              // y: 231,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 36,
              pos_y: 240 - 231,
              center_x: 240,
              center_y: 240,
              src: 'Hand_S1.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            function startSecAnim(sec, animDuration) {
              const secAnim = {
                anim_steps: [{
                  anim_rate: 'linear',
                  anim_duration: animDuration,
                  anim_from: sec,
                  anim_to: sec + (360*(animDuration*6/1000))/360,
                  anim_key: 'angle',
                }],
                anim_fps: 15,
                anim_auto_start: 1,
                anim_repeat: 1,
                anim_auto_destroy: 1,
              }
              normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANIM, secAnim);
            }
            // normal_analog_clock_pro_smooth_second = hmUI.createWidget(hmUI.widget.SMOOTH_SECOND, {
              // type: 4,
              // fps: 15,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'Hand_S1.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 36,
              second_posY: 231,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'main5.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'main_aod.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 183,
              y: 329,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 198,
              y: 283,
              week_en: ["AOD_Week_01.png","AOD_Week_02.png","AOD_Week_03.png","AOD_Week_04.png","AOD_Week_05.png","AOD_Week_06.png","AOD_Week_07.png"],
              week_tc: ["AOD_Week_01.png","AOD_Week_02.png","AOD_Week_03.png","AOD_Week_04.png","AOD_Week_05.png","AOD_Week_06.png","AOD_Week_07.png"],
              week_sc: ["AOD_Week_01.png","AOD_Week_02.png","AOD_Week_03.png","AOD_Week_04.png","AOD_Week_05.png","AOD_Week_06.png","AOD_Week_07.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 221,
              month_startY: 343,
              month_sc_array: ["AOD_Month_01.png","AOD_Month_02.png","AOD_Month_03.png","AOD_Month_04.png","AOD_Month_05.png","AOD_Month_06.png","AOD_Month_07.png","AOD_Month_08.png","AOD_Month_09.png","AOD_Month_10.png","AOD_Month_11.png","AOD_Month_12.png"],
              month_tc_array: ["AOD_Month_01.png","AOD_Month_02.png","AOD_Month_03.png","AOD_Month_04.png","AOD_Month_05.png","AOD_Month_06.png","AOD_Month_07.png","AOD_Month_08.png","AOD_Month_09.png","AOD_Month_10.png","AOD_Month_11.png","AOD_Month_12.png"],
              month_en_array: ["AOD_Month_01.png","AOD_Month_02.png","AOD_Month_03.png","AOD_Month_04.png","AOD_Month_05.png","AOD_Month_06.png","AOD_Month_07.png","AOD_Month_08.png","AOD_Month_09.png","AOD_Month_10.png","AOD_Month_11.png","AOD_Month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 223,
              day_startY: 309,
              day_sc_array: ["AOD_Day_0.png","AOD_Day_1.png","AOD_Day_2.png","AOD_Day_3.png","AOD_Day_4.png","AOD_Day_5.png","AOD_Day_6.png","AOD_Day_7.png","AOD_Day_8.png","AOD_Day_9.png"],
              day_tc_array: ["AOD_Day_0.png","AOD_Day_1.png","AOD_Day_2.png","AOD_Day_3.png","AOD_Day_4.png","AOD_Day_5.png","AOD_Day_6.png","AOD_Day_7.png","AOD_Day_8.png","AOD_Day_9.png"],
              day_en_array: ["AOD_Day_0.png","AOD_Day_1.png","AOD_Day_2.png","AOD_Day_3.png","AOD_Day_4.png","AOD_Day_5.png","AOD_Day_6.png","AOD_Day_7.png","AOD_Day_8.png","AOD_Day_9.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 304,
              y: 283,
              font_array: ["AOD_ACT_B_0.png","AOD_ACT_B_1.png","AOD_ACT_B_2.png","AOD_ACT_B_3.png","AOD_ACT_B_4.png","AOD_ACT_B_5.png","AOD_ACT_B_6.png","AOD_ACT_B_7.png","AOD_ACT_B_8.png","AOD_ACT_B_9.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 270,
              y: 330,
              src: 'AOD_Compress_icon.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 355,
              y: 219,
              image_array: ["AOD_Weather_icon_01.png","AOD_Weather_icon_02.png","AOD_Weather_icon_03.png","AOD_Weather_icon_04.png","AOD_Weather_icon_05.png","AOD_Weather_icon_06.png","AOD_Weather_icon_07.png","AOD_Weather_icon_08.png","AOD_Weather_icon_09.png","AOD_Weather_icon_10.png","AOD_Weather_icon_11.png","AOD_Weather_icon_12.png","AOD_Weather_icon_13.png","AOD_Weather_icon_14.png","AOD_Weather_icon_15.png","AOD_Weather_icon_16.png","AOD_Weather_icon_17.png","AOD_Weather_icon_18.png","AOD_Weather_icon_19.png","AOD_Weather_icon_20.png","AOD_Weather_icon_21.png","AOD_Weather_icon_22.png","AOD_Weather_icon_23.png","AOD_Weather_icon_24.png","AOD_Weather_icon_25.png","AOD_Weather_icon_26.png","AOD_Weather_icon_27.png","AOD_Weather_icon_28.png","AOD_Weather_icon_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 359,
              y: 259,
              font_array: ["AOD_ACT_B_0.png","AOD_ACT_B_1.png","AOD_ACT_B_2.png","AOD_ACT_B_3.png","AOD_ACT_B_4.png","AOD_ACT_B_5.png","AOD_ACT_B_6.png","AOD_ACT_B_7.png","AOD_ACT_B_8.png","AOD_ACT_B_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'AOD_Weather_symbol_1.png',
              unit_tc: 'AOD_Weather_symbol_1.png',
              unit_en: 'AOD_Weather_symbol_1.png',
              imperial_unit_sc: 'AOD_Weather_symbol_2.png',
              imperial_unit_tc: 'AOD_Weather_symbol_2.png',
              imperial_unit_en: 'AOD_Weather_symbol_2.png',
              negative_image: 'AOD_Weather_symbol_2.png',
              invalid_image: 'AOD_Weather_symbol_2.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            //start of ignored block
            if (temperatureUnit == 1) {
              idle_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
                x: 359,
                y: 259,
                font_array: ["AOD_ACT_B_0.png","AOD_ACT_B_1.png","AOD_ACT_B_2.png","AOD_ACT_B_3.png","AOD_ACT_B_4.png","AOD_ACT_B_5.png","AOD_ACT_B_6.png","AOD_ACT_B_7.png","AOD_ACT_B_8.png","AOD_ACT_B_9.png"],
                padding: false,
                h_space: 0,
                unit_sc: 'AOD_Weather_symbol_2.png',
                unit_tc: 'AOD_Weather_symbol_2.png',
                unit_en: 'AOD_Weather_symbol_2.png',
                imperial_unit_sc: 'AOD_Weather_symbol_1.png',
                imperial_unit_tc: 'AOD_Weather_symbol_1.png',
                imperial_unit_en: 'AOD_Weather_symbol_1.png',
                negative_image: 'AOD_Weather_symbol_2.png',
                invalid_image: 'AOD_Weather_symbol_2.png',
                align_h: hmUI.align.CENTER_H,
                type: hmUI.data_type.WEATHER_CURRENT,
                show_level: hmUI.show_level.ONLY_AOD,
              });
            };
            //end of ignored block

            idle_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 260,
              y: 81,
              font_array: ["AOD_ACT_B_0.png","AOD_ACT_B_1.png","AOD_ACT_B_2.png","AOD_ACT_B_3.png","AOD_ACT_B_4.png","AOD_ACT_B_5.png","AOD_ACT_B_6.png","AOD_ACT_B_7.png","AOD_ACT_B_8.png","AOD_ACT_B_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Aod_dis_km.png',
              unit_tc: 'Aod_dis_km.png',
              unit_en: 'Aod_dis_km.png',
              imperial_unit_sc: 'Aod_dis_mi.png',
              imperial_unit_tc: 'Aod_dis_mi.png',
              imperial_unit_en: 'Aod_dis_mi.png',
              dot_image: 'Aod_dis_dot.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 172,
              y: 84,
              font_array: ["AOD_ACT_B_0.png","AOD_ACT_B_1.png","AOD_ACT_B_2.png","AOD_ACT_B_3.png","AOD_ACT_B_4.png","AOD_ACT_B_5.png","AOD_ACT_B_6.png","AOD_ACT_B_7.png","AOD_ACT_B_8.png","AOD_ACT_B_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 172,
              y: 39,
              image_array: ["Cal_progress_1.png","Cal_progress_2.png","Cal_progress_3.png","Cal_progress_4.png","Cal_progress_5.png"],
              image_length: 5,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 213,
              y: 100,
              font_array: ["AOD_ACT_B_0.png","AOD_ACT_B_1.png","AOD_ACT_B_2.png","AOD_ACT_B_3.png","AOD_ACT_B_4.png","AOD_ACT_B_5.png","AOD_ACT_B_6.png","AOD_ACT_B_7.png","AOD_ACT_B_8.png","AOD_ACT_B_9.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 209,
              y: 58,
              image_array: ["Step_progress_1.png","Step_progress_2.png","Step_progress_3.png","Step_progress_4.png","Step_progress_5.png"],
              image_length: 5,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_wind_direction_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 253,
              y: 369,
              image_array: ["Wind_direction_1.png","Wind_direction_2.png","Wind_direction_3.png","Wind_direction_4.png","Wind_direction_5.png","Wind_direction_6.png","Wind_direction_7.png","Wind_direction_8.png"],
              image_length: 8,
              type: hmUI.data_type.WIND_DIRECTION,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_wind_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 244,
              y: 382,
              font_array: ["AOD_ACT_B_0.png","AOD_ACT_B_1.png","AOD_ACT_B_2.png","AOD_ACT_B_3.png","AOD_ACT_B_4.png","AOD_ACT_B_5.png","AOD_ACT_B_6.png","AOD_ACT_B_7.png","AOD_ACT_B_8.png","AOD_ACT_B_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WIND,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 77,
              y: 185,
              image_array: ["Batt_icon_01.png","Batt_icon_02.png","Batt_icon_03.png","Batt_icon_04.png","Batt_icon_05.png"],
              image_length: 5,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'Pointer_batt.png',
              center_x: 120,
              center_y: 240,
              x: 27,
              y: 47,
              start_angle: 214,
              end_angle: 391,
              invalid_visible: false,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_heart_rate_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 120,
              // circle_center_Y: 240,
              // font_array: ["AOD_ACT_B_0.png","AOD_ACT_B_1.png","AOD_ACT_B_2.png","AOD_ACT_B_3.png","AOD_ACT_B_4.png","AOD_ACT_B_5.png","AOD_ACT_B_6.png","AOD_ACT_B_7.png","AOD_ACT_B_8.png","AOD_ACT_B_9.png"],
              // radius: 74,
              // angle: 105,
              // char_space_angle: 4,
              // error_image: '0_Empty.png',
              // zero: false,
              // reverse_direction: true,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: LEFT,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_heart_rate_TextCircle_ASCIIARRAY[0] = 'AOD_ACT_B_0.png';  // set of images with numbers
            idle_heart_rate_TextCircle_ASCIIARRAY[1] = 'AOD_ACT_B_1.png';  // set of images with numbers
            idle_heart_rate_TextCircle_ASCIIARRAY[2] = 'AOD_ACT_B_2.png';  // set of images with numbers
            idle_heart_rate_TextCircle_ASCIIARRAY[3] = 'AOD_ACT_B_3.png';  // set of images with numbers
            idle_heart_rate_TextCircle_ASCIIARRAY[4] = 'AOD_ACT_B_4.png';  // set of images with numbers
            idle_heart_rate_TextCircle_ASCIIARRAY[5] = 'AOD_ACT_B_5.png';  // set of images with numbers
            idle_heart_rate_TextCircle_ASCIIARRAY[6] = 'AOD_ACT_B_6.png';  // set of images with numbers
            idle_heart_rate_TextCircle_ASCIIARRAY[7] = 'AOD_ACT_B_7.png';  // set of images with numbers
            idle_heart_rate_TextCircle_ASCIIARRAY[8] = 'AOD_ACT_B_8.png';  // set of images with numbers
            idle_heart_rate_TextCircle_ASCIIARRAY[9] = 'AOD_ACT_B_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 3; i++) {
              idle_heart_rate_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 120,
                center_y: 240,
                pos_x: 120 - idle_heart_rate_TextCircle_img_width / 2,
                pos_y: 240 + 58,
                src: 'AOD_ACT_B_0.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_heart_rate_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            idle_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 144,
              y: 239,
              image_array: ["Zone1.png","Zone2.png","Zone3.png","Zone4.png","Zone5.png","Zone6.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'Pointer_heart.png',
              center_x: 120,
              center_y: 240,
              x: 23,
              y: 66,
              start_angle: 180,
              end_angle: 124,
              invalid_visible: false,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 348,
              y: 349,
              src: 'System_BT_OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 169,
              y: 135,
              src: 'System_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_second = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              second_startX: 309,
              second_startY: 173,
              second_array: ["AOD_Time_S_0.png","AOD_Time_S_1.png","AOD_Time_S_2.png","AOD_Time_S_3.png","AOD_Time_S_4.png","AOD_Time_S_5.png","AOD_Time_S_6.png","AOD_Time_S_7.png","AOD_Time_S_8.png","AOD_Time_S_9.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 244,
              minute_startY: 135,
              minute_array: ["AOD_Time_0.png","AOD_Time_1.png","AOD_Time_2.png","AOD_Time_3.png","AOD_Time_4.png","AOD_Time_5.png","AOD_Time_6.png","AOD_Time_7.png","AOD_Time_8.png","AOD_Time_9.png"],
              minute_zero: 1,
              minute_space: -1,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 181,
              hour_startY: 135,
              hour_array: ["AOD_Time_0.png","AOD_Time_1.png","AOD_Time_2.png","AOD_Time_3.png","AOD_Time_4.png","AOD_Time_5.png","AOD_Time_6.png","AOD_Time_7.png","AOD_Time_8.png","AOD_Time_9.png"],
              hour_zero: 1,
              hour_space: -1,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 158,
              am_y: 121,
              am_sc_path: 'Clock_AM.png',
              am_en_path: 'Clock_AM.png',
              pm_x: 158,
              pm_y: 121,
              pm_sc_path: 'Clock_PM.png',
              pm_en_path: 'Clock_PM.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'Hand_H1.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 36,
              hour_posY: 231,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'Hand_M1.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 36,
              minute_posY: 231,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'Hand_S1.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 36,
              second_posY: 231,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            image_top_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'select_color.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            console.log('Watch_Face.Shortcuts');

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 245,
              y: 134,
              w: 56,
              h: 40,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 306,
              y: 170,
              w: 45,
              h: 29,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 146,
              y: 121,
              w: 39,
              h: 34,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 181,
              y: 325,
              w: 33,
              h: 39,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 350,
              y: 218,
              w: 52,
              h: 56,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 165,
              y: 56,
              w: 51,
              h: 46,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 115,
              y: 281,
              w: 53,
              h: 38,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 149,
              y: 245,
              w: 34,
              h: 35,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 222,
              y: 78,
              w: 41,
              h: 38,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 246,
              y: 272,
              w: 129,
              h: 131,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                //color5
                colornumber_main = 5
                click_Color()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 104,
              y: 272,
              w: 129,
              h: 131,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                // color4
                colornumber_main = 4
                click_Color()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 315,
              y: 134,
              w: 129,
              h: 131,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                // color3
                colornumber_main = 3
                click_Color()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 178,
              y: 133,
              w: 129,
              h: 131,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                // color2
                colornumber_main = 2
                click_Color()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 36,
              y: 133,
              w: 129,
              h: 131,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                //color1
                colornumber_main = 1
                click_Color()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 347,
              y: 168,
              w: 67,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                //Change color Style 
                select_color()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_7 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 214,
              y: 212,
              w: 54,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                // Analog ON/OFF
                click_elemente2()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_8 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 429,
              y: 212,
              w: 47,
              h: 57,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                // Smooth ON/OFF
                click_elemente()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_9 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 269,
              y: 55,
              w: 44,
              h: 47,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'SportListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_10 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 265,
              y: 320,
              w: 44,
              h: 47,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'CompassScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_11 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 221,
              y: 305,
              w: 44,
              h: 47,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_12 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 72,
              y: 190,
              w: 44,
              h: 47,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PowerSaveHintScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            console.log('user_script_end.js');
            // start user_script_end.js

let cc=0
if(cc==0){
image_top_img.setProperty(hmUI.prop.VISIBLE, false);
normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, false);
cc =1
        Button_1.setProperty(hmUI.prop.VISIBLE, false);
        Button_2.setProperty(hmUI.prop.VISIBLE, false);
        Button_3.setProperty(hmUI.prop.VISIBLE, false);
        Button_4.setProperty(hmUI.prop.VISIBLE, false);
        Button_5.setProperty(hmUI.prop.VISIBLE, false);
        Button_6.setProperty(hmUI.prop.VISIBLE, true);
        Button_7.setProperty(hmUI.prop.VISIBLE, true);
        Button_8.setProperty(hmUI.prop.VISIBLE, true);
        Button_9.setProperty(hmUI.prop.VISIBLE, true);
        Button_10.setProperty(hmUI.prop.VISIBLE, true);
        Button_11.setProperty(hmUI.prop.VISIBLE, true);
        Button_12.setProperty(hmUI.prop.VISIBLE, true);
        normal_stopwatch_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
        normal_countdown_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
        normal_alarm_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
        normal_sunrise_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
        normal_temperature_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
        normal_pai_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
        normal_spo2_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
        normal_heart_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
        normal_step_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
}
            // end user_script_end.js

            //start of ignored block
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              if (updateHour) {
                let normal_hour = hour;
                let normal_fullAngle_hour = 360;
                if (normal_hour > 11) normal_hour -= 12;
                let normal_angle_hour = 0 + normal_fullAngle_hour*normal_hour/12 + (normal_fullAngle_hour/12)*minute/60;
                if (normal_analog_clock_pro_hour_pointer_img) normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_hour);
              };

              if (updateMinute) {
                let normal_fullAngle_minute = 360;
                let normal_angle_minute = 0 + normal_fullAngle_minute*(minute + second/60)/60;
                if (normal_analog_clock_pro_minute_pointer_img) normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_minute);
              };

            };

            //end of ignored block
            //start of ignored block
            function text_update() {
              console.log('text_update()');

              console.log('update text circle heart_rate_HEART');
              let valueHeartRate = heart_rate.last;
              let normal_heart_rate_circle_string = parseInt(valueHeartRate).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  normal_heart_rate_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = 285;
                if (valueHeartRate != null && valueHeartRate != undefined && isFinite(valueHeartRate) && normal_heart_rate_circle_string.length > 0 && normal_heart_rate_circle_string.length <= 3) {  // display data if it was possible to get it
                  let normal_heart_rate_TextCircle_img_angle = 0;
                  let normal_heart_rate_TextCircle_dot_img_angle = 0;
                  normal_heart_rate_TextCircle_img_angle = toDegree(Math.atan2(normal_heart_rate_TextCircle_img_width/2, 74));
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_heart_rate_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= normal_heart_rate_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_heart_rate_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_heart_rate_TextCircle[index].setProperty(hmUI.prop.POS_X, 120 - normal_heart_rate_TextCircle_img_width / 2);
                      normal_heart_rate_TextCircle[index].setProperty(hmUI.prop.SRC, normal_heart_rate_TextCircle_ASCIIARRAY[charCode]);
                      normal_heart_rate_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= normal_heart_rate_TextCircle_img_angle + 4;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite
                else {
                  normal_heart_rate_TextCircle[0].setProperty(hmUI.prop.ANGLE, char_Angle);
                  normal_heart_rate_TextCircle[0].setProperty(hmUI.prop.POS_X, 120 - normal_heart_rate_TextCircle_error_img_width / 2);
                  normal_heart_rate_TextCircle[0].setProperty(hmUI.prop.SRC, '0_Empty.png');
                  normal_heart_rate_TextCircle[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

              console.log('update text circle heart_rate_HEART');
              let idle_heart_rate_circle_string = parseInt(valueHeartRate).toString();

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  idle_heart_rate_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = 285;
                if (valueHeartRate != null && valueHeartRate != undefined && isFinite(valueHeartRate) && idle_heart_rate_circle_string.length > 0 && idle_heart_rate_circle_string.length <= 3) {  // display data if it was possible to get it
                  let idle_heart_rate_TextCircle_img_angle = 0;
                  let idle_heart_rate_TextCircle_dot_img_angle = 0;
                  idle_heart_rate_TextCircle_img_angle = toDegree(Math.atan2(idle_heart_rate_TextCircle_img_width/2, 74));
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of idle_heart_rate_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= idle_heart_rate_TextCircle_img_angle;
                      firstSymbol = false;
                      idle_heart_rate_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      idle_heart_rate_TextCircle[index].setProperty(hmUI.prop.POS_X, 120 - idle_heart_rate_TextCircle_img_width / 2);
                      idle_heart_rate_TextCircle[index].setProperty(hmUI.prop.SRC, idle_heart_rate_TextCircle_ASCIIARRAY[charCode]);
                      idle_heart_rate_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= idle_heart_rate_TextCircle_img_angle + 4;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite
                else {
                  idle_heart_rate_TextCircle[0].setProperty(hmUI.prop.ANGLE, char_Angle);
                  idle_heart_rate_TextCircle[0].setProperty(hmUI.prop.POS_X, 120 - idle_heart_rate_TextCircle_error_img_width / 2);
                  idle_heart_rate_TextCircle[0].setProperty(hmUI.prop.SRC, '0_Empty.png');
                  idle_heart_rate_TextCircle[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

            };

            //end of ignored block
            //start of ignored block
            console.log('compass_update()');
            if (screenType == hmSetting.screen_type.WATCHFACE){
              compass = hmSensor.createSensor(hmSensor.id.COMPASS);
              compass.start();

              if (compass.direction_angle && compass.direction  && compass.direction_angle != 'INVALID') { // initial data
                // Compass Pointer
                let compass_direction_angle = parseInt(compass.direction_angle);
                normal_compass_direction_pointer_img.setProperty(hmUI.prop.ANGLE, -compass_direction_angle);

              } else { // error data
                normal_compass_direction_pointer_img.setProperty(hmUI.prop.ANGLE, 0);

              }

              compass.addEventListener(hmSensor.event.CHANGE, function (compass_res) { // change values when changing direction

                if (compass_res.calibration_status) {
                  // Compass Pointer
                  let compass_direction_angle = parseInt(compass_res.direction_angle);
                  normal_compass_direction_pointer_img.setProperty(hmUI.prop.ANGLE, -compass_direction_angle);

                } else { // error data
                  normal_compass_direction_pointer_img.setProperty(hmUI.prop.ANGLE, 0);

                }

              }); // Listener end

            };
            //end of ignored block

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                time_update(true, true);
                text_update();

                let nawAnimationTime = now.utc;;
                
                let delay_anim_rotate_1 = 0;
                let repeat_anim_rotate_1 = 10000;
                delay_anim_rotate_1 = repeat_anim_rotate_1 - (nawAnimationTime - normal_rotate_animation_lastTime_1);
                if(delay_anim_rotate_1 < 0) delay_anim_rotate_1 = 0; 
                if((nawAnimationTime - normal_rotate_animation_lastTime_1) > repeat_anim_rotate_1) {
                  normal_rotate_animation_count_1 = 0;
                  timer_anim_rotate_1_mirror = false;
                };

                if (!timer_anim_rotate_1) {
                  timer_anim_rotate_1 = timer.createTimer(delay_anim_rotate_1, repeat_anim_rotate_1, (function (option) {
                    anim_rotate_1_complete_call()
                  })); // end timer create
                };
                if (compass && screenType == hmSetting.screen_type.WATCHFACE) compass.start();
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSec) {
                    let animDelay = timeSensor.utc % 1000;
                    let animRepeat = 1000;
                    normal_timerUpdateSec = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, true);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                let secAngle = 0 + (360*6)*(timeSensor.second + ((timeSensor.utc % 1000) / 1000))/360;
                normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, secAngle);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSecSmooth) {
                    let duration = 0;
                    let animDuration = 5000;
                    if (timeSensor.second > 55) animDuration = 1000*(60.1 - (timeSensor.second - (timeSensor.utc % 1000) / 1000));
                    let diffTime = timeSensor.utc - lastTime;
                    if (diffTime < animDuration) duration = animDuration - diffTime;
                    normal_timerUpdateSecSmooth = timer.createTimer(duration, animDuration, (function (option) {
                      lastTime = timeSensor.utc;
                      secAngle = 0 + (360*6)*(timeSensor.second + ((timeSensor.utc % 1000) / 1000))/360;
                      startSecAnim(secAngle, animDuration);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                console.log('pause_call()');
                stop_anim_rotate_1();
                if (compass) compass.stop();
                if (normal_timerUpdateSec) {
                  timer.stopTimer(normal_timerUpdateSec);
                  normal_timerUpdateSec = undefined;
                }
                if (normal_timerUpdateSecSmooth) {
                  timer.stopTimer(normal_timerUpdateSecSmooth);
                  normal_timerUpdateSecSmooth = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_humidity_current_text_font = ''
        let normal_sun_high_text_font = ''
        let normal_sun_low_text_font = ''
        let normal_heart_rate_text_font = ''
        let normal_calorie_current_text_font = ''
        let normal_distance_icon_img = ''
        let normal_distance_current_text_font = ''
        let normal_step_current_text_font = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_font = ''
        let normal_battery_current_text_font = ''
        let normal_battery_image_progress_img_level = ''
        let normal_digital_clock_img_time = ''
        let normal_time_second_text_font = ''
        let normal_timerTimeUpdate = undefined;
        let normal_analog_clock_time_pointer_second = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_week_img = ''
        let idle_digital_clock_img_time = ''
        let idle_time_second_text_font = ''
        let idle_timerTimeUpdate = undefined;
        let normal_step_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'FREE153.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 160,
              y: 59,
              w: 150,
              h: 46,
              text_size: 19,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 91,
              y: 289,
              w: 150,
              h: 50,
              text_size: 20,
              char_space: 0,
              line_space: 0,
              color: 0xFFFF8C00,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 284,
              y: 289,
              w: 150,
              h: 30,
              text_size: 20,
              char_space: 0,
              line_space: 0,
              color: 0xFFFF8C00,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: -11,
              y: 192,
              w: 150,
              h: 41,
              text_size: 24,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: -10,
              y: 274,
              w: 150,
              h: 47,
              text_size: 24,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 397,
              y: 305,
              src: 'Dis_KM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 332,
              y: 267,
              w: 150,
              h: 57,
              text_size: 24,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              padding: true,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 332,
              y: 193,
              w: 150,
              h: 46,
              text_size: 24,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 324,
              y: 367,
              src: 'BT.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 130,
              y: 368,
              src: 'alarme.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 321,
              month_startY: 117,
              month_sc_array: ["MOIS-01.png","MOIS-02.png","MOIS-03.png","MOIS-04.png","MOIS-05.png","MOIS-06.png","MOIS-07.png","MOIS-08.png","MOIS-09.png","MOIS-10.png","MOIS-11.png","MOIS-12.png"],
              month_tc_array: ["MOIS-01.png","MOIS-02.png","MOIS-03.png","MOIS-04.png","MOIS-05.png","MOIS-06.png","MOIS-07.png","MOIS-08.png","MOIS-09.png","MOIS-10.png","MOIS-11.png","MOIS-12.png"],
              month_en_array: ["MOIS-01.png","MOIS-02.png","MOIS-03.png","MOIS-04.png","MOIS-05.png","MOIS-06.png","MOIS-07.png","MOIS-08.png","MOIS-09.png","MOIS-10.png","MOIS-11.png","MOIS-12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 131,
              day_startY: 103,
              day_sc_array: ["CH-00.png","CH-01.png","CH-02.png","CH-03.png","CH-04.png","CH-05.png","CH-06.png","CH-07.png","CH-08.png","CH-09.png"],
              day_tc_array: ["CH-00.png","CH-01.png","CH-02.png","CH-03.png","CH-04.png","CH-05.png","CH-06.png","CH-07.png","CH-08.png","CH-09.png"],
              day_en_array: ["CH-00.png","CH-01.png","CH-02.png","CH-03.png","CH-04.png","CH-05.png","CH-06.png","CH-07.png","CH-08.png","CH-09.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 176,
              y: 100,
              week_en: ["SEM-01.png","SEM-02.png","SEM-03.png","SEM-04.png","SEM-05.png","SEM-06.png","SEM-07.png"],
              week_tc: ["SEM-01.png","SEM-02.png","SEM-03.png","SEM-04.png","SEM-05.png","SEM-06.png","SEM-07.png"],
              week_sc: ["SEM-01.png","SEM-02.png","SEM-03.png","SEM-04.png","SEM-05.png","SEM-06.png","SEM-07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 207,
              y: 24,
              image_array: ["meteo-01.png","meteo-02.png","meteo-03.png","meteo-04.png","meteo-05.png","meteo-06.png","meteo-07.png","meteo-08.png","meteo-09.png","meteo-10.png","meteo-11.png","meteo-12.png","meteo-13.png","meteo-14.png","meteo-15.png","meteo-16.png","meteo-17.png","meteo-18.png","meteo-19.png","meteo-20.png","meteo-21.png","meteo-22.png","meteo-23.png","meteo-24.png","meteo-25.png","meteo-26.png","meteo-27.png","meteo-28.png","meteo-29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 280,
              y: 42,
              w: 150,
              h: 55,
              text_size: 29,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 165,
              y: 385,
              w: 150,
              h: 30,
              text_size: 22,
              char_space: 0,
              line_space: 0,
              color: 0xFFFF0000,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 192,
              y: 358,
              image_array: ["ENE01.png","ENE02.png","ENE03.png","ENE04.png","ENE05.png","ENE06.png","ENE07.png","ENE08.png","ENE09.png","ENE10.png","ENE11.png","ENE12.png","ENE13.png","ENE14.png","ENE15.png","ENE16.png","ENE17.png","ENE18.png","ENE19.png","ENE20.png","ENE21.png","ENE22.png","ENE23.png","ENE24.png","ENE25.png","ENE26.png","ENE27.png","ENE28.png"],
              image_length: 28,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 135,
              hour_startY: 164,
              hour_array: ["ANT140-0.png","ANT140-1.png","ANT140-2.png","ANT140-3.png","ANT140-4.png","ANT140-5.png","ANT140-6.png","ANT140-7.png","ANT140-8.png","ANT140-9.png"],
              hour_zero: 1,
              hour_space: -1,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 244,
              minute_startY: 164,
              minute_array: ["ANTRED-0_P.png","ANTRED-1_P.png","ANTRED-2_P.png","ANTRED-3_P.png","ANTRED-4_P.png","ANTRED-5_P.png","ANTRED-6_P.png","ANTRED-7_P.png","ANTRED-8_P.png","ANTRED-9_P.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            let screenType = hmSetting.getScreenType();
            normal_time_second_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 226,
              y: 251,
              w: 150,
              h: 50,
              text_size: 24,
              char_space: 0,
              line_space: 0,
              color: 0xFFC0C0C0,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'SEC.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 50,
              second_posY: 245,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 324,
              y: 296,
              src: 'BT.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 155,
              y: 295,
              src: 'alarme.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 321,
              month_startY: 117,
              month_sc_array: ["MOIS-01.png","MOIS-02.png","MOIS-03.png","MOIS-04.png","MOIS-05.png","MOIS-06.png","MOIS-07.png","MOIS-08.png","MOIS-09.png","MOIS-10.png","MOIS-11.png","MOIS-12.png"],
              month_tc_array: ["MOIS-01.png","MOIS-02.png","MOIS-03.png","MOIS-04.png","MOIS-05.png","MOIS-06.png","MOIS-07.png","MOIS-08.png","MOIS-09.png","MOIS-10.png","MOIS-11.png","MOIS-12.png"],
              month_en_array: ["MOIS-01.png","MOIS-02.png","MOIS-03.png","MOIS-04.png","MOIS-05.png","MOIS-06.png","MOIS-07.png","MOIS-08.png","MOIS-09.png","MOIS-10.png","MOIS-11.png","MOIS-12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 131,
              day_startY: 103,
              day_sc_array: ["CH-00.png","CH-01.png","CH-02.png","CH-03.png","CH-04.png","CH-05.png","CH-06.png","CH-07.png","CH-08.png","CH-09.png"],
              day_tc_array: ["CH-00.png","CH-01.png","CH-02.png","CH-03.png","CH-04.png","CH-05.png","CH-06.png","CH-07.png","CH-08.png","CH-09.png"],
              day_en_array: ["CH-00.png","CH-01.png","CH-02.png","CH-03.png","CH-04.png","CH-05.png","CH-06.png","CH-07.png","CH-08.png","CH-09.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 176,
              y: 100,
              week_en: ["SEM-01.png","SEM-02.png","SEM-03.png","SEM-04.png","SEM-05.png","SEM-06.png","SEM-07.png"],
              week_tc: ["SEM-01.png","SEM-02.png","SEM-03.png","SEM-04.png","SEM-05.png","SEM-06.png","SEM-07.png"],
              week_sc: ["SEM-01.png","SEM-02.png","SEM-03.png","SEM-04.png","SEM-05.png","SEM-06.png","SEM-07.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 135,
              hour_startY: 164,
              hour_array: ["ANT140-0.png","ANT140-1.png","ANT140-2.png","ANT140-3.png","ANT140-4.png","ANT140-5.png","ANT140-6.png","ANT140-7.png","ANT140-8.png","ANT140-9.png"],
              hour_zero: 1,
              hour_space: -1,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 244,
              minute_startY: 164,
              minute_array: ["ANTRED-0_P.png","ANTRED-1_P.png","ANTRED-2_P.png","ANTRED-3_P.png","ANTRED-4_P.png","ANTRED-5_P.png","ANTRED-6_P.png","ANTRED-7_P.png","ANTRED-8_P.png","ANTRED-9_P.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_time_second_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 226,
              y: 251,
              w: 150,
              h: 50,
              text_size: 24,
              char_space: 0,
              line_space: 0,
              color: 0xFFC0C0C0,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              // padding: true,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 9,
              // disconneсnt_toast_text: BT OFF,
              // conneсnt_vibrate_type: 9,
              // conneсnt_toast_text: BT ON,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              console.log('checkConnection()');
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  hmUI.showToast({text: "BT OFF"});
                  vibro(9);
                }
                if(status) {
                  hmUI.showToast({text: "BT ON"});
                  vibro(9);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              if (scene != 1) timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 370,
              y: 136,
              w: 75,
              h: 200,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 136,
              y: 284,
              w: 200,
              h: 40,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 125,
              y: 364,
              w: 40,
              h: 40,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            //start of ignored block
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              console.log('second font');
                let normal_secondStr = second.toString();
                normal_secondStr = normal_secondStr.padStart(2, '0');
                normal_time_second_text_font.setProperty(hmUI.prop.TEXT, normal_secondStr );
              console.log('second font');
                let idle_secondStr = second.toString();
                idle_secondStr = idle_secondStr.padStart(2, '0');
                idle_time_second_text_font.setProperty(hmUI.prop.TEXT, idle_secondStr );
            };

            //end of ignored block
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                time_update(true, true);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerTimeUpdate) {
                    normal_timerTimeUpdate = timer.createTimer(0, 1000, (function (option) {
                      let updateHour = timeSensor.minute == 0 && timeSensor.second < 2;
                      let updateMinute = timeSensor.second < 2;
                      time_update(updateHour, updateMinute);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.AOD) {
                  if (!idle_timerTimeUpdate) {
                    idle_timerTimeUpdate = timer.createTimer(0, 1000, (function (option) {
                      let updateHour = timeSensor.minute == 0 && timeSensor.second < 2;
                      let updateMinute = timeSensor.second < 2;
                      time_update(updateHour, updateMinute);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                checkConnection();
                stopVibro();

              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerTimeUpdate) {
                  timer.stopTimer(normal_timerTimeUpdate);
                  normal_timerTimeUpdate = undefined;
                }
                if (idle_timerTimeUpdate) {
                  timer.stopTimer(idle_timerTimeUpdate);
                  idle_timerTimeUpdate = undefined;
                }
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
/*
** Facemaker bundle tool v0.0.3
* *huamiOS watchface js version v4.4.0.1
* *Copyright © Huami. All Rights Reserved
*/


try {
	(() => {
		var __$$app$$__ = __$$hmAppManager$$__.currentApp;
		var __$$module$$__ = __$$app$$__.current;

		//drink is a name,can modify
		var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

		'use strict';

		//dynamic modify start
		let normal_img0 = '';
		let normal_hour_imagecombo2 = '';
		let normal_minute_imagecombo3 = '';
		let normal_img5 = '';
		let normal_week_imageset6 = '';
		let normal_date_imagecombo7 = '';
		let normal_month_imageset8 = '';
		let normal_battery_imagecombo10 = '';
		let normal_img11 = '';
		let normal_battery_rotary12 = '';
		let normal_stress_imagecombo14 = '';
		let normal_img15 = '';
		let normal_img16 = '';
		let normal_stress_rotary17 = '';
		let normal_img18 = '';
		let normal_steps_imagecombo20 = '';
		let normal_distance_imagecombo22 = '';
		let normal_heart_current_imagecombo24 = '';
		let normal_img25 = '';
		let normal_img26 = '';
		let normal_heart_min_imagecombo27 = new Array(3);
		let normal_heart_min_imagecombo27_padding = false;
		let normal_heart_min_imagecombo27_array = ['0090.png','0091.png','0092.png','0093.png','0094.png','0095.png','0096.png','0097.png','0098.png','0099.png','0100.png'];
		let normal_heart_max_imagecombo28 = new Array(3);
		let normal_heart_max_imagecombo28_padding = false;
		let normal_heart_max_imagecombo28_array = ['0090.png','0091.png','0092.png','0093.png','0094.png','0095.png','0096.png','0097.png','0098.png','0099.png','0100.png'];
		let normal_img29 = '';
		let normal_weather_imageset31 = '';
		let normal_weather_imageset32 = '';
		let normal_temperature_current_imagecombo33 = '';
		let normal_temperature_high_imagecombo34 = '';
		let normal_temperature_low_imagecombo35 = '';
		let normal_img36 = '';
		let normal_img37 = '';
		let normal_heart_shortcut40 = '';
		let normal_steps_shortcut41 = '';
		let normal_stress_shortcut42 = '';
		let normal_alarm_shortcut43 = '';
		let normal_countdown_shortcut44 = '';
		let normal_calendar_shortcut45 = '';
		let normal_weather_shortcut46 = '';
		let normal_battery_shortcut47 = '';
		let idle_hour_imagecombo49 = '';
		let idle_minute_imagecombo50 = '';
		let idle_img51 = '';
		let idle_week_imageset53 = '';
		let idle_date_imagecombo54 = '';
		let idle_month_imageset55 = '';
		let idle_img56 = '';
		//dynamic modify end

		//not required
		const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

		__$$module$$__.module = DeviceRuntimeCore.WatchFace({
			init_view() {

				const heartSensor = hmSensor.createSensor(hmSensor.id.HEART);
				let screenType = hmSetting.getScreenType();

				normal_img0 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					src: '0002.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_hour_imagecombo2 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					hour_startX: 31,
					hour_startY: 208,
					hour_array: ["0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png"],
					hour_zero: true,
					hour_space: 0,
					hour_align: hmUI.align.CENTER_H,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_minute_imagecombo3 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					minute_startX: 305,
					minute_startY: 208,
					minute_array: ["0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png"],
					minute_zero: true,
					minute_space: 0,
					minute_align: hmUI.align.CENTER_H,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img5 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 5,
					y: 0,
					w: 470,
					h: 293,
					src: '0013.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_week_imageset6 = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
					x: 190,
					y: 154,
					week_en: ["0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png"],
					week_tc: ["0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png"],
					week_sc: ["0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png"],
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_date_imagecombo7 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
					day_startX: 205,
					day_startY: 18,
					day_sc_array: ["0021.png","0022.png","0023.png","0024.png","0025.png","0026.png","0027.png","0028.png","0029.png","0030.png"],
					day_tc_array: ["0021.png","0022.png","0023.png","0024.png","0025.png","0026.png","0027.png","0028.png","0029.png","0030.png"],
					day_en_array: ["0021.png","0022.png","0023.png","0024.png","0025.png","0026.png","0027.png","0028.png","0029.png","0030.png"],
					day_zero: true,
					day_space: 0,
					day_align: hmUI.align.CENTER_H,
					day_is_character: false,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_month_imageset8 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
					month_startX: 206,
					month_startY: 89,
					month_sc_array: ["0031.png","0032.png","0033.png","0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png"],
					month_tc_array: ["0031.png","0032.png","0033.png","0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png"],
					month_en_array: ["0031.png","0032.png","0033.png","0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png"],
					month_is_character: true,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_battery_imagecombo10 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 97,
					y: 77,
					font_array: ["0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png","0050.png","0051.png","0052.png"],
					padding: false,
					h_space: -3,
					unit_sc: '0053.png',
					unit_tc: '0053.png',
					unit_en: '0053.png',
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.BATTERY,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img11 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 88,
					y: 150,
					w: 43,
					h: 20,
					src: '0054.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_battery_rotary12 = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
					src: '0055.png',
					center_x: 111,
					center_y: 134,
					x: 8,
					y: 45,
					start_angle: 305,
					end_angle: 93,
					type: hmUI.data_type.BATTERY,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_stress_imagecombo14 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 337,
					y: 80,
					font_array: ["0056.png","0057.png","0058.png","0059.png","0060.png","0061.png","0062.png","0063.png","0064.png","0065.png"],
					padding: false,
					h_space: -3,
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.STRESS,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img15 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 312,
					y: 115,
					w: 20,
					h: 20,
					src: '0066.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img16 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 387,
					y: 78,
					w: 19,
					h: 24,
					src: '0067.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_stress_rotary17 = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
					src: '0055.png',
					center_x: 371,
					center_y: 136,
					x: 8,
					y: 49,
					start_angle: 264,
					end_angle: 47,
					type: hmUI.data_type.STRESS,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img18 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 347,
					y: 154,
					w: 49,
					h: 20,
					src: '0068.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_steps_imagecombo20 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 44,
					y: 302,
					font_array: ["0069.png","0070.png","0071.png","0072.png","0073.png","0074.png","0075.png","0076.png","0077.png","0078.png"],
					padding: false,
					h_space: -3,
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.STEP,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_distance_imagecombo22 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 361,
					y: 302,
					font_array: ["0079.png","0080.png","0081.png","0082.png","0083.png","0084.png","0085.png","0086.png","0087.png","0088.png"],
					padding: false,
					h_space: -3,
					dot_image: '0089.png',
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.DISTANCE,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_heart_current_imagecombo24 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 215,
					y: 412,
					font_array: ["0090.png","0091.png","0092.png","0093.png","0094.png","0095.png","0096.png","0097.png","0098.png","0099.png"],
					padding: false,
					h_space: -3,
					invalid_image: '0100.png',
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.HEART,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img25 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 211,
					y: 383,
					w: 60,
					h: 21,
					src: '0101.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img26 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 132,
					y: 383,
					w: 230,
					h: 19,
					src: '0102.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				for (let i = 0; i < normal_heart_min_imagecombo27.length; i++) {
					normal_heart_min_imagecombo27[i] = hmUI.createWidget(hmUI.widget.IMG, {
						x: 123 + i * 20,
						y: 412,
						w: 20,
						h: 35,
						enable: false,
						show_level: hmUI.show_level.ONLY_NORMAL,
					})

				}

				for (let i = 0; i < normal_heart_max_imagecombo28.length; i++) {
					normal_heart_max_imagecombo28[i] = hmUI.createWidget(hmUI.widget.IMG, {
						x: 307 + i * 20,
						y: 412,
						w: 20,
						h: 35,
						enable: false,
						show_level: hmUI.show_level.ONLY_NORMAL,
					})

				}

				normal_img29 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 222,
					y: 450,
					w: 37,
					h: 34,
					src: '0103.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_weather_imageset31 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
					x: 201,
					y: 280,
					image_array: ["0104.png","0105.png","0106.png","0107.png","0108.png","0109.png","0110.png","0111.png","0112.png","0113.png","0114.png","0115.png","0116.png","0117.png","0118.png","0119.png","0120.png","0121.png","0122.png","0123.png","0124.png","0125.png","0126.png","0127.png","0128.png","0129.png","0130.png","0131.png","0132.png"],
					image_length: 29,
					type: hmUI.data_type.WEATHER_CURRENT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_weather_imageset32 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
					x: 171,
					y: 351,
					image_array: ["0133.png","0134.png","0135.png","0136.png","0137.png","0138.png","0139.png","0140.png","0141.png","0142.png","0143.png","0144.png","0145.png","0146.png","0147.png","0148.png","0149.png","0150.png","0151.png","0152.png","0153.png","0154.png","0155.png","0156.png","0157.png","0158.png","0159.png","0160.png","0161.png"],
					image_length: 29,
					type: hmUI.data_type.WEATHER_CURRENT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_temperature_current_imagecombo33 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 200,
					y: 241,
					font_array: ["0162.png","0163.png","0164.png","0165.png","0166.png","0167.png","0168.png","0169.png","0170.png","0171.png"],
					padding: false,
					h_space: -3,
					unit_sc: ["0173.png"],
					unit_tc: ["0173.png"],
					unit_en: ["0173.png"],
					negative_image: ["0172.png"],
					invalid_image: ["0172.png"],
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.WEATHER_CURRENT,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_temperature_high_imagecombo34 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 268,
					y: 313,
					font_array: ["0174.png","0175.png","0176.png","0177.png","0178.png","0179.png","0180.png","0181.png","0182.png","0183.png"],
					padding: false,
					h_space: -3,
					unit_sc: ["0185.png"],
					unit_tc: ["0185.png"],
					unit_en: ["0185.png"],
					negative_image: ["0184.png"],
					invalid_image: ["0184.png"],
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.WEATHER_HIGH,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_temperature_low_imagecombo35 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 145,
					y: 313,
					font_array: ["0186.png","0187.png","0188.png","0189.png","0190.png","0191.png","0192.png","0193.png","0194.png","0195.png"],
					padding: false,
					h_space: -3,
					unit_sc: ["0197.png"],
					unit_tc: ["0197.png"],
					unit_en: ["0197.png"],
					negative_image: ["0196.png"],
					invalid_image: ["0196.png"],
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.WEATHER_LOW,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img36 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 169,
					y: 295,
					w: 17,
					h: 16,
					src: '0198.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img37 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 286,
					y: 295,
					w: 17,
					h: 16,
					src: '0199.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_heart_shortcut40 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 193,
					y: 380,
					w: 100,
					h: 100,
					src: '',
					type: hmUI.data_type.HEART,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_steps_shortcut41 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 37,
					y: 301,
					w: 100,
					h: 70,
					src: '',
					type: hmUI.data_type.STEP,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_stress_shortcut42 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 325,
					y: 85,
					w: 100,
					h: 100,
					src: '',
					type: hmUI.data_type.STRESS,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_alarm_shortcut43 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 49,
					y: 205,
					w: 100,
					h: 77,
					src: '',
					type: hmUI.data_type.ALARM_CLOCK,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_countdown_shortcut44 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 322,
					y: 205,
					w: 100,
					h: 78,
					src: '',
					type: hmUI.data_type.COUNT_DOWN,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_calendar_shortcut45 = hmUI.createWidget(hmUI.widget.BUTTON, {
					x: 193,
					y: 25,
					w: 100,
					h: 100,
					text: '',
					normal_src: '',
					press_src: '',
					click_func: () => {
						hmApp.startApp({ url: 'ScheduleCalScreen', native: true });
					},
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_weather_shortcut46 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 190,
					y: 252,
					w: 100,
					h: 100,
					src: '',
					type: hmUI.data_type.WEATHER_CURRENT,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_battery_shortcut47 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 61,
					y: 85,
					w: 100,
					h: 100,
					src: '',
					type: hmUI.data_type.BATTERY,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				idle_hour_imagecombo49 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					hour_startX: 78,
					hour_startY: 208,
					hour_array: ["0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png"],
					hour_zero: true,
					hour_space: 0,
					hour_align: hmUI.align.CENTER_H,
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_minute_imagecombo50 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					minute_startX: 259,
					minute_startY: 208,
					minute_array: ["0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png"],
					minute_zero: true,
					minute_space: 0,
					minute_align: hmUI.align.CENTER_H,
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_img51 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 226,
					y: 198,
					w: 24,
					h: 91,
					src: '0200.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_week_imageset53 = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
					x: 190,
					y: 154,
					week_en: ["0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png"],
					week_tc: ["0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png"],
					week_sc: ["0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png"],
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_date_imagecombo54 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
					day_startX: 205,
					day_startY: 44,
					day_sc_array: ["0021.png","0022.png","0023.png","0024.png","0025.png","0026.png","0027.png","0028.png","0029.png","0030.png"],
					day_tc_array: ["0021.png","0022.png","0023.png","0024.png","0025.png","0026.png","0027.png","0028.png","0029.png","0030.png"],
					day_en_array: ["0021.png","0022.png","0023.png","0024.png","0025.png","0026.png","0027.png","0028.png","0029.png","0030.png"],
					day_zero: true,
					day_space: 0,
					day_align: hmUI.align.CENTER_H,
					day_is_character: false,
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_month_imageset55 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
					month_startX: 206,
					month_startY: 118,
					month_sc_array: ["0031.png","0032.png","0033.png","0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png"],
					month_tc_array: ["0031.png","0032.png","0033.png","0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png"],
					month_en_array: ["0031.png","0032.png","0033.png","0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png"],
					month_is_character: true,
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_img56 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					src: '0201.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				function updateHeart() {
					let normal_heart_min_imagecombo27_current = Math.min(...heartSensor.today);
					if (normal_heart_min_imagecombo27_padding) {
						normal_heart_min_imagecombo27_current = normal_heart_min_imagecombo27_current.toString().padStart(normal_heart_min_imagecombo27.length, '0');
					}
					for (let i = 0; i < normal_heart_min_imagecombo27.length; i++) {
						normal_heart_min_imagecombo27[i].setProperty(hmUI.prop.MORE, { x: 123+((((normal_heart_min_imagecombo27.length-normal_heart_min_imagecombo27_current.toString().length)*20)/2)+20*i) });
						if ((normal_heart_min_imagecombo27.length-normal_heart_min_imagecombo27_current.length) < i && normal_heart_min_imagecombo27_padding === false) {
							normal_heart_min_imagecombo27[i].setProperty(hmUI.prop.VISIBLE, false);
						} else {
							normal_heart_min_imagecombo27[i].setProperty(hmUI.prop.VISIBLE, true);
							normal_heart_min_imagecombo27[i].setProperty(hmUI.prop.SRC, normal_heart_min_imagecombo27_array[normal_heart_min_imagecombo27_current.toString().charAt(i)]);
						}
					}
					let normal_heart_max_imagecombo28_current = Math.max(...heartSensor.today);
					if (normal_heart_max_imagecombo28_padding) {
						normal_heart_max_imagecombo28_current = normal_heart_max_imagecombo28_current.toString().padStart(normal_heart_max_imagecombo28.length, '0');
					}
					for (let i = 0; i < normal_heart_max_imagecombo28.length; i++) {
						normal_heart_max_imagecombo28[i].setProperty(hmUI.prop.MORE, { x: 307+((((normal_heart_max_imagecombo28.length-normal_heart_max_imagecombo28_current.toString().length)*20)/2)+20*i) });
						if ((normal_heart_max_imagecombo28.length-normal_heart_max_imagecombo28_current.length) < i && normal_heart_max_imagecombo28_padding === false) {
							normal_heart_max_imagecombo28[i].setProperty(hmUI.prop.VISIBLE, false);
						} else {
							normal_heart_max_imagecombo28[i].setProperty(hmUI.prop.VISIBLE, true);
							normal_heart_max_imagecombo28[i].setProperty(hmUI.prop.SRC, normal_heart_max_imagecombo28_array[normal_heart_max_imagecombo28_current.toString().charAt(i)]);
						}
					}
				}

				heartSensor.addEventListener(hmSensor.event.CHANGE, function() {
					updateHeart();
				});

				const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
					resume_call: (function () {
						updateHeart();
					}),
					pause_call: (function () {
					}),
				})
			},

		onInit() {
			console.log('index page.js on init invoke')
			this.init_view()
		},
		onReady() {
			console.log('index page.js on ready invoke')
		},
		onShow() {
			console.log('index page.js on show invoke')
		},
		onHide() {
			console.log('index page.js on hide invoke')
		},
		onDestroy() {
			console.log('index page.js on destroy invoke')
		},
	});	})()
} catch (e) {
	console.log(e)
}
﻿    /*
    ** Watch_Face_Editor tool v 18.1
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg = ''
        let normal_date_img_date_week_img = ''
        let normal_step_current_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_digital_clock_img_time = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_month = ''
        let normal_battery_text_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_system_disconnect_img = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_hour = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 251,
              y: 162,
              week_en: ["chars_712CA981_000.png","chars_712CA981_001.png","chars_712CA981_002.png","chars_712CA981_003.png","chars_712CA981_004.png","chars_712CA981_005.png","chars_712CA981_006.png"],
              week_tc: ["chars_712CA981_000.png","chars_712CA981_001.png","chars_712CA981_002.png","chars_712CA981_003.png","chars_712CA981_004.png","chars_712CA981_005.png","chars_712CA981_006.png"],
              week_sc: ["chars_712CA981_000.png","chars_712CA981_001.png","chars_712CA981_002.png","chars_712CA981_003.png","chars_712CA981_004.png","chars_712CA981_005.png","chars_712CA981_006.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 180,
              y: 299,
              font_array: ["chars_1EC317BE_000.png","chars_1EC317BE_001.png","chars_1EC317BE_002.png","chars_1EC317BE_003.png","chars_1EC317BE_004.png","chars_1EC317BE_005.png","chars_1EC317BE_006.png","chars_1EC317BE_007.png","chars_1EC317BE_008.png","chars_1EC317BE_009.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 184,
              y: 162,
              font_array: ["chars_CBD5500B_000.png","chars_CBD5500B_001.png","chars_CBD5500B_002.png","chars_CBD5500B_003.png","chars_CBD5500B_004.png","chars_CBD5500B_005.png","chars_CBD5500B_006.png","chars_CBD5500B_007.png","chars_CBD5500B_008.png","chars_CBD5500B_009.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'chars_CBD5500B_011.png',
              unit_tc: 'chars_CBD5500B_011.png',
              unit_en: 'chars_CBD5500B_011.png',
              negative_image: 'chars_CBD5500B_010.png',
              invalid_image: 'chars_CBD5500B_012.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 67,
              y: 97,
              image_array: ["set_20_130x130_h0s100b90_meteo_1.png","set_20_130x130_h0s100b90_meteo_2.png","set_20_130x130_h0s100b90_meteo_3.png","set_20_130x130_h0s100b90_meteo_4.png","set_20_130x130_h0s100b90_meteo_5.png","set_20_130x130_h0s100b90_meteo_6.png","set_20_130x130_h0s100b90_meteo_7.png","set_20_130x130_h0s100b90_meteo_8.png","set_20_130x130_h0s100b90_meteo_9.png","set_20_130x130_h0s100b90_meteo_10.png","set_20_130x130_h0s100b90_meteo_11.png","set_20_130x130_h0s100b90_meteo_12.png","set_20_130x130_h0s100b90_meteo_13.png","set_20_130x130_h0s100b90_meteo_14.png","set_20_130x130_h0s100b90_meteo_15.png","set_20_130x130_h0s100b90_meteo_16.png","set_20_130x130_h0s100b90_meteo_17.png","set_20_130x130_h0s100b90_meteo_18.png","set_20_130x130_h0s100b90_meteo_19.png","set_20_130x130_h0s100b90_meteo_20.png","set_20_130x130_h0s100b90_meteo_21.png","set_20_130x130_h0s100b90_meteo_22.png","set_20_130x130_h0s100b90_meteo_23.png","set_20_130x130_h0s100b90_meteo_24.png","set_20_130x130_h0s100b90_meteo_25.png","set_20_130x130_h0s100b90_meteo_26.png","set_20_130x130_h0s100b90_meteo_27.png","set_20_130x130_h0s100b90_meteo_28.png","set_20_130x130_h0s100b90_meteo_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 63,
              hour_startY: 220,
              hour_array: ["chars_72561EE_000.png","chars_72561EE_001.png","chars_72561EE_002.png","chars_72561EE_003.png","chars_72561EE_004.png","chars_72561EE_005.png","chars_72561EE_006.png","chars_72561EE_007.png","chars_72561EE_008.png","chars_72561EE_009.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 253,
              minute_startY: 220,
              minute_array: ["chars_72561EE_000.png","chars_72561EE_001.png","chars_72561EE_002.png","chars_72561EE_003.png","chars_72561EE_004.png","chars_72561EE_005.png","chars_72561EE_006.png","chars_72561EE_007.png","chars_72561EE_008.png","chars_72561EE_009.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 319,
              day_startY: 162,
              day_sc_array: ["chars_CBD5500B_000.png","chars_CBD5500B_001.png","chars_CBD5500B_002.png","chars_CBD5500B_003.png","chars_CBD5500B_004.png","chars_CBD5500B_005.png","chars_CBD5500B_006.png","chars_CBD5500B_007.png","chars_CBD5500B_008.png","chars_CBD5500B_009.png"],
              day_tc_array: ["chars_CBD5500B_000.png","chars_CBD5500B_001.png","chars_CBD5500B_002.png","chars_CBD5500B_003.png","chars_CBD5500B_004.png","chars_CBD5500B_005.png","chars_CBD5500B_006.png","chars_CBD5500B_007.png","chars_CBD5500B_008.png","chars_CBD5500B_009.png"],
              day_en_array: ["chars_CBD5500B_000.png","chars_CBD5500B_001.png","chars_CBD5500B_002.png","chars_CBD5500B_003.png","chars_CBD5500B_004.png","chars_CBD5500B_005.png","chars_CBD5500B_006.png","chars_CBD5500B_007.png","chars_CBD5500B_008.png","chars_CBD5500B_009.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 365,
              month_startY: 162,
              month_sc_array: ["chars_CBD5500B_000.png","chars_CBD5500B_001.png","chars_CBD5500B_002.png","chars_CBD5500B_003.png","chars_CBD5500B_004.png","chars_CBD5500B_005.png","chars_CBD5500B_006.png","chars_CBD5500B_007.png","chars_CBD5500B_008.png","chars_CBD5500B_009.png"],
              month_tc_array: ["chars_CBD5500B_000.png","chars_CBD5500B_001.png","chars_CBD5500B_002.png","chars_CBD5500B_003.png","chars_CBD5500B_004.png","chars_CBD5500B_005.png","chars_CBD5500B_006.png","chars_CBD5500B_007.png","chars_CBD5500B_008.png","chars_CBD5500B_009.png"],
              month_en_array: ["chars_CBD5500B_000.png","chars_CBD5500B_001.png","chars_CBD5500B_002.png","chars_CBD5500B_003.png","chars_CBD5500B_004.png","chars_CBD5500B_005.png","chars_CBD5500B_006.png","chars_CBD5500B_007.png","chars_CBD5500B_008.png","chars_CBD5500B_009.png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 217,
              y: 81,
              font_array: ["chars_CDB15BBA_000.png","chars_CDB15BBA_001.png","chars_CDB15BBA_002.png","chars_CDB15BBA_003.png","chars_CDB15BBA_004.png","chars_CDB15BBA_005.png","chars_CDB15BBA_006.png","chars_CDB15BBA_007.png","chars_CDB15BBA_008.png","chars_CDB15BBA_009.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 238,
              y: 353,
              font_array: ["chars_CDB15BBA_000.png","chars_CDB15BBA_001.png","chars_CDB15BBA_002.png","chars_CDB15BBA_003.png","chars_CDB15BBA_004.png","chars_CDB15BBA_005.png","chars_CDB15BBA_006.png","chars_CDB15BBA_007.png","chars_CDB15BBA_008.png","chars_CDB15BBA_009.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 136,
              y: 72,
              src: 'custom_icon_1786951847151_48x48.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'pointers_second_custom_icons_custom_icon_1786451916159_A490410B.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 40,
              second_posY: 233,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'pointers_minute_custom_icons_custom_icon_1790168533836_5BC90EE4.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 40,
              minute_posY: 267,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'pointers_hour_custom_icons_custom_icon_1790168478663_102FCCFC.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 40,
              hour_posY: 282,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
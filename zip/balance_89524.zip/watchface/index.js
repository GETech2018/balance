/*
** Facemaker bundle tool v0.0.3
* *huamiOS watchface js version v4.4.0.1
* *Copyright © Huami. All Rights Reserved
*/


try {
	(() => {
		var __$$app$$__ = __$$hmAppManager$$__.currentApp;
		var __$$module$$__ = __$$app$$__.current;

		//drink is a name,can modify
		var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

		'use strict';

		//dynamic modify start
		let normal_img0 = '';
		let normal_weather_imageset2 = '';
		let normal_weather_imageset3 = '';
		let normal_temperature_low_imagecombo4 = '';
		let normal_temperature_high_imagecombo5 = '';
		let normal_img6 = '';
		let normal_temperature_current_imagecombo7 = '';
		let normal_img8 = '';
		let normal_battery_imagecombo10 = '';
		let normal_img11 = '';
		let normal_airpressure_imagecombo13 = '';
		let normal_img14 = '';
		let normal_steps_imagecombo16 = '';
		let normal_img17 = '';
		let normal_distance_imagecombo19 = '';
		let normal_img20 = '';
		let normal_heart_current_imagecombo22 = '';
		let normal_img23 = '';
		let normal_stress_imagecombo25 = '';
		let normal_img26 = '';
		let normal_sunrise_text28 = '';
		let normal_sunset_text29 = '';
		let normal_img30 = '';
		let normal_week_imageset32 = '';
		let normal_month_imageset33 = '';
		let normal_date_imagecombo34 = '';
		let normal_hour_imagecombo36 = '';
		let normal_minute_imagecombo37 = '';
		let normal_img38 = '';
		let normal_alarm_shortcut41 = '';
		let normal_countdown_shortcut42 = '';
		let normal_calendar_shortcut43 = '';
		let normal_weather_shortcut44 = '';
		let normal_airpressure_shortcut45 = '';
		let normal_heart_shortcut46 = '';
		let normal_steps_shortcut47 = '';
		let normal_stress_shortcut48 = '';
		let normal_sun_shortcut49 = '';
		let idle_hour_imagecombo51 = '';
		let idle_minute_imagecombo52 = '';
		let idle_img53 = '';
		let idle_week_imageset55 = '';
		let idle_month_imageset56 = '';
		let idle_date_imagecombo57 = '';
		let idle_weather_imageset59 = '';
		let idle_weather_imageset60 = '';
		let idle_temperature_low_imagecombo61 = '';
		let idle_temperature_high_imagecombo62 = '';
		let idle_img63 = '';
		let idle_temperature_current_imagecombo64 = '';
		let idle_img65 = '';
		//dynamic modify end

		//not required
		const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

		__$$module$$__.module = DeviceRuntimeCore.WatchFace({
			init_view() {

				const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);
				let screenType = hmSetting.getScreenType();

				normal_img0 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					src: '0002.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_weather_imageset2 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
					x: 179,
					y: 80,
					image_array: ["0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0005.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0005.png","0005.png","0020.png","0021.png","0014.png","0020.png","0022.png","0023.png","0004.png","0024.png"],
					image_length: 29,
					type: hmUI.data_type.WEATHER_CURRENT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_weather_imageset3 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
					x: 154,
					y: 18,
					image_array: ["0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0030.png","0031.png","0032.png","0033.png","0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0033.png","0041.png","0042.png","0033.png","0043.png","0044.png","0033.png","0045.png","0046.png","0047.png","0048.png"],
					image_length: 29,
					type: hmUI.data_type.WEATHER_CURRENT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_temperature_low_imagecombo4 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 38,
					y: 135,
					font_array: ["0049.png","0050.png","0051.png","0052.png","0053.png","0054.png","0055.png","0056.png","0057.png","0058.png"],
					padding: false,
					h_space: -3,
					unit_sc: ["0060.png"],
					unit_tc: ["0060.png"],
					unit_en: ["0060.png"],
					negative_image: ["0059.png"],
					invalid_image: ["0059.png"],
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.WEATHER_LOW,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_temperature_high_imagecombo5 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 109,
					y: 135,
					font_array: ["0049.png","0050.png","0051.png","0052.png","0053.png","0054.png","0055.png","0056.png","0057.png","0058.png"],
					padding: false,
					h_space: -3,
					unit_sc: ["0060.png"],
					unit_tc: ["0060.png"],
					unit_en: ["0060.png"],
					negative_image: ["0059.png"],
					invalid_image: ["0059.png"],
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.WEATHER_HIGH,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img6 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 103,
					y: 136,
					w: 17,
					h: 38,
					src: '0061.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_temperature_current_imagecombo7 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 93,
					y: 96,
					font_array: ["0049.png","0050.png","0051.png","0052.png","0053.png","0054.png","0055.png","0056.png","0057.png","0058.png"],
					padding: false,
					h_space: -3,
					unit_sc: ["0060.png"],
					unit_tc: ["0060.png"],
					unit_en: ["0060.png"],
					negative_image: ["0059.png"],
					invalid_image: ["0059.png"],
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.WEATHER_CURRENT,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img8 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 72,
					y: 97,
					w: 26,
					h: 26,
					src: '0062.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_battery_imagecombo10 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 310,
					y: 135,
					font_array: ["0049.png","0050.png","0051.png","0052.png","0053.png","0054.png","0055.png","0056.png","0057.png","0058.png"],
					padding: false,
					h_space: -3,
					unit_sc: '0063.png',
					unit_tc: '0063.png',
					unit_en: '0063.png',
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.BATTERY,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img11 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 399,
					y: 133,
					w: 35,
					h: 35,
					src: '0064.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_airpressure_imagecombo13 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 302,
					y: 97,
					font_array: ["0065.png","0066.png","0067.png","0068.png","0069.png","0070.png","0071.png","0072.png","0073.png","0074.png"],
					padding: false,
					h_space: -3,
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.ALTIMETER,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img14 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 374,
					y: 94,
					w: 33,
					h: 33,
					src: '0075.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_steps_imagecombo16 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 102,
					y: 323,
					font_array: ["0076.png","0077.png","0078.png","0079.png","0080.png","0081.png","0082.png","0083.png","0084.png","0085.png"],
					padding: false,
					h_space: -3,
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.STEP,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img17 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 56,
					y: 325,
					w: 37,
					h: 32,
					src: '0086.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_distance_imagecombo19 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 268,
					y: 323,
					font_array: ["0087.png","0088.png","0089.png","0090.png","0091.png","0092.png","0093.png","0094.png","0095.png","0096.png"],
					padding: false,
					h_space: -3,
					dot_image: '0097.png',
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.DISTANCE,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img20 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 371,
					y: 324,
					w: 36,
					h: 36,
					src: '0098.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_heart_current_imagecombo22 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 145,
					y: 377,
					font_array: ["0099.png","0100.png","0101.png","0102.png","0103.png","0104.png","0105.png","0106.png","0107.png","0108.png"],
					padding: false,
					h_space: -3,
					invalid_image: '0109.png',
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.HEART,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img23 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 103,
					y: 376,
					w: 36,
					h: 36,
					src: '0110.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_stress_imagecombo25 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 253,
					y: 377,
					font_array: ["0099.png","0100.png","0101.png","0102.png","0103.png","0104.png","0105.png","0106.png","0107.png","0108.png"],
					padding: false,
					h_space: -3,
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.STRESS,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img26 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 337,
					y: 371,
					w: 33,
					h: 41,
					src: '0111.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_sunrise_text28 = hmUI.createWidget(hmUI.widget.TEXT, {
					x: 129,
					y: 433,
					w: 100,
					h: 28,
					color: 0xA1A1A1,
					text_size: 28,
					align_h: hmUI.align.CENTER_H,
					align_v: hmUI.align.CENTER_V,
					text_style: hmUI.text_style.NONE,
					font: 'fonts/Oswald-Medium.ttf',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_sunset_text29 = hmUI.createWidget(hmUI.widget.TEXT, {
					x: 244,
					y: 433,
					w: 100,
					h: 28,
					color: 0xA1A1A1,
					text_size: 28,
					align_h: hmUI.align.CENTER_H,
					align_v: hmUI.align.CENTER_V,
					text_style: hmUI.text_style.NONE,
					font: 'fonts/Oswald-Medium.ttf',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img30 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 224,
					y: 437,
					w: 32,
					h: 27,
					src: '0112.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_week_imageset32 = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
					x: 132,
					y: 49,
					week_en: ["0113.png","0114.png","0115.png","0116.png","0117.png","0118.png","0119.png"],
					week_tc: ["0113.png","0114.png","0115.png","0116.png","0117.png","0118.png","0119.png"],
					week_sc: ["0113.png","0114.png","0115.png","0116.png","0117.png","0118.png","0119.png"],
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_month_imageset33 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
					month_startX: 273,
					month_startY: 49,
					month_sc_array: ["0120.png","0121.png","0122.png","0123.png","0124.png","0125.png","0126.png","0127.png","0128.png","0129.png","0130.png","0131.png"],
					month_tc_array: ["0120.png","0121.png","0122.png","0123.png","0124.png","0125.png","0126.png","0127.png","0128.png","0129.png","0130.png","0131.png"],
					month_en_array: ["0120.png","0121.png","0122.png","0123.png","0124.png","0125.png","0126.png","0127.png","0128.png","0129.png","0130.png","0131.png"],
					month_is_character: true,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_date_imagecombo34 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
					day_startX: 210,
					day_startY: 43,
					day_sc_array: ["0132.png","0133.png","0134.png","0135.png","0136.png","0137.png","0138.png","0139.png","0140.png","0141.png"],
					day_tc_array: ["0132.png","0133.png","0134.png","0135.png","0136.png","0137.png","0138.png","0139.png","0140.png","0141.png"],
					day_en_array: ["0132.png","0133.png","0134.png","0135.png","0136.png","0137.png","0138.png","0139.png","0140.png","0141.png"],
					day_zero: true,
					day_space: -6,
					day_align: hmUI.align.CENTER_H,
					day_is_character: false,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_hour_imagecombo36 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					hour_startX: 15,
					hour_startY: 181,
					hour_array: ["0142.png","0143.png","0144.png","0145.png","0146.png","0147.png","0148.png","0149.png","0150.png","0151.png"],
					hour_zero: true,
					hour_space: 0,
					hour_align: hmUI.align.LEFT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_minute_imagecombo37 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					minute_startX: 254,
					minute_startY: 181,
					minute_array: ["0142.png","0143.png","0144.png","0145.png","0146.png","0147.png","0148.png","0149.png","0150.png","0151.png"],
					minute_zero: true,
					minute_space: 0,
					minute_align: hmUI.align.LEFT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img38 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 224,
					y: 204,
					w: 30,
					h: 88,
					src: '0152.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_alarm_shortcut41 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 73,
					y: 197,
					w: 100,
					h: 100,
					src: '',
					type: hmUI.data_type.ALARM_CLOCK,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_countdown_shortcut42 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 301,
					y: 202,
					w: 100,
					h: 100,
					src: '',
					type: hmUI.data_type.COUNT_DOWN,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_calendar_shortcut43 = hmUI.createWidget(hmUI.widget.BUTTON, {
					x: 193,
					y: 1,
					w: 100,
					h: 79,
					text: '',
					normal_src: '',
					press_src: '',
					click_func: () => {
						hmApp.startApp({ url: 'ScheduleCalScreen', native: true });
					},
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_weather_shortcut44 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 97,
					y: 95,
					w: 165,
					h: 75,
					src: '',
					type: hmUI.data_type.WEATHER_CURRENT,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_airpressure_shortcut45 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 313,
					y: 97,
					w: 100,
					h: 68,
					src: '',
					type: hmUI.data_type.PRESSURE,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_heart_shortcut46 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 121,
					y: 373,
					w: 100,
					h: 44,
					src: '',
					type: hmUI.data_type.HEART,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_steps_shortcut47 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 109,
					y: 323,
					w: 257,
					h: 40,
					src: '',
					type: hmUI.data_type.STEP,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_stress_shortcut48 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 265,
					y: 373,
					w: 100,
					h: 43,
					src: '',
					type: hmUI.data_type.STRESS,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_sun_shortcut49 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 193,
					y: 430,
					w: 100,
					h: 42,
					src: '',
					type: hmUI.data_type.SUN_CURRENT,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				idle_hour_imagecombo51 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					hour_startX: 15,
					hour_startY: 181,
					hour_array: ["0142.png","0143.png","0144.png","0145.png","0146.png","0147.png","0148.png","0149.png","0150.png","0151.png"],
					hour_zero: true,
					hour_space: 0,
					hour_align: hmUI.align.LEFT,
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_minute_imagecombo52 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					minute_startX: 254,
					minute_startY: 181,
					minute_array: ["0142.png","0143.png","0144.png","0145.png","0146.png","0147.png","0148.png","0149.png","0150.png","0151.png"],
					minute_zero: true,
					minute_space: 0,
					minute_align: hmUI.align.LEFT,
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_img53 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 224,
					y: 204,
					w: 30,
					h: 88,
					src: '0152.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_week_imageset55 = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
					x: 132,
					y: 123,
					week_en: ["0113.png","0114.png","0115.png","0116.png","0117.png","0118.png","0119.png"],
					week_tc: ["0113.png","0114.png","0115.png","0116.png","0117.png","0118.png","0119.png"],
					week_sc: ["0113.png","0114.png","0115.png","0116.png","0117.png","0118.png","0119.png"],
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_month_imageset56 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
					month_startX: 273,
					month_startY: 123,
					month_sc_array: ["0120.png","0121.png","0122.png","0123.png","0124.png","0125.png","0126.png","0127.png","0128.png","0129.png","0130.png","0131.png"],
					month_tc_array: ["0120.png","0121.png","0122.png","0123.png","0124.png","0125.png","0126.png","0127.png","0128.png","0129.png","0130.png","0131.png"],
					month_en_array: ["0120.png","0121.png","0122.png","0123.png","0124.png","0125.png","0126.png","0127.png","0128.png","0129.png","0130.png","0131.png"],
					month_is_character: true,
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_date_imagecombo57 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
					day_startX: 210,
					day_startY: 117,
					day_sc_array: ["0132.png","0133.png","0134.png","0135.png","0136.png","0137.png","0138.png","0139.png","0140.png","0141.png"],
					day_tc_array: ["0132.png","0133.png","0134.png","0135.png","0136.png","0137.png","0138.png","0139.png","0140.png","0141.png"],
					day_en_array: ["0132.png","0133.png","0134.png","0135.png","0136.png","0137.png","0138.png","0139.png","0140.png","0141.png"],
					day_zero: true,
					day_space: -6,
					day_align: hmUI.align.CENTER_H,
					day_is_character: false,
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_weather_imageset59 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
					x: 191,
					y: 39,
					image_array: ["0153.png","0154.png","0155.png","0156.png","0157.png","0158.png","0159.png","0160.png","0161.png","0162.png","0163.png","0164.png","0165.png","0166.png","0167.png","0168.png","0169.png","0170.png","0171.png","0172.png","0173.png","0174.png","0175.png","0176.png","0177.png","0178.png","0179.png","0180.png","0181.png"],
					image_length: 29,
					type: hmUI.data_type.WEATHER_CURRENT,
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_weather_imageset60 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
					x: 154,
					y: 18,
					image_array: ["0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0030.png","0031.png","0032.png","0033.png","0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0033.png","0041.png","0042.png","0033.png","0043.png","0044.png","0033.png","0045.png","0046.png","0047.png","0048.png"],
					image_length: 29,
					type: hmUI.data_type.WEATHER_CURRENT,
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_temperature_low_imagecombo61 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 269,
					y: 89,
					font_array: ["0182.png","0183.png","0184.png","0185.png","0186.png","0187.png","0188.png","0189.png","0190.png","0191.png"],
					padding: false,
					h_space: -3,
					unit_sc: ["0193.png"],
					unit_tc: ["0193.png"],
					unit_en: ["0193.png"],
					negative_image: ["0192.png"],
					invalid_image: ["0192.png"],
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.WEATHER_LOW,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_temperature_high_imagecombo62 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 324,
					y: 89,
					font_array: ["0182.png","0183.png","0184.png","0185.png","0186.png","0187.png","0188.png","0189.png","0190.png","0191.png"],
					padding: false,
					h_space: -3,
					unit_sc: ["0193.png"],
					unit_tc: ["0193.png"],
					unit_en: ["0193.png"],
					negative_image: ["0192.png"],
					invalid_image: ["0192.png"],
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.WEATHER_HIGH,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_img63 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 320,
					y: 91,
					w: 13,
					h: 28,
					src: '0194.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_temperature_current_imagecombo64 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 116,
					y: 84,
					font_array: ["0049.png","0050.png","0051.png","0052.png","0053.png","0054.png","0055.png","0056.png","0057.png","0058.png"],
					padding: false,
					h_space: -3,
					unit_sc: ["0060.png"],
					unit_tc: ["0060.png"],
					unit_en: ["0060.png"],
					negative_image: ["0059.png"],
					invalid_image: ["0059.png"],
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.WEATHER_CURRENT,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_img65 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 89,
					y: 89,
					w: 26,
					h: 26,
					src: '0195.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				function updateWeather() {
					let tideData = weatherSensor.getForecastWeather().tideData;
					normal_sunrise_text28.setProperty(hmUI.prop.TEXT, tideData.data[0].sunrise.hour.toString().padStart(2, '0') + ':' + tideData.data[0].sunrise.minute.toString().padStart(2, '0'));
					normal_sunset_text29.setProperty(hmUI.prop.TEXT, tideData.data[0].sunset.hour.toString().padStart(2, '0') + ':' + tideData.data[0].sunset.minute.toString().padStart(2, '0'));
				}

				weatherSensor.addEventListener(hmSensor.event.CHANGE, function() {
					updateWeather();
				});

				const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
					resume_call: (function () {
						updateWeather();
					}),
					pause_call: (function () {
					}),
				})
			},

		onInit() {
			console.log('index page.js on init invoke')
			this.init_view()
		},
		onReady() {
			console.log('index page.js on ready invoke')
		},
		onShow() {
			console.log('index page.js on show invoke')
		},
		onHide() {
			console.log('index page.js on hide invoke')
		},
		onDestroy() {
			console.log('index page.js on destroy invoke')
		},
	});	})()
} catch (e) {
	console.log(e)
}
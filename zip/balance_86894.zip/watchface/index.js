﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_heart_rate_TextCircle = new Array(3);
        let normal_heart_rate_TextCircle_ASCIIARRAY = new Array(10);
        let normal_heart_rate_TextCircle_img_width = 15;
        let normal_heart_rate_TextCircle_img_height = 26;
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_step_pointer_progress_img_pointer = ''
        let normal_step_TextCircle = new Array(5);
        let normal_step_TextCircle_ASCIIARRAY = new Array(10);
        let normal_step_TextCircle_img_width = 15;
        let normal_step_TextCircle_img_height = 26;
        let normal_moon_icon_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_battery_pointer_progress_img_pointer = ''
        let normal_digital_clock_img_time = ''
        let normal_analog_clock_pro_hour_pointer_img = ''
        let normal_analog_clock_pro_minute_pointer_img = ''
        let normal_timerUpdateSec = undefined;
        let normal_analog_clock_time_pointer_smooth_second = ''
        let idle_background_bg_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_heart_rate_TextCircle = new Array(3);
        let idle_heart_rate_TextCircle_ASCIIARRAY = new Array(10);
        let idle_heart_rate_TextCircle_img_width = 15;
        let idle_heart_rate_TextCircle_img_height = 26;
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_month = ''
        let idle_date_img_date_day = ''
        let idle_step_TextCircle = new Array(5);
        let idle_step_TextCircle_ASCIIARRAY = new Array(10);
        let idle_step_TextCircle_img_width = 15;
        let idle_step_TextCircle_img_height = 26;
        let idle_digital_clock_img_time = ''
        let idle_analog_clock_pro_hour_pointer_img = ''
        let idle_analog_clock_pro_minute_pointer_img = ''
        let image_top_img = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let Button_7 = ''
        let Button_8 = ''
        let Button_9 = ''
        let Button_Switch_BG = ''

        let backgroundIndex = 0;
        let backgroundList = ['bg_1.png', 'bg_2.png', 'bg_3.png', 'bg_4.png', 'bg_5.png', 'bg_6.png', 'bg_7.png', 'bg_8.png'];
        let backgroundToastList = ['Фон %s', 'Фон %s', 'Фон %s', 'Фон %s', 'Фон %s', 'Фон %s', 'Фон %s', 'Фон %s'];
        const watchfaceId = hmApp.packageInfo().watchfaceId;
        let timeSensor = '';

        function loadSettings() {
 if (hmFS.SysProGetInt('name_vash_cifer_VIS_str') === undefined) {
  VIS_str = 0;
  hmFS.SysProSetInt('name_vash_cifer_VIS_str', VIS_str);
 } else {
  VIS_str = hmFS.SysProGetInt('name_vash_cifer_VIS_str');
 }
}
		
let VIS_str = 0;
let btn_VIS_str = '';

function clic_VIS_str() {
 VIS_str = (VIS_str + 1) % 2
 hmFS.SysProSetInt('name_vash_cifer_VIS_str', VIS_str);// запись настроек
 normal_moon_icon_img.setProperty(hmUI.prop.VISIBLE, VIS_str == 0);
 normal_moon_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, VIS_str == 0);
 Button_9.setProperty(hmUI.prop.VISIBLE, VIS_str == 0);
			
hmUI.showToast({text: VIS_str==0 ? 'Луна вкл':'Луна выкл'});
        }

        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
  loadSettings()
                
            //#region SwitchBackground
            console.log('SwitchBackground');
            function switchBackground() {
              backgroundIndex++;
              if (backgroundIndex >= backgroundList.length) backgroundIndex = 0;
              hmFS.SysProSetInt(`backgroundIndex_${watchfaceId}`, backgroundIndex);
              let toastText = backgroundToastList[backgroundIndex].replace('%s', `${backgroundIndex + 1}`);
              if (toastText.length > 0) hmUI.showToast({text: toastText});
              normal_background_bg_img.setProperty(hmUI.prop.SRC, backgroundList[backgroundIndex]);
              vibro(28);
            };
            //#endregion

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 10,
              y: 10,
              src: 'bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 354,
              y: 289,
              src: 'alarm1.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_heart_rate_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 240,
              // circle_center_Y: 240,
              // font_array: ["cif_00.png","cif_01.png","cif_02.png","cif_03.png","cif_04.png","cif_05.png","cif_06.png","cif_07.png","cif_08.png","cif_09.png"],
              // radius: 186,
              // angle: 134,
              // char_space_angle: 1,
              // zero: false,
              // reverse_direction: true,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_heart_rate_TextCircle_ASCIIARRAY[0] = 'cif_00.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[1] = 'cif_01.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[2] = 'cif_02.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[3] = 'cif_03.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[4] = 'cif_04.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[5] = 'cif_05.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[6] = 'cif_06.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[7] = 'cif_07.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[8] = 'cif_08.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[9] = 'cif_09.png';  // set of images with numbers

            //#region TextCircle
            for (let i = 0; i < 3; i++) {
              normal_heart_rate_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 240,
                center_y: 240,
                pos_x: 240 - normal_heart_rate_TextCircle_img_width / 2,
                pos_y: 240 + 160,
                src: 'cif_00.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_heart_rate_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //#endregion
            
            const heart_rate = hmSensor.createSensor(hmSensor.id.HEART);
            heart_rate.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });
            
            function toDegree (radian) {
              return radian * (180 / Math.PI);
            };

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 347,
              y: 172,
              week_en: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              week_tc: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              week_sc: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 117,
              month_startY: 172,
              month_sc_array: ["cif_00.png","cif_01.png","cif_02.png","cif_03.png","cif_04.png","cif_05.png","cif_06.png","cif_07.png","cif_08.png","cif_09.png"],
              month_tc_array: ["cif_00.png","cif_01.png","cif_02.png","cif_03.png","cif_04.png","cif_05.png","cif_06.png","cif_07.png","cif_08.png","cif_09.png"],
              month_en_array: ["cif_00.png","cif_01.png","cif_02.png","cif_03.png","cif_04.png","cif_05.png","cif_06.png","cif_07.png","cif_08.png","cif_09.png"],
              month_zero: 1,
              month_space: 1,
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 78,
              day_startY: 172,
              day_sc_array: ["cif_00.png","cif_01.png","cif_02.png","cif_03.png","cif_04.png","cif_05.png","cif_06.png","cif_07.png","cif_08.png","cif_09.png"],
              day_tc_array: ["cif_00.png","cif_01.png","cif_02.png","cif_03.png","cif_04.png","cif_05.png","cif_06.png","cif_07.png","cif_08.png","cif_09.png"],
              day_en_array: ["cif_00.png","cif_01.png","cif_02.png","cif_03.png","cif_04.png","cif_05.png","cif_06.png","cif_07.png","cif_08.png","cif_09.png"],
              day_zero: 1,
              day_space: 1,
              day_unit_sc: 'cif_10.png',
              day_unit_tc: 'cif_10.png',
              day_unit_en: 'cif_10.png',
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'str.png',
              center_x: 240,
              center_y: 343,
              x: 8,
              y: 37,
              start_angle: -180,
              end_angle: 180,
              invalid_visible: false,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_step_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 240,
              // circle_center_Y: 240,
              // font_array: ["cif_00.png","cif_01.png","cif_02.png","cif_03.png","cif_04.png","cif_05.png","cif_06.png","cif_07.png","cif_08.png","cif_09.png"],
              // radius: 186,
              // angle: -135,
              // char_space_angle: 1,
              // zero: false,
              // reverse_direction: true,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_step_TextCircle_ASCIIARRAY[0] = 'cif_00.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[1] = 'cif_01.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[2] = 'cif_02.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[3] = 'cif_03.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[4] = 'cif_04.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[5] = 'cif_05.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[6] = 'cif_06.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[7] = 'cif_07.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[8] = 'cif_08.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[9] = 'cif_09.png';  // set of images with numbers

            //#region TextCircle
            for (let i = 0; i < 5; i++) {
              normal_step_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 240,
                center_y: 240,
                pos_x: 240 - normal_step_TextCircle_img_width / 2,
                pos_y: 240 + 160,
                src: 'cif_00.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_step_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //#endregion
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            normal_moon_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 150,
              y: 27,
              src: 'ram.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 208,
              y: 271,
              image_array: ["moon_0.png","moon_1.png","moon_2.png","moon_3.png","moon_4.png","moon_5.png","moon_6.png","moon_7.png","moon_8.png","moon_9.png","moon_10.png","moon_11.png","moon_12.png","moon_13.png","moon_14.png","moon_15.png","moon_16.png","moon_17.png","moon_18.png","moon_19.png","moon_20.png","moon_21.png","moon_22.png","moon_23.png","moon_24.png","moon_25.png","moon_26.png","moon_27.png","moon_28.png","moon_29.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'str.png',
              center_x: 240,
              center_y: 136,
              x: 8,
              y: 37,
              start_angle: -180,
              end_angle: 180,
              invalid_visible: false,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 76,
              hour_startY: 211,
              hour_array: ["time_00.png","time_01.png","time_02.png","time_03.png","time_04.png","time_05.png","time_06.png","time_07.png","time_08.png","time_09.png"],
              hour_zero: 1,
              hour_space: 5,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 334,
              minute_startY: 211,
              minute_array: ["time_00.png","time_01.png","time_02.png","time_03.png","time_04.png","time_05.png","time_06.png","time_07.png","time_08.png","time_09.png"],
              minute_zero: 1,
              minute_space: 5,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const deviceInfo = hmSetting.getDeviceInfo();
            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.MINUTEEND, function() {
              let updateHour = timeSensor.minute == 0;

              time_update(updateHour, true);
            });

            // normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'h.png',
              // center_x: 240,
              // center_y: 240,
              // x: 30,
              // y: 240,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.hour,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 30,
              pos_y: 240 - 240,
              center_x: 240,
              center_y: 240,
              src: 'h.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            // normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'm.png',
              // center_x: 240,
              // center_y: 240,
              // x: 29,
              // y: 239,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.minute,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 29,
              pos_y: 240 - 239,
              center_x: 240,
              center_y: 240,
              src: 'm.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 's.png',
              // center_x: 240,
              // center_y: 240,
              // x: 22,
              // y: 240,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_time_pointer_smooth_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 's.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 22,
              second_posY: 240,
              fresh_frequency: 15,
              fresh_freqency: 15,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_smooth_second = hmUI.createWidget(hmUI.widget.SMOOTH_SECOND, {
              // type: 3,
              // fps: 15,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });



            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg_aod.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 10,
              y: 10,
              src: 'bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 354,
              y: 289,
              src: 'alarm1.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_heart_rate_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 240,
              // circle_center_Y: 240,
              // font_array: ["cif_00.png","cif_01.png","cif_02.png","cif_03.png","cif_04.png","cif_05.png","cif_06.png","cif_07.png","cif_08.png","cif_09.png"],
              // radius: 186,
              // angle: 134,
              // char_space_angle: 1,
              // zero: false,
              // reverse_direction: true,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_heart_rate_TextCircle_ASCIIARRAY[0] = 'cif_00.png';  // set of images with numbers
            idle_heart_rate_TextCircle_ASCIIARRAY[1] = 'cif_01.png';  // set of images with numbers
            idle_heart_rate_TextCircle_ASCIIARRAY[2] = 'cif_02.png';  // set of images with numbers
            idle_heart_rate_TextCircle_ASCIIARRAY[3] = 'cif_03.png';  // set of images with numbers
            idle_heart_rate_TextCircle_ASCIIARRAY[4] = 'cif_04.png';  // set of images with numbers
            idle_heart_rate_TextCircle_ASCIIARRAY[5] = 'cif_05.png';  // set of images with numbers
            idle_heart_rate_TextCircle_ASCIIARRAY[6] = 'cif_06.png';  // set of images with numbers
            idle_heart_rate_TextCircle_ASCIIARRAY[7] = 'cif_07.png';  // set of images with numbers
            idle_heart_rate_TextCircle_ASCIIARRAY[8] = 'cif_08.png';  // set of images with numbers
            idle_heart_rate_TextCircle_ASCIIARRAY[9] = 'cif_09.png';  // set of images with numbers

            //#region TextCircle
            for (let i = 0; i < 3; i++) {
              idle_heart_rate_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 240,
                center_y: 240,
                pos_x: 240 - idle_heart_rate_TextCircle_img_width / 2,
                pos_y: 240 + 160,
                src: 'cif_00.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_heart_rate_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //#endregion

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 347,
              y: 172,
              week_en: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              week_tc: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              week_sc: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 117,
              month_startY: 172,
              month_sc_array: ["cif_00.png","cif_01.png","cif_02.png","cif_03.png","cif_04.png","cif_05.png","cif_06.png","cif_07.png","cif_08.png","cif_09.png"],
              month_tc_array: ["cif_00.png","cif_01.png","cif_02.png","cif_03.png","cif_04.png","cif_05.png","cif_06.png","cif_07.png","cif_08.png","cif_09.png"],
              month_en_array: ["cif_00.png","cif_01.png","cif_02.png","cif_03.png","cif_04.png","cif_05.png","cif_06.png","cif_07.png","cif_08.png","cif_09.png"],
              month_zero: 1,
              month_space: 1,
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 78,
              day_startY: 172,
              day_sc_array: ["cif_00.png","cif_01.png","cif_02.png","cif_03.png","cif_04.png","cif_05.png","cif_06.png","cif_07.png","cif_08.png","cif_09.png"],
              day_tc_array: ["cif_00.png","cif_01.png","cif_02.png","cif_03.png","cif_04.png","cif_05.png","cif_06.png","cif_07.png","cif_08.png","cif_09.png"],
              day_en_array: ["cif_00.png","cif_01.png","cif_02.png","cif_03.png","cif_04.png","cif_05.png","cif_06.png","cif_07.png","cif_08.png","cif_09.png"],
              day_zero: 1,
              day_space: 1,
              day_unit_sc: 'cif_10.png',
              day_unit_tc: 'cif_10.png',
              day_unit_en: 'cif_10.png',
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_step_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 240,
              // circle_center_Y: 240,
              // font_array: ["cif_00.png","cif_01.png","cif_02.png","cif_03.png","cif_04.png","cif_05.png","cif_06.png","cif_07.png","cif_08.png","cif_09.png"],
              // radius: 186,
              // angle: -135,
              // char_space_angle: 1,
              // zero: false,
              // reverse_direction: true,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_step_TextCircle_ASCIIARRAY[0] = 'cif_00.png';  // set of images with numbers
            idle_step_TextCircle_ASCIIARRAY[1] = 'cif_01.png';  // set of images with numbers
            idle_step_TextCircle_ASCIIARRAY[2] = 'cif_02.png';  // set of images with numbers
            idle_step_TextCircle_ASCIIARRAY[3] = 'cif_03.png';  // set of images with numbers
            idle_step_TextCircle_ASCIIARRAY[4] = 'cif_04.png';  // set of images with numbers
            idle_step_TextCircle_ASCIIARRAY[5] = 'cif_05.png';  // set of images with numbers
            idle_step_TextCircle_ASCIIARRAY[6] = 'cif_06.png';  // set of images with numbers
            idle_step_TextCircle_ASCIIARRAY[7] = 'cif_07.png';  // set of images with numbers
            idle_step_TextCircle_ASCIIARRAY[8] = 'cif_08.png';  // set of images with numbers
            idle_step_TextCircle_ASCIIARRAY[9] = 'cif_09.png';  // set of images with numbers

            //#region TextCircle
            for (let i = 0; i < 5; i++) {
              idle_step_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 240,
                center_y: 240,
                pos_x: 240 - idle_step_TextCircle_img_width / 2,
                pos_y: 240 + 160,
                src: 'cif_00.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_step_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //#endregion

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 76,
              hour_startY: 211,
              hour_array: ["aod_time_00.png","aod_time_01.png","aod_time_02.png","aod_time_03.png","aod_time_04.png","aod_time_05.png","aod_time_06.png","aod_time_07.png","aod_time_08.png","aod_time_09.png"],
              hour_zero: 1,
              hour_space: 5,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 334,
              minute_startY: 211,
              minute_array: ["aod_time_00.png","aod_time_01.png","aod_time_02.png","aod_time_03.png","aod_time_04.png","aod_time_05.png","aod_time_06.png","aod_time_07.png","aod_time_08.png","aod_time_09.png"],
              minute_zero: 1,
              minute_space: 5,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'h.png',
              // center_x: 240,
              // center_y: 240,
              // x: 30,
              // y: 240,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.hour,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });


            idle_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 30,
              pos_y: 240 - 240,
              center_x: 240,
              center_y: 240,
              src: 'h.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'm.png',
              // center_x: 240,
              // center_y: 240,
              // x: 29,
              // y: 239,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.minute,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });


            idle_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 29,
              pos_y: 240 - 239,
              center_x: 240,
              center_y: 240,
              src: 'm.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            image_top_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'top_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

 normal_moon_icon_img.setProperty(hmUI.prop.VISIBLE, VIS_str == 0);
 normal_moon_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, VIS_str == 0);
            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 195,
              y: 390,
              w: 90,
              h: 90,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '1empty.png',
              normal_src: '1empty.png',
              click_func: (button_widget) => {
                clic_VIS_str();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 200,
              y: 96,
              w: 80,
              h: 80,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '1empty.png',
              normal_src: '1empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'Settings_batteryManagerScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 331,
              y: 137,
              w: 80,
              h: 70,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '1empty.png',
              normal_src: '1empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 73,
              y: 137,
              w: 80,
              h: 70,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '1empty.png',
              normal_src: '1empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'AlarmInfoScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 331,
              y: 207,
              w: 80,
              h: 70,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '1empty.png',
              normal_src: '1empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'StopWatchScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 73,
              y: 207,
              w: 80,
              h: 70,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '1empty.png',
              normal_src: '1empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'CountdownAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_7 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 77,
              y: 323,
              w: 80,
              h: 80,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '1empty.png',
              normal_src: '1empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'activityAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_8 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 322,
              y: 323,
              w: 80,
              h: 80,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '1empty.png',
              normal_src: '1empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'heart_app_Screen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_9 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 201,
              y: 287,
              w: 80,
              h: 80,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '1empty.png',
              normal_src: '1empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({ appid: 1051195, url: 'page/index', params: { from_wf: true} });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            console.log('Watch_Face.SwitchBackground');
            // Button_Switch_BG = hmUI.createWidget(hmUI.widget.SwitchBackground, {
              // x: 190,
              // y: 199,
              // w: 100,
              // h: 80,
              // text: '',
              // color: 0xFFFF8C00,
              // text_size: 25,
              // press_src: '1empty.png',
              // normal_src: '1empty.png',
              // bg_list: bg_1|bg_2|bg_3|bg_4|bg_5|bg_6|bg_7|bg_8,
              // toast_list: Фон %s|Фон %s|Фон %s|Фон %s|Фон %s|Фон %s|Фон %s|Фон %s,
              // use_crown: False,
              // use_in_AOD: False,
              // vibro: True,
            // });

            Button_Switch_BG = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 190,
              y: 199,
              w: 100,
              h: 80,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '1empty.png',
              normal_src: '1empty.png',
              click_func: (button_widget) => {
                switchBackground();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            //#region vibrate function
            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;

            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            //#endregion

            //#region time_update
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              if (updateMinute) { // Hour Pointer
                let normal_hour = hour;
                let normal_fullAngle_hour = 360;
                if (normal_hour > 11) normal_hour -= 12;
                let normal_angle_hour = 0 + normal_fullAngle_hour*normal_hour/12 + (normal_fullAngle_hour/12)*minute/60;
                if (normal_analog_clock_pro_hour_pointer_img) normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_hour);
              };

                let normal_fullAngle_minute = 360;
                let normal_angle_minute = 0 + normal_fullAngle_minute*(minute + second/60)/60;
                if (normal_analog_clock_pro_minute_pointer_img) normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_minute);
              if (updateMinute) { // Hour Pointer
                let idle_hour = hour;
                let idle_fullAngle_hour = 360;
                if (idle_hour > 11) idle_hour -= 12;
                let idle_angle_hour = 0 + idle_fullAngle_hour*idle_hour/12 + (idle_fullAngle_hour/12)*minute/60;
                if (idle_analog_clock_pro_hour_pointer_img) idle_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.ANGLE, idle_angle_hour);
              };

              if (updateMinute) { // Minute Pointer
                let idle_fullAngle_minute = 360;
                let idle_angle_minute = 0 + idle_fullAngle_minute*minute/60;
                if (idle_analog_clock_pro_minute_pointer_img) idle_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.ANGLE, idle_angle_minute);
              };

            };

            //#endregion
            //#region text_update
            function text_update() {
              console.log('text_update()');

              console.log('update text circle heart_rate_HEART');
              let valueHeartRate = heart_rate.last;
              let normal_heart_rate_circle_string = parseInt(valueHeartRate).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  normal_heart_rate_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = 314;
                if (valueHeartRate != null && valueHeartRate != undefined && isFinite(valueHeartRate) && normal_heart_rate_circle_string.length > 0 && normal_heart_rate_circle_string.length <= 3) {  // display data if it was possible to get it
                  let normal_heart_rate_TextCircle_img_angle = 0;
                  let normal_heart_rate_TextCircle_dot_img_angle = 0;
                  normal_heart_rate_TextCircle_img_angle = toDegree(Math.atan2(normal_heart_rate_TextCircle_img_width/2, 186));
                  // alignment = CENTER_H
                  let normal_heart_rate_TextCircle_angleOffset = normal_heart_rate_TextCircle_img_angle * (normal_heart_rate_circle_string.length - 1);
                  normal_heart_rate_TextCircle_angleOffset = normal_heart_rate_TextCircle_angleOffset + 1 * (normal_heart_rate_circle_string.length - 1) / 2;
                  normal_heart_rate_TextCircle_angleOffset = -normal_heart_rate_TextCircle_angleOffset;
                  char_Angle -= normal_heart_rate_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_heart_rate_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= normal_heart_rate_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_heart_rate_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_heart_rate_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - normal_heart_rate_TextCircle_img_width / 2);
                      normal_heart_rate_TextCircle[index].setProperty(hmUI.prop.SRC, normal_heart_rate_TextCircle_ASCIIARRAY[charCode]);
                      normal_heart_rate_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= normal_heart_rate_TextCircle_img_angle + 1;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text circle step_STEP');
              let valueStep = step.current;
              let normal_step_circle_string = parseInt(valueStep).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  normal_step_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = 45;
                if (valueStep != null && valueStep != undefined && isFinite(valueStep) && normal_step_circle_string.length > 0 && normal_step_circle_string.length <= 5) {  // display data if it was possible to get it
                  let normal_step_TextCircle_img_angle = 0;
                  let normal_step_TextCircle_dot_img_angle = 0;
                  normal_step_TextCircle_img_angle = toDegree(Math.atan2(normal_step_TextCircle_img_width/2, 186));
                  // alignment = CENTER_H
                  let normal_step_TextCircle_angleOffset = normal_step_TextCircle_img_angle * (normal_step_circle_string.length - 1);
                  normal_step_TextCircle_angleOffset = normal_step_TextCircle_angleOffset + 1 * (normal_step_circle_string.length - 1) / 2;
                  normal_step_TextCircle_angleOffset = -normal_step_TextCircle_angleOffset;
                  char_Angle -= normal_step_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_step_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= normal_step_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_step_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_step_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - normal_step_TextCircle_img_width / 2);
                      normal_step_TextCircle[index].setProperty(hmUI.prop.SRC, normal_step_TextCircle_ASCIIARRAY[charCode]);
                      normal_step_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= normal_step_TextCircle_img_angle + 1;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text circle heart_rate_HEART');
              let idle_heart_rate_circle_string = parseInt(valueHeartRate).toString();

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  idle_heart_rate_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = 314;
                if (valueHeartRate != null && valueHeartRate != undefined && isFinite(valueHeartRate) && idle_heart_rate_circle_string.length > 0 && idle_heart_rate_circle_string.length <= 3) {  // display data if it was possible to get it
                  let idle_heart_rate_TextCircle_img_angle = 0;
                  let idle_heart_rate_TextCircle_dot_img_angle = 0;
                  idle_heart_rate_TextCircle_img_angle = toDegree(Math.atan2(idle_heart_rate_TextCircle_img_width/2, 186));
                  // alignment = CENTER_H
                  let idle_heart_rate_TextCircle_angleOffset = idle_heart_rate_TextCircle_img_angle * (idle_heart_rate_circle_string.length - 1);
                  idle_heart_rate_TextCircle_angleOffset = idle_heart_rate_TextCircle_angleOffset + 1 * (idle_heart_rate_circle_string.length - 1) / 2;
                  idle_heart_rate_TextCircle_angleOffset = -idle_heart_rate_TextCircle_angleOffset;
                  char_Angle -= idle_heart_rate_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of idle_heart_rate_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= idle_heart_rate_TextCircle_img_angle;
                      firstSymbol = false;
                      idle_heart_rate_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      idle_heart_rate_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - idle_heart_rate_TextCircle_img_width / 2);
                      idle_heart_rate_TextCircle[index].setProperty(hmUI.prop.SRC, idle_heart_rate_TextCircle_ASCIIARRAY[charCode]);
                      idle_heart_rate_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= idle_heart_rate_TextCircle_img_angle + 1;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text circle step_STEP');
              let idle_step_circle_string = parseInt(valueStep).toString();

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  idle_step_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = 45;
                if (valueStep != null && valueStep != undefined && isFinite(valueStep) && idle_step_circle_string.length > 0 && idle_step_circle_string.length <= 5) {  // display data if it was possible to get it
                  let idle_step_TextCircle_img_angle = 0;
                  let idle_step_TextCircle_dot_img_angle = 0;
                  idle_step_TextCircle_img_angle = toDegree(Math.atan2(idle_step_TextCircle_img_width/2, 186));
                  // alignment = CENTER_H
                  let idle_step_TextCircle_angleOffset = idle_step_TextCircle_img_angle * (idle_step_circle_string.length - 1);
                  idle_step_TextCircle_angleOffset = idle_step_TextCircle_angleOffset + 1 * (idle_step_circle_string.length - 1) / 2;
                  idle_step_TextCircle_angleOffset = -idle_step_TextCircle_angleOffset;
                  char_Angle -= idle_step_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of idle_step_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= idle_step_TextCircle_img_angle;
                      firstSymbol = false;
                      idle_step_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      idle_step_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - idle_step_TextCircle_img_width / 2);
                      idle_step_TextCircle[index].setProperty(hmUI.prop.SRC, idle_step_TextCircle_ASCIIARRAY[charCode]);
                      idle_step_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= idle_step_TextCircle_img_angle + 1;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

            };

            //#endregion
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
   loadSettings()
                console.log('resume_call()');
                time_update(true, true);
                text_update();
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSec) {
                    let animDelay = timeSensor.utc % 1000;
                    let animRepeat = 1000;
                    normal_timerUpdateSec = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, true);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


                //SwitchBackground
                if (hmFS.SysProGetInt(`backgroundIndex_${watchfaceId}`) === undefined) {
                  backgroundIndex = 0;
                  hmFS.SysProSetInt(`backgroundIndex_${watchfaceId}`, backgroundIndex);
                } else {
                  backgroundIndex = hmFS.SysProGetInt(`backgroundIndex_${watchfaceId}`);
                };
                if (screenType == hmSetting.screen_type.WATCHFACE && normal_background_bg_img) normal_background_bg_img.setProperty(hmUI.prop.SRC, backgroundList[backgroundIndex]);
              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerUpdateSec) {
                  timer.stopTimer(normal_timerUpdateSec);
                  normal_timerUpdateSec = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                heart_rate.removeEventListener(heart.event.CURRENT, hrCurrListener);
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
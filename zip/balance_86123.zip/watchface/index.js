﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_week_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_text_separator_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_text_separator_img = ''
        let normal_step_icon_img = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_digital_clock_minute_separator_img = ''
        let normal_digital_clock_second_separator_img = ''
        let idle_background_bg_img = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_week_img = ''
        let idle_battery_text_text_img = ''
        let idle_battery_text_separator_img = ''
        let idle_battery_image_progress_img_level = ''
        let idle_heart_rate_text_text_img = ''
        let idle_heart_rate_text_separator_img = ''
        let idle_step_current_text_img = ''
        let idle_step_current_separator_img = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''
        let idle_digital_clock_minute_separator_img = ''
        let normal_step_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_battery_jumpable_img_click = ''
        let normal_stand_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_Switch_BG = ''

        let backgroundIndex = 0;
        let backgroundList = ['WF_Default.png', 'WF_Orange.png', 'WF_Gold.png', 'WF_Yellow.png', 'WF_Blue.png', 'WF_Gray.png', 'WF_Red.png', 'WF_DarkGray.png', 'WF_Green.png', 'WF_Brown.png'];
        let backgroundToastList = ['Default', 'Burnt Orange', 'Gold', 'Yellow', 'Sports Blue', 'Gray', 'Red', 'Dark Gray', 'Green', 'Brown'];
        const watchfaceId = hmApp.packageInfo().watchfaceId;


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            //#region SwitchBackground
            console.log('SwitchBackground');
            function switchBackground() {
              backgroundIndex++;
              if (backgroundIndex >= backgroundList.length) backgroundIndex = 0;
              hmFS.SysProSetInt(`backgroundIndex_${watchfaceId}`, backgroundIndex);
              let toastText = backgroundToastList[backgroundIndex].replace('%s', `${backgroundIndex + 1}`);
              if (toastText.length > 0) hmUI.showToast({text: toastText});
              normal_background_bg_img.setProperty(hmUI.prop.SRC, backgroundList[backgroundIndex]);
            };
            //#endregion

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'WF_Default.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 419,
              y: 216,
              src: 'Bluetooth_off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 419,
              y: 170,
              src: 'Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 186,
              day_startY: 407,
              day_sc_array: ["digit_01.png","digit_02.png","digit_03.png","digit_04.png","digit_05.png","digit_06.png","digit_07.png","digit_08.png","digit_09.png","digit_10.png"],
              day_tc_array: ["digit_01.png","digit_02.png","digit_03.png","digit_04.png","digit_05.png","digit_06.png","digit_07.png","digit_08.png","digit_09.png","digit_10.png"],
              day_en_array: ["digit_01.png","digit_02.png","digit_03.png","digit_04.png","digit_05.png","digit_06.png","digit_07.png","digit_08.png","digit_09.png","digit_10.png"],
              day_zero: 1,
              day_space: -5,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 230,
              month_startY: 407,
              month_sc_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_tc_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_en_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 149,
              y: 349,
              week_en: ["day_01.png","day_02.png","day_03.png","day_04.png","day_05.png","day_06.png","day_07.png"],
              week_tc: ["day_01.png","day_02.png","day_03.png","day_04.png","day_05.png","day_06.png","day_07.png"],
              week_sc: ["day_01.png","day_02.png","day_03.png","day_04.png","day_05.png","day_06.png","day_07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 310,
              y: 93,
              font_array: ["digit_01.png","digit_02.png","digit_03.png","digit_04.png","digit_05.png","digit_06.png","digit_07.png","digit_08.png","digit_09.png","digit_10.png"],
              padding: false,
              h_space: -5,
              unit_sc: 'Percent.png',
              unit_tc: 'Percent.png',
              unit_en: 'Percent.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 333,
              y: 164,
              src: 'Clock_digit_01.png',
              // alpha: 50,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_separator_img.setAlpha(50);

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 335,
              y: 46,
              image_array: ["Bat0.png","Bat1.png","Bat2.png","Bat3.png","Bat4.png","Bat5.png"],
              image_length: 6,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 444,
              y: 268,
              src: 'Sec_digit_01.png',
              // alpha: 50,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_icon_img.setAlpha(50);

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 84,
              y: 93,
              font_array: ["digit_01.png","digit_02.png","digit_03.png","digit_04.png","digit_05.png","digit_06.png","digit_07.png","digit_08.png","digit_09.png","digit_10.png"],
              padding: false,
              h_space: -5,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 93,
              y: 46,
              src: 'Heart.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 419,
              y: 268,
              src: 'Sec_digit_01.png',
              // alpha: 50,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img.setAlpha(50);

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 183,
              y: 52,
              font_array: ["digit_01.png","digit_02.png","digit_03.png","digit_04.png","digit_05.png","digit_06.png","digit_07.png","digit_08.png","digit_09.png","digit_10.png"],
              padding: false,
              h_space: -5,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 217,
              y: 5,
              src: 'shoe.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 44,
              hour_startY: 164,
              hour_array: ["Clock_digit_01.png","Clock_digit_02.png","Clock_digit_03.png","Clock_digit_04.png","Clock_digit_05.png","Clock_digit_06.png","Clock_digit_07.png","Clock_digit_08.png","Clock_digit_09.png","Clock_digit_10.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_unit_sc: 'Col.png',
              hour_unit_tc: 'Col.png',
              hour_unit_en: 'Col.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 0,
              minute_startY: 0,
              minute_array: ["Clock_digit_01.png","Clock_digit_02.png","Clock_digit_03.png","Clock_digit_04.png","Clock_digit_05.png","Clock_digit_06.png","Clock_digit_07.png","Clock_digit_08.png","Clock_digit_09.png","Clock_digit_10.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 1,
              minute_align: hmUI.align.LEFT,

              second_startX: 419,
              second_startY: 268,
              second_array: ["Sec_digit_01.png","Sec_digit_02.png","Sec_digit_03.png","Sec_digit_04.png","Sec_digit_05.png","Sec_digit_06.png","Sec_digit_07.png","Sec_digit_08.png","Sec_digit_09.png","Sec_digit_10.png"],
              second_zero: 1,
              second_space: -5,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 44,
              y: 164,
              src: 'Clock_digit_01.png',
              // alpha: 50,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img.setAlpha(50);

            normal_digital_clock_minute_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 251,
              y: 164,
              src: 'Clock_digit_01.png',
              // alpha: 50,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_minute_separator_img.setAlpha(50);

            normal_digital_clock_second_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 127,
              y: 164,
              src: 'Clock_digit_01.png',
              // alpha: 50,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_second_separator_img.setAlpha(50);


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'WF_DarkGray.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 186,
              day_startY: 407,
              day_sc_array: ["digit_01.png","digit_02.png","digit_03.png","digit_04.png","digit_05.png","digit_06.png","digit_07.png","digit_08.png","digit_09.png","digit_10.png"],
              day_tc_array: ["digit_01.png","digit_02.png","digit_03.png","digit_04.png","digit_05.png","digit_06.png","digit_07.png","digit_08.png","digit_09.png","digit_10.png"],
              day_en_array: ["digit_01.png","digit_02.png","digit_03.png","digit_04.png","digit_05.png","digit_06.png","digit_07.png","digit_08.png","digit_09.png","digit_10.png"],
              day_zero: 1,
              day_space: -5,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 230,
              month_startY: 407,
              month_sc_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_tc_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_en_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 149,
              y: 349,
              week_en: ["day_01.png","day_02.png","day_03.png","day_04.png","day_05.png","day_06.png","day_07.png"],
              week_tc: ["day_01.png","day_02.png","day_03.png","day_04.png","day_05.png","day_06.png","day_07.png"],
              week_sc: ["day_01.png","day_02.png","day_03.png","day_04.png","day_05.png","day_06.png","day_07.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 310,
              y: 93,
              font_array: ["digit_01.png","digit_02.png","digit_03.png","digit_04.png","digit_05.png","digit_06.png","digit_07.png","digit_08.png","digit_09.png","digit_10.png"],
              padding: false,
              h_space: -5,
              unit_sc: 'Percent.png',
              unit_tc: 'Percent.png',
              unit_en: 'Percent.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 333,
              y: 164,
              src: 'Clock_digit_01.png',
              // alpha: 50,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_separator_img.setAlpha(50);

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 335,
              y: 46,
              image_array: ["Bat0.png","Bat1.png","Bat2.png","Bat3.png","Bat4.png","Bat5.png"],
              image_length: 6,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 84,
              y: 93,
              font_array: ["digit_01.png","digit_02.png","digit_03.png","digit_04.png","digit_05.png","digit_06.png","digit_07.png","digit_08.png","digit_09.png","digit_10.png"],
              padding: false,
              h_space: -5,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 93,
              y: 46,
              src: 'Heart.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 183,
              y: 52,
              font_array: ["digit_01.png","digit_02.png","digit_03.png","digit_04.png","digit_05.png","digit_06.png","digit_07.png","digit_08.png","digit_09.png","digit_10.png"],
              padding: false,
              h_space: -5,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 217,
              y: 5,
              src: 'shoe.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 44,
              hour_startY: 164,
              hour_array: ["Clock_digit_01.png","Clock_digit_02.png","Clock_digit_03.png","Clock_digit_04.png","Clock_digit_05.png","Clock_digit_06.png","Clock_digit_07.png","Clock_digit_08.png","Clock_digit_09.png","Clock_digit_10.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_unit_sc: 'Col.png',
              hour_unit_tc: 'Col.png',
              hour_unit_en: 'Col.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 0,
              minute_startY: 0,
              minute_array: ["Clock_digit_01.png","Clock_digit_02.png","Clock_digit_03.png","Clock_digit_04.png","Clock_digit_05.png","Clock_digit_06.png","Clock_digit_07.png","Clock_digit_08.png","Clock_digit_09.png","Clock_digit_10.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 1,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 44,
              y: 164,
              src: 'Clock_digit_01.png',
              // alpha: 50,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img.setAlpha(50);

            idle_digital_clock_minute_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 251,
              y: 164,
              src: 'Clock_digit_01.png',
              // alpha: 50,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_minute_separator_img.setAlpha(50);
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 184,
              y: 0,
              w: 103,
              h: 103,
              src: '0_Empty.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 69,
              y: 36,
              w: 103,
              h: 103,
              src: '0_Empty.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 308,
              y: 36,
              w: 103,
              h: 103,
              src: '0_Empty.png',
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 410,
              y: 230,
              w: 103,
              h: 103,
              src: '0_Empty.png',
              type: hmUI.data_type.STAND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 35,
              y: 340,
              w: 412,
              h: 155,
              text: '',
              color: 0xFFFF8C00,
              text_size: 26,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 0,
              y: 0,
              w: 103,
              h: 41,
              text: '',
              color: 0xFFFF8C00,
              text_size: 26,
              radius: 12,
              press_color: 0xFFA0A0A0,
              normal_color: 0xFF696969,
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            console.log('Watch_Face.SwitchBackground');
            // Button_Switch_BG = hmUI.createWidget(hmUI.widget.SwitchBackground, {
              // x: 199,
              // y: 147,
              // w: 62,
              // h: 185,
              // text: '',
              // color: 0xFFFF8C00,
              // text_size: 26,
              // press_src: '0_Empty.png',
              // normal_src: '0_Empty.png',
              // bg_list: WF_Default|WF_Orange|WF_Gold|WF_Yellow|WF_Blue|WF_Gray|WF_Red|WF_DarkGray|WF_Green|WF_Brown,
              // toast_list: Default|Burnt Orange|Gold|Yellow|Sports Blue|Gray|Red|Dark Gray|Green|Brown,
              // use_crown: False,
              // use_in_AOD: False,
              // vibro: False,
            // });

            Button_Switch_BG = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 199,
              y: 147,
              w: 62,
              h: 185,
              text: '',
              color: 0xFFFF8C00,
              text_size: 26,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                switchBackground();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            let screenType = hmSetting.getScreenType();
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');

                //SwitchBackground
                if (hmFS.SysProGetInt(`backgroundIndex_${watchfaceId}`) === undefined) {
                  backgroundIndex = 0;
                  hmFS.SysProSetInt(`backgroundIndex_${watchfaceId}`, backgroundIndex);
                } else {
                  backgroundIndex = hmFS.SysProGetInt(`backgroundIndex_${watchfaceId}`);
                };
                if (screenType == hmSetting.screen_type.WATCHFACE && normal_background_bg_img) normal_background_bg_img.setProperty(hmUI.prop.SRC, backgroundList[backgroundIndex]);
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
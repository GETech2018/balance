/*
** Facemaker bundle tool v0.0.3
* *huamiOS watchface js version v4.4.0.1
* *Copyright © Huami. All Rights Reserved
*/


try {
	(() => {
		var __$$app$$__ = __$$hmAppManager$$__.currentApp;
		var __$$module$$__ = __$$app$$__.current;

		//drink is a name,can modify
		var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

		'use strict';

		//dynamic modify start
		let normal_img0 = '';
		let normal_hour_imagecombo2 = '';
		let normal_minute_imagecombo3 = '';
		let normal_img4 = '';
		let normal_week_imageset6 = '';
		let normal_month_imageset7 = '';
		let normal_date_imagecombo8 = '';
		let normal_heart_current_imagecombo10 = '';
		let normal_steps_imagecombo12 = '';
		let normal_calories_imagecombo14 = '';
		let normal_weather_imageset16 = '';
		let normal_temperature_current_imagecombo17 = '';
		let normal_battery_imagecombo19 = '';
		let normal_calories_shortcut22 = '';
		let normal_heart_shortcut23 = '';
		let normal_steps_shortcut24 = '';
		let normal_weather_shortcut25 = '';
		let normal_calendar_shortcut26 = '';
		let normal_alarm_shortcut27 = '';
		let normal_countdown_shortcut28 = '';
		let idle_hour_imagecombo30 = '';
		let idle_minute_imagecombo31 = '';
		let idle_img32 = '';
		let idle_week_imageset34 = '';
		let idle_month_imageset35 = '';
		let idle_date_imagecombo36 = '';
		let idle_img37 = '';
		//dynamic modify end

		//not required
		const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

		__$$module$$__.module = DeviceRuntimeCore.WatchFace({
			init_view() {

				let screenType = hmSetting.getScreenType();

				normal_img0 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					src: '0002.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_hour_imagecombo2 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					hour_startX: 140,
					hour_startY: 106,
					hour_array: ["0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png"],
					hour_zero: true,
					hour_space: -9,
					hour_align: hmUI.align.CENTER_H,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_minute_imagecombo3 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					minute_startX: 241,
					minute_startY: 106,
					minute_array: ["0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png"],
					minute_zero: true,
					minute_space: -9,
					minute_align: hmUI.align.CENTER_H,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img4 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 232,
					y: 106,
					w: 14,
					h: 64,
					src: '0013.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_week_imageset6 = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
					x: 154,
					y: 187,
					week_en: ["0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png"],
					week_tc: ["0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png"],
					week_sc: ["0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png"],
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_month_imageset7 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
					month_startX: 263,
					month_startY: 187,
					month_sc_array: ["0021.png","0022.png","0023.png","0024.png","0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png"],
					month_tc_array: ["0021.png","0022.png","0023.png","0024.png","0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png"],
					month_en_array: ["0021.png","0022.png","0023.png","0024.png","0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png"],
					month_is_character: true,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_date_imagecombo8 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
					day_startX: 219,
					day_startY: 187,
					day_sc_array: ["0033.png","0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png"],
					day_tc_array: ["0033.png","0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png"],
					day_en_array: ["0033.png","0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png"],
					day_zero: true,
					day_space: -8,
					day_align: hmUI.align.CENTER_H,
					day_is_character: false,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_heart_current_imagecombo10 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 147,
					y: 269,
					font_array: ["0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png","0050.png","0051.png","0052.png"],
					padding: false,
					h_space: -7,
					invalid_image: '0053.png',
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.HEART,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_steps_imagecombo12 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 318,
					y: 270,
					font_array: ["0054.png","0055.png","0056.png","0057.png","0058.png","0059.png","0060.png","0061.png","0062.png","0063.png"],
					padding: false,
					h_space: -8,
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.STEP,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_calories_imagecombo14 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 147,
					y: 348,
					font_array: ["0064.png","0065.png","0066.png","0067.png","0068.png","0069.png","0070.png","0071.png","0072.png","0073.png"],
					padding: false,
					h_space: -7,
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.CAL,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_weather_imageset16 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
					x: 372,
					y: 319,
					image_array: ["0074.png","0075.png","0076.png","0077.png","0078.png","0079.png","0080.png","0081.png","0082.png","0083.png","0084.png","0085.png","0086.png","0087.png","0088.png","0089.png","0090.png","0091.png","0092.png","0093.png","0094.png","0095.png","0096.png","0097.png","0098.png","0099.png","0100.png","0101.png","0102.png"],
					image_length: 29,
					type: hmUI.data_type.WEATHER_CURRENT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_temperature_current_imagecombo17 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 324,
					y: 359,
					font_array: ["0103.png","0104.png","0105.png","0106.png","0107.png","0108.png","0109.png","0110.png","0111.png","0112.png"],
					padding: false,
					h_space: -6,
					unit_sc: ["0114.png"],
					unit_tc: ["0114.png"],
					unit_en: ["0114.png"],
					negative_image: ["0113.png"],
					invalid_image: ["0113.png"],
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.WEATHER_CURRENT,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_battery_imagecombo19 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 157,
					y: 418,
					font_array: ["0115.png","0116.png","0117.png","0118.png","0119.png","0120.png","0121.png","0122.png","0123.png","0124.png"],
					padding: false,
					h_space: -7,
					unit_sc: '0125.png',
					unit_tc: '0125.png',
					unit_en: '0125.png',
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.BATTERY,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_calories_shortcut22 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 121,
					y: 319,
					w: 100,
					h: 59,
					src: '',
					type: hmUI.data_type.CAL,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_heart_shortcut23 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 109,
					y: 244,
					w: 100,
					h: 61,
					src: '',
					type: hmUI.data_type.HEART,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_steps_shortcut24 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 289,
					y: 249,
					w: 100,
					h: 61,
					src: '',
					type: hmUI.data_type.STEP,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_weather_shortcut25 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 277,
					y: 337,
					w: 100,
					h: 100,
					src: '',
					type: hmUI.data_type.WEATHER_CURRENT,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_calendar_shortcut26 = hmUI.createWidget(hmUI.widget.BUTTON, {
					x: 190,
					y: 179,
					w: 100,
					h: 50,
					text: '',
					normal_src: '',
					press_src: '',
					click_func: () => {
						hmApp.startApp({ url: 'ScheduleCalScreen', native: true });
					},
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_alarm_shortcut27 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 121,
					y: 73,
					w: 100,
					h: 100,
					src: '',
					type: hmUI.data_type.ALARM_CLOCK,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_countdown_shortcut28 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 253,
					y: 73,
					w: 100,
					h: 100,
					src: '',
					type: hmUI.data_type.COUNT_DOWN,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				idle_hour_imagecombo30 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					hour_startX: 140,
					hour_startY: 106,
					hour_array: ["0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png"],
					hour_zero: true,
					hour_space: -9,
					hour_align: hmUI.align.CENTER_H,
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_minute_imagecombo31 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					minute_startX: 241,
					minute_startY: 106,
					minute_array: ["0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png"],
					minute_zero: true,
					minute_space: -9,
					minute_align: hmUI.align.CENTER_H,
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_img32 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 232,
					y: 106,
					w: 14,
					h: 64,
					src: '0013.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_week_imageset34 = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
					x: 154,
					y: 187,
					week_en: ["0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png"],
					week_tc: ["0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png"],
					week_sc: ["0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png"],
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_month_imageset35 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
					month_startX: 263,
					month_startY: 187,
					month_sc_array: ["0021.png","0022.png","0023.png","0024.png","0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png"],
					month_tc_array: ["0021.png","0022.png","0023.png","0024.png","0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png"],
					month_en_array: ["0021.png","0022.png","0023.png","0024.png","0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png"],
					month_is_character: true,
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_date_imagecombo36 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
					day_startX: 219,
					day_startY: 187,
					day_sc_array: ["0033.png","0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png"],
					day_tc_array: ["0033.png","0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png"],
					day_en_array: ["0033.png","0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png"],
					day_zero: true,
					day_space: -8,
					day_align: hmUI.align.CENTER_H,
					day_is_character: false,
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_img37 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 67,
					y: 253,
					w: 350,
					h: 79,
					src: '0126.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

			},

		onInit() {
			console.log('index page.js on init invoke')
			this.init_view()
		},
		onReady() {
			console.log('index page.js on ready invoke')
		},
		onShow() {
			console.log('index page.js on show invoke')
		},
		onHide() {
			console.log('index page.js on hide invoke')
		},
		onDestroy() {
			console.log('index page.js on destroy invoke')
		},
	});	})()
} catch (e) {
	console.log(e)
}
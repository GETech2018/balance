﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_system_clock_img = ''
        let normal_step_current_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_date_img_date_year = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_month = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_digital_clock_img_time = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_system_clock_img = ''
        let idle_date_img_date_year = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_month = ''
        let idle_digital_clock_img_time = ''
        let normal_step_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_fatBurning_jumpable_img_click = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'FREE174.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 196,
              y: 4,
              image_array: ["w00.png","w01.png","w02.png","w03.png","w04.png","w05.png","w06.png","w07.png","w08.png","w09.png","w10.png","w11.png","w12.png","w13.png","w14.png","w15.png","w16.png","w17.png","w18.png","w19.png","w20.png","w21.png","w22.png","w23.png","w24.png","w25.png","w26.png","w27.png","w28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 247,
              y: 25,
              font_array: ["MINI00.png","MINI01.png","MINI02.png","MINI03.png","MINI04.png","MINI05.png","MINI06.png","MINI07.png","MINI08.png","MINI09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'MINI15.png',
              unit_tc: 'MINI15.png',
              unit_en: 'MINI15.png',
              negative_image: 'MINI13.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 381,
              y: 242,
              src: 'ALAEME.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 198,
              y: 330,
              font_array: ["MINI00.png","MINI01.png","MINI02.png","MINI03.png","MINI04.png","MINI05.png","MINI06.png","MINI07.png","MINI08.png","MINI09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 330,
              y: 330,
              font_array: ["MINI00.png","MINI01.png","MINI02.png","MINI03.png","MINI04.png","MINI05.png","MINI06.png","MINI07.png","MINI08.png","MINI09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 89,
              y: 330,
              font_array: ["MINI00.png","MINI01.png","MINI02.png","MINI03.png","MINI04.png","MINI05.png","MINI06.png","MINI07.png","MINI08.png","MINI09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 260,
              year_startY: 99,
              year_sc_array: ["INI-00.png","INI-01.png","INI-02.png","INI-03.png","INI-04.png","INI-05.png","INI-06.png","INI-07.png","INI-08.png","INI-09.png"],
              year_tc_array: ["INI-00.png","INI-01.png","INI-02.png","INI-03.png","INI-04.png","INI-05.png","INI-06.png","INI-07.png","INI-08.png","INI-09.png"],
              year_en_array: ["INI-00.png","INI-01.png","INI-02.png","INI-03.png","INI-04.png","INI-05.png","INI-06.png","INI-07.png","INI-08.png","INI-09.png"],
              year_zero: 1,
              year_space: 0,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 212,
              y: 62,
              week_en: ["J0047.png","J0048.png","J0049.png","J0050.png","J0051.png","J0052.png","J0053.png"],
              week_tc: ["J0047.png","J0048.png","J0049.png","J0050.png","J0051.png","J0052.png","J0053.png"],
              week_sc: ["J0047.png","J0048.png","J0049.png","J0050.png","J0051.png","J0052.png","J0053.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 87,
              day_startY: 99,
              day_sc_array: ["INI-00.png","INI-01.png","INI-02.png","INI-03.png","INI-04.png","INI-05.png","INI-06.png","INI-07.png","INI-08.png","INI-09.png"],
              day_tc_array: ["INI-00.png","INI-01.png","INI-02.png","INI-03.png","INI-04.png","INI-05.png","INI-06.png","INI-07.png","INI-08.png","INI-09.png"],
              day_en_array: ["INI-00.png","INI-01.png","INI-02.png","INI-03.png","INI-04.png","INI-05.png","INI-06.png","INI-07.png","INI-08.png","INI-09.png"],
              day_zero: 1,
              day_space: 0,
              day_unit_sc: 'INI-11.png',
              day_unit_tc: 'INI-11.png',
              day_unit_en: 'INI-11.png',
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 172,
              month_startY: 99,
              month_sc_array: ["INI-00.png","INI-01.png","INI-02.png","INI-03.png","INI-04.png","INI-05.png","INI-06.png","INI-07.png","INI-08.png","INI-09.png"],
              month_tc_array: ["INI-00.png","INI-01.png","INI-02.png","INI-03.png","INI-04.png","INI-05.png","INI-06.png","INI-07.png","INI-08.png","INI-09.png"],
              month_en_array: ["INI-00.png","INI-01.png","INI-02.png","INI-03.png","INI-04.png","INI-05.png","INI-06.png","INI-07.png","INI-08.png","INI-09.png"],
              month_zero: 1,
              month_space: 0,
              month_unit_sc: 'INI-11.png',
              month_unit_tc: 'INI-11.png',
              month_unit_en: 'INI-11.png',
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 211,
              y: 451,
              font_array: ["MINI00.png","MINI01.png","MINI02.png","MINI03.png","MINI04.png","MINI05.png","MINI06.png","MINI07.png","MINI08.png","MINI09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'MINI11.png',
              unit_tc: 'MINI11.png',
              unit_en: 'MINI11.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 165,
              y: 415,
              image_array: ["ENERJ-01.png","ENERJ-02.png","ENERJ-03.png","ENERJ-04.png","ENERJ-05.png","ENERJ-06.png","ENERJ-07.png","ENERJ-08.png","ENERJ-09.png","ENERJ-010.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 34,
              hour_startY: 165,
              hour_array: ["G-00.png","G-01.png","G-02.png","G-03.png","G-04.png","G-05.png","G-06.png","G-07.png","G-08.png","G-09.png"],
              hour_zero: 1,
              hour_space: -2,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 206,
              minute_startY: 165,
              minute_array: ["H-00.png","H-01.png","H-02.png","H-03.png","H-04.png","H-05.png","H-06.png","H-07.png","H-08.png","H-09.png"],
              minute_zero: 1,
              minute_space: -2,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 389,
              second_startY: 182,
              second_array: ["MINI00.png","MINI01.png","MINI02.png","MINI03.png","MINI04.png","MINI05.png","MINI06.png","MINI07.png","MINI08.png","MINI09.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'SEC.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 240,
              second_posY: 240,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 381,
              y: 242,
              src: 'ALAEME.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 260,
              year_startY: 99,
              year_sc_array: ["INI-00.png","INI-01.png","INI-02.png","INI-03.png","INI-04.png","INI-05.png","INI-06.png","INI-07.png","INI-08.png","INI-09.png"],
              year_tc_array: ["INI-00.png","INI-01.png","INI-02.png","INI-03.png","INI-04.png","INI-05.png","INI-06.png","INI-07.png","INI-08.png","INI-09.png"],
              year_en_array: ["INI-00.png","INI-01.png","INI-02.png","INI-03.png","INI-04.png","INI-05.png","INI-06.png","INI-07.png","INI-08.png","INI-09.png"],
              year_zero: 1,
              year_space: 0,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 212,
              y: 62,
              week_en: ["J0047.png","J0048.png","J0049.png","J0050.png","J0051.png","J0052.png","J0053.png"],
              week_tc: ["J0047.png","J0048.png","J0049.png","J0050.png","J0051.png","J0052.png","J0053.png"],
              week_sc: ["J0047.png","J0048.png","J0049.png","J0050.png","J0051.png","J0052.png","J0053.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 87,
              day_startY: 99,
              day_sc_array: ["INI-00.png","INI-01.png","INI-02.png","INI-03.png","INI-04.png","INI-05.png","INI-06.png","INI-07.png","INI-08.png","INI-09.png"],
              day_tc_array: ["INI-00.png","INI-01.png","INI-02.png","INI-03.png","INI-04.png","INI-05.png","INI-06.png","INI-07.png","INI-08.png","INI-09.png"],
              day_en_array: ["INI-00.png","INI-01.png","INI-02.png","INI-03.png","INI-04.png","INI-05.png","INI-06.png","INI-07.png","INI-08.png","INI-09.png"],
              day_zero: 1,
              day_space: 0,
              day_unit_sc: 'INI-11.png',
              day_unit_tc: 'INI-11.png',
              day_unit_en: 'INI-11.png',
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 172,
              month_startY: 99,
              month_sc_array: ["INI-00.png","INI-01.png","INI-02.png","INI-03.png","INI-04.png","INI-05.png","INI-06.png","INI-07.png","INI-08.png","INI-09.png"],
              month_tc_array: ["INI-00.png","INI-01.png","INI-02.png","INI-03.png","INI-04.png","INI-05.png","INI-06.png","INI-07.png","INI-08.png","INI-09.png"],
              month_en_array: ["INI-00.png","INI-01.png","INI-02.png","INI-03.png","INI-04.png","INI-05.png","INI-06.png","INI-07.png","INI-08.png","INI-09.png"],
              month_zero: 1,
              month_space: 0,
              month_unit_sc: 'INI-11.png',
              month_unit_tc: 'INI-11.png',
              month_unit_en: 'INI-11.png',
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 34,
              hour_startY: 165,
              hour_array: ["H-00.png","H-01.png","H-02.png","H-03.png","H-04.png","H-05.png","H-06.png","H-07.png","H-08.png","H-09.png"],
              hour_zero: 1,
              hour_space: -2,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 206,
              minute_startY: 165,
              minute_array: ["F-00.png","F-01.png","F-02.png","F-03.png","F-04.png","F-05.png","F-06.png","F-07.png","F-08.png","F-09.png"],
              minute_zero: 1,
              minute_space: -2,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 389,
              second_startY: 182,
              second_array: ["MINI00.png","MINI01.png","MINI02.png","MINI03.png","MINI04.png","MINI05.png","MINI06.png","MINI07.png","MINI08.png","MINI09.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 9,
              // disconneсnt_toast_text: BT OFF,
              // conneсnt_vibrate_type: 9,
              // conneсnt_toast_text: BT ON,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              console.log('checkConnection()');
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  hmUI.showToast({text: "BT OFF"});
                  vibro(9);
                }
                if(status) {
                  hmUI.showToast({text: "BT ON"});
                  vibro(9);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              if (scene != 1) timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 202,
              y: 318,
              w: 80,
              h: 80,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 316,
              y: 317,
              w: 80,
              h: 80,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 188,
              y: 1,
              w: 122,
              h: 60,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 375,
              y: 233,
              w: 60,
              h: 60,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_fatBurning_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 79,
              y: 320,
              w: 80,
              h: 80,
              type: hmUI.data_type.FAT_BURNING,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                checkConnection();
                stopVibro();

              }),
              pause_call: (function () {
                console.log('pause_call()');
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
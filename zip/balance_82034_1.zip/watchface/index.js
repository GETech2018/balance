﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_calorie_icon_img = ''
        let normal_calorie_current_text_img = ''
        let normal_calorie_image_progress_img_level = ''
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_image_img = ''
        let normal_date_img_date_week_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let normal_step_icon_img = ''
        let normal_step_circle_scale = ''
        let normal_step_TextRotate = new Array(5);
        let normal_step_TextRotate_ASCIIARRAY = new Array(10);
        let normal_step_TextRotate_img_width = 18;
        let normal_battery_icon_img = ''
        let normal_battery_circle_scale = ''
        let normal_battery_TextRotate = new Array(3);
        let normal_battery_TextRotate_ASCIIARRAY = new Array(10);
        let normal_battery_TextRotate_img_width = 18;
        let normal_battery_TextRotate_unit = null;
        let normal_battery_TextRotate_unit_width = 29;
        let idle_image_img = ''
        let idle_digital_clock_img_time = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 117,
              y: 366,
              src: 'calories.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 311,
              y: 369,
              font_array: ["tny_dark_00.png","tny_dark_01.png","tny_dark_02.png","tny_dark_03.png","tny_dark_04.png","tny_dark_05.png","tny_dark_06.png","tny_dark_07.png","tny_dark_08.png","tny_dark_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 159,
              y: 378,
              image_array: ["prg00.png","prg01.png","prg02.png","prg03.png","prg04.png","prg05.png","prg06.png","prg07.png","prg08.png","prg09.png"],
              image_length: 10,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 191,
              y: 421,
              src: 'heart.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 236,
              y: 423,
              font_array: ["tny_dark_00.png","tny_dark_01.png","tny_dark_02.png","tny_dark_03.png","tny_dark_04.png","tny_dark_05.png","tny_dark_06.png","tny_dark_07.png","tny_dark_08.png","tny_dark_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 212,
              y: 6,
              image_array: ["weather01.png","weather02.png","weather03.png","weather04.png","weather05.png","weather06.png","weather07.png","weather08.png","weather09.png","weather10.png","weather11.png","weather12.png","weather13.png","weather14.png","weather15.png","weather16.png","weather17.png","weather18.png","weather19.png","weather20.png","weather21.png","weather22.png","weather23.png","weather24.png","weather25.png","weather26.png","weather27.png","weather28.png","weather29.png"],
              image_length: 29,
              shortcut: true,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 233,
              month_startY: 68,
              month_sc_array: ["mnth01.png","mnth02.png","mnth03.png","mnth04.png","mnth05.png","mnth06.png","mnth07.png","mnth08.png","mnth09.png","mnth10.png","mnth11.png","mnth12.png"],
              month_tc_array: ["mnth01.png","mnth02.png","mnth03.png","mnth04.png","mnth05.png","mnth06.png","mnth07.png","mnth08.png","mnth09.png","mnth10.png","mnth11.png","mnth12.png"],
              month_en_array: ["mnth01.png","mnth02.png","mnth03.png","mnth04.png","mnth05.png","mnth06.png","mnth07.png","mnth08.png","mnth09.png","mnth10.png","mnth11.png","mnth12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 169,
              day_startY: 68,
              day_sc_array: ["sml00.png","sml01.png","sml02.png","sml03.png","sml04.png","sml05.png","sml06.png","sml07.png","sml08.png","sml09.png"],
              day_tc_array: ["sml00.png","sml01.png","sml02.png","sml03.png","sml04.png","sml05.png","sml06.png","sml07.png","sml08.png","sml09.png"],
              day_en_array: ["sml00.png","sml01.png","sml02.png","sml03.png","sml04.png","sml05.png","sml06.png","sml07.png","sml08.png","sml09.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 226,
              y: 191,
              src: 'big_colon.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 77,
              y: 150,
              week_en: ["week01.png","week02.png","week03.png","week04.png","week05.png","week06.png","week07.png"],
              week_tc: ["week01.png","week02.png","week03.png","week04.png","week05.png","week06.png","week07.png"],
              week_sc: ["week01.png","week02.png","week03.png","week04.png","week05.png","week06.png","week07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 221,
              am_y: 302,
              am_sc_path: 'am.png',
              am_en_path: 'am.png',
              pm_x: 221,
              pm_y: 302,
              pm_sc_path: 'pm.png',
              pm_en_path: 'pm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 101,
              hour_startY: 191,
              hour_array: ["big00.png","big01.png","big02.png","big03.png","big04.png","big05.png","big06.png","big07.png","big08.png","big09.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.RIGHT,

              minute_startX: 256,
              minute_startY: 191,
              minute_array: ["big00.png","big01.png","big02.png","big03.png","big04.png","big05.png","big06.png","big07.png","big08.png","big09.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 402,
              y: 335,
              src: 'steps.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 240,
              // center_y: 240,
              // start_angle: 115,
              // end_angle: 65,
              // radius: 226,
              // line_width: 7,
              // line_cap: Rounded,
              // color: 0xFF8A8371,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            let screenType = hmSetting.getScreenType();
            normal_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 240,
              center_y: 240,
              start_angle: 115,
              end_angle: 65,
              radius: 223,
              line_width: 7,
              corner_flag: 0,
              color: 0xFF8A8371,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
              scale_call();
            });

            // normal_step_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 440,
              // y: 239,
              // font_array: ["tny_light_00.png","tny_light_01.png","tny_light_02.png","tny_light_03.png","tny_light_04.png","tny_light_05.png","tny_light_06.png","tny_light_07.png","tny_light_08.png","tny_light_09.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: 90,
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_step_TextRotate_ASCIIARRAY[0] = 'tny_light_00.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[1] = 'tny_light_01.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[2] = 'tny_light_02.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[3] = 'tny_light_03.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[4] = 'tny_light_04.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[5] = 'tny_light_05.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[6] = 'tny_light_06.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[7] = 'tny_light_07.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[8] = 'tny_light_08.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[9] = 'tny_light_09.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              normal_step_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 440,
                center_y: 239,
                pos_x: 440,
                pos_y: 239,
                angle: 90,
                src: 'tny_light_00.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_step_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 42,
              y: 335,
              src: 'battery.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 240,
              // center_y: 240,
              // start_angle: 245,
              // end_angle: 295,
              // radius: 226,
              // line_width: 7,
              // line_cap: Rounded,
              // color: 0xFF8A8371,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 240,
              center_y: 240,
              start_angle: 245,
              end_angle: 295,
              radius: 223,
              line_width: 7,
              corner_flag: 0,
              color: 0xFF8A8371,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
              scale_call();
            });

            // normal_battery_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 35,
              // y: 254,
              // font_array: ["tny_light_00.png","tny_light_01.png","tny_light_02.png","tny_light_03.png","tny_light_04.png","tny_light_05.png","tny_light_06.png","tny_light_07.png","tny_light_08.png","tny_light_09.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: 270,
              // unit_en: 'tny_light_pctg.png',
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_battery_TextRotate_ASCIIARRAY[0] = 'tny_light_00.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[1] = 'tny_light_01.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[2] = 'tny_light_02.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[3] = 'tny_light_03.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[4] = 'tny_light_04.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[5] = 'tny_light_05.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[6] = 'tny_light_06.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[7] = 'tny_light_07.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[8] = 'tny_light_08.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[9] = 'tny_light_09.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 3; i++) {
              normal_battery_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 35,
                center_y: 254,
                pos_x: 35,
                pos_y: 254,
                angle: 270,
                src: 'tny_light_00.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_battery_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_battery_TextRotate_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              center_x: 35,
              center_y: 254,
              pos_x: 35,
              pos_y: 254,
              angle: 270,
              src: 'tny_light_pctg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_battery_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block


            console.log('Watch_Face.ScreenAOD');

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 226,
              y: 191,
              src: 'bigaod_colon.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 101,
              hour_startY: 191,
              hour_array: ["bigaod00.png","bigaod01.png","bigaod02.png","bigaod03.png","bigaod04.png","bigaod05.png","bigaod06.png","bigaod07.png","bigaod08.png","bigaod09.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.RIGHT,

              minute_startX: 256,
              minute_startY: 191,
              minute_array: ["bigaod00.png","bigaod01.png","bigaod02.png","bigaod03.png","bigaod04.png","bigaod05.png","bigaod06.png","bigaod07.png","bigaod08.png","bigaod09.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 0,
              y: 146,
              w: 66,
              h: 188,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'spacer.png',
              normal_src: 'spacer.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: "Settings_batteryManagerScreen", native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 178,
              y: 412,
              w: 132,
              h: 53,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'spacer.png',
              normal_src: 'spacer.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'heart_app_Screen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 95,
              y: 187,
              w: 132,
              h: 108,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'spacer.png',
              normal_src: 'spacer.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'AlarmInfoScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 252,
              y: 187,
              w: 132,
              h: 108,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'spacer.png',
              normal_src: 'spacer.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'CountdownAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 198,
              y: 9,
              w: 79,
              h: 49,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'spacer.png',
              normal_src: 'spacer.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'WeatherScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 167,
              y: 63,
              w: 141,
              h: 49,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'spacer.png',
              normal_src: 'spacer.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            //start of ignored block
            function text_update() {
              console.log('text_update()');

              console.log('update text rotate step_STEP');
              let valueStep = step.current;
              let normal_step_rotate_string = parseInt(valueStep).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  normal_step_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueStep != null && valueStep != undefined && isFinite(valueStep) && normal_step_rotate_string.length > 0 && normal_step_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let normal_step_TextRotate_posOffset = normal_step_TextRotate_img_width * normal_step_rotate_string.length;
                  img_offset -= normal_step_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_step_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_step_TextRotate[index].setProperty(hmUI.prop.POS_X, 440 + img_offset);
                      normal_step_TextRotate[index].setProperty(hmUI.prop.SRC, normal_step_TextRotate_ASCIIARRAY[charCode]);
                      normal_step_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_step_TextRotate_img_width;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate battery_BATTERY');
              let valueBattery = battery.current;
              let normal_battery_rotate_string = parseInt(valueBattery).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  normal_battery_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_battery_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
                if (valueBattery != null && valueBattery != undefined && isFinite(valueBattery) && normal_battery_rotate_string.length > 0 && normal_battery_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let normal_battery_TextRotate_posOffset = normal_battery_TextRotate_img_width * normal_battery_rotate_string.length;
                  img_offset -= normal_battery_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_battery_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_battery_TextRotate[index].setProperty(hmUI.prop.POS_X, 35 + img_offset);
                      normal_battery_TextRotate[index].setProperty(hmUI.prop.SRC, normal_battery_TextRotate_ASCIIARRAY[charCode]);
                      normal_battery_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_battery_TextRotate_img_width;
                      index++;
                    };  // end if digit
                  };  // end char of string
                  normal_battery_TextRotate_unit.setProperty(hmUI.prop.POS_X, 35 + img_offset);
                  normal_battery_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite

              };

            };

            //end of ignored block
            function scale_call() {
              console.log('scale_call()');

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_cs_normal_step = progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_step * 100);
                  if (normal_step_circle_scale) {
                    normal_step_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 240,
                      center_y: 240,
                      start_angle: 115,
                      end_angle: 65,
                      radius: 223,
                      line_width: 7,
                      corner_flag: 0,
                      color: 0xFF8A8371,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_cs_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_battery * 100);
                  if (normal_battery_circle_scale) {
                    normal_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 240,
                      center_y: 240,
                      start_angle: 245,
                      end_angle: 295,
                      radius: 223,
                      line_width: 7,
                      corner_flag: 0,
                      color: 0xFF8A8371,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                text_update();
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
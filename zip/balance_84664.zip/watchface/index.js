﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js
		// user_script_end START
		let cc = 0
		// user_script_end END
		
		// Hands START
		let handsnumber = 1
        let total_hands = 3

        function click_HANDS() {
            if(handsnumber==total_hands) {
            handsnumber=1;
                UpdatehandsOne();
                }
            else {
                handsnumber=handsnumber+1;
                if(handsnumber==2) {
                  UpdatehandsTwo();
                }
				if(handsnumber==3) {
                  UpdatehandsThree();
                }
            }
            if(handsnumber==1) hmUI.showToast({text: 'NORMAL SEC'});
            if(handsnumber==2) hmUI.showToast({text: 'SMOOTH SEC'});
			if(handsnumber==3) hmUI.showToast({text: 'NO SECOND'});
        }

        function UpdatehandsOne(){
                normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, true);
        }

        function UpdatehandsTwo(){
                normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.VISIBLE, true);
                normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, false);
        }
		
        function UpdatehandsThree(){
                normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, false);
        }
		// Hands END
		
		// Color START	
		let colornumber_main = 1
        let totalcolors_main = 15
	
		function click_COLOR() {
            if(colornumber_main>=totalcolors_main) {
            colornumber_main=1;
            }
            else {
                colornumber_main=colornumber_main+1;
            }
			
			normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.MORE, {
              second_path: "hand_sec" + parseInt(colornumber_main) + ".png",
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 240,
              second_posY: 240,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			normal_image_img.setProperty(hmUI.prop.SRC, "color" + parseInt(colornumber_main) + ".png"); 
			normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.SRC, "hand_sec" + parseInt(colornumber_main) + ".png");
		}
		// Color END
        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_image_img = ''
        let normal_day_text_font = ''
        let normal_battery_linear_scale = ''
        let normal_battery_linear_scale_pointer_img = ''
        let normal_fat_burning_icon_img = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_analog_clock_pro_second_pointer_img = ''
        let normal_timerUpdateSecSmooth = undefined;
        let lastTime = 0;
        let normal_pai_icon_img = ''
        let idle_background_bg_img = ''
        let idle_battery_linear_scale = ''
        let idle_battery_linear_scale_pointer_img = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_pai_icon_img = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let Button_7 = ''
        let Button_8 = ''
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'color1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function() {
              time_update(true);
            });

            normal_day_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 220,
              y: 352,
              w: 40,
              h: 34,
              text_size: 34,
              char_space: -2,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            if (screenType != hmSetting.screen_type.AOD) {
              normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            normal_battery_linear_scale_pointer_img = hmUI.createWidget(hmUI.widget.IMG);
            // normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 173,
              // start_y: 310,
              // color: 0xFFC0C0C0,
              // pointer: 'pointer.png',
              // lenght: 136,
              // line_width: 0,
              // line_cap: Flat,
              // vertical: False,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_fat_burning_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'top.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hand_hour.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 240,
              hour_posY: 240,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'hand_min.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 240,
              minute_posY: 240,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'hand_sec1.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 240,
              second_posY: 240,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const deviceInfo = hmSetting.getDeviceInfo();
            // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'hand_sec1.png',
              // center_x: 240,
              // center_y: 240,
              // x: 240,
              // y: 240,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 240,
              pos_y: 240 - 240,
              center_x: 240,
              center_y: 240,
              src: 'hand_sec1.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            function startSecAnim(sec, animDuration) {
              const secAnim = {
                anim_steps: [{
                  anim_rate: 'linear',
                  anim_duration: animDuration,
                  anim_from: sec,
                  anim_to: sec + (360*(animDuration*6/1000))/360,
                  anim_key: 'angle',
                }],
                anim_fps: 15,
                anim_auto_start: 1,
                anim_repeat: 0,
                anim_auto_destroy: 1,
              }
              normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANIM, secAnim);
            }
            // normal_analog_clock_pro_smooth_second = hmUI.createWidget(hmUI.widget.SMOOTH_SECOND, {
              // type: 4,
              // fps: 15,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_pai_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'hand_top.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'glow_main.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            if (screenType == hmSetting.screen_type.AOD) {
              idle_battery_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            idle_battery_linear_scale_pointer_img = hmUI.createWidget(hmUI.widget.IMG);
            // idle_battery_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 173,
              // start_y: 310,
              // color: 0xFFC0C0C0,
              // pointer: 'glow_pointer.png',
              // lenght: 136,
              // line_width: 0,
              // line_cap: Flat,
              // vertical: False,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'glow_hand_hour.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 240,
              hour_posY: 240,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'glow_hand_min.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 240,
              minute_posY: 240,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_pai_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'hand_top.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 210,
              y: 210,
              w: 60,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                				click_HANDS();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 210,
              y: 340,
              w: 60,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 210,
              y: 20,
              w: 60,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'StopWatchScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 210,
              y: 400,
              w: 60,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'CountdownAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 20,
              y: 210,
              w: 60,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'WeatherScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 400,
              y: 210,
              w: 60,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'SportListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_7 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 170,
              y: 275,
              w: 140,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PowerSaveHintScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_8 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 170,
              y: 120,
              w: 140,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                				click_COLOR();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            console.log('user_script_end.js');
            // start user_script_end.js
			if (cc ==0 ){
			  normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.VISIBLE, false);
			cc = 1;
			}
            // end user_script_end.js

            //start of ignored block
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              console.log('day font');
              if (updateHour) {
                let normal_dayStr = timeSensor.day.toString();
                normal_dayStr = normal_dayStr.padStart(2, '0');
                normal_day_text_font.setProperty(hmUI.prop.TEXT, normal_dayStr );
              };

            };

            //end of ignored block
            function scale_call() {
              console.log('scale_call()');

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_ls_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_linear_scale
                  // initial parameters
                  let start_x_normal_battery = 173;
                  let start_y_normal_battery = 310;
                  let lenght_ls_normal_battery = 136;
                  let line_width_ls_normal_battery = 0;
                  let color_ls_normal_battery = 0xFFC0C0C0;
                  
                  // calculated parameters
                  let start_x_normal_battery_draw = start_x_normal_battery;
                  let start_y_normal_battery_draw = start_y_normal_battery;
                  lenght_ls_normal_battery = lenght_ls_normal_battery * progress_ls_normal_battery;
                  let lenght_ls_normal_battery_draw = lenght_ls_normal_battery;
                  let line_width_ls_normal_battery_draw = line_width_ls_normal_battery;
                  if (lenght_ls_normal_battery < 0){
                    lenght_ls_normal_battery_draw = -lenght_ls_normal_battery;
                    start_x_normal_battery_draw = start_x_normal_battery - lenght_ls_normal_battery_draw;
                  };
                  
                  normal_battery_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_battery_draw,
                    y: start_y_normal_battery_draw,
                    w: lenght_ls_normal_battery_draw,
                    h: line_width_ls_normal_battery_draw,
                    color: color_ls_normal_battery,
                  });
                  
                  // pointers parameters
                  let pointer_offset_x_ls_normal_battery = 30;
                  let pointer_offset_y_ls_normal_battery = 30;
                  normal_battery_linear_scale_pointer_img.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_battery + lenght_ls_normal_battery - pointer_offset_x_ls_normal_battery,
                    y: start_y_normal_battery_draw + line_width_ls_normal_battery / 2 - pointer_offset_y_ls_normal_battery,
                    src: 'pointer.png',
                    show_level: hmUI.show_level.ONLY_NORMAL,
                  });
                };

                console.log('update scales BATTERY');
                let progress_ls_idle_battery = progressBattery;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_battery_linear_scale
                  // initial parameters
                  let start_x_idle_battery = 173;
                  let start_y_idle_battery = 310;
                  let lenght_ls_idle_battery = 136;
                  let line_width_ls_idle_battery = 0;
                  let color_ls_idle_battery = 0xFFC0C0C0;
                  
                  // calculated parameters
                  let start_x_idle_battery_draw = start_x_idle_battery;
                  let start_y_idle_battery_draw = start_y_idle_battery;
                  lenght_ls_idle_battery = lenght_ls_idle_battery * progress_ls_idle_battery;
                  let lenght_ls_idle_battery_draw = lenght_ls_idle_battery;
                  let line_width_ls_idle_battery_draw = line_width_ls_idle_battery;
                  if (lenght_ls_idle_battery < 0){
                    lenght_ls_idle_battery_draw = -lenght_ls_idle_battery;
                    start_x_idle_battery_draw = start_x_idle_battery - lenght_ls_idle_battery_draw;
                  };
                  
                  idle_battery_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_idle_battery_draw,
                    y: start_y_idle_battery_draw,
                    w: lenght_ls_idle_battery_draw,
                    h: line_width_ls_idle_battery_draw,
                    color: color_ls_idle_battery,
                  });
                  
                  // pointers parameters
                  let pointer_offset_x_ls_idle_battery = 30;
                  let pointer_offset_y_ls_idle_battery = 30;
                  idle_battery_linear_scale_pointer_img.setProperty(hmUI.prop.MORE, {
                    x: start_x_idle_battery + lenght_ls_idle_battery - pointer_offset_x_ls_idle_battery,
                    y: start_y_idle_battery_draw + line_width_ls_idle_battery / 2 - pointer_offset_y_ls_idle_battery,
                    src: 'glow_pointer.png',
                    show_level: hmUI.show_level.ONLY_AOD,
                  });
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                time_update(true, true);
                let secAngle = 0 + (360*6)*(timeSensor.second + ((timeSensor.utc % 1000) / 1000))/360;
                normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, secAngle);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSecSmooth) {
                    let duration = 0;
                    let animDuration = 5000;
                    if (timeSensor.second > 55) animDuration = 1000*(60.1 - (timeSensor.second - (timeSensor.utc % 1000) / 1000));
                    let diffTime = timeSensor.utc - lastTime;
                    if (diffTime < animDuration) duration = animDuration - diffTime;
                    normal_timerUpdateSecSmooth = timer.createTimer(duration, animDuration, (function (option) {
                      lastTime = timeSensor.utc;
                      secAngle = 0 + (360*6)*(timeSensor.second + ((timeSensor.utc % 1000) / 1000))/360;
                      startSecAnim(secAngle, animDuration);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerUpdateSecSmooth) {
                  timer.stopTimer(normal_timerUpdateSecSmooth);
                  normal_timerUpdateSecSmooth = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_pai_weekly_text_img = ''
        let normal_fat_burning_current_text_img = ''
        let normal_frame_animation_1 = ''
        let normal_frame_animation_2 = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_year = ''
        let normal_distance_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg_img = ''
        let idle_pai_weekly_text_img = ''
        let idle_fat_burning_current_text_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_temperature_current_text_img = ''
        let idle_calorie_current_text_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_heart_rate_text_text_img = ''
        let idle_heart_rate_image_progress_img_level = ''
        let idle_battery_text_text_img = ''
        let idle_battery_image_progress_img_level = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_year = ''
        let idle_distance_text_text_img = ''
        let idle_step_current_text_img = ''
        let idle_step_image_progress_img_level = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let normal_step_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'base.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_weekly_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 333,
              y: 86,
              font_array: ["dt_0.png","dt_1.png","dt_2.png","dt_3.png","dt_4.png","dt_5.png","dt_6.png","dt_7.png","dt_8.png","dt_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_fat_burning_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 226,
              y: 86,
              font_array: ["dt_0.png","dt_1.png","dt_2.png","dt_3.png","dt_4.png","dt_5.png","dt_6.png","dt_7.png","dt_8.png","dt_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'min.png',
              unit_tc: 'min.png',
              unit_en: 'min.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.FAT_BURNING,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_frame_animation_1 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
              x: 88,
              y: 128,
              anim_path: "animation",
              anim_ext: "png",
              anim_prefix: "ht",
              anim_fps: 2,
              anim_size: 2,
              repeat_count: 0,
              anim_repeat: true,
              anim_status:hmUI.anim_status.START,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_frame_animation_2 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
              x: 35,
              y: 312,
              anim_path: "animation",
              anim_ext: "png",
              anim_prefix: "bt",
              anim_fps: 4,
              anim_size: 2,
              repeat_count: 0,
              anim_repeat: true,
              anim_status:hmUI.anim_status.START,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 269,
              y: 273,
              image_array: ["w-01.png","w-02.png","w-03.png","w-04.png","w-05.png","w-06.png","w-07.png","w-08.png","w-09.png","w-10.png","w-11.png","w-12.png","w-13.png","w-14.png","w-15.png","w-16.png","w-17.png","w-18.png","w-19.png","w-20.png","w-21.png","w-22.png","w-23.png","w-24.png","w-25.png","w-26.png","w-27.png","w-28.png","w-29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 310,
              y: 276,
              font_array: ["dt_0.png","dt_1.png","dt_2.png","dt_3.png","dt_4.png","dt_5.png","dt_6.png","dt_7.png","dt_8.png","dt_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'tm_0.png',
              unit_tc: 'tm_0.png',
              unit_en: 'tm_0.png',
              imperial_unit_sc: 'tm_1.png',
              imperial_unit_tc: 'tm_1.png',
              imperial_unit_en: 'tm_1.png',
              negative_image: 'minus.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const temperatureUnit = hmSetting.getTemperatureUnit();
            //start of ignored block
            if (temperatureUnit == 1) {
              normal_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
                x: 310,
                y: 276,
                font_array: ["dt_0.png","dt_1.png","dt_2.png","dt_3.png","dt_4.png","dt_5.png","dt_6.png","dt_7.png","dt_8.png","dt_9.png"],
                padding: false,
                h_space: 0,
                unit_sc: 'tm_1.png',
                unit_tc: 'tm_1.png',
                unit_en: 'tm_1.png',
                imperial_unit_sc: 'tm_0.png',
                imperial_unit_tc: 'tm_0.png',
                imperial_unit_en: 'tm_0.png',
                negative_image: 'minus.png',
                align_h: hmUI.align.CENTER_H,
                type: hmUI.data_type.WEATHER_CURRENT,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
            };
            //end of ignored block

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 212,
              y: 368,
              font_array: ["dt_0.png","dt_1.png","dt_2.png","dt_3.png","dt_4.png","dt_5.png","dt_6.png","dt_7.png","dt_8.png","dt_9.png"],
              padding: false,
              h_space: 4,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 266,
              y: 447,
              src: 'bluetooth.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 194,
              y: 447,
              src: 'alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 111,
              y: 124,
              font_array: ["dt_0.png","dt_1.png","dt_2.png","dt_3.png","dt_4.png","dt_5.png","dt_6.png","dt_7.png","dt_8.png","dt_9.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 235,
              y: 122,
              image_array: ["hr_0.png","hr_1.png","hr_2.png","hr_3.png","hr_4.png","hr_5.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 73,
              y: 326,
              font_array: ["dt_0.png","dt_1.png","dt_2.png","dt_3.png","dt_4.png","dt_5.png","dt_6.png","dt_7.png","dt_8.png","dt_9.png"],
              padding: false,
              h_space: 3,
              unit_sc: 'pct.png',
              unit_tc: 'pct.png',
              unit_en: 'pct.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 20,
              y: 149,
              image_array: ["bt_00.png","bt_01.png","bt_02.png","bt_03.png","bt_04.png","bt_05.png","bt_06.png","bt_07.png","bt_08.png","bt_09.png","bt_10.png","bt_11.png","bt_12.png","bt_13.png","bt_14.png","bt_15.png","bt_16.png","bt_17.png","bt_18.png","bt_19.png","bt_20.png","bt_21.png","bt_22.png","bt_23.png","bt_24.png","bt_25.png","bt_26.png","bt_27.png","bt_28.png","bt_29.png","bt_30.png","bt_31.png","bt_32.png","bt_33.png","bt_34.png","bt_35.png","bt_36.png","bt_37.png","bt_38.png","bt_39.png","bt_40.png","bt_41.png","bt_42.png","bt_43.png","bt_44.png","bt_45.png","bt_46.png","bt_47.png","bt_48.png","bt_49.png","bt_50.png","bt_51.png","bt_52.png","bt_53.png","bt_54.png","bt_55.png","bt_56.png","bt_57.png","bt_58.png","bt_59.png","bt_60.png","bt_61.png","bt_62.png","bt_63.png","bt_64.png","bt_65.png","bt_66.png","bt_67.png","bt_68.png","bt_69.png","bt_70.png","bt_71.png","bt_72.png","bt_73.png","bt_74.png","bt_75.png","bt_76.png","bt_77.png","bt_78.png","bt_79.png","bt_80.png","bt_81.png","bt_82.png","bt_83.png","bt_84.png","bt_85.png","bt_86.png","bt_87.png","bt_88.png","bt_89.png","bt_90.png","bt_91.png","bt_92.png","bt_93.png","bt_94.png","bt_95.png","bt_96.png","bt_97.png","bt_98.png","bt_99.png"],
              image_length: 100,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 95,
              y: 275,
              week_en: ["wk_1.png","wk_2.png","wk_3.png","wk_4.png","wk_5.png","wk_6.png","wk_7.png"],
              week_tc: ["wk_1.png","wk_2.png","wk_3.png","wk_4.png","wk_5.png","wk_6.png","wk_7.png"],
              week_sc: ["wk_1.png","wk_2.png","wk_3.png","wk_4.png","wk_5.png","wk_6.png","wk_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 198,
              day_startY: 173,
              day_sc_array: ["dt_0.png","dt_1.png","dt_2.png","dt_3.png","dt_4.png","dt_5.png","dt_6.png","dt_7.png","dt_8.png","dt_9.png"],
              day_tc_array: ["dt_0.png","dt_1.png","dt_2.png","dt_3.png","dt_4.png","dt_5.png","dt_6.png","dt_7.png","dt_8.png","dt_9.png"],
              day_en_array: ["dt_0.png","dt_1.png","dt_2.png","dt_3.png","dt_4.png","dt_5.png","dt_6.png","dt_7.png","dt_8.png","dt_9.png"],
              day_zero: 1,
              day_space: 4,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 112,
              month_startY: 169,
              month_sc_array: ["mo_01.png","mo_02.png","mo_03.png","mo_04.png","mo_05.png","mo_06.png","mo_07.png","mo_08.png","mo_09.png","mo_10.png","mo_11.png","mo_12.png"],
              month_tc_array: ["mo_01.png","mo_02.png","mo_03.png","mo_04.png","mo_05.png","mo_06.png","mo_07.png","mo_08.png","mo_09.png","mo_10.png","mo_11.png","mo_12.png"],
              month_en_array: ["mo_01.png","mo_02.png","mo_03.png","mo_04.png","mo_05.png","mo_06.png","mo_07.png","mo_08.png","mo_09.png","mo_10.png","mo_11.png","mo_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 277,
              year_startY: 173,
              year_sc_array: ["dt_0.png","dt_1.png","dt_2.png","dt_3.png","dt_4.png","dt_5.png","dt_6.png","dt_7.png","dt_8.png","dt_9.png"],
              year_tc_array: ["dt_0.png","dt_1.png","dt_2.png","dt_3.png","dt_4.png","dt_5.png","dt_6.png","dt_7.png","dt_8.png","dt_9.png"],
              year_en_array: ["dt_0.png","dt_1.png","dt_2.png","dt_3.png","dt_4.png","dt_5.png","dt_6.png","dt_7.png","dt_8.png","dt_9.png"],
              year_zero: 1,
              year_space: 2,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 203,
              y: 408,
              font_array: ["dt_0.png","dt_1.png","dt_2.png","dt_3.png","dt_4.png","dt_5.png","dt_6.png","dt_7.png","dt_8.png","dt_9.png"],
              padding: false,
              h_space: 4,
              unit_sc: 'di_0.png',
              unit_tc: 'di_0.png',
              unit_en: 'di_0.png',
              imperial_unit_sc: 'di_1.png',
              imperial_unit_tc: 'di_1.png',
              imperial_unit_en: 'di_1.png',
              dot_image: 'point.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 190,
              y: 326,
              font_array: ["dt_0.png","dt_1.png","dt_2.png","dt_3.png","dt_4.png","dt_5.png","dt_6.png","dt_7.png","dt_8.png","dt_9.png"],
              padding: false,
              h_space: 4,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 424,
              y: 149,
              image_array: ["st_00.png","st_01.png","st_02.png","st_03.png","st_04.png","st_05.png","st_06.png","st_07.png","st_08.png","st_09.png","st_10.png","st_11.png","st_12.png","st_13.png","st_14.png","st_15.png","st_16.png","st_17.png","st_18.png","st_19.png","st_20.png","st_21.png","st_22.png","st_23.png","st_24.png","st_25.png","st_26.png","st_27.png","st_28.png","st_29.png","st_30.png","st_31.png","st_32.png","st_33.png","st_34.png","st_35.png","st_36.png","st_37.png","st_38.png","st_39.png","st_40.png","st_41.png","st_42.png","st_43.png","st_44.png","st_45.png","st_46.png","st_47.png","st_48.png","st_49.png","st_50.png","st_51.png","st_52.png","st_53.png","st_54.png","st_55.png","st_56.png","st_57.png","st_58.png","st_59.png","st_60.png","st_61.png","st_62.png","st_63.png","st_64.png","st_65.png","st_66.png","st_67.png","st_68.png","st_69.png","st_70.png","st_71.png","st_72.png","st_73.png","st_74.png","st_75.png","st_76.png","st_77.png","st_78.png","st_79.png","st_80.png","st_81.png","st_82.png","st_83.png","st_84.png","st_85.png","st_86.png","st_87.png","st_88.png","st_89.png","st_90.png","st_91.png","st_92.png","st_93.png","st_94.png","st_95.png","st_96.png","st_97.png","st_98.png","st_99.png"],
              image_length: 100,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 330,
              am_y: 206,
              am_sc_path: 'ap_0.png',
              am_en_path: 'ap_0.png',
              pm_x: 330,
              pm_y: 206,
              pm_sc_path: 'ap_1.png',
              pm_en_path: 'ap_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 93,
              hour_startY: 209,
              hour_array: ["t_0.png","t_1.png","t_2.png","t_3.png","t_4.png","t_5.png","t_6.png","t_7.png","t_8.png","t_9.png"],
              hour_zero: 0,
              hour_space: 2,
              hour_angle: 0,
              hour_align: hmUI.align.RIGHT,

              minute_startX: 225,
              minute_startY: 209,
              minute_array: ["t_0.png","t_1.png","t_2.png","t_3.png","t_4.png","t_5.png","t_6.png","t_7.png","t_8.png","t_9.png"],
              minute_zero: 1,
              minute_space: 2,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.RIGHT,

              second_startX: 326,
              second_startY: 236,
              second_array: ["s_0.png","s_1.png","s_2.png","s_3.png","s_4.png","s_5.png","s_6.png","s_7.png","s_8.png","s_9.png"],
              second_zero: 1,
              second_space: 2,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'aod_base.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_pai_weekly_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 333,
              y: 86,
              font_array: ["dt_0.png","dt_1.png","dt_2.png","dt_3.png","dt_4.png","dt_5.png","dt_6.png","dt_7.png","dt_8.png","dt_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_fat_burning_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 226,
              y: 86,
              font_array: ["dt_0.png","dt_1.png","dt_2.png","dt_3.png","dt_4.png","dt_5.png","dt_6.png","dt_7.png","dt_8.png","dt_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'min.png',
              unit_tc: 'min.png',
              unit_en: 'min.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.FAT_BURNING,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 269,
              y: 273,
              image_array: ["w-01.png","w-02.png","w-03.png","w-04.png","w-05.png","w-06.png","w-07.png","w-08.png","w-09.png","w-10.png","w-11.png","w-12.png","w-13.png","w-14.png","w-15.png","w-16.png","w-17.png","w-18.png","w-19.png","w-20.png","w-21.png","w-22.png","w-23.png","w-24.png","w-25.png","w-26.png","w-27.png","w-28.png","w-29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 310,
              y: 276,
              font_array: ["dt_0.png","dt_1.png","dt_2.png","dt_3.png","dt_4.png","dt_5.png","dt_6.png","dt_7.png","dt_8.png","dt_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'tm_0.png',
              unit_tc: 'tm_0.png',
              unit_en: 'tm_0.png',
              imperial_unit_sc: 'tm_1.png',
              imperial_unit_tc: 'tm_1.png',
              imperial_unit_en: 'tm_1.png',
              negative_image: 'minus.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            //start of ignored block
            if (temperatureUnit == 1) {
              idle_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
                x: 310,
                y: 276,
                font_array: ["dt_0.png","dt_1.png","dt_2.png","dt_3.png","dt_4.png","dt_5.png","dt_6.png","dt_7.png","dt_8.png","dt_9.png"],
                padding: false,
                h_space: 0,
                unit_sc: 'tm_1.png',
                unit_tc: 'tm_1.png',
                unit_en: 'tm_1.png',
                imperial_unit_sc: 'tm_0.png',
                imperial_unit_tc: 'tm_0.png',
                imperial_unit_en: 'tm_0.png',
                negative_image: 'minus.png',
                align_h: hmUI.align.CENTER_H,
                type: hmUI.data_type.WEATHER_CURRENT,
                show_level: hmUI.show_level.ONLY_AOD,
              });
            };
            //end of ignored block

            idle_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 212,
              y: 368,
              font_array: ["dt_0.png","dt_1.png","dt_2.png","dt_3.png","dt_4.png","dt_5.png","dt_6.png","dt_7.png","dt_8.png","dt_9.png"],
              padding: false,
              h_space: 4,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 266,
              y: 447,
              src: 'aod_bluetooth.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 194,
              y: 447,
              src: 'aod_alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 111,
              y: 124,
              font_array: ["dt_0.png","dt_1.png","dt_2.png","dt_3.png","dt_4.png","dt_5.png","dt_6.png","dt_7.png","dt_8.png","dt_9.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 235,
              y: 122,
              image_array: ["hr_0.png","hr_1.png","hr_2.png","hr_3.png","hr_4.png","hr_5.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 73,
              y: 326,
              font_array: ["dt_0.png","dt_1.png","dt_2.png","dt_3.png","dt_4.png","dt_5.png","dt_6.png","dt_7.png","dt_8.png","dt_9.png"],
              padding: false,
              h_space: 3,
              unit_sc: 'pct.png',
              unit_tc: 'pct.png',
              unit_en: 'pct.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 20,
              y: 149,
              image_array: ["bt_00.png","bt_01.png","bt_02.png","bt_03.png","bt_04.png","bt_05.png","bt_06.png","bt_07.png","bt_08.png","bt_09.png","bt_10.png","bt_11.png","bt_12.png","bt_13.png","bt_14.png","bt_15.png","bt_16.png","bt_17.png","bt_18.png","bt_19.png","bt_20.png","bt_21.png","bt_22.png","bt_23.png","bt_24.png","bt_25.png","bt_26.png","bt_27.png","bt_28.png","bt_29.png","bt_30.png","bt_31.png","bt_32.png","bt_33.png","bt_34.png","bt_35.png","bt_36.png","bt_37.png","bt_38.png","bt_39.png","bt_40.png","bt_41.png","bt_42.png","bt_43.png","bt_44.png","bt_45.png","bt_46.png","bt_47.png","bt_48.png","bt_49.png","bt_50.png","bt_51.png","bt_52.png","bt_53.png","bt_54.png","bt_55.png","bt_56.png","bt_57.png","bt_58.png","bt_59.png","bt_60.png","bt_61.png","bt_62.png","bt_63.png","bt_64.png","bt_65.png","bt_66.png","bt_67.png","bt_68.png","bt_69.png","bt_70.png","bt_71.png","bt_72.png","bt_73.png","bt_74.png","bt_75.png","bt_76.png","bt_77.png","bt_78.png","bt_79.png","bt_80.png","bt_81.png","bt_82.png","bt_83.png","bt_84.png","bt_85.png","bt_86.png","bt_87.png","bt_88.png","bt_89.png","bt_90.png","bt_91.png","bt_92.png","bt_93.png","bt_94.png","bt_95.png","bt_96.png","bt_97.png","bt_98.png","bt_99.png"],
              image_length: 100,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 95,
              y: 275,
              week_en: ["wk_1.png","wk_2.png","wk_3.png","wk_4.png","wk_5.png","wk_6.png","wk_7.png"],
              week_tc: ["wk_1.png","wk_2.png","wk_3.png","wk_4.png","wk_5.png","wk_6.png","wk_7.png"],
              week_sc: ["wk_1.png","wk_2.png","wk_3.png","wk_4.png","wk_5.png","wk_6.png","wk_7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 198,
              day_startY: 173,
              day_sc_array: ["dt_0.png","dt_1.png","dt_2.png","dt_3.png","dt_4.png","dt_5.png","dt_6.png","dt_7.png","dt_8.png","dt_9.png"],
              day_tc_array: ["dt_0.png","dt_1.png","dt_2.png","dt_3.png","dt_4.png","dt_5.png","dt_6.png","dt_7.png","dt_8.png","dt_9.png"],
              day_en_array: ["dt_0.png","dt_1.png","dt_2.png","dt_3.png","dt_4.png","dt_5.png","dt_6.png","dt_7.png","dt_8.png","dt_9.png"],
              day_zero: 1,
              day_space: 4,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 112,
              month_startY: 169,
              month_sc_array: ["mo_01.png","mo_02.png","mo_03.png","mo_04.png","mo_05.png","mo_06.png","mo_07.png","mo_08.png","mo_09.png","mo_10.png","mo_11.png","mo_12.png"],
              month_tc_array: ["mo_01.png","mo_02.png","mo_03.png","mo_04.png","mo_05.png","mo_06.png","mo_07.png","mo_08.png","mo_09.png","mo_10.png","mo_11.png","mo_12.png"],
              month_en_array: ["mo_01.png","mo_02.png","mo_03.png","mo_04.png","mo_05.png","mo_06.png","mo_07.png","mo_08.png","mo_09.png","mo_10.png","mo_11.png","mo_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 277,
              year_startY: 173,
              year_sc_array: ["dt_0.png","dt_1.png","dt_2.png","dt_3.png","dt_4.png","dt_5.png","dt_6.png","dt_7.png","dt_8.png","dt_9.png"],
              year_tc_array: ["dt_0.png","dt_1.png","dt_2.png","dt_3.png","dt_4.png","dt_5.png","dt_6.png","dt_7.png","dt_8.png","dt_9.png"],
              year_en_array: ["dt_0.png","dt_1.png","dt_2.png","dt_3.png","dt_4.png","dt_5.png","dt_6.png","dt_7.png","dt_8.png","dt_9.png"],
              year_zero: 1,
              year_space: 2,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 203,
              y: 408,
              font_array: ["dt_0.png","dt_1.png","dt_2.png","dt_3.png","dt_4.png","dt_5.png","dt_6.png","dt_7.png","dt_8.png","dt_9.png"],
              padding: false,
              h_space: 4,
              unit_sc: 'di_0.png',
              unit_tc: 'di_0.png',
              unit_en: 'di_0.png',
              imperial_unit_sc: 'di_1.png',
              imperial_unit_tc: 'di_1.png',
              imperial_unit_en: 'di_1.png',
              dot_image: 'point.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 190,
              y: 326,
              font_array: ["dt_0.png","dt_1.png","dt_2.png","dt_3.png","dt_4.png","dt_5.png","dt_6.png","dt_7.png","dt_8.png","dt_9.png"],
              padding: false,
              h_space: 4,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 424,
              y: 149,
              image_array: ["st_00.png","st_01.png","st_02.png","st_03.png","st_04.png","st_05.png","st_06.png","st_07.png","st_08.png","st_09.png","st_10.png","st_11.png","st_12.png","st_13.png","st_14.png","st_15.png","st_16.png","st_17.png","st_18.png","st_19.png","st_20.png","st_21.png","st_22.png","st_23.png","st_24.png","st_25.png","st_26.png","st_27.png","st_28.png","st_29.png","st_30.png","st_31.png","st_32.png","st_33.png","st_34.png","st_35.png","st_36.png","st_37.png","st_38.png","st_39.png","st_40.png","st_41.png","st_42.png","st_43.png","st_44.png","st_45.png","st_46.png","st_47.png","st_48.png","st_49.png","st_50.png","st_51.png","st_52.png","st_53.png","st_54.png","st_55.png","st_56.png","st_57.png","st_58.png","st_59.png","st_60.png","st_61.png","st_62.png","st_63.png","st_64.png","st_65.png","st_66.png","st_67.png","st_68.png","st_69.png","st_70.png","st_71.png","st_72.png","st_73.png","st_74.png","st_75.png","st_76.png","st_77.png","st_78.png","st_79.png","st_80.png","st_81.png","st_82.png","st_83.png","st_84.png","st_85.png","st_86.png","st_87.png","st_88.png","st_89.png","st_90.png","st_91.png","st_92.png","st_93.png","st_94.png","st_95.png","st_96.png","st_97.png","st_98.png","st_99.png"],
              image_length: 100,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 330,
              am_y: 206,
              am_sc_path: 'ap_0.png',
              am_en_path: 'ap_0.png',
              pm_x: 330,
              pm_y: 206,
              pm_sc_path: 'ap_1.png',
              pm_en_path: 'ap_1.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 93,
              hour_startY: 209,
              hour_array: ["t_0.png","t_1.png","t_2.png","t_3.png","t_4.png","t_5.png","t_6.png","t_7.png","t_8.png","t_9.png"],
              hour_zero: 0,
              hour_space: 2,
              hour_angle: 0,
              hour_align: hmUI.align.RIGHT,

              minute_startX: 225,
              minute_startY: 209,
              minute_array: ["t_0.png","t_1.png","t_2.png","t_3.png","t_4.png","t_5.png","t_6.png","t_7.png","t_8.png","t_9.png"],
              minute_zero: 1,
              minute_space: 2,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.RIGHT,

              second_startX: 326,
              second_startY: 236,
              second_array: ["s_0.png","s_1.png","s_2.png","s_3.png","s_4.png","s_5.png","s_6.png","s_7.png","s_8.png","s_9.png"],
              second_zero: 1,
              second_space: 2,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 181,
              y: 321,
              w: 227,
              h: 40,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 171,
              y: 116,
              w: 140,
              h: 44,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 265,
              y: 272,
              w: 124,
              h: 40,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 179,
              y: 204,
              w: 120,
              h: 68,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 174,
              y: 419,
              w: 60,
              h: 60,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);
                normal_frame_animation_2.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);

              }),
              pause_call: (function () {
                console.log('pause_call()');
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);
                normal_frame_animation_2.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
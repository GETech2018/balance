﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let editBg = ''
        let normal_image_img = ''
        let normal_heart_rate_text_font = ''
        let normal_battery_current_text_font = ''
        let normal_step_current_text_font = ''
        let normal_sun_high_text_font = ''
        let normal_sun_low_text_font = ''
        let normal_temperature_high_text_font = ''
        let normal_temperature_low_text_font = ''
        let normal_temperature_current_text_font = ''
        let normal_weather_image_progress_img_level = ''
        let normal_altitude_target_text_font = ''
        let normal_calorie_image_progress_img_level = ''
        let normal_dow_text_font = ''
        let normal_DOW_Array = ['星期一', '星期二', '星期三', '星期四', '星期五', '星期六', '星期日', ];
        let normal_month_text_font = ''
        let normal_day_text_font = ''
        let normal_digital_clock_img_time = ''
        let normal$_$lunar$_$lunar_date = ""
        let lunarText = ""
        let lunar_month = ""
        let lunar_day = ""
        let festival = ""
        let idle_background_bg = ''
        let idle_digital_clock_img_time = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_sleep_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_altimeter_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let Button_1 = ''
        let timeSensor = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            // FontName: Alte DIN 1451 Mittelschrift.ttf; FontSize: 31
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 420,
              h: 45,
              text_size: 31,
              char_space: 2,
              line_space: 0,
              font: 'fonts/Alte DIN 1451 Mittelschrift.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: Alte DIN 1451 Mittelschrift.ttf; FontSize: 30
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 397,
              h: 43,
              text_size: 30,
              char_space: 2,
              line_space: 0,
              font: 'fonts/Alte DIN 1451 Mittelschrift.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: Alte DIN 1451 Mittelschrift.ttf; FontSize: 26
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 360,
              h: 37,
              text_size: 26,
              char_space: 2,
              line_space: 0,
              font: 'fonts/Alte DIN 1451 Mittelschrift.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: Alte DIN 1451 Mittelschrift.ttf; FontSize: 34
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 446,
              h: 48,
              text_size: 34,
              char_space: 2,
              line_space: 0,
              font: 'fonts/Alte DIN 1451 Mittelschrift.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.RIGHT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.ScreenNormal');
            editBg = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_BG, {
              edit_id: 1002,
              x: 0,
              y: 0,
              // w: 480,
              // h: 480,
              // AOD_show: False,
              bg_config: [
                { id: 1, preview: 'bg_edit_1_preview.png', path: 'B07.png' },
                { id: 2, preview: 'bg_edit_2_preview.png', path: 'B02.png' },
                { id: 3, preview: 'bg_edit_3_preview.png', path: 'B06.png' },
              ],
              count: 3,
              default_id: 1,
              fg: '.png',
              tips_bg: '.png',
              tips_x: 0,
              tips_y: 0,
              show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 175,
              y: 96,
              src: 'xiegang.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 255,
              y: 361,
              w: 150,
              h: 40,
              text_size: 31,
              char_space: 2,
              line_space: 0,
              font: 'fonts/Alte DIN 1451 Mittelschrift.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            ormal_readiness_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 76,
              y: 402,
              w: 150,
              h: 40,
              text_size: 31,
              char_space: 2,
              line_space: 0,
              font: 'fonts/Alte DIN 1451 Mittelschrift.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.RIGHT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.READINESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            ormal_recovery_time_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 255,
              y: 402,
              w: 150,
              h: 40,
              text_size: 31,
              char_space: 2,
              line_space: 0,
              font: 'fonts/Alte DIN 1451 Mittelschrift.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.RECOVERY_TIME,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal$_$lunar$_$lunar_date = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 116,
              y: 128,
              w: 130,
              h: 38,
              text: "",
              color: 0xFFFFFFFF,
              text_size: 27,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              show_level: hmUI.show_level.ONLY_NORMAL
            });
            timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            function isVoid(value) {
              return value === "INVALID";
            }
            function getLunarText() {
              lunar_month = timeSensor.lunar_month;
              lunar_day = timeSensor.lunar_day;
              festival = timeSensor.getShowFestival();
              festival = isVoid(festival) ? "" : festival;
              if (!isVoid(lunar_month)) {
                if (lunar_month.indexOf("\u95F0") > -1) {
                  lunarText = lunar_month;
                } else if (!isVoid(lunar_day)) {
                  lunarText = lunar_month + lunar_day;
                }
              }
              normal$_$lunar$_$lunar_date.setProperty(hmUI.prop.MORE, {
                text: festival || lunarText 
              });
            }
            hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: function() {
                getLunarText();
              }
            });

            normal_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 76,
              y: 361,
              w: 150,
              h: 40,
              text_size: 31,
              char_space: 2,
              line_space: 0,
              font: 'fonts/Alte DIN 1451 Mittelschrift.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.RIGHT,
              align_v: hmUI.align.TOP,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 76,
              y: 316,
              w: 150,
              h: 40,
              text_size: 31,
              char_space: 2,
              line_space: 0,
              font: 'fonts/Alte DIN 1451 Mittelschrift.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.RIGHT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 154,
              y: 48,
              w: 150,
              h: 40,
              text_size: 30,
              char_space: 2,
              line_space: 0,
              font: 'fonts/Alte DIN 1451 Mittelschrift.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 260,
              y: 48,
              w: 150,
              h: 30,
              text_size: 30,
              char_space: 2,
              line_space: 0,
              font: 'fonts/Alte DIN 1451 Mittelschrift.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 369,
              y: 133,
              w: 150,
              h: 30,
              text_size: 26,
              char_space: 2,
              line_space: 0,
              font: 'fonts/Alte DIN 1451 Mittelschrift.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 201,
              y: 133,
              w: 150,
              h: 35,
              text_size: 26,
              char_space: 2,
              line_space: 0,
              font: 'fonts/Alte DIN 1451 Mittelschrift.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.RIGHT,
              align_v: hmUI.align.TOP,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 273,
              y: 91,
              w: 150,
              h: 40,
              text_size: 31,
              char_space: 2,
              line_space: 0,
              font: 'fonts/Alte DIN 1451 Mittelschrift.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 245,
              y: 80,
              image_array: ["weath00.png","weath01.png","weath010.png","weath011.png","weath012.png","weath013.png","weath014.png","weath015.png","weath016.png","weath017.png","weath018.png","weath019.png","weath02.png","weath020.png","weath021.png","weath022.png","weath023.png","weath024.png","weath025.png","weath026.png","weath027.png","weath028.png","weath03.png","weath04.png","weath05.png","weath06.png","weath07.png","weath08.png","weath09.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altitude_target_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 255,
              y: 316,
              w: 150,
              h: 40,
              text_size: 31,
              char_space: 2,
              line_space: 0,
              font: 'fonts/Alte DIN 1451 Mittelschrift.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.ALTITUDE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 239,
              y: 0,
              image_array: ["cellevel00_(1).png","cellevel00_(2).png","cellevel00_(3).png","cellevel00_(4).png","cellevel00_(5).png","cellevel00_(6).png","cellevel00_(7).png","cellevel00_(8).png","cellevel00_(9).png","cellevel0001.png"],
              image_length: 10,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function() {
              time_update(true);
            });

            normal_dow_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 64,
              y: 92,
              w: 150,
              h: 30,
              text_size: 23,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              // unit_string: 星期一, 星期二, 星期三, 星期四, 星期五, 星期六, 星期日,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_month_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 14,
              y: 91,
              w: 160,
              h: 40,
              text_size: 34,
              char_space: 2,
              line_space: 0,
              font: 'fonts/Alte DIN 1451 Mittelschrift.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.RIGHT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_day_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 193,
              y: 91,
              w: 160,
              h: 40,
              text_size: 34,
              char_space: 2,
              line_space: 0,
              font: 'fonts/Alte DIN 1451 Mittelschrift.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 38,
              hour_startY: 187,
              hour_array: ["houer00_(1).png","houer00_(2).png","houer00_(3).png","houer00_(4).png","houer00_(5).png","houer00_(6).png","houer00_(7).png","houer00_(8).png","houer00_(9).png","houer01.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_unit_sc: 'houer02.png',
              hour_unit_tc: 'houer02.png',
              hour_unit_en: 'houer02.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 182,
              minute_startY: 187,
              minute_array: ["houer00_(1).png","houer00_(2).png","houer00_(3).png","houer00_(4).png","houer00_(5).png","houer00_(6).png","houer00_(7).png","houer00_(8).png","houer00_(9).png","houer01.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 1,
              minute_unit_sc: 'second20.png',
              minute_unit_tc: 'second20.png',
              minute_unit_en: 'second20.png',
              minute_align: hmUI.align.LEFT,

              second_startX: 328,
              second_startY: 187,
              second_array: ["second00.png","second01.png","second02.png","second03.png","second04.png","second05.png","second06.png","second07.png","second08.png","second09.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 110,
              hour_startY: 190,
              hour_array: ["AODTIME_(1).png","AODTIME_(2).png","AODTIME_(3).png","AODTIME_(4).png","AODTIME_(5).png","AODTIME_(6).png","AODTIME_(7).png","AODTIME_(8).png","AODTIME_(9).png","AODTIME09.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_unit_sc: 'AODTIME10.png',
              hour_unit_tc: 'AODTIME10.png',
              hour_unit_en: 'AODTIME10.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 0,
              minute_startY: 0,
              minute_array: ["AODTIME_(1).png","AODTIME_(2).png","AODTIME_(3).png","AODTIME_(4).png","AODTIME_(5).png","AODTIME_(6).png","AODTIME_(7).png","AODTIME_(8).png","AODTIME_(9).png","AODTIME09.png"],
              minute_zero: 0,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 1,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 333,
              y: 192,
              w: 100,
              h: 100,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 196,
              y: 192,
              w: 100,
              h: 100,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sleep_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 123,
              y: 367,
              w: 100,
              h: 30,
              type: hmUI.data_type.SLEEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 50,
              y: 194,
              w: 100,
              h: 100,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_readiness_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 137,
              y: 408,
              w: 100,
              h: 35,
              type: hmUI.data_type.READINESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_recovery_time_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 260,
              y: 408,
              w: 100,
              h: 35,
              type: hmUI.data_type.RECOVERY_TIME,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 164,
              y: 31,
              w: 160,
              h: 50,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 262,
              y: 316,
              w: 160,
              h: 35,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 265,
              y: 93,
              w: 150,
              h: 75,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 259,
              y: 361,
              w: 100,
              h: 35,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 49,
              y: 316,
              w: 180,
              h: 35,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 143,
              y: 89,
              w: 82,
              h: 80,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'gang.png',
              normal_src: 'gang.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            let screenType = hmSetting.getScreenType();
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              console.log('day of week font');
              if (updateHour) {
                let normal_DOW_Str = normal_DOW_Array[timeSensor.week-1];
                normal_dow_text_font.setProperty(hmUI.prop.TEXT, normal_DOW_Str );
              };

              console.log('month font');
              if (updateHour) {
                let normal_monthStr = timeSensor.month.toString();
                normal_month_text_font.setProperty(hmUI.prop.TEXT, normal_monthStr );
              };

              console.log('day font');
              if (updateHour) {
                let normal_dayStr = timeSensor.day.toString();
                normal_dayStr = normal_dayStr.padStart(2, '0');
                normal_day_text_font.setProperty(hmUI.prop.TEXT, normal_dayStr );
              };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                time_update(true, true);
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
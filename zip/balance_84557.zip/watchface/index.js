﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_calorie_current_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_sun_icon_img = ''
        let normal_sun_high_text_font = ''
        let normal_sun_low_text_font = ''
        let normal_city_name_text = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_year = ''
        let normal_date_img_date_month_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_date_img_date_day = ''
        let normal_digital_clock_img_time = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_year = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_day = ''
        let idle_digital_clock_img_time = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            // FontName: Aemstel-Regular.ttf; FontSize: 23; Cache: full
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 27,
              h: 27,
              text_size: 23,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Aemstel-Regular.ttf',
              color: 0xFF000000,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'fond01.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 357,
              y: 354,
              font_array: ["MINI00.png","MINI01.png","MINI02.png","MINI03.png","MINI04.png","MINI05.png","MINI06.png","MINI07.png","MINI08.png","MINI09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 123,
              y: 354,
              font_array: ["MINI00.png","MINI01.png","MINI02.png","MINI03.png","MINI04.png","MINI05.png","MINI06.png","MINI07.png","MINI08.png","MINI09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 232,
              y: 114,
              src: 'SUNSET.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 150,
              y: 107,
              w: 150,
              h: 30,
              text_size: 30,
              char_space: -1,
              line_space: 0,
              color: 0xFFFF8C00,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 230,
              y: 107,
              w: 150,
              h: 30,
              text_size: 30,
              char_space: -1,
              line_space: 0,
              color: 0xFFC78EFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 274,
              y: 154,
              w: 170,
              h: 30,
              text_size: 23,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Aemstel-Regular.ttf',
              color: 0xFF000000,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 189,
              y: 7,
              image_array: ["Weather_1.png","Weather_2.png","Weather_3.png","Weather_4.png","Weather_5.png","Weather_6.png","Weather_7.png","Weather_8.png","Weather_9.png","Weather_10.png","Weather_11.png","Weather_12.png","Weather_13.png","Weather_14.png","Weather_15.png","Weather_16.png","Weather_17.png","Weather_18.png","Weather_19.png","Weather_20.png","Weather_21.png","Weather_22.png","Weather_23.png","Weather_24.png","Weather_25.png","Weather_26.png","Weather_27.png","Weather_28.png","Weather_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 284,
              y: 52,
              font_array: ["MINI00.png","MINI01.png","MINI02.png","MINI03.png","MINI04.png","MINI05.png","MINI06.png","MINI07.png","MINI08.png","MINI09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'MINI14.png',
              unit_tc: 'MINI14.png',
              unit_en: 'MINI14.png',
              negative_image: 'MINI12.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 215,
              y: 392,
              font_array: ["AA00.png","AA01.png","AA02.png","AA03.png","AA04.png","AA05.png","AA06.png","AA07.png","AA08.png","AA09.png"],
              padding: false,
              h_space: -3,
              unit_sc: 'AA11.png',
              unit_tc: 'AA11.png',
              unit_en: 'AA11.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 190,
              y: 351,
              image_array: ["ENER_01.png","ENER_02.png","ENER_03.png","ENER_04.png","ENER_05.png","ENER_06.png","ENER_07.png","ENER_08.png","ENER_09.png","ENER_10.png","ENER_11.png","ENER_12.png","ENER_13.png","ENER_14.png","ENER_15.png","ENER_16.png","ENER_17.png","ENER_18.png","ENER_19.png","ENER_20.png"],
              image_length: 20,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 249,
              y: 191,
              week_en: ["J01.png","J02.png","J03.png","J04.png","J05.png","J06.png","J07.png"],
              week_tc: ["J01.png","J02.png","J03.png","J04.png","J05.png","J06.png","J07.png"],
              week_sc: ["J01.png","J02.png","J03.png","J04.png","J05.png","J06.png","J07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 348,
              year_startY: 282,
              year_sc_array: ["MINI00.png","MINI01.png","MINI02.png","MINI03.png","MINI04.png","MINI05.png","MINI06.png","MINI07.png","MINI08.png","MINI09.png"],
              year_tc_array: ["MINI00.png","MINI01.png","MINI02.png","MINI03.png","MINI04.png","MINI05.png","MINI06.png","MINI07.png","MINI08.png","MINI09.png"],
              year_en_array: ["MINI00.png","MINI01.png","MINI02.png","MINI03.png","MINI04.png","MINI05.png","MINI06.png","MINI07.png","MINI08.png","MINI09.png"],
              year_zero: 1,
              year_space: 6,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 339,
              month_startY: 253,
              month_sc_array: ["r1.png","r10.png","r11.png","r12.png","r2.png","r3.png","r4.png","r5.png","r6.png","r7.png","r8.png","r9.png"],
              month_tc_array: ["r1.png","r10.png","r11.png","r12.png","r2.png","r3.png","r4.png","r5.png","r6.png","r7.png","r8.png","r9.png"],
              month_en_array: ["r1.png","r10.png","r11.png","r12.png","r2.png","r3.png","r4.png","r5.png","r6.png","r7.png","r8.png","r9.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 314,
              y: 410,
              src: 'BT_OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 135,
              y: 411,
              src: 'alarme.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 279,
              day_startY: 255,
              day_sc_array: ["D00.png","D01.png","D02.png","D03.png","D04.png","D05.png","D06.png","D07.png","D08.png","D9.png"],
              day_tc_array: ["D00.png","D01.png","D02.png","D03.png","D04.png","D05.png","D06.png","D07.png","D08.png","D9.png"],
              day_en_array: ["D00.png","D01.png","D02.png","D03.png","D04.png","D05.png","D06.png","D07.png","D08.png","D9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 37,
              hour_startY: 193,
              hour_array: ["H02.png","H03.png","H04.png","H05.png","H06.png","H07.png","H08.png","H09.png","H10.png","H11.png"],
              hour_zero: 1,
              hour_space: -9,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 147,
              minute_startY: 193,
              minute_array: ["G02.png","G03.png","G04.png","G05.png","G06.png","G07.png","G08.png","G09.png","G10.png","G11.png"],
              minute_zero: 1,
              minute_space: -8,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 153,
              y: 310,
              src: 'BT_OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 99,
              y: 313,
              src: 'alarme.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 250,
              y: 199,
              week_en: ["J01.png","J02.png","J03.png","J04.png","J05.png","J06.png","J07.png"],
              week_tc: ["J01.png","J02.png","J03.png","J04.png","J05.png","J06.png","J07.png"],
              week_sc: ["J01.png","J02.png","J03.png","J04.png","J05.png","J06.png","J07.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 350,
              year_startY: 277,
              year_sc_array: ["MINI00.png","MINI01.png","MINI02.png","MINI03.png","MINI04.png","MINI05.png","MINI06.png","MINI07.png","MINI08.png","MINI09.png"],
              year_tc_array: ["MINI00.png","MINI01.png","MINI02.png","MINI03.png","MINI04.png","MINI05.png","MINI06.png","MINI07.png","MINI08.png","MINI09.png"],
              year_en_array: ["MINI00.png","MINI01.png","MINI02.png","MINI03.png","MINI04.png","MINI05.png","MINI06.png","MINI07.png","MINI08.png","MINI09.png"],
              year_zero: 1,
              year_space: 4,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 340,
              month_startY: 245,
              month_sc_array: ["r1.png","r10.png","r11.png","r12.png","r2.png","r3.png","r4.png","r5.png","r6.png","r7.png","r8.png","r9.png"],
              month_tc_array: ["r1.png","r10.png","r11.png","r12.png","r2.png","r3.png","r4.png","r5.png","r6.png","r7.png","r8.png","r9.png"],
              month_en_array: ["r1.png","r10.png","r11.png","r12.png","r2.png","r3.png","r4.png","r5.png","r6.png","r7.png","r8.png","r9.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 274,
              day_startY: 251,
              day_sc_array: ["D00.png","D01.png","D02.png","D03.png","D04.png","D05.png","D06.png","D07.png","D08.png","D9.png"],
              day_tc_array: ["D00.png","D01.png","D02.png","D03.png","D04.png","D05.png","D06.png","D07.png","D08.png","D9.png"],
              day_en_array: ["D00.png","D01.png","D02.png","D03.png","D04.png","D05.png","D06.png","D07.png","D08.png","D9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 37,
              hour_startY: 193,
              hour_array: ["H02.png","H03.png","H04.png","H05.png","H06.png","H07.png","H08.png","H09.png","H10.png","H11.png"],
              hour_zero: 1,
              hour_space: -9,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 147,
              minute_startY: 193,
              minute_array: ["H02.png","H03.png","H04.png","H05.png","H06.png","H07.png","H08.png","H09.png","H10.png","H11.png"],
              minute_zero: 1,
              minute_space: -8,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            function scale_call() {
              console.log('scale_call()');

              console.log('Weather city name');
              let weatherData = weatherSensor.getForecastWeather();
              normal_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
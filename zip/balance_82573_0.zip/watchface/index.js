﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_compass_direction_pointer_img = ''
        let normal_system_lock_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_year = ''
        let normal_calorie_current_text_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_distance_text_text_img = ''
        let normal_date_img_date_week_img = ''
        let normal_step_current_text_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_moon_image_progress_img_level = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_heart_rate_text_text_img = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg_img = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_year = ''
        let idle_battery_text_text_img = ''
        let idle_battery_image_progress_img_level = ''
        let idle_date_img_date_week_img = ''
        let idle_digital_clock_img_time = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'EXPERIMENT.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const deviceInfo = hmSetting.getDeviceInfo();
            
            // normal_compass_custom_pointer_img = hmUI.createWidget(hmUI.widget.CUSTOM_POINTER, {
              // src: 'auto prodotta.png',
              // center_x: 240,
              // center_y: 240,
              // x: 240,
              // y: 240,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.COMPASS,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            //start of ignored block
            normal_compass_direction_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 240,
              pos_y: 240 - 240,
              center_x: 240,
              center_y: 240,
              src: 'auto prodotta.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            //end of ignored block

            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 163,
              y: 40,
              src: 'block.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 0,
              y: 0,
              src: 'bloff.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 298,
              y: 40,
              src: 'sveglia.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 137,
              month_startY: 76,
              month_sc_array: ["ME01.png","ME02.png","ME03.png","ME04.png","ME05.png","ME06.png","ME07.png","ME08.png","ME09.png","ME10.png","ME11.png","ME12.png"],
              month_tc_array: ["ME01.png","ME02.png","ME03.png","ME04.png","ME05.png","ME06.png","ME07.png","ME08.png","ME09.png","ME10.png","ME11.png","ME12.png"],
              month_en_array: ["ME01.png","ME02.png","ME03.png","ME04.png","ME05.png","ME06.png","ME07.png","ME08.png","ME09.png","ME10.png","ME11.png","ME12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 218,
              day_startY: 59,
              day_sc_array: ["G0.png","G1.png","G2.png","G3.png","G4.png","G5.png","G6.png","G7.png","G8.png","G9.png"],
              day_tc_array: ["G0.png","G1.png","G2.png","G3.png","G4.png","G5.png","G6.png","G7.png","G8.png","G9.png"],
              day_en_array: ["G0.png","G1.png","G2.png","G3.png","G4.png","G5.png","G6.png","G7.png","G8.png","G9.png"],
              day_zero: 1,
              day_space: 1,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 288,
              year_startY: 76,
              year_sc_array: ["A0.png","A1.png","A2.png","A3.png","A4.png","A5.png","A6.png","A7.png","A8.png","A9.png"],
              year_tc_array: ["A0.png","A1.png","A2.png","A3.png","A4.png","A5.png","A6.png","A7.png","A8.png","A9.png"],
              year_en_array: ["A0.png","A1.png","A2.png","A3.png","A4.png","A5.png","A6.png","A7.png","A8.png","A9.png"],
              year_zero: 1,
              year_space: 2,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 248,
              y: 404,
              font_array: ["N0.png","N1.png","N2.png","N3.png","N4.png","N5.png","N6.png","N7.png","N8.png","N9.png"],
              padding: false,
              h_space: -1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 34,
              y: 249,
              font_array: ["BAT0.png","BAT1.png","BAT2.png","BAT3.png","BAT4.png","BAT5.png","BAT6.png","BAT7.png","BAT8.png","BAT9.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'PERCBATTERIA.png',
              unit_tc: 'PERCBATTERIA.png',
              unit_en: 'PERCBATTERIA.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 41,
              y: 278,
              image_array: ["BA0.png","BA1.png","BA2.png","BA3.png","BA4.png","BA5.png"],
              image_length: 6,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 277,
              y: 352,
              font_array: ["N0.png","N1.png","N2.png","N3.png","N4.png","N5.png","N6.png","N7.png","N8.png","N9.png"],
              padding: false,
              h_space: -1,
              unit_sc: 'KM.png',
              unit_tc: 'KM.png',
              unit_en: 'KM.png',
              dot_image: 'PUNTO.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 67,
              y: 127,
              week_en: ["se1.png","se2.png","se3.png","se4.png","se5.png","se6.png","se7.png"],
              week_tc: ["se1.png","se2.png","se3.png","se4.png","se5.png","se6.png","se7.png"],
              week_sc: ["se1.png","se2.png","se3.png","se4.png","se5.png","se6.png","se7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 263,
              y: 299,
              font_array: ["N0.png","N1.png","N2.png","N3.png","N4.png","N5.png","N6.png","N7.png","N8.png","N9.png"],
              padding: false,
              h_space: -1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 26,
              y: 154,
              image_array: ["pa1.png","pa2.png","pa3.png","pa4.png","pa5.png","pa6.png"],
              image_length: 6,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 381,
              y: 314,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 355,
              y: 250,
              image_array: ["w_01.png","w_02.png","w_03.png","w_04.png","w_05.png","w_06.png","w_07.png","w_08.png","w_09.png","w_10.png","w_11.png","w_12.png","w_13.png","w_14.png","w_15.png","w_16.png","w_17.png","w_18.png","w_19.png","w_20.png","w_21.png","w_22.png","w_23.png","w_24.png","w_25.png","w_26.png","w_27.png","w_28.png","w_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 399,
              y: 273,
              font_array: ["N0.png","N1.png","N2.png","N3.png","N4.png","N5.png","N6.png","N7.png","N8.png","N9.png"],
              padding: false,
              h_space: -2,
              unit_sc: 'gr.png',
              unit_tc: 'gr.png',
              unit_en: 'gr.png',
              negative_image: 'meno.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 71,
              y: 334,
              image_array: ["CUORE1.png","CUORE2.png","CUORE3.png","CUORE4.png","CUORE5.png","CUORE6.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 123,
              y: 363,
              font_array: ["N0.png","N1.png","N2.png","N3.png","N4.png","N5.png","N6.png","N7.png","N8.png","N9.png"],
              padding: false,
              h_space: -3,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 96,
              hour_startY: 158,
              hour_array: ["O0.png","O1.png","O2.png","O3.png","O4.png","O5.png","O6.png","O7.png","O8.png","O9.png"],
              hour_zero: 1,
              hour_space: 7,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 236,
              minute_startY: 158,
              minute_array: ["M0.png","M1.png","M2.png","M3.png","M4.png","M5.png","M6.png","M7.png","M8.png","M9.png"],
              minute_zero: 1,
              minute_space: 7,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 361,
              second_startY: 160,
              second_array: ["SS0.png","SS1.png","SS2.png","SS3.png","SS4.png","SS5.png","SS6.png","SS7.png","SS8.png","SS9.png"],
              second_zero: 1,
              second_space: 5,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'aod.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 137,
              month_startY: 76,
              month_sc_array: ["ME01.png","ME02.png","ME03.png","ME04.png","ME05.png","ME06.png","ME07.png","ME08.png","ME09.png","ME10.png","ME11.png","ME12.png"],
              month_tc_array: ["ME01.png","ME02.png","ME03.png","ME04.png","ME05.png","ME06.png","ME07.png","ME08.png","ME09.png","ME10.png","ME11.png","ME12.png"],
              month_en_array: ["ME01.png","ME02.png","ME03.png","ME04.png","ME05.png","ME06.png","ME07.png","ME08.png","ME09.png","ME10.png","ME11.png","ME12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 218,
              day_startY: 59,
              day_sc_array: ["G0.png","G1.png","G2.png","G3.png","G4.png","G5.png","G6.png","G7.png","G8.png","G9.png"],
              day_tc_array: ["G0.png","G1.png","G2.png","G3.png","G4.png","G5.png","G6.png","G7.png","G8.png","G9.png"],
              day_en_array: ["G0.png","G1.png","G2.png","G3.png","G4.png","G5.png","G6.png","G7.png","G8.png","G9.png"],
              day_zero: 1,
              day_space: 1,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 288,
              year_startY: 76,
              year_sc_array: ["A0.png","A1.png","A2.png","A3.png","A4.png","A5.png","A6.png","A7.png","A8.png","A9.png"],
              year_tc_array: ["A0.png","A1.png","A2.png","A3.png","A4.png","A5.png","A6.png","A7.png","A8.png","A9.png"],
              year_en_array: ["A0.png","A1.png","A2.png","A3.png","A4.png","A5.png","A6.png","A7.png","A8.png","A9.png"],
              year_zero: 1,
              year_space: 2,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 34,
              y: 249,
              font_array: ["BAT0.png","BAT1.png","BAT2.png","BAT3.png","BAT4.png","BAT5.png","BAT6.png","BAT7.png","BAT8.png","BAT9.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'PERCBATTERIA.png',
              unit_tc: 'PERCBATTERIA.png',
              unit_en: 'PERCBATTERIA.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 41,
              y: 278,
              image_array: ["BA0.png","BA1.png","BA2.png","BA3.png","BA4.png","BA5.png"],
              image_length: 6,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 67,
              y: 127,
              week_en: ["se1.png","se2.png","se3.png","se4.png","se5.png","se6.png","se7.png"],
              week_tc: ["se1.png","se2.png","se3.png","se4.png","se5.png","se6.png","se7.png"],
              week_sc: ["se1.png","se2.png","se3.png","se4.png","se5.png","se6.png","se7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 96,
              hour_startY: 158,
              hour_array: ["O0.png","O1.png","O2.png","O3.png","O4.png","O5.png","O6.png","O7.png","O8.png","O9.png"],
              hour_zero: 1,
              hour_space: 7,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 236,
              minute_startY: 158,
              minute_array: ["M0.png","M1.png","M2.png","M3.png","M4.png","M5.png","M6.png","M7.png","M8.png","M9.png"],
              minute_zero: 1,
              minute_space: 7,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 361,
              second_startY: 160,
              second_array: ["SS0.png","SS1.png","SS2.png","SS3.png","SS4.png","SS5.png","SS6.png","SS7.png","SS8.png","SS9.png"],
              second_zero: 1,
              second_space: 5,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            let screenType = hmSetting.getScreenType();
            //start of ignored block
            console.log('compass_update()');
            if (screenType == hmSetting.screen_type.WATCHFACE){
              compass = hmSensor.createSensor(hmSensor.id.COMPASS);
              compass.start();

              if (compass.direction_angle && compass.direction  && compass.direction_angle != 'INVALID') { // initial data
                // Compass Pointer
                let compass_direction_angle = parseInt(compass.direction_angle);
                normal_compass_direction_pointer_img.setProperty(hmUI.prop.ANGLE, -compass_direction_angle);

              } else { // error data
                normal_compass_direction_pointer_img.setProperty(hmUI.prop.ANGLE, 0);

              }

              compass.addEventListener(hmSensor.event.CHANGE, function (compass_res) { // change values when changing direction

                if (compass_res.calibration_status) {
                  // Compass Pointer
                  let compass_direction_angle = parseInt(compass_res.direction_angle);
                  normal_compass_direction_pointer_img.setProperty(hmUI.prop.ANGLE, -compass_direction_angle);

                } else { // error data
                  normal_compass_direction_pointer_img.setProperty(hmUI.prop.ANGLE, 0);

                }

              }); // Listener end

            };
            //end of ignored block

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                if (compass && screenType == hmSetting.screen_type.WATCHFACE) compass.start();

              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (compass) compass.stop();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
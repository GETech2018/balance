/*
** Facemaker bundle tool v0.0.3
* *huamiOS watchface js version v4.4.0.1
* *Copyright © Huami. All Rights Reserved
*/


try {
	(() => {
		var __$$app$$__ = __$$hmAppManager$$__.currentApp;
		var __$$module$$__ = __$$app$$__.current;

		//drink is a name,can modify
		var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

		'use strict';

		//dynamic modify start
		let normal_img0 = '';
		let normal_img1 = '';
		let normal_img2 = '';
		let normal_img3 = '';
		let normal_img4 = '';
		let normal_img5 = '';
		let normal_img6 = '';
		let normal_img7 = '';
		let normal_img8 = '';
		let normal_img9 = '';
		let normal_img10 = '';
		let normal_img11 = '';
		let normal_img12 = '';
		let normal_img13 = '';
		let normal_calories_imagecombo15 = '';
		let normal_distance_imagecombo17 = '';
		let normal_heart_current_imagecombo19 = '';
		let normal_heart_min_imagecombo20 = new Array(3);
		let normal_heart_min_imagecombo20_padding = false;
		let normal_heart_min_imagecombo20_array = ['0038.png','0039.png','0040.png','0041.png','0042.png','0043.png','0044.png','0045.png','0046.png','0047.png','0048.png'];
		let normal_heart_max_imagecombo21 = new Array(3);
		let normal_heart_max_imagecombo21_padding = false;
		let normal_heart_max_imagecombo21_array = ['0038.png','0039.png','0040.png','0041.png','0042.png','0043.png','0044.png','0045.png','0046.png','0047.png','0048.png'];
		let normal_img22 = '';
		let normal_steps_imagecombo24 = '';
		let normal_fat_burning_imagecombo26 = new Array(3);
		let normal_fat_burning_imagecombo26_padding = false;
		let normal_fat_burning_imagecombo26_array = ['0027.png','0028.png','0029.png','0030.png','0031.png','0032.png','0033.png','0034.png','0035.png','0036.png'];
		let normal_stand_imagecombo28 = '';
		let normal_stress_imagecombo30 = '';
		let normal_blood_oxygen_imagecombo32 = '';
		let normal_sleep_imagecombo34 = new Array(5);
		let normal_sleep_imagecombo34_padding = true;
		let normal_sleep_imagecombo34_array = ['0050.png','0051.png','0052.png','0053.png','0054.png','0055.png','0056.png','0057.png','0058.png','0059.png','0060.png'];
		let normal_weather_imageset36 = '';
		let normal_temperature_current_imagecombo37 = '';
		let normal_temperature_low_imagecombo38 = '';
		let normal_temperature_high_imagecombo39 = '';
		let normal_img40 = '';
		let normal_airpressure_imagecombo42 = '';
		let normal_battery_imagecombo44 = '';
		let normal_battery_progress45 = '';
		let normal_hour_imagecombo47 = '';
		let normal_minute_imagecombo48 = '';
		let normal_second_imagecombo49 = '';
		let normal_img50 = '';
		let normal_week_imageset52 = '';
		let normal_month_imageset53 = '';
		let normal_date_imagecombo54 = '';
		let normal_moon_phase_imageset55 = '';
		let normal_sunrise_hours_high_imageset57 = '';
		let normal_sunrise_hours_high_imageset57_array = ['0173.png','0174.png','0175.png'];
		let normal_sunrise_hours_low_imageset58 = '';
		let normal_sunrise_hours_low_imageset58_array = ['0173.png','0174.png','0175.png','0176.png','0177.png','0178.png','0179.png','0180.png','0181.png','0182.png'];
		let normal_sunrise_minutes_high_imageset59 = '';
		let normal_sunrise_minutes_high_imageset59_array = ['0173.png','0174.png','0175.png','0176.png','0177.png','0178.png'];
		let normal_sunrise_minutes_low_imageset60 = '';
		let normal_sunrise_minutes_low_imageset60_array = ['0173.png','0174.png','0175.png','0176.png','0177.png','0178.png','0179.png','0180.png','0181.png','0182.png'];
		let normal_sunset_hours_high_imageset61 = '';
		let normal_sunset_hours_high_imageset61_array = ['0173.png','0174.png','0175.png'];
		let normal_sunset_hours_low_imageset62 = '';
		let normal_sunset_hours_low_imageset62_array = ['0173.png','0174.png','0175.png','0176.png','0177.png','0178.png','0179.png','0180.png','0181.png','0182.png'];
		let normal_sunset_minutes_high_imageset63 = '';
		let normal_sunset_minutes_high_imageset63_array = ['0173.png','0174.png','0175.png','0176.png','0177.png','0178.png'];
		let normal_sunset_minutes_low_imageset64 = '';
		let normal_sunset_minutes_low_imageset64_array = ['0173.png','0174.png','0175.png','0176.png','0177.png','0178.png','0179.png','0180.png','0181.png','0182.png'];
		let normal_img65 = '';
		let normal_img66 = '';
		let normal_bt_status68 = '';
		let normal_activities_shortcut71 = '';
		let normal_calories_shortcut72 = '';
		let normal_heart_shortcut73 = '';
		let normal_sleep_shortcut74 = '';
		let normal_stands_shortcut75 = '';
		let normal_spo2_shortcut76 = '';
		let normal_steps_shortcut77 = '';
		let normal_stress_shortcut78 = '';
		let normal_alarm_shortcut79 = '';
		let normal_calendar_shortcut80 = '';
		let normal_countdown_shortcut81 = '';
		let normal_sun_shortcut82 = '';
		let normal_weather_shortcut83 = '';
		let idle_hour_imagecombo85 = '';
		let idle_minute_imagecombo86 = '';
		let idle_img87 = '';
		let idle_week_imageset89 = '';
		let idle_month_imageset90 = '';
		let idle_date_imagecombo91 = '';
		let idle_moon_phase_imageset92 = '';
		//dynamic modify end

		//not required
		const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

		__$$module$$__.module = DeviceRuntimeCore.WatchFace({
			init_view() {

				const batterySensor = hmSensor.createSensor(hmSensor.id.BATTERY);
				const heartSensor = hmSensor.createSensor(hmSensor.id.HEART);
				const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);
				const fat_burningSensor = hmSensor.createSensor(hmSensor.id.FAT_BURRING);
				const sleepSensor = hmSensor.createSensor(hmSensor.id.SLEEP);
				let screenType = hmSetting.getScreenType();

				normal_img0 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					src: '0002.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img1 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 54,
					y: 303,
					w: 41,
					h: 18,
					src: '0003.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img2 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 137,
					y: 303,
					w: 40,
					h: 18,
					src: '0004.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img3 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 208,
					y: 303,
					w: 66,
					h: 18,
					src: '0005.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img4 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 295,
					y: 303,
					w: 58,
					h: 18,
					src: '0006.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img5 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 373,
					y: 303,
					w: 71,
					h: 18,
					src: '0007.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img6 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 109,
					y: 408,
					w: 49,
					h: 17,
					src: '0008.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img7 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 210,
					y: 408,
					w: 60,
					h: 17,
					src: '0009.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img8 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 301,
					y: 108,
					w: 62,
					h: 18,
					src: '0010.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img9 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 49,
					y: 143,
					w: 42,
					h: 18,
					src: '0011.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img10 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 125,
					y: 143,
					w: 60,
					h: 18,
					src: '0012.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img11 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 212,
					y: 143,
					w: 66,
					h: 18,
					src: '0013.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img12 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 301,
					y: 137,
					w: 46,
					h: 18,
					src: '0014.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img13 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 75,
					y: 97,
					w: 169,
					h: 36,
					src: '0015.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_calories_imagecombo15 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 207,
					y: 330,
					font_array: ["0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png","0023.png","0024.png","0025.png"],
					padding: false,
					h_space: -2,
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.CAL,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_distance_imagecombo17 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 124,
					y: 330,
					font_array: ["0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png","0023.png","0024.png","0025.png"],
					padding: false,
					h_space: -2,
					dot_image: '0026.png',
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.DISTANCE,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_heart_current_imagecombo19 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 174,
					y: 438,
					font_array: ["0027.png","0028.png","0029.png","0030.png","0031.png","0032.png","0033.png","0034.png","0035.png","0036.png"],
					padding: false,
					h_space: -3,
					invalid_image: '0037.png',
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.HEART,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				for (let i = 0; i < normal_heart_min_imagecombo20.length; i++) {
					normal_heart_min_imagecombo20[i] = hmUI.createWidget(hmUI.widget.IMG, {
						x: 227 + i * 15,
						y: 441,
						w: 15,
						h: 26,
						enable: false,
						show_level: hmUI.show_level.ONLY_NORMAL,
					})

				}

				for (let i = 0; i < normal_heart_max_imagecombo21.length; i++) {
					normal_heart_max_imagecombo21[i] = hmUI.createWidget(hmUI.widget.IMG, {
						x: 273 + i * 15,
						y: 441,
						w: 15,
						h: 26,
						enable: false,
						show_level: hmUI.show_level.ONLY_NORMAL,
					})

				}

				normal_img22 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 263,
					y: 442,
					w: 12,
					h: 26,
					src: '0049.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_steps_imagecombo24 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 36,
					y: 330,
					font_array: ["0050.png","0051.png","0052.png","0053.png","0054.png","0055.png","0056.png","0057.png","0058.png","0059.png"],
					padding: false,
					h_space: -3,
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.STEP,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				for (let i = 0; i < normal_fat_burning_imagecombo26.length; i++) {
					normal_fat_burning_imagecombo26[i] = hmUI.createWidget(hmUI.widget.IMG, {
						x: 296 + i * 18,
						y: 330,
						w: 18,
						h: 33,
						enable: false,
						show_level: hmUI.show_level.ONLY_NORMAL,
					})

				}

				normal_stand_imagecombo28 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 381,
					y: 330,
					font_array: ["0027.png","0028.png","0029.png","0030.png","0031.png","0032.png","0033.png","0034.png","0035.png","0036.png"],
					padding: false,
					h_space: -3,
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.STAND,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_stress_imagecombo30 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 109,
					y: 373,
					font_array: ["0027.png","0028.png","0029.png","0030.png","0031.png","0032.png","0033.png","0034.png","0035.png","0036.png"],
					padding: false,
					h_space: -3,
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.STRESS,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_blood_oxygen_imagecombo32 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 354,
					y: 373,
					font_array: ["0027.png","0028.png","0029.png","0030.png","0031.png","0032.png","0033.png","0034.png","0035.png","0036.png"],
					padding: false,
					h_space: -3,
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.SPO2,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				for (let i = 0; i < normal_sleep_imagecombo34.length; i++) {
					normal_sleep_imagecombo34[i] = hmUI.createWidget(hmUI.widget.IMG, {
						x: 191 + i * 18,
						y: 373,
						w: 18,
						h: 33,
						enable: false,
						show_level: hmUI.show_level.ONLY_NORMAL,
					})

				}

				normal_weather_imageset36 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
					x: 92,
					y: 43,
					image_array: ["0061.png","0062.png","0063.png","0064.png","0065.png","0066.png","0067.png","0068.png","0069.png","0070.png","0071.png","0072.png","0073.png","0074.png","0075.png","0076.png","0077.png","0078.png","0079.png","0080.png","0081.png","0082.png","0083.png","0084.png","0085.png","0086.png","0087.png","0088.png","0089.png"],
					image_length: 29,
					type: hmUI.data_type.WEATHER_CURRENT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_temperature_current_imagecombo37 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 128,
					y: 51,
					font_array: ["0090.png","0091.png","0092.png","0093.png","0094.png","0095.png","0096.png","0097.png","0098.png","0099.png"],
					padding: false,
					h_space: -3,
					unit_sc: ["0101.png"],
					unit_tc: ["0101.png"],
					unit_en: ["0101.png"],
					negative_image: ["0100.png"],
					invalid_image: ["0100.png"],
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.WEATHER_CURRENT,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_temperature_low_imagecombo38 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 185,
					y: 51,
					font_array: ["0090.png","0091.png","0092.png","0093.png","0094.png","0095.png","0096.png","0097.png","0098.png","0099.png"],
					padding: false,
					h_space: -3,
					unit_sc: ["0101.png"],
					unit_tc: ["0101.png"],
					unit_en: ["0101.png"],
					negative_image: ["0100.png"],
					invalid_image: ["0100.png"],
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.WEATHER_LOW,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_temperature_high_imagecombo39 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 241,
					y: 51,
					font_array: ["0090.png","0091.png","0092.png","0093.png","0094.png","0095.png","0096.png","0097.png","0098.png","0099.png"],
					padding: false,
					h_space: -3,
					unit_sc: ["0101.png"],
					unit_tc: ["0101.png"],
					unit_en: ["0101.png"],
					negative_image: ["0100.png"],
					invalid_image: ["0100.png"],
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.WEATHER_HIGH,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img40 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 238,
					y: 51,
					w: 14,
					h: 33,
					src: '0102.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_airpressure_imagecombo42 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 325,
					y: 51,
					font_array: ["0090.png","0091.png","0092.png","0093.png","0094.png","0095.png","0096.png","0097.png","0098.png","0099.png"],
					padding: false,
					h_space: -3,
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.ALTIMETER,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_battery_imagecombo44 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 222,
					y: 13,
					font_array: ["0103.png","0104.png","0105.png","0106.png","0107.png","0108.png","0109.png","0110.png","0111.png","0112.png"],
					padding: false,
					h_space: -3,
					unit_sc: '0113.png',
					unit_tc: '0113.png',
					unit_en: '0113.png',
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.BATTERY,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_battery_progress45 = hmUI.createWidget(hmUI.widget.IMG, {
					w: 27,
					h: 15,
					x: 174,
					y: 18,
					src: '0114.png',
					auto_scale: false,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});
				normal_hour_imagecombo47 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					hour_startX: 16,
					hour_startY: 163,
					hour_array: ["0115.png","0116.png","0117.png","0118.png","0119.png","0120.png","0121.png","0122.png","0123.png","0124.png"],
					hour_zero: true,
					hour_space: 0,
					hour_align: hmUI.align.CENTER_H,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_minute_imagecombo48 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					minute_startX: 146,
					minute_startY: 163,
					minute_array: ["0115.png","0116.png","0117.png","0118.png","0119.png","0120.png","0121.png","0122.png","0123.png","0124.png"],
					minute_zero: true,
					minute_space: 0,
					minute_align: hmUI.align.CENTER_H,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_second_imagecombo49 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					second_startX: 264,
					second_startY: 223,
					second_array: ["0125.png","0126.png","0127.png","0128.png","0129.png","0130.png","0131.png","0132.png","0133.png","0134.png"],
					second_zero: true,
					second_space: -4,
					second_align: hmUI.align.CENTER_H,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img50 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 124,
					y: 180,
					w: 33,
					h: 94,
					src: '0135.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_week_imageset52 = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
					x: 338,
					y: 209,
					week_en: ["0136.png","0137.png","0138.png","0139.png","0140.png","0141.png","0142.png"],
					week_tc: ["0136.png","0137.png","0138.png","0139.png","0140.png","0141.png","0142.png"],
					week_sc: ["0136.png","0137.png","0138.png","0139.png","0140.png","0141.png","0142.png"],
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_month_imageset53 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
					month_startX: 385,
					month_startY: 177,
					month_sc_array: ["0143.png","0144.png","0145.png","0146.png","0147.png","0148.png","0149.png","0150.png","0151.png","0152.png","0153.png","0154.png"],
					month_tc_array: ["0143.png","0144.png","0145.png","0146.png","0147.png","0148.png","0149.png","0150.png","0151.png","0152.png","0153.png","0154.png"],
					month_en_array: ["0143.png","0144.png","0145.png","0146.png","0147.png","0148.png","0149.png","0150.png","0151.png","0152.png","0153.png","0154.png"],
					month_is_character: true,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_date_imagecombo54 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
					day_startX: 352,
					day_startY: 176,
					day_sc_array: ["0155.png","0156.png","0157.png","0158.png","0159.png","0160.png","0161.png","0162.png","0163.png","0164.png"],
					day_tc_array: ["0155.png","0156.png","0157.png","0158.png","0159.png","0160.png","0161.png","0162.png","0163.png","0164.png"],
					day_en_array: ["0155.png","0156.png","0157.png","0158.png","0159.png","0160.png","0161.png","0162.png","0163.png","0164.png"],
					day_zero: true,
					day_space: -11,
					day_align: hmUI.align.CENTER_H,
					day_is_character: false,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_moon_phase_imageset55 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
					x: 334,
					y: 239,
					image_array: ["0165.png","0166.png","0167.png","0168.png","0169.png","0170.png","0171.png","0172.png"],
					image_length: 8,
					type: hmUI.data_type.MOON,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_sunrise_hours_high_imageset57 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 369,
					y: 101,
					w: 369,
					h: 101,
					src: '0175.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_sunrise_hours_low_imageset58 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 381,
					y: 101,
					w: 381,
					h: 101,
					src: '0182.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_sunrise_minutes_high_imageset59 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 398,
					y: 101,
					w: 398,
					h: 101,
					src: '0178.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_sunrise_minutes_low_imageset60 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 410,
					y: 101,
					w: 410,
					h: 101,
					src: '0182.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_sunset_hours_high_imageset61 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 369,
					y: 130,
					w: 369,
					h: 130,
					src: '0175.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_sunset_hours_low_imageset62 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 381,
					y: 130,
					w: 381,
					h: 130,
					src: '0182.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_sunset_minutes_high_imageset63 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 398,
					y: 130,
					w: 398,
					h: 130,
					src: '0178.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_sunset_minutes_low_imageset64 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 410,
					y: 130,
					w: 410,
					h: 130,
					src: '0182.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_img65 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 393,
					y: 99,
					w: 8,
					h: 26,
					src: '0183.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img66 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 393,
					y: 128,
					w: 8,
					h: 26,
					src: '0183.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_bt_status68 = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
					x: 268,
					y: 181,
					w: 40,
					h: 40,
					type: hmUI.system_status.DISCONNECT,
					src: '0184.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_activities_shortcut71 = hmUI.createWidget(hmUI.widget.BUTTON, {
					x: 289,
					y: 289,
					w: 70,
					h: 70,
					text: '',
					normal_src: '',
					press_src: '',
					click_func: () => {
						hmApp.startApp({ url: 'SportListScreen', native: true });
					},
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_calories_shortcut72 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 205,
					y: 301,
					w: 59,
					h: 59,
					src: '',
					type: hmUI.data_type.CAL,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_heart_shortcut73 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 193,
					y: 436,
					w: 100,
					h: 40,
					src: '',
					type: hmUI.data_type.HEART,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_sleep_shortcut74 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 193,
					y: 374,
					w: 100,
					h: 47,
					src: '',
					type: hmUI.data_type.SLEEP,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_stands_shortcut75 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 373,
					y: 296,
					w: 61,
					h: 61,
					src: '',
					type: hmUI.data_type.STAND,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_spo2_shortcut76 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 313,
					y: 373,
					w: 100,
					h: 46,
					src: '',
					type: hmUI.data_type.SPO2,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_steps_shortcut77 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 61,
					y: 301,
					w: 100,
					h: 58,
					src: '',
					type: hmUI.data_type.STEP,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_stress_shortcut78 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 61,
					y: 373,
					w: 100,
					h: 47,
					src: '',
					type: hmUI.data_type.STRESS,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_alarm_shortcut79 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 25,
					y: 181,
					w: 100,
					h: 100,
					src: '',
					type: hmUI.data_type.ALARM_CLOCK,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_calendar_shortcut80 = hmUI.createWidget(hmUI.widget.BUTTON, {
					x: 337,
					y: 181,
					w: 100,
					h: 100,
					text: '',
					normal_src: '',
					press_src: '',
					click_func: () => {
						hmApp.startApp({ url: 'ScheduleCalScreen', native: true });
					},
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_countdown_shortcut81 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 156,
					y: 173,
					w: 100,
					h: 100,
					src: '',
					type: hmUI.data_type.COUNT_DOWN,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_sun_shortcut82 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 313,
					y: 97,
					w: 100,
					h: 54,
					src: '',
					type: hmUI.data_type.SUN_CURRENT,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_weather_shortcut83 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 133,
					y: 38,
					w: 146,
					h: 45,
					src: '',
					type: hmUI.data_type.WEATHER_CURRENT,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				idle_hour_imagecombo85 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					hour_startX: 16,
					hour_startY: 163,
					hour_array: ["0115.png","0116.png","0117.png","0118.png","0119.png","0120.png","0121.png","0122.png","0123.png","0124.png"],
					hour_zero: true,
					hour_space: 0,
					hour_align: hmUI.align.CENTER_H,
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_minute_imagecombo86 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					minute_startX: 146,
					minute_startY: 163,
					minute_array: ["0115.png","0116.png","0117.png","0118.png","0119.png","0120.png","0121.png","0122.png","0123.png","0124.png"],
					minute_zero: true,
					minute_space: 0,
					minute_align: hmUI.align.CENTER_H,
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_img87 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 124,
					y: 180,
					w: 33,
					h: 94,
					src: '0135.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_week_imageset89 = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
					x: 338,
					y: 209,
					week_en: ["0136.png","0137.png","0138.png","0139.png","0140.png","0141.png","0142.png"],
					week_tc: ["0136.png","0137.png","0138.png","0139.png","0140.png","0141.png","0142.png"],
					week_sc: ["0136.png","0137.png","0138.png","0139.png","0140.png","0141.png","0142.png"],
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_month_imageset90 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
					month_startX: 385,
					month_startY: 177,
					month_sc_array: ["0143.png","0144.png","0145.png","0146.png","0147.png","0148.png","0149.png","0150.png","0151.png","0152.png","0153.png","0154.png"],
					month_tc_array: ["0143.png","0144.png","0145.png","0146.png","0147.png","0148.png","0149.png","0150.png","0151.png","0152.png","0153.png","0154.png"],
					month_en_array: ["0143.png","0144.png","0145.png","0146.png","0147.png","0148.png","0149.png","0150.png","0151.png","0152.png","0153.png","0154.png"],
					month_is_character: true,
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_date_imagecombo91 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
					day_startX: 352,
					day_startY: 176,
					day_sc_array: ["0155.png","0156.png","0157.png","0158.png","0159.png","0160.png","0161.png","0162.png","0163.png","0164.png"],
					day_tc_array: ["0155.png","0156.png","0157.png","0158.png","0159.png","0160.png","0161.png","0162.png","0163.png","0164.png"],
					day_en_array: ["0155.png","0156.png","0157.png","0158.png","0159.png","0160.png","0161.png","0162.png","0163.png","0164.png"],
					day_zero: true,
					day_space: -11,
					day_align: hmUI.align.CENTER_H,
					day_is_character: false,
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_moon_phase_imageset92 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
					x: 334,
					y: 239,
					image_array: ["0165.png","0166.png","0167.png","0168.png","0169.png","0170.png","0171.png","0172.png"],
					image_length: 8,
					type: hmUI.data_type.MOON,
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				function updateBattery() {
					var current_normal_battery_progress45 = batterySensor.current;
					var target_normal_battery_progress45 = 100;
					var progress_normal_battery_progress45 = current_normal_battery_progress45/target_normal_battery_progress45;

					normal_battery_progress45.setProperty(hmUI.prop.MORE, {
						w: Math.ceil(27*progress_normal_battery_progress45)
					})
				}

				function updateHeart() {
					let normal_heart_min_imagecombo20_current = Math.min(...heartSensor.today);
					if (normal_heart_min_imagecombo20_padding) {
						normal_heart_min_imagecombo20_current = normal_heart_min_imagecombo20_current.toString().padStart(normal_heart_min_imagecombo20.length, '0');
					}
					for (let i = 0; i < normal_heart_min_imagecombo20.length; i++) {
						normal_heart_min_imagecombo20[i].setProperty(hmUI.prop.MORE, { x: 227+((((normal_heart_min_imagecombo20.length-normal_heart_min_imagecombo20_current.toString().length)*15)/2)+15*i) });
						if ((normal_heart_min_imagecombo20.length-normal_heart_min_imagecombo20_current.length) < i && normal_heart_min_imagecombo20_padding === false) {
							normal_heart_min_imagecombo20[i].setProperty(hmUI.prop.VISIBLE, false);
						} else {
							normal_heart_min_imagecombo20[i].setProperty(hmUI.prop.VISIBLE, true);
							normal_heart_min_imagecombo20[i].setProperty(hmUI.prop.SRC, normal_heart_min_imagecombo20_array[normal_heart_min_imagecombo20_current.toString().charAt(i)]);
						}
					}
					let normal_heart_max_imagecombo21_current = Math.max(...heartSensor.today);
					if (normal_heart_max_imagecombo21_padding) {
						normal_heart_max_imagecombo21_current = normal_heart_max_imagecombo21_current.toString().padStart(normal_heart_max_imagecombo21.length, '0');
					}
					for (let i = 0; i < normal_heart_max_imagecombo21.length; i++) {
						normal_heart_max_imagecombo21[i].setProperty(hmUI.prop.MORE, { x: 273+((((normal_heart_max_imagecombo21.length-normal_heart_max_imagecombo21_current.toString().length)*15)/2)+15*i) });
						if ((normal_heart_max_imagecombo21.length-normal_heart_max_imagecombo21_current.length) < i && normal_heart_max_imagecombo21_padding === false) {
							normal_heart_max_imagecombo21[i].setProperty(hmUI.prop.VISIBLE, false);
						} else {
							normal_heart_max_imagecombo21[i].setProperty(hmUI.prop.VISIBLE, true);
							normal_heart_max_imagecombo21[i].setProperty(hmUI.prop.SRC, normal_heart_max_imagecombo21_array[normal_heart_max_imagecombo21_current.toString().charAt(i)]);
						}
					}
				}

				function updateWeather() {
					let tideData = weatherSensor.getForecastWeather().tideData;
					normal_sunrise_hours_high_imageset57.setProperty(hmUI.prop.MORE, {
						src: normal_sunrise_hours_high_imageset57_array[tideData.data[0].sunrise.hour.toString().padStart(2, '0').charAt(0)]
					})
					normal_sunrise_hours_low_imageset58.setProperty(hmUI.prop.MORE, {
						src: normal_sunrise_hours_low_imageset58_array[tideData.data[0].sunrise.hour.toString().padStart(2, '0').charAt(1)]
					})
					normal_sunrise_minutes_high_imageset59.setProperty(hmUI.prop.MORE, {
						src: normal_sunrise_minutes_high_imageset59_array[tideData.data[0].sunrise.minute.toString().padStart(2, '0').charAt(0)]
					})
					normal_sunrise_minutes_low_imageset60.setProperty(hmUI.prop.MORE, {
						src: normal_sunrise_minutes_low_imageset60_array[tideData.data[0].sunrise.minute.toString().padStart(2, '0').charAt(1)]
					})
					normal_sunset_hours_high_imageset61.setProperty(hmUI.prop.MORE, {
						src: normal_sunset_hours_high_imageset61_array[tideData.data[0].sunset.hour.toString().padStart(2, '0').charAt(0)]
					})
					normal_sunset_hours_low_imageset62.setProperty(hmUI.prop.MORE, {
						src: normal_sunset_hours_low_imageset62_array[tideData.data[0].sunset.hour.toString().padStart(2, '0').charAt(1)]
					})
					normal_sunset_minutes_high_imageset63.setProperty(hmUI.prop.MORE, {
						src: normal_sunset_minutes_high_imageset63_array[tideData.data[0].sunset.minute.toString().padStart(2, '0').charAt(0)]
					})
					normal_sunset_minutes_low_imageset64.setProperty(hmUI.prop.MORE, {
						src: normal_sunset_minutes_low_imageset64_array[tideData.data[0].sunset.minute.toString().padStart(2, '0').charAt(1)]
					})
				}

				function updateFatBurning() {
					let normal_fat_burning_imagecombo26_current = fat_burningSensor.current;
					if (normal_fat_burning_imagecombo26_padding) {
						normal_fat_burning_imagecombo26_current = normal_fat_burning_imagecombo26_current.toString().padStart(normal_fat_burning_imagecombo26.length, '0');
					}
					for (let i = 0; i < normal_fat_burning_imagecombo26.length; i++) {
						normal_fat_burning_imagecombo26[i].setProperty(hmUI.prop.MORE, { x: 296+((((normal_fat_burning_imagecombo26.length-normal_fat_burning_imagecombo26_current.toString().length)*18)/2)+18*i) });
						if ((normal_fat_burning_imagecombo26.length-normal_fat_burning_imagecombo26_current.length) < i && normal_fat_burning_imagecombo26_padding === false) {
							normal_fat_burning_imagecombo26[i].setProperty(hmUI.prop.VISIBLE, false);
						} else {
							normal_fat_burning_imagecombo26[i].setProperty(hmUI.prop.VISIBLE, true);
							normal_fat_burning_imagecombo26[i].setProperty(hmUI.prop.SRC, normal_fat_burning_imagecombo26_array[normal_fat_burning_imagecombo26_current.toString().charAt(i)]);
						}
					}
				}

				function updateSleep() {
					let normal_sleep_imagecombo34_h = Math.floor(sleepSensor.getTotalTime() / 60).toString();
					let normal_sleep_imagecombo34_m = Math.floor(sleepSensor.getTotalTime() % 60).toString().padStart(2, '0');
					let normal_sleep_imagecombo34_current = (normal_sleep_imagecombo34_padding === true ? normal_sleep_imagecombo34_h.padStart(2, '0') : normal_sleep_imagecombo34_h) + ':' + normal_sleep_imagecombo34_m;
					let normal_sleep_imagecombo34_cp = (normal_sleep_imagecombo34_padding === true || normal_sleep_imagecombo34_h.length == 2) ? 2 : 1;
					for (let i = 0; i < normal_sleep_imagecombo34.length; i++) {
						if (i == normal_sleep_imagecombo34_cp) {
							normal_sleep_imagecombo34[i].setProperty(hmUI.prop.SRC, normal_sleep_imagecombo34_array[10]);
						} else {
							normal_sleep_imagecombo34[i].setProperty(hmUI.prop.SRC, normal_sleep_imagecombo34_array[normal_sleep_imagecombo34_current.toString().charAt(i)]);
						}
					}
				}

				batterySensor.addEventListener(hmSensor.event.CHANGE, function() {
					updateBattery();
				});

				heartSensor.addEventListener(hmSensor.event.CHANGE, function() {
					updateHeart();
				});

				weatherSensor.addEventListener(hmSensor.event.CHANGE, function() {
					updateWeather();
				});

				fat_burningSensor.addEventListener(hmSensor.event.CHANGE, function() {
					updateFatBurning();
				});

				sleepSensor.addEventListener(hmSensor.event.CHANGE, function() {
					updateSleep();
				});

				const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
					resume_call: (function () {
						updateBattery();
						updateHeart();
						updateWeather();
						updateFatBurning();
						updateSleep();
					}),
					pause_call: (function () {
					}),
				})
			},

		onInit() {
			console.log('index page.js on init invoke')
			this.init_view()
		},
		onReady() {
			console.log('index page.js on ready invoke')
		},
		onShow() {
			console.log('index page.js on show invoke')
		},
		onHide() {
			console.log('index page.js on hide invoke')
		},
		onDestroy() {
			console.log('index page.js on destroy invoke')
		},
	});	})()
} catch (e) {
	console.log(e)
}
﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_day_pointer_progress_date_pointer = ''
        let normal_date_img_date_week_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg_img = ''
        let idle_day_pointer_progress_date_pointer = ''
        let idle_date_img_date_week_img = ''
        let idle_moon_image_progress_img_level = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'A100_579.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_day_pointer_progress_date_pointer = hmUI.createWidget(hmUI.widget.DATE_POINTER, {
              src: 'A100_441.png',
              center_x: 240,
              center_y: 240,
              posX: 161,
              posY: 161,
              start_angle: 372,
              end_angle: 12,
              scale_sc: 'A100_574.png',
              scale_tc: 'A100_574.png',
              scale_en: 'A100_574.png',
              scale_x: 0,
              scale_y: 0,
              cover_path: 'A100_578.png',
              cover_x: 0,
              cover_y: 0,
              type: hmUI.date.DAY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 164,
              y: 74,
              week_en: ["A100_121.png","A100_122.png","A100_123.png","A100_124.png","A100_125.png","A100_126.png","A100_127.png"],
              week_tc: ["A100_121.png","A100_122.png","A100_123.png","A100_124.png","A100_125.png","A100_126.png","A100_127.png"],
              week_sc: ["A100_121.png","A100_122.png","A100_123.png","A100_124.png","A100_125.png","A100_126.png","A100_127.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 177,
              y: 81,
              image_array: ["A100_128.png","A100_130.png","A100_132.png","A100_134.png","A100_135.png","A100_137.png","A100_139.png","A100_141.png","A100_143.png"],
              image_length: 9,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'A100_593.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 21,
              hour_posY: 240,
              hour_cover_path: 'A100_190.png',
              hour_cover_x: 75,
              hour_cover_y: 144,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'A100_594.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 21,
              minute_posY: 240,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'A100_148.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 21,
              second_posY: 240,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'A100_583.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_day_pointer_progress_date_pointer = hmUI.createWidget(hmUI.widget.DATE_POINTER, {
              src: 'A100_250.png',
              center_x: 240,
              center_y: 240,
              posX: 161,
              posY: 161,
              start_angle: 372,
              end_angle: 12,
              scale_sc: 'A100_580.png',
              scale_tc: 'A100_580.png',
              scale_en: 'A100_580.png',
              scale_x: 0,
              scale_y: 0,
              cover_path: 'A100_581.png',
              cover_x: 0,
              cover_y: 0,
              type: hmUI.date.DAY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 164,
              y: 74,
              week_en: ["A100_311.png","A100_312.png","A100_313.png","A100_314.png","A100_315.png","A100_316.png","A100_317.png"],
              week_tc: ["A100_311.png","A100_312.png","A100_313.png","A100_314.png","A100_315.png","A100_316.png","A100_317.png"],
              week_sc: ["A100_311.png","A100_312.png","A100_313.png","A100_314.png","A100_315.png","A100_316.png","A100_317.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 177,
              y: 81,
              image_array: ["A100_318.png","A100_320.png","A100_322.png","A100_324.png","A100_325.png","A100_327.png","A100_329.png","A100_331.png","A100_333.png"],
              image_length: 9,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'A100_584.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 21,
              hour_posY: 240,
              hour_cover_path: 'A100_381.png',
              hour_cover_x: 75,
              hour_cover_y: 144,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'A100_585.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 21,
              minute_posY: 240,
              minute_cover_path: 'A100_597.png',
              minute_cover_x: 219,
              minute_cover_y: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_text_separator_img = ''
        let normal_calorie_current_text_img = ''
        let normal_pai_weekly_text_img = ''
        let normal_pai_weekly_separator_img = ''
        let normal_distance_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_sun_high_text_img = ''
        let normal_sun_high_separator_img = ''
        let normal_sun_low_text_img = ''
        let normal_sun_low_separator_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_max_min_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_battery_text_text_img = ''
        let normal_digital_clock_img_time = ''
        let normal_step_jumpable_img_click = ''
        let normal_cal_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_battery_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_moon_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_readiness_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_Switch_BG = ''

        let backgroundIndex = 0;
        let backgroundList = ['wallpaper0.png', 'wallpaper1.png', 'wallpaper2.png', 'wallpaper3.png', 'wallpaper4.png'];
        let backgroundToastList = ['Фон %s', 'Фон %s', 'Фон %s', 'Фон %s', 'Фон %s'];
        const watchfaceId = hmApp.packageInfo().watchfaceId;


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            //start of ignored block
            console.log('SwitchBackground');
            function switchBackground() {
              backgroundIndex++;
              if (backgroundIndex >= backgroundList.length) backgroundIndex = 0;
              hmFS.SysProSetInt(`backgroundIndex_${watchfaceId}`, backgroundIndex);
              let toastText = backgroundToastList[backgroundIndex].replace('%s', `${backgroundIndex + 1}`);
              if (toastText.length > 0) hmUI.showToast({text: toastText});
              normal_background_bg_img.setProperty(hmUI.prop.SRC, backgroundList[backgroundIndex]);
              vibro(28);
            };
            //end of ignored block

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'wallpaper0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 380,
              y: 80,
              image_array: ["moon_0.png","moon_1.png","moon_2.png","moon_3.png","moon_4.png","moon_5.png","moon_6.png","moon_7.png","moon_8.png","moon_9.png","moon_10.png","moon_11.png","moon_12.png","moon_13.png","moon_14.png","moon_15.png","moon_16.png","moon_17.png","moon_18.png","moon_19.png","moon_20.png","moon_21.png","moon_22.png","moon_23.png","moon_24.png","moon_25.png","moon_26.png","moon_27.png","moon_28.png","moon_29.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 164,
              y: 17,
              src: 'bluetooth.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 292,
              y: 17,
              src: 'alarm-clock.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 253,
              y: 266,
              week_en: ["week_0.png","week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png"],
              week_tc: ["week_0.png","week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png"],
              week_sc: ["week_0.png","week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 379,
              month_startY: 236,
              month_sc_array: ["months_0.png","months_1.png","months_2.png","months_3.png","months_4.png","months_5.png","months_6.png","months_7.png","months_8.png","months_9.png","months_10.png","months_11.png"],
              month_tc_array: ["months_0.png","months_1.png","months_2.png","months_3.png","months_4.png","months_5.png","months_6.png","months_7.png","months_8.png","months_9.png","months_10.png","months_11.png"],
              month_en_array: ["months_0.png","months_1.png","months_2.png","months_3.png","months_4.png","months_5.png","months_6.png","months_7.png","months_8.png","months_9.png","months_10.png","months_11.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 382,
              day_startY: 265,
              day_sc_array: ["date_0.png","date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png","date_8.png","date_9.png"],
              day_tc_array: ["date_0.png","date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png","date_8.png","date_9.png"],
              day_en_array: ["date_0.png","date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png","date_8.png","date_9.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 189,
              y: 425,
              font_array: ["font24_0.png","font24_1.png","font24_2.png","font24_3.png","font24_4.png","font24_5.png","font24_6.png","font24_7.png","font24_8.png","font24_9.png"],
              padding: false,
              h_space: 0,
              invalid_image: 'symb24_1.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 237,
              y: 425,
              src: 'bpm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 256,
              y: 385,
              font_array: ["font24_0.png","font24_1.png","font24_2.png","font24_3.png","font24_4.png","font24_5.png","font24_6.png","font24_7.png","font24_8.png","font24_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'kcal.png',
              unit_tc: 'kcal.png',
              unit_en: 'kcal.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_weekly_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 176,
              y: 385,
              font_array: ["font24_0.png","font24_1.png","font24_2.png","font24_3.png","font24_4.png","font24_5.png","font24_6.png","font24_7.png","font24_8.png","font24_9.png"],
              padding: true,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_weekly_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 133,
              y: 385,
              src: 'pai.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 256,
              y: 345,
              font_array: ["font24_0.png","font24_1.png","font24_2.png","font24_3.png","font24_4.png","font24_5.png","font24_6.png","font24_7.png","font24_8.png","font24_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'distance.png',
              unit_tc: 'distance.png',
              unit_en: 'distance.png',
              dot_image: 'font24_11.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 144,
              y: 345,
              font_array: ["font24_0.png","font24_1.png","font24_2.png","font24_3.png","font24_4.png","font24_5.png","font24_6.png","font24_7.png","font24_8.png","font24_9.png"],
              padding: true,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 74,
              y: 346,
              src: 'steps.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 295,
              y: 57,
              font_array: ["font24_0.png","font24_1.png","font24_2.png","font24_3.png","font24_4.png","font24_5.png","font24_6.png","font24_7.png","font24_8.png","font24_9.png"],
              padding: false,
              h_space: 0,
              dot_image: 'font24_10.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 256,
              y: 51,
              src: 'sunrise.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 295,
              y: 97,
              font_array: ["font24_0.png","font24_1.png","font24_2.png","font24_3.png","font24_4.png","font24_5.png","font24_6.png","font24_7.png","font24_8.png","font24_9.png"],
              padding: false,
              h_space: 0,
              dot_image: 'font24_10.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 256,
              y: 91,
              src: 'sunset.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 112,
              y: 48,
              image_array: ["wthr_0.png","wthr_1.png","wthr_2.png","wthr_3.png","wthr_4.png","wthr_5.png","wthr_6.png","wthr_7.png","wthr_8.png","wthr_9.png","wthr_10.png","wthr_11.png","wthr_12.png","wthr_13.png","wthr_14.png","wthr_15.png","wthr_16.png","wthr_17.png","wthr_18.png","wthr_19.png","wthr_20.png","wthr_21.png","wthr_22.png","wthr_23.png","wthr_24.png","wthr_25.png","wthr_26.png","wthr_27.png","wthr_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_max_min_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 106,
              y: 97,
              font_array: ["font24_0.png","font24_1.png","font24_2.png","font24_3.png","font24_4.png","font24_5.png","font24_6.png","font24_7.png","font24_8.png","font24_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'symb24_2.png',
              unit_tc: 'symb24_2.png',
              unit_en: 'symb24_2.png',
              negative_image: 'symb24_1.png',
              invalid_image: 'symb24_1.png',
              dot_image: 'symb24_0.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_HIGH_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 163,
              y: 57,
              font_array: ["font24_0.png","font24_1.png","font24_2.png","font24_3.png","font24_4.png","font24_5.png","font24_6.png","font24_7.png","font24_8.png","font24_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'symb24_2.png',
              unit_tc: 'symb24_2.png',
              unit_en: 'symb24_2.png',
              negative_image: 'symb24_1.png',
              invalid_image: 'symb24_1.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 205,
              y: 15,
              font_array: ["font24_0.png","font24_1.png","font24_2.png","font24_3.png","font24_4.png","font24_5.png","font24_6.png","font24_7.png","font24_8.png","font24_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'symb24_3.png',
              unit_tc: 'symb24_3.png',
              unit_en: 'symb24_3.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 35,
              hour_startY: 167,
              hour_array: ["font176_0.png","font176_1.png","font176_2.png","font176_3.png","font176_4.png","font176_5.png","font176_6.png","font176_7.png","font176_8.png","font176_9.png"],
              hour_zero: 1,
              hour_space: -6,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 226,
              minute_startY: 167,
              minute_array: ["font114_0.png","font114_1.png","font114_2.png","font114_3.png","font114_4.png","font114_5.png","font114_6.png","font114_7.png","font114_8.png","font114_9.png"],
              minute_zero: 1,
              minute_space: -3,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 360,
              second_startY: 167,
              second_array: ["font81_0.png","font81_1.png","font81_2.png","font81_3.png","font81_4.png","font81_5.png","font81_6.png","font81_7.png","font81_8.png","font81_9.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 74,
              y: 345,
              w: 150,
              h: 24,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_cal_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 256,
              y: 345,
              w: 112,
              h: 64,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 186,
              y: 423,
              w: 114,
              h: 38,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 133,
              y: 385,
              w: 91,
              h: 24,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 205,
              y: 15,
              w: 70,
              h: 24,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 256,
              y: 57,
              w: 110,
              h: 64,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 376,
              y: 76,
              w: 40,
              h: 40,
              type: hmUI.data_type.MOON_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 106,
              y: 57,
              w: 118,
              h: 64,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 226,
              y: 167,
              w: 119,
              h: 85,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 360,
              y: 167,
              w: 86,
              h: 60,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 287,
              y: 14,
              w: 35,
              h: 30,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_readiness_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 247,
              y: 262,
              w: 77,
              h: 40,
              type: hmUI.data_type.READINESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 372,
              y: 234,
              w: 62,
              h: 66,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'empty.png',
              normal_src: 'empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 35,
              y: 167,
              w: 176,
              h: 130,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'empty.png',
              normal_src: 'empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'FlashLightScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            console.log('Watch_Face.SwitchBackground');
            // Button_Switch_BG = hmUI.createWidget(hmUI.widget.SwitchBackground, {
              // x: 159,
              // y: 14,
              // w: 35,
              // h: 30,
              // text: '',
              // color: 0xFFFF8C00,
              // text_size: 25,
              // press_src: 'empty.png',
              // normal_src: 'empty.png',
              // bg_list: wallpaper0|wallpaper1|wallpaper2|wallpaper3|wallpaper4,
              // toast_list: Фон %s|Фон %s|Фон %s|Фон %s|Фон %s,
              // use_crown: False,
              // use_in_AOD: False,
              // vibro: True,
            // });

            Button_Switch_BG = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 159,
              y: 14,
              w: 35,
              h: 30,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'empty.png',
              normal_src: 'empty.png',
              click_func: (button_widget) => {
                switchBackground();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            let screenType = hmSetting.getScreenType();
            // vibrate function
            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;

            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');

                //SwitchBackground
                if (hmFS.SysProGetInt(`backgroundIndex_${watchfaceId}`) === undefined) {
                  backgroundIndex = 0;
                  hmFS.SysProSetInt(`backgroundIndex_${watchfaceId}`, backgroundIndex);
                } else {
                  backgroundIndex = hmFS.SysProGetInt(`backgroundIndex_${watchfaceId}`);
                };
                if (screenType == hmSetting.screen_type.WATCHFACE && normal_background_bg_img) normal_background_bg_img.setProperty(hmUI.prop.SRC, backgroundList[backgroundIndex]);
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
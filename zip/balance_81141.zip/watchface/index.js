﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

// Start color change
         let colornumber_main = 1
        let totalcolors_main = 5
        let namecolor_main = ''

        function click_Color() {
            if(colornumber_main>=totalcolors_main) {
            colornumber_main=1;
                }
            else {
                colornumber_main=colornumber_main+1;
            }

if ( colornumber_main == 1) { namecolor_main = "GRAY"}
if ( colornumber_main == 2) { namecolor_main = "BLUE"}
if ( colornumber_main == 3) { namecolor_main = "YELLOW"}
if ( colornumber_main == 4) { namecolor_main = "RED"}
if ( colornumber_main == 5) { namecolor_main = "GREEN"}
hmUI.showToast({text: namecolor_main });

             //hmUI.showToast({text: "color " + parseInt(colornumber_main) });
             normal_background_bg_img.setProperty(hmUI.prop.SRC, "main" + parseInt(colornumber_main) + ".png");
                           
        }

/////////////////////////////////////////////////////////////////////////////////////////////////

        // Start swith weather / activity

        let timer_anim_rotate_1_mirror =''
        let cc = 0
        let elementnumber_1 = 1
        let total_elemente = 2

        function click_elemente() {
            if(elementnumber_1==total_elemente) {
            elementnumber_1=1;
                UpdateElementeOne();
                }
            else {
                elementnumber_1=elementnumber_1+1;
                if(elementnumber_1==2) {
                  UpdateElementeTwo();
                }

            }
            if(elementnumber_1==1) hmUI.showToast({text: 'Activity'});
            if(elementnumber_1==2) hmUI.showToast({text: 'Weather'});
        }

        //Activity
        function UpdateElementeOne(){
         normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, true);
         normal_heart_rate_circle_scale.setProperty(hmUI.prop.VISIBLE, true);
         normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
         normal_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, true);
         normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
         normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, true);
         normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
         normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, true);
         normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
         normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, true);


        normal_humidity_icon_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_humidity_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_wind_icon_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_wind_direction_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
        normal_wind_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_rotate_animation_img_1.setProperty(hmUI.prop.VISIBLE, false);
     ///   normal_rotate_animation_param_1 = null;
     ///  normal_rotate_animation_lastTime_1 = 0;
     ///  timer_anim_rotate_1;
     ///   normal_rotate_animation_count_1 = 0;
        normal_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_temperature_high_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_temperature_low_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_temperature_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);


        normal_temperature_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_pai_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
        normal_step_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
        normal_spo2_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
        normal_heart_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);

        }

        //Weather
        function UpdateElementeTwo(){
          normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, false);
         normal_heart_rate_circle_scale.setProperty(hmUI.prop.VISIBLE, false);
         normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
         normal_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
         normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
         normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
         normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
         normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
         normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
         normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);


        normal_humidity_icon_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_humidity_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_wind_icon_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_wind_direction_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);
        normal_wind_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_rotate_animation_img_1.setProperty(hmUI.prop.VISIBLE, true);
     ///   normal_rotate_animation_param_1 = null;
     ///  normal_rotate_animation_lastTime_1 = 0;
     ///  timer_anim_rotate_1;
     ///   normal_rotate_animation_count_1 = 0;
        normal_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_temperature_high_text_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_temperature_low_text_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_temperature_current_separator_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);


        normal_temperature_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
        normal_pai_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_step_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_spo2_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_heart_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);

        }
        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_humidity_icon_img = ''
        let normal_humidity_text_text_img = ''
        let normal_wind_icon_img = ''
        let normal_wind_direction_image_progress_img_level = ''
        let normal_wind_text_text_img = ''
        let normal_rotate_animation_img_1 = '';
        let normal_rotate_animation_param_1 = null;
        let normal_rotate_animation_lastTime_1 = 0;
        let timer_anim_rotate_1;
        let normal_rotate_animation_count_1 = 0;
        let normal_city_name_text = ''
        let normal_temperature_icon_img = ''
        let normal_temperature_high_text_img = ''
        let normal_temperature_low_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_temperature_current_separator_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_sun_current_text_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_date_day_separator_img = ''
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_circle_scale = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_text_separator_img = ''
        let normal_distance_text_text_img = ''
        let normal_distance_text_separator_img = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_calorie_current_text_img = ''
        let normal_calorie_current_separator_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time_second = ''
        let normal_digital_clock_img_time_minute = ''
        let normal_digital_clock_img_time_hour = ''
        let normal_digital_clock_hour_separator_img = ''
        let idle_background_bg_img = ''
        let idle_city_name_text = ''
        let idle_temperature_high_text_img = ''
        let idle_temperature_low_text_img = ''
        let idle_temperature_current_text_img = ''
        let idle_temperature_current_separator_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_moon_image_progress_img_level = ''
        let idle_battery_text_text_img = ''
        let idle_battery_image_progress_img_level = ''
        let idle_sun_current_text_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_month = ''
        let idle_date_img_date_day = ''
        let idle_date_day_separator_img = ''
        let idle_heart_rate_icon_img = ''
        let idle_heart_rate_circle_scale = ''
        let idle_heart_rate_text_text_img = ''
        let idle_heart_rate_text_separator_img = ''
        let idle_step_current_text_img = ''
        let idle_step_current_separator_img = ''
        let idle_calorie_current_text_img = ''
        let idle_calorie_current_separator_img = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time_second = ''
        let idle_digital_clock_img_time_minute = ''
        let idle_digital_clock_img_time_hour = ''
        let idle_digital_clock_hour_separator_img = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'main1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 240,
              y: 62,
              src: 'icon_hu.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 256,
              y: 58,
              font_array: ["Act_0.png","Act_1.png","Act_2.png","Act_3.png","Act_4.png","Act_5.png","Act_6.png","Act_7.png","Act_8.png","Act_9.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'Hu_unit.png',
              unit_tc: 'Hu_unit.png',
              unit_en: 'Hu_unit.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 204,
              y: 106,
              src: 'icon_wind.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_direction_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 311,
              y: 99,
              image_array: ["Wind_C_1.png","Wind_C_2.png","Wind_C_3.png","Wind_C_4.png","Wind_C_5.png","Wind_C_6.png","Wind_C_7.png","Wind_C_8.png"],
              image_length: 8,
              type: hmUI.data_type.WIND_DIRECTION,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 241,
              y: 99,
              font_array: ["Act_0.png","Act_1.png","Act_2.png","Act_3.png","Act_4.png","Act_5.png","Act_6.png","Act_7.png","Act_8.png","Act_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WIND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_rotate_animation_img_1 = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 481,
              h: 481,
              pos_x: 205,
              pos_y: 100,
              center_x: 218,
              center_y: 112,
              angle: 0,
              src: 'animation/fan_0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_rotate_animation_param_1 = {
              anim_steps: [{
                anim_rate: 'linear',
                anim_duration: 1000,
                anim_from: 0,
                anim_to: 360,
                anim_key: "angle",
              }],
              anim_fps: 15,
              anim_auto_start: 1,
              anim_repeat: 1,
              anim_auto_destroy: 1,
            };

            let now = hmSensor.createSensor(hmSensor.id.TIME);

            function anim_rotate_1_complete_call() {
              normal_rotate_animation_img_1.setProperty(hmUI.prop.ANIM, normal_rotate_animation_param_1);
              normal_rotate_animation_lastTime_1 = now.utc;
              normal_rotate_animation_count_1 = normal_rotate_animation_count_1 - 1;
              if(normal_rotate_animation_count_1 < -1) normal_rotate_animation_count_1 = - 1;
              if(normal_rotate_animation_count_1 == 0) stop_anim_rotate_1();
            }; // end animation callback function
            
            function stop_anim_rotate_1() {
              if (timer_anim_rotate_1) {
                timer.stopTimer(timer_anim_rotate_1);
                timer_anim_rotate_1 = undefined;
              };
            }; // end stop_anim_rotate function

            // normal_rotate_anime_1 = hmUI.createWidget(hmUI.widget.Rotate_Animation, {
              // start_angle: 0,
              // end_angle: 360,
              // pos_x: 13,
              // pos_y: 12,
              // center_x: 218,
              // center_y: 112,
              // src: 'fan_0.png',
              // anim_fps: 15,
              // anim_duration: 1000,
              // repeat_count: 0,
              // anim_two_sides: False,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 242,
              y: 371,
              w: 150,
              h: 39,
              text_size: 23,
              char_space: 0,
              line_space: 0,
              color: 0xFF000000,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 38,
              y: 128,
              src: 'Weather_BG.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 387,
              y: 146,
              font_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Weahter_S_Symbo2.png',
              unit_tc: 'Weahter_S_Symbo2.png',
              unit_en: 'Weahter_S_Symbo2.png',
              negative_image: 'Weahter_S_Symbo1.png',
              invalid_image: 'Weahter_S_Symbo1.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 300,
              y: 146,
              font_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Weahter_S_Symbo2.png',
              unit_tc: 'Weahter_S_Symbo2.png',
              unit_en: 'Weahter_S_Symbo2.png',
              negative_image: 'Weahter_S_Symbo1.png',
              invalid_image: 'Weahter_S_Symbo1.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 193,
              y: 139,
              font_array: ["Act_0.png","Act_1.png","Act_2.png","Act_3.png","Act_4.png","Act_5.png","Act_6.png","Act_7.png","Act_8.png","Act_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Weather_Symbo2.png',
              unit_tc: 'Weather_Symbo2.png',
              unit_en: 'Weather_Symbo2.png',
              negative_image: 'Weather_Symbo1.png',
              invalid_image: 'Weather_Symbo1.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 170,
              y: 139,
              src: 'icon_weather1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 56,
              y: 141,
              image_array: ["Weather_icon_01.png","Weather_icon_02.png","Weather_icon_03.png","Weather_icon_04.png","Weather_icon_05.png","Weather_icon_06.png","Weather_icon_07.png","Weather_icon_08.png","Weather_icon_09.png","Weather_icon_10.png","Weather_icon_11.png","Weather_icon_12.png","Weather_icon_13.png","Weather_icon_14.png","Weather_icon_15.png","Weather_icon_16.png","Weather_icon_17.png","Weather_icon_18.png","Weather_icon_19.png","Weather_icon_20.png","Weather_icon_21.png","Weather_icon_22.png","Weather_icon_23.png","Weather_icon_24.png","Weather_icon_25.png","Weather_icon_26.png","Weather_icon_27.png","Weather_icon_28.png","Weather_icon_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 422,
              y: 289,
              src: 'System_BT_OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 180,
              y: 34,
              src: 'System_alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 123,
              y: 71,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 200,
              y: 236,
              font_array: ["Batt_Font_0.png","Batt_Font_1.png","Batt_Font_2.png","Batt_Font_3.png","Batt_Font_4.png","Batt_Font_5.png","Batt_Font_6.png","Batt_Font_7.png","Batt_Font_8.png","Batt_Font_9.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'Batt_unit.png',
              unit_tc: 'Batt_unit.png',
              unit_en: 'Batt_unit.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 163,
              y: 210,
              image_array: ["power_01.png","power_02.png","power_03.png","power_04.png","power_05.png","power_06.png","power_07.png","power_08.png","power_09.png","power_10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 140,
              y: 386,
              font_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              padding: false,
              h_space: 1,
              dot_image: 'sun_moon_dot.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 160,
              y: 273,
              week_en: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              week_tc: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              week_sc: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 110,
              month_startY: 266,
              month_sc_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              month_tc_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              month_en_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 51,
              day_startY: 266,
              day_sc_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              day_tc_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              day_en_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              day_zero: 1,
              day_space: 1,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_day_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 90,
              y: 266,
              src: 'Day_unit.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 43,
              y: 130,
              src: 'Heart_BG.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_heart_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 94,
              // center_y: 181,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 52,
              // line_width: 5,
              // line_cap: Rounded,
              // color: 0xFFFF0000,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            let screenType = hmSetting.getScreenType();
            normal_heart_rate_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 94,
              center_y: 181,
              start_angle: 0,
              end_angle: 360,
              radius: 50,
              line_width: 5,
              corner_flag: 0,
              color: 0xFFFF0000,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const heart_rate = hmSensor.createSensor(hmSensor.id.HEART);
            heart_rate.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 51,
              y: 177,
              font_array: ["Heart_font_0.png","Heart_font_1.png","Heart_font_2.png","Heart_font_3.png","Heart_font_4.png","Heart_font_5.png","Heart_font_6.png","Heart_font_7.png","Heart_font_8.png","Heart_font_9.png"],
              padding: false,
              h_space: 0,
              invalid_image: 'Heart_font_0.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 72,
              y: 143,
              src: 'icon_heart.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 189,
              y: 139,
              font_array: ["Act_0.png","Act_1.png","Act_2.png","Act_3.png","Act_4.png","Act_5.png","Act_6.png","Act_7.png","Act_8.png","Act_9.png"],
              padding: false,
              h_space: 3,
              unit_sc: 'Dis_KM.png',
              unit_tc: 'Dis_KM.png',
              unit_en: 'Dis_KM.png',
              imperial_unit_sc: 'Dis_Mi.png',
              imperial_unit_tc: 'Dis_Mi.png',
              imperial_unit_en: 'Dis_Mi.png',
              dot_image: 'Dis_Dot.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 167,
              y: 137,
              src: 'icon_Dis.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 241,
              y: 99,
              font_array: ["Act_0.png","Act_1.png","Act_2.png","Act_3.png","Act_4.png","Act_5.png","Act_6.png","Act_7.png","Act_8.png","Act_9.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 205,
              y: 96,
              src: 'icon_steps.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 260,
              y: 57,
              font_array: ["Act_0.png","Act_1.png","Act_2.png","Act_3.png","Act_4.png","Act_5.png","Act_6.png","Act_7.png","Act_8.png","Act_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 238,
              y: 62,
              src: 'icon_cal.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 63,
              am_y: 334,
              am_sc_path: 'Clock_AM.png',
              am_en_path: 'Clock_AM.png',
              pm_x: 63,
              pm_y: 334,
              pm_sc_path: 'Clock_PM.png',
              pm_en_path: 'Clock_PM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_second = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              second_startX: 371,
              second_startY: 240,
              second_array: ["Time_S_0.png","Time_S_1.png","Time_S_2.png","Time_S_3.png","Time_S_4.png","Time_S_5.png","Time_S_6.png","Time_S_7.png","Time_S_8.png","Time_S_9.png"],
              second_zero: 1,
              second_space: 1,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 285,
              minute_startY: 304,
              minute_array: ["Time_0.png","Time_1.png","Time_2.png","Time_3.png","Time_4.png","Time_5.png","Time_6.png","Time_7.png","Time_8.png","Time_9.png"],
              minute_zero: 1,
              minute_space: 2,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 127,
              hour_startY: 303,
              hour_array: ["Time_0.png","Time_1.png","Time_2.png","Time_3.png","Time_4.png","Time_5.png","Time_6.png","Time_7.png","Time_8.png","Time_9.png"],
              hour_zero: 1,
              hour_space: 2,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 264,
              y: 303,
              src: 'Time_dot.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'main1.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 242,
              y: 371,
              w: 150,
              h: 39,
              text_size: 23,
              char_space: 0,
              line_space: 0,
              color: 0xFF000000,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 387,
              y: 146,
              font_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Weahter_S_Symbo2.png',
              unit_tc: 'Weahter_S_Symbo2.png',
              unit_en: 'Weahter_S_Symbo2.png',
              negative_image: 'Weahter_S_Symbo1.png',
              invalid_image: 'Weahter_S_Symbo1.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 300,
              y: 146,
              font_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Weahter_S_Symbo2.png',
              unit_tc: 'Weahter_S_Symbo2.png',
              unit_en: 'Weahter_S_Symbo2.png',
              negative_image: 'Weahter_S_Symbo1.png',
              invalid_image: 'Weahter_S_Symbo1.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 193,
              y: 139,
              font_array: ["Act_0.png","Act_1.png","Act_2.png","Act_3.png","Act_4.png","Act_5.png","Act_6.png","Act_7.png","Act_8.png","Act_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Weather_Symbo2.png',
              unit_tc: 'Weather_Symbo2.png',
              unit_en: 'Weather_Symbo2.png',
              negative_image: 'Weather_Symbo1.png',
              invalid_image: 'Weather_Symbo1.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 170,
              y: 139,
              src: 'icon_weather1.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 422,
              y: 289,
              src: 'System_BT_OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 180,
              y: 34,
              src: 'System_alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 123,
              y: 71,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 200,
              y: 236,
              font_array: ["Batt_Font_0.png","Batt_Font_1.png","Batt_Font_2.png","Batt_Font_3.png","Batt_Font_4.png","Batt_Font_5.png","Batt_Font_6.png","Batt_Font_7.png","Batt_Font_8.png","Batt_Font_9.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'Batt_unit.png',
              unit_tc: 'Batt_unit.png',
              unit_en: 'Batt_unit.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 163,
              y: 210,
              image_array: ["power_01.png","power_02.png","power_03.png","power_04.png","power_05.png","power_06.png","power_07.png","power_08.png","power_09.png","power_10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_sun_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 140,
              y: 386,
              font_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              padding: false,
              h_space: 1,
              dot_image: 'sun_moon_dot.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 160,
              y: 273,
              week_en: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              week_tc: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              week_sc: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 110,
              month_startY: 266,
              month_sc_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              month_tc_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              month_en_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 51,
              day_startY: 266,
              day_sc_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              day_tc_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              day_en_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              day_zero: 1,
              day_space: 1,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_day_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 90,
              y: 266,
              src: 'Day_unit.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 43,
              y: 130,
              src: 'Heart_BG.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_heart_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 94,
              // center_y: 181,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 52,
              // line_width: 5,
              // line_cap: Rounded,
              // color: 0xFFFF0000,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_heart_rate_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 94,
              center_y: 181,
              start_angle: 0,
              end_angle: 360,
              radius: 50,
              line_width: 5,
              corner_flag: 0,
              color: 0xFFFF0000,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 51,
              y: 177,
              font_array: ["Heart_font_0.png","Heart_font_1.png","Heart_font_2.png","Heart_font_3.png","Heart_font_4.png","Heart_font_5.png","Heart_font_6.png","Heart_font_7.png","Heart_font_8.png","Heart_font_9.png"],
              padding: false,
              h_space: 0,
              invalid_image: 'Heart_font_0.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 72,
              y: 143,
              src: 'icon_heart.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 241,
              y: 99,
              font_array: ["Act_0.png","Act_1.png","Act_2.png","Act_3.png","Act_4.png","Act_5.png","Act_6.png","Act_7.png","Act_8.png","Act_9.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 205,
              y: 96,
              src: 'icon_steps.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 260,
              y: 57,
              font_array: ["Act_0.png","Act_1.png","Act_2.png","Act_3.png","Act_4.png","Act_5.png","Act_6.png","Act_7.png","Act_8.png","Act_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 238,
              y: 62,
              src: 'icon_cal.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 63,
              am_y: 334,
              am_sc_path: 'Clock_AM.png',
              am_en_path: 'Clock_AM.png',
              pm_x: 63,
              pm_y: 334,
              pm_sc_path: 'Clock_PM.png',
              pm_en_path: 'Clock_PM.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_second = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              second_startX: 371,
              second_startY: 240,
              second_array: ["Time_S_0.png","Time_S_1.png","Time_S_2.png","Time_S_3.png","Time_S_4.png","Time_S_5.png","Time_S_6.png","Time_S_7.png","Time_S_8.png","Time_S_9.png"],
              second_zero: 1,
              second_space: 1,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 285,
              minute_startY: 304,
              minute_array: ["Time_0.png","Time_1.png","Time_2.png","Time_3.png","Time_4.png","Time_5.png","Time_6.png","Time_7.png","Time_8.png","Time_9.png"],
              minute_zero: 1,
              minute_space: 2,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 127,
              hour_startY: 303,
              hour_array: ["Time_0.png","Time_1.png","Time_2.png","Time_3.png","Time_4.png","Time_5.png","Time_6.png","Time_7.png","Time_8.png","Time_9.png"],
              hour_zero: 1,
              hour_space: 2,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 264,
              y: 303,
              src: 'Time_dot.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 262,
              y: 315,
              w: 30,
              h: 50,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 381,
              y: 237,
              w: 62,
              h: 43,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 178,
              y: 24,
              w: 41,
              h: 44,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 101,
              y: 382,
              w: 122,
              h: 27,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 184,
              y: 136,
              w: 247,
              h: 37,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 251,
              y: 57,
              w: 106,
              h: 29,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 48,
              y: 123,
              w: 93,
              h: 51,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 51,
              y: 185,
              w: 93,
              h: 42,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 207,
              y: 92,
              w: 196,
              h: 37,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 217,
              y: 421,
              w: 47,
              h: 45,
              text: '',
              color: 0xFFFF8C00,
              text_size: 26,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'SportListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 202,
              y: 219,
              w: 76,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 26,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PowerSaveHintScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 38,
              y: 288,
              w: 59,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 26,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 379,
              y: 190,
              w: 59,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 26,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                click_elemente()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 5,
              y: 221,
              w: 38,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 26,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                click_Color()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            console.log('user_script_end.js');
            // start user_script_end.js

if (cc==0) { 
         normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, true);
         normal_heart_rate_circle_scale.setProperty(hmUI.prop.VISIBLE, true);
         normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
         normal_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, true);
         normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
         normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, true);
         normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
         normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, true);
         normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
         normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, true);


        normal_humidity_icon_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_humidity_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_wind_icon_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_wind_direction_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
        normal_wind_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_rotate_animation_img_1.setProperty(hmUI.prop.VISIBLE, false);
     ///   normal_rotate_animation_param_1 = null;
     ///  normal_rotate_animation_lastTime_1 = 0;
     ///  timer_anim_rotate_1;
     ///   normal_rotate_animation_count_1 = 0;
        normal_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_temperature_high_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_temperature_low_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_temperature_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);


        normal_temperature_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_pai_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
        normal_step_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
        normal_spo2_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
        normal_heart_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);

cc= 1
}
            // end user_script_end.js

            function scale_call() {
              console.log('scale_call()');

              console.log('Weather city name');
              let weatherData = weatherSensor.getForecastWeather();
              normal_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

                console.log('update scales HEART');
                
                let valueHeartRate = heart_rate.last;
                let targetHeartRate = 179;
                let progressHeartRate = (valueHeartRate - 71)/(targetHeartRate - 71);
                if (progressHeartRate < 0) progressHeartRate = 0;
                if (progressHeartRate > 1) progressHeartRate = 1;
                let progress_cs_normal_heart_rate = progressHeartRate;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_heart_rate_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_heart_rate * 100);
                  if (normal_heart_rate_circle_scale) {
                    normal_heart_rate_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 94,
                      center_y: 181,
                      start_angle: 0,
                      end_angle: 360,
                      radius: 50,
                      line_width: 5,
                      corner_flag: 0,
                      color: 0xFFFF0000,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

              console.log('Weather city name');
              idle_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

                console.log('update scales HEART');
                let progress_cs_idle_heart_rate = progressHeartRate;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_heart_rate_circle_scale_circle_scale
                  let level = Math.round(progress_cs_idle_heart_rate * 100);
                  if (idle_heart_rate_circle_scale) {
                    idle_heart_rate_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 94,
                      center_y: 181,
                      start_angle: 0,
                      end_angle: 360,
                      radius: 50,
                      line_width: 5,
                      corner_flag: 0,
                      color: 0xFFFF0000,
                      show_level: hmUI.show_level.ONLY_AOD,
                      level: level,
                    });
                  };
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();

                let nawAnimationTime = now.utc;;
                
                let delay_anim_rotate_1 = 0;
                let repeat_anim_rotate_1 = 1000;
                delay_anim_rotate_1 = repeat_anim_rotate_1 - (nawAnimationTime - normal_rotate_animation_lastTime_1);
                if(delay_anim_rotate_1 < 0) delay_anim_rotate_1 = 0; 
                if((nawAnimationTime - normal_rotate_animation_lastTime_1) > repeat_anim_rotate_1) {
                  normal_rotate_animation_count_1 = 0;
                  timer_anim_rotate_1_mirror = false;
                };

                if (!timer_anim_rotate_1) {
                  timer_anim_rotate_1 = timer.createTimer(delay_anim_rotate_1, repeat_anim_rotate_1, (function (option) {
                    anim_rotate_1_complete_call()
                  })); // end timer create
                };

              }),
              pause_call: (function () {
                console.log('pause_call()');
                stop_anim_rotate_1();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
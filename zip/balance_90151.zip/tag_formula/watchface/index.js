import * as hmUI from '@zos/ui'

const DIGITS = ['Dig-0.png','Dig-1.png','Dig-2.png','Dig-3.png','Dig-4.png',
                'Dig-5.png','Dig-6.png','Dig-7.png','Dig-8.png','Dig-9.png']

const NORMAL = hmUI.show_level.ONLY_NORMAL
const AOD = hmUI.show_level.ONAL_AOD
const BOTH = NORMAL | AOD

// Centro real de la esfera (medido sobre la imagen de fondo)
const CX = 241
const CY = 237

WatchFace({
  build() {
    // ---------- Fondo ----------
    hmUI.createWidget(hmUI.widget.IMG, {
      x: 0, y: 0, w: 480, h: 480,
      src: 'Tag Formula.png',
      show_level: NORMAL
    })
    hmUI.createWidget(hmUI.widget.IMG, {
      x: 0, y: 0, w: 480, h: 480,
      src: 'Tag Formula PH.png',
      show_level: AOD
    })

    // ---------- Fecha: día dentro de la ventanilla (normal y AOD) ----------
    hmUI.createWidget(hmUI.widget.IMG_DATE, {
      day_startX: 378, day_startY: 228,
      day_sc_array: DIGITS, day_tc_array: DIGITS, day_en_array: DIGITS,
      day_zero: 0, day_space: 3,
      day_align: hmUI.align.LEFT,
      day_is_character: false,
      show_level: BOTH
    })

    // ---------- Agujas (modo normal) ----------
    hmUI.createWidget(hmUI.widget.TIME_POINTER, {
      hour_path: 'ATHO001.png', hour_centerX: CX, hour_centerY: CY, hour_posX: 15, hour_posY: 132,
      show_level: NORMAL
    })
    hmUI.createWidget(hmUI.widget.TIME_POINTER, {
      minute_path: 'ATHO002.png', minute_centerX: CX, minute_centerY: CY, minute_posX: 12, minute_posY: 198,
      show_level: NORMAL
    })
    hmUI.createWidget(hmUI.widget.TIME_POINTER, {
      second_path: 'ATHF003.png', second_centerX: CX, second_centerY: CY, second_posX: 40, second_posY: 230,
      show_level: NORMAL
    })

    // ---------- Agujas (AOD, sin segundero) ----------
    hmUI.createWidget(hmUI.widget.TIME_POINTER, {
      hour_path: 'ATHP001.png', hour_centerX: CX, hour_centerY: CY, hour_posX: 15, hour_posY: 131,
      show_level: AOD
    })
    hmUI.createWidget(hmUI.widget.TIME_POINTER, {
      minute_path: 'ATHP002.png', minute_centerX: CX, minute_centerY: CY, minute_posX: 12, minute_posY: 200,
      show_level: AOD
    })
  }
})

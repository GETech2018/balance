﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_stress_text_text_img = ''
        let normal_stress_text_separator_img = ''
        let normal_distance_text_text_img = ''
        let normal_distance_text_separator_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_text_separator_img = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_system_lock_img = ''
        let normal_system_dnd_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_high_text_img = ''
        let normal_temperature_high_separator_img = ''
        let normal_temperature_low_text_img = ''
        let normal_temperature_low_separator_img = ''
        let normal_temperature_current_text_img = ''
        let normal_digital_clock_img_time = ''
        let normal_image_img = ''
        let normal_analog_clock_time_pointer_smooth_second = ''
        let idle_background_bg = ''
        let idle_heart_rate_text_text_img = ''
        let idle_heart_rate_text_separator_img = ''
        let idle_digital_clock_img_time = ''
        let idle_system_lock_img = ''
        let idle_system_dnd_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_battery_text_text_img = ''
        let idle_battery_image_progress_img_level = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_day = ''
        let idle_image_img = ''
        let normal_step_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_battery_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_moon_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('user_script_start.js');
            // start user_script_start.js

let isAOD = hmSetting.getScreenType() == hmSetting.screen_type.AOD;
const curTime = hmSensor.createSensor(hmSensor.id.TIME);
const worldClock = hmSensor.createSensor(hmSensor.id.WORLD_CLOCK);


let normal_top_background_img;
let normal_world_time_text_img;
let normal_world_time_zone_text_img;
let normal_world_time_img_level;
let normal_world_time_gmt_img;
let normal_world_time_chr1_level;
let normal_world_time_chr2_level;
let normal_world_time_chr3_level;

let normal_top_text_line_01;
let normal_top_text_line_02;
let normal_top_text_line_03;
let normal_top_text_line_04;
let normal_top_text_line_05;
let normal_top_text_line_06;
let normal_top_text_line_07;
let normal_top_text_line_08;
let normal_top_text_line_09;
let normal_top_text_line_10;
let normal_top_text_line_11;
let normal_top_text_line_12;
let normal_top_text_line_13;
let normal_top_text_line_14;
let normal_top_text_line_15;
let normal_top_text_line_16;

let clockIndex = -1;
let reInitClock = true;
let showTimeZone = false;
            // end user_script_start.js

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'BACKGROUND_CIRCUIT.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('user_script.js');
            // start user_script.js
normal_top_background_img = hmUI.createWidget(hmUI.widget.IMG, {
    x: 0,
    y: 150,
    src: 'PLATE_INV_LARGE.png',
    show_level: hmUI.show_level.ONLY_NORMAL,
});

normal_world_time_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
    x: 118,
    y: 82,
    font_array: ["NUM_MEDIUM_0.png", "NUM_MEDIUM_1.png", "NUM_MEDIUM_2.png", "NUM_MEDIUM_3.png", "NUM_MEDIUM_4.png", "NUM_MEDIUM_5.png", "NUM_MEDIUM_6.png", "NUM_MEDIUM_7.png", "NUM_MEDIUM_8.png", "NUM_MEDIUM_9.png"],
    padding: false,
    h_space: 0,
    dot_image: 'NUM_MEDIUM_COLON.png',
    align_h: hmUI.align.LEFT,
    text: '00.00',
    show_level: hmUI.show_level.ONLY_NORMAL,
});

normal_world_time_zone_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
    x: 236,
    y: 156,
    font_array: ["NUM_SMALL_INV_0.png", "NUM_SMALL_INV_1.png", "NUM_SMALL_INV_2.png", "NUM_SMALL_INV_3.png", "NUM_SMALL_INV_4.png", "NUM_SMALL_INV_5.png", "NUM_SMALL_INV_6.png", "NUM_SMALL_INV_7.png", "NUM_SMALL_INV_8.png", "NUM_SMALL_INV_9.png"],
    padding: false,
    h_space: 0,
    dot_image: 'NUM_SMALL_INV_COLON.png',
    align_h: hmUI.align.LEFT,
    text: '00.00',
    show_level: hmUI.show_level.ONLY_NORMAL,
});

normal_world_time_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
    x: 220,
    y: 156,
    image_array: ["NUM_SMALL_INV_HALF_DASH.png", "blank.png", "NUM_SMALL_INV_HALF_PLUS.png"],
    image_length: 3,
    level: 2,
    show_level: hmUI.show_level.ONLY_NORMAL,
});

normal_world_time_gmt_img = hmUI.createWidget(hmUI.widget.IMG, {
    x: 118,
    y: 150,
    src: 'PLATE_INV_GMT.png',
    show_level: hmUI.show_level.ONLY_NORMAL,
});

normal_world_time_chr1_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
    x: 116,
    y: 150,
    image_array: ["CHR_INV_34.png", "CHR_INV_35.png", "CHR_INV_36.png", "CHR_INV_37.png", "CHR_INV_38.png", "CHR_INV_39.png", "CHR_INV_40.png", "CHR_INV_41.png", "CHR_INV_42.png", "CHR_INV_43.png", "CHR_INV_44.png", "CHR_INV_45.png", "CHR_INV_46.png", "CHR_INV_47.png", "CHR_INV_48.png", "CHR_INV_49.png", "CHR_INV_50.png", "CHR_INV_51.png", "CHR_INV_52.png", "CHR_INV_53.png", "CHR_INV_54.png", "CHR_INV_55.png", "CHR_INV_56.png", "CHR_INV_57.png", "CHR_INV_58.png", "CHR_INV_59.png"],
    image_length: 26,
    level: 7,
    show_level: hmUI.show_level.ONLY_NORMAL,
});
normal_world_time_chr2_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
    x: 140,
    y: 150,
    image_array: ["CHR_INV_34.png", "CHR_INV_35.png", "CHR_INV_36.png", "CHR_INV_37.png", "CHR_INV_38.png", "CHR_INV_39.png", "CHR_INV_40.png", "CHR_INV_41.png", "CHR_INV_42.png", "CHR_INV_43.png", "CHR_INV_44.png", "CHR_INV_45.png", "CHR_INV_46.png", "CHR_INV_47.png", "CHR_INV_48.png", "CHR_INV_49.png", "CHR_INV_50.png", "CHR_INV_51.png", "CHR_INV_52.png", "CHR_INV_53.png", "CHR_INV_54.png", "CHR_INV_55.png", "CHR_INV_56.png", "CHR_INV_57.png", "CHR_INV_58.png", "CHR_INV_59.png"],
    image_length: 26,
    level: 13,
    show_level: hmUI.show_level.ONLY_NORMAL,
});
normal_world_time_chr3_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
    x: 164,
    y: 150,
    image_array: ["CHR_INV_34.png", "CHR_INV_35.png", "CHR_INV_36.png", "CHR_INV_37.png", "CHR_INV_38.png", "CHR_INV_39.png", "CHR_INV_40.png", "CHR_INV_41.png", "CHR_INV_42.png", "CHR_INV_43.png", "CHR_INV_44.png", "CHR_INV_45.png", "CHR_INV_46.png", "CHR_INV_47.png", "CHR_INV_48.png", "CHR_INV_49.png", "CHR_INV_50.png", "CHR_INV_51.png", "CHR_INV_52.png", "CHR_INV_53.png", "CHR_INV_54.png", "CHR_INV_55.png", "CHR_INV_56.png", "CHR_INV_57.png", "CHR_INV_58.png", "CHR_INV_59.png"],
    image_length: 26,
    level: 20,
    show_level: hmUI.show_level.ONLY_NORMAL,
});

normal_top_text_line_01 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
    x: 48,
    y: 150,
    image_array: ["CHR_INV_01.png", "CHR_INV_02.png", "CHR_INV_03.png", "CHR_INV_04.png", "CHR_INV_05.png", "CHR_INV_06.png", "CHR_INV_07.png", "CHR_INV_08.png", "CHR_INV_09.png", "CHR_INV_10.png", "CHR_INV_11.png", "CHR_INV_12.png", "CHR_INV_13.png", "CHR_INV_14.png", "CHR_INV_15.png", "CHR_INV_16.png", "CHR_INV_17.png", "CHR_INV_18.png", "CHR_INV_19.png", "CHR_INV_20.png", "CHR_INV_21.png", "CHR_INV_22.png", "CHR_INV_23.png", "CHR_INV_24.png", "CHR_INV_25.png", "CHR_INV_26.png", "CHR_INV_27.png", "CHR_INV_28.png", "CHR_INV_29.png", "CHR_INV_30.png", "CHR_INV_31.png", "CHR_INV_32.png", "CHR_INV_33.png", "CHR_INV_34.png", "CHR_INV_35.png", "CHR_INV_36.png", "CHR_INV_37.png", "CHR_INV_38.png", "CHR_INV_39.png", "CHR_INV_40.png", "CHR_INV_41.png", "CHR_INV_42.png", "CHR_INV_43.png", "CHR_INV_44.png", "CHR_INV_45.png", "CHR_INV_46.png", "CHR_INV_47.png", "CHR_INV_48.png", "CHR_INV_49.png", "CHR_INV_50.png", "CHR_INV_51.png", "CHR_INV_52.png", "CHR_INV_53.png", "CHR_INV_54.png", "CHR_INV_55.png", "CHR_INV_56.png", "CHR_INV_57.png", "CHR_INV_58.png", "CHR_INV_59.png", "CHR_INV_60.png", "CHR_INV_61.png", "CHR_INV_62.png", "CHR_INV_63.png", "CHR_INV_64.png", "CHR_INV_65.png", "CHR_INV_66.png", "CHR_INV_67.png", "CHR_INV_68.png", "CHR_INV_69.png", "CHR_INV_70.png", "CHR_INV_71.png", "CHR_INV_72.png", "CHR_INV_73.png", "CHR_INV_74.png", "CHR_INV_75.png", "CHR_INV_76.png", "CHR_INV_77.png", "CHR_INV_78.png", "CHR_INV_79.png", "CHR_INV_80.png", "CHR_INV_81.png", "CHR_INV_82.png", "CHR_INV_83.png", "CHR_INV_84.png", "CHR_INV_85.png", "CHR_INV_86.png", "CHR_INV_87.png", "CHR_INV_88.png", "CHR_INV_89.png", "CHR_INV_90.png", "CHR_INV_91.png", "CHR_INV_92.png", "CHR_INV_93.png", "CHR_INV_94.png", "CHR_INV_95.png", "CHR_INV_96.png", "CHR_INV_97.png", "CHR_INV_98.png", "CHR_INV_99.png", "CHR_INV_100.png", "CHR_INV_101.png", "CHR_INV_102.png", "CHR_INV_103.png", "CHR_INV_104.png", "CHR_INV_105.png", "CHR_INV_106.png", "CHR_INV_107.png", "CHR_INV_108.png", "CHR_INV_109.png", "CHR_INV_110.png", "CHR_INV_111.png", "CHR_INV_112.png", "CHR_INV_113.png", "CHR_INV_114.png", "CHR_INV_115.png", "CHR_INV_116.png", "CHR_INV_117.png", "CHR_INV_118.png", "CHR_INV_119.png", "CHR_INV_120.png", "CHR_INV_121.png", "CHR_INV_122.png", "CHR_INV_123.png", "CHR_INV_124.png", "CHR_INV_125.png", "CHR_INV_126.png", "CHR_INV_127.png", "CHR_INV_128.png", "CHR_INV_129.png", "CHR_INV_130.png", "CHR_INV_131.png", "CHR_INV_132.png", "CHR_INV_133.png", "CHR_INV_134.png", "CHR_INV_135.png", "CHR_INV_136.png", "CHR_INV_137.png", "CHR_INV_138.png", "CHR_INV_139.png", "CHR_INV_140.png", "CHR_INV_141.png", "CHR_INV_142.png", "CHR_INV_143.png", "CHR_INV_144.png", "CHR_INV_145.png", "CHR_INV_146.png", "CHR_INV_147.png", "CHR_INV_148.png", "CHR_INV_149.png", "CHR_INV_150.png", "CHR_INV_151.png", "CHR_INV_152.png", "CHR_INV_153.png", "CHR_INV_154.png", "CHR_INV_155.png", "CHR_INV_156.png", "CHR_INV_157.png", "CHR_INV_158.png", "CHR_INV_159.png", "CHR_INV_160.png", "CHR_INV_161.png", "CHR_INV_162.png", "CHR_INV_163.png", "CHR_INV_164.png", "CHR_INV_165.png", "CHR_INV_166.png", "CHR_INV_167.png", "CHR_INV_168.png", "CHR_INV_169.png", "CHR_INV_170.png", "CHR_INV_171.png", "CHR_INV_172.png", "CHR_INV_173.png", "CHR_INV_174.png", "CHR_INV_175.png", "CHR_INV_176.png", "CHR_INV_177.png", "CHR_INV_178.png", "CHR_INV_179.png", "CHR_INV_180.png", "CHR_INV_181.png", "CHR_INV_182.png", "CHR_INV_183.png", "CHR_INV_184.png", "CHR_INV_185.png", "CHR_INV_186.png", "CHR_INV_187.png", "CHR_INV_188.png", "CHR_INV_189.png", "CHR_INV_190.png", "CHR_INV_191.png", "CHR_INV_192.png", "CHR_INV_193.png", "CHR_INV_194.png", "CHR_INV_195.png", "CHR_INV_196.png", "CHR_INV_197.png", "CHR_INV_198.png", "CHR_INV_199.png", "CHR_INV_200.png", "CHR_INV_201.png", "CHR_INV_202.png", "CHR_INV_203.png", "CHR_INV_204.png", "CHR_INV_205.png", "CHR_INV_206.png", "CHR_INV_207.png", "CHR_INV_208.png", "CHR_INV_209.png", "CHR_INV_210.png", "CHR_INV_211.png", "CHR_INV_212.png", "CHR_INV_213.png", "CHR_INV_214.png", "CHR_INV_215.png", "CHR_INV_216.png", "CHR_INV_217.png", "CHR_INV_218.png", "CHR_INV_219.png", "CHR_INV_220.png", "CHR_INV_221.png", "CHR_INV_222.png", "CHR_INV_223.png", "CHR_INV_224.png"],
    image_length: 224,
    level: 1,
    show_level: hmUI.show_level.ONLY_NORMAL,
});
normal_top_text_line_02 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
    x: 72,
    y: 150,
    image_array: ["CHR_INV_01.png", "CHR_INV_02.png", "CHR_INV_03.png", "CHR_INV_04.png", "CHR_INV_05.png", "CHR_INV_06.png", "CHR_INV_07.png", "CHR_INV_08.png", "CHR_INV_09.png", "CHR_INV_10.png", "CHR_INV_11.png", "CHR_INV_12.png", "CHR_INV_13.png", "CHR_INV_14.png", "CHR_INV_15.png", "CHR_INV_16.png", "CHR_INV_17.png", "CHR_INV_18.png", "CHR_INV_19.png", "CHR_INV_20.png", "CHR_INV_21.png", "CHR_INV_22.png", "CHR_INV_23.png", "CHR_INV_24.png", "CHR_INV_25.png", "CHR_INV_26.png", "CHR_INV_27.png", "CHR_INV_28.png", "CHR_INV_29.png", "CHR_INV_30.png", "CHR_INV_31.png", "CHR_INV_32.png", "CHR_INV_33.png", "CHR_INV_34.png", "CHR_INV_35.png", "CHR_INV_36.png", "CHR_INV_37.png", "CHR_INV_38.png", "CHR_INV_39.png", "CHR_INV_40.png", "CHR_INV_41.png", "CHR_INV_42.png", "CHR_INV_43.png", "CHR_INV_44.png", "CHR_INV_45.png", "CHR_INV_46.png", "CHR_INV_47.png", "CHR_INV_48.png", "CHR_INV_49.png", "CHR_INV_50.png", "CHR_INV_51.png", "CHR_INV_52.png", "CHR_INV_53.png", "CHR_INV_54.png", "CHR_INV_55.png", "CHR_INV_56.png", "CHR_INV_57.png", "CHR_INV_58.png", "CHR_INV_59.png", "CHR_INV_60.png", "CHR_INV_61.png", "CHR_INV_62.png", "CHR_INV_63.png", "CHR_INV_64.png", "CHR_INV_65.png", "CHR_INV_66.png", "CHR_INV_67.png", "CHR_INV_68.png", "CHR_INV_69.png", "CHR_INV_70.png", "CHR_INV_71.png", "CHR_INV_72.png", "CHR_INV_73.png", "CHR_INV_74.png", "CHR_INV_75.png", "CHR_INV_76.png", "CHR_INV_77.png", "CHR_INV_78.png", "CHR_INV_79.png", "CHR_INV_80.png", "CHR_INV_81.png", "CHR_INV_82.png", "CHR_INV_83.png", "CHR_INV_84.png", "CHR_INV_85.png", "CHR_INV_86.png", "CHR_INV_87.png", "CHR_INV_88.png", "CHR_INV_89.png", "CHR_INV_90.png", "CHR_INV_91.png", "CHR_INV_92.png", "CHR_INV_93.png", "CHR_INV_94.png", "CHR_INV_95.png", "CHR_INV_96.png", "CHR_INV_97.png", "CHR_INV_98.png", "CHR_INV_99.png", "CHR_INV_100.png", "CHR_INV_101.png", "CHR_INV_102.png", "CHR_INV_103.png", "CHR_INV_104.png", "CHR_INV_105.png", "CHR_INV_106.png", "CHR_INV_107.png", "CHR_INV_108.png", "CHR_INV_109.png", "CHR_INV_110.png", "CHR_INV_111.png", "CHR_INV_112.png", "CHR_INV_113.png", "CHR_INV_114.png", "CHR_INV_115.png", "CHR_INV_116.png", "CHR_INV_117.png", "CHR_INV_118.png", "CHR_INV_119.png", "CHR_INV_120.png", "CHR_INV_121.png", "CHR_INV_122.png", "CHR_INV_123.png", "CHR_INV_124.png", "CHR_INV_125.png", "CHR_INV_126.png", "CHR_INV_127.png", "CHR_INV_128.png", "CHR_INV_129.png", "CHR_INV_130.png", "CHR_INV_131.png", "CHR_INV_132.png", "CHR_INV_133.png", "CHR_INV_134.png", "CHR_INV_135.png", "CHR_INV_136.png", "CHR_INV_137.png", "CHR_INV_138.png", "CHR_INV_139.png", "CHR_INV_140.png", "CHR_INV_141.png", "CHR_INV_142.png", "CHR_INV_143.png", "CHR_INV_144.png", "CHR_INV_145.png", "CHR_INV_146.png", "CHR_INV_147.png", "CHR_INV_148.png", "CHR_INV_149.png", "CHR_INV_150.png", "CHR_INV_151.png", "CHR_INV_152.png", "CHR_INV_153.png", "CHR_INV_154.png", "CHR_INV_155.png", "CHR_INV_156.png", "CHR_INV_157.png", "CHR_INV_158.png", "CHR_INV_159.png", "CHR_INV_160.png", "CHR_INV_161.png", "CHR_INV_162.png", "CHR_INV_163.png", "CHR_INV_164.png", "CHR_INV_165.png", "CHR_INV_166.png", "CHR_INV_167.png", "CHR_INV_168.png", "CHR_INV_169.png", "CHR_INV_170.png", "CHR_INV_171.png", "CHR_INV_172.png", "CHR_INV_173.png", "CHR_INV_174.png", "CHR_INV_175.png", "CHR_INV_176.png", "CHR_INV_177.png", "CHR_INV_178.png", "CHR_INV_179.png", "CHR_INV_180.png", "CHR_INV_181.png", "CHR_INV_182.png", "CHR_INV_183.png", "CHR_INV_184.png", "CHR_INV_185.png", "CHR_INV_186.png", "CHR_INV_187.png", "CHR_INV_188.png", "CHR_INV_189.png", "CHR_INV_190.png", "CHR_INV_191.png", "CHR_INV_192.png", "CHR_INV_193.png", "CHR_INV_194.png", "CHR_INV_195.png", "CHR_INV_196.png", "CHR_INV_197.png", "CHR_INV_198.png", "CHR_INV_199.png", "CHR_INV_200.png", "CHR_INV_201.png", "CHR_INV_202.png", "CHR_INV_203.png", "CHR_INV_204.png", "CHR_INV_205.png", "CHR_INV_206.png", "CHR_INV_207.png", "CHR_INV_208.png", "CHR_INV_209.png", "CHR_INV_210.png", "CHR_INV_211.png", "CHR_INV_212.png", "CHR_INV_213.png", "CHR_INV_214.png", "CHR_INV_215.png", "CHR_INV_216.png", "CHR_INV_217.png", "CHR_INV_218.png", "CHR_INV_219.png", "CHR_INV_220.png", "CHR_INV_221.png", "CHR_INV_222.png", "CHR_INV_223.png", "CHR_INV_224.png"],
    image_length: 224,
    level: 1,
    show_level: hmUI.show_level.ONLY_NORMAL,
});
normal_top_text_line_03 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
    x: 96,
    y: 150,
    image_array: ["CHR_INV_01.png", "CHR_INV_02.png", "CHR_INV_03.png", "CHR_INV_04.png", "CHR_INV_05.png", "CHR_INV_06.png", "CHR_INV_07.png", "CHR_INV_08.png", "CHR_INV_09.png", "CHR_INV_10.png", "CHR_INV_11.png", "CHR_INV_12.png", "CHR_INV_13.png", "CHR_INV_14.png", "CHR_INV_15.png", "CHR_INV_16.png", "CHR_INV_17.png", "CHR_INV_18.png", "CHR_INV_19.png", "CHR_INV_20.png", "CHR_INV_21.png", "CHR_INV_22.png", "CHR_INV_23.png", "CHR_INV_24.png", "CHR_INV_25.png", "CHR_INV_26.png", "CHR_INV_27.png", "CHR_INV_28.png", "CHR_INV_29.png", "CHR_INV_30.png", "CHR_INV_31.png", "CHR_INV_32.png", "CHR_INV_33.png", "CHR_INV_34.png", "CHR_INV_35.png", "CHR_INV_36.png", "CHR_INV_37.png", "CHR_INV_38.png", "CHR_INV_39.png", "CHR_INV_40.png", "CHR_INV_41.png", "CHR_INV_42.png", "CHR_INV_43.png", "CHR_INV_44.png", "CHR_INV_45.png", "CHR_INV_46.png", "CHR_INV_47.png", "CHR_INV_48.png", "CHR_INV_49.png", "CHR_INV_50.png", "CHR_INV_51.png", "CHR_INV_52.png", "CHR_INV_53.png", "CHR_INV_54.png", "CHR_INV_55.png", "CHR_INV_56.png", "CHR_INV_57.png", "CHR_INV_58.png", "CHR_INV_59.png", "CHR_INV_60.png", "CHR_INV_61.png", "CHR_INV_62.png", "CHR_INV_63.png", "CHR_INV_64.png", "CHR_INV_65.png", "CHR_INV_66.png", "CHR_INV_67.png", "CHR_INV_68.png", "CHR_INV_69.png", "CHR_INV_70.png", "CHR_INV_71.png", "CHR_INV_72.png", "CHR_INV_73.png", "CHR_INV_74.png", "CHR_INV_75.png", "CHR_INV_76.png", "CHR_INV_77.png", "CHR_INV_78.png", "CHR_INV_79.png", "CHR_INV_80.png", "CHR_INV_81.png", "CHR_INV_82.png", "CHR_INV_83.png", "CHR_INV_84.png", "CHR_INV_85.png", "CHR_INV_86.png", "CHR_INV_87.png", "CHR_INV_88.png", "CHR_INV_89.png", "CHR_INV_90.png", "CHR_INV_91.png", "CHR_INV_92.png", "CHR_INV_93.png", "CHR_INV_94.png", "CHR_INV_95.png", "CHR_INV_96.png", "CHR_INV_97.png", "CHR_INV_98.png", "CHR_INV_99.png", "CHR_INV_100.png", "CHR_INV_101.png", "CHR_INV_102.png", "CHR_INV_103.png", "CHR_INV_104.png", "CHR_INV_105.png", "CHR_INV_106.png", "CHR_INV_107.png", "CHR_INV_108.png", "CHR_INV_109.png", "CHR_INV_110.png", "CHR_INV_111.png", "CHR_INV_112.png", "CHR_INV_113.png", "CHR_INV_114.png", "CHR_INV_115.png", "CHR_INV_116.png", "CHR_INV_117.png", "CHR_INV_118.png", "CHR_INV_119.png", "CHR_INV_120.png", "CHR_INV_121.png", "CHR_INV_122.png", "CHR_INV_123.png", "CHR_INV_124.png", "CHR_INV_125.png", "CHR_INV_126.png", "CHR_INV_127.png", "CHR_INV_128.png", "CHR_INV_129.png", "CHR_INV_130.png", "CHR_INV_131.png", "CHR_INV_132.png", "CHR_INV_133.png", "CHR_INV_134.png", "CHR_INV_135.png", "CHR_INV_136.png", "CHR_INV_137.png", "CHR_INV_138.png", "CHR_INV_139.png", "CHR_INV_140.png", "CHR_INV_141.png", "CHR_INV_142.png", "CHR_INV_143.png", "CHR_INV_144.png", "CHR_INV_145.png", "CHR_INV_146.png", "CHR_INV_147.png", "CHR_INV_148.png", "CHR_INV_149.png", "CHR_INV_150.png", "CHR_INV_151.png", "CHR_INV_152.png", "CHR_INV_153.png", "CHR_INV_154.png", "CHR_INV_155.png", "CHR_INV_156.png", "CHR_INV_157.png", "CHR_INV_158.png", "CHR_INV_159.png", "CHR_INV_160.png", "CHR_INV_161.png", "CHR_INV_162.png", "CHR_INV_163.png", "CHR_INV_164.png", "CHR_INV_165.png", "CHR_INV_166.png", "CHR_INV_167.png", "CHR_INV_168.png", "CHR_INV_169.png", "CHR_INV_170.png", "CHR_INV_171.png", "CHR_INV_172.png", "CHR_INV_173.png", "CHR_INV_174.png", "CHR_INV_175.png", "CHR_INV_176.png", "CHR_INV_177.png", "CHR_INV_178.png", "CHR_INV_179.png", "CHR_INV_180.png", "CHR_INV_181.png", "CHR_INV_182.png", "CHR_INV_183.png", "CHR_INV_184.png", "CHR_INV_185.png", "CHR_INV_186.png", "CHR_INV_187.png", "CHR_INV_188.png", "CHR_INV_189.png", "CHR_INV_190.png", "CHR_INV_191.png", "CHR_INV_192.png", "CHR_INV_193.png", "CHR_INV_194.png", "CHR_INV_195.png", "CHR_INV_196.png", "CHR_INV_197.png", "CHR_INV_198.png", "CHR_INV_199.png", "CHR_INV_200.png", "CHR_INV_201.png", "CHR_INV_202.png", "CHR_INV_203.png", "CHR_INV_204.png", "CHR_INV_205.png", "CHR_INV_206.png", "CHR_INV_207.png", "CHR_INV_208.png", "CHR_INV_209.png", "CHR_INV_210.png", "CHR_INV_211.png", "CHR_INV_212.png", "CHR_INV_213.png", "CHR_INV_214.png", "CHR_INV_215.png", "CHR_INV_216.png", "CHR_INV_217.png", "CHR_INV_218.png", "CHR_INV_219.png", "CHR_INV_220.png", "CHR_INV_221.png", "CHR_INV_222.png", "CHR_INV_223.png", "CHR_INV_224.png"],
    image_length: 224,
    level: 1,
    show_level: hmUI.show_level.ONLY_NORMAL,
});
normal_top_text_line_04 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
    x: 120,
    y: 150,
    image_array: ["CHR_INV_01.png", "CHR_INV_02.png", "CHR_INV_03.png", "CHR_INV_04.png", "CHR_INV_05.png", "CHR_INV_06.png", "CHR_INV_07.png", "CHR_INV_08.png", "CHR_INV_09.png", "CHR_INV_10.png", "CHR_INV_11.png", "CHR_INV_12.png", "CHR_INV_13.png", "CHR_INV_14.png", "CHR_INV_15.png", "CHR_INV_16.png", "CHR_INV_17.png", "CHR_INV_18.png", "CHR_INV_19.png", "CHR_INV_20.png", "CHR_INV_21.png", "CHR_INV_22.png", "CHR_INV_23.png", "CHR_INV_24.png", "CHR_INV_25.png", "CHR_INV_26.png", "CHR_INV_27.png", "CHR_INV_28.png", "CHR_INV_29.png", "CHR_INV_30.png", "CHR_INV_31.png", "CHR_INV_32.png", "CHR_INV_33.png", "CHR_INV_34.png", "CHR_INV_35.png", "CHR_INV_36.png", "CHR_INV_37.png", "CHR_INV_38.png", "CHR_INV_39.png", "CHR_INV_40.png", "CHR_INV_41.png", "CHR_INV_42.png", "CHR_INV_43.png", "CHR_INV_44.png", "CHR_INV_45.png", "CHR_INV_46.png", "CHR_INV_47.png", "CHR_INV_48.png", "CHR_INV_49.png", "CHR_INV_50.png", "CHR_INV_51.png", "CHR_INV_52.png", "CHR_INV_53.png", "CHR_INV_54.png", "CHR_INV_55.png", "CHR_INV_56.png", "CHR_INV_57.png", "CHR_INV_58.png", "CHR_INV_59.png", "CHR_INV_60.png", "CHR_INV_61.png", "CHR_INV_62.png", "CHR_INV_63.png", "CHR_INV_64.png", "CHR_INV_65.png", "CHR_INV_66.png", "CHR_INV_67.png", "CHR_INV_68.png", "CHR_INV_69.png", "CHR_INV_70.png", "CHR_INV_71.png", "CHR_INV_72.png", "CHR_INV_73.png", "CHR_INV_74.png", "CHR_INV_75.png", "CHR_INV_76.png", "CHR_INV_77.png", "CHR_INV_78.png", "CHR_INV_79.png", "CHR_INV_80.png", "CHR_INV_81.png", "CHR_INV_82.png", "CHR_INV_83.png", "CHR_INV_84.png", "CHR_INV_85.png", "CHR_INV_86.png", "CHR_INV_87.png", "CHR_INV_88.png", "CHR_INV_89.png", "CHR_INV_90.png", "CHR_INV_91.png", "CHR_INV_92.png", "CHR_INV_93.png", "CHR_INV_94.png", "CHR_INV_95.png", "CHR_INV_96.png", "CHR_INV_97.png", "CHR_INV_98.png", "CHR_INV_99.png", "CHR_INV_100.png", "CHR_INV_101.png", "CHR_INV_102.png", "CHR_INV_103.png", "CHR_INV_104.png", "CHR_INV_105.png", "CHR_INV_106.png", "CHR_INV_107.png", "CHR_INV_108.png", "CHR_INV_109.png", "CHR_INV_110.png", "CHR_INV_111.png", "CHR_INV_112.png", "CHR_INV_113.png", "CHR_INV_114.png", "CHR_INV_115.png", "CHR_INV_116.png", "CHR_INV_117.png", "CHR_INV_118.png", "CHR_INV_119.png", "CHR_INV_120.png", "CHR_INV_121.png", "CHR_INV_122.png", "CHR_INV_123.png", "CHR_INV_124.png", "CHR_INV_125.png", "CHR_INV_126.png", "CHR_INV_127.png", "CHR_INV_128.png", "CHR_INV_129.png", "CHR_INV_130.png", "CHR_INV_131.png", "CHR_INV_132.png", "CHR_INV_133.png", "CHR_INV_134.png", "CHR_INV_135.png", "CHR_INV_136.png", "CHR_INV_137.png", "CHR_INV_138.png", "CHR_INV_139.png", "CHR_INV_140.png", "CHR_INV_141.png", "CHR_INV_142.png", "CHR_INV_143.png", "CHR_INV_144.png", "CHR_INV_145.png", "CHR_INV_146.png", "CHR_INV_147.png", "CHR_INV_148.png", "CHR_INV_149.png", "CHR_INV_150.png", "CHR_INV_151.png", "CHR_INV_152.png", "CHR_INV_153.png", "CHR_INV_154.png", "CHR_INV_155.png", "CHR_INV_156.png", "CHR_INV_157.png", "CHR_INV_158.png", "CHR_INV_159.png", "CHR_INV_160.png", "CHR_INV_161.png", "CHR_INV_162.png", "CHR_INV_163.png", "CHR_INV_164.png", "CHR_INV_165.png", "CHR_INV_166.png", "CHR_INV_167.png", "CHR_INV_168.png", "CHR_INV_169.png", "CHR_INV_170.png", "CHR_INV_171.png", "CHR_INV_172.png", "CHR_INV_173.png", "CHR_INV_174.png", "CHR_INV_175.png", "CHR_INV_176.png", "CHR_INV_177.png", "CHR_INV_178.png", "CHR_INV_179.png", "CHR_INV_180.png", "CHR_INV_181.png", "CHR_INV_182.png", "CHR_INV_183.png", "CHR_INV_184.png", "CHR_INV_185.png", "CHR_INV_186.png", "CHR_INV_187.png", "CHR_INV_188.png", "CHR_INV_189.png", "CHR_INV_190.png", "CHR_INV_191.png", "CHR_INV_192.png", "CHR_INV_193.png", "CHR_INV_194.png", "CHR_INV_195.png", "CHR_INV_196.png", "CHR_INV_197.png", "CHR_INV_198.png", "CHR_INV_199.png", "CHR_INV_200.png", "CHR_INV_201.png", "CHR_INV_202.png", "CHR_INV_203.png", "CHR_INV_204.png", "CHR_INV_205.png", "CHR_INV_206.png", "CHR_INV_207.png", "CHR_INV_208.png", "CHR_INV_209.png", "CHR_INV_210.png", "CHR_INV_211.png", "CHR_INV_212.png", "CHR_INV_213.png", "CHR_INV_214.png", "CHR_INV_215.png", "CHR_INV_216.png", "CHR_INV_217.png", "CHR_INV_218.png", "CHR_INV_219.png", "CHR_INV_220.png", "CHR_INV_221.png", "CHR_INV_222.png", "CHR_INV_223.png", "CHR_INV_224.png"],
    image_length: 224,
    level: 1,
    show_level: hmUI.show_level.ONLY_NORMAL,
});
normal_top_text_line_05 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
    x: 144,
    y: 150,
    image_array: ["CHR_INV_01.png", "CHR_INV_02.png", "CHR_INV_03.png", "CHR_INV_04.png", "CHR_INV_05.png", "CHR_INV_06.png", "CHR_INV_07.png", "CHR_INV_08.png", "CHR_INV_09.png", "CHR_INV_10.png", "CHR_INV_11.png", "CHR_INV_12.png", "CHR_INV_13.png", "CHR_INV_14.png", "CHR_INV_15.png", "CHR_INV_16.png", "CHR_INV_17.png", "CHR_INV_18.png", "CHR_INV_19.png", "CHR_INV_20.png", "CHR_INV_21.png", "CHR_INV_22.png", "CHR_INV_23.png", "CHR_INV_24.png", "CHR_INV_25.png", "CHR_INV_26.png", "CHR_INV_27.png", "CHR_INV_28.png", "CHR_INV_29.png", "CHR_INV_30.png", "CHR_INV_31.png", "CHR_INV_32.png", "CHR_INV_33.png", "CHR_INV_34.png", "CHR_INV_35.png", "CHR_INV_36.png", "CHR_INV_37.png", "CHR_INV_38.png", "CHR_INV_39.png", "CHR_INV_40.png", "CHR_INV_41.png", "CHR_INV_42.png", "CHR_INV_43.png", "CHR_INV_44.png", "CHR_INV_45.png", "CHR_INV_46.png", "CHR_INV_47.png", "CHR_INV_48.png", "CHR_INV_49.png", "CHR_INV_50.png", "CHR_INV_51.png", "CHR_INV_52.png", "CHR_INV_53.png", "CHR_INV_54.png", "CHR_INV_55.png", "CHR_INV_56.png", "CHR_INV_57.png", "CHR_INV_58.png", "CHR_INV_59.png", "CHR_INV_60.png", "CHR_INV_61.png", "CHR_INV_62.png", "CHR_INV_63.png", "CHR_INV_64.png", "CHR_INV_65.png", "CHR_INV_66.png", "CHR_INV_67.png", "CHR_INV_68.png", "CHR_INV_69.png", "CHR_INV_70.png", "CHR_INV_71.png", "CHR_INV_72.png", "CHR_INV_73.png", "CHR_INV_74.png", "CHR_INV_75.png", "CHR_INV_76.png", "CHR_INV_77.png", "CHR_INV_78.png", "CHR_INV_79.png", "CHR_INV_80.png", "CHR_INV_81.png", "CHR_INV_82.png", "CHR_INV_83.png", "CHR_INV_84.png", "CHR_INV_85.png", "CHR_INV_86.png", "CHR_INV_87.png", "CHR_INV_88.png", "CHR_INV_89.png", "CHR_INV_90.png", "CHR_INV_91.png", "CHR_INV_92.png", "CHR_INV_93.png", "CHR_INV_94.png", "CHR_INV_95.png", "CHR_INV_96.png", "CHR_INV_97.png", "CHR_INV_98.png", "CHR_INV_99.png", "CHR_INV_100.png", "CHR_INV_101.png", "CHR_INV_102.png", "CHR_INV_103.png", "CHR_INV_104.png", "CHR_INV_105.png", "CHR_INV_106.png", "CHR_INV_107.png", "CHR_INV_108.png", "CHR_INV_109.png", "CHR_INV_110.png", "CHR_INV_111.png", "CHR_INV_112.png", "CHR_INV_113.png", "CHR_INV_114.png", "CHR_INV_115.png", "CHR_INV_116.png", "CHR_INV_117.png", "CHR_INV_118.png", "CHR_INV_119.png", "CHR_INV_120.png", "CHR_INV_121.png", "CHR_INV_122.png", "CHR_INV_123.png", "CHR_INV_124.png", "CHR_INV_125.png", "CHR_INV_126.png", "CHR_INV_127.png", "CHR_INV_128.png", "CHR_INV_129.png", "CHR_INV_130.png", "CHR_INV_131.png", "CHR_INV_132.png", "CHR_INV_133.png", "CHR_INV_134.png", "CHR_INV_135.png", "CHR_INV_136.png", "CHR_INV_137.png", "CHR_INV_138.png", "CHR_INV_139.png", "CHR_INV_140.png", "CHR_INV_141.png", "CHR_INV_142.png", "CHR_INV_143.png", "CHR_INV_144.png", "CHR_INV_145.png", "CHR_INV_146.png", "CHR_INV_147.png", "CHR_INV_148.png", "CHR_INV_149.png", "CHR_INV_150.png", "CHR_INV_151.png", "CHR_INV_152.png", "CHR_INV_153.png", "CHR_INV_154.png", "CHR_INV_155.png", "CHR_INV_156.png", "CHR_INV_157.png", "CHR_INV_158.png", "CHR_INV_159.png", "CHR_INV_160.png", "CHR_INV_161.png", "CHR_INV_162.png", "CHR_INV_163.png", "CHR_INV_164.png", "CHR_INV_165.png", "CHR_INV_166.png", "CHR_INV_167.png", "CHR_INV_168.png", "CHR_INV_169.png", "CHR_INV_170.png", "CHR_INV_171.png", "CHR_INV_172.png", "CHR_INV_173.png", "CHR_INV_174.png", "CHR_INV_175.png", "CHR_INV_176.png", "CHR_INV_177.png", "CHR_INV_178.png", "CHR_INV_179.png", "CHR_INV_180.png", "CHR_INV_181.png", "CHR_INV_182.png", "CHR_INV_183.png", "CHR_INV_184.png", "CHR_INV_185.png", "CHR_INV_186.png", "CHR_INV_187.png", "CHR_INV_188.png", "CHR_INV_189.png", "CHR_INV_190.png", "CHR_INV_191.png", "CHR_INV_192.png", "CHR_INV_193.png", "CHR_INV_194.png", "CHR_INV_195.png", "CHR_INV_196.png", "CHR_INV_197.png", "CHR_INV_198.png", "CHR_INV_199.png", "CHR_INV_200.png", "CHR_INV_201.png", "CHR_INV_202.png", "CHR_INV_203.png", "CHR_INV_204.png", "CHR_INV_205.png", "CHR_INV_206.png", "CHR_INV_207.png", "CHR_INV_208.png", "CHR_INV_209.png", "CHR_INV_210.png", "CHR_INV_211.png", "CHR_INV_212.png", "CHR_INV_213.png", "CHR_INV_214.png", "CHR_INV_215.png", "CHR_INV_216.png", "CHR_INV_217.png", "CHR_INV_218.png", "CHR_INV_219.png", "CHR_INV_220.png", "CHR_INV_221.png", "CHR_INV_222.png", "CHR_INV_223.png", "CHR_INV_224.png"],
    image_length: 224,
    level: 1,
    show_level: hmUI.show_level.ONLY_NORMAL,
});
normal_top_text_line_06 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
    x: 168,
    y: 150,
    image_array: ["CHR_INV_01.png", "CHR_INV_02.png", "CHR_INV_03.png", "CHR_INV_04.png", "CHR_INV_05.png", "CHR_INV_06.png", "CHR_INV_07.png", "CHR_INV_08.png", "CHR_INV_09.png", "CHR_INV_10.png", "CHR_INV_11.png", "CHR_INV_12.png", "CHR_INV_13.png", "CHR_INV_14.png", "CHR_INV_15.png", "CHR_INV_16.png", "CHR_INV_17.png", "CHR_INV_18.png", "CHR_INV_19.png", "CHR_INV_20.png", "CHR_INV_21.png", "CHR_INV_22.png", "CHR_INV_23.png", "CHR_INV_24.png", "CHR_INV_25.png", "CHR_INV_26.png", "CHR_INV_27.png", "CHR_INV_28.png", "CHR_INV_29.png", "CHR_INV_30.png", "CHR_INV_31.png", "CHR_INV_32.png", "CHR_INV_33.png", "CHR_INV_34.png", "CHR_INV_35.png", "CHR_INV_36.png", "CHR_INV_37.png", "CHR_INV_38.png", "CHR_INV_39.png", "CHR_INV_40.png", "CHR_INV_41.png", "CHR_INV_42.png", "CHR_INV_43.png", "CHR_INV_44.png", "CHR_INV_45.png", "CHR_INV_46.png", "CHR_INV_47.png", "CHR_INV_48.png", "CHR_INV_49.png", "CHR_INV_50.png", "CHR_INV_51.png", "CHR_INV_52.png", "CHR_INV_53.png", "CHR_INV_54.png", "CHR_INV_55.png", "CHR_INV_56.png", "CHR_INV_57.png", "CHR_INV_58.png", "CHR_INV_59.png", "CHR_INV_60.png", "CHR_INV_61.png", "CHR_INV_62.png", "CHR_INV_63.png", "CHR_INV_64.png", "CHR_INV_65.png", "CHR_INV_66.png", "CHR_INV_67.png", "CHR_INV_68.png", "CHR_INV_69.png", "CHR_INV_70.png", "CHR_INV_71.png", "CHR_INV_72.png", "CHR_INV_73.png", "CHR_INV_74.png", "CHR_INV_75.png", "CHR_INV_76.png", "CHR_INV_77.png", "CHR_INV_78.png", "CHR_INV_79.png", "CHR_INV_80.png", "CHR_INV_81.png", "CHR_INV_82.png", "CHR_INV_83.png", "CHR_INV_84.png", "CHR_INV_85.png", "CHR_INV_86.png", "CHR_INV_87.png", "CHR_INV_88.png", "CHR_INV_89.png", "CHR_INV_90.png", "CHR_INV_91.png", "CHR_INV_92.png", "CHR_INV_93.png", "CHR_INV_94.png", "CHR_INV_95.png", "CHR_INV_96.png", "CHR_INV_97.png", "CHR_INV_98.png", "CHR_INV_99.png", "CHR_INV_100.png", "CHR_INV_101.png", "CHR_INV_102.png", "CHR_INV_103.png", "CHR_INV_104.png", "CHR_INV_105.png", "CHR_INV_106.png", "CHR_INV_107.png", "CHR_INV_108.png", "CHR_INV_109.png", "CHR_INV_110.png", "CHR_INV_111.png", "CHR_INV_112.png", "CHR_INV_113.png", "CHR_INV_114.png", "CHR_INV_115.png", "CHR_INV_116.png", "CHR_INV_117.png", "CHR_INV_118.png", "CHR_INV_119.png", "CHR_INV_120.png", "CHR_INV_121.png", "CHR_INV_122.png", "CHR_INV_123.png", "CHR_INV_124.png", "CHR_INV_125.png", "CHR_INV_126.png", "CHR_INV_127.png", "CHR_INV_128.png", "CHR_INV_129.png", "CHR_INV_130.png", "CHR_INV_131.png", "CHR_INV_132.png", "CHR_INV_133.png", "CHR_INV_134.png", "CHR_INV_135.png", "CHR_INV_136.png", "CHR_INV_137.png", "CHR_INV_138.png", "CHR_INV_139.png", "CHR_INV_140.png", "CHR_INV_141.png", "CHR_INV_142.png", "CHR_INV_143.png", "CHR_INV_144.png", "CHR_INV_145.png", "CHR_INV_146.png", "CHR_INV_147.png", "CHR_INV_148.png", "CHR_INV_149.png", "CHR_INV_150.png", "CHR_INV_151.png", "CHR_INV_152.png", "CHR_INV_153.png", "CHR_INV_154.png", "CHR_INV_155.png", "CHR_INV_156.png", "CHR_INV_157.png", "CHR_INV_158.png", "CHR_INV_159.png", "CHR_INV_160.png", "CHR_INV_161.png", "CHR_INV_162.png", "CHR_INV_163.png", "CHR_INV_164.png", "CHR_INV_165.png", "CHR_INV_166.png", "CHR_INV_167.png", "CHR_INV_168.png", "CHR_INV_169.png", "CHR_INV_170.png", "CHR_INV_171.png", "CHR_INV_172.png", "CHR_INV_173.png", "CHR_INV_174.png", "CHR_INV_175.png", "CHR_INV_176.png", "CHR_INV_177.png", "CHR_INV_178.png", "CHR_INV_179.png", "CHR_INV_180.png", "CHR_INV_181.png", "CHR_INV_182.png", "CHR_INV_183.png", "CHR_INV_184.png", "CHR_INV_185.png", "CHR_INV_186.png", "CHR_INV_187.png", "CHR_INV_188.png", "CHR_INV_189.png", "CHR_INV_190.png", "CHR_INV_191.png", "CHR_INV_192.png", "CHR_INV_193.png", "CHR_INV_194.png", "CHR_INV_195.png", "CHR_INV_196.png", "CHR_INV_197.png", "CHR_INV_198.png", "CHR_INV_199.png", "CHR_INV_200.png", "CHR_INV_201.png", "CHR_INV_202.png", "CHR_INV_203.png", "CHR_INV_204.png", "CHR_INV_205.png", "CHR_INV_206.png", "CHR_INV_207.png", "CHR_INV_208.png", "CHR_INV_209.png", "CHR_INV_210.png", "CHR_INV_211.png", "CHR_INV_212.png", "CHR_INV_213.png", "CHR_INV_214.png", "CHR_INV_215.png", "CHR_INV_216.png", "CHR_INV_217.png", "CHR_INV_218.png", "CHR_INV_219.png", "CHR_INV_220.png", "CHR_INV_221.png", "CHR_INV_222.png", "CHR_INV_223.png", "CHR_INV_224.png"],
    image_length: 224,
    level: 1,
    show_level: hmUI.show_level.ONLY_NORMAL,
});
normal_top_text_line_07 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
    x: 192,
    y: 150,
    image_array: ["CHR_INV_01.png", "CHR_INV_02.png", "CHR_INV_03.png", "CHR_INV_04.png", "CHR_INV_05.png", "CHR_INV_06.png", "CHR_INV_07.png", "CHR_INV_08.png", "CHR_INV_09.png", "CHR_INV_10.png", "CHR_INV_11.png", "CHR_INV_12.png", "CHR_INV_13.png", "CHR_INV_14.png", "CHR_INV_15.png", "CHR_INV_16.png", "CHR_INV_17.png", "CHR_INV_18.png", "CHR_INV_19.png", "CHR_INV_20.png", "CHR_INV_21.png", "CHR_INV_22.png", "CHR_INV_23.png", "CHR_INV_24.png", "CHR_INV_25.png", "CHR_INV_26.png", "CHR_INV_27.png", "CHR_INV_28.png", "CHR_INV_29.png", "CHR_INV_30.png", "CHR_INV_31.png", "CHR_INV_32.png", "CHR_INV_33.png", "CHR_INV_34.png", "CHR_INV_35.png", "CHR_INV_36.png", "CHR_INV_37.png", "CHR_INV_38.png", "CHR_INV_39.png", "CHR_INV_40.png", "CHR_INV_41.png", "CHR_INV_42.png", "CHR_INV_43.png", "CHR_INV_44.png", "CHR_INV_45.png", "CHR_INV_46.png", "CHR_INV_47.png", "CHR_INV_48.png", "CHR_INV_49.png", "CHR_INV_50.png", "CHR_INV_51.png", "CHR_INV_52.png", "CHR_INV_53.png", "CHR_INV_54.png", "CHR_INV_55.png", "CHR_INV_56.png", "CHR_INV_57.png", "CHR_INV_58.png", "CHR_INV_59.png", "CHR_INV_60.png", "CHR_INV_61.png", "CHR_INV_62.png", "CHR_INV_63.png", "CHR_INV_64.png", "CHR_INV_65.png", "CHR_INV_66.png", "CHR_INV_67.png", "CHR_INV_68.png", "CHR_INV_69.png", "CHR_INV_70.png", "CHR_INV_71.png", "CHR_INV_72.png", "CHR_INV_73.png", "CHR_INV_74.png", "CHR_INV_75.png", "CHR_INV_76.png", "CHR_INV_77.png", "CHR_INV_78.png", "CHR_INV_79.png", "CHR_INV_80.png", "CHR_INV_81.png", "CHR_INV_82.png", "CHR_INV_83.png", "CHR_INV_84.png", "CHR_INV_85.png", "CHR_INV_86.png", "CHR_INV_87.png", "CHR_INV_88.png", "CHR_INV_89.png", "CHR_INV_90.png", "CHR_INV_91.png", "CHR_INV_92.png", "CHR_INV_93.png", "CHR_INV_94.png", "CHR_INV_95.png", "CHR_INV_96.png", "CHR_INV_97.png", "CHR_INV_98.png", "CHR_INV_99.png", "CHR_INV_100.png", "CHR_INV_101.png", "CHR_INV_102.png", "CHR_INV_103.png", "CHR_INV_104.png", "CHR_INV_105.png", "CHR_INV_106.png", "CHR_INV_107.png", "CHR_INV_108.png", "CHR_INV_109.png", "CHR_INV_110.png", "CHR_INV_111.png", "CHR_INV_112.png", "CHR_INV_113.png", "CHR_INV_114.png", "CHR_INV_115.png", "CHR_INV_116.png", "CHR_INV_117.png", "CHR_INV_118.png", "CHR_INV_119.png", "CHR_INV_120.png", "CHR_INV_121.png", "CHR_INV_122.png", "CHR_INV_123.png", "CHR_INV_124.png", "CHR_INV_125.png", "CHR_INV_126.png", "CHR_INV_127.png", "CHR_INV_128.png", "CHR_INV_129.png", "CHR_INV_130.png", "CHR_INV_131.png", "CHR_INV_132.png", "CHR_INV_133.png", "CHR_INV_134.png", "CHR_INV_135.png", "CHR_INV_136.png", "CHR_INV_137.png", "CHR_INV_138.png", "CHR_INV_139.png", "CHR_INV_140.png", "CHR_INV_141.png", "CHR_INV_142.png", "CHR_INV_143.png", "CHR_INV_144.png", "CHR_INV_145.png", "CHR_INV_146.png", "CHR_INV_147.png", "CHR_INV_148.png", "CHR_INV_149.png", "CHR_INV_150.png", "CHR_INV_151.png", "CHR_INV_152.png", "CHR_INV_153.png", "CHR_INV_154.png", "CHR_INV_155.png", "CHR_INV_156.png", "CHR_INV_157.png", "CHR_INV_158.png", "CHR_INV_159.png", "CHR_INV_160.png", "CHR_INV_161.png", "CHR_INV_162.png", "CHR_INV_163.png", "CHR_INV_164.png", "CHR_INV_165.png", "CHR_INV_166.png", "CHR_INV_167.png", "CHR_INV_168.png", "CHR_INV_169.png", "CHR_INV_170.png", "CHR_INV_171.png", "CHR_INV_172.png", "CHR_INV_173.png", "CHR_INV_174.png", "CHR_INV_175.png", "CHR_INV_176.png", "CHR_INV_177.png", "CHR_INV_178.png", "CHR_INV_179.png", "CHR_INV_180.png", "CHR_INV_181.png", "CHR_INV_182.png", "CHR_INV_183.png", "CHR_INV_184.png", "CHR_INV_185.png", "CHR_INV_186.png", "CHR_INV_187.png", "CHR_INV_188.png", "CHR_INV_189.png", "CHR_INV_190.png", "CHR_INV_191.png", "CHR_INV_192.png", "CHR_INV_193.png", "CHR_INV_194.png", "CHR_INV_195.png", "CHR_INV_196.png", "CHR_INV_197.png", "CHR_INV_198.png", "CHR_INV_199.png", "CHR_INV_200.png", "CHR_INV_201.png", "CHR_INV_202.png", "CHR_INV_203.png", "CHR_INV_204.png", "CHR_INV_205.png", "CHR_INV_206.png", "CHR_INV_207.png", "CHR_INV_208.png", "CHR_INV_209.png", "CHR_INV_210.png", "CHR_INV_211.png", "CHR_INV_212.png", "CHR_INV_213.png", "CHR_INV_214.png", "CHR_INV_215.png", "CHR_INV_216.png", "CHR_INV_217.png", "CHR_INV_218.png", "CHR_INV_219.png", "CHR_INV_220.png", "CHR_INV_221.png", "CHR_INV_222.png", "CHR_INV_223.png", "CHR_INV_224.png"],
    image_length: 224,
    level: 1,
    show_level: hmUI.show_level.ONLY_NORMAL,
});
normal_top_text_line_08 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
    x: 216,
    y: 150,
    image_array: ["CHR_INV_01.png", "CHR_INV_02.png", "CHR_INV_03.png", "CHR_INV_04.png", "CHR_INV_05.png", "CHR_INV_06.png", "CHR_INV_07.png", "CHR_INV_08.png", "CHR_INV_09.png", "CHR_INV_10.png", "CHR_INV_11.png", "CHR_INV_12.png", "CHR_INV_13.png", "CHR_INV_14.png", "CHR_INV_15.png", "CHR_INV_16.png", "CHR_INV_17.png", "CHR_INV_18.png", "CHR_INV_19.png", "CHR_INV_20.png", "CHR_INV_21.png", "CHR_INV_22.png", "CHR_INV_23.png", "CHR_INV_24.png", "CHR_INV_25.png", "CHR_INV_26.png", "CHR_INV_27.png", "CHR_INV_28.png", "CHR_INV_29.png", "CHR_INV_30.png", "CHR_INV_31.png", "CHR_INV_32.png", "CHR_INV_33.png", "CHR_INV_34.png", "CHR_INV_35.png", "CHR_INV_36.png", "CHR_INV_37.png", "CHR_INV_38.png", "CHR_INV_39.png", "CHR_INV_40.png", "CHR_INV_41.png", "CHR_INV_42.png", "CHR_INV_43.png", "CHR_INV_44.png", "CHR_INV_45.png", "CHR_INV_46.png", "CHR_INV_47.png", "CHR_INV_48.png", "CHR_INV_49.png", "CHR_INV_50.png", "CHR_INV_51.png", "CHR_INV_52.png", "CHR_INV_53.png", "CHR_INV_54.png", "CHR_INV_55.png", "CHR_INV_56.png", "CHR_INV_57.png", "CHR_INV_58.png", "CHR_INV_59.png", "CHR_INV_60.png", "CHR_INV_61.png", "CHR_INV_62.png", "CHR_INV_63.png", "CHR_INV_64.png", "CHR_INV_65.png", "CHR_INV_66.png", "CHR_INV_67.png", "CHR_INV_68.png", "CHR_INV_69.png", "CHR_INV_70.png", "CHR_INV_71.png", "CHR_INV_72.png", "CHR_INV_73.png", "CHR_INV_74.png", "CHR_INV_75.png", "CHR_INV_76.png", "CHR_INV_77.png", "CHR_INV_78.png", "CHR_INV_79.png", "CHR_INV_80.png", "CHR_INV_81.png", "CHR_INV_82.png", "CHR_INV_83.png", "CHR_INV_84.png", "CHR_INV_85.png", "CHR_INV_86.png", "CHR_INV_87.png", "CHR_INV_88.png", "CHR_INV_89.png", "CHR_INV_90.png", "CHR_INV_91.png", "CHR_INV_92.png", "CHR_INV_93.png", "CHR_INV_94.png", "CHR_INV_95.png", "CHR_INV_96.png", "CHR_INV_97.png", "CHR_INV_98.png", "CHR_INV_99.png", "CHR_INV_100.png", "CHR_INV_101.png", "CHR_INV_102.png", "CHR_INV_103.png", "CHR_INV_104.png", "CHR_INV_105.png", "CHR_INV_106.png", "CHR_INV_107.png", "CHR_INV_108.png", "CHR_INV_109.png", "CHR_INV_110.png", "CHR_INV_111.png", "CHR_INV_112.png", "CHR_INV_113.png", "CHR_INV_114.png", "CHR_INV_115.png", "CHR_INV_116.png", "CHR_INV_117.png", "CHR_INV_118.png", "CHR_INV_119.png", "CHR_INV_120.png", "CHR_INV_121.png", "CHR_INV_122.png", "CHR_INV_123.png", "CHR_INV_124.png", "CHR_INV_125.png", "CHR_INV_126.png", "CHR_INV_127.png", "CHR_INV_128.png", "CHR_INV_129.png", "CHR_INV_130.png", "CHR_INV_131.png", "CHR_INV_132.png", "CHR_INV_133.png", "CHR_INV_134.png", "CHR_INV_135.png", "CHR_INV_136.png", "CHR_INV_137.png", "CHR_INV_138.png", "CHR_INV_139.png", "CHR_INV_140.png", "CHR_INV_141.png", "CHR_INV_142.png", "CHR_INV_143.png", "CHR_INV_144.png", "CHR_INV_145.png", "CHR_INV_146.png", "CHR_INV_147.png", "CHR_INV_148.png", "CHR_INV_149.png", "CHR_INV_150.png", "CHR_INV_151.png", "CHR_INV_152.png", "CHR_INV_153.png", "CHR_INV_154.png", "CHR_INV_155.png", "CHR_INV_156.png", "CHR_INV_157.png", "CHR_INV_158.png", "CHR_INV_159.png", "CHR_INV_160.png", "CHR_INV_161.png", "CHR_INV_162.png", "CHR_INV_163.png", "CHR_INV_164.png", "CHR_INV_165.png", "CHR_INV_166.png", "CHR_INV_167.png", "CHR_INV_168.png", "CHR_INV_169.png", "CHR_INV_170.png", "CHR_INV_171.png", "CHR_INV_172.png", "CHR_INV_173.png", "CHR_INV_174.png", "CHR_INV_175.png", "CHR_INV_176.png", "CHR_INV_177.png", "CHR_INV_178.png", "CHR_INV_179.png", "CHR_INV_180.png", "CHR_INV_181.png", "CHR_INV_182.png", "CHR_INV_183.png", "CHR_INV_184.png", "CHR_INV_185.png", "CHR_INV_186.png", "CHR_INV_187.png", "CHR_INV_188.png", "CHR_INV_189.png", "CHR_INV_190.png", "CHR_INV_191.png", "CHR_INV_192.png", "CHR_INV_193.png", "CHR_INV_194.png", "CHR_INV_195.png", "CHR_INV_196.png", "CHR_INV_197.png", "CHR_INV_198.png", "CHR_INV_199.png", "CHR_INV_200.png", "CHR_INV_201.png", "CHR_INV_202.png", "CHR_INV_203.png", "CHR_INV_204.png", "CHR_INV_205.png", "CHR_INV_206.png", "CHR_INV_207.png", "CHR_INV_208.png", "CHR_INV_209.png", "CHR_INV_210.png", "CHR_INV_211.png", "CHR_INV_212.png", "CHR_INV_213.png", "CHR_INV_214.png", "CHR_INV_215.png", "CHR_INV_216.png", "CHR_INV_217.png", "CHR_INV_218.png", "CHR_INV_219.png", "CHR_INV_220.png", "CHR_INV_221.png", "CHR_INV_222.png", "CHR_INV_223.png", "CHR_INV_224.png"],
    image_length: 224,
    level: 1,
    show_level: hmUI.show_level.ONLY_NORMAL,
});
normal_top_text_line_09 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
    x: 240,
    y: 150,
    image_array: ["CHR_INV_01.png", "CHR_INV_02.png", "CHR_INV_03.png", "CHR_INV_04.png", "CHR_INV_05.png", "CHR_INV_06.png", "CHR_INV_07.png", "CHR_INV_08.png", "CHR_INV_09.png", "CHR_INV_10.png", "CHR_INV_11.png", "CHR_INV_12.png", "CHR_INV_13.png", "CHR_INV_14.png", "CHR_INV_15.png", "CHR_INV_16.png", "CHR_INV_17.png", "CHR_INV_18.png", "CHR_INV_19.png", "CHR_INV_20.png", "CHR_INV_21.png", "CHR_INV_22.png", "CHR_INV_23.png", "CHR_INV_24.png", "CHR_INV_25.png", "CHR_INV_26.png", "CHR_INV_27.png", "CHR_INV_28.png", "CHR_INV_29.png", "CHR_INV_30.png", "CHR_INV_31.png", "CHR_INV_32.png", "CHR_INV_33.png", "CHR_INV_34.png", "CHR_INV_35.png", "CHR_INV_36.png", "CHR_INV_37.png", "CHR_INV_38.png", "CHR_INV_39.png", "CHR_INV_40.png", "CHR_INV_41.png", "CHR_INV_42.png", "CHR_INV_43.png", "CHR_INV_44.png", "CHR_INV_45.png", "CHR_INV_46.png", "CHR_INV_47.png", "CHR_INV_48.png", "CHR_INV_49.png", "CHR_INV_50.png", "CHR_INV_51.png", "CHR_INV_52.png", "CHR_INV_53.png", "CHR_INV_54.png", "CHR_INV_55.png", "CHR_INV_56.png", "CHR_INV_57.png", "CHR_INV_58.png", "CHR_INV_59.png", "CHR_INV_60.png", "CHR_INV_61.png", "CHR_INV_62.png", "CHR_INV_63.png", "CHR_INV_64.png", "CHR_INV_65.png", "CHR_INV_66.png", "CHR_INV_67.png", "CHR_INV_68.png", "CHR_INV_69.png", "CHR_INV_70.png", "CHR_INV_71.png", "CHR_INV_72.png", "CHR_INV_73.png", "CHR_INV_74.png", "CHR_INV_75.png", "CHR_INV_76.png", "CHR_INV_77.png", "CHR_INV_78.png", "CHR_INV_79.png", "CHR_INV_80.png", "CHR_INV_81.png", "CHR_INV_82.png", "CHR_INV_83.png", "CHR_INV_84.png", "CHR_INV_85.png", "CHR_INV_86.png", "CHR_INV_87.png", "CHR_INV_88.png", "CHR_INV_89.png", "CHR_INV_90.png", "CHR_INV_91.png", "CHR_INV_92.png", "CHR_INV_93.png", "CHR_INV_94.png", "CHR_INV_95.png", "CHR_INV_96.png", "CHR_INV_97.png", "CHR_INV_98.png", "CHR_INV_99.png", "CHR_INV_100.png", "CHR_INV_101.png", "CHR_INV_102.png", "CHR_INV_103.png", "CHR_INV_104.png", "CHR_INV_105.png", "CHR_INV_106.png", "CHR_INV_107.png", "CHR_INV_108.png", "CHR_INV_109.png", "CHR_INV_110.png", "CHR_INV_111.png", "CHR_INV_112.png", "CHR_INV_113.png", "CHR_INV_114.png", "CHR_INV_115.png", "CHR_INV_116.png", "CHR_INV_117.png", "CHR_INV_118.png", "CHR_INV_119.png", "CHR_INV_120.png", "CHR_INV_121.png", "CHR_INV_122.png", "CHR_INV_123.png", "CHR_INV_124.png", "CHR_INV_125.png", "CHR_INV_126.png", "CHR_INV_127.png", "CHR_INV_128.png", "CHR_INV_129.png", "CHR_INV_130.png", "CHR_INV_131.png", "CHR_INV_132.png", "CHR_INV_133.png", "CHR_INV_134.png", "CHR_INV_135.png", "CHR_INV_136.png", "CHR_INV_137.png", "CHR_INV_138.png", "CHR_INV_139.png", "CHR_INV_140.png", "CHR_INV_141.png", "CHR_INV_142.png", "CHR_INV_143.png", "CHR_INV_144.png", "CHR_INV_145.png", "CHR_INV_146.png", "CHR_INV_147.png", "CHR_INV_148.png", "CHR_INV_149.png", "CHR_INV_150.png", "CHR_INV_151.png", "CHR_INV_152.png", "CHR_INV_153.png", "CHR_INV_154.png", "CHR_INV_155.png", "CHR_INV_156.png", "CHR_INV_157.png", "CHR_INV_158.png", "CHR_INV_159.png", "CHR_INV_160.png", "CHR_INV_161.png", "CHR_INV_162.png", "CHR_INV_163.png", "CHR_INV_164.png", "CHR_INV_165.png", "CHR_INV_166.png", "CHR_INV_167.png", "CHR_INV_168.png", "CHR_INV_169.png", "CHR_INV_170.png", "CHR_INV_171.png", "CHR_INV_172.png", "CHR_INV_173.png", "CHR_INV_174.png", "CHR_INV_175.png", "CHR_INV_176.png", "CHR_INV_177.png", "CHR_INV_178.png", "CHR_INV_179.png", "CHR_INV_180.png", "CHR_INV_181.png", "CHR_INV_182.png", "CHR_INV_183.png", "CHR_INV_184.png", "CHR_INV_185.png", "CHR_INV_186.png", "CHR_INV_187.png", "CHR_INV_188.png", "CHR_INV_189.png", "CHR_INV_190.png", "CHR_INV_191.png", "CHR_INV_192.png", "CHR_INV_193.png", "CHR_INV_194.png", "CHR_INV_195.png", "CHR_INV_196.png", "CHR_INV_197.png", "CHR_INV_198.png", "CHR_INV_199.png", "CHR_INV_200.png", "CHR_INV_201.png", "CHR_INV_202.png", "CHR_INV_203.png", "CHR_INV_204.png", "CHR_INV_205.png", "CHR_INV_206.png", "CHR_INV_207.png", "CHR_INV_208.png", "CHR_INV_209.png", "CHR_INV_210.png", "CHR_INV_211.png", "CHR_INV_212.png", "CHR_INV_213.png", "CHR_INV_214.png", "CHR_INV_215.png", "CHR_INV_216.png", "CHR_INV_217.png", "CHR_INV_218.png", "CHR_INV_219.png", "CHR_INV_220.png", "CHR_INV_221.png", "CHR_INV_222.png", "CHR_INV_223.png", "CHR_INV_224.png"],
    image_length: 224,
    level: 1,
    show_level: hmUI.show_level.ONLY_NORMAL,
});
normal_top_text_line_10 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
    x: 264,
    y: 150,
    image_array: ["CHR_INV_01.png", "CHR_INV_02.png", "CHR_INV_03.png", "CHR_INV_04.png", "CHR_INV_05.png", "CHR_INV_06.png", "CHR_INV_07.png", "CHR_INV_08.png", "CHR_INV_09.png", "CHR_INV_10.png", "CHR_INV_11.png", "CHR_INV_12.png", "CHR_INV_13.png", "CHR_INV_14.png", "CHR_INV_15.png", "CHR_INV_16.png", "CHR_INV_17.png", "CHR_INV_18.png", "CHR_INV_19.png", "CHR_INV_20.png", "CHR_INV_21.png", "CHR_INV_22.png", "CHR_INV_23.png", "CHR_INV_24.png", "CHR_INV_25.png", "CHR_INV_26.png", "CHR_INV_27.png", "CHR_INV_28.png", "CHR_INV_29.png", "CHR_INV_30.png", "CHR_INV_31.png", "CHR_INV_32.png", "CHR_INV_33.png", "CHR_INV_34.png", "CHR_INV_35.png", "CHR_INV_36.png", "CHR_INV_37.png", "CHR_INV_38.png", "CHR_INV_39.png", "CHR_INV_40.png", "CHR_INV_41.png", "CHR_INV_42.png", "CHR_INV_43.png", "CHR_INV_44.png", "CHR_INV_45.png", "CHR_INV_46.png", "CHR_INV_47.png", "CHR_INV_48.png", "CHR_INV_49.png", "CHR_INV_50.png", "CHR_INV_51.png", "CHR_INV_52.png", "CHR_INV_53.png", "CHR_INV_54.png", "CHR_INV_55.png", "CHR_INV_56.png", "CHR_INV_57.png", "CHR_INV_58.png", "CHR_INV_59.png", "CHR_INV_60.png", "CHR_INV_61.png", "CHR_INV_62.png", "CHR_INV_63.png", "CHR_INV_64.png", "CHR_INV_65.png", "CHR_INV_66.png", "CHR_INV_67.png", "CHR_INV_68.png", "CHR_INV_69.png", "CHR_INV_70.png", "CHR_INV_71.png", "CHR_INV_72.png", "CHR_INV_73.png", "CHR_INV_74.png", "CHR_INV_75.png", "CHR_INV_76.png", "CHR_INV_77.png", "CHR_INV_78.png", "CHR_INV_79.png", "CHR_INV_80.png", "CHR_INV_81.png", "CHR_INV_82.png", "CHR_INV_83.png", "CHR_INV_84.png", "CHR_INV_85.png", "CHR_INV_86.png", "CHR_INV_87.png", "CHR_INV_88.png", "CHR_INV_89.png", "CHR_INV_90.png", "CHR_INV_91.png", "CHR_INV_92.png", "CHR_INV_93.png", "CHR_INV_94.png", "CHR_INV_95.png", "CHR_INV_96.png", "CHR_INV_97.png", "CHR_INV_98.png", "CHR_INV_99.png", "CHR_INV_100.png", "CHR_INV_101.png", "CHR_INV_102.png", "CHR_INV_103.png", "CHR_INV_104.png", "CHR_INV_105.png", "CHR_INV_106.png", "CHR_INV_107.png", "CHR_INV_108.png", "CHR_INV_109.png", "CHR_INV_110.png", "CHR_INV_111.png", "CHR_INV_112.png", "CHR_INV_113.png", "CHR_INV_114.png", "CHR_INV_115.png", "CHR_INV_116.png", "CHR_INV_117.png", "CHR_INV_118.png", "CHR_INV_119.png", "CHR_INV_120.png", "CHR_INV_121.png", "CHR_INV_122.png", "CHR_INV_123.png", "CHR_INV_124.png", "CHR_INV_125.png", "CHR_INV_126.png", "CHR_INV_127.png", "CHR_INV_128.png", "CHR_INV_129.png", "CHR_INV_130.png", "CHR_INV_131.png", "CHR_INV_132.png", "CHR_INV_133.png", "CHR_INV_134.png", "CHR_INV_135.png", "CHR_INV_136.png", "CHR_INV_137.png", "CHR_INV_138.png", "CHR_INV_139.png", "CHR_INV_140.png", "CHR_INV_141.png", "CHR_INV_142.png", "CHR_INV_143.png", "CHR_INV_144.png", "CHR_INV_145.png", "CHR_INV_146.png", "CHR_INV_147.png", "CHR_INV_148.png", "CHR_INV_149.png", "CHR_INV_150.png", "CHR_INV_151.png", "CHR_INV_152.png", "CHR_INV_153.png", "CHR_INV_154.png", "CHR_INV_155.png", "CHR_INV_156.png", "CHR_INV_157.png", "CHR_INV_158.png", "CHR_INV_159.png", "CHR_INV_160.png", "CHR_INV_161.png", "CHR_INV_162.png", "CHR_INV_163.png", "CHR_INV_164.png", "CHR_INV_165.png", "CHR_INV_166.png", "CHR_INV_167.png", "CHR_INV_168.png", "CHR_INV_169.png", "CHR_INV_170.png", "CHR_INV_171.png", "CHR_INV_172.png", "CHR_INV_173.png", "CHR_INV_174.png", "CHR_INV_175.png", "CHR_INV_176.png", "CHR_INV_177.png", "CHR_INV_178.png", "CHR_INV_179.png", "CHR_INV_180.png", "CHR_INV_181.png", "CHR_INV_182.png", "CHR_INV_183.png", "CHR_INV_184.png", "CHR_INV_185.png", "CHR_INV_186.png", "CHR_INV_187.png", "CHR_INV_188.png", "CHR_INV_189.png", "CHR_INV_190.png", "CHR_INV_191.png", "CHR_INV_192.png", "CHR_INV_193.png", "CHR_INV_194.png", "CHR_INV_195.png", "CHR_INV_196.png", "CHR_INV_197.png", "CHR_INV_198.png", "CHR_INV_199.png", "CHR_INV_200.png", "CHR_INV_201.png", "CHR_INV_202.png", "CHR_INV_203.png", "CHR_INV_204.png", "CHR_INV_205.png", "CHR_INV_206.png", "CHR_INV_207.png", "CHR_INV_208.png", "CHR_INV_209.png", "CHR_INV_210.png", "CHR_INV_211.png", "CHR_INV_212.png", "CHR_INV_213.png", "CHR_INV_214.png", "CHR_INV_215.png", "CHR_INV_216.png", "CHR_INV_217.png", "CHR_INV_218.png", "CHR_INV_219.png", "CHR_INV_220.png", "CHR_INV_221.png", "CHR_INV_222.png", "CHR_INV_223.png", "CHR_INV_224.png"],
    image_length: 224,
    level: 1,
    show_level: hmUI.show_level.ONLY_NORMAL,
});
normal_top_text_line_11 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
    x: 288,
    y: 150,
    image_array: ["CHR_INV_01.png", "CHR_INV_02.png", "CHR_INV_03.png", "CHR_INV_04.png", "CHR_INV_05.png", "CHR_INV_06.png", "CHR_INV_07.png", "CHR_INV_08.png", "CHR_INV_09.png", "CHR_INV_10.png", "CHR_INV_11.png", "CHR_INV_12.png", "CHR_INV_13.png", "CHR_INV_14.png", "CHR_INV_15.png", "CHR_INV_16.png", "CHR_INV_17.png", "CHR_INV_18.png", "CHR_INV_19.png", "CHR_INV_20.png", "CHR_INV_21.png", "CHR_INV_22.png", "CHR_INV_23.png", "CHR_INV_24.png", "CHR_INV_25.png", "CHR_INV_26.png", "CHR_INV_27.png", "CHR_INV_28.png", "CHR_INV_29.png", "CHR_INV_30.png", "CHR_INV_31.png", "CHR_INV_32.png", "CHR_INV_33.png", "CHR_INV_34.png", "CHR_INV_35.png", "CHR_INV_36.png", "CHR_INV_37.png", "CHR_INV_38.png", "CHR_INV_39.png", "CHR_INV_40.png", "CHR_INV_41.png", "CHR_INV_42.png", "CHR_INV_43.png", "CHR_INV_44.png", "CHR_INV_45.png", "CHR_INV_46.png", "CHR_INV_47.png", "CHR_INV_48.png", "CHR_INV_49.png", "CHR_INV_50.png", "CHR_INV_51.png", "CHR_INV_52.png", "CHR_INV_53.png", "CHR_INV_54.png", "CHR_INV_55.png", "CHR_INV_56.png", "CHR_INV_57.png", "CHR_INV_58.png", "CHR_INV_59.png", "CHR_INV_60.png", "CHR_INV_61.png", "CHR_INV_62.png", "CHR_INV_63.png", "CHR_INV_64.png", "CHR_INV_65.png", "CHR_INV_66.png", "CHR_INV_67.png", "CHR_INV_68.png", "CHR_INV_69.png", "CHR_INV_70.png", "CHR_INV_71.png", "CHR_INV_72.png", "CHR_INV_73.png", "CHR_INV_74.png", "CHR_INV_75.png", "CHR_INV_76.png", "CHR_INV_77.png", "CHR_INV_78.png", "CHR_INV_79.png", "CHR_INV_80.png", "CHR_INV_81.png", "CHR_INV_82.png", "CHR_INV_83.png", "CHR_INV_84.png", "CHR_INV_85.png", "CHR_INV_86.png", "CHR_INV_87.png", "CHR_INV_88.png", "CHR_INV_89.png", "CHR_INV_90.png", "CHR_INV_91.png", "CHR_INV_92.png", "CHR_INV_93.png", "CHR_INV_94.png", "CHR_INV_95.png", "CHR_INV_96.png", "CHR_INV_97.png", "CHR_INV_98.png", "CHR_INV_99.png", "CHR_INV_100.png", "CHR_INV_101.png", "CHR_INV_102.png", "CHR_INV_103.png", "CHR_INV_104.png", "CHR_INV_105.png", "CHR_INV_106.png", "CHR_INV_107.png", "CHR_INV_108.png", "CHR_INV_109.png", "CHR_INV_110.png", "CHR_INV_111.png", "CHR_INV_112.png", "CHR_INV_113.png", "CHR_INV_114.png", "CHR_INV_115.png", "CHR_INV_116.png", "CHR_INV_117.png", "CHR_INV_118.png", "CHR_INV_119.png", "CHR_INV_120.png", "CHR_INV_121.png", "CHR_INV_122.png", "CHR_INV_123.png", "CHR_INV_124.png", "CHR_INV_125.png", "CHR_INV_126.png", "CHR_INV_127.png", "CHR_INV_128.png", "CHR_INV_129.png", "CHR_INV_130.png", "CHR_INV_131.png", "CHR_INV_132.png", "CHR_INV_133.png", "CHR_INV_134.png", "CHR_INV_135.png", "CHR_INV_136.png", "CHR_INV_137.png", "CHR_INV_138.png", "CHR_INV_139.png", "CHR_INV_140.png", "CHR_INV_141.png", "CHR_INV_142.png", "CHR_INV_143.png", "CHR_INV_144.png", "CHR_INV_145.png", "CHR_INV_146.png", "CHR_INV_147.png", "CHR_INV_148.png", "CHR_INV_149.png", "CHR_INV_150.png", "CHR_INV_151.png", "CHR_INV_152.png", "CHR_INV_153.png", "CHR_INV_154.png", "CHR_INV_155.png", "CHR_INV_156.png", "CHR_INV_157.png", "CHR_INV_158.png", "CHR_INV_159.png", "CHR_INV_160.png", "CHR_INV_161.png", "CHR_INV_162.png", "CHR_INV_163.png", "CHR_INV_164.png", "CHR_INV_165.png", "CHR_INV_166.png", "CHR_INV_167.png", "CHR_INV_168.png", "CHR_INV_169.png", "CHR_INV_170.png", "CHR_INV_171.png", "CHR_INV_172.png", "CHR_INV_173.png", "CHR_INV_174.png", "CHR_INV_175.png", "CHR_INV_176.png", "CHR_INV_177.png", "CHR_INV_178.png", "CHR_INV_179.png", "CHR_INV_180.png", "CHR_INV_181.png", "CHR_INV_182.png", "CHR_INV_183.png", "CHR_INV_184.png", "CHR_INV_185.png", "CHR_INV_186.png", "CHR_INV_187.png", "CHR_INV_188.png", "CHR_INV_189.png", "CHR_INV_190.png", "CHR_INV_191.png", "CHR_INV_192.png", "CHR_INV_193.png", "CHR_INV_194.png", "CHR_INV_195.png", "CHR_INV_196.png", "CHR_INV_197.png", "CHR_INV_198.png", "CHR_INV_199.png", "CHR_INV_200.png", "CHR_INV_201.png", "CHR_INV_202.png", "CHR_INV_203.png", "CHR_INV_204.png", "CHR_INV_205.png", "CHR_INV_206.png", "CHR_INV_207.png", "CHR_INV_208.png", "CHR_INV_209.png", "CHR_INV_210.png", "CHR_INV_211.png", "CHR_INV_212.png", "CHR_INV_213.png", "CHR_INV_214.png", "CHR_INV_215.png", "CHR_INV_216.png", "CHR_INV_217.png", "CHR_INV_218.png", "CHR_INV_219.png", "CHR_INV_220.png", "CHR_INV_221.png", "CHR_INV_222.png", "CHR_INV_223.png", "CHR_INV_224.png"],
    image_length: 224,
    level: 1,
    show_level: hmUI.show_level.ONLY_NORMAL,
});
normal_top_text_line_12 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
    x: 312,
    y: 150,
    image_array: ["CHR_INV_01.png", "CHR_INV_02.png", "CHR_INV_03.png", "CHR_INV_04.png", "CHR_INV_05.png", "CHR_INV_06.png", "CHR_INV_07.png", "CHR_INV_08.png", "CHR_INV_09.png", "CHR_INV_10.png", "CHR_INV_11.png", "CHR_INV_12.png", "CHR_INV_13.png", "CHR_INV_14.png", "CHR_INV_15.png", "CHR_INV_16.png", "CHR_INV_17.png", "CHR_INV_18.png", "CHR_INV_19.png", "CHR_INV_20.png", "CHR_INV_21.png", "CHR_INV_22.png", "CHR_INV_23.png", "CHR_INV_24.png", "CHR_INV_25.png", "CHR_INV_26.png", "CHR_INV_27.png", "CHR_INV_28.png", "CHR_INV_29.png", "CHR_INV_30.png", "CHR_INV_31.png", "CHR_INV_32.png", "CHR_INV_33.png", "CHR_INV_34.png", "CHR_INV_35.png", "CHR_INV_36.png", "CHR_INV_37.png", "CHR_INV_38.png", "CHR_INV_39.png", "CHR_INV_40.png", "CHR_INV_41.png", "CHR_INV_42.png", "CHR_INV_43.png", "CHR_INV_44.png", "CHR_INV_45.png", "CHR_INV_46.png", "CHR_INV_47.png", "CHR_INV_48.png", "CHR_INV_49.png", "CHR_INV_50.png", "CHR_INV_51.png", "CHR_INV_52.png", "CHR_INV_53.png", "CHR_INV_54.png", "CHR_INV_55.png", "CHR_INV_56.png", "CHR_INV_57.png", "CHR_INV_58.png", "CHR_INV_59.png", "CHR_INV_60.png", "CHR_INV_61.png", "CHR_INV_62.png", "CHR_INV_63.png", "CHR_INV_64.png", "CHR_INV_65.png", "CHR_INV_66.png", "CHR_INV_67.png", "CHR_INV_68.png", "CHR_INV_69.png", "CHR_INV_70.png", "CHR_INV_71.png", "CHR_INV_72.png", "CHR_INV_73.png", "CHR_INV_74.png", "CHR_INV_75.png", "CHR_INV_76.png", "CHR_INV_77.png", "CHR_INV_78.png", "CHR_INV_79.png", "CHR_INV_80.png", "CHR_INV_81.png", "CHR_INV_82.png", "CHR_INV_83.png", "CHR_INV_84.png", "CHR_INV_85.png", "CHR_INV_86.png", "CHR_INV_87.png", "CHR_INV_88.png", "CHR_INV_89.png", "CHR_INV_90.png", "CHR_INV_91.png", "CHR_INV_92.png", "CHR_INV_93.png", "CHR_INV_94.png", "CHR_INV_95.png", "CHR_INV_96.png", "CHR_INV_97.png", "CHR_INV_98.png", "CHR_INV_99.png", "CHR_INV_100.png", "CHR_INV_101.png", "CHR_INV_102.png", "CHR_INV_103.png", "CHR_INV_104.png", "CHR_INV_105.png", "CHR_INV_106.png", "CHR_INV_107.png", "CHR_INV_108.png", "CHR_INV_109.png", "CHR_INV_110.png", "CHR_INV_111.png", "CHR_INV_112.png", "CHR_INV_113.png", "CHR_INV_114.png", "CHR_INV_115.png", "CHR_INV_116.png", "CHR_INV_117.png", "CHR_INV_118.png", "CHR_INV_119.png", "CHR_INV_120.png", "CHR_INV_121.png", "CHR_INV_122.png", "CHR_INV_123.png", "CHR_INV_124.png", "CHR_INV_125.png", "CHR_INV_126.png", "CHR_INV_127.png", "CHR_INV_128.png", "CHR_INV_129.png", "CHR_INV_130.png", "CHR_INV_131.png", "CHR_INV_132.png", "CHR_INV_133.png", "CHR_INV_134.png", "CHR_INV_135.png", "CHR_INV_136.png", "CHR_INV_137.png", "CHR_INV_138.png", "CHR_INV_139.png", "CHR_INV_140.png", "CHR_INV_141.png", "CHR_INV_142.png", "CHR_INV_143.png", "CHR_INV_144.png", "CHR_INV_145.png", "CHR_INV_146.png", "CHR_INV_147.png", "CHR_INV_148.png", "CHR_INV_149.png", "CHR_INV_150.png", "CHR_INV_151.png", "CHR_INV_152.png", "CHR_INV_153.png", "CHR_INV_154.png", "CHR_INV_155.png", "CHR_INV_156.png", "CHR_INV_157.png", "CHR_INV_158.png", "CHR_INV_159.png", "CHR_INV_160.png", "CHR_INV_161.png", "CHR_INV_162.png", "CHR_INV_163.png", "CHR_INV_164.png", "CHR_INV_165.png", "CHR_INV_166.png", "CHR_INV_167.png", "CHR_INV_168.png", "CHR_INV_169.png", "CHR_INV_170.png", "CHR_INV_171.png", "CHR_INV_172.png", "CHR_INV_173.png", "CHR_INV_174.png", "CHR_INV_175.png", "CHR_INV_176.png", "CHR_INV_177.png", "CHR_INV_178.png", "CHR_INV_179.png", "CHR_INV_180.png", "CHR_INV_181.png", "CHR_INV_182.png", "CHR_INV_183.png", "CHR_INV_184.png", "CHR_INV_185.png", "CHR_INV_186.png", "CHR_INV_187.png", "CHR_INV_188.png", "CHR_INV_189.png", "CHR_INV_190.png", "CHR_INV_191.png", "CHR_INV_192.png", "CHR_INV_193.png", "CHR_INV_194.png", "CHR_INV_195.png", "CHR_INV_196.png", "CHR_INV_197.png", "CHR_INV_198.png", "CHR_INV_199.png", "CHR_INV_200.png", "CHR_INV_201.png", "CHR_INV_202.png", "CHR_INV_203.png", "CHR_INV_204.png", "CHR_INV_205.png", "CHR_INV_206.png", "CHR_INV_207.png", "CHR_INV_208.png", "CHR_INV_209.png", "CHR_INV_210.png", "CHR_INV_211.png", "CHR_INV_212.png", "CHR_INV_213.png", "CHR_INV_214.png", "CHR_INV_215.png", "CHR_INV_216.png", "CHR_INV_217.png", "CHR_INV_218.png", "CHR_INV_219.png", "CHR_INV_220.png", "CHR_INV_221.png", "CHR_INV_222.png", "CHR_INV_223.png", "CHR_INV_224.png"],
    image_length: 224,
    level: 1,
    show_level: hmUI.show_level.ONLY_NORMAL,
});
normal_top_text_line_13 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
    x: 336,
    y: 150,
    image_array: ["CHR_INV_01.png", "CHR_INV_02.png", "CHR_INV_03.png", "CHR_INV_04.png", "CHR_INV_05.png", "CHR_INV_06.png", "CHR_INV_07.png", "CHR_INV_08.png", "CHR_INV_09.png", "CHR_INV_10.png", "CHR_INV_11.png", "CHR_INV_12.png", "CHR_INV_13.png", "CHR_INV_14.png", "CHR_INV_15.png", "CHR_INV_16.png", "CHR_INV_17.png", "CHR_INV_18.png", "CHR_INV_19.png", "CHR_INV_20.png", "CHR_INV_21.png", "CHR_INV_22.png", "CHR_INV_23.png", "CHR_INV_24.png", "CHR_INV_25.png", "CHR_INV_26.png", "CHR_INV_27.png", "CHR_INV_28.png", "CHR_INV_29.png", "CHR_INV_30.png", "CHR_INV_31.png", "CHR_INV_32.png", "CHR_INV_33.png", "CHR_INV_34.png", "CHR_INV_35.png", "CHR_INV_36.png", "CHR_INV_37.png", "CHR_INV_38.png", "CHR_INV_39.png", "CHR_INV_40.png", "CHR_INV_41.png", "CHR_INV_42.png", "CHR_INV_43.png", "CHR_INV_44.png", "CHR_INV_45.png", "CHR_INV_46.png", "CHR_INV_47.png", "CHR_INV_48.png", "CHR_INV_49.png", "CHR_INV_50.png", "CHR_INV_51.png", "CHR_INV_52.png", "CHR_INV_53.png", "CHR_INV_54.png", "CHR_INV_55.png", "CHR_INV_56.png", "CHR_INV_57.png", "CHR_INV_58.png", "CHR_INV_59.png", "CHR_INV_60.png", "CHR_INV_61.png", "CHR_INV_62.png", "CHR_INV_63.png", "CHR_INV_64.png", "CHR_INV_65.png", "CHR_INV_66.png", "CHR_INV_67.png", "CHR_INV_68.png", "CHR_INV_69.png", "CHR_INV_70.png", "CHR_INV_71.png", "CHR_INV_72.png", "CHR_INV_73.png", "CHR_INV_74.png", "CHR_INV_75.png", "CHR_INV_76.png", "CHR_INV_77.png", "CHR_INV_78.png", "CHR_INV_79.png", "CHR_INV_80.png", "CHR_INV_81.png", "CHR_INV_82.png", "CHR_INV_83.png", "CHR_INV_84.png", "CHR_INV_85.png", "CHR_INV_86.png", "CHR_INV_87.png", "CHR_INV_88.png", "CHR_INV_89.png", "CHR_INV_90.png", "CHR_INV_91.png", "CHR_INV_92.png", "CHR_INV_93.png", "CHR_INV_94.png", "CHR_INV_95.png", "CHR_INV_96.png", "CHR_INV_97.png", "CHR_INV_98.png", "CHR_INV_99.png", "CHR_INV_100.png", "CHR_INV_101.png", "CHR_INV_102.png", "CHR_INV_103.png", "CHR_INV_104.png", "CHR_INV_105.png", "CHR_INV_106.png", "CHR_INV_107.png", "CHR_INV_108.png", "CHR_INV_109.png", "CHR_INV_110.png", "CHR_INV_111.png", "CHR_INV_112.png", "CHR_INV_113.png", "CHR_INV_114.png", "CHR_INV_115.png", "CHR_INV_116.png", "CHR_INV_117.png", "CHR_INV_118.png", "CHR_INV_119.png", "CHR_INV_120.png", "CHR_INV_121.png", "CHR_INV_122.png", "CHR_INV_123.png", "CHR_INV_124.png", "CHR_INV_125.png", "CHR_INV_126.png", "CHR_INV_127.png", "CHR_INV_128.png", "CHR_INV_129.png", "CHR_INV_130.png", "CHR_INV_131.png", "CHR_INV_132.png", "CHR_INV_133.png", "CHR_INV_134.png", "CHR_INV_135.png", "CHR_INV_136.png", "CHR_INV_137.png", "CHR_INV_138.png", "CHR_INV_139.png", "CHR_INV_140.png", "CHR_INV_141.png", "CHR_INV_142.png", "CHR_INV_143.png", "CHR_INV_144.png", "CHR_INV_145.png", "CHR_INV_146.png", "CHR_INV_147.png", "CHR_INV_148.png", "CHR_INV_149.png", "CHR_INV_150.png", "CHR_INV_151.png", "CHR_INV_152.png", "CHR_INV_153.png", "CHR_INV_154.png", "CHR_INV_155.png", "CHR_INV_156.png", "CHR_INV_157.png", "CHR_INV_158.png", "CHR_INV_159.png", "CHR_INV_160.png", "CHR_INV_161.png", "CHR_INV_162.png", "CHR_INV_163.png", "CHR_INV_164.png", "CHR_INV_165.png", "CHR_INV_166.png", "CHR_INV_167.png", "CHR_INV_168.png", "CHR_INV_169.png", "CHR_INV_170.png", "CHR_INV_171.png", "CHR_INV_172.png", "CHR_INV_173.png", "CHR_INV_174.png", "CHR_INV_175.png", "CHR_INV_176.png", "CHR_INV_177.png", "CHR_INV_178.png", "CHR_INV_179.png", "CHR_INV_180.png", "CHR_INV_181.png", "CHR_INV_182.png", "CHR_INV_183.png", "CHR_INV_184.png", "CHR_INV_185.png", "CHR_INV_186.png", "CHR_INV_187.png", "CHR_INV_188.png", "CHR_INV_189.png", "CHR_INV_190.png", "CHR_INV_191.png", "CHR_INV_192.png", "CHR_INV_193.png", "CHR_INV_194.png", "CHR_INV_195.png", "CHR_INV_196.png", "CHR_INV_197.png", "CHR_INV_198.png", "CHR_INV_199.png", "CHR_INV_200.png", "CHR_INV_201.png", "CHR_INV_202.png", "CHR_INV_203.png", "CHR_INV_204.png", "CHR_INV_205.png", "CHR_INV_206.png", "CHR_INV_207.png", "CHR_INV_208.png", "CHR_INV_209.png", "CHR_INV_210.png", "CHR_INV_211.png", "CHR_INV_212.png", "CHR_INV_213.png", "CHR_INV_214.png", "CHR_INV_215.png", "CHR_INV_216.png", "CHR_INV_217.png", "CHR_INV_218.png", "CHR_INV_219.png", "CHR_INV_220.png", "CHR_INV_221.png", "CHR_INV_222.png", "CHR_INV_223.png", "CHR_INV_224.png"],
    image_length: 224,
    level: 1,
    show_level: hmUI.show_level.ONLY_NORMAL,
});
normal_top_text_line_14 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
    x: 360,
    y: 150,
    image_array: ["CHR_INV_01.png", "CHR_INV_02.png", "CHR_INV_03.png", "CHR_INV_04.png", "CHR_INV_05.png", "CHR_INV_06.png", "CHR_INV_07.png", "CHR_INV_08.png", "CHR_INV_09.png", "CHR_INV_10.png", "CHR_INV_11.png", "CHR_INV_12.png", "CHR_INV_13.png", "CHR_INV_14.png", "CHR_INV_15.png", "CHR_INV_16.png", "CHR_INV_17.png", "CHR_INV_18.png", "CHR_INV_19.png", "CHR_INV_20.png", "CHR_INV_21.png", "CHR_INV_22.png", "CHR_INV_23.png", "CHR_INV_24.png", "CHR_INV_25.png", "CHR_INV_26.png", "CHR_INV_27.png", "CHR_INV_28.png", "CHR_INV_29.png", "CHR_INV_30.png", "CHR_INV_31.png", "CHR_INV_32.png", "CHR_INV_33.png", "CHR_INV_34.png", "CHR_INV_35.png", "CHR_INV_36.png", "CHR_INV_37.png", "CHR_INV_38.png", "CHR_INV_39.png", "CHR_INV_40.png", "CHR_INV_41.png", "CHR_INV_42.png", "CHR_INV_43.png", "CHR_INV_44.png", "CHR_INV_45.png", "CHR_INV_46.png", "CHR_INV_47.png", "CHR_INV_48.png", "CHR_INV_49.png", "CHR_INV_50.png", "CHR_INV_51.png", "CHR_INV_52.png", "CHR_INV_53.png", "CHR_INV_54.png", "CHR_INV_55.png", "CHR_INV_56.png", "CHR_INV_57.png", "CHR_INV_58.png", "CHR_INV_59.png", "CHR_INV_60.png", "CHR_INV_61.png", "CHR_INV_62.png", "CHR_INV_63.png", "CHR_INV_64.png", "CHR_INV_65.png", "CHR_INV_66.png", "CHR_INV_67.png", "CHR_INV_68.png", "CHR_INV_69.png", "CHR_INV_70.png", "CHR_INV_71.png", "CHR_INV_72.png", "CHR_INV_73.png", "CHR_INV_74.png", "CHR_INV_75.png", "CHR_INV_76.png", "CHR_INV_77.png", "CHR_INV_78.png", "CHR_INV_79.png", "CHR_INV_80.png", "CHR_INV_81.png", "CHR_INV_82.png", "CHR_INV_83.png", "CHR_INV_84.png", "CHR_INV_85.png", "CHR_INV_86.png", "CHR_INV_87.png", "CHR_INV_88.png", "CHR_INV_89.png", "CHR_INV_90.png", "CHR_INV_91.png", "CHR_INV_92.png", "CHR_INV_93.png", "CHR_INV_94.png", "CHR_INV_95.png", "CHR_INV_96.png", "CHR_INV_97.png", "CHR_INV_98.png", "CHR_INV_99.png", "CHR_INV_100.png", "CHR_INV_101.png", "CHR_INV_102.png", "CHR_INV_103.png", "CHR_INV_104.png", "CHR_INV_105.png", "CHR_INV_106.png", "CHR_INV_107.png", "CHR_INV_108.png", "CHR_INV_109.png", "CHR_INV_110.png", "CHR_INV_111.png", "CHR_INV_112.png", "CHR_INV_113.png", "CHR_INV_114.png", "CHR_INV_115.png", "CHR_INV_116.png", "CHR_INV_117.png", "CHR_INV_118.png", "CHR_INV_119.png", "CHR_INV_120.png", "CHR_INV_121.png", "CHR_INV_122.png", "CHR_INV_123.png", "CHR_INV_124.png", "CHR_INV_125.png", "CHR_INV_126.png", "CHR_INV_127.png", "CHR_INV_128.png", "CHR_INV_129.png", "CHR_INV_130.png", "CHR_INV_131.png", "CHR_INV_132.png", "CHR_INV_133.png", "CHR_INV_134.png", "CHR_INV_135.png", "CHR_INV_136.png", "CHR_INV_137.png", "CHR_INV_138.png", "CHR_INV_139.png", "CHR_INV_140.png", "CHR_INV_141.png", "CHR_INV_142.png", "CHR_INV_143.png", "CHR_INV_144.png", "CHR_INV_145.png", "CHR_INV_146.png", "CHR_INV_147.png", "CHR_INV_148.png", "CHR_INV_149.png", "CHR_INV_150.png", "CHR_INV_151.png", "CHR_INV_152.png", "CHR_INV_153.png", "CHR_INV_154.png", "CHR_INV_155.png", "CHR_INV_156.png", "CHR_INV_157.png", "CHR_INV_158.png", "CHR_INV_159.png", "CHR_INV_160.png", "CHR_INV_161.png", "CHR_INV_162.png", "CHR_INV_163.png", "CHR_INV_164.png", "CHR_INV_165.png", "CHR_INV_166.png", "CHR_INV_167.png", "CHR_INV_168.png", "CHR_INV_169.png", "CHR_INV_170.png", "CHR_INV_171.png", "CHR_INV_172.png", "CHR_INV_173.png", "CHR_INV_174.png", "CHR_INV_175.png", "CHR_INV_176.png", "CHR_INV_177.png", "CHR_INV_178.png", "CHR_INV_179.png", "CHR_INV_180.png", "CHR_INV_181.png", "CHR_INV_182.png", "CHR_INV_183.png", "CHR_INV_184.png", "CHR_INV_185.png", "CHR_INV_186.png", "CHR_INV_187.png", "CHR_INV_188.png", "CHR_INV_189.png", "CHR_INV_190.png", "CHR_INV_191.png", "CHR_INV_192.png", "CHR_INV_193.png", "CHR_INV_194.png", "CHR_INV_195.png", "CHR_INV_196.png", "CHR_INV_197.png", "CHR_INV_198.png", "CHR_INV_199.png", "CHR_INV_200.png", "CHR_INV_201.png", "CHR_INV_202.png", "CHR_INV_203.png", "CHR_INV_204.png", "CHR_INV_205.png", "CHR_INV_206.png", "CHR_INV_207.png", "CHR_INV_208.png", "CHR_INV_209.png", "CHR_INV_210.png", "CHR_INV_211.png", "CHR_INV_212.png", "CHR_INV_213.png", "CHR_INV_214.png", "CHR_INV_215.png", "CHR_INV_216.png", "CHR_INV_217.png", "CHR_INV_218.png", "CHR_INV_219.png", "CHR_INV_220.png", "CHR_INV_221.png", "CHR_INV_222.png", "CHR_INV_223.png", "CHR_INV_224.png"],
    image_length: 224,
    level: 1,
    show_level: hmUI.show_level.ONLY_NORMAL,
});
normal_top_text_line_15 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
    x: 384,
    y: 150,
    image_array: ["CHR_INV_01.png", "CHR_INV_02.png", "CHR_INV_03.png", "CHR_INV_04.png", "CHR_INV_05.png", "CHR_INV_06.png", "CHR_INV_07.png", "CHR_INV_08.png", "CHR_INV_09.png", "CHR_INV_10.png", "CHR_INV_11.png", "CHR_INV_12.png", "CHR_INV_13.png", "CHR_INV_14.png", "CHR_INV_15.png", "CHR_INV_16.png", "CHR_INV_17.png", "CHR_INV_18.png", "CHR_INV_19.png", "CHR_INV_20.png", "CHR_INV_21.png", "CHR_INV_22.png", "CHR_INV_23.png", "CHR_INV_24.png", "CHR_INV_25.png", "CHR_INV_26.png", "CHR_INV_27.png", "CHR_INV_28.png", "CHR_INV_29.png", "CHR_INV_30.png", "CHR_INV_31.png", "CHR_INV_32.png", "CHR_INV_33.png", "CHR_INV_34.png", "CHR_INV_35.png", "CHR_INV_36.png", "CHR_INV_37.png", "CHR_INV_38.png", "CHR_INV_39.png", "CHR_INV_40.png", "CHR_INV_41.png", "CHR_INV_42.png", "CHR_INV_43.png", "CHR_INV_44.png", "CHR_INV_45.png", "CHR_INV_46.png", "CHR_INV_47.png", "CHR_INV_48.png", "CHR_INV_49.png", "CHR_INV_50.png", "CHR_INV_51.png", "CHR_INV_52.png", "CHR_INV_53.png", "CHR_INV_54.png", "CHR_INV_55.png", "CHR_INV_56.png", "CHR_INV_57.png", "CHR_INV_58.png", "CHR_INV_59.png", "CHR_INV_60.png", "CHR_INV_61.png", "CHR_INV_62.png", "CHR_INV_63.png", "CHR_INV_64.png", "CHR_INV_65.png", "CHR_INV_66.png", "CHR_INV_67.png", "CHR_INV_68.png", "CHR_INV_69.png", "CHR_INV_70.png", "CHR_INV_71.png", "CHR_INV_72.png", "CHR_INV_73.png", "CHR_INV_74.png", "CHR_INV_75.png", "CHR_INV_76.png", "CHR_INV_77.png", "CHR_INV_78.png", "CHR_INV_79.png", "CHR_INV_80.png", "CHR_INV_81.png", "CHR_INV_82.png", "CHR_INV_83.png", "CHR_INV_84.png", "CHR_INV_85.png", "CHR_INV_86.png", "CHR_INV_87.png", "CHR_INV_88.png", "CHR_INV_89.png", "CHR_INV_90.png", "CHR_INV_91.png", "CHR_INV_92.png", "CHR_INV_93.png", "CHR_INV_94.png", "CHR_INV_95.png", "CHR_INV_96.png", "CHR_INV_97.png", "CHR_INV_98.png", "CHR_INV_99.png", "CHR_INV_100.png", "CHR_INV_101.png", "CHR_INV_102.png", "CHR_INV_103.png", "CHR_INV_104.png", "CHR_INV_105.png", "CHR_INV_106.png", "CHR_INV_107.png", "CHR_INV_108.png", "CHR_INV_109.png", "CHR_INV_110.png", "CHR_INV_111.png", "CHR_INV_112.png", "CHR_INV_113.png", "CHR_INV_114.png", "CHR_INV_115.png", "CHR_INV_116.png", "CHR_INV_117.png", "CHR_INV_118.png", "CHR_INV_119.png", "CHR_INV_120.png", "CHR_INV_121.png", "CHR_INV_122.png", "CHR_INV_123.png", "CHR_INV_124.png", "CHR_INV_125.png", "CHR_INV_126.png", "CHR_INV_127.png", "CHR_INV_128.png", "CHR_INV_129.png", "CHR_INV_130.png", "CHR_INV_131.png", "CHR_INV_132.png", "CHR_INV_133.png", "CHR_INV_134.png", "CHR_INV_135.png", "CHR_INV_136.png", "CHR_INV_137.png", "CHR_INV_138.png", "CHR_INV_139.png", "CHR_INV_140.png", "CHR_INV_141.png", "CHR_INV_142.png", "CHR_INV_143.png", "CHR_INV_144.png", "CHR_INV_145.png", "CHR_INV_146.png", "CHR_INV_147.png", "CHR_INV_148.png", "CHR_INV_149.png", "CHR_INV_150.png", "CHR_INV_151.png", "CHR_INV_152.png", "CHR_INV_153.png", "CHR_INV_154.png", "CHR_INV_155.png", "CHR_INV_156.png", "CHR_INV_157.png", "CHR_INV_158.png", "CHR_INV_159.png", "CHR_INV_160.png", "CHR_INV_161.png", "CHR_INV_162.png", "CHR_INV_163.png", "CHR_INV_164.png", "CHR_INV_165.png", "CHR_INV_166.png", "CHR_INV_167.png", "CHR_INV_168.png", "CHR_INV_169.png", "CHR_INV_170.png", "CHR_INV_171.png", "CHR_INV_172.png", "CHR_INV_173.png", "CHR_INV_174.png", "CHR_INV_175.png", "CHR_INV_176.png", "CHR_INV_177.png", "CHR_INV_178.png", "CHR_INV_179.png", "CHR_INV_180.png", "CHR_INV_181.png", "CHR_INV_182.png", "CHR_INV_183.png", "CHR_INV_184.png", "CHR_INV_185.png", "CHR_INV_186.png", "CHR_INV_187.png", "CHR_INV_188.png", "CHR_INV_189.png", "CHR_INV_190.png", "CHR_INV_191.png", "CHR_INV_192.png", "CHR_INV_193.png", "CHR_INV_194.png", "CHR_INV_195.png", "CHR_INV_196.png", "CHR_INV_197.png", "CHR_INV_198.png", "CHR_INV_199.png", "CHR_INV_200.png", "CHR_INV_201.png", "CHR_INV_202.png", "CHR_INV_203.png", "CHR_INV_204.png", "CHR_INV_205.png", "CHR_INV_206.png", "CHR_INV_207.png", "CHR_INV_208.png", "CHR_INV_209.png", "CHR_INV_210.png", "CHR_INV_211.png", "CHR_INV_212.png", "CHR_INV_213.png", "CHR_INV_214.png", "CHR_INV_215.png", "CHR_INV_216.png", "CHR_INV_217.png", "CHR_INV_218.png", "CHR_INV_219.png", "CHR_INV_220.png", "CHR_INV_221.png", "CHR_INV_222.png", "CHR_INV_223.png", "CHR_INV_224.png"],
    image_length: 224,
    level: 1,
    show_level: hmUI.show_level.ONLY_NORMAL,
});
normal_top_text_line_16 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
    x: 408,
    y: 150,
    image_array: ["CHR_INV_01.png", "CHR_INV_02.png", "CHR_INV_03.png", "CHR_INV_04.png", "CHR_INV_05.png", "CHR_INV_06.png", "CHR_INV_07.png", "CHR_INV_08.png", "CHR_INV_09.png", "CHR_INV_10.png", "CHR_INV_11.png", "CHR_INV_12.png", "CHR_INV_13.png", "CHR_INV_14.png", "CHR_INV_15.png", "CHR_INV_16.png", "CHR_INV_17.png", "CHR_INV_18.png", "CHR_INV_19.png", "CHR_INV_20.png", "CHR_INV_21.png", "CHR_INV_22.png", "CHR_INV_23.png", "CHR_INV_24.png", "CHR_INV_25.png", "CHR_INV_26.png", "CHR_INV_27.png", "CHR_INV_28.png", "CHR_INV_29.png", "CHR_INV_30.png", "CHR_INV_31.png", "CHR_INV_32.png", "CHR_INV_33.png", "CHR_INV_34.png", "CHR_INV_35.png", "CHR_INV_36.png", "CHR_INV_37.png", "CHR_INV_38.png", "CHR_INV_39.png", "CHR_INV_40.png", "CHR_INV_41.png", "CHR_INV_42.png", "CHR_INV_43.png", "CHR_INV_44.png", "CHR_INV_45.png", "CHR_INV_46.png", "CHR_INV_47.png", "CHR_INV_48.png", "CHR_INV_49.png", "CHR_INV_50.png", "CHR_INV_51.png", "CHR_INV_52.png", "CHR_INV_53.png", "CHR_INV_54.png", "CHR_INV_55.png", "CHR_INV_56.png", "CHR_INV_57.png", "CHR_INV_58.png", "CHR_INV_59.png", "CHR_INV_60.png", "CHR_INV_61.png", "CHR_INV_62.png", "CHR_INV_63.png", "CHR_INV_64.png", "CHR_INV_65.png", "CHR_INV_66.png", "CHR_INV_67.png", "CHR_INV_68.png", "CHR_INV_69.png", "CHR_INV_70.png", "CHR_INV_71.png", "CHR_INV_72.png", "CHR_INV_73.png", "CHR_INV_74.png", "CHR_INV_75.png", "CHR_INV_76.png", "CHR_INV_77.png", "CHR_INV_78.png", "CHR_INV_79.png", "CHR_INV_80.png", "CHR_INV_81.png", "CHR_INV_82.png", "CHR_INV_83.png", "CHR_INV_84.png", "CHR_INV_85.png", "CHR_INV_86.png", "CHR_INV_87.png", "CHR_INV_88.png", "CHR_INV_89.png", "CHR_INV_90.png", "CHR_INV_91.png", "CHR_INV_92.png", "CHR_INV_93.png", "CHR_INV_94.png", "CHR_INV_95.png", "CHR_INV_96.png", "CHR_INV_97.png", "CHR_INV_98.png", "CHR_INV_99.png", "CHR_INV_100.png", "CHR_INV_101.png", "CHR_INV_102.png", "CHR_INV_103.png", "CHR_INV_104.png", "CHR_INV_105.png", "CHR_INV_106.png", "CHR_INV_107.png", "CHR_INV_108.png", "CHR_INV_109.png", "CHR_INV_110.png", "CHR_INV_111.png", "CHR_INV_112.png", "CHR_INV_113.png", "CHR_INV_114.png", "CHR_INV_115.png", "CHR_INV_116.png", "CHR_INV_117.png", "CHR_INV_118.png", "CHR_INV_119.png", "CHR_INV_120.png", "CHR_INV_121.png", "CHR_INV_122.png", "CHR_INV_123.png", "CHR_INV_124.png", "CHR_INV_125.png", "CHR_INV_126.png", "CHR_INV_127.png", "CHR_INV_128.png", "CHR_INV_129.png", "CHR_INV_130.png", "CHR_INV_131.png", "CHR_INV_132.png", "CHR_INV_133.png", "CHR_INV_134.png", "CHR_INV_135.png", "CHR_INV_136.png", "CHR_INV_137.png", "CHR_INV_138.png", "CHR_INV_139.png", "CHR_INV_140.png", "CHR_INV_141.png", "CHR_INV_142.png", "CHR_INV_143.png", "CHR_INV_144.png", "CHR_INV_145.png", "CHR_INV_146.png", "CHR_INV_147.png", "CHR_INV_148.png", "CHR_INV_149.png", "CHR_INV_150.png", "CHR_INV_151.png", "CHR_INV_152.png", "CHR_INV_153.png", "CHR_INV_154.png", "CHR_INV_155.png", "CHR_INV_156.png", "CHR_INV_157.png", "CHR_INV_158.png", "CHR_INV_159.png", "CHR_INV_160.png", "CHR_INV_161.png", "CHR_INV_162.png", "CHR_INV_163.png", "CHR_INV_164.png", "CHR_INV_165.png", "CHR_INV_166.png", "CHR_INV_167.png", "CHR_INV_168.png", "CHR_INV_169.png", "CHR_INV_170.png", "CHR_INV_171.png", "CHR_INV_172.png", "CHR_INV_173.png", "CHR_INV_174.png", "CHR_INV_175.png", "CHR_INV_176.png", "CHR_INV_177.png", "CHR_INV_178.png", "CHR_INV_179.png", "CHR_INV_180.png", "CHR_INV_181.png", "CHR_INV_182.png", "CHR_INV_183.png", "CHR_INV_184.png", "CHR_INV_185.png", "CHR_INV_186.png", "CHR_INV_187.png", "CHR_INV_188.png", "CHR_INV_189.png", "CHR_INV_190.png", "CHR_INV_191.png", "CHR_INV_192.png", "CHR_INV_193.png", "CHR_INV_194.png", "CHR_INV_195.png", "CHR_INV_196.png", "CHR_INV_197.png", "CHR_INV_198.png", "CHR_INV_199.png", "CHR_INV_200.png", "CHR_INV_201.png", "CHR_INV_202.png", "CHR_INV_203.png", "CHR_INV_204.png", "CHR_INV_205.png", "CHR_INV_206.png", "CHR_INV_207.png", "CHR_INV_208.png", "CHR_INV_209.png", "CHR_INV_210.png", "CHR_INV_211.png", "CHR_INV_212.png", "CHR_INV_213.png", "CHR_INV_214.png", "CHR_INV_215.png", "CHR_INV_216.png", "CHR_INV_217.png", "CHR_INV_218.png", "CHR_INV_219.png", "CHR_INV_220.png", "CHR_INV_221.png", "CHR_INV_222.png", "CHR_INV_223.png", "CHR_INV_224.png"],
    image_length: 224,
    level: 1,
    show_level: hmUI.show_level.ONLY_NORMAL,
});
            // end user_script.js

            normal_stress_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 124,
              y: 116,
              font_array: ["NUM_SMALL_0.png","NUM_SMALL_1.png","NUM_SMALL_2.png","NUM_SMALL_3.png","NUM_SMALL_4.png","NUM_SMALL_5.png","NUM_SMALL_6.png","NUM_SMALL_7.png","NUM_SMALL_8.png","NUM_SMALL_9.png"],
              padding: true,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STRESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 96,
              y: 116,
              src: 'STRESS_SMALL.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 284,
              y: 116,
              font_array: ["NUM_SMALL_0.png","NUM_SMALL_1.png","NUM_SMALL_2.png","NUM_SMALL_3.png","NUM_SMALL_4.png","NUM_SMALL_5.png","NUM_SMALL_6.png","NUM_SMALL_7.png","NUM_SMALL_8.png","NUM_SMALL_9.png"],
              padding: true,
              h_space: 0,
              dot_image: 'NUM_SMALL_DOT.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 256,
              y: 116,
              src: 'DISTANCE_SMALL.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 124,
              y: 84,
              font_array: ["NUM_SMALL_0.png","NUM_SMALL_1.png","NUM_SMALL_2.png","NUM_SMALL_3.png","NUM_SMALL_4.png","NUM_SMALL_5.png","NUM_SMALL_6.png","NUM_SMALL_7.png","NUM_SMALL_8.png","NUM_SMALL_9.png"],
              padding: true,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 96,
              y: 84,
              src: 'HEART_SMALL.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 284,
              y: 84,
              font_array: ["NUM_SMALL_0.png","NUM_SMALL_1.png","NUM_SMALL_2.png","NUM_SMALL_3.png","NUM_SMALL_4.png","NUM_SMALL_5.png","NUM_SMALL_6.png","NUM_SMALL_7.png","NUM_SMALL_8.png","NUM_SMALL_9.png"],
              padding: true,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 256,
              y: 84,
              src: 'STEPS_SMALL.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 0,
              y: 150,
              image_array: ["PROGRESS_INV_1.png","PROGRESS_INV_2.png","PROGRESS_INV_3.png","PROGRESS_INV_4.png","PROGRESS_INV_5.png","PROGRESS_INV_6.png","PROGRESS_INV_7.png","PROGRESS_INV_8.png","PROGRESS_INV_9.png","PROGRESS_INV_10.png"],
              image_length: 10,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 28,
              y: 196,
              src: 'LOCK_SMALL.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 4,
              y: 224,
              src: 'DND_SMALL.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 28,
              y: 252,
              src: 'BT_SMALL.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 440,
              y: 196,
              src: 'ALARM_SMALL.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 216,
              y: 416,
              font_array: ["NUM_SMALL_0.png","NUM_SMALL_1.png","NUM_SMALL_2.png","NUM_SMALL_3.png","NUM_SMALL_4.png","NUM_SMALL_5.png","NUM_SMALL_6.png","NUM_SMALL_7.png","NUM_SMALL_8.png","NUM_SMALL_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 172,
              y: 416,
              image_array: ["BATTERY_ICON_0.png","BATTERY_ICON_1.png","BATTERY_ICON_2.png","BATTERY_ICON_3.png","BATTERY_ICON_4.png","BATTERY_ICON_5.png","BATTERY_ICON_6.png","BATTERY_ICON_7.png","BATTERY_ICON_8.png","BATTERY_ICON_9.png","BATTERY_ICON_10.png","BATTERY_ICON_11.png","BATTERY_ICON_12.png","BATTERY_ICON_13.png","BATTERY_ICON_14.png","BATTERY_ICON_15.png"],
              image_length: 16,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 118,
              y: 34,
              week_en: ["DAY_INV_01.png","DAY_INV_02.png","DAY_INV_03.png","DAY_INV_04.png","DAY_INV_05.png","DAY_INV_06.png","DAY_INV_07.png"],
              week_tc: ["DAY_INV_01.png","DAY_INV_02.png","DAY_INV_03.png","DAY_INV_04.png","DAY_INV_05.png","DAY_INV_06.png","DAY_INV_07.png"],
              week_sc: ["DAY_INV_01.png","DAY_INV_02.png","DAY_INV_03.png","DAY_INV_04.png","DAY_INV_05.png","DAY_INV_06.png","DAY_INV_07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 278,
              month_startY: 34,
              month_sc_array: ["MONTH_INV_01.png","MONTH_INV_02.png","MONTH_INV_03.png","MONTH_INV_04.png","MONTH_INV_05.png","MONTH_INV_06.png","MONTH_INV_07.png","MONTH_INV_08.png","MONTH_INV_09.png","MONTH_INV_10.png","MONTH_INV_11.png","MONTH_INV_12.png"],
              month_tc_array: ["MONTH_INV_01.png","MONTH_INV_02.png","MONTH_INV_03.png","MONTH_INV_04.png","MONTH_INV_05.png","MONTH_INV_06.png","MONTH_INV_07.png","MONTH_INV_08.png","MONTH_INV_09.png","MONTH_INV_10.png","MONTH_INV_11.png","MONTH_INV_12.png"],
              month_en_array: ["MONTH_INV_01.png","MONTH_INV_02.png","MONTH_INV_03.png","MONTH_INV_04.png","MONTH_INV_05.png","MONTH_INV_06.png","MONTH_INV_07.png","MONTH_INV_08.png","MONTH_INV_09.png","MONTH_INV_10.png","MONTH_INV_11.png","MONTH_INV_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 216,
              day_startY: 40,
              day_sc_array: ["NUM_SMALL_0.png","NUM_SMALL_1.png","NUM_SMALL_2.png","NUM_SMALL_3.png","NUM_SMALL_4.png","NUM_SMALL_5.png","NUM_SMALL_6.png","NUM_SMALL_7.png","NUM_SMALL_8.png","NUM_SMALL_9.png"],
              day_tc_array: ["NUM_SMALL_0.png","NUM_SMALL_1.png","NUM_SMALL_2.png","NUM_SMALL_3.png","NUM_SMALL_4.png","NUM_SMALL_5.png","NUM_SMALL_6.png","NUM_SMALL_7.png","NUM_SMALL_8.png","NUM_SMALL_9.png"],
              day_en_array: ["NUM_SMALL_0.png","NUM_SMALL_1.png","NUM_SMALL_2.png","NUM_SMALL_3.png","NUM_SMALL_4.png","NUM_SMALL_5.png","NUM_SMALL_6.png","NUM_SMALL_7.png","NUM_SMALL_8.png","NUM_SMALL_9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 0,
              y: 286,
              image_array: ["WEATHER_INV_01.png","WEATHER_INV_02.png","WEATHER_INV_03.png","WEATHER_INV_04.png","WEATHER_INV_05.png","WEATHER_INV_06.png","WEATHER_INV_07.png","WEATHER_INV_08.png","WEATHER_INV_09.png","WEATHER_INV_10.png","WEATHER_INV_11.png","WEATHER_INV_12.png","WEATHER_INV_13.png","WEATHER_INV_14.png","WEATHER_INV_15.png","WEATHER_INV_16.png","WEATHER_INV_17.png","WEATHER_INV_18.png","WEATHER_INV_19.png","WEATHER_INV_20.png","WEATHER_INV_21.png","WEATHER_INV_22.png","WEATHER_INV_23.png","WEATHER_INV_24.png","WEATHER_INV_25.png","WEATHER_INV_26.png","WEATHER_INV_27.png","WEATHER_INV_28.png","WEATHER_INV_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 320,
              y: 332,
              font_array: ["NUM_SMALL_0.png","NUM_SMALL_1.png","NUM_SMALL_2.png","NUM_SMALL_3.png","NUM_SMALL_4.png","NUM_SMALL_5.png","NUM_SMALL_6.png","NUM_SMALL_7.png","NUM_SMALL_8.png","NUM_SMALL_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'NUM_SMALL_HALF_DEG.png',
              unit_tc: 'NUM_SMALL_HALF_DEG.png',
              unit_en: 'NUM_SMALL_HALF_DEG.png',
              negative_image: 'NUM_SMALL_HALF_DASH.png',
              invalid_image: 'NUM_SMALL_DASH.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 326,
              y: 366,
              src: 'PLATE_INV_MAX.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 64,
              y: 332,
              font_array: ["NUM_SMALL_0.png","NUM_SMALL_1.png","NUM_SMALL_2.png","NUM_SMALL_3.png","NUM_SMALL_4.png","NUM_SMALL_5.png","NUM_SMALL_6.png","NUM_SMALL_7.png","NUM_SMALL_8.png","NUM_SMALL_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'NUM_SMALL_HALF_DEG.png',
              unit_tc: 'NUM_SMALL_HALF_DEG.png',
              unit_en: 'NUM_SMALL_HALF_DEG.png',
              negative_image: 'NUM_SMALL_HALF_DASH.png',
              invalid_image: 'NUM_SMALL_DASH.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 70,
              y: 366,
              src: 'PLATE_INV_MIN.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 146,
              y: 338,
              font_array: ["NUM_MEDIUM_0.png","NUM_MEDIUM_1.png","NUM_MEDIUM_2.png","NUM_MEDIUM_3.png","NUM_MEDIUM_4.png","NUM_MEDIUM_5.png","NUM_MEDIUM_6.png","NUM_MEDIUM_7.png","NUM_MEDIUM_8.png","NUM_MEDIUM_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'NUM_MEDIUM_HALF_DEG.png',
              unit_tc: 'NUM_MEDIUM_HALF_DEG.png',
              unit_en: 'NUM_MEDIUM_HALF_DEG.png',
              negative_image: 'NUM_MEDIUM_HALF_DASH.png',
              invalid_image: 'NUM_MEDIUM_HALF_DASH.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 60,
              hour_startY: 192,
              hour_array: ["NUM_LARGE_0.png","NUM_LARGE_1.png","NUM_LARGE_2.png","NUM_LARGE_3.png","NUM_LARGE_4.png","NUM_LARGE_5.png","NUM_LARGE_6.png","NUM_LARGE_7.png","NUM_LARGE_8.png","NUM_LARGE_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_unit_sc: 'NUM_LARGE_COLON.png',
              hour_unit_tc: 'NUM_LARGE_COLON.png',
              hour_unit_en: 'NUM_LARGE_COLON.png',
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 276,
              minute_startY: 192,
              minute_array: ["NUM_LARGE_0.png","NUM_LARGE_1.png","NUM_LARGE_2.png","NUM_LARGE_3.png","NUM_LARGE_4.png","NUM_LARGE_5.png","NUM_LARGE_6.png","NUM_LARGE_7.png","NUM_LARGE_8.png","NUM_LARGE_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 1,
              minute_align: hmUI.align.LEFT,

              second_startX: 428,
              second_startY: 252,
              second_array: ["NUM_SMALL_0.png","NUM_SMALL_1.png","NUM_SMALL_2.png","NUM_SMALL_3.png","NUM_SMALL_4.png","NUM_SMALL_5.png","NUM_SMALL_6.png","NUM_SMALL_7.png","NUM_SMALL_8.png","NUM_SMALL_9.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'GRID_BLURED.png',
              // alpha: 200,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img.setAlpha(200);

            // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'SECONDS.png',
              // center_x: 240,
              // center_y: 240,
              // x: 8,
              // y: 240,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_time_pointer_smooth_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'SECONDS.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 8,
              second_posY: 240,
              fresh_frequency: 15,
              fresh_freqency: 15,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_smooth_second = hmUI.createWidget(hmUI.widget.SMOOTH_SECOND, {
              // type: 3,
              // fps: 15,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });



            console.log('Watch_Face.ScreenAOD');
            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 190,
              y: 106,
              font_array: ["NUM_MEDIUM_0.png","NUM_MEDIUM_1.png","NUM_MEDIUM_2.png","NUM_MEDIUM_3.png","NUM_MEDIUM_4.png","NUM_MEDIUM_5.png","NUM_MEDIUM_6.png","NUM_MEDIUM_7.png","NUM_MEDIUM_8.png","NUM_MEDIUM_9.png"],
              padding: true,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 144,
              y: 108,
              src: 'HEART_LARGE.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 60,
              hour_startY: 192,
              hour_array: ["NUM_LARGE_0.png","NUM_LARGE_1.png","NUM_LARGE_2.png","NUM_LARGE_3.png","NUM_LARGE_4.png","NUM_LARGE_5.png","NUM_LARGE_6.png","NUM_LARGE_7.png","NUM_LARGE_8.png","NUM_LARGE_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_unit_sc: 'NUM_LARGE_COLON.png',
              hour_unit_tc: 'NUM_LARGE_COLON.png',
              hour_unit_en: 'NUM_LARGE_COLON.png',
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 0,
              minute_startY: 0,
              minute_array: ["NUM_LARGE_0.png","NUM_LARGE_1.png","NUM_LARGE_2.png","NUM_LARGE_3.png","NUM_LARGE_4.png","NUM_LARGE_5.png","NUM_LARGE_6.png","NUM_LARGE_7.png","NUM_LARGE_8.png","NUM_LARGE_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 1,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 28,
              y: 196,
              src: 'LOCK_SMALL.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 4,
              y: 224,
              src: 'DND_SMALL.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 28,
              y: 252,
              src: 'BT_SMALL.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 440,
              y: 196,
              src: 'ALARM_SMALL.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 216,
              y: 416,
              font_array: ["NUM_SMALL_0.png","NUM_SMALL_1.png","NUM_SMALL_2.png","NUM_SMALL_3.png","NUM_SMALL_4.png","NUM_SMALL_5.png","NUM_SMALL_6.png","NUM_SMALL_7.png","NUM_SMALL_8.png","NUM_SMALL_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 172,
              y: 416,
              image_array: ["BATTERY_ICON_0.png","BATTERY_ICON_1.png","BATTERY_ICON_2.png","BATTERY_ICON_3.png","BATTERY_ICON_4.png","BATTERY_ICON_5.png","BATTERY_ICON_6.png","BATTERY_ICON_7.png","BATTERY_ICON_8.png","BATTERY_ICON_9.png","BATTERY_ICON_10.png","BATTERY_ICON_11.png","BATTERY_ICON_12.png","BATTERY_ICON_13.png","BATTERY_ICON_14.png","BATTERY_ICON_15.png"],
              image_length: 16,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 118,
              y: 34,
              week_en: ["DAY_01.png","DAY_02.png","DAY_03.png","DAY_04.png","DAY_05.png","DAY_06.png","DAY_07.png"],
              week_tc: ["DAY_01.png","DAY_02.png","DAY_03.png","DAY_04.png","DAY_05.png","DAY_06.png","DAY_07.png"],
              week_sc: ["DAY_01.png","DAY_02.png","DAY_03.png","DAY_04.png","DAY_05.png","DAY_06.png","DAY_07.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 278,
              month_startY: 34,
              month_sc_array: ["MONTH_01.png","MONTH_02.png","MONTH_03.png","MONTH_04.png","MONTH_05.png","MONTH_06.png","MONTH_07.png","MONTH_08.png","MONTH_09.png","MONTH_10.png","MONTH_11.png","MONTH_12.png"],
              month_tc_array: ["MONTH_01.png","MONTH_02.png","MONTH_03.png","MONTH_04.png","MONTH_05.png","MONTH_06.png","MONTH_07.png","MONTH_08.png","MONTH_09.png","MONTH_10.png","MONTH_11.png","MONTH_12.png"],
              month_en_array: ["MONTH_01.png","MONTH_02.png","MONTH_03.png","MONTH_04.png","MONTH_05.png","MONTH_06.png","MONTH_07.png","MONTH_08.png","MONTH_09.png","MONTH_10.png","MONTH_11.png","MONTH_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 216,
              day_startY: 40,
              day_sc_array: ["NUM_SMALL_0.png","NUM_SMALL_1.png","NUM_SMALL_2.png","NUM_SMALL_3.png","NUM_SMALL_4.png","NUM_SMALL_5.png","NUM_SMALL_6.png","NUM_SMALL_7.png","NUM_SMALL_8.png","NUM_SMALL_9.png"],
              day_tc_array: ["NUM_SMALL_0.png","NUM_SMALL_1.png","NUM_SMALL_2.png","NUM_SMALL_3.png","NUM_SMALL_4.png","NUM_SMALL_5.png","NUM_SMALL_6.png","NUM_SMALL_7.png","NUM_SMALL_8.png","NUM_SMALL_9.png"],
              day_en_array: ["NUM_SMALL_0.png","NUM_SMALL_1.png","NUM_SMALL_2.png","NUM_SMALL_3.png","NUM_SMALL_4.png","NUM_SMALL_5.png","NUM_SMALL_6.png","NUM_SMALL_7.png","NUM_SMALL_8.png","NUM_SMALL_9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: '24_grid_sharp_double_w_logo.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 25,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              console.log('checkConnection()');
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  vibro(25);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              if (scene != 1) timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 240,
              y: 84,
              w: 166,
              h: 70,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 74,
              y: 84,
              w: 166,
              h: 70,
              src: 'blank.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 167,
              y: 408,
              w: 146,
              h: 50,
              src: 'blank.png',
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 70,
              y: 330,
              w: 84,
              h: 80,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 326,
              y: 330,
              w: 84,
              h: 80,
              type: hmUI.data_type.MOON_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 156,
              y: 330,
              w: 168,
              h: 78,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 0,
              y: 192,
              w: 204,
              h: 96,
              src: 'blank.png',
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 276,
              y: 192,
              w: 204,
              h: 96,
              src: 'blank.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 114,
              y: 0,
              w: 252,
              h: 80,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'blank.png',
              normal_src: 'blank.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 204,
              y: 194,
              w: 72,
              h: 92,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'blank.png',
              normal_src: 'blank.png',
              click_func: (button_widget) => {
                toggleWorldClock(1);
              }, // end func
              longpress_func: (button_widget) => {
                //Show WorldClock
hmApp.startApp({url: 'WorldClockScreen', native: true });
reInitClock = true;

              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            console.log('user_script_end.js');
            // start user_script_end.js

curTime.addEventListener(curTime.event.MINUTEEND, function () {
    updateWorldTime();
});

function updateWorldTime() {
    if (!isAOD) {
        let worldHourValue = '00';
        let worldMinuteValue = '00';
        if (clockIndex > -1) {
            const worldData = worldClock.getWorldClockInfo(clockIndex);
			worldHourValue = worldData.hour.toString().padStart(2, "0");
			worldMinuteValue = worldData.minute.toString().padStart(2, "0");
        }
        normal_world_time_text_img.setProperty(hmUI.prop.TEXT, worldHourValue + '.' + worldMinuteValue);
    }
}

function updateTimeZone() {
    if (!isAOD) {
        let worldZoneHourValue = '00';
        let worldZoneMinuteValue = '00';
        let worldZoneSign = 3;
        let cityCodeChr1 = 7;
        let cityCodeChr2 = 13;
        let cityCodeChr3 = 20;
        let codes = [];
        if (clockIndex > -1) {
            const worldData = worldClock.getWorldClockInfo(clockIndex);
            cityCode = worldData.cityCode;

            cityCodeChr1 = cityCode.charCodeAt(0) - 64;
            cityCodeChr2 = cityCode.charCodeAt(1) - 64;
            cityCodeChr3 = cityCode.charCodeAt(2) - 64;

            togleDisplay(false);
            codes = string2levels(worldData.city.toUpperCase());
            displayCodesAsText(codes);

            let offset = new Date().getTimezoneOffset();
            let off_hh = parseInt(Math.trunc(offset / 60));
            let off_mm = parseInt(offset % 60);

            let timeZoneHour = parseInt(worldData.timeZoneHour) - off_hh;
            let timeZoneMinute = parseInt(worldData.timeZoneMinute) - off_mm;

            if (timeZoneHour > 0) {
                worldZoneHourValue = timeZoneHour.toString().padStart(2, "0");
            } else {
                worldZoneHourValue = (timeZoneHour * -1).toString().padStart(2, "0");
                worldZoneSign = 1;
            }

            if (timeZoneMinute > 0) {
                worldZoneMinuteValue = timeZoneMinute.toString().padStart(2, "0");
            } else {
                worldZoneMinuteValue = (timeZoneMinute * -1).toString().padStart(2, "0");
            }
        } else {
            togleDisplay(true);
        }

        if (showTimeZone) {
            normal_world_time_zone_text_img.setProperty(hmUI.prop.TEXT, worldZoneHourValue + '.' + worldZoneMinuteValue);
            normal_world_time_img_level.setProperty(hmUI.prop.LEVEL, worldZoneSign);
            normal_world_time_chr1_level.setProperty(hmUI.prop.LEVEL, cityCodeChr1);
            normal_world_time_chr2_level.setProperty(hmUI.prop.LEVEL, cityCodeChr2);
            normal_world_time_chr3_level.setProperty(hmUI.prop.LEVEL, cityCodeChr3);
        }
        updateWorldTime();
    }
}

function toggleWorldClock(step = 1) {
    const count = worldClock.getWorldClockCount();
    if (count) {
        clockIndex += step;
        if (clockIndex < -1)
            clockIndex = count - 1;
        if (clockIndex > count)
            clockIndex =  - 1;
        updateTimeZone();
        updateWorldTime();
    } else {
        togleDisplay(true);
    }
}

function initWorldClock() {
    if (reInitClock) {
        clockIndex = -1;
        worldClock.uninit();
        reInitClock = false;
    }
    worldClock.init();
    let count = worldClock.getWorldClockCount();
    if (count > 0) {
        clockIndex = 0;
        togleDisplay(false);
    } else {
        togleDisplay(true);
    }
}

function togleDisplay(swith) {
    normal_stress_text_text_img.setProperty(hmUI.prop.VISIBLE, swith);
    normal_stress_text_separator_img.setProperty(hmUI.prop.VISIBLE, swith);
    normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, swith);
    normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, swith);
    normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, swith);
    normal_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, swith);
    normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, swith);
    normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, swith);
    normal_step_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, swith);
    normal_step_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, swith);
    normal_heart_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, swith);

    normal_world_time_text_img.setProperty(hmUI.prop.VISIBLE, !swith);

    if (showTimeZone) {
        normal_world_time_zone_text_img.setProperty(hmUI.prop.VISIBLE, !swith);
        normal_world_time_gmt_img.setProperty(hmUI.prop.VISIBLE, !swith);

        normal_world_time_img_level.setProperty(hmUI.prop.VISIBLE, !swith);
        normal_world_time_chr1_level.setProperty(hmUI.prop.VISIBLE, !swith);
        normal_world_time_chr2_level.setProperty(hmUI.prop.VISIBLE, !swith);
        normal_world_time_chr3_level.setProperty(hmUI.prop.VISIBLE, !swith);

        normal_top_text_line_01.setProperty(hmUI.prop.VISIBLE, false);
        normal_top_text_line_02.setProperty(hmUI.prop.VISIBLE, false);
        normal_top_text_line_03.setProperty(hmUI.prop.VISIBLE, false);
        normal_top_text_line_04.setProperty(hmUI.prop.VISIBLE, false);
        normal_top_text_line_05.setProperty(hmUI.prop.VISIBLE, false);
        normal_top_text_line_06.setProperty(hmUI.prop.VISIBLE, false);
        normal_top_text_line_07.setProperty(hmUI.prop.VISIBLE, false);
        normal_top_text_line_08.setProperty(hmUI.prop.VISIBLE, false);
        normal_top_text_line_09.setProperty(hmUI.prop.VISIBLE, false);
        normal_top_text_line_10.setProperty(hmUI.prop.VISIBLE, false);
        normal_top_text_line_11.setProperty(hmUI.prop.VISIBLE, false);
        normal_top_text_line_12.setProperty(hmUI.prop.VISIBLE, false);
        normal_top_text_line_13.setProperty(hmUI.prop.VISIBLE, false);
        normal_top_text_line_14.setProperty(hmUI.prop.VISIBLE, false);
        normal_top_text_line_15.setProperty(hmUI.prop.VISIBLE, false);
        normal_top_text_line_16.setProperty(hmUI.prop.VISIBLE, false);
    } else {
        normal_world_time_zone_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_world_time_gmt_img.setProperty(hmUI.prop.VISIBLE, false);

        normal_world_time_img_level.setProperty(hmUI.prop.VISIBLE, false);
        normal_world_time_chr1_level.setProperty(hmUI.prop.VISIBLE, false);
        normal_world_time_chr2_level.setProperty(hmUI.prop.VISIBLE, false);
        normal_world_time_chr3_level.setProperty(hmUI.prop.VISIBLE, false);

        normal_top_text_line_01.setProperty(hmUI.prop.VISIBLE, !swith);
        normal_top_text_line_02.setProperty(hmUI.prop.VISIBLE, !swith);
        normal_top_text_line_03.setProperty(hmUI.prop.VISIBLE, !swith);
        normal_top_text_line_04.setProperty(hmUI.prop.VISIBLE, !swith);
        normal_top_text_line_05.setProperty(hmUI.prop.VISIBLE, !swith);
        normal_top_text_line_06.setProperty(hmUI.prop.VISIBLE, !swith);
        normal_top_text_line_07.setProperty(hmUI.prop.VISIBLE, !swith);
        normal_top_text_line_08.setProperty(hmUI.prop.VISIBLE, !swith);
        normal_top_text_line_09.setProperty(hmUI.prop.VISIBLE, !swith);
        normal_top_text_line_10.setProperty(hmUI.prop.VISIBLE, !swith);
        normal_top_text_line_11.setProperty(hmUI.prop.VISIBLE, !swith);
        normal_top_text_line_12.setProperty(hmUI.prop.VISIBLE, !swith);
        normal_top_text_line_13.setProperty(hmUI.prop.VISIBLE, !swith);
        normal_top_text_line_14.setProperty(hmUI.prop.VISIBLE, !swith);
        normal_top_text_line_15.setProperty(hmUI.prop.VISIBLE, !swith);
        normal_top_text_line_16.setProperty(hmUI.prop.VISIBLE, !swith);
    }
}

function string2levels(str) {
    if (str.length > 16) {
        str = str.substring(0, 16);
    }
    if (str.length < 16) {
        strLen = str.length;
        padLen = Math.trunc((16 - strLen) / 2);
        str = str.padStart(strLen + padLen, ' ');
        str = str.padEnd(16, ' ');
    }
    codes = []
    for (i = 0; i < str.length; i++) {
        charCode = str.charCodeAt(i);
        if (charCode < 1000)
            charCode = charCode - 31;
        if (charCode > 1000)
            charCode = charCode - 879;
        codes[i] = charCode;
    }
    return codes;
}

function displayCodesAsText(codes) {
    normal_top_text_line_01.setProperty(hmUI.prop.LEVEL, codes[0]);
    normal_top_text_line_02.setProperty(hmUI.prop.LEVEL, codes[1]);
    normal_top_text_line_03.setProperty(hmUI.prop.LEVEL, codes[2]);
    normal_top_text_line_04.setProperty(hmUI.prop.LEVEL, codes[3]);
    normal_top_text_line_05.setProperty(hmUI.prop.LEVEL, codes[4]);
    normal_top_text_line_06.setProperty(hmUI.prop.LEVEL, codes[5]);
    normal_top_text_line_07.setProperty(hmUI.prop.LEVEL, codes[6]);
    normal_top_text_line_08.setProperty(hmUI.prop.LEVEL, codes[7]);
    normal_top_text_line_09.setProperty(hmUI.prop.LEVEL, codes[8]);
    normal_top_text_line_10.setProperty(hmUI.prop.LEVEL, codes[9]);
    normal_top_text_line_11.setProperty(hmUI.prop.LEVEL, codes[10]);
    normal_top_text_line_12.setProperty(hmUI.prop.LEVEL, codes[11]);
    normal_top_text_line_13.setProperty(hmUI.prop.LEVEL, codes[12]);
    normal_top_text_line_14.setProperty(hmUI.prop.LEVEL, codes[13]);
    normal_top_text_line_15.setProperty(hmUI.prop.LEVEL, codes[14]);
    normal_top_text_line_16.setProperty(hmUI.prop.LEVEL, codes[15]);
}

            // end user_script_end.js

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                checkConnection();
                stopVibro();

                console.log('resume_call.js');
                // start resume_call.js

if (reInitClock && !isAOD) initWorldClock();
updateWorldTime();
updateTimeZone();

                // end resume_call.js

              }),
              pause_call: (function () {
                console.log('pause_call()');
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
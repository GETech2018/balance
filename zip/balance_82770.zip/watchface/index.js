﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_vo2max_current_text_img = ''
        let normal_vo2max_pointer_progress_img_pointer = ''
        let normal_weather_image_progress_img_level = ''
        let normal_heart_rate_text_text_img = ''
        let normal_battery_text_text_img = ''
        let normal_compass_text_img = ''
        let normal_compass_direction_img_level = ''
        let normal_compass_direction_arr = ["d_1.png", "d_2.png", "d_3.png", "d_4.png", "d_5.png", "d_6.png", "d_7.png", "d_8.png"];
        let normal_altitude_target_text_img = ''
        let normal_altimeter_text_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_step_current_text_img = ''
        let normal_date_img_date_month_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg_img = ''
        let idle_battery_pointer_progress_img_pointer = ''
        let idle_date_img_date_month_img = ''
        let idle_digital_clock_img_time = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let normal_step_jumpable_img_click = ''
        let normal_cal_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_battery_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_altimeter_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_altitude_jumpable_img_click = ''
        let normal_vo2max_jumpable_img_click = ''
        let Button_1 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'BG.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_vo2max_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 213,
              y: 393,
              font_array: ["vo_0.png","vo_1.png","vo_2.png","vo_3.png","vo_4.png","vo_5.png","vo_6.png","vo_7.png","vo_8.png","vo_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.VO2MAX,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_vo2max_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'data_point.png',
              center_x: 240,
              center_y: 375,
              x: 15,
              y: 70,
              start_angle: -130,
              end_angle: 130,
              invalid_visible: false,
              type: hmUI.data_type.VO2MAX,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 216,
              y: 129,
              image_array: ["1.png","2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png","12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png","22.png","23.png","24.png","25.png","26.png","27.png","28.png","29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 83,
              y: 345,
              font_array: ["black_0.png","black_1.png","black_2.png","black_3.png","black_4.png","black_5.png","black_6.png","black_7.png","black_8.png","black_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 346,
              y: 345,
              font_array: ["black_0.png","black_1.png","black_2.png","black_3.png","black_4.png","black_5.png","black_6.png","black_7.png","black_8.png","black_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_compass_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 300,
              y: 229,
              font_array: ["black_0.png","black_1.png","black_2.png","black_3.png","black_4.png","black_5.png","black_6.png","black_7.png","black_8.png","black_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              // type: hmUI.data_type.COMPASS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_compass_direction_img_level = hmUI.createWidget(hmUI.widget.IMG, {
              x: 297,
              y: 228,
              src: 'd_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
              // type: hmUI.data_type.COMPASS,
            });

            normal_altitude_target_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 317,
              y: 260,
              font_array: ["black_0.png","black_1.png","black_2.png","black_3.png","black_4.png","black_5.png","black_6.png","black_7.png","black_8.png","black_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.ALTITUDE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 317,
              y: 196,
              font_array: ["black_0.png","black_1.png","black_2.png","black_3.png","black_4.png","black_5.png","black_6.png","black_7.png","black_8.png","black_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 97,
              y: 229,
              font_array: ["black_0.png","black_1.png","black_2.png","black_3.png","black_4.png","black_5.png","black_6.png","black_7.png","black_8.png","black_9.png"],
              padding: false,
              h_space: 0,
              dot_image: 'dot.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 100,
              y: 196,
              font_array: ["black_0.png","black_1.png","black_2.png","black_3.png","black_4.png","black_5.png","black_6.png","black_7.png","black_8.png","black_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 96,
              y: 260,
              font_array: ["black_0.png","black_1.png","black_2.png","black_3.png","black_4.png","black_5.png","black_6.png","black_7.png","black_8.png","black_9.png"],
              padding: false,
              h_space: -1,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 6,
              month_startY: 64,
              month_sc_array: ["m_1.png","m_2.png","m_3.png","m_4.png","m_5.png","m_6.png","m_7.png","m_8.png","m_9.png","m_10.png","m_11.png","m_12.png"],
              month_tc_array: ["m_1.png","m_2.png","m_3.png","m_4.png","m_5.png","m_6.png","m_7.png","m_8.png","m_9.png","m_10.png","m_11.png","m_12.png"],
              month_en_array: ["m_1.png","m_2.png","m_3.png","m_4.png","m_5.png","m_6.png","m_7.png","m_8.png","m_9.png","m_10.png","m_11.png","m_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 117,
              am_y: 83,
              am_sc_path: 'am.png',
              am_en_path: 'am.png',
              pm_x: 117,
              pm_y: 83,
              pm_sc_path: 'pm.png',
              pm_en_path: 'pm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 151,
              hour_startY: 81,
              hour_array: ["time_0.png","time_1.png","time_2.png","time_3.png","time_4.png","time_5.png","time_6.png","time_7.png","time_8.png","time_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_unit_sc: 'maohao.png',
              hour_unit_tc: 'maohao.png',
              hour_unit_en: 'maohao.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 250,
              minute_startY: 81,
              minute_array: ["time_0.png","time_1.png","time_2.png","time_3.png","time_4.png","time_5.png","time_6.png","time_7.png","time_8.png","time_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'h.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 46,
              hour_posY: 240,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'm.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 42,
              minute_posY: 240,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 's.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 21,
              second_posY: 239,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'aod.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'data_point.png',
              center_x: 240,
              center_y: 375,
              x: 15,
              y: 70,
              start_angle: -150,
              end_angle: 150,
              invalid_visible: false,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 6,
              month_startY: 64,
              month_sc_array: ["m_1.png","m_2.png","m_3.png","m_4.png","m_5.png","m_6.png","m_7.png","m_8.png","m_9.png","m_10.png","m_11.png","m_12.png"],
              month_tc_array: ["m_1.png","m_2.png","m_3.png","m_4.png","m_5.png","m_6.png","m_7.png","m_8.png","m_9.png","m_10.png","m_11.png","m_12.png"],
              month_en_array: ["m_1.png","m_2.png","m_3.png","m_4.png","m_5.png","m_6.png","m_7.png","m_8.png","m_9.png","m_10.png","m_11.png","m_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 151,
              hour_startY: 81,
              hour_array: ["aodtime_0.png","aodtime_1.png","aodtime_2.png","aodtime_3.png","aodtime_4.png","aodtime_5.png","aodtime_6.png","aodtime_7.png","aodtime_8.png","aodtime_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_unit_sc: 'aodmaohao.png',
              hour_unit_tc: 'aodmaohao.png',
              hour_unit_en: 'aodmaohao.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 250,
              minute_startY: 81,
              minute_array: ["aodtime_0.png","aodtime_1.png","aodtime_2.png","aodtime_3.png","aodtime_4.png","aodtime_5.png","aodtime_6.png","aodtime_7.png","aodtime_8.png","aodtime_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'aodh.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 45,
              hour_posY: 239,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'aodm.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 41,
              minute_posY: 239,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 95,
              y: 256,
              w: 75,
              h: 45,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_cal_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 95,
              y: 190,
              w: 75,
              h: 60,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 80,
              y: 340,
              w: 50,
              h: 50,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 350,
              y: 340,
              w: 50,
              h: 50,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 207,
              y: 135,
              w: 60,
              h: 60,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 335,
              y: 172,
              w: 75,
              h: 45,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 258,
              y: 78,
              w: 60,
              h: 50,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 161,
              y: 78,
              w: 60,
              h: 50,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altitude_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 335,
              y: 260,
              w: 75,
              h: 45,
              type: hmUI.data_type.ALTITUDE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_vo2max_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 195,
              y: 335,
              w: 100,
              h: 100,
              type: hmUI.data_type.VO2MAX,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 330,
              y: 223,
              w: 80,
              h: 30,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'CompassScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            let screenType = hmSetting.getScreenType();
            //start of ignored block
            console.log('compass_update()');
            if (screenType == hmSetting.screen_type.WATCHFACE){
              compass = hmSensor.createSensor(hmSensor.id.COMPASS);
              compass.start();

              if (compass.direction_angle && compass.direction  && compass.direction_angle != 'INVALID') { // initial data
                // Compass Number
                let compass_direction_angle = parseInt(compass.direction_angle);
                let normal_compass_direction_angle_text = compass_direction_angle.toString();
                normal_compass_text_img.setProperty(hmUI.prop.TEXT, normal_compass_direction_angle_text);
                // Compass Images
                let compass_direction_angle_img = compass_direction_angle + 45 / 2;
                let compass_direction_index = parseInt(compass_direction_angle_img/45);
                if (compass_direction_index > 7) compass_direction_index = 0;
                normal_compass_direction_img_level.setProperty(hmUI.prop.SRC, normal_compass_direction_arr[compass_direction_index]);

              } else { // error data
                normal_compass_text_img.setProperty(hmUI.prop.TEXT, '-');
                normal_compass_direction_img_level.setProperty(hmUI.prop.SRC, normal_compass_direction_arr[0]);

              }

              compass.addEventListener(hmSensor.event.CHANGE, function (compass_res) { // change values when changing direction

                if (compass_res.calibration_status) {
                  // Compass Number
                  let compass_direction_angle = parseInt(compass_res.direction_angle);
                  let normal_compass_direction_angle_text = compass_direction_angle.toString();
                  normal_compass_text_img.setProperty(hmUI.prop.TEXT, normal_compass_direction_angle_text);
                  // Compass Images
                  let compass_direction_angle_img = compass_direction_angle + 45 / 2;
                  let compass_direction_index = parseInt(compass_direction_angle_img/45);
                  if (compass_direction_index > 7) compass_direction_index = 0;
                  normal_compass_direction_img_level.setProperty(hmUI.prop.SRC, normal_compass_direction_arr[compass_direction_index]);

                } else { // error data
                  normal_compass_text_img.setProperty(hmUI.prop.TEXT, '-');
                  normal_compass_direction_img_level.setProperty(hmUI.prop.SRC, normal_compass_direction_arr[0]);

                }

              }); // Listener end

            };
            //end of ignored block

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                if (compass && screenType == hmSetting.screen_type.WATCHFACE) compass.start();

              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (compass) compass.stop();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
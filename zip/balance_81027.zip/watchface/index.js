/*
** Facemaker bundle tool v0.0.3
* *huamiOS watchface js version v1.0.1
* *Copyright © Huami. All Rights Reserved
*/


try {
	(() => {
		var __$$app$$__ = __$$hmAppManager$$__.currentApp;
		var __$$module$$__ = __$$app$$__.current;

		//drink is a name,can modify
		var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

		'use strict';

		//dynamic modify start
		let normal_img0 = '';
		let timeInterval;
		let normal_hour_high_imageset2 = '';
		let normal_hour_high_imageset2_array = ['0003.png','0004.png','0005.png'];
		let normal_hour_low_imageset3 = '';
		let normal_hour_low_imageset3_array = ['0003.png','0004.png','0005.png','0006.png','0007.png','0008.png','0009.png','0010.png','0011.png','0012.png'];
		let normal_minute_high_imageset4 = '';
		let normal_minute_high_imageset4_array = ['0003.png','0004.png','0005.png','0006.png','0007.png','0008.png'];
		let normal_minute_low_imageset5 = '';
		let normal_minute_low_imageset5_array = ['0003.png','0004.png','0005.png','0006.png','0007.png','0008.png','0009.png','0010.png','0011.png','0012.png'];
		let normal_second_sweep_rotary7 = '';
		let clock_timer;
		let normal_date_high_imageset9 = '';
		let normal_date_high_imageset9_array = ['0014.png','0015.png','0016.png','0017.png','0018.png','0019.png','0020.png','0021.png','0022.png','0023.png'];
		let normal_date_low_imageset10 = '';
		let normal_date_low_imageset10_array = ['0014.png','0015.png','0016.png','0017.png','0018.png','0019.png','0020.png','0021.png','0022.png','0023.png'];
		let normal_month_imageset11 = '';
		let normal_week_imageset12 = '';
		let normal_steps_imagecombo14 = '';
		let normal_battery_imagecombo16 = '';
		let normal_heart_current_imagecombo18 = '';
		let normal_distance_imagecombo20 = '';
		let normal_temperature_current_imagecombo22 = '';
		let normal_weather_imageset23 = '';
		let normal_alarm_status25 = '';
		let normal_bt_status26 = '';
		let normal_weather_shortcut29 = '';
		let normal_heart_shortcut30 = '';
		let normal_steps_shortcut31 = '';
		let normal_alarm_shortcut32 = '';
		let normal_sleep_shortcut33 = '';
		let normal_countdown_shortcut34 = '';
		let normal_stress_shortcut35 = '';
		let idle_hour_high_imageset37 = '';
		let idle_hour_high_imageset37_array = ['0003.png','0004.png','0005.png'];
		let idle_hour_low_imageset38 = '';
		let idle_hour_low_imageset38_array = ['0003.png','0004.png','0005.png','0006.png','0007.png','0008.png','0009.png','0010.png','0011.png','0012.png'];
		let idle_minute_high_imageset39 = '';
		let idle_minute_high_imageset39_array = ['0003.png','0004.png','0005.png','0006.png','0007.png','0008.png'];
		let idle_minute_low_imageset40 = '';
		let idle_minute_low_imageset40_array = ['0003.png','0004.png','0005.png','0006.png','0007.png','0008.png','0009.png','0010.png','0011.png','0012.png'];
		//dynamic modify end

		//not required
		const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

		__$$module$$__.module = DeviceRuntimeCore.WatchFace({
			init_view() {

				const timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
				let screenType = hmSetting.getScreenType();

				normal_img0 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: -55,
					w: 480,
					h: 535,
					src: '0002.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_hour_high_imageset2 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 71,
					y: 195,
					w: 71,
					h: 195,
					src: '0005.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_hour_low_imageset3 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 157,
					y: 195,
					w: 157,
					h: 195,
					src: '0012.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_minute_high_imageset4 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 248,
					y: 195,
					w: 248,
					h: 195,
					src: '0008.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_minute_low_imageset5 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 334,
					y: 195,
					w: 334,
					h: 195,
					src: '0012.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_second_sweep_rotary7 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					center_x: 240,
					center_y: 240,
					pos_x: 0,
					pos_y: 0,
					src: '0013.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_date_high_imageset9 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 129,
					y: 57,
					w: 129,
					h: 57,
					src: '0023.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_date_low_imageset10 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 159,
					y: 57,
					w: 159,
					h: 57,
					src: '0023.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_month_imageset11 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
					month_startX: 216,
					month_startY: 42,
					month_sc_array: ["0024.png","0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png","0033.png","0034.png","0035.png"],
					month_tc_array: ["0024.png","0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png","0033.png","0034.png","0035.png"],
					month_en_array: ["0024.png","0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png","0033.png","0034.png","0035.png"],
					month_is_character: true,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_week_imageset12 = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
					x: 206,
					y: 73,
					week_en: ["0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png"],
					week_tc: ["0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png"],
					week_sc: ["0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png"],
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_steps_imagecombo14 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 104,
					y: 143,
					font_array: ["0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png","0050.png","0051.png","0052.png"],
					padding: false,
					h_space: 0,
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.STEP,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_battery_imagecombo16 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 309,
					y: 143,
					font_array: ["0053.png","0054.png","0055.png","0056.png","0057.png","0058.png","0059.png","0060.png","0061.png","0062.png"],
					padding: false,
					h_space: 0,
					unit_sc: '0063.png',
					unit_tc: '0063.png',
					unit_en: '0063.png',
					align_h: hmUI.align.RIGHT,
					type: hmUI.data_type.BATTERY,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_heart_current_imagecombo18 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 111,
					y: 357,
					font_array: ["0064.png","0065.png","0066.png","0067.png","0068.png","0069.png","0070.png","0071.png","0072.png","0073.png"],
					padding: false,
					h_space: 0,
					invalid_image: '0074.png',
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.HEART,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_distance_imagecombo20 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 296,
					y: 357,
					font_array: ["0053.png","0054.png","0055.png","0056.png","0057.png","0058.png","0059.png","0060.png","0061.png","0062.png"],
					padding: false,
					h_space: 0,
					dot_image: '0075.png',
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.DISTANCE,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_temperature_current_imagecombo22 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 208,
					y: 415,
					font_array: ["0064.png","0065.png","0066.png","0067.png","0068.png","0069.png","0070.png","0071.png","0072.png","0073.png"],
					padding: false,
					h_space: 0,
					unit_sc: ["0076.png"],
					unit_tc: ["0076.png"],
					unit_en: ["0076.png"],
					negative_image: ["0074.png"],
					invalid_image: ["0077.png"],
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.WEATHER_CURRENT,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_weather_imageset23 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
					x: 208,
					y: 349,
					image_array: ["0078.png","0079.png","0080.png","0081.png","0082.png","0083.png","0080.png","0084.png","0085.png","0086.png","0087.png","0088.png","0089.png","0090.png","0091.png","0092.png","0093.png","0094.png","0095.png","0096.png","0097.png","0098.png","0099.png","0100.png","0101.png","0102.png","0078.png","0079.png","0081.png"],
					image_length: 29,
					type: hmUI.data_type.WEATHER_CURRENT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_alarm_status25 = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
					x: 31,
					y: 237,
					w: 34,
					h: 39,
					type: hmUI.system_status.CLOCK,
					src: '0103.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_bt_status26 = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
					x: 418,
					y: 238,
					w: 29,
					h: 41,
					type: hmUI.system_status.DISCONNECT,
					src: '0104.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_weather_shortcut29 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 188,
					y: 339,
					w: 103,
					h: 103,
					src: '',
					type: hmUI.data_type.WEATHER_CURRENT,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_heart_shortcut30 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 80,
					y: 332,
					w: 103,
					h: 103,
					src: '',
					type: hmUI.data_type.HEART,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_steps_shortcut31 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 92,
					y: 108,
					w: 103,
					h: 70,
					src: '',
					type: hmUI.data_type.STEP,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_alarm_shortcut32 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 73,
					y: 206,
					w: 155,
					h: 103,
					src: '',
					type: hmUI.data_type.ALARM_CLOCK,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_sleep_shortcut33 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 200,
					y: 0,
					w: 155,
					h: 103,
					src: '',
					type: hmUI.data_type.SLEEP,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_countdown_shortcut34 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 249,
					y: 203,
					w: 155,
					h: 103,
					src: '',
					type: hmUI.data_type.COUNT_DOWN,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_stress_shortcut35 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 301,
					y: 115,
					w: 124,
					h: 62,
					src: '',
					type: hmUI.data_type.STRESS,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				idle_hour_high_imageset37 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 71,
					y: 195,
					w: 71,
					h: 195,
					src: '0005.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				})

				idle_hour_low_imageset38 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 157,
					y: 195,
					w: 157,
					h: 195,
					src: '0012.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				})

				idle_minute_high_imageset39 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 248,
					y: 195,
					w: 248,
					h: 195,
					src: '0008.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				})

				idle_minute_low_imageset40 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 334,
					y: 195,
					w: 334,
					h: 195,
					src: '0012.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				})

				function updateTime() {
					normal_hour_high_imageset2.setProperty(hmUI.prop.MORE, {
						src: normal_hour_high_imageset2_array[(timeSensor.format_hour.toString().length == 2 ? timeSensor.format_hour.toString().charAt(0) : 0)]
					})
					normal_hour_low_imageset3.setProperty(hmUI.prop.MORE, {
						src: normal_hour_low_imageset3_array[(timeSensor.format_hour.toString().length == 2 ? timeSensor.format_hour.toString().charAt(1) : timeSensor.format_hour.toString().charAt(0))]
					})
					normal_minute_high_imageset4.setProperty(hmUI.prop.MORE, {
						src: normal_minute_high_imageset4_array[(timeSensor.minute.toString().length == 2 ? timeSensor.minute.toString().charAt(0) : 0)]
					})
					normal_minute_low_imageset5.setProperty(hmUI.prop.MORE, {
						src: normal_minute_low_imageset5_array[(timeSensor.minute.toString().length == 2 ? timeSensor.minute.toString().charAt(1) : timeSensor.minute.toString().charAt(0))]
					})
					normal_date_high_imageset9.setProperty(hmUI.prop.MORE, {
						src: normal_date_high_imageset9_array[(timeSensor.day.toString().length == 2 ? timeSensor.day.toString().charAt(0) : 0)]
					})
					normal_date_low_imageset10.setProperty(hmUI.prop.MORE, {
						src: normal_date_low_imageset10_array[(timeSensor.day.toString().length == 2 ? timeSensor.day.toString().charAt(1) : timeSensor.day.toString().charAt(0))]
					})
					idle_hour_high_imageset37.setProperty(hmUI.prop.MORE, {
						src: idle_hour_high_imageset37_array[(timeSensor.format_hour.toString().length == 2 ? timeSensor.format_hour.toString().charAt(0) : 0)]
					})
					idle_hour_low_imageset38.setProperty(hmUI.prop.MORE, {
						src: idle_hour_low_imageset38_array[(timeSensor.format_hour.toString().length == 2 ? timeSensor.format_hour.toString().charAt(1) : timeSensor.format_hour.toString().charAt(0))]
					})
					idle_minute_high_imageset39.setProperty(hmUI.prop.MORE, {
						src: idle_minute_high_imageset39_array[(timeSensor.minute.toString().length == 2 ? timeSensor.minute.toString().charAt(0) : 0)]
					})
					idle_minute_low_imageset40.setProperty(hmUI.prop.MORE, {
						src: idle_minute_low_imageset40_array[(timeSensor.minute.toString().length == 2 ? timeSensor.minute.toString().charAt(1) : timeSensor.minute.toString().charAt(0))]
					})
				}

				timeSensor.addEventListener(hmSensor.event.CHANGE, function() {
					updateTime();
				});

				const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
					resume_call: (function () {
						const animFps = 60;
						const animRepeat = 1000/animFps;
						const animProgress = 6/animFps;
						let animAngle = 0;
						let animDelay = 0;
						clock_timer = timer.createTimer(animDelay, animRepeat, (function(option) {
							animAngle = timeSensor.second * 6 + ((timeSensor.utc % 1000) / 1000) * 6;
							normal_second_sweep_rotary7.setProperty(hmUI.prop.ANGLE, animAngle);
						}));

						updateTime();
						timeInterval = setInterval(updateTime, 1000);
					}),
					pause_call: (function () {
						timer.stopTimer(clock_timer);
						clearInterval(timeInterval);
					}),
				})
			},

		onInit() {
			console.log('index page.js on init invoke')
			this.init_view()
		},
		onReady() {
			console.log('index page.js on ready invoke')
		},
		onShow() {
			console.log('index page.js on show invoke')
		},
		onHide() {
			console.log('index page.js on hide invoke')
		},
		onDestroy() {
			console.log('index page.js on destroy invoke')
						timer.stopTimer(clock_timer);
		},
	});	})()
} catch (e) {
	console.log(e)
}
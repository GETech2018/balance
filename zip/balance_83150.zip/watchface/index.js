﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (()=>{
        //dynamic modify start

        const lang = DeviceRuntimeCore.HmUtils.getLanguage()
        let normal_background_bg_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_temperature_current_TextRotate = new Array(4);
        let normal_temperature_current_TextRotate_ASCIIARRAY = new Array(10);
        let normal_temperature_current_TextRotate_img_width = 18;
        let normal_temperature_current_TextRotate_unit = null;
        let normal_temperature_current_TextRotate_unit_width = 29;
        let normal_temperature_current_TextRotate_dot_width = 18;
        let normal_altitude_target_text_img = ''
        let normal_altimeter_text_text_img = ''
        let normal_fat_burning_TextRotate = new Array(3);
        let normal_fat_burning_TextRotate_ASCIIARRAY = new Array(10);
        let normal_fat_burning_TextRotate_img_width = 18;
        let normal_fat_burning_TextRotate_unit = null;
        let normal_fat_burning_TextRotate_unit_width = 29;
        let normal_fat_burning_image_progress_img_level = ''
        let normal_stand_TextRotate = new Array(2);
        let normal_stand_TextRotate_ASCIIARRAY = new Array(10);
        let normal_stand_TextRotate_img_width = 18;
        let normal_stand_TextRotate_unit = null;
        let normal_stand_TextRotate_unit_width = 18;
        let normal_stand_image_progress_img_level = ''
        let normal_distance_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_calorie_TextRotate = new Array(4);
        let normal_calorie_TextRotate_ASCIIARRAY = new Array(10);
        let normal_calorie_TextRotate_img_width = 18;
        let normal_calorie_image_progress_img_level = ''
        let normal_pai_icon_img = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_day = ''
        let idle_fat_burning_image_progress_img_level = ''
        let idle_stand_image_progress_img_level = ''
        let idle_calorie_image_progress_img_level = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_pai_icon_img = ''
        let normal_step_jumpable_img_click = ''
        let normal_cal_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_stand_jumpable_img_click = ''
        let normal_altimeter_jumpable_img_click = ''
        let normal_altitude_jumpable_img_click = ''
        let normal_fatBurning_jumpable_img_click = ''
        let Button_1 = ''


        //dynamic modify end
        const e = __$$hmAppManager$$__.currentApp;
        const o = e.current
          , {px: i} = (new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(e,o)),
        e.__globals__)
          , n = Logger.getLogger("watchface6");
        o.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'A100_265.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			let dned=["week_0.png","week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png"]
			if(lang=='ru-RU'){
				dned=["weekru_0.png","weekru_1.png","weekru_2.png","weekru_3.png","weekru_4.png","weekru_5.png","weekru_6.png"]
			}
            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 201,
              y: 332,
              week_en: dned,
              week_tc: ["week_0.png","week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png"],
              week_sc: ["week_0.png","week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			let dmonth=["m_0.png","m_1.png","m_2.png","m_3.png","m_4.png","m_5.png","m_6.png","m_7.png","m_8.png","m_9.png","m_10.png","m_11.png"]
			if(lang=='ru-RU'){
				dmonth=["mru_0.png","mru_1.png","mru_2.png","mru_3.png","mru_4.png","mru_5.png","mru_6.png","mru_7.png","mru_8.png","mru_9.png","mru_10.png","mru_11.png"]
			}
            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 185,
              month_startY: 376,
              month_sc_array: ["m_0.png","m_1.png","m_2.png","m_3.png","m_4.png","m_5.png","m_6.png","m_7.png","m_8.png","m_9.png","m_10.png","m_11.png"],
              month_tc_array: ["m_0.png","m_1.png","m_2.png","m_3.png","m_4.png","m_5.png","m_6.png","m_7.png","m_8.png","m_9.png","m_10.png","m_11.png"],
              month_en_array: dmonth,
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 217,
              day_startY: 278,
              day_sc_array: ["A100_321.png","A100_322.png","A100_323.png","A100_324.png","A100_325.png","A100_326.png","A100_327.png","A100_328.png","A100_329.png","A100_330.png"],
              day_tc_array: ["A100_321.png","A100_322.png","A100_323.png","A100_324.png","A100_325.png","A100_326.png","A100_327.png","A100_328.png","A100_329.png","A100_330.png"],
              day_en_array: ["A100_321.png","A100_322.png","A100_323.png","A100_324.png","A100_325.png","A100_326.png","A100_327.png","A100_328.png","A100_329.png","A100_330.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_temperature_current_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 384,
              // y: 381,
              // font_array: ["A100_300.png","A100_301.png","A100_302.png","A100_303.png","A100_304.png","A100_305.png","A100_306.png","A100_307.png","A100_308.png","A100_309.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: -43,
              // unit_en: 'A100_299.png',
              // negative_image: 'minus.png',
              // dot_image: 'minus.png',
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.WEATHER_CURRENT,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_temperature_current_TextRotate_ASCIIARRAY[0] = 'A100_300.png';  // set of images with numbers
            normal_temperature_current_TextRotate_ASCIIARRAY[1] = 'A100_301.png';  // set of images with numbers
            normal_temperature_current_TextRotate_ASCIIARRAY[2] = 'A100_302.png';  // set of images with numbers
            normal_temperature_current_TextRotate_ASCIIARRAY[3] = 'A100_303.png';  // set of images with numbers
            normal_temperature_current_TextRotate_ASCIIARRAY[4] = 'A100_304.png';  // set of images with numbers
            normal_temperature_current_TextRotate_ASCIIARRAY[5] = 'A100_305.png';  // set of images with numbers
            normal_temperature_current_TextRotate_ASCIIARRAY[6] = 'A100_306.png';  // set of images with numbers
            normal_temperature_current_TextRotate_ASCIIARRAY[7] = 'A100_307.png';  // set of images with numbers
            normal_temperature_current_TextRotate_ASCIIARRAY[8] = 'A100_308.png';  // set of images with numbers
            normal_temperature_current_TextRotate_ASCIIARRAY[9] = 'A100_309.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 4; i++) {
              normal_temperature_current_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 384,
                center_y: 381,
                pos_x: 384,
                pos_y: 381,
                angle: -43,
                src: 'A100_300.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_temperature_current_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_temperature_current_TextRotate_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              center_x: 384,
              center_y: 381,
              pos_x: 384,
              pos_y: 381,
              angle: -43,
              src: 'A100_299.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_temperature_current_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block
            const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

            normal_altitude_target_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 442,
              y: 203,
              font_array: ["A100_300.png","A100_301.png","A100_302.png","A100_303.png","A100_304.png","A100_305.png","A100_306.png","A100_307.png","A100_308.png","A100_309.png"],
              padding: false,
              h_space: 0,
              angle: 90,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.ALTITUDE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 364,
              y: 47,
              font_array: ["A100_300.png","A100_301.png","A100_302.png","A100_303.png","A100_304.png","A100_305.png","A100_306.png","A100_307.png","A100_308.png","A100_309.png"],
              padding: false,
              h_space: 0,
              angle: 45,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_fat_burning_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: -2,
              // y: 253,
              // font_array: ["fat_0.png","fat_1.png","fat_2.png","fat_3.png","fat_4.png","fat_5.png","fat_6.png","fat_7.png","fat_8.png","fat_9.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: -90,
              // unit_en: 'min.png',
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.FAT_BURNING,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_fat_burning_TextRotate_ASCIIARRAY[0] = 'fat_0.png';  // set of images with numbers
            normal_fat_burning_TextRotate_ASCIIARRAY[1] = 'fat_1.png';  // set of images with numbers
            normal_fat_burning_TextRotate_ASCIIARRAY[2] = 'fat_2.png';  // set of images with numbers
            normal_fat_burning_TextRotate_ASCIIARRAY[3] = 'fat_3.png';  // set of images with numbers
            normal_fat_burning_TextRotate_ASCIIARRAY[4] = 'fat_4.png';  // set of images with numbers
            normal_fat_burning_TextRotate_ASCIIARRAY[5] = 'fat_5.png';  // set of images with numbers
            normal_fat_burning_TextRotate_ASCIIARRAY[6] = 'fat_6.png';  // set of images with numbers
            normal_fat_burning_TextRotate_ASCIIARRAY[7] = 'fat_7.png';  // set of images with numbers
            normal_fat_burning_TextRotate_ASCIIARRAY[8] = 'fat_8.png';  // set of images with numbers
            normal_fat_burning_TextRotate_ASCIIARRAY[9] = 'fat_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 3; i++) {
              normal_fat_burning_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: -2,
                center_y: 253,
                pos_x: -2,
                pos_y: 253,
                angle: -90,
                src: 'fat_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_fat_burning_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_fat_burning_TextRotate_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              center_x: -2,
              center_y: 253,
              pos_x: -2,
              pos_y: 253,
              angle: -90,
              src: 'min.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_fat_burning_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block
            
            const fat_burning = hmSensor.createSensor(hmSensor.id.FAT_BURRING);
            fat_burning.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            normal_fat_burning_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 0,
              y: 0,
              image_array: ["cal_0.png","cal_1.png","cal_2.png","cal_3.png","cal_4.png","cal_5.png","cal_6.png","cal_7.png","cal_8.png","cal_9.png"],
              image_length: 10,
              type: hmUI.data_type.FAT_BURNING,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_stand_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 64,
              // y: 71,
              // font_array: ["stnd_1.png","stnd_2.png","stnd_3.png","stnd_4.png","stnd_5.png","stnd_6.png","stnd_7.png","stnd_8.png","stnd_9.png","stnd_10.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: -45,
              // unit_en: 'h.png',
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.STAND,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_stand_TextRotate_ASCIIARRAY[0] = 'stnd_1.png';  // set of images with numbers
            normal_stand_TextRotate_ASCIIARRAY[1] = 'stnd_2.png';  // set of images with numbers
            normal_stand_TextRotate_ASCIIARRAY[2] = 'stnd_3.png';  // set of images with numbers
            normal_stand_TextRotate_ASCIIARRAY[3] = 'stnd_4.png';  // set of images with numbers
            normal_stand_TextRotate_ASCIIARRAY[4] = 'stnd_5.png';  // set of images with numbers
            normal_stand_TextRotate_ASCIIARRAY[5] = 'stnd_6.png';  // set of images with numbers
            normal_stand_TextRotate_ASCIIARRAY[6] = 'stnd_7.png';  // set of images with numbers
            normal_stand_TextRotate_ASCIIARRAY[7] = 'stnd_8.png';  // set of images with numbers
            normal_stand_TextRotate_ASCIIARRAY[8] = 'stnd_9.png';  // set of images with numbers
            normal_stand_TextRotate_ASCIIARRAY[9] = 'stnd_10.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              normal_stand_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 64,
                center_y: 71,
                pos_x: 64,
                pos_y: 71,
                angle: -45,
                src: 'stnd_1.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_stand_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_stand_TextRotate_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              center_x: 64,
              center_y: 71,
              pos_x: 64,
              pos_y: 71,
              angle: -45,
              src: 'h.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_stand_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block
            
            const stand = hmSensor.createSensor(hmSensor.id.STAND);
            stand.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            normal_stand_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 0,
              y: 0,
              image_array: ["stand_0.png","stand_1.png","stand_2.png","stand_3.png","stand_4.png","stand_5.png","stand_6.png","stand_7.png","stand_8.png","stand_9.png"],
              image_length: 10,
              type: hmUI.data_type.STAND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 199,
              y: 441,
              font_array: ["A100_300.png","A100_301.png","A100_302.png","A100_303.png","A100_304.png","A100_305.png","A100_306.png","A100_307.png","A100_308.png","A100_309.png"],
              padding: false,
              h_space: 0,
              dot_image: 'dot.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 199,
              y: -3,
              font_array: ["A100_300.png","A100_301.png","A100_302.png","A100_303.png","A100_304.png","A100_305.png","A100_306.png","A100_307.png","A100_308.png","A100_309.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_calorie_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 97,
              // y: 382,
              // font_array: ["kcal_0.png","kcal_1.png","kcal_2.png","kcal_3.png","kcal_4.png","kcal_5.png","kcal_6.png","kcal_7.png","kcal_8.png","kcal_9.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: 45,
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_calorie_TextRotate_ASCIIARRAY[0] = 'kcal_0.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[1] = 'kcal_1.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[2] = 'kcal_2.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[3] = 'kcal_3.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[4] = 'kcal_4.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[5] = 'kcal_5.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[6] = 'kcal_6.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[7] = 'kcal_7.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[8] = 'kcal_8.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[9] = 'kcal_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 4; i++) {
              normal_calorie_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 97,
                center_y: 382,
                pos_x: 97,
                pos_y: 382,
                angle: 45,
                src: 'kcal_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_calorie_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            
            const calorie = hmSensor.createSensor(hmSensor.id.CALORIE);
            calorie.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            normal_calorie_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 0,
              y: 0,
              image_array: ["step_0.png","step_1.png","step_2.png","step_3.png","step_4.png","step_5.png","step_6.png","step_7.png","step_8.png","step_9.png"],
              image_length: 10,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			let dpai='names.png'
			if(lang=='ru-RU'){
				dpai='names_1.png'
			}
            normal_pai_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 29,
              y: 29,
              src: dpai,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'A100_270.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 19,
              hour_posY: 142,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'A100_271.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 19,
              minute_posY: 227,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'A100_274.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 19,
              second_posY: 227,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'A100_266.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 201,
              y: 332,
              week_en: ["week_0.png","week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png"],
              week_tc: ["week_0.png","week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png"],
              week_sc: ["week_0.png","week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 185,
              month_startY: 376,
              month_sc_array: ["m_0.png","m_1.png","m_2.png","m_3.png","m_4.png","m_5.png","m_6.png","m_7.png","m_8.png","m_9.png","m_10.png","m_11.png"],
              month_tc_array: ["m_0.png","m_1.png","m_2.png","m_3.png","m_4.png","m_5.png","m_6.png","m_7.png","m_8.png","m_9.png","m_10.png","m_11.png"],
              month_en_array: ["m_0.png","m_1.png","m_2.png","m_3.png","m_4.png","m_5.png","m_6.png","m_7.png","m_8.png","m_9.png","m_10.png","m_11.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 217,
              day_startY: 278,
              day_sc_array: ["A100_321.png","A100_322.png","A100_323.png","A100_324.png","A100_325.png","A100_326.png","A100_327.png","A100_328.png","A100_329.png","A100_330.png"],
              day_tc_array: ["A100_321.png","A100_322.png","A100_323.png","A100_324.png","A100_325.png","A100_326.png","A100_327.png","A100_328.png","A100_329.png","A100_330.png"],
              day_en_array: ["A100_321.png","A100_322.png","A100_323.png","A100_324.png","A100_325.png","A100_326.png","A100_327.png","A100_328.png","A100_329.png","A100_330.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_fat_burning_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 0,
              y: 0,
              image_array: ["cal_0.png","cal_1.png","cal_2.png","cal_3.png","cal_4.png","cal_5.png","cal_6.png","cal_7.png","cal_8.png","cal_9.png"],
              image_length: 10,
              type: hmUI.data_type.FAT_BURNING,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_stand_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 0,
              y: 0,
              image_array: ["stand_0.png","stand_1.png","stand_2.png","stand_3.png","stand_4.png","stand_5.png","stand_6.png","stand_7.png","stand_8.png","stand_9.png"],
              image_length: 10,
              type: hmUI.data_type.STAND,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 0,
              y: 0,
              image_array: ["step_0.png","step_1.png","step_2.png","step_3.png","step_4.png","step_5.png","step_6.png","step_7.png","step_8.png","step_9.png"],
              image_length: 10,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'A100_163.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 30,
              hour_posY: 156,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'A100_164.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 30,
              minute_posY: 235,
              minute_cover_path: 'A100_014.png',
              minute_cover_x: 210,
              minute_cover_y: 210,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_pai_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'A100_066.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 206,
              y: 422,
              w: 72,
              h: 52,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_cal_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 62,
              y: 350,
              w: 62,
              h: 72,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 361,
              y: 350,
              w: 62,
              h: 72,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 72,
              y: 57,
              w: 62,
              h: 72,
              type: hmUI.data_type.STAND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 361,
              y: 62,
              w: 62,
              h: 72,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altitude_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 417,
              y: 206,
              w: 62,
              h: 72,
              type: hmUI.data_type.ALTITUDE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_fatBurning_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 0,
              y: 206,
              w: 62,
              h: 72,
              type: hmUI.data_type.FAT_BURNING,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 204,
              y: 299,
              w: 72,
              h: 88,
              text: '',
              color: 0xFFFF8C00,
              text_size: 26,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              longpress_func: (button_widget) => {
                hmApp.startApp({url: 'todoListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            let screenType = hmSetting.getScreenType();
            //start of ignored block
            function text_update() {
              console.log('text_update()');
              let weatherData = weatherSensor.getForecastWeather();
              let temperature_current_temp = -100;
              if (weatherSensor.current != undefined && weatherSensor.current != 'undefined') {
                temperature_current_temp = weatherSensor.current;
              }; // end currentWeather;

              console.log('update text rotate temperature_current_currentWeather');
              let temperatureCurrent = undefined;
              let normal_temperature_current_rotate_string = undefined;
              if (temperature_current_temp > -100) {
                temperatureCurrent = 0;
                normal_temperature_current_rotate_string = String(temperature_current_temp)
              };

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 4; i++) {  // hide all symbols
                  normal_temperature_current_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_temperature_current_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
                if (temperatureCurrent != null && temperatureCurrent != undefined && isFinite(temperatureCurrent) && normal_temperature_current_rotate_string.length > 0 && normal_temperature_current_rotate_string.length <= 4) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let normal_temperature_current_TextRotate_posOffset = normal_temperature_current_TextRotate_img_width * normal_temperature_current_rotate_string.length;
                  img_offset -= normal_temperature_current_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_temperature_current_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 4) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_temperature_current_TextRotate[index].setProperty(hmUI.prop.POS_X, 384 + img_offset);
                      normal_temperature_current_TextRotate[index].setProperty(hmUI.prop.SRC, normal_temperature_current_TextRotate_ASCIIARRAY[charCode]);
                      normal_temperature_current_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_temperature_current_TextRotate_img_width;
                      index++;
                    }  // end if digit
                    else { 
                      normal_temperature_current_TextRotate[index].setProperty(hmUI.prop.POS_X, 384 + img_offset);
                      normal_temperature_current_TextRotate[index].setProperty(hmUI.prop.SRC, 'minus.png');
                      normal_temperature_current_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_temperature_current_TextRotate_dot_width;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                  normal_temperature_current_TextRotate_unit.setProperty(hmUI.prop.POS_X, 384 + img_offset);
                  normal_temperature_current_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite

              };

              console.log('update text rotate fat_burning_FAT_BURRING');
              let valueFatBurning = fat_burning.current;
              let normal_fat_burning_rotate_string = parseInt(valueFatBurning).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  normal_fat_burning_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_fat_burning_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
                if (valueFatBurning != null && valueFatBurning != undefined && isFinite(valueFatBurning) && normal_fat_burning_rotate_string.length > 0 && normal_fat_burning_rotate_string.length <= 3) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let normal_fat_burning_TextRotate_posOffset = normal_fat_burning_TextRotate_img_width * normal_fat_burning_rotate_string.length;
                  img_offset -= normal_fat_burning_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_fat_burning_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_fat_burning_TextRotate[index].setProperty(hmUI.prop.POS_X, -2 + img_offset);
                      normal_fat_burning_TextRotate[index].setProperty(hmUI.prop.SRC, normal_fat_burning_TextRotate_ASCIIARRAY[charCode]);
                      normal_fat_burning_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_fat_burning_TextRotate_img_width;
                      index++;
                    };  // end if digit
                  };  // end char of string
                  normal_fat_burning_TextRotate_unit.setProperty(hmUI.prop.POS_X, -2 + img_offset);
                  normal_fat_burning_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite

              };

              console.log('update text rotate stand_STAND');
              let valueStand = stand.current;
              let normal_stand_rotate_string = parseInt(valueStand).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_stand_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_stand_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
                if (valueStand != null && valueStand != undefined && isFinite(valueStand) && normal_stand_rotate_string.length > 0 && normal_stand_rotate_string.length <= 2) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let normal_stand_TextRotate_posOffset = normal_stand_TextRotate_img_width * normal_stand_rotate_string.length;
                  img_offset -= normal_stand_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_stand_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_stand_TextRotate[index].setProperty(hmUI.prop.POS_X, 64 + img_offset);
                      normal_stand_TextRotate[index].setProperty(hmUI.prop.SRC, normal_stand_TextRotate_ASCIIARRAY[charCode]);
                      normal_stand_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_stand_TextRotate_img_width;
                      index++;
                    };  // end if digit
                  };  // end char of string
                  normal_stand_TextRotate_unit.setProperty(hmUI.prop.POS_X, 64 + img_offset);
                  normal_stand_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite

              };

              console.log('update text rotate calorie_CALORIE');
              let valueCalories = calorie.current;
              let normal_calorie_rotate_string = parseInt(valueCalories).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 4; i++) {  // hide all symbols
                  normal_calorie_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueCalories != null && valueCalories != undefined && isFinite(valueCalories) && normal_calorie_rotate_string.length > 0 && normal_calorie_rotate_string.length <= 4) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let normal_calorie_TextRotate_posOffset = normal_calorie_TextRotate_img_width * normal_calorie_rotate_string.length;
                  img_offset -= normal_calorie_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_calorie_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 4) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_calorie_TextRotate[index].setProperty(hmUI.prop.POS_X, 97 + img_offset);
                      normal_calorie_TextRotate[index].setProperty(hmUI.prop.SRC, normal_calorie_TextRotate_ASCIIARRAY[charCode]);
                      normal_calorie_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_calorie_TextRotate_img_width;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

            };

            //end of ignored block
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                text_update();
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
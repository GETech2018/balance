﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
		let normal_date_img_date_week_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_battery_circle_scale = ''
        let normal_battery_text_text_img = ''
        let normal_fat_burning_target_text_img = ''
        let normal_fat_burning_current_text_img = ''
        let normal_fat_burning_current_separator_img = ''
        let normal_stand_target_text_img = ''
        let normal_stand_current_text_img = ''
        let normal_stand_current_separator_img = ''
        let normal_floor_current_text_img = ''
        let normal_wind_text_separator_img = ''
        let normal_calorie_current_text_img = ''
        let normal_calorie_current_separator_img = ''
        let normal_distance_text_text_img = ''
        let normal_distance_text_separator_img = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg_img = ''
        let idle_date_img_date_month = ''
        let idle_date_img_date_day = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let normal_heart_jumpable_img_click = ''
		let idle_date_text_date_week = ''
		let time=false
		let normal_date_text_date_week = '';
		
		let weekday=["MONDAY", "TUESDAY", "WEDNESDAY", "THURSDAY", "FRIDAY", "SATURDAY", "SUNDAY"];
		
		let btn_zona1 = ''
        let zona1_num = 0
        let zona1_all = 2
		
		function click_zona1() {
		  zona1_num = (zona1_num + 1) % (zona1_all + 1);
          if (zona1_num == 0) {		
		    normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
            normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		    hmUI.showToast({
            });
          };
		  
		 if (zona1_num == 1) {
			normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		    hmUI.showToast({
            });
          };
		  
		  if (zona1_num == 2) {
			normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, true);
		    hmUI.showToast({
            });
          };
        }
		
		let btn_zona2 = ''
        let zona2_num = 0
        let zona2_all = 2
		
		function click_zona2() {
		  zona2_num = (zona2_num + 1) % (zona2_all + 1);
          if (zona2_num == 0) {		
		    normal_stand_target_text_img.setProperty(hmUI.prop.VISIBLE, true);
            normal_stand_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_stand_current_separator_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_fat_burning_target_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_fat_burning_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_fat_burning_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_floor_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_wind_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		    hmUI.showToast({
            });
          };
		  
		 if (zona2_num == 1) {
			normal_stand_target_text_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_stand_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_stand_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_fat_burning_target_text_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_fat_burning_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_fat_burning_current_separator_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_floor_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_wind_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		    hmUI.showToast({
            });
          };
		  
		  if (zona2_num == 2) {
			normal_stand_target_text_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_stand_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_stand_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_fat_burning_target_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_fat_burning_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_fat_burning_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_floor_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_wind_text_separator_img.setProperty(hmUI.prop.VISIBLE, true);
		    hmUI.showToast({
            });
          };
        }
		
		let btn_bezel = ''
        let bezel_num = 1
        let bezel_all = 7
     
        function click_Bezel() {
            if(bezel_num>=bezel_all) {bezel_num=1;}
            else { bezel_num=bezel_num+1;}
            hmUI.showToast({text: "<Bezel> " + parseInt(bezel_num) });
            normal_background_bg_img.setProperty(hmUI.prop.SRC, "bg_" + parseInt(bezel_num) + ".png");
        }


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
				
		function setLang(){
				const lang = DeviceRuntimeCore.HmUtils.getLanguage();
				if(lang=='en-US'){
					
					weekday=["MONDAY", "TUESDAY", "WEDNESDAY", "THURSDAY", "FRIDAY", "SATURDAY", "SUNDAY"];
				}
				if(lang=='uk-UA'){
					weekday=["ПОНЕДІЛОК", "ВІВТОРОК", "СЕРЕДА", "ЧЕТВЕР", "П'ЯТНИЦЯ", "СУБОТА", "НЕДІЛЯ"];										
				}
				if(lang=='ru-RU'){
					weekday=["ПОНЕДЕЛЬНИК","ВТОРНИК","СРЕДА","ЧЕТВЕРГ","ПЯТНИЦА","СУББОТА","ВОСКРЕСЕНЬЕ"];					
				}				
			}			
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 249,
              month_startY: 65,
              month_sc_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
              month_tc_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
              month_en_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 203,
              day_startY: 65,
              day_sc_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
              day_tc_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
              day_en_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
              day_zero: 1,
              day_space: 0,
              day_unit_sc: 'dot_1.png',
              day_unit_tc: 'dot_1.png',
              day_unit_en: 'dot_1.png',
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 233,
              y: 145,
              font_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 240,
              // center_y: 360,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 55,
              // line_width: 12,
              // line_cap: Flat,
              // color: 0xFF008000,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            let screenType = hmSetting.getScreenType();
            normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 240,
              center_y: 360,
              start_angle: 0,
              end_angle: 360,
              radius: 49,
              line_width: 12,
              corner_flag: 3,
              color: 0xFF008000,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 215,
              y: 347,
              font_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_fat_burning_target_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 366,
              y: 220,
              font_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.FAT_BURNING_TARGET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_fat_burning_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 320,
              y: 220,
              font_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
              padding: false,
              h_space: -2,
              unit_sc: 'dot_1.png',
              unit_tc: 'dot_1.png',
              unit_en: 'dot_1.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.FAT_BURNING,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_fat_burning_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 336,
              y: 253,
              src: 'fat.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_target_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 371,
              y: 220,
              font_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STAND_TARGET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 329,
              y: 220,
              font_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
              padding: true,
              h_space: 0,
              unit_sc: 'dot_1.png',
              unit_tc: 'dot_1.png',
              unit_en: 'dot_1.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STAND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 338,
              y: 253,
              src: 'stand.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_floor_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 340,
              y: 220,
              font_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.FLOOR,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 339,
              y: 253,
              src: 'floor.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 87,
              y: 220,
              font_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 96,
              y: 253,
              src: 'kcal.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 84,
              y: 220,
              font_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
              padding: false,
              h_space: 0,
              dot_image: 'dot.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 98,
              y: 253,
              src: 'dist.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 81,
              y: 220,
              font_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 97,
              y: 253,
              src: 'step.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
/*            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 140,
              y: 89,
              week_en: ["A100_036.png","A100_037.png","A100_038.png","A100_039.png","A100_040.png","A100_041.png","A100_042.png"],
              week_tc: ["A100_036.png","A100_037.png","A100_038.png","A100_039.png","A100_040.png","A100_041.png","A100_042.png"],
              week_sc: ["A100_036.png","A100_037.png","A100_038.png","A100_039.png","A100_040.png","A100_041.png","A100_042.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });*/
			
			normal_date_text_date_week = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 148,
              y: 100,
			  w:190,
			  h:20,
			  color: 0xffffff,
			  text_size: 24,
			  align_h: hmUI.align.CENTER_H,
			  align_v: hmUI.align.CENTER_V,
			  text_style: hmUI.text_style.NONE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			time = hmSensor.createSensor(hmSensor.id.TIME);
			
			time.addEventListener(time.event.DAYCHANGE, function() {
				setTextData();
			});
			
			function setTextData(){
				if(typeof normal_date_text_date_week !== 'string'){
					normal_date_text_date_week.setProperty(hmUI.prop.TEXT,weekday[time.week-1]);
				}
				if(typeof idle_date_text_date_week !== 'string'){
					idle_date_text_date_week.setProperty(hmUI.prop.TEXT,weekday[time.week-1]);
				}		
			}

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'stretch_index_hands_hr_dark_bg.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 27,
              hour_posY: 239,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'stretch_index_hands_min_dark_bg.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 27,
              minute_posY: 210,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'stretch_index_metal_hands_sec.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 27,
              second_posY: 239,
              second_cover_path: 'centr.png',
              second_cover_x: 185,
              second_cover_y: 185,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'aodbg.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

/*            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 140,
              y: 94,
              week_en: ["A100_036.png","A100_037.png","A100_038.png","A100_039.png","A100_040.png","A100_041.png","A100_042.png"],
              week_tc: ["A100_036.png","A100_037.png","A100_038.png","A100_039.png","A100_040.png","A100_041.png","A100_042.png"],
              week_sc: ["A100_036.png","A100_037.png","A100_038.png","A100_039.png","A100_040.png","A100_041.png","A100_042.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });*/
			
			idle_date_text_date_week = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 148,
              y: 100,
			  w:190,
			  h:20,
			  color: 0xffffff,
			  text_size: 24,
			  align_h: hmUI.align.CENTER_H,
			  align_v: hmUI.align.CENTER_V,
			  text_style: hmUI.text_style.NONE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 249,
              month_startY: 65,
              month_sc_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
              month_tc_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
              month_en_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 203,
              day_startY: 65,
              day_sc_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
              day_tc_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
              day_en_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
              day_zero: 1,
              day_space: 0,
              day_unit_sc: 'dot_1.png',
              day_unit_tc: 'dot_1.png',
              day_unit_en: 'dot_1.png',
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'stretch_index_hands_hr_dark_bg.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 27,
              hour_posY: 239,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'stretch_index_hands_min_dark_bg.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 27,
              minute_posY: 239,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');
			
			const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if (scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro() {
              vibrate.stop();
              if (timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            btn_bezel = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 190,
              y: 420,
              text: '',
              w: 100,
              h: 60,
              normal_src: 'Empty.png',
              press_src: 'Empty.png',
              click_func: () => {
                  click_Bezel();
				  vibro();
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btn_bezel.setProperty(hmUI.prop.VISIBLE, true);

            btn_zona2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 325,
              y: 205,
              text: '',
              w: 80,
              h: 80,
              normal_src: 'Empty.png',
              press_src: 'Empty.png',
              click_func: () => {
				click_zona2();
				vibro();
                click_Vibrate();
             },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btn_zona2.setProperty(hmUI.prop.VISIBLE, true);
			normal_fat_burning_target_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_fat_burning_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_fat_burning_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_floor_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_wind_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 202,
              y: 137,
              w: 80,
              h: 50,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            btn_zona1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 80,
              y: 205,
              text: '',
              w: 80,
              h: 80,
              normal_src: 'Empty.png',
              press_src: 'Empty.png',
              click_func: () => {
				click_zona1();
				vibro();
                click_Vibrate();
              },
			  longpress_func: () => {
             hmApp.startApp({ url: "activityAppScreen", native: true });
             },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btn_zona1.setProperty(hmUI.prop.VISIBLE, true);
			normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			
			let gr_panels = hmUI.createWidget(hmUI.widget.GROUP, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
            });
            gr_panels.setProperty(hmUI.prop.VISIBLE, false);

            let gr_panels_fill = gr_panels.createWidget(hmUI.widget.FILL_RECT, {
              x: 70,
              y: 70,
              w: 466 - 140,
              h: 466 - 140,
              color: '0xAA211d1e',
              radius: 20,
              alpha: 220,
              show_level:

                hmUI.show_level.ONLY_NORMAL,
            });

            
            gr_panels.createWidget(hmUI.widget.BUTTON, {
              x: 100,
              y: 100,
              w: 70,
              h: 70,
              text: '',
              normal_src: 'phone.png',
              press_src: 'phone.png',
              click_func: () => {
                vibro();
                hmApp.startApp({
                  appid: 1,
                  url: 'PhoneRecentCallScreen',
                  native: true
                });
             

              },
              longpress_func: () => {
               hmApp.startApp({ url: "PhoneContactsScreen", native: true });
              },

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            
            gr_panels.createWidget(hmUI.widget.BUTTON, {
              x: 200,
              y: 100,
              w: 70,
              h: 70,
              text: '',
              normal_src: 'music.png',
              press_src: 'music.png',
              click_func: () => {
                vibro();
                hmApp.startApp({
                  appid: 1,
                  url: 'LocalMusicScreen',
                  native: true
                });
                

              },
              longpress_func: () => {
               hmApp.startApp({ url: "PhoneMusicCtrlScreen", native: true });

              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            
            gr_panels.createWidget(hmUI.widget.BUTTON, {
              x: 300,
              y: 100,
              w: 70,
              h: 70,
              text: '',
              normal_src: 'voicememo.png',
              press_src: 'Empty.png',
              click_func: () => {
                vibro();
                hmApp.startApp({
                  appid: 1,
                  url: 'VoiceMemoScreen',
                  native: true
                });
                

              },

              longpress_func: () => {

              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            gr_panels.createWidget(hmUI.widget.BUTTON, {
              x: 100,
              y: 200,
              w: 70,
              h: 70,
              text: '',
              normal_src: 'stopwatch.png',
              press_src: 'Empty.png',
              click_func: () => {
                vibro();
                hmApp.startApp({
                  appid: 1,
                  url: 'StopWatchScreen',
                  native: true
                });
                

              },

              longpress_func: () => {

              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            gr_panels.createWidget(hmUI.widget.BUTTON, {
              x: 100,
              y: 300,
              w: 70,
              h: 70,
              text: '',
              normal_src: 'compass.png',
              press_src: 'Empty.png',
              click_func: () => {
                vibro();
                hmApp.startApp({
                  appid: 1,
                  url: 'CompassScreen',
                  native: true
                });
                

              },

              longpress_func: () => {

              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            gr_panels.createWidget(hmUI.widget.BUTTON, {
              x: 200,
              y: 200,
              w: 70,
              h: 70,
              text: '',
              normal_src: 'countdown.png',
              press_src: 'Empty.png',
              click_func: () => {
                vibro();
                hmApp.startApp({
                  appid: 1,
                  url: 'CountdownAppScreen',
                  native: true
                });
                

              },

              longpress_func: () => {

              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            gr_panels.createWidget(hmUI.widget.BUTTON, {
              x: 200,
              y: 300,
              w: 70,
              h: 70,
              text: '',
              normal_src: 'measurement.png',
              press_src: 'Empty.png',
              click_func: () => {
                vibro();
                hmApp.startApp({
                  appid: 1,
                  url: 'oneKeyAppScreen',
                  native: true
                });
                

              },

              longpress_func: () => {

              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            gr_panels.createWidget(hmUI.widget.BUTTON, {
              x: 300,
              y: 300,
              w: 70,
              h: 70,
              text: '',
              normal_src: 'setting.png',
              press_src: 'setting.png',
              click_func: () => {
                vibro();
                hmApp.startApp({
                  appid: 1,
                  url: 'Settings_homeScreen',
                  native: true
                });
                

              },

              longpress_func: () => {
               hmApp.startApp({ url: "Settings_batteryManagerScreen", native: true });
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            gr_panels.createWidget(hmUI.widget.BUTTON, {
              x: 300,
              y: 200,
              w: 70,
              h: 70,
              text: '',
              normal_src: 'sport.png',
              press_src: 'sport.png',
              click_func: () => {
                vibro();
                hmApp.startApp({
                  appid: 1,
                  url: 'SportListScreen',
                  native: true
                });
                

              },

              longpress_func: () => {
               hmApp.startApp({ url: "SportRecordListScreen", native: true });
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            
            let panel_visible = false;
            
            gr_panels.createWidget(hmUI.widget.BUTTON, {
              x: 365,
              y: 55,
              w: 50,
              h: 50,
              radius: 25,
              text: 'X',
              normal_color: 0x992255,
              press_color: 0xfeb4a8,
              click_func: () => {

                vibro(24);
                panel_visible = !panel_visible;
                gr_panels.setProperty(hmUI.prop.VISIBLE, panel_visible);
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

           
            hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 380,
              y: 320,
              w: 85,
              h: 50,
              text: '',
              normal_src: 'Empty.png',
              press_src: 'Empty.png',
              click_func: () => {
                vibro();
                panel_visible = !panel_visible;
                gr_panels.setProperty(hmUI.prop.VISIBLE, panel_visible);
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 203,
              y: 75, 
              text: '',
              w: 75, 
              h: 50, 
              normal_src: 'Empty.png',
              press_src: 'Empty.png',
               click_func: () => {
              hmApp.startApp({ url: 'ScheduleCalScreen', native: true });
              },
               longpress_func: () => {
              hmApp.startApp({ url: 'todoListScreen', native: true });
              },
                show_level: hmUI.show_level.ONLY_NORMAL,
            });

            function scale_call() {
              console.log('scale_call()');

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_cs_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_battery * 100);
                  if (normal_battery_circle_scale) {
                    normal_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 240,
                      center_y: 360,
                      start_angle: 0,
                      end_angle: 360,
                      radius: 49,
                      line_width: 12,
                      corner_flag: 3,
                      color: 0xFF008000,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                setLang();
				setTextData();
				scale_call();
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
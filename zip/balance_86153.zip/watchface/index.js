﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_clock_img = ''
        let normal_temperature_icon_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_font = ''
        let normal_battery_icon_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_heart_rate_text_text_img = ''
        let normal_step_icon_img = ''
        let normal_step_current_text_img = ''
        let normal_date_img_date_month = ''
        let normal_year_icon_img = ''
        let normal_date_img_date_year = ''
        let normal_day_text_font = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_image_img = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg_img = ''
        let idle_system_clock_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_temperature_current_text_font = ''
        let idle_battery_icon_img = ''
        let idle_battery_text_text_img = ''
        let idle_battery_image_progress_img_level = ''
        let idle_heart_rate_text_text_img = ''
        let idle_step_icon_img = ''
        let idle_step_current_text_img = ''
        let idle_date_img_date_month = ''
        let idle_year_icon_img = ''
        let idle_date_img_date_year = ''
        let idle_day_text_font = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_week_img = ''
        let idle_image_img = ''
        let idle_digital_clock_img_time = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let Button_7 = ''
        let Button_8 = ''
        let Button_9 = ''
        let Button_10 = ''
        let Button_11 = ''
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            // FontName: Roboto-Medium.ttf; FontSize: 25
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 328,
              h: 36,
              text_size: 25,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Roboto-Medium.ttf',
              color: 0xFF008080,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: 3D-DBX0.ttf; FontSize: 43
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 460,
              h: 58,
              text_size: 43,
              char_space: -2,
              line_space: 0,
              font: 'fonts/3D-DBX0.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'image1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 103,
              y: 125,
              src: '130.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'wind.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 214,
              y: 118,
              image_array: ["wea_00.png","wea_01.png","wea_02.png","wea_03.png","wea_04.png","wea_05.png","wea_06.png","wea_07.png","wea_08.png","wea_09.png","wea_10.png","wea_11.png","wea_12.png","wea_13.png","wea_14.png","wea_15.png","wea_16.png","wea_17.png","wea_18.png","wea_19.png","wea_20.png","wea_21.png","wea_22.png","wea_23.png","wea_24.png","wea_25.png","wea_26.png","wea_27.png","wea_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 248,
              y: 105,
              w: 150,
              h: 60,
              text_size: 25,
              char_space: 0,
              font: 'fonts/Roboto-Medium.ttf',
              color: 0xFF008080,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              unit_type: 1,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'digital9_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 310,
              y: 309,
              font_array: ["digital2_0.png","digital2_1.png","digital2_2.png","digital2_3.png","digital2_4.png","digital2_5.png","digital2_6.png","digital2_7.png","digital2_8.png","digital2_9.png"],
              padding: true,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 0,
              y: 0,
              image_array: ["digital9_0.png","digital9_1.png","digital9_2.png","digital9_3.png","digital9_4.png","digital9_5.png","digital9_6.png","digital9_7.png","digital9_8.png","digital9_9.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 333,
              y: 251,
              font_array: ["digital2_0.png","digital2_1.png","digital2_2.png","digital2_3.png","digital2_4.png","digital2_5.png","digital2_6.png","digital2_7.png","digital2_8.png","digital2_9.png"],
              padding: true,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 89,
              y: 280,
              src: 'image2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 166,
              y: 317,
              font_array: ["digital2_0.png","digital2_1.png","digital2_2.png","digital2_3.png","digital2_4.png","digital2_5.png","digital2_6.png","digital2_7.png","digital2_8.png","digital2_9.png"],
              padding: true,
              h_space: 5,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 216,
              month_startY: 74,
              month_sc_array: ["digital5_0.png","digital5_1.png","digital5_2.png","digital5_3.png","digital5_4.png","digital5_5.png","digital5_6.png","digital5_7.png","digital5_8.png","digital5_9.png"],
              month_tc_array: ["digital5_0.png","digital5_1.png","digital5_2.png","digital5_3.png","digital5_4.png","digital5_5.png","digital5_6.png","digital5_7.png","digital5_8.png","digital5_9.png"],
              month_en_array: ["digital5_0.png","digital5_1.png","digital5_2.png","digital5_3.png","digital5_4.png","digital5_5.png","digital5_6.png","digital5_7.png","digital5_8.png","digital5_9.png"],
              month_zero: 1,
              month_space: 0,
              month_unit_sc: 'digital5_10.png',
              month_unit_tc: 'digital5_10.png',
              month_unit_en: 'digital5_10.png',
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_year_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'digital1_8.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 250,
              year_startY: 74,
              year_sc_array: ["digital5_0.png","digital5_1.png","digital5_2.png","digital5_3.png","digital5_4.png","digital5_5.png","digital5_6.png","digital5_7.png","digital5_8.png","digital5_9.png"],
              year_tc_array: ["digital5_0.png","digital5_1.png","digital5_2.png","digital5_3.png","digital5_4.png","digital5_5.png","digital5_6.png","digital5_7.png","digital5_8.png","digital5_9.png"],
              year_en_array: ["digital5_0.png","digital5_1.png","digital5_2.png","digital5_3.png","digital5_4.png","digital5_5.png","digital5_6.png","digital5_7.png","digital5_8.png","digital5_9.png"],
              year_zero: 1,
              year_space: 0,
              year_align: hmUI.align.CENTER_H,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function() {
              time_update(true);
            });

            normal_day_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 103,
              y: 273,
              w: 150,
              h: 66,
              text_size: 43,
              char_space: -2,
              font: 'fonts/3D-DBX0.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 181,
              day_startY: 74,
              day_sc_array: ["digital5_0.png","digital5_1.png","digital5_2.png","digital5_3.png","digital5_4.png","digital5_5.png","digital5_6.png","digital5_7.png","digital5_8.png","digital5_9.png"],
              day_tc_array: ["digital5_0.png","digital5_1.png","digital5_2.png","digital5_3.png","digital5_4.png","digital5_5.png","digital5_6.png","digital5_7.png","digital5_8.png","digital5_9.png"],
              day_en_array: ["digital5_0.png","digital5_1.png","digital5_2.png","digital5_3.png","digital5_4.png","digital5_5.png","digital5_6.png","digital5_7.png","digital5_8.png","digital5_9.png"],
              day_zero: 1,
              day_space: 0,
              day_unit_sc: 'digital5_10.png',
              day_unit_tc: 'digital5_10.png',
              day_unit_en: 'digital5_10.png',
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 217,
              y: 95,
              week_en: ["digital10_1.png","digital10_2.png","digital10_3.png","digital10_4.png","digital10_5.png","digital10_6.png","digital10_7.png"],
              week_tc: ["digital10_1.png","digital10_2.png","digital10_3.png","digital10_4.png","digital10_5.png","digital10_6.png","digital10_7.png"],
              week_sc: ["digital10_1.png","digital10_2.png","digital10_3.png","digital10_4.png","digital10_5.png","digital10_6.png","digital10_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: -4,
              y: -5,
              src: 'image3.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 94,
              hour_startY: 174,
              hour_array: ["digital6_0.png","digital6_1.png","digital6_2.png","digital6_3.png","digital6_4.png","digital6_5.png","digital6_6.png","digital6_7.png","digital6_8.png","digital6_9.png"],
              hour_zero: 1,
              hour_space: 4,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 209,
              minute_startY: 167,
              minute_array: ["digital7_0.png","digital7_1.png","digital7_2.png","digital7_3.png","digital7_4.png","digital7_5.png","digital7_6.png","digital7_7.png","digital7_8.png","digital7_9.png"],
              minute_zero: 1,
              minute_space: 4,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 331,
              second_startY: 196,
              second_array: ["digital8_0.png","digital8_1.png","digital8_2.png","digital8_3.png","digital8_4.png","digital8_5.png","digital8_6.png","digital8_7.png","digital8_8.png","digital8_9.png"],
              second_zero: 1,
              second_space: 4,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'image1.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 103,
              y: 125,
              src: '130.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 214,
              y: 118,
              image_array: ["wea_00.png","wea_01.png","wea_02.png","wea_03.png","wea_04.png","wea_05.png","wea_06.png","wea_07.png","wea_08.png","wea_09.png","wea_10.png","wea_11.png","wea_12.png","wea_13.png","wea_14.png","wea_15.png","wea_16.png","wea_17.png","wea_18.png","wea_19.png","wea_20.png","wea_21.png","wea_22.png","wea_23.png","wea_24.png","wea_25.png","wea_26.png","wea_27.png","wea_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 248,
              y: 105,
              w: 150,
              h: 60,
              text_size: 25,
              char_space: 0,
              font: 'fonts/Roboto-Medium.ttf',
              color: 0xFF008080,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              unit_type: 1,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'digital9_1.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 310,
              y: 309,
              font_array: ["digital2_0.png","digital2_1.png","digital2_2.png","digital2_3.png","digital2_4.png","digital2_5.png","digital2_6.png","digital2_7.png","digital2_8.png","digital2_9.png"],
              padding: true,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 0,
              y: 0,
              image_array: ["digital9_0.png","digital9_1.png","digital9_2.png","digital9_3.png","digital9_4.png","digital9_5.png","digital9_6.png","digital9_7.png","digital9_8.png","digital9_9.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 333,
              y: 251,
              font_array: ["digital2_0.png","digital2_1.png","digital2_2.png","digital2_3.png","digital2_4.png","digital2_5.png","digital2_6.png","digital2_7.png","digital2_8.png","digital2_9.png"],
              padding: true,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 89,
              y: 280,
              src: 'image2.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 166,
              y: 317,
              font_array: ["digital2_0.png","digital2_1.png","digital2_2.png","digital2_3.png","digital2_4.png","digital2_5.png","digital2_6.png","digital2_7.png","digital2_8.png","digital2_9.png"],
              padding: true,
              h_space: 5,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 216,
              month_startY: 74,
              month_sc_array: ["digital5_0.png","digital5_1.png","digital5_2.png","digital5_3.png","digital5_4.png","digital5_5.png","digital5_6.png","digital5_7.png","digital5_8.png","digital5_9.png"],
              month_tc_array: ["digital5_0.png","digital5_1.png","digital5_2.png","digital5_3.png","digital5_4.png","digital5_5.png","digital5_6.png","digital5_7.png","digital5_8.png","digital5_9.png"],
              month_en_array: ["digital5_0.png","digital5_1.png","digital5_2.png","digital5_3.png","digital5_4.png","digital5_5.png","digital5_6.png","digital5_7.png","digital5_8.png","digital5_9.png"],
              month_zero: 1,
              month_space: 0,
              month_unit_sc: 'digital5_10.png',
              month_unit_tc: 'digital5_10.png',
              month_unit_en: 'digital5_10.png',
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_year_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'digital1_8.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 250,
              year_startY: 74,
              year_sc_array: ["digital5_0.png","digital5_1.png","digital5_2.png","digital5_3.png","digital5_4.png","digital5_5.png","digital5_6.png","digital5_7.png","digital5_8.png","digital5_9.png"],
              year_tc_array: ["digital5_0.png","digital5_1.png","digital5_2.png","digital5_3.png","digital5_4.png","digital5_5.png","digital5_6.png","digital5_7.png","digital5_8.png","digital5_9.png"],
              year_en_array: ["digital5_0.png","digital5_1.png","digital5_2.png","digital5_3.png","digital5_4.png","digital5_5.png","digital5_6.png","digital5_7.png","digital5_8.png","digital5_9.png"],
              year_zero: 1,
              year_space: 0,
              year_align: hmUI.align.CENTER_H,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_day_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 103,
              y: 273,
              w: 150,
              h: 66,
              text_size: 43,
              char_space: -2,
              font: 'fonts/3D-DBX0.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              // padding: true,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 181,
              day_startY: 74,
              day_sc_array: ["digital5_0.png","digital5_1.png","digital5_2.png","digital5_3.png","digital5_4.png","digital5_5.png","digital5_6.png","digital5_7.png","digital5_8.png","digital5_9.png"],
              day_tc_array: ["digital5_0.png","digital5_1.png","digital5_2.png","digital5_3.png","digital5_4.png","digital5_5.png","digital5_6.png","digital5_7.png","digital5_8.png","digital5_9.png"],
              day_en_array: ["digital5_0.png","digital5_1.png","digital5_2.png","digital5_3.png","digital5_4.png","digital5_5.png","digital5_6.png","digital5_7.png","digital5_8.png","digital5_9.png"],
              day_zero: 1,
              day_space: 0,
              day_unit_sc: 'digital5_10.png',
              day_unit_tc: 'digital5_10.png',
              day_unit_en: 'digital5_10.png',
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 217,
              y: 95,
              week_en: ["digital10_1.png","digital10_2.png","digital10_3.png","digital10_4.png","digital10_5.png","digital10_6.png","digital10_7.png"],
              week_tc: ["digital10_1.png","digital10_2.png","digital10_3.png","digital10_4.png","digital10_5.png","digital10_6.png","digital10_7.png"],
              week_sc: ["digital10_1.png","digital10_2.png","digital10_3.png","digital10_4.png","digital10_5.png","digital10_6.png","digital10_7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: -4,
              y: -5,
              src: 'image3.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 94,
              hour_startY: 174,
              hour_array: ["digital6_0.png","digital6_1.png","digital6_2.png","digital6_3.png","digital6_4.png","digital6_5.png","digital6_6.png","digital6_7.png","digital6_8.png","digital6_9.png"],
              hour_zero: 1,
              hour_space: 4,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 209,
              minute_startY: 167,
              minute_array: ["digital7_0.png","digital7_1.png","digital7_2.png","digital7_3.png","digital7_4.png","digital7_5.png","digital7_6.png","digital7_7.png","digital7_8.png","digital7_9.png"],
              minute_zero: 1,
              minute_space: 4,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 331,
              second_startY: 196,
              second_array: ["digital8_0.png","digital8_1.png","digital8_2.png","digital8_3.png","digital8_4.png","digital8_5.png","digital8_6.png","digital8_7.png","digital8_8.png","digital8_9.png"],
              second_zero: 1,
              second_space: 4,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 0,
              // disconneсnt_toast_text: RUSH OFF,
              // conneсnt_vibrate_type: 0,
              // conneсnt_toast_text: RUSH ON,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              console.log('checkConnection()');
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  hmUI.showToast({text: "RUSH OFF"});
                  vibro(0);
                }
                if(status) {
                  hmUI.showToast({text: "RUSH ON"});
                  vibro(0);
                }
              });
            }

            // end vibration when connecting or disconnecting
            //#region vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              if (scene != 1) timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            //#endregion

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 188,
              y: 4,
              w: 100,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'O_Empty.png',
              normal_src: 'O_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PowerSaveHintScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 188,
              y: 63,
              w: 100,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'O_Empty.png',
              normal_src: 'O_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 188,
              y: 122,
              w: 100,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'O_Empty.png',
              normal_src: 'O_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'WeatherScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 50,
              y: 122,
              w: 100,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'O_Empty.png',
              normal_src: 'O_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'AlarmInfoScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 306,
              y: 104,
              w: 100,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'O_Empty.png',
              normal_src: 'O_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'TideScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 306,
              y: 192,
              w: 100,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'O_Empty.png',
              normal_src: 'O_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'AppListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_7 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 306,
              y: 245,
              w: 100,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'O_Empty.png',
              normal_src: 'O_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'heart_app_Screen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_8 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 306,
              y: 305,
              w: 100,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'O_Empty.png',
              normal_src: 'O_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'Settings_batteryManagerScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_9 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 167,
              y: 305,
              w: 100,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'O_Empty.png',
              normal_src: 'O_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'activityAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_10 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 77,
              y: 275,
              w: 60,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'O_Empty.png',
              normal_src: 'O_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'spo_HomeScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_11 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 210,
              y: 211,
              w: 60,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'O_Empty.png',
              normal_src: 'O_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'SportListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            let screenType = hmSetting.getScreenType();
            //#region time_update
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              console.log('day font');
              if (updateHour) {
                let normal_dayStr = timeSensor.day.toString();
                normal_dayStr = normal_dayStr.padStart(2, '0');
                normal_day_text_font.setProperty(hmUI.prop.TEXT, normal_dayStr );
              };

              console.log('day font');
              if (updateHour) {
                let idle_dayStr = timeSensor.day.toString();
                idle_dayStr = idle_dayStr.padStart(2, '0');
                idle_day_text_font.setProperty(hmUI.prop.TEXT, idle_dayStr );
              };

            };

            //#endregion
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                time_update(true, true);
                checkConnection();
                stopVibro();

              }),
              pause_call: (function () {
                console.log('pause_call()');
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
try {
    ((() => {
        const {beforeModuleCreate = () => {
            }, afterModuleCreate = () => {
            }} = DeviceRuntimeCore.LifeCycle;
        beforeModuleCreate();
        const {beforePageCreate = () => {
            }, afterPageCreate = () => {
            }} = DeviceRuntimeCore.LifeCycle;
        beforePageCreate();
        const __$$G$$__ = __$$hmAppManager$$__.currentApp.current.__globals__.__$$G$$__;
        !function (context) {
            with (context) {
                const __$$RQR$$__ = __$$R$$__;
                const ui = __$$RQR$$__('@zos/ui');
                const app = __$$RQR$$__('@zos/app');
                const sensor = __$$RQR$$__('@zos/sensor');
                const storage = __$$RQR$$__('@zos/storage');
                const router = __$$RQR$$__('@zos/router');
                const settings = __$$RQR$$__('@zos/settings');
                const _interopDefaultCompat = e => e && typeof e === 'object' && 'default' in e ? e : { default: e };
                const ui__default = _interopDefaultCompat(ui);
                const R = {
                    'glyphs': {
                        'metric': {
                            '0': {
                                'src': 'metric/48.png',
                                'w': 29,
                                'h': 46
                            },
                            '1': {
                                'src': 'metric/49.png',
                                'w': 29,
                                'h': 46
                            },
                            '2': {
                                'src': 'metric/50.png',
                                'w': 29,
                                'h': 46
                            },
                            '3': {
                                'src': 'metric/51.png',
                                'w': 29,
                                'h': 46
                            },
                            '4': {
                                'src': 'metric/52.png',
                                'w': 29,
                                'h': 46
                            },
                            '5': {
                                'src': 'metric/53.png',
                                'w': 29,
                                'h': 46
                            },
                            '6': {
                                'src': 'metric/54.png',
                                'w': 29,
                                'h': 46
                            },
                            '7': {
                                'src': 'metric/55.png',
                                'w': 29,
                                'h': 46
                            },
                            '8': {
                                'src': 'metric/56.png',
                                'w': 29,
                                'h': 46
                            },
                            '9': {
                                'src': 'metric/57.png',
                                'w': 29,
                                'h': 46
                            },
                            '.': {
                                'src': 'metric/46.png',
                                'w': 9,
                                'h': 46
                            },
                            '-': {
                                'src': 'metric/45.png',
                                'w': 17,
                                'h': 46
                            }
                        },
                        'date': {
                            '0': {
                                'src': 'date/48.png',
                                'w': 21,
                                'h': 35
                            },
                            '1': {
                                'src': 'date/49.png',
                                'w': 21,
                                'h': 35
                            },
                            '2': {
                                'src': 'date/50.png',
                                'w': 21,
                                'h': 35
                            },
                            '3': {
                                'src': 'date/51.png',
                                'w': 21,
                                'h': 35
                            },
                            '4': {
                                'src': 'date/52.png',
                                'w': 21,
                                'h': 35
                            },
                            '5': {
                                'src': 'date/53.png',
                                'w': 21,
                                'h': 35
                            },
                            '6': {
                                'src': 'date/54.png',
                                'w': 21,
                                'h': 35
                            },
                            '7': {
                                'src': 'date/55.png',
                                'w': 21,
                                'h': 35
                            },
                            '8': {
                                'src': 'date/56.png',
                                'w': 21,
                                'h': 35
                            },
                            '9': {
                                'src': 'date/57.png',
                                'w': 21,
                                'h': 35
                            },
                            'A': {
                                'src': 'date/65.png',
                                'w': 28,
                                'h': 35
                            },
                            'B': {
                                'src': 'date/66.png',
                                'w': 28,
                                'h': 35
                            },
                            'C': {
                                'src': 'date/67.png',
                                'w': 28,
                                'h': 35
                            },
                            'D': {
                                'src': 'date/68.png',
                                'w': 28,
                                'h': 35
                            },
                            'E': {
                                'src': 'date/69.png',
                                'w': 26,
                                'h': 35
                            },
                            'F': {
                                'src': 'date/70.png',
                                'w': 23,
                                'h': 35
                            },
                            'G': {
                                'src': 'date/71.png',
                                'w': 30,
                                'h': 35
                            },
                            'H': {
                                'src': 'date/72.png',
                                'w': 28,
                                'h': 35
                            },
                            'I': {
                                'src': 'date/73.png',
                                'w': 11,
                                'h': 35
                            },
                            'J': {
                                'src': 'date/74.png',
                                'w': 21,
                                'h': 35
                            },
                            'L': {
                                'src': 'date/76.png',
                                'w': 23,
                                'h': 35
                            },
                            'M': {
                                'src': 'date/77.png',
                                'w': 32,
                                'h': 35
                            },
                            'N': {
                                'src': 'date/78.png',
                                'w': 28,
                                'h': 35
                            },
                            'O': {
                                'src': 'date/79.png',
                                'w': 30,
                                'h': 35
                            },
                            'P': {
                                'src': 'date/80.png',
                                'w': 26,
                                'h': 35
                            },
                            'R': {
                                'src': 'date/82.png',
                                'w': 28,
                                'h': 35
                            },
                            'S': {
                                'src': 'date/83.png',
                                'w': 26,
                                'h': 35
                            },
                            'T': {
                                'src': 'date/84.png',
                                'w': 23,
                                'h': 35
                            },
                            'U': {
                                'src': 'date/85.png',
                                'w': 28,
                                'h': 35
                            },
                            'V': {
                                'src': 'date/86.png',
                                'w': 26,
                                'h': 35
                            },
                            'W': {
                                'src': 'date/87.png',
                                'w': 36,
                                'h': 35
                            },
                            'Y': {
                                'src': 'date/89.png',
                                'w': 26,
                                'h': 35
                            },
                            ' ': {
                                'src': 'date/32.png',
                                'w': 9,
                                'h': 35
                            }
                        },
                        'battery': {
                            '0': {
                                'src': 'battery/48.png',
                                'w': 23,
                                'h': 38
                            },
                            '1': {
                                'src': 'battery/49.png',
                                'w': 23,
                                'h': 38
                            },
                            '2': {
                                'src': 'battery/50.png',
                                'w': 23,
                                'h': 38
                            },
                            '3': {
                                'src': 'battery/51.png',
                                'w': 23,
                                'h': 38
                            },
                            '4': {
                                'src': 'battery/52.png',
                                'w': 23,
                                'h': 38
                            },
                            '5': {
                                'src': 'battery/53.png',
                                'w': 23,
                                'h': 38
                            },
                            '6': {
                                'src': 'battery/54.png',
                                'w': 23,
                                'h': 38
                            },
                            '7': {
                                'src': 'battery/55.png',
                                'w': 23,
                                'h': 38
                            },
                            '8': {
                                'src': 'battery/56.png',
                                'w': 23,
                                'h': 38
                            },
                            '9': {
                                'src': 'battery/57.png',
                                'w': 23,
                                'h': 38
                            },
                            '%': {
                                'src': 'battery/37.png',
                                'w': 37,
                                'h': 38
                            },
                            '-': {
                                'src': 'battery/45.png',
                                'w': 14,
                                'h': 38
                            }
                        }
                    },
                    'words': {
                        '\xB0C': {
                            'src': 'unit-0.png',
                            'w': 30,
                            'h': 24
                        },
                        '\xB0F': {
                            'src': 'unit-1.png',
                            'w': 27,
                            'h': 23
                        },
                        '%': {
                            'src': 'unit-2.png',
                            'w': 24,
                            'h': 24
                        },
                        'Bft': {
                            'src': 'unit-3.png',
                            'w': 37,
                            'h': 24
                        },
                        'km': {
                            'src': 'unit-4.png',
                            'w': 38,
                            'h': 23
                        },
                        'mi': {
                            'src': 'unit-5.png',
                            'w': 31,
                            'h': 24
                        },
                        'kcal': {
                            'src': 'unit-6.png',
                            'w': 51,
                            'h': 24
                        },
                        'hPa': {
                            'src': 'unit-7.png',
                            'w': 48,
                            'h': 24
                        }
                    },
                    'audit': [
                        {
                            'text': '0',
                            'src': 'metric/48.png',
                            'letter_heights': { '0': 45 }
                        },
                        {
                            'text': '1',
                            'src': 'metric/49.png',
                            'letter_heights': { '1': 44 }
                        },
                        {
                            'text': '2',
                            'src': 'metric/50.png',
                            'letter_heights': { '2': 44 }
                        },
                        {
                            'text': '3',
                            'src': 'metric/51.png',
                            'letter_heights': { '3': 45 }
                        },
                        {
                            'text': '4',
                            'src': 'metric/52.png',
                            'letter_heights': { '4': 44 }
                        },
                        {
                            'text': '5',
                            'src': 'metric/53.png',
                            'letter_heights': { '5': 45 }
                        },
                        {
                            'text': '6',
                            'src': 'metric/54.png',
                            'letter_heights': { '6': 45 }
                        },
                        {
                            'text': '7',
                            'src': 'metric/55.png',
                            'letter_heights': { '7': 43 }
                        },
                        {
                            'text': '8',
                            'src': 'metric/56.png',
                            'letter_heights': { '8': 45 }
                        },
                        {
                            'text': '9',
                            'src': 'metric/57.png',
                            'letter_heights': { '9': 45 }
                        },
                        {
                            'text': '0',
                            'src': 'date/48.png',
                            'letter_heights': { '0': 34 }
                        },
                        {
                            'text': '1',
                            'src': 'date/49.png',
                            'letter_heights': { '1': 33 }
                        },
                        {
                            'text': '2',
                            'src': 'date/50.png',
                            'letter_heights': { '2': 33 }
                        },
                        {
                            'text': '3',
                            'src': 'date/51.png',
                            'letter_heights': { '3': 34 }
                        },
                        {
                            'text': '4',
                            'src': 'date/52.png',
                            'letter_heights': { '4': 33 }
                        },
                        {
                            'text': '5',
                            'src': 'date/53.png',
                            'letter_heights': { '5': 33 }
                        },
                        {
                            'text': '6',
                            'src': 'date/54.png',
                            'letter_heights': { '6': 34 }
                        },
                        {
                            'text': '7',
                            'src': 'date/55.png',
                            'letter_heights': { '7': 32 }
                        },
                        {
                            'text': '8',
                            'src': 'date/56.png',
                            'letter_heights': { '8': 34 }
                        },
                        {
                            'text': '9',
                            'src': 'date/57.png',
                            'letter_heights': { '9': 34 }
                        },
                        {
                            'text': 'A',
                            'src': 'date/65.png',
                            'letter_heights': { 'A': 33 }
                        },
                        {
                            'text': 'B',
                            'src': 'date/66.png',
                            'letter_heights': { 'B': 33 }
                        },
                        {
                            'text': 'C',
                            'src': 'date/67.png',
                            'letter_heights': { 'C': 35 }
                        },
                        {
                            'text': 'D',
                            'src': 'date/68.png',
                            'letter_heights': { 'D': 33 }
                        },
                        {
                            'text': 'E',
                            'src': 'date/69.png',
                            'letter_heights': { 'E': 33 }
                        },
                        {
                            'text': 'F',
                            'src': 'date/70.png',
                            'letter_heights': { 'F': 33 }
                        },
                        {
                            'text': 'G',
                            'src': 'date/71.png',
                            'letter_heights': { 'G': 35 }
                        },
                        {
                            'text': 'H',
                            'src': 'date/72.png',
                            'letter_heights': { 'H': 33 }
                        },
                        {
                            'text': 'I',
                            'src': 'date/73.png',
                            'letter_heights': { 'I': 33 }
                        },
                        {
                            'text': 'J',
                            'src': 'date/74.png',
                            'letter_heights': { 'J': 34 }
                        },
                        {
                            'text': 'L',
                            'src': 'date/76.png',
                            'letter_heights': { 'L': 33 }
                        },
                        {
                            'text': 'M',
                            'src': 'date/77.png',
                            'letter_heights': { 'M': 33 }
                        },
                        {
                            'text': 'N',
                            'src': 'date/78.png',
                            'letter_heights': { 'N': 33 }
                        },
                        {
                            'text': 'O',
                            'src': 'date/79.png',
                            'letter_heights': { 'O': 35 }
                        },
                        {
                            'text': 'P',
                            'src': 'date/80.png',
                            'letter_heights': { 'P': 33 }
                        },
                        {
                            'text': 'R',
                            'src': 'date/82.png',
                            'letter_heights': { 'R': 33 }
                        },
                        {
                            'text': 'S',
                            'src': 'date/83.png',
                            'letter_heights': { 'S': 35 }
                        },
                        {
                            'text': 'T',
                            'src': 'date/84.png',
                            'letter_heights': { 'T': 33 }
                        },
                        {
                            'text': 'U',
                            'src': 'date/85.png',
                            'letter_heights': { 'U': 34 }
                        },
                        {
                            'text': 'V',
                            'src': 'date/86.png',
                            'letter_heights': { 'V': 33 }
                        },
                        {
                            'text': 'W',
                            'src': 'date/87.png',
                            'letter_heights': { 'W': 33 }
                        },
                        {
                            'text': 'Y',
                            'src': 'date/89.png',
                            'letter_heights': { 'Y': 33 }
                        },
                        {
                            'text': '0',
                            'src': 'battery/48.png',
                            'letter_heights': { '0': 37 }
                        },
                        {
                            'text': '1',
                            'src': 'battery/49.png',
                            'letter_heights': { '1': 36 }
                        },
                        {
                            'text': '2',
                            'src': 'battery/50.png',
                            'letter_heights': { '2': 36 }
                        },
                        {
                            'text': '3',
                            'src': 'battery/51.png',
                            'letter_heights': { '3': 37 }
                        },
                        {
                            'text': '4',
                            'src': 'battery/52.png',
                            'letter_heights': { '4': 36 }
                        },
                        {
                            'text': '5',
                            'src': 'battery/53.png',
                            'letter_heights': { '5': 36 }
                        },
                        {
                            'text': '6',
                            'src': 'battery/54.png',
                            'letter_heights': { '6': 37 }
                        },
                        {
                            'text': '7',
                            'src': 'battery/55.png',
                            'letter_heights': { '7': 35 }
                        },
                        {
                            'text': '8',
                            'src': 'battery/56.png',
                            'letter_heights': { '8': 37 }
                        },
                        {
                            'text': '9',
                            'src': 'battery/57.png',
                            'letter_heights': { '9': 37 }
                        },
                        {
                            'text': '\xB0C',
                            'src': 'unit-0.png',
                            'letter_heights': { 'C': 24 }
                        },
                        {
                            'text': '\xB0F',
                            'src': 'unit-1.png',
                            'letter_heights': { 'F': 23 }
                        },
                        {
                            'text': '%',
                            'src': 'unit-2.png',
                            'letter_heights': {}
                        },
                        {
                            'text': 'Bft',
                            'src': 'unit-3.png',
                            'letter_heights': {
                                't': 22,
                                'f': 23,
                                'B': 23
                            }
                        },
                        {
                            'text': 'km',
                            'src': 'unit-4.png',
                            'letter_heights': {
                                'm': 18,
                                'k': 23
                            }
                        },
                        {
                            'text': 'mi',
                            'src': 'unit-5.png',
                            'letter_heights': {
                                'm': 18,
                                'i': 21
                            }
                        },
                        {
                            'text': 'kcal',
                            'src': 'unit-6.png',
                            'letter_heights': {
                                'a': 18,
                                'l': 23,
                                'c': 18,
                                'k': 23
                            }
                        },
                        {
                            'text': 'hPa',
                            'src': 'unit-7.png',
                            'letter_heights': {
                                'P': 23,
                                'a': 18,
                                'h': 23
                            }
                        },
                        {
                            'text': 'ArtIst',
                            'src': 'logo.png',
                            'letter_heights': {
                                'A': 24,
                                'r': 19,
                                't': 23,
                                'I': 24,
                                's': 20
                            }
                        }
                    ],
                    'themes': [
                        'cinnabar',
                        'ochre',
                        'indigo'
                    ],
                    'demo': {
                        'src': 'demo.png',
                        'w': 321,
                        'h': 99
                    },
                    'logoWidth': 101,
                    'logoHeight': 25,
                    'aod': [
                        {
                            'kind': 'IMG_TIME',
                            'props': {
                                'hour_startX': 38,
                                'hour_startY': 159,
                                'hour_zero': 1,
                                'hour_space': 0,
                                'hour_array': [
                                    'aod-brush/0.png',
                                    'aod-brush/1.png',
                                    'aod-brush/2.png',
                                    'aod-brush/3.png',
                                    'aod-brush/4.png',
                                    'aod-brush/5.png',
                                    'aod-brush/6.png',
                                    'aod-brush/7.png',
                                    'aod-brush/8.png',
                                    'aod-brush/9.png'
                                ],
                                'minute_startX': 263,
                                'minute_startY': 159,
                                'minute_zero': 1,
                                'minute_follow': 0,
                                'minute_space': 0,
                                'minute_array': [
                                    'aod-brush/0.png',
                                    'aod-brush/1.png',
                                    'aod-brush/2.png',
                                    'aod-brush/3.png',
                                    'aod-brush/4.png',
                                    'aod-brush/5.png',
                                    'aod-brush/6.png',
                                    'aod-brush/7.png',
                                    'aod-brush/8.png',
                                    'aod-brush/9.png'
                                ]
                            }
                        },
                        {
                            'kind': 'IMG',
                            'props': {
                                'src': 'aod-brush/colon.png',
                                'x': 218,
                                'y': 159
                            }
                        },
                        {
                            'kind': 'IMG_WEEK',
                            'props': {
                                'x': 121,
                                'y': 109,
                                'week_en': [
                                    'aod-face/week-0.png',
                                    'aod-face/week-1.png',
                                    'aod-face/week-2.png',
                                    'aod-face/week-3.png',
                                    'aod-face/week-4.png',
                                    'aod-face/week-5.png',
                                    'aod-face/week-6.png'
                                ],
                                'week_sc': [
                                    'aod-face/week-0.png',
                                    'aod-face/week-1.png',
                                    'aod-face/week-2.png',
                                    'aod-face/week-3.png',
                                    'aod-face/week-4.png',
                                    'aod-face/week-5.png',
                                    'aod-face/week-6.png'
                                ],
                                'week_tc': [
                                    'aod-face/week-0.png',
                                    'aod-face/week-1.png',
                                    'aod-face/week-2.png',
                                    'aod-face/week-3.png',
                                    'aod-face/week-4.png',
                                    'aod-face/week-5.png',
                                    'aod-face/week-6.png'
                                ]
                            }
                        },
                        {
                            'kind': 'IMG_DATE',
                            'props': {
                                'day_startX': 220,
                                'day_startY': 109,
                                'day_is_character': true,
                                'day_zero': 0,
                                'day_follow': 0,
                                'day_space': 0,
                                'day_align': 1,
                                'day_en_array': [
                                    'aod-face/day-0.png',
                                    'aod-face/day-1.png',
                                    'aod-face/day-2.png',
                                    'aod-face/day-3.png',
                                    'aod-face/day-4.png',
                                    'aod-face/day-5.png',
                                    'aod-face/day-6.png',
                                    'aod-face/day-7.png',
                                    'aod-face/day-8.png',
                                    'aod-face/day-9.png',
                                    'aod-face/day-10.png',
                                    'aod-face/day-11.png',
                                    'aod-face/day-12.png',
                                    'aod-face/day-13.png',
                                    'aod-face/day-14.png',
                                    'aod-face/day-15.png',
                                    'aod-face/day-16.png',
                                    'aod-face/day-17.png',
                                    'aod-face/day-18.png',
                                    'aod-face/day-19.png',
                                    'aod-face/day-20.png',
                                    'aod-face/day-21.png',
                                    'aod-face/day-22.png',
                                    'aod-face/day-23.png',
                                    'aod-face/day-24.png',
                                    'aod-face/day-25.png',
                                    'aod-face/day-26.png',
                                    'aod-face/day-27.png',
                                    'aod-face/day-28.png',
                                    'aod-face/day-29.png',
                                    'aod-face/day-30.png'
                                ],
                                'day_sc_array': [
                                    'aod-face/day-0.png',
                                    'aod-face/day-1.png',
                                    'aod-face/day-2.png',
                                    'aod-face/day-3.png',
                                    'aod-face/day-4.png',
                                    'aod-face/day-5.png',
                                    'aod-face/day-6.png',
                                    'aod-face/day-7.png',
                                    'aod-face/day-8.png',
                                    'aod-face/day-9.png',
                                    'aod-face/day-10.png',
                                    'aod-face/day-11.png',
                                    'aod-face/day-12.png',
                                    'aod-face/day-13.png',
                                    'aod-face/day-14.png',
                                    'aod-face/day-15.png',
                                    'aod-face/day-16.png',
                                    'aod-face/day-17.png',
                                    'aod-face/day-18.png',
                                    'aod-face/day-19.png',
                                    'aod-face/day-20.png',
                                    'aod-face/day-21.png',
                                    'aod-face/day-22.png',
                                    'aod-face/day-23.png',
                                    'aod-face/day-24.png',
                                    'aod-face/day-25.png',
                                    'aod-face/day-26.png',
                                    'aod-face/day-27.png',
                                    'aod-face/day-28.png',
                                    'aod-face/day-29.png',
                                    'aod-face/day-30.png'
                                ],
                                'day_tc_array': [
                                    'aod-face/day-0.png',
                                    'aod-face/day-1.png',
                                    'aod-face/day-2.png',
                                    'aod-face/day-3.png',
                                    'aod-face/day-4.png',
                                    'aod-face/day-5.png',
                                    'aod-face/day-6.png',
                                    'aod-face/day-7.png',
                                    'aod-face/day-8.png',
                                    'aod-face/day-9.png',
                                    'aod-face/day-10.png',
                                    'aod-face/day-11.png',
                                    'aod-face/day-12.png',
                                    'aod-face/day-13.png',
                                    'aod-face/day-14.png',
                                    'aod-face/day-15.png',
                                    'aod-face/day-16.png',
                                    'aod-face/day-17.png',
                                    'aod-face/day-18.png',
                                    'aod-face/day-19.png',
                                    'aod-face/day-20.png',
                                    'aod-face/day-21.png',
                                    'aod-face/day-22.png',
                                    'aod-face/day-23.png',
                                    'aod-face/day-24.png',
                                    'aod-face/day-25.png',
                                    'aod-face/day-26.png',
                                    'aod-face/day-27.png',
                                    'aod-face/day-28.png',
                                    'aod-face/day-29.png',
                                    'aod-face/day-30.png'
                                ],
                                'month_startX': 271,
                                'month_startY': 109,
                                'month_is_character': true,
                                'month_zero': 0,
                                'month_follow': 0,
                                'month_space': 0,
                                'month_align': 1,
                                'month_en_array': [
                                    'aod-face/month-0.png',
                                    'aod-face/month-1.png',
                                    'aod-face/month-2.png',
                                    'aod-face/month-3.png',
                                    'aod-face/month-4.png',
                                    'aod-face/month-5.png',
                                    'aod-face/month-6.png',
                                    'aod-face/month-7.png',
                                    'aod-face/month-8.png',
                                    'aod-face/month-9.png',
                                    'aod-face/month-10.png',
                                    'aod-face/month-11.png'
                                ],
                                'month_sc_array': [
                                    'aod-face/month-0.png',
                                    'aod-face/month-1.png',
                                    'aod-face/month-2.png',
                                    'aod-face/month-3.png',
                                    'aod-face/month-4.png',
                                    'aod-face/month-5.png',
                                    'aod-face/month-6.png',
                                    'aod-face/month-7.png',
                                    'aod-face/month-8.png',
                                    'aod-face/month-9.png',
                                    'aod-face/month-10.png',
                                    'aod-face/month-11.png'
                                ],
                                'month_tc_array': [
                                    'aod-face/month-0.png',
                                    'aod-face/month-1.png',
                                    'aod-face/month-2.png',
                                    'aod-face/month-3.png',
                                    'aod-face/month-4.png',
                                    'aod-face/month-5.png',
                                    'aod-face/month-6.png',
                                    'aod-face/month-7.png',
                                    'aod-face/month-8.png',
                                    'aod-face/month-9.png',
                                    'aod-face/month-10.png',
                                    'aod-face/month-11.png'
                                ]
                            }
                        }
                    ]
                };
                var __defProp = Object.defineProperty;
                var __defProps = Object.defineProperties;
                var __getOwnPropDescs = Object.getOwnPropertyDescriptors;
                var __getOwnPropSymbols = Object.getOwnPropertySymbols;
                var __hasOwnProp = Object.prototype.hasOwnProperty;
                var __propIsEnum = Object.prototype.propertyIsEnumerable;
                var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, {
                    enumerable: true,
                    configurable: true,
                    writable: true,
                    value
                }) : obj[key] = value;
                var __spreadValues = (a, b) => {
                    for (var prop in b || (b = {}))
                        if (__hasOwnProp.call(b, prop))
                            __defNormalProp(a, prop, b[prop]);
                    if (__getOwnPropSymbols)
                        for (var prop of __getOwnPropSymbols(b)) {
                            if (__propIsEnum.call(b, prop))
                                __defNormalProp(a, prop, b[prop]);
                        }
                    return a;
                };
                var __spreadProps = (a, b) => __defProps(a, __getOwnPropDescs(b));
                const N = ui__default.default.show_level.ONLY_NORMAL, A = ui__default.default.show_level.ONLY_AOD, safe = f => {
                        try {
                            return f();
                        } catch (e) {
                            return void 0;
                        }
                    };
                const KEY = 'artist-sumi-e-trial-v1', PREF = 'artist-sumi-e-prefs-v1';
                let cleanup = () => {
                };
                __$$module$$__.module = WatchFace({
                    build() {
                        cleanup();
                        const create = (kind, p, level = N) => {
                            var _a;
                            const w = ui__default.default.createWidget(kind, __spreadProps(__spreadValues({}, p), { show_level: level }));
                            if (![
                                    ui__default.default.widget.BUTTON,
                                    ui__default.default.widget.IMG_CLICK,
                                    ui__default.default.widget.WIDGET_DELEGATE
                                ].includes(kind))
                                (_a = w.setEnable) == null ? void 0 : _a.call(w, false);
                            return w;
                        };
                        const show = (w, v) => w && w.setProperty(ui__default.default.prop.VISIBLE, !!v), img = (src, x, y) => create(ui__default.default.widget.IMG, {
                                src,
                                x,
                                y
                            });
                        create(ui__default.default.widget.FILL_RECT, {
                            x: 0,
                            y: 0,
                            w: 480,
                            h: 480,
                            color: 0
                        }, A);
                        for (const w of R.aod)
                            create(ui__default.default.widget[w.kind], w.props, A);
                        if (app.getScene() === app.SCENE_AOD)
                            return;
                        const store = safe(() => new storage.LocalStorage()), saved = safe(() => store.getItem(PREF)) || {}, bounded = (v, n) => Number.isInteger(v) && v >= 0 && v < n ? v : 0;
                        let theme = bounded(saved.theme, 3), small = bounded(saved.small, 4), bottom = bounded(saved.bottom, 4), awake = false, dead = false, timer = null, expired = false, registered = false;
                        const persist = () => safe(() => store.setItem(PREF, {
                            theme,
                            small,
                            bottom
                        }));
                        let trial = safe(() => store.getItem(KEY));
                        if (!trial || !Number.isFinite(trial.started) || !Number.isFinite(trial.last)) {
                            const n = Date.now();
                            trial = {
                                started: n,
                                last: n,
                                expired: false
                            };
                            try {
                                store.setItem(KEY, trial);
                            } catch (e) {
                                trial.expired = true;
                            }
                        }
                        function check() {
                            const n = Date.now(), old = trial.expired;
                            trial.expired = !!old || n < trial.last - 5000 || n - trial.started >= 1800000;
                            if (old !== trial.expired || n - trial.last >= 60000) {
                                trial.last = Math.max(n, trial.last);
                                safe(() => store.setItem(KEY, trial));
                            }
                            return trial.expired;
                        }
                        const battery = safe(() => new sensor.Battery()), step = safe(() => new sensor.Step()), barometer = safe(() => new sensor.Barometer()), time = safe(() => new sensor.Time());
                        const background = img('background-' + R.themes[theme] + '.png', 0, 0);
                        img('logo.png', Math.round(240 - R.logoWidth / 2), Math.round(61 - R.logoHeight / 2));
                        const imageSlot = () => {
                            const w = img('battery-0.png', 0, 0);
                            show(w, false);
                            return (item, cx, cy) => {
                                show(w, !!item);
                                if (item)
                                    w.setProperty(ui__default.default.prop.MORE, {
                                        src: item.src,
                                        x: Math.round(cx - item.w / 2),
                                        y: Math.round(cy - item.h / 2)
                                    });
                            };
                        };
                        function textSlot(x, cy, center = false) {
                            const pool = [];
                            return (s, f) => {
                                const parts = [...s].map(c => {
                                    var _a;
                                    return (_a = R.glyphs[f]) == null ? void 0 : _a[c];
                                }).filter(Boolean);
                                let left = center ? Math.round(x - parts.reduce((n, p) => n + p.w, 0) / 2) : x;
                                pool.forEach(w => show(w, false));
                                parts.forEach((p, i) => {
                                    if (!pool[i])
                                        pool[i] = img(p.src, 0, 0);
                                    pool[i].setProperty(ui__default.default.prop.MORE, {
                                        src: p.src,
                                        x: left,
                                        y: Math.round(cy - p.h / 2)
                                    });
                                    show(pool[i], true);
                                    left += p.w;
                                });
                            };
                        }
                        const date = textSlot(240, 126, true), charge = textSlot(244, 397), bottomText = textSlot(294, 328), smallZero = textSlot(152, 328), unit = imageSlot(), bottomUnit = imageSlot();
                        const smallIcon = img('mode-hr.png', 105, 312), bottomIcon = img('mode-steps.png', 242, 314);
                        const batIcon = img('battery-4.png', 177, 381);
                        const clock = create(ui__default.default.widget.IMG_TIME, {
                            hour_startX: 38,
                            hour_startY: 159,
                            hour_zero: 1,
                            hour_space: 0,
                            hour_array: Array.from({ length: 10 }, (_, i) => 'brush-clock/' + i + '.png'),
                            minute_startX: 263,
                            minute_startY: 159,
                            minute_zero: 1,
                            minute_follow: 0,
                            minute_space: 0,
                            minute_array: Array.from({ length: 10 }, (_, i) => 'brush-clock/' + i + '.png')
                        });
                        const colon = img('clock/colon.png', 218, 159), demo = imageSlot();
                        const native = (type, x, w) => ui__default.default.data_type[type] === void 0 ? null : create(ui__default.default.widget.TEXT_IMG, {
                            x,
                            y: 305,
                            w,
                            h: 46,
                            type: ui__default.default.data_type[type],
                            font_array: Array.from({ length: 10 }, (_, i) => R.glyphs.metric[i].src),
                            dot_image: R.glyphs.metric['.'].src,
                            negative_image: R.glyphs.metric['-'].src,
                            invalid_image: R.glyphs.metric['-'].src,
                            h_space: 0,
                            align_h: ui__default.default.align.LEFT
                        });
                        const smallNative = [
                                'HEART',
                                'WEATHER_CURRENT',
                                'HUMIDITY',
                                'WIND'
                            ].map(t => native(t, 152, 90)), bottomNative = [
                                null,
                                native('DISTANCE', 294, 145),
                                native('CAL', 294, 145),
                                null
                            ];
                        const pending = new Set(), clearTaps = () => {
                                pending.forEach(clearTimeout);
                                pending.clear();
                            }, open = id => {
                                if (awake && !check())
                                    safe(() => router.launchApp({
                                        appId: id,
                                        native: true
                                    }));
                            };
                        function button(x, y, w, h, fn) {
                            return create(ui__default.default.widget.BUTTON, {
                                x,
                                y,
                                w,
                                h,
                                text: '',
                                normal_src: `hit-${ w }-${ h }.png`,
                                press_src: `hit-${ w }-${ h }.png`,
                                click_func: () => {
                                    if (awake && !check())
                                        fn();
                                    else
                                        refresh();
                                }
                            });
                        }
                        function double(x, y, w, h, single, second) {
                            let id = null, last = 0;
                            button(x, y, w, h, () => {
                                const n = Date.now();
                                if (id !== null && pending.has(id) && n - last <= 330) {
                                    clearTimeout(id);
                                    pending.delete(id);
                                    id = null;
                                    second();
                                    return;
                                }
                                last = n;
                                id = setTimeout(() => {
                                    pending.delete(id);
                                    id = null;
                                    if (awake && !check())
                                        single();
                                }, 330);
                                pending.add(id);
                            });
                        }
                        const batteryTap = ui__default.default.data_type.BATTERY === void 0 ? null : create(ui__default.default.widget.IMG_CLICK, {
                            src: 'hit-210-54.png',
                            x: 165,
                            y: 376,
                            w: 210,
                            h: 54,
                            type: ui__default.default.data_type.BATTERY
                        });
                        function refresh() {
                            if (dead || !awake)
                                return;
                            expired = check();
                            background.setProperty(ui__default.default.prop.SRC, 'background-' + R.themes[theme] + '.png');
                            show(clock, !expired);
                            show(colon, !expired);
                            demo(expired ? R.demo : null, 240, 226);
                            const d = new Date();
                            date([
                                'SUN',
                                'MON',
                                'TUE',
                                'WED',
                                'THU',
                                'FRI',
                                'SAT'
                            ][d.getDay()] + ' ' + d.getDate() + ' ' + [
                                'JAN',
                                'FEB',
                                'MAR',
                                'APR',
                                'MAY',
                                'JUN',
                                'JUL',
                                'AUG',
                                'SEP',
                                'OCT',
                                'NOV',
                                'DEC'
                            ][d.getMonth()], 'date');
                            const bat = safe(() => battery.getCurrent()), valid = Number.isFinite(bat) && bat >= 0 && bat <= 100;
                            charge(expired ? '00%' : valid ? Math.round(bat) + '%' : '--%', 'battery');
                            batIcon.setProperty(ui__default.default.prop.SRC, 'battery-' + (expired || !valid ? 0 : Math.ceil(bat / 25)) + '.png');
                            show(batteryTap, !expired);
                            const degrees = safe(() => settings.getTemperatureUnit()) === settings.TEMPERATURE_UNIT_FAHRENHEIT ? '\xB0F' : '\xB0C', distance = safe(() => settings.getDistanceUnit()) === settings.DISTANCE_UNIT_IMPERIAL ? 'mi' : 'km';
                            const smallNames = [
                                    'hr',
                                    'temp',
                                    'hum',
                                    'wind'
                                ], bottomNames = [
                                    'steps',
                                    'distance',
                                    'cal',
                                    'pressure'
                                ];
                            smallIcon.setProperty(ui__default.default.prop.MORE, {
                                src: 'mode-' + smallNames[small] + '.png',
                                x: 105,
                                y: small === 0 ? 312 : 312
                            });
                            bottomIcon.setProperty(ui__default.default.prop.MORE, {
                                src: 'mode-' + bottomNames[bottom] + '.png',
                                x: 242,
                                y: bottom === 0 ? 314 : 312
                            });
                            unit(small ? R.words[[
                                null,
                                degrees,
                                '%',
                                'Bft'
                            ][small]] : null, 196, 365);
                            bottomUnit(bottom ? R.words[[
                                null,
                                distance,
                                'kcal',
                                'hPa'
                            ][bottom]] : null, 355, 365);
                            smallNative.forEach((w, i) => show(w, !expired && i === small));
                            bottomNative.forEach((w, i) => show(w, !expired && i === bottom));
                            smallZero(expired ? '00' : smallNative[small] ? '' : '--', 'metric');
                            let value = '';
                            if (expired)
                                value = '00';
                            else if (bottom === 0) {
                                const n = safe(() => step.getCurrent());
                                value = Number.isFinite(n) && n >= 0 && n <= 99999 ? String(Math.round(n)) : '--';
                            } else if (bottom === 3) {
                                const n = safe(() => barometer.getAirPressure());
                                value = Number.isFinite(n) && n > 0 && n <= 1200 ? String(Math.round(n)) : '--';
                            } else if (!bottomNative[bottom])
                                value = '--';
                            bottomText(value, 'metric');
                            if (expired) {
                                clearTaps();
                                stopTimer();
                            }
                        }
                        function stopTimer() {
                            if (timer !== null) {
                                clearInterval(timer);
                                timer = null;
                            }
                        }
                        function pause() {
                            awake = false;
                            clearTaps();
                            stopTimer();
                            if (registered) {
                                for (const s of [
                                        battery,
                                        step,
                                        barometer
                                    ])
                                    safe(() => s.offChange(refresh));
                                safe(() => time.offPerMinute(refresh));
                                registered = false;
                            }
                            {
                                check();
                                trial.last = Math.max(trial.last, Date.now());
                                safe(() => store.setItem(KEY, trial));
                            }
                        }
                        function resume() {
                            if (dead)
                                return;
                            pause();
                            awake = true;
                            refresh();
                            if (!expired) {
                                for (const s of [
                                        battery,
                                        step,
                                        barometer
                                    ])
                                    safe(() => s.onChange(refresh));
                                safe(() => time.onPerMinute(refresh));
                                registered = true;
                                timer = setInterval(refresh, 1000);
                            }
                        }
                        button(155, 38, 170, 48, () => {
                            theme = (theme + 1) % 3;
                            persist();
                            refresh();
                        });
                        button(40, 154, 400, 140, () => open(router.SYSTEM_APP_ALARM));
                        button(95, 97, 290, 58, () => open(router.SYSTEM_APP_CALENDAR));
                        double(90, 299, 150, 78, () => {
                            small = (small + 1) % 4;
                            persist();
                            refresh();
                        }, () => open(small === 0 ? router.SYSTEM_APP_HR : router.SYSTEM_APP_WEATHER));
                        double(240, 299, 220, 78, () => {
                            bottom = (bottom + 1) % 4;
                            persist();
                            refresh();
                        }, () => open(bottom === 3 ? router.SYSTEM_APP_ALTIMETER : router.SYSTEM_APP_STATUS));
                        create(ui__default.default.widget.WIDGET_DELEGATE, {
                            pause_call: pause,
                            resume_call: resume
                        });
                        cleanup = () => {
                            pause();
                            dead = true;
                            cleanup = () => {
                            };
                        };
                        resume();
                    },
                    onDestroy() {
                        cleanup();
                    }
                });
                ;
            }
        }.bind(__$$G$$__)(__$$G$$__);
        afterPageCreate();
        afterModuleCreate();
        ;
    })());
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

let colorNumber = 1
let totalColors = 7
let colorName = ''


function click_color() {

    if(colorNumber >= totalColors) {
        colorNumber = 1;
    }
    else {
        colorNumber = colorNumber + 1;
    }


    //*** Toast with text / Toast con texto ***
    if ( colorNumber == 1) { colorName = "Original"}
    if ( colorNumber > 1)  { colorName = "Variant " + parseInt(colorNumber - 1)}
    hmUI.showToast({text: colorName });


    //*** Toast with text and index / Toast con texto e indice ***
    //hmUI.showToast({text: "Color " + parseInt(colorNumber) });


    //*** Toast with index / Toast con indice ***
	//hmUI.showToast({text: "" + parseInt(colorNumber) });


    normal_background_bg_img.setProperty(hmUI.prop.SRC, "bg" + parseInt(colorNumber) + ".png");
         
    }
        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_date_img_date_year = ''
        let normal_system_clock_img = ''
        let normal_date_img_date_week_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_step_current_text_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_image_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_city_name_text = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_battery_image_progress_img_level = ''
        let normal_battery_text_text_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg_img = ''
        let idle_date_img_date_week_img = ''
        let idle_image_img = ''
        let idle_date_img_date_day = ''
        let idle_battery_text_text_img = ''
        let idle_battery_text_separator_img = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let Button_1 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 340,
              year_startY: 237,
              year_sc_array: ["WF0_Frame0047.png","WF0_Frame0048.png","WF0_Frame0049.png","WF0_Frame0050.png","WF0_Frame0051.png","WF0_Frame0052.png","WF0_Frame0053.png","WF0_Frame0054.png","WF0_Frame0055.png","WF0_Frame0056.png"],
              year_tc_array: ["WF0_Frame0047.png","WF0_Frame0048.png","WF0_Frame0049.png","WF0_Frame0050.png","WF0_Frame0051.png","WF0_Frame0052.png","WF0_Frame0053.png","WF0_Frame0054.png","WF0_Frame0055.png","WF0_Frame0056.png"],
              year_en_array: ["WF0_Frame0047.png","WF0_Frame0048.png","WF0_Frame0049.png","WF0_Frame0050.png","WF0_Frame0051.png","WF0_Frame0052.png","WF0_Frame0053.png","WF0_Frame0054.png","WF0_Frame0055.png","WF0_Frame0056.png"],
              year_zero: 1,
              year_space: 0,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 109,
              y: 357,
              src: '0075.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 82,
              y: 187,
              week_en: ["m0043.png","m0044.png","m0045.png","m0046.png","m0047.png","m0048.png","m0049.png"],
              week_tc: ["m0043.png","m0044.png","m0045.png","m0046.png","m0047.png","m0048.png","m0049.png"],
              week_sc: ["m0043.png","m0044.png","m0045.png","m0046.png","m0047.png","m0048.png","m0049.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 94,
              y: 238,
              font_array: ["WF0_Frame0047.png","WF0_Frame0048.png","WF0_Frame0049.png","WF0_Frame0050.png","WF0_Frame0051.png","WF0_Frame0052.png","WF0_Frame0053.png","WF0_Frame0054.png","WF0_Frame0055.png","WF0_Frame0056.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 108,
              y: 129,
              font_array: ["WF0_Frame0047.png","WF0_Frame0048.png","WF0_Frame0049.png","WF0_Frame0050.png","WF0_Frame0051.png","WF0_Frame0052.png","WF0_Frame0053.png","WF0_Frame0054.png","WF0_Frame0055.png","WF0_Frame0056.png"],
              padding: false,
              h_space: 0,
              unit_sc: '0042.png',
              unit_tc: '0042.png',
              unit_en: '0042.png',
              dot_image: '0039.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 259,
              y: 83,
              font_array: ["WF0_Frame0047.png","WF0_Frame0048.png","WF0_Frame0049.png","WF0_Frame0050.png","WF0_Frame0051.png","WF0_Frame0052.png","WF0_Frame0053.png","WF0_Frame0054.png","WF0_Frame0055.png","WF0_Frame0056.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 156,
              y: 83,
              font_array: ["WF0_Frame0047.png","WF0_Frame0048.png","WF0_Frame0049.png","WF0_Frame0050.png","WF0_Frame0051.png","WF0_Frame0052.png","WF0_Frame0053.png","WF0_Frame0054.png","WF0_Frame0055.png","WF0_Frame0056.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 244,
              y: 121,
              image_array: ["0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png","0023.png"],
              image_length: 10,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 212,
              y: 276,
              src: 'wfs_points_113d9760_a00c_46d1_864c_9403f38f898e.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 135,
              y: 372,
              font_array: ["WF0_Frame0047.png","WF0_Frame0048.png","WF0_Frame0049.png","WF0_Frame0050.png","WF0_Frame0051.png","WF0_Frame0052.png","WF0_Frame0053.png","WF0_Frame0054.png","WF0_Frame0055.png","WF0_Frame0056.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'gp.png',
              unit_tc: 'gp.png',
              unit_en: 'gp.png',
              negative_image: 'gt.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 206,
              y: 348,
              image_array: ["weather_icon_01.png","weather_icon_02.png","weather_icon_03.png","weather_icon_04.png","weather_icon_05.png","weather_icon_06.png","weather_icon_07.png","weather_icon_08.png","weather_icon_09.png","weather_icon_10.png","weather_icon_11.png","weather_icon_12.png","weather_icon_13.png","weather_icon_14.png","weather_icon_15.png","weather_icon_16.png","weather_icon_17.png","weather_icon_18.png","weather_icon_19.png","weather_icon_20.png","weather_icon_21.png","weather_icon_22.png","weather_icon_23.png","weather_icon_24.png","weather_icon_25.png","weather_icon_26.png","weather_icon_27.png","weather_icon_28.png","weather_icon_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 159,
              y: 228,
              w: 167,
              h: 31,
              text_size: 24,
              char_space: 0,
              line_space: 0,
              color: 0xFF000000,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.NONE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 224,
              month_startY: 186,
              month_sc_array: ["d0053.png","d0054.png","d0055.png","d0056.png","d0057.png","d0058.png","d0059.png","d0060.png","d0061.png","d0062.png","d0063.png","d0064.png"],
              month_tc_array: ["d0053.png","d0054.png","d0055.png","d0056.png","d0057.png","d0058.png","d0059.png","d0060.png","d0061.png","d0062.png","d0063.png","d0064.png"],
              month_en_array: ["d0053.png","d0054.png","d0055.png","d0056.png","d0057.png","d0058.png","d0059.png","d0060.png","d0061.png","d0062.png","d0063.png","d0064.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 344,
              day_startY: 132,
              day_sc_array: ["p0.png","p1.png","p2.png","p3.png","p4.png","p5.png","p6.png","p7.png","p8.png","p9.png"],
              day_tc_array: ["p0.png","p1.png","p2.png","p3.png","p4.png","p5.png","p6.png","p7.png","p8.png","p9.png"],
              day_en_array: ["p0.png","p1.png","p2.png","p3.png","p4.png","p5.png","p6.png","p7.png","p8.png","p9.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 286,
              y: 387,
              image_array: ["0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png","0023.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 304,
              y: 356,
              font_array: ["WF0_Frame0047.png","WF0_Frame0048.png","WF0_Frame0049.png","WF0_Frame0050.png","WF0_Frame0051.png","WF0_Frame0052.png","WF0_Frame0053.png","WF0_Frame0054.png","WF0_Frame0055.png","WF0_Frame0056.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'perc.png',
              unit_tc: 'perc.png',
              unit_en: 'perc.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: -15,
              am_y: 16,
              am_sc_path: 'wfs_am_9f6ace29_ffd9_42b0_9456_0089028c4694.png',
              am_en_path: 'wfs_am_9f6ace29_ffd9_42b0_9456_0089028c4694.png',
              pm_x: -15,
              pm_y: 29,
              pm_sc_path: 'wfs_pm_f06d9694_516b_478c_b114_e139e24dd530.png',
              pm_en_path: 'wfs_pm_f06d9694_516b_478c_b114_e139e24dd530.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 105,
              hour_startY: 268,
              hour_array: ["wfs_0_caeed31e_9284_496d_8754_f5435249bc8c.png","wfs_1_9a5a428a_355d_476f_8f78_2c5ac1b388aa.png","wfs_2_9924e7b2_8357_4edc_b178_eb5890a86a65.png","wfs_3_cdb47a35_fa54_4293_b707_ff7e3b8d6cf7.png","wfs_4_75bc2677_7c2c_4727_94b5_582ed975d537.png","wfs_5_e5f67c04_229a_4c16_be71_592983b58205.png","wfs_6_77ccba1e_8e9a_4a70_8463_bd2401c4eec9.png","wfs_7_cbe63b6d_5c1d_4f57_b4cb_ac2119acfadb.png","wfs_8_cc9df689_9c4f_4552_890e_8873bee0f4d5.png","wfs_9_fe1b0831_5367_47b6_a598_fddb4ae6b056.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 239,
              minute_startY: 268,
              minute_array: ["wfs_0_caeed31e_9284_496d_8754_f5435249bc8c.png","wfs_1_9a5a428a_355d_476f_8f78_2c5ac1b388aa.png","wfs_2_9924e7b2_8357_4edc_b178_eb5890a86a65.png","wfs_3_cdb47a35_fa54_4293_b707_ff7e3b8d6cf7.png","wfs_4_75bc2677_7c2c_4727_94b5_582ed975d537.png","wfs_5_e5f67c04_229a_4c16_be71_592983b58205.png","wfs_6_77ccba1e_8e9a_4a70_8463_bd2401c4eec9.png","wfs_7_cbe63b6d_5c1d_4f57_b4cb_ac2119acfadb.png","wfs_8_cc9df689_9c4f_4552_890e_8873bee0f4d5.png","wfs_9_fe1b0831_5367_47b6_a598_fddb4ae6b056.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 348,
              second_startY: 270,
              second_array: ["p0.png","p1.png","p2.png","p3.png","p4.png","p5.png","p6.png","p7.png","p8.png","p9.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'aod.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 136,
              y: 171,
              week_en: ["m0043.png","m0044.png","m0045.png","m0046.png","m0047.png","m0048.png","m0049.png"],
              week_tc: ["m0043.png","m0044.png","m0045.png","m0046.png","m0047.png","m0048.png","m0049.png"],
              week_sc: ["m0043.png","m0044.png","m0045.png","m0046.png","m0047.png","m0048.png","m0049.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 212,
              y: 213,
              src: 'wfs_points_113d9760_a00c_46d1_864c_9403f38f898e.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 229,
              day_startY: 146,
              day_sc_array: ["p0.png","p1.png","p2.png","p3.png","p4.png","p5.png","p6.png","p7.png","p8.png","p9.png"],
              day_tc_array: ["p0.png","p1.png","p2.png","p3.png","p4.png","p5.png","p6.png","p7.png","p8.png","p9.png"],
              day_en_array: ["p0.png","p1.png","p2.png","p3.png","p4.png","p5.png","p6.png","p7.png","p8.png","p9.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 222,
              y: 317,
              font_array: ["WF0_Frame0047.png","WF0_Frame0048.png","WF0_Frame0049.png","WF0_Frame0050.png","WF0_Frame0051.png","WF0_Frame0052.png","WF0_Frame0053.png","WF0_Frame0054.png","WF0_Frame0055.png","WF0_Frame0056.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'perc.png',
              unit_tc: 'perc.png',
              unit_en: 'perc.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 188,
              y: 298,
              src: '0150.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: -18,
              am_y: -19,
              am_sc_path: 'wfs_am_9f6ace29_ffd9_42b0_9456_0089028c4694.png',
              am_en_path: 'wfs_am_9f6ace29_ffd9_42b0_9456_0089028c4694.png',
              pm_x: -18,
              pm_y: -37,
              pm_sc_path: 'wfs_pm_f06d9694_516b_478c_b114_e139e24dd530.png',
              pm_en_path: 'wfs_pm_f06d9694_516b_478c_b114_e139e24dd530.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 105,
              hour_startY: 208,
              hour_array: ["wfs_0_caeed31e_9284_496d_8754_f5435249bc8c.png","wfs_1_9a5a428a_355d_476f_8f78_2c5ac1b388aa.png","wfs_2_9924e7b2_8357_4edc_b178_eb5890a86a65.png","wfs_3_cdb47a35_fa54_4293_b707_ff7e3b8d6cf7.png","wfs_4_75bc2677_7c2c_4727_94b5_582ed975d537.png","wfs_5_e5f67c04_229a_4c16_be71_592983b58205.png","wfs_6_77ccba1e_8e9a_4a70_8463_bd2401c4eec9.png","wfs_7_cbe63b6d_5c1d_4f57_b4cb_ac2119acfadb.png","wfs_8_cc9df689_9c4f_4552_890e_8873bee0f4d5.png","wfs_9_fe1b0831_5367_47b6_a598_fddb4ae6b056.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 239,
              minute_startY: 208,
              minute_array: ["wfs_0_caeed31e_9284_496d_8754_f5435249bc8c.png","wfs_1_9a5a428a_355d_476f_8f78_2c5ac1b388aa.png","wfs_2_9924e7b2_8357_4edc_b178_eb5890a86a65.png","wfs_3_cdb47a35_fa54_4293_b707_ff7e3b8d6cf7.png","wfs_4_75bc2677_7c2c_4727_94b5_582ed975d537.png","wfs_5_e5f67c04_229a_4c16_be71_592983b58205.png","wfs_6_77ccba1e_8e9a_4a70_8463_bd2401c4eec9.png","wfs_7_cbe63b6d_5c1d_4f57_b4cb_ac2119acfadb.png","wfs_8_cc9df689_9c4f_4552_890e_8873bee0f4d5.png","wfs_9_fe1b0831_5367_47b6_a598_fddb4ae6b056.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 351,
              second_startY: 241,
              second_array: ["p0.png","p1.png","p2.png","p3.png","p4.png","p5.png","p6.png","p7.png","p8.png","p9.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 63,
              y: 324,
              w: 100,
              h: 100,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 162,
              y: 348,
              w: 100,
              h: 100,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 77,
              y: 206,
              w: 100,
              h: 100,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 147,
              y: 60,
              w: 100,
              h: 100,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 186,
              y: 3,
              w: 100,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'empty.png',
              normal_src: 'empty.png',
              click_func: (button_widget) => {
                click_color()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            function scale_call() {
              console.log('scale_call()');

              console.log('Weather city name');
              let weatherData = weatherSensor.getForecastWeather();
              normal_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_digital_clock_img_time = ''
        let normal_pai_icon_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_max_min_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_system_lock_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_distance_text_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_step_current_text_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_moon_image_progress_img_level = ''
        let idle_background_bg = ''
        let idle_digital_clock_img_time = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_day = ''
        let normal_step_jumpable_img_click = ''
        let normal_cal_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_battery_jumpable_img_click = ''
        let normal_moon_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let Button_1 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 15,
              hour_startY: 188,
              hour_array: ["A100_032.png","A100_033.png","A100_034.png","A100_035.png","A100_036.png","A100_037.png","A100_038.png","A100_039.png","A100_040.png","A100_041.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_unit_sc: 'A100_042.png',
              hour_unit_tc: 'A100_042.png',
              hour_unit_en: 'A100_042.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 194,
              minute_startY: 188,
              minute_array: ["A100_032.png","A100_033.png","A100_034.png","A100_035.png","A100_036.png","A100_037.png","A100_038.png","A100_039.png","A100_040.png","A100_041.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 362,
              second_startY: 178,
              second_array: ["A100_043.png","A100_044.png","A100_045.png","A100_046.png","A100_047.png","A100_048.png","A100_049.png","A100_050.png","A100_051.png","A100_052.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'mask.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 60,
              y: 345,
              image_array: ["w_1.png","w_2.png","w_3.png","w_4.png","w_5.png","w_6.png","w_7.png","w_8.png","w_9.png","w_10.png","w_11.png","w_12.png","w_13.png","w_14.png","w_15.png","w_16.png","w_17.png","w_18.png","w_19.png","w_20.png","w_21.png","w_22.png","w_23.png","w_24.png","w_25.png","w_26.png","w_27.png","w_28.png","w_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_max_min_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 71,
              y: 395,
              font_array: ["f_1.png","f_2.png","f_3.png","f_4.png","f_5.png","f_6.png","f_7.png","f_8.png","f_9.png","f_10.png"],
              padding: false,
              h_space: 0,
              negative_image: 'min.png',
              dot_image: 'sl.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_HIGH_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 110,
              y: 355,
              font_array: ["A100_005.png","A100_006.png","A100_007.png","A100_008.png","A100_009.png","A100_010.png","A100_011.png","A100_012.png","A100_013.png","A100_014.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'A100_018.png',
              unit_tc: 'A100_018.png',
              unit_en: 'A100_018.png',
              negative_image: 'A100_188.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 50,
              y: 309,
              image_array: ["A100_203.png","A100_204.png","A100_205.png","A100_206.png","A100_207.png","A100_208.png","A100_209.png","A100_210.png","A100_211.png","A100_212.png","A100_213.png","A100_214.png","A100_215.png","A100_216.png"],
              image_length: 14,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 435,
              y: 262,
              src: '140.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 360,
              y: 262,
              src: '138.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 397,
              y: 262,
              src: '141.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 285,
              y: 337,
              font_array: ["A100_005.png","A100_006.png","A100_007.png","A100_008.png","A100_009.png","A100_010.png","A100_011.png","A100_012.png","A100_013.png","A100_014.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'A100_023.png',
              unit_tc: 'A100_023.png',
              unit_en: 'A100_023.png',
              dot_image: 'A100_016.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 171,
              y: 40,
              font_array: ["A100_005.png","A100_006.png","A100_007.png","A100_008.png","A100_009.png","A100_010.png","A100_011.png","A100_012.png","A100_013.png","A100_014.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'A100_026.png',
              unit_tc: 'A100_026.png',
              unit_en: 'A100_026.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 237,
              y: 418,
              font_array: ["A100_005.png","A100_006.png","A100_007.png","A100_008.png","A100_009.png","A100_010.png","A100_011.png","A100_012.png","A100_013.png","A100_014.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'A100_024.png',
              unit_tc: 'A100_024.png',
              unit_en: 'A100_024.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 96,
              y: 120,
              font_array: ["A100_005.png","A100_006.png","A100_007.png","A100_008.png","A100_009.png","A100_010.png","A100_011.png","A100_012.png","A100_013.png","A100_014.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'A100_025.png',
              unit_tc: 'A100_025.png',
              unit_en: 'A100_025.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 291,
              y: 120,
              week_en: ["A100_135.png","A100_136.png","A100_137.png","A100_138.png","A100_139.png","A100_140.png","A100_141.png"],
              week_tc: ["A100_135.png","A100_136.png","A100_137.png","A100_138.png","A100_139.png","A100_140.png","A100_141.png"],
              week_sc: ["A100_135.png","A100_136.png","A100_137.png","A100_138.png","A100_139.png","A100_140.png","A100_141.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 390,
              month_startY: 120,
              month_sc_array: ["A100_142.png","A100_143.png","A100_144.png","A100_145.png","A100_146.png","A100_147.png","A100_148.png","A100_149.png","A100_150.png","A100_151.png","A100_152.png","A100_153.png"],
              month_tc_array: ["A100_142.png","A100_143.png","A100_144.png","A100_145.png","A100_146.png","A100_147.png","A100_148.png","A100_149.png","A100_150.png","A100_151.png","A100_152.png","A100_153.png"],
              month_en_array: ["A100_142.png","A100_143.png","A100_144.png","A100_145.png","A100_146.png","A100_147.png","A100_148.png","A100_149.png","A100_150.png","A100_151.png","A100_152.png","A100_153.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 352,
              day_startY: 120,
              day_sc_array: ["A100_172.png","A100_173.png","A100_174.png","A100_175.png","A100_176.png","A100_177.png","A100_178.png","A100_179.png","A100_180.png","A100_181.png"],
              day_tc_array: ["A100_172.png","A100_173.png","A100_174.png","A100_175.png","A100_176.png","A100_177.png","A100_178.png","A100_179.png","A100_180.png","A100_181.png"],
              day_en_array: ["A100_172.png","A100_173.png","A100_174.png","A100_175.png","A100_176.png","A100_177.png","A100_178.png","A100_179.png","A100_180.png","A100_181.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 308,
              y: 35,
              image_array: ["m56.png","m57.png","m58.png","m59.png","m60.png","m61.png","m62.png","m63.png","m64.png","m65.png","m66.png","m67.png","m68.png","m69.png","m70.png","m71.png","m72.png","m73.png","m74.png","m75.png","m76.png","m77.png","m78.png","m79.png","m80.png","m81.png","m82.png","m83.png","m84.png","m85.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 84,
              hour_startY: 195,
              hour_array: ["A100_190.png","A100_191.png","A100_192.png","A100_193.png","A100_194.png","A100_195.png","A100_196.png","A100_197.png","A100_198.png","A100_199.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_unit_sc: 'A100_201.png',
              hour_unit_tc: 'A100_201.png',
              hour_unit_en: 'A100_201.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 194,
              minute_startY: 188,
              minute_array: ["A100_190.png","A100_191.png","A100_192.png","A100_193.png","A100_194.png","A100_195.png","A100_196.png","A100_197.png","A100_198.png","A100_199.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 1,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 227,
              y: 115,
              src: '138.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 227,
              y: 350,
              src: '141.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 162,
              y: 50,
              week_en: ["A100_135.png","A100_136.png","A100_137.png","A100_138.png","A100_139.png","A100_140.png","A100_141.png"],
              week_tc: ["A100_135.png","A100_136.png","A100_137.png","A100_138.png","A100_139.png","A100_140.png","A100_141.png"],
              week_sc: ["A100_135.png","A100_136.png","A100_137.png","A100_138.png","A100_139.png","A100_140.png","A100_141.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 272,
              month_startY: 50,
              month_sc_array: ["A100_142.png","A100_143.png","A100_144.png","A100_145.png","A100_146.png","A100_147.png","A100_148.png","A100_149.png","A100_150.png","A100_151.png","A100_152.png","A100_153.png"],
              month_tc_array: ["A100_142.png","A100_143.png","A100_144.png","A100_145.png","A100_146.png","A100_147.png","A100_148.png","A100_149.png","A100_150.png","A100_151.png","A100_152.png","A100_153.png"],
              month_en_array: ["A100_142.png","A100_143.png","A100_144.png","A100_145.png","A100_146.png","A100_147.png","A100_148.png","A100_149.png","A100_150.png","A100_151.png","A100_152.png","A100_153.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 227,
              day_startY: 50,
              day_sc_array: ["A100_172.png","A100_173.png","A100_174.png","A100_175.png","A100_176.png","A100_177.png","A100_178.png","A100_179.png","A100_180.png","A100_181.png"],
              day_tc_array: ["A100_172.png","A100_173.png","A100_174.png","A100_175.png","A100_176.png","A100_177.png","A100_178.png","A100_179.png","A100_180.png","A100_181.png"],
              day_en_array: ["A100_172.png","A100_173.png","A100_174.png","A100_175.png","A100_176.png","A100_177.png","A100_178.png","A100_179.png","A100_180.png","A100_181.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 120,
              y: 109,
              w: 100,
              h: 50,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_cal_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 255,
              y: 345,
              w: 100,
              h: 100,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 105,
              y: 30,
              w: 100,
              h: 50,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 65,
              y: 296,
              w: 100,
              h: 40,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 315,
              y: 45,
              w: 60,
              h: 60,
              type: hmUI.data_type.MOON_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 80,
              y: 345,
              w: 80,
              h: 80,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 220,
              y: 200,
              w: 100,
              h: 75,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 370,
              y: 170,
              w: 70,
              h: 70,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 50,
              y: 200,
              w: 100,
              h: 75,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 315,
              y: 115,
              w: 100,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_battery_text_text_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_distance_text_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_digital_clock_img_time = ''
        let normal_step_current_text_img = ''
        let idle_background_bg_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_digital_clock_img_time = ''
        let idle_analog_clock_time_pointer_second = ''
        let normal_heart_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'FOND001.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 434,
              y: 230,
              font_array: ["UM-00.png","UM-01.png","UM-02.png","UM-03.png","UM-04.png","UM-05.png","UM-06.png","UM-07.png","UM-08.png","UM-09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'UM-11.png',
              unit_tc: 'UM-11.png',
              unit_en: 'UM-11.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 390,
              y: 163,
              src: 'bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 386,
              y: 115,
              src: 'ALARME.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 61,
              y: 196,
              font_array: ["NUM-00.png","NUM-01.png","NUM-02.png","NUM-03.png","NUM-04.png","NUM-05.png","NUM-06.png","NUM-07.png","NUM-08.png","NUM-09.png"],
              padding: false,
              h_space: 0,
              angle: -90,
              dot_image: 'NUM-10.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 381,
              y: 240,
              font_array: ["UM-00.png","UM-01.png","UM-02.png","UM-03.png","UM-04.png","UM-05.png","UM-06.png","UM-07.png","UM-08.png","UM-09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 388,
              y: 300,
              font_array: ["UM-00.png","UM-01.png","UM-02.png","UM-03.png","UM-04.png","UM-05.png","UM-06.png","UM-07.png","UM-08.png","UM-09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 54,
              y: 313,
              image_array: ["w00.png","w01.png","w02.png","w03.png","w04.png","w05.png","w06.png","w07.png","w08.png","w09.png","w10.png","w11.png","w12.png","w13.png","w14.png","w15.png","w16.png","w17.png","w18.png","w19.png","w20.png","w21.png","w22.png","w23.png","w24.png","w25.png","w26.png","w27.png","w28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 52,
              y: 294,
              font_array: ["UM-00.png","UM-01.png","UM-02.png","UM-03.png","UM-04.png","UM-05.png","UM-06.png","UM-07.png","UM-08.png","UM-09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'UM-12.png',
              unit_tc: 'UM-12.png',
              unit_en: 'UM-12.png',
              negative_image: 'UM-13.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 126,
              y: 47,
              week_en: ["SEM-01.png","SEM-02.png","SEM-03.png","SEM-04.png","SEM-05.png","SEM-06.png","SEM-07.png"],
              week_tc: ["SEM-01.png","SEM-02.png","SEM-03.png","SEM-04.png","SEM-05.png","SEM-06.png","SEM-07.png"],
              week_sc: ["SEM-01.png","SEM-02.png","SEM-03.png","SEM-04.png","SEM-05.png","SEM-06.png","SEM-07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 246,
              month_startY: 400,
              month_sc_array: ["NM-00.png","NM-01.png","NM-02.png","NM-03.png","NM-04.png","NM-05.png","NM-06.png","NM-07.png","NM-08.png","NM-09.png"],
              month_tc_array: ["NM-00.png","NM-01.png","NM-02.png","NM-03.png","NM-04.png","NM-05.png","NM-06.png","NM-07.png","NM-08.png","NM-09.png"],
              month_en_array: ["NM-00.png","NM-01.png","NM-02.png","NM-03.png","NM-04.png","NM-05.png","NM-06.png","NM-07.png","NM-08.png","NM-09.png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 182,
              day_startY: 400,
              day_sc_array: ["NM-00.png","NM-01.png","NM-02.png","NM-03.png","NM-04.png","NM-05.png","NM-06.png","NM-07.png","NM-08.png","NM-09.png"],
              day_tc_array: ["NM-00.png","NM-01.png","NM-02.png","NM-03.png","NM-04.png","NM-05.png","NM-06.png","NM-07.png","NM-08.png","NM-09.png"],
              day_en_array: ["NM-00.png","NM-01.png","NM-02.png","NM-03.png","NM-04.png","NM-05.png","NM-06.png","NM-07.png","NM-08.png","NM-09.png"],
              day_zero: 1,
              day_space: 0,
              day_unit_sc: 'NM-10.png',
              day_unit_tc: 'NM-10.png',
              day_unit_en: 'NM-10.png',
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'sec.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: -5,
              second_posY: 160,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 103,
              hour_startY: 99,
              hour_array: ["H-00.png","H-01.png","H-02.png","H-03.png","H-04.png","H-05.png","H-06.png","H-07.png","H-08.png","H-09.png"],
              hour_zero: 1,
              hour_space: -2,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 102,
              minute_startY: 222,
              minute_array: ["H-00.png","H-01.png","H-02.png","H-03.png","H-04.png","H-05.png","H-06.png","H-07.png","H-08.png","H-09.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 312,
              second_startY: 348,
              second_array: ["NM-00.png","NM-01.png","NM-02.png","NM-03.png","NM-04.png","NM-05.png","NM-06.png","NM-07.png","NM-08.png","NM-09.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 138,
              y: 355,
              font_array: ["NM-00.png","NM-01.png","NM-02.png","NM-03.png","NM-04.png","NM-05.png","NM-06.png","NM-07.png","NM-08.png","NM-09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'AOD.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 390,
              y: 163,
              src: 'bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 386,
              y: 115,
              src: 'ALARME.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 102,
              hour_startY: 99,
              hour_array: ["H-00.png","H-01.png","H-02.png","H-03.png","H-04.png","H-05.png","H-06.png","H-07.png","H-08.png","H-09.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 100,
              minute_startY: 221,
              minute_array: ["H-00.png","H-01.png","H-02.png","H-03.png","H-04.png","H-05.png","H-06.png","H-07.png","H-08.png","H-09.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'sec.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: -3,
              second_posY: 160,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 9,
              // disconneсnt_toast_text: BT OFF,
              // conneсnt_vibrate_type: 9,
              // conneсnt_toast_text: BT ON,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              console.log('checkConnection()');
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  hmUI.showToast({text: "BT OFF"});
                  vibro(9);
                }
                if(status) {
                  hmUI.showToast({text: "BT ON"});
                  vibro(9);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              if (scene != 1) timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function
            console.log('Watch_Face.Shortcuts');

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 379,
              y: 299,
              w: 50,
              h: 50,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 380,
              y: 109,
              w: 50,
              h: 50,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                checkConnection();
                stopVibro();

              }),
              pause_call: (function () {
                console.log('pause_call()');
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
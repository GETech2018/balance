﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_image_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_TextRotate = new Array(4);
        let normal_temperature_current_TextRotate_ASCIIARRAY = new Array(10);
        let normal_temperature_current_TextRotate_img_width = 36;
        let normal_temperature_current_TextRotate_unit = null;
        let normal_temperature_current_TextRotate_unit_width = 14;
        let normal_temperature_current_TextRotate_dot_width = 14;
        let normal_temperature_current_TextRotate_error_img_width = 14;
        let normal_battery_TextRotate = new Array(3);
        let normal_battery_TextRotate_ASCIIARRAY = new Array(10);
        let normal_battery_TextRotate_img_width = 36;
        let normal_battery_TextRotate_unit = null;
        let normal_battery_TextRotate_unit_width = 32;
        let normal_step_icon_img = ''
        let normal_step_current_text_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_digital_clock_img_time = ''
        let normal_second_TextRotate = new Array(2);
        let normal_second_TextRotate_ASCIIARRAY = new Array(10);
        let normal_second_TextRotate_img_width = 39;
        let normal_timerTextUpdate = undefined;
        let idle_background_bg_img = ''
        let idle_image_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_temperature_current_TextRotate = new Array(4);
        let idle_temperature_current_TextRotate_ASCIIARRAY = new Array(10);
        let idle_temperature_current_TextRotate_img_width = 36;
        let idle_temperature_current_TextRotate_unit = null;
        let idle_temperature_current_TextRotate_unit_width = 14;
        let idle_temperature_current_TextRotate_dot_width = 14;
        let idle_temperature_current_TextRotate_error_img_width = 14;
        let idle_battery_TextRotate = new Array(3);
        let idle_battery_TextRotate_ASCIIARRAY = new Array(10);
        let idle_battery_TextRotate_img_width = 36;
        let idle_battery_TextRotate_unit = null;
        let idle_battery_TextRotate_unit_width = 32;
        let idle_step_icon_img = ''
        let idle_step_current_text_img = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_week_img = ''
        let idle_digital_clock_img_time = ''
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'sfondo.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 79,
              y: 70,
              src: 'momo it (1).png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 118,
              y: 362,
              image_array: ["w01.png","w02.png","w03.png","w04.png","w05.png","w06.png","w07.png","w08.png","w09.png","w10.png","w11.png","w12.png","w13.png","w14.png","w15.png","w16.png","w17.png","w18.png","w19.png","w20.png","w21.png","w22.png","w23.png","w24.png","w25.png","w26.png","w27.png","w28.png","w29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_temperature_current_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 234,
              // y: 409,
              // font_array: ["aq0.png","aq1.png","aq2.png","aq3.png","aq4.png","aq5.png","aq6.png","aq7.png","aq8.png","aq9.png"],
              // zero: false,
              // unit_in_alignment: true,
              // h_space: 0,
              // angle: -45,
              // unit_en: 'gradi.png',
              // negative_image: 'meno.png',
              // invalid_image: 'meno.png',
              // dot_image: 'meno.png',
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.WEATHER_CURRENT,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_temperature_current_TextRotate_ASCIIARRAY[0] = 'aq0.png';  // set of images with numbers
            normal_temperature_current_TextRotate_ASCIIARRAY[1] = 'aq1.png';  // set of images with numbers
            normal_temperature_current_TextRotate_ASCIIARRAY[2] = 'aq2.png';  // set of images with numbers
            normal_temperature_current_TextRotate_ASCIIARRAY[3] = 'aq3.png';  // set of images with numbers
            normal_temperature_current_TextRotate_ASCIIARRAY[4] = 'aq4.png';  // set of images with numbers
            normal_temperature_current_TextRotate_ASCIIARRAY[5] = 'aq5.png';  // set of images with numbers
            normal_temperature_current_TextRotate_ASCIIARRAY[6] = 'aq6.png';  // set of images with numbers
            normal_temperature_current_TextRotate_ASCIIARRAY[7] = 'aq7.png';  // set of images with numbers
            normal_temperature_current_TextRotate_ASCIIARRAY[8] = 'aq8.png';  // set of images with numbers
            normal_temperature_current_TextRotate_ASCIIARRAY[9] = 'aq9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 4; i++) {
              normal_temperature_current_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 454,
                h: 454,
                center_x: 234,
                center_y: 409,
                pos_x: 234,
                pos_y: 409,
                angle: -45,
                src: 'aq0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_temperature_current_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_temperature_current_TextRotate_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              center_x: 234,
              center_y: 409,
              pos_x: 234,
              pos_y: 409,
              angle: -45,
              src: 'gradi.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_temperature_current_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block
            const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

            // normal_battery_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 231,
              // y: 5,
              // font_array: ["aq0.png","aq1.png","aq2.png","aq3.png","aq4.png","aq5.png","aq6.png","aq7.png","aq8.png","aq9.png"],
              // zero: false,
              // unit_in_alignment: true,
              // h_space: 8,
              // angle: 45,
              // unit_en: 'perc.png',
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_battery_TextRotate_ASCIIARRAY[0] = 'aq0.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[1] = 'aq1.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[2] = 'aq2.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[3] = 'aq3.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[4] = 'aq4.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[5] = 'aq5.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[6] = 'aq6.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[7] = 'aq7.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[8] = 'aq8.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[9] = 'aq9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 3; i++) {
              normal_battery_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 454,
                h: 454,
                center_x: 231,
                center_y: 5,
                pos_x: 231,
                pos_y: 5,
                angle: 45,
                src: 'aq0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_battery_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_battery_TextRotate_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              center_x: 231,
              center_y: 5,
              pos_x: 231,
              pos_y: 5,
              angle: 45,
              src: 'perc.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_battery_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 50,
              y: 291,
              src: 'passi 2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 198,
              y: 300,
              font_array: ["aq0.png","aq1.png","aq2.png","aq3.png","aq4.png","aq5.png","aq6.png","aq7.png","aq8.png","aq9.png"],
              padding: true,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 271,
              month_startY: 131,
              month_sc_array: ["M01.png","M02.png","M03.png","M04.png","M05.png","M06.png","M07.png","M08.png","M09.png","M10.png","M11.png","M12.png"],
              month_tc_array: ["M01.png","M02.png","M03.png","M04.png","M05.png","M06.png","M07.png","M08.png","M09.png","M10.png","M11.png","M12.png"],
              month_en_array: ["M01.png","M02.png","M03.png","M04.png","M05.png","M06.png","M07.png","M08.png","M09.png","M10.png","M11.png","M12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 169,
              day_startY: 132,
              day_sc_array: ["aq0.png","aq1.png","aq2.png","aq3.png","aq4.png","aq5.png","aq6.png","aq7.png","aq8.png","aq9.png"],
              day_tc_array: ["aq0.png","aq1.png","aq2.png","aq3.png","aq4.png","aq5.png","aq6.png","aq7.png","aq8.png","aq9.png"],
              day_en_array: ["aq0.png","aq1.png","aq2.png","aq3.png","aq4.png","aq5.png","aq6.png","aq7.png","aq8.png","aq9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 52,
              y: 131,
              week_en: ["G1.png","G2.png","G3.png","G4.png","G5.png","G6.png","G7.png"],
              week_tc: ["G1.png","G2.png","G3.png","G4.png","G5.png","G6.png","G7.png"],
              week_sc: ["G1.png","G2.png","G3.png","G4.png","G5.png","G6.png","G7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 44,
              hour_startY: 189,
              hour_array: ["b0.png","b1.png","b2.png","b3.png","b4.png","b5.png","b6.png","b7.png","b8.png","b9.png"],
              hour_zero: 1,
              hour_space: 10,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 273,
              minute_startY: 189,
              minute_array: ["b0.png","b1.png","b2.png","b3.png","b4.png","b5.png","b6.png","b7.png","b8.png","b9.png"],
              minute_zero: 1,
              minute_space: 10,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_second_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 266,
              // y: 192,
              // font_array: ["bb0.png","bb1.png","bb2.png","bb3.png","bb4.png","bb5.png","bb6.png","bb7.png","bb8.png","bb9.png"],
              // zero: true,
              // unit_in_alignment: true,
              // h_space: 12,
              // angle: 90,
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.SECOND,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_second_TextRotate_ASCIIARRAY[0] = 'bb0.png';  // set of images with numbers
            normal_second_TextRotate_ASCIIARRAY[1] = 'bb1.png';  // set of images with numbers
            normal_second_TextRotate_ASCIIARRAY[2] = 'bb2.png';  // set of images with numbers
            normal_second_TextRotate_ASCIIARRAY[3] = 'bb3.png';  // set of images with numbers
            normal_second_TextRotate_ASCIIARRAY[4] = 'bb4.png';  // set of images with numbers
            normal_second_TextRotate_ASCIIARRAY[5] = 'bb5.png';  // set of images with numbers
            normal_second_TextRotate_ASCIIARRAY[6] = 'bb6.png';  // set of images with numbers
            normal_second_TextRotate_ASCIIARRAY[7] = 'bb7.png';  // set of images with numbers
            normal_second_TextRotate_ASCIIARRAY[8] = 'bb8.png';  // set of images with numbers
            normal_second_TextRotate_ASCIIARRAY[9] = 'bb9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              normal_second_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 454,
                h: 454,
                center_x: 266,
                center_y: 192,
                pos_x: 266,
                pos_y: 192,
                angle: 90,
                src: 'bb0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_second_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            let screenType = hmSetting.getScreenType();

            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'sfondo.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 79,
              y: 70,
              src: 'momo it (1).png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 118,
              y: 362,
              image_array: ["w01.png","w02.png","w03.png","w04.png","w05.png","w06.png","w07.png","w08.png","w09.png","w10.png","w11.png","w12.png","w13.png","w14.png","w15.png","w16.png","w17.png","w18.png","w19.png","w20.png","w21.png","w22.png","w23.png","w24.png","w25.png","w26.png","w27.png","w28.png","w29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_temperature_current_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 234,
              // y: 409,
              // font_array: ["aq0.png","aq1.png","aq2.png","aq3.png","aq4.png","aq5.png","aq6.png","aq7.png","aq8.png","aq9.png"],
              // zero: false,
              // unit_in_alignment: true,
              // h_space: 0,
              // angle: -45,
              // unit_en: 'gradi.png',
              // negative_image: 'meno.png',
              // invalid_image: 'meno.png',
              // dot_image: 'meno.png',
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.WEATHER_CURRENT,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_temperature_current_TextRotate_ASCIIARRAY[0] = 'aq0.png';  // set of images with numbers
            idle_temperature_current_TextRotate_ASCIIARRAY[1] = 'aq1.png';  // set of images with numbers
            idle_temperature_current_TextRotate_ASCIIARRAY[2] = 'aq2.png';  // set of images with numbers
            idle_temperature_current_TextRotate_ASCIIARRAY[3] = 'aq3.png';  // set of images with numbers
            idle_temperature_current_TextRotate_ASCIIARRAY[4] = 'aq4.png';  // set of images with numbers
            idle_temperature_current_TextRotate_ASCIIARRAY[5] = 'aq5.png';  // set of images with numbers
            idle_temperature_current_TextRotate_ASCIIARRAY[6] = 'aq6.png';  // set of images with numbers
            idle_temperature_current_TextRotate_ASCIIARRAY[7] = 'aq7.png';  // set of images with numbers
            idle_temperature_current_TextRotate_ASCIIARRAY[8] = 'aq8.png';  // set of images with numbers
            idle_temperature_current_TextRotate_ASCIIARRAY[9] = 'aq9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 4; i++) {
              idle_temperature_current_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 454,
                h: 454,
                center_x: 234,
                center_y: 409,
                pos_x: 234,
                pos_y: 409,
                angle: -45,
                src: 'aq0.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_temperature_current_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            idle_temperature_current_TextRotate_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              center_x: 234,
              center_y: 409,
              pos_x: 234,
              pos_y: 409,
              angle: -45,
              src: 'gradi.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            idle_temperature_current_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block

            // idle_battery_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 231,
              // y: 5,
              // font_array: ["aq0.png","aq1.png","aq2.png","aq3.png","aq4.png","aq5.png","aq6.png","aq7.png","aq8.png","aq9.png"],
              // zero: false,
              // unit_in_alignment: true,
              // h_space: 8,
              // angle: 45,
              // unit_en: 'perc.png',
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_battery_TextRotate_ASCIIARRAY[0] = 'aq0.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[1] = 'aq1.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[2] = 'aq2.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[3] = 'aq3.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[4] = 'aq4.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[5] = 'aq5.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[6] = 'aq6.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[7] = 'aq7.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[8] = 'aq8.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[9] = 'aq9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 3; i++) {
              idle_battery_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 454,
                h: 454,
                center_x: 231,
                center_y: 5,
                pos_x: 231,
                pos_y: 5,
                angle: 45,
                src: 'aq0.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_battery_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            idle_battery_TextRotate_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              center_x: 231,
              center_y: 5,
              pos_x: 231,
              pos_y: 5,
              angle: 45,
              src: 'perc.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            idle_battery_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block

            idle_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 50,
              y: 291,
              src: 'passi 2.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 198,
              y: 300,
              font_array: ["aq0.png","aq1.png","aq2.png","aq3.png","aq4.png","aq5.png","aq6.png","aq7.png","aq8.png","aq9.png"],
              padding: true,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 271,
              month_startY: 131,
              month_sc_array: ["M01.png","M02.png","M03.png","M04.png","M05.png","M06.png","M07.png","M08.png","M09.png","M10.png","M11.png","M12.png"],
              month_tc_array: ["M01.png","M02.png","M03.png","M04.png","M05.png","M06.png","M07.png","M08.png","M09.png","M10.png","M11.png","M12.png"],
              month_en_array: ["M01.png","M02.png","M03.png","M04.png","M05.png","M06.png","M07.png","M08.png","M09.png","M10.png","M11.png","M12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 169,
              day_startY: 132,
              day_sc_array: ["aq0.png","aq1.png","aq2.png","aq3.png","aq4.png","aq5.png","aq6.png","aq7.png","aq8.png","aq9.png"],
              day_tc_array: ["aq0.png","aq1.png","aq2.png","aq3.png","aq4.png","aq5.png","aq6.png","aq7.png","aq8.png","aq9.png"],
              day_en_array: ["aq0.png","aq1.png","aq2.png","aq3.png","aq4.png","aq5.png","aq6.png","aq7.png","aq8.png","aq9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 52,
              y: 131,
              week_en: ["G1.png","G2.png","G3.png","G4.png","G5.png","G6.png","G7.png"],
              week_tc: ["G1.png","G2.png","G3.png","G4.png","G5.png","G6.png","G7.png"],
              week_sc: ["G1.png","G2.png","G3.png","G4.png","G5.png","G6.png","G7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 44,
              hour_startY: 189,
              hour_array: ["b0.png","b1.png","b2.png","b3.png","b4.png","b5.png","b6.png","b7.png","b8.png","b9.png"],
              hour_zero: 1,
              hour_space: 10,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 273,
              minute_startY: 189,
              minute_array: ["b0.png","b1.png","b2.png","b3.png","b4.png","b5.png","b6.png","b7.png","b8.png","b9.png"],
              minute_zero: 1,
              minute_space: 10,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 9,
              // conneсnt_vibrate_type: 25,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              console.log('checkConnection()');
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  vibro(9);
                }
                if(status) {
                  vibro(25);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              if (scene != 1) timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function

            //start of ignored block
            function text_update() {
              console.log('text_update()');
              let weatherData = weatherSensor.getForecastWeather();
              let temperature_current_temp = -100;
              if (weatherSensor.current != undefined && weatherSensor.current != 'undefined') {
                temperature_current_temp = weatherSensor.current;
              }; // end currentWeather;

              console.log('update text rotate temperature_current_currentWeather');
              let temperatureCurrent = undefined;
              let normal_temperature_current_rotate_string = undefined;
              if (temperature_current_temp > -100) {
                temperatureCurrent = 0;
                normal_temperature_current_rotate_string = String(temperature_current_temp)
              };

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 4; i++) {  // hide all symbols
                  normal_temperature_current_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_temperature_current_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
                if (temperatureCurrent != null && temperatureCurrent != undefined && isFinite(temperatureCurrent) && normal_temperature_current_rotate_string.length > 0 && normal_temperature_current_rotate_string.length <= 4) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of normal_temperature_current_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 4) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_temperature_current_TextRotate[index].setProperty(hmUI.prop.POS_X, 234 + img_offset);
                      normal_temperature_current_TextRotate[index].setProperty(hmUI.prop.SRC, normal_temperature_current_TextRotate_ASCIIARRAY[charCode]);
                      normal_temperature_current_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_temperature_current_TextRotate_img_width;
                      index++;
                    }  // end if digit
                    else { 
                      normal_temperature_current_TextRotate[index].setProperty(hmUI.prop.POS_X, 234 + img_offset);
                      normal_temperature_current_TextRotate[index].setProperty(hmUI.prop.SRC, 'meno.png');
                      normal_temperature_current_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_temperature_current_TextRotate_dot_width;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                  normal_temperature_current_TextRotate_unit.setProperty(hmUI.prop.POS_X, 234 + img_offset);
                  normal_temperature_current_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite
                else {
                  normal_temperature_current_TextRotate[0].setProperty(hmUI.prop.POS_X, 234);
                  normal_temperature_current_TextRotate[0].setProperty(hmUI.prop.SRC, 'meno.png');
                  normal_temperature_current_TextRotate[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

              console.log('update text rotate battery_BATTERY');
              let valueBattery = battery.current;
              let normal_battery_rotate_string = parseInt(valueBattery).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  normal_battery_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_battery_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
                if (valueBattery != null && valueBattery != undefined && isFinite(valueBattery) && normal_battery_rotate_string.length > 0 && normal_battery_rotate_string.length <= 3) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of normal_battery_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_battery_TextRotate[index].setProperty(hmUI.prop.POS_X, 231 + img_offset);
                      normal_battery_TextRotate[index].setProperty(hmUI.prop.SRC, normal_battery_TextRotate_ASCIIARRAY[charCode]);
                      normal_battery_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_battery_TextRotate_img_width + 8;
                      index++;
                    };  // end if digit
                  };  // end char of string
                  normal_battery_TextRotate_unit.setProperty(hmUI.prop.POS_X, 231 + img_offset);
                  normal_battery_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite

              };

              console.log('update text rotate second_TIME');
              let valueSecond = timeSensor.second;
              let normal_second_rotate_string = parseInt(valueSecond).toString();
              normal_second_rotate_string = normal_second_rotate_string.padStart(2, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_second_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueSecond != null && valueSecond != undefined && isFinite(valueSecond) && normal_second_rotate_string.length > 0 && normal_second_rotate_string.length <= 2) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of normal_second_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_second_TextRotate[index].setProperty(hmUI.prop.POS_X, 266 + img_offset);
                      normal_second_TextRotate[index].setProperty(hmUI.prop.SRC, normal_second_TextRotate_ASCIIARRAY[charCode]);
                      normal_second_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_second_TextRotate_img_width + 12;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate temperature_current_currentWeather');
              let idle_temperature_current_rotate_string = undefined;
              if (temperature_current_temp > -100) {
                temperatureCurrent = 0;
                idle_temperature_current_rotate_string = String(temperature_current_temp)
              };

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 4; i++) {  // hide all symbols
                  idle_temperature_current_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                idle_temperature_current_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
                if (temperatureCurrent != null && temperatureCurrent != undefined && isFinite(temperatureCurrent) && idle_temperature_current_rotate_string.length > 0 && idle_temperature_current_rotate_string.length <= 4) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of idle_temperature_current_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 4) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_temperature_current_TextRotate[index].setProperty(hmUI.prop.POS_X, 234 + img_offset);
                      idle_temperature_current_TextRotate[index].setProperty(hmUI.prop.SRC, idle_temperature_current_TextRotate_ASCIIARRAY[charCode]);
                      idle_temperature_current_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_temperature_current_TextRotate_img_width;
                      index++;
                    }  // end if digit
                    else { 
                      idle_temperature_current_TextRotate[index].setProperty(hmUI.prop.POS_X, 234 + img_offset);
                      idle_temperature_current_TextRotate[index].setProperty(hmUI.prop.SRC, 'meno.png');
                      idle_temperature_current_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_temperature_current_TextRotate_dot_width;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                  idle_temperature_current_TextRotate_unit.setProperty(hmUI.prop.POS_X, 234 + img_offset);
                  idle_temperature_current_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite
                else {
                  idle_temperature_current_TextRotate[0].setProperty(hmUI.prop.POS_X, 234);
                  idle_temperature_current_TextRotate[0].setProperty(hmUI.prop.SRC, 'meno.png');
                  idle_temperature_current_TextRotate[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

              console.log('update text rotate battery_BATTERY');
              let idle_battery_rotate_string = parseInt(valueBattery).toString();

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  idle_battery_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                idle_battery_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
                if (valueBattery != null && valueBattery != undefined && isFinite(valueBattery) && idle_battery_rotate_string.length > 0 && idle_battery_rotate_string.length <= 3) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of idle_battery_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_battery_TextRotate[index].setProperty(hmUI.prop.POS_X, 231 + img_offset);
                      idle_battery_TextRotate[index].setProperty(hmUI.prop.SRC, idle_battery_TextRotate_ASCIIARRAY[charCode]);
                      idle_battery_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_battery_TextRotate_img_width + 8;
                      index++;
                    };  // end if digit
                  };  // end char of string
                  idle_battery_TextRotate_unit.setProperty(hmUI.prop.POS_X, 231 + img_offset);
                  idle_battery_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite

              };

            };

            //end of ignored block
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                text_update();
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerTextUpdate) {
                    normal_timerTextUpdate = timer.createTimer(0, 1000, (function (option) {
                      text_update();
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                checkConnection();
                stopVibro();

              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerTextUpdate) {
                  timer.stopTimer(normal_timerTextUpdate);
                  normal_timerTextUpdate = undefined;
                }
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
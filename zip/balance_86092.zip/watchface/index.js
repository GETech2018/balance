﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

/////////////////////////////////////////////////////////////////////////////////////////////////
          
// Start color change
         let colornumber_main = 1
        let totalcolors_main = 6
        let namecolor_main = ''

        function click_Color() {
            if(colornumber_main>=totalcolors_main) {
            colornumber_main=1;
                }
            else {
                colornumber_main=colornumber_main+1;
            }

if ( colornumber_main == 1) { namecolor_main = "GOLD"}
if ( colornumber_main == 2) { namecolor_main = "PINKY"}
if ( colornumber_main == 3) { namecolor_main = "BLUE"}
if ( colornumber_main == 4) { namecolor_main = "RED"}
if ( colornumber_main == 5) { namecolor_main = "GREEN"}
if ( colornumber_main == 6) { namecolor_main = "GREYISH"}
hmUI.showToast({text: namecolor_main });

             //hmUI.showToast({text: "color " + parseInt(colornumber_main) });
             normal_background_bg_img.setProperty(hmUI.prop.SRC, "main" + parseInt(colornumber_main) + ".png");
                           
        }
        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_battery_text_text_img = ''
        let normal_date_img_date_year = ''
        let normal_date_img_date_month = ''
        let normal_date_month_separator_img = ''
        let normal_date_img_date_day = ''
        let normal_date_day_separator_img = ''
        let normal_date_img_date_week_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time_second = ''
        let normal_digital_clock_img_time_minute = ''
        let normal_digital_clock_img_time_hour = ''
        let normal_digital_clock_hour_separator_img = ''
        let idle_background_bg_img = ''
        let idle_city_name_text = ''
        let idle_step_current_text_img = ''
        let idle_step_current_separator_img = ''
        let idle_calorie_current_text_img = ''
        let idle_calorie_current_separator_img = ''
        let idle_heart_rate_icon_img = ''
        let idle_heart_rate_circle_scale_2 = ''
        let idle_heart_rate_text_text_img = ''
        let idle_heart_rate_text_separator_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_moon_image_progress_img_level = ''
        let idle_battery_text_text_img = ''
        let idle_sun_current_text_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_month = ''
        let idle_date_img_date_day = ''
        let idle_date_day_separator_img = ''
        let idle_distance_text_text_img = ''
        let idle_distance_text_separator_img = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''
        let idle_digital_clock_minute_separator_img = ''
        let normal_battery_jumpable_img_click = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let Button_1 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'main1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 238,
              y: 440,
              src: 'System_BT_OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 95,
              y: 263,
              src: 'System_alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 210,
              y: 400,
              font_array: ["Batt_Font_0.png","Batt_Font_1.png","Batt_Font_2.png","Batt_Font_3.png","Batt_Font_4.png","Batt_Font_5.png","Batt_Font_6.png","Batt_Font_7.png","Batt_Font_8.png","Batt_Font_9.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'Batt_unit.png',
              unit_tc: 'Batt_unit.png',
              unit_en: 'Batt_unit.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 275,
              year_startY: 85,
              year_sc_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              year_tc_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              year_en_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              year_zero: 0,
              year_space: 0,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 225,
              month_startY: 85,
              month_sc_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              month_tc_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              month_en_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_month_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 260,
              y: 85,
              src: 'Day_unit.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 175,
              day_startY: 85,
              day_sc_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              day_tc_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              day_en_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              day_zero: 1,
              day_space: 1,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_day_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 210,
              y: 85,
              src: 'Day_unit.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 200,
              y: 110,
              week_en: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              week_tc: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              week_sc: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 66,
              am_y: 264,
              am_sc_path: 'Clock_AM.png',
              am_en_path: 'Clock_AM.png',
              pm_x: 66,
              pm_y: 264,
              pm_sc_path: 'Clock_PM.png',
              pm_en_path: 'Clock_PM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_second = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              second_startX: 240,
              second_startY: 340,
              second_array: ["Time_S_0.png","Time_S_1.png","Time_S_2.png","Time_S_3.png","Time_S_4.png","Time_S_5.png","Time_S_6.png","Time_S_7.png","Time_S_8.png","Time_S_9.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 191,
              minute_startY: 287,
              minute_array: ["Time_0.png","Time_1.png","Time_2.png","Time_3.png","Time_4.png","Time_5.png","Time_6.png","Time_7.png","Time_8.png","Time_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 90,
              hour_startY: 287,
              hour_array: ["Time_0.png","Time_1.png","Time_2.png","Time_3.png","Time_4.png","Time_5.png","Time_6.png","Time_7.png","Time_8.png","Time_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.RIGHT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 176,
              y: 288,
              src: 'Time_dot.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'main5.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

            idle_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 231,
              y: 423,
              w: 175,
              h: 34,
              text_size: 27,
              char_space: 0,
              line_space: 0,
              color: 0xFF000000,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 244,
              y: 126,
              font_array: ["Act_0.png","Act_1.png","Act_2.png","Act_3.png","Act_4.png","Act_5.png","Act_6.png","Act_7.png","Act_8.png","Act_9.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 209,
              y: 121,
              src: 'icon_steps.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 267,
              y: 81,
              font_array: ["Act_0.png","Act_1.png","Act_2.png","Act_3.png","Act_4.png","Act_5.png","Act_6.png","Act_7.png","Act_8.png","Act_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 245,
              y: 81,
              src: 'icon_cal.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 28,
              y: 158,
              src: 'Heart_BG.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_circle_scale_2 = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 82,
              center_y: 212,
              start_angle: 0,
              end_angle: 360,
              radius: 51,
              line_width: 5,
              corner_flag: 3,
              type: hmUI.data_type.HEART,
              color: 0xFFFF0000,
              // mirror: False,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 41,
              y: 212,
              font_array: ["Heart_font_0.png","Heart_font_1.png","Heart_font_2.png","Heart_font_3.png","Heart_font_4.png","Heart_font_5.png","Heart_font_6.png","Heart_font_7.png","Heart_font_8.png","Heart_font_9.png"],
              padding: false,
              h_space: 0,
              invalid_image: 'Heart_font_0.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 63,
              y: 174,
              src: 'icon_heart.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 76,
              y: 340,
              src: 'System_BT_OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 176,
              y: 55,
              src: 'System_alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 113,
              y: 94,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 198,
              y: 274,
              font_array: ["Batt_Font_0.png","Batt_Font_1.png","Batt_Font_2.png","Batt_Font_3.png","Batt_Font_4.png","Batt_Font_5.png","Batt_Font_6.png","Batt_Font_7.png","Batt_Font_8.png","Batt_Font_9.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'Batt_unit.png',
              unit_tc: 'Batt_unit.png',
              unit_en: 'Batt_unit.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_sun_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 134,
              y: 436,
              font_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              padding: false,
              h_space: 1,
              dot_image: 'sun_moon_dot.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 154,
              y: 313,
              week_en: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              week_tc: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              week_sc: ["Week_1.png","Week_2.png","Week_3.png","Week_4.png","Week_5.png","Week_6.png","Week_7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 105,
              month_startY: 298,
              month_sc_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              month_tc_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              month_en_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 36,
              day_startY: 298,
              day_sc_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              day_tc_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              day_en_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              day_zero: 1,
              day_space: 1,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_day_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 80,
              y: 298,
              src: 'Day_unit.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 222,
              y: 169,
              font_array: ["Act_0.png","Act_1.png","Act_2.png","Act_3.png","Act_4.png","Act_5.png","Act_6.png","Act_7.png","Act_8.png","Act_9.png"],
              padding: false,
              h_space: 4,
              unit_sc: 'Dis_KM.png',
              unit_tc: 'Dis_KM.png',
              unit_en: 'Dis_KM.png',
              imperial_unit_sc: 'Dis_Mi.png',
              imperial_unit_tc: 'Dis_Mi.png',
              imperial_unit_en: 'Dis_Mi.png',
              dot_image: 'Dis_Dot.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_distance_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 169,
              y: 166,
              src: 'icon_Dis.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 49,
              am_y: 378,
              am_sc_path: 'Clock_AM.png',
              am_en_path: 'Clock_AM.png',
              pm_x: 49,
              pm_y: 378,
              pm_sc_path: 'Clock_PM.png',
              pm_en_path: 'Clock_PM.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 113,
              hour_startY: 345,
              hour_array: ["Time_0.png","Time_1.png","Time_2.png","Time_3.png","Time_4.png","Time_5.png","Time_6.png","Time_7.png","Time_8.png","Time_9.png"],
              hour_zero: 1,
              hour_space: 2,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 284,
              minute_startY: 345,
              minute_array: ["Time_0.png","Time_1.png","Time_2.png","Time_3.png","Time_4.png","Time_5.png","Time_6.png","Time_7.png","Time_8.png","Time_9.png"],
              minute_zero: 1,
              minute_space: 2,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 261,
              y: 343,
              src: 'Time_dot.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_minute_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 386,
              y: 283,
              src: 'aod_icon.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 155,
              y: 215,
              w: 160,
              h: 45,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 239,
              y: 338,
              w: 55,
              h: 35,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 191,
              y: 283,
              w: 82,
              h: 52,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 88,
              y: 283,
              w: 85,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 31,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'AlarmInfoScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 200,
              y: 395,
              w: 90,
              h: 25,
              text: '',
              color: 0xFFFF8C00,
              text_size: 31,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PowerSaveHintScreen', native: true });
              }, // end func
              longpress_func: (button_widget) => {
                hmApp.startApp({url: 'LowBatteryScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 175,
              y: 80,
              w: 160,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 31,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              longpress_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 50,
              y: 110,
              w: 75,
              h: 70,
              text: '',
              color: 0xFFFF8C00,
              text_size: 31,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                click_Color()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            function scale_call() {
              console.log('scale_call()');

              console.log('Weather city name');
              let weatherData = weatherSensor.getForecastWeather();
              let idle_cityNameStr = weatherData.cityName;
              idle_city_name_text.setProperty(hmUI.prop.TEXT, idle_cityNameStr);

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
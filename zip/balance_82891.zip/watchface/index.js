﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_sun_high_text_img = ''
        let normal_sun_high_separator_img = ''
        let normal_sun_low_text_img = ''
        let normal_sun_low_separator_img = ''
        let normal_battery_circle_scale = ''
        let normal_battery_TextRotate = new Array(3);
        let normal_battery_TextRotate_ASCIIARRAY = new Array(10);
        let normal_battery_TextRotate_img_width = 11;
        let normal_battery_TextRotate_unit = null;
        let normal_battery_TextRotate_unit_width = 11;
        let normal_moon_image_progress_img_level = ''
        let normal_heart_rate_circle_scale = ''
        let normal_heart_rate_TextRotate = new Array(3);
        let normal_heart_rate_TextRotate_ASCIIARRAY = new Array(10);
        let normal_heart_rate_TextRotate_img_width = 11;
        let normal_calorie_circle_scale = ''
        let normal_calorie_TextRotate = new Array(4);
        let normal_calorie_TextRotate_ASCIIARRAY = new Array(10);
        let normal_calorie_TextRotate_img_width = 11;
        let normal_step_circle_scale = ''
        let normal_step_TextRotate = new Array(5);
        let normal_step_TextRotate_ASCIIARRAY = new Array(10);
        let normal_step_TextRotate_img_width = 11;
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_analog_clock_pro_hour_pointer_img = ''
        let normal_analog_clock_pro_minute_pointer_img = ''
        let normal_timerUpdateSec = undefined;
        let normal_analog_clock_pro_second_pointer_img = ''
        let normal_timerUpdateSecSmooth = undefined;
        let lastTime = 0;
        let normal_digital_clock_img_time = ''
        let idle_background_bg_img = ''
        let idle_analog_clock_pro_hour_pointer_img = ''
        let idle_analog_clock_pro_minute_pointer_img = ''
        let idle_timerUpdateSec = undefined;
        let idle_analog_clock_pro_second_pointer_img = ''
        let idle_timerUpdateSecSmooth = undefined;
        let idle_battery_icon_img = ''
        let idle_battery_text_text_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_temperature_current_text_img = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_month = ''
        let idle_digital_clock_img_time = ''
        let normal_step_jumpable_img_click = ''
        let normal_cal_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_moon_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let timeSensor = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg0006.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 124,
              y: 261,
              font_array: ["f0.png","f1.png","f2.png","f3.png","f4.png","f5.png","f6.png","f7.png","f8.png","f9.png"],
              padding: false,
              h_space: 0,
              dot_image: 'maohao.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 108,
              y: 182,
              src: 'sunrise_no_data.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 304,
              y: 261,
              font_array: ["f0.png","f1.png","f2.png","f3.png","f4.png","f5.png","f6.png","f7.png","f8.png","f9.png"],
              padding: false,
              h_space: 0,
              dot_image: 'maohao.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 288,
              y: 182,
              src: 'sunset_no_data.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 240,
              // center_y: 240,
              // start_angle: 108,
              // end_angle: 162,
              // radius: 180,
              // line_width: 15,
              // line_cap: Rounded,
              // color: 0xFF1FBE23,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            let screenType = hmSetting.getScreenType();
            normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 240,
              center_y: 240,
              start_angle: 108,
              end_angle: 162,
              radius: 173,
              line_width: 15,
              corner_flag: 0,
              color: 0xFF1FBE23,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
              scale_call();
            });

            // normal_battery_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 275,
              // y: 400,
              // font_array: ["Act_0.png","Act_1.png","Act_2.png","Act_3.png","Act_4.png","Act_5.png","Act_6.png","Act_7.png","Act_8.png","Act_9.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 3,
              // angle: -5,
              // unit_en: 'P_Symbol.png',
              // align_h: hmUI.align.RIGHT,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_battery_TextRotate_ASCIIARRAY[0] = 'Act_0.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[1] = 'Act_1.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[2] = 'Act_2.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[3] = 'Act_3.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[4] = 'Act_4.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[5] = 'Act_5.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[6] = 'Act_6.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[7] = 'Act_7.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[8] = 'Act_8.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[9] = 'Act_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 3; i++) {
              normal_battery_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 275,
                center_y: 400,
                pos_x: 275,
                pos_y: 400,
                angle: -5,
                src: 'Act_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_battery_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_battery_TextRotate_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              center_x: 275,
              center_y: 400,
              pos_x: 275,
              pos_y: 400,
              angle: -5,
              src: 'P_Symbol.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_battery_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 204,
              y: 100,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_heart_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 240,
              // center_y: 240,
              // start_angle: 288,
              // end_angle: 342,
              // radius: 180,
              // line_width: 15,
              // line_cap: Rounded,
              // color: 0xFFFF0000,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_heart_rate_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 240,
              center_y: 240,
              start_angle: 288,
              end_angle: 342,
              radius: 173,
              line_width: 15,
              corner_flag: 0,
              color: 0xFFFF0000,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const heart_rate = hmSensor.createSensor(hmSensor.id.HEART);
            heart_rate.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
              scale_call();
            });

            // normal_heart_rate_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 190,
              // y: 65,
              // font_array: ["Act_0.png","Act_1.png","Act_2.png","Act_3.png","Act_4.png","Act_5.png","Act_6.png","Act_7.png","Act_8.png","Act_9.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 3,
              // angle: -5,
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_heart_rate_TextRotate_ASCIIARRAY[0] = 'Act_0.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[1] = 'Act_1.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[2] = 'Act_2.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[3] = 'Act_3.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[4] = 'Act_4.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[5] = 'Act_5.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[6] = 'Act_6.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[7] = 'Act_7.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[8] = 'Act_8.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[9] = 'Act_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 3; i++) {
              normal_heart_rate_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 190,
                center_y: 65,
                pos_x: 190,
                pos_y: 65,
                angle: -5,
                src: 'Act_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_heart_rate_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            // normal_cal_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 240,
              // center_y: 240,
              // start_angle: 18,
              // end_angle: 72,
              // radius: 180,
              // line_width: 15,
              // line_cap: Rounded,
              // color: 0xFFFF8C00,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_calorie_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 240,
              center_y: 240,
              start_angle: 18,
              end_angle: 72,
              radius: 173,
              line_width: 15,
              corner_flag: 0,
              color: 0xFFFF8C00,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const calorie = hmSensor.createSensor(hmSensor.id.CALORIE);
            calorie.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
              scale_call();
            });

            // normal_calorie_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 415,
              // y: 195,
              // font_array: ["Act_0.png","Act_1.png","Act_2.png","Act_3.png","Act_4.png","Act_5.png","Act_6.png","Act_7.png","Act_8.png","Act_9.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 3,
              // angle: 82,
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_calorie_TextRotate_ASCIIARRAY[0] = 'Act_0.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[1] = 'Act_1.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[2] = 'Act_2.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[3] = 'Act_3.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[4] = 'Act_4.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[5] = 'Act_5.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[6] = 'Act_6.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[7] = 'Act_7.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[8] = 'Act_8.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[9] = 'Act_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 4; i++) {
              normal_calorie_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 415,
                center_y: 195,
                pos_x: 415,
                pos_y: 195,
                angle: 82,
                src: 'Act_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_calorie_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            // normal_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 240,
              // center_y: 240,
              // start_angle: 198,
              // end_angle: 252,
              // radius: 180,
              // line_width: 15,
              // line_cap: Rounded,
              // color: 0xFF107BAF,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 240,
              center_y: 240,
              start_angle: 198,
              end_angle: 252,
              radius: 173,
              line_width: 15,
              corner_flag: 0,
              color: 0xFF107BAF,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
              scale_call();
            });

            // normal_step_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 82,
              // y: 287,
              // font_array: ["Act_0.png","Act_1.png","Act_2.png","Act_3.png","Act_4.png","Act_5.png","Act_6.png","Act_7.png","Act_8.png","Act_9.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 3,
              // angle: 82,
              // align_h: hmUI.align.RIGHT,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_step_TextRotate_ASCIIARRAY[0] = 'Act_0.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[1] = 'Act_1.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[2] = 'Act_2.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[3] = 'Act_3.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[4] = 'Act_4.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[5] = 'Act_5.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[6] = 'Act_6.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[7] = 'Act_7.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[8] = 'Act_8.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[9] = 'Act_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              normal_step_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 82,
                center_y: 287,
                pos_x: 82,
                pos_y: 287,
                angle: 82,
                src: 'Act_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_step_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 125,
              y: 140,
              week_en: ["20.png","21.png","22.png","23.png","24.png","25.png","26.png"],
              week_tc: ["20.png","21.png","22.png","23.png","24.png","25.png","26.png"],
              week_sc: ["20.png","21.png","22.png","23.png","24.png","25.png","26.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 285,
              day_startY: 142,
              day_sc_array: ["78.png","79.png","80.png","81.png","82.png","83.png","84.png","85.png","86.png","87.png"],
              day_tc_array: ["78.png","79.png","80.png","81.png","82.png","83.png","84.png","85.png","86.png","87.png"],
              day_en_array: ["78.png","79.png","80.png","81.png","82.png","83.png","84.png","85.png","86.png","87.png"],
              day_zero: 1,
              day_space: 2,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const deviceInfo = hmSetting.getDeviceInfo();
            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.MINUTEEND, function() {
              let updateHour = timeSensor.minute == 0;

              time_update(updateHour, true);
            });

            // normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'Hand_H1.png',
              // center_x: 240,
              // center_y: 240,
              // x: 26,
              // y: 223,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.hour,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 26,
              pos_y: 240 - 223,
              center_x: 240,
              center_y: 240,
              src: 'Hand_H1.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'Hand_M1.png',
              // center_x: 240,
              // center_y: 240,
              // x: 26,
              // y: 223,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.minute,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 26,
              pos_y: 240 - 223,
              center_x: 240,
              center_y: 240,
              src: 'Hand_M1.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'Hand_S1.png',
              // center_x: 240,
              // center_y: 240,
              // x: 26,
              // y: 223,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 26,
              pos_y: 240 - 223,
              center_x: 240,
              center_y: 240,
              src: 'Hand_S1.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            function startSecAnim(sec, animDuration) {
              const secAnim = {
                anim_steps: [{
                  anim_rate: 'linear',
                  anim_duration: animDuration,
                  anim_from: sec,
                  anim_to: sec + (360*(animDuration*6/1000))/360,
                  anim_key: 'angle',
                }],
                anim_fps: 15,
                anim_auto_start: 1,
                anim_repeat: 0,
                anim_auto_destroy: 1,
              }
              normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANIM, secAnim);
            }
            // normal_analog_clock_pro_smooth_second = hmUI.createWidget(hmUI.widget.SMOOTH_SECOND, {
              // type: 4,
              // fps: 15,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 201,
              hour_startY: 258,
              hour_array: ["informative_analog_digital_time_num_0.png","informative_analog_digital_time_num_1.png","informative_analog_digital_time_num_2.png","informative_analog_digital_time_num_3.png","informative_analog_digital_time_num_4.png","informative_analog_digital_time_num_5.png","informative_analog_digital_time_num_6.png","informative_analog_digital_time_num_7.png","informative_analog_digital_time_num_8.png","informative_analog_digital_time_num_9.png"],
              hour_zero: 1,
              hour_space: 2,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 201,
              minute_startY: 315,
              minute_array: ["informative_analog_digital_time_num_0.png","informative_analog_digital_time_num_1.png","informative_analog_digital_time_num_2.png","informative_analog_digital_time_num_3.png","informative_analog_digital_time_num_4.png","informative_analog_digital_time_num_5.png","informative_analog_digital_time_num_6.png","informative_analog_digital_time_num_7.png","informative_analog_digital_time_num_8.png","informative_analog_digital_time_num_9.png"],
              minute_zero: 1,
              minute_space: 2,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'AOD1.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'Hand_H1.png',
              // center_x: 240,
              // center_y: 240,
              // x: 26,
              // y: 223,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.hour,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });


            idle_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 26,
              pos_y: 240 - 223,
              center_x: 240,
              center_y: 240,
              src: 'Hand_H1.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'Hand_M1.png',
              // center_x: 240,
              // center_y: 240,
              // x: 26,
              // y: 223,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.minute,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });


            idle_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 26,
              pos_y: 240 - 223,
              center_x: 240,
              center_y: 240,
              src: 'Hand_M1.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'Hand_S1.png',
              // center_x: 240,
              // center_y: 240,
              // x: 26,
              // y: 223,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });


            idle_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 26,
              pos_y: 240 - 223,
              center_x: 240,
              center_y: 240,
              src: 'Hand_S1.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_analog_clock_pro_smooth_second = hmUI.createWidget(hmUI.widget.SMOOTH_SECOND, {
              // type: 2,
              // fps: 15,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });


            idle_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 210,
              y: 375,
              src: 'power.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 242,
              y: 381,
              font_array: ["f0.png","f1.png","f2.png","f3.png","f4.png","f5.png","f6.png","f7.png","f8.png","f9.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'P_Symbol.png',
              unit_tc: 'P_Symbol.png',
              unit_en: 'P_Symbol.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 310,
              y: 222,
              image_array: ["weather00.png","weather01.png","weather02.png","weather03.png","weather04.png","weather05.png","weather06.png","weather07.png","weather08.png","weather09.png","weather10.png","weather11.png","weather12.png","weather13.png","weather14.png","weather15.png","weather16.png","weather17.png","weather18.png","weather19.png","weather20.png","weather21.png","weather22.png","weather23.png","weather24.png","weather25.png","weather26.png","weather27.png","weather28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 360,
              y: 230,
              font_array: ["f0.png","f1.png","f2.png","f3.png","f4.png","f5.png","f6.png","f7.png","f8.png","f9.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'temp.png',
              unit_tc: 'temp.png',
              unit_en: 'temp.png',
              imperial_unit_sc: 'temp.png',
              imperial_unit_tc: 'temp.png',
              imperial_unit_en: 'temp.png',
              negative_image: 'fuhao.png',
              invalid_image: 'none.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            const temperatureUnit = hmSetting.getTemperatureUnit();
            //start of ignored block
            if (temperatureUnit == 1) {
              idle_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
                x: 360,
                y: 230,
                font_array: ["f0.png","f1.png","f2.png","f3.png","f4.png","f5.png","f6.png","f7.png","f8.png","f9.png"],
                padding: false,
                h_space: 2,
                unit_sc: 'temp.png',
                unit_tc: 'temp.png',
                unit_en: 'temp.png',
                imperial_unit_sc: 'temp.png',
                imperial_unit_tc: 'temp.png',
                imperial_unit_en: 'temp.png',
                negative_image: 'fuhao.png',
                invalid_image: 'none.png',
                align_h: hmUI.align.LEFT,
                type: hmUI.data_type.WEATHER_CURRENT,
                show_level: hmUI.show_level.ONLY_AOD,
              });
            };
            //end of ignored block

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 248,
              day_startY: 80,
              day_sc_array: ["f0.png","f1.png","f2.png","f3.png","f4.png","f5.png","f6.png","f7.png","f8.png","f9.png"],
              day_tc_array: ["f0.png","f1.png","f2.png","f3.png","f4.png","f5.png","f6.png","f7.png","f8.png","f9.png"],
              day_en_array: ["f0.png","f1.png","f2.png","f3.png","f4.png","f5.png","f6.png","f7.png","f8.png","f9.png"],
              day_zero: 1,
              day_space: 2,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 207,
              month_startY: 80,
              month_sc_array: ["f0.png","f1.png","f2.png","f3.png","f4.png","f5.png","f6.png","f7.png","f8.png","f9.png"],
              month_tc_array: ["f0.png","f1.png","f2.png","f3.png","f4.png","f5.png","f6.png","f7.png","f8.png","f9.png"],
              month_en_array: ["f0.png","f1.png","f2.png","f3.png","f4.png","f5.png","f6.png","f7.png","f8.png","f9.png"],
              month_zero: 1,
              month_space: 2,
              month_unit_sc: 'line.png',
              month_unit_tc: 'line.png',
              month_unit_en: 'line.png',
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 100,
              hour_startY: 175,
              hour_array: ["informative_analog_digital_time_num_0.png","informative_analog_digital_time_num_1.png","informative_analog_digital_time_num_2.png","informative_analog_digital_time_num_3.png","informative_analog_digital_time_num_4.png","informative_analog_digital_time_num_5.png","informative_analog_digital_time_num_6.png","informative_analog_digital_time_num_7.png","informative_analog_digital_time_num_8.png","informative_analog_digital_time_num_9.png"],
              hour_zero: 1,
              hour_space: 4,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 100,
              minute_startY: 245,
              minute_array: ["informative_analog_digital_time_num_0.png","informative_analog_digital_time_num_1.png","informative_analog_digital_time_num_2.png","informative_analog_digital_time_num_3.png","informative_analog_digital_time_num_4.png","informative_analog_digital_time_num_5.png","informative_analog_digital_time_num_6.png","informative_analog_digital_time_num_7.png","informative_analog_digital_time_num_8.png","informative_analog_digital_time_num_9.png"],
              minute_zero: 1,
              minute_space: 4,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 180,
              y: 385,
              w: 50,
              h: 50,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_cal_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 255,
              y: 45,
              w: 50,
              h: 50,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 45,
              y: 175,
              w: 50,
              h: 50,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 110,
              y: 196,
              w: 80,
              h: 80,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 210,
              y: 106,
              w: 60,
              h: 60,
              type: hmUI.data_type.MOON_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 195,
              y: 275,
              w: 90,
              h: 90,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 390,
              y: 255,
              w: 50,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PowerSaveHintScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 286,
              y: 132,
              w: 50,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 135,
              y: 132,
              w: 50,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 290,
              y: 195,
              w: 80,
              h: 80,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              longpress_func: (button_widget) => {
                hmApp.startApp({url: 'oneKeyAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            //start of ignored block
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              if (updateHour) {
                let normal_hour = hour;
                let normal_fullAngle_hour = 360;
                if (normal_hour > 11) normal_hour -= 12;
                let normal_angle_hour = 0 + normal_fullAngle_hour*normal_hour/12 + (normal_fullAngle_hour/12)*minute/60;
                if (normal_analog_clock_pro_hour_pointer_img) normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_hour);
              };

              if (updateMinute) {
                let normal_fullAngle_minute = 360;
                let normal_angle_minute = 0 + normal_fullAngle_minute*(minute + second/60)/60;
                if (normal_analog_clock_pro_minute_pointer_img) normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_minute);
              };

              if (updateHour) {
                let idle_hour = hour;
                let idle_fullAngle_hour = 360;
                if (idle_hour > 11) idle_hour -= 12;
                let idle_angle_hour = 0 + idle_fullAngle_hour*idle_hour/12 + (idle_fullAngle_hour/12)*minute/60;
                if (idle_analog_clock_pro_hour_pointer_img) idle_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.ANGLE, idle_angle_hour);
              };

              if (updateMinute) {
                let idle_fullAngle_minute = 360;
                let idle_angle_minute = 0 + idle_fullAngle_minute*(minute + second/60)/60;
                if (idle_analog_clock_pro_minute_pointer_img) idle_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.ANGLE, idle_angle_minute);
              };

              let idle_fullAngle_second = 360;
              let idle_angle_second = 0 + idle_fullAngle_second*(second + (timeSensor.utc % 1000)/1000)/60;
              if (idle_analog_clock_pro_second_pointer_img) idle_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, idle_angle_second);

            };

            //end of ignored block
            //start of ignored block
            function text_update() {
              console.log('text_update()');

              console.log('update text rotate battery_BATTERY');
              let valueBattery = battery.current;
              let normal_battery_rotate_string = parseInt(valueBattery).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  normal_battery_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_battery_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
                if (valueBattery != null && valueBattery != undefined && isFinite(valueBattery) && normal_battery_rotate_string.length > 0 && normal_battery_rotate_string.length <= 3) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = RIGHT
                  let normal_battery_TextRotate_posOffset = normal_battery_TextRotate_img_width * normal_battery_rotate_string.length;
                  normal_battery_TextRotate_posOffset = normal_battery_TextRotate_posOffset + 3 * (normal_battery_rotate_string.length - 1);
                  img_offset -= normal_battery_TextRotate_posOffset;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_battery_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_battery_TextRotate[index].setProperty(hmUI.prop.POS_X, 275 + img_offset);
                      normal_battery_TextRotate[index].setProperty(hmUI.prop.SRC, normal_battery_TextRotate_ASCIIARRAY[charCode]);
                      normal_battery_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_battery_TextRotate_img_width + 3;
                      index++;
                    };  // end if digit
                  };  // end char of string
                  normal_battery_TextRotate_unit.setProperty(hmUI.prop.POS_X, 275 + img_offset);
                  normal_battery_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite

              };

              console.log('update text rotate heart_rate_HEART');
              let valueHeartRate = heart_rate.last;
              let normal_heart_rate_rotate_string = parseInt(valueHeartRate).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  normal_heart_rate_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueHeartRate != null && valueHeartRate != undefined && isFinite(valueHeartRate) && normal_heart_rate_rotate_string.length > 0 && normal_heart_rate_rotate_string.length <= 3) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of normal_heart_rate_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_heart_rate_TextRotate[index].setProperty(hmUI.prop.POS_X, 190 + img_offset);
                      normal_heart_rate_TextRotate[index].setProperty(hmUI.prop.SRC, normal_heart_rate_TextRotate_ASCIIARRAY[charCode]);
                      normal_heart_rate_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_heart_rate_TextRotate_img_width + 3;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate calorie_CALORIE');
              let valueCalories = calorie.current;
              let normal_calorie_rotate_string = parseInt(valueCalories).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 4; i++) {  // hide all symbols
                  normal_calorie_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueCalories != null && valueCalories != undefined && isFinite(valueCalories) && normal_calorie_rotate_string.length > 0 && normal_calorie_rotate_string.length <= 4) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of normal_calorie_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 4) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_calorie_TextRotate[index].setProperty(hmUI.prop.POS_X, 415 + img_offset);
                      normal_calorie_TextRotate[index].setProperty(hmUI.prop.SRC, normal_calorie_TextRotate_ASCIIARRAY[charCode]);
                      normal_calorie_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_calorie_TextRotate_img_width + 3;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate step_STEP');
              let valueStep = step.current;
              let normal_step_rotate_string = parseInt(valueStep).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  normal_step_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueStep != null && valueStep != undefined && isFinite(valueStep) && normal_step_rotate_string.length > 0 && normal_step_rotate_string.length <= 5) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = RIGHT
                  let normal_step_TextRotate_posOffset = normal_step_TextRotate_img_width * normal_step_rotate_string.length;
                  normal_step_TextRotate_posOffset = normal_step_TextRotate_posOffset + 3 * (normal_step_rotate_string.length - 1);
                  img_offset -= normal_step_TextRotate_posOffset;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_step_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_step_TextRotate[index].setProperty(hmUI.prop.POS_X, 82 + img_offset);
                      normal_step_TextRotate[index].setProperty(hmUI.prop.SRC, normal_step_TextRotate_ASCIIARRAY[charCode]);
                      normal_step_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_step_TextRotate_img_width + 3;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

            };

            //end of ignored block
            function scale_call() {
              console.log('scale_call()');

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_cs_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_battery * 100);
                  if (normal_battery_circle_scale) {
                    normal_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 240,
                      center_y: 240,
                      start_angle: 108,
                      end_angle: 162,
                      radius: 173,
                      line_width: 15,
                      corner_flag: 0,
                      color: 0xFF1FBE23,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales HEART');
                
                let valueHeartRate = heart_rate.last;
                let targetHeartRate = 179;
                let progressHeartRate = (valueHeartRate - 71)/(targetHeartRate - 71);
                if (progressHeartRate < 0) progressHeartRate = 0;
                if (progressHeartRate > 1) progressHeartRate = 1;
                let progress_cs_normal_heart_rate = progressHeartRate;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_heart_rate_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_heart_rate * 100);
                  if (normal_heart_rate_circle_scale) {
                    normal_heart_rate_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 240,
                      center_y: 240,
                      start_angle: 288,
                      end_angle: 342,
                      radius: 173,
                      line_width: 15,
                      corner_flag: 0,
                      color: 0xFFFF0000,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales CALORIE');
                
                let valueCalories = calorie.current;
                let targetCalories = calorie.target;
                let progressCalories = valueCalories/targetCalories;
                if (progressCalories > 1) progressCalories = 1;
                let progress_cs_normal_calorie = progressCalories;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_calorie_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_calorie * 100);
                  if (normal_calorie_circle_scale) {
                    normal_calorie_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 240,
                      center_y: 240,
                      start_angle: 18,
                      end_angle: 72,
                      radius: 173,
                      line_width: 15,
                      corner_flag: 0,
                      color: 0xFFFF8C00,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_cs_normal_step = progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_step * 100);
                  if (normal_step_circle_scale) {
                    normal_step_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 240,
                      center_y: 240,
                      start_angle: 198,
                      end_angle: 252,
                      radius: 173,
                      line_width: 15,
                      corner_flag: 0,
                      color: 0xFF107BAF,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                time_update(true, true);
                text_update();
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSec) {
                    let animDelay = timeSensor.utc % 1000;
                    let animRepeat = 1000;
                    normal_timerUpdateSec = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, true);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                let secAngle = 0 + (360*6)*(timeSensor.second + ((timeSensor.utc % 1000) / 1000))/360;
                normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, secAngle);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSecSmooth) {
                    let duration = 0;
                    let animDuration = 5000;
                    if (timeSensor.second > 55) animDuration = 1000*(60.1 - (timeSensor.second - (timeSensor.utc % 1000) / 1000));
                    let diffTime = timeSensor.utc - lastTime;
                    if (diffTime < animDuration) duration = animDuration - diffTime;
                    normal_timerUpdateSecSmooth = timer.createTimer(duration, animDuration, (function (option) {
                      lastTime = timeSensor.utc;
                      secAngle = 0 + (360*6)*(timeSensor.second + ((timeSensor.utc % 1000) / 1000))/360;
                      startSecAnim(secAngle, animDuration);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.AOD) {
                  if (!idle_timerUpdateSec) {
                    let animDelay = timeSensor.utc % 1000;
                    let animRepeat = 1000;
                    idle_timerUpdateSec = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, true);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.AOD) {
                  if (!idle_timerUpdateSecSmooth) {
                    let animDelay = 0;
                    let animRepeat = 1000/15;
                    idle_timerUpdateSecSmooth = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, false);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerUpdateSec) {
                  timer.stopTimer(normal_timerUpdateSec);
                  normal_timerUpdateSec = undefined;
                }
                if (normal_timerUpdateSecSmooth) {
                  timer.stopTimer(normal_timerUpdateSecSmooth);
                  normal_timerUpdateSecSmooth = undefined;
                }
                if (idle_timerUpdateSec) {
                  timer.stopTimer(idle_timerUpdateSec);
                  idle_timerUpdateSec = undefined;
                }
                if (idle_timerUpdateSecSmooth) {
                  timer.stopTimer(idle_timerUpdateSecSmooth);
                  idle_timerUpdateSecSmooth = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
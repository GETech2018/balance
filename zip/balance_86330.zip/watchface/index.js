﻿﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start
        let btn_bezel = ''
        let bezel_num = 1
        let bezel_all = 8  
        
        let normal_background_bg_img = ''
        let normal_hour_img = ''
        let normal_minute_img = ''
        let normal_image_img = ''
        let normal_battery_current_text_font = ''
        let normal_dow_text_font = ''
        let normal_DOW_Array = ['Пнд', 'Втр', 'Срд', 'Чтв', 'Птн', 'Сбт', 'Вск'];
        let normal_day_text_font = ''
        let idle_background_bg_img = ''
        let idle_hour_img = ''
        let idle_minute_img = ''
        let idle_image_img = ''
        let idle_battery_current_text_font = ''
        let idle_dow_text_font = ''
        let idle_DOW_Array = ['Пнд', 'Втр', 'Срд', 'Чтв', 'Птн', 'Сбт', 'Вск'];
        let idle_day_text_font = ''
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
            function click_Bezel() {
              if(bezel_num>=bezel_all) {bezel_num=1;}
              else { bezel_num=bezel_num+1;}
              hmUI.showToast({text: "Цвет " + parseInt(bezel_num) });
                normal_background_bg_img.setProperty(hmUI.prop.SRC, "osn_" + parseInt(bezel_num) + ".png");

            }                     
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'osn_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_hour_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'H_0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_minute_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'M_0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'zapl_1.png',
              // alpha: 170,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img.setAlpha(170);

            normal_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 168,
              y: 430,
              w: 150,
              h: 50,
              text_size: 30,
              char_space: 0,
              alpha: 170,
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              unit_type: 1,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function() {
              time_update();
            });
            timeSensor.addEventListener(timeSensor.event.MINUTEEND, function() {
              time_update();
            });

            normal_dow_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 230,
              y: 396,
              w: 150,
              h: 50,
              text_size: 35,
              char_space: 0,
              alpha: 170,
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              // unit_string: Пнд, Втр, Срд, Чтв, Птн, Сбт, Вск,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            

            normal_day_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 120,
              y: 396,
              w: 100,
              h: 50,
              text_size: 35,
              char_space: 0,
              alpha: 170,
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.RIGHT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'osn_2.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_hour_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'H_0.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_minute_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'M_0.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'zapl_1.png',
              // alpha: 170,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img.setAlpha(170);

            idle_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 168,
              y: 430,
              w: 150,
              h: 50,
              text_size: 30,
              char_space: 0,
              alpha: 170,
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              unit_type: 1,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_dow_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 230,
              y: 396,
              w: 150,
              h: 50,
              text_size: 35,
              char_space: 0,
              alpha: 170,
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              // unit_string: Пнд, Втр, Срд, Чтв, Птн, Сбт, Вск,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_day_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 120,
              y: 396,
              w: 100,
              h: 50,
              text_size: 35,
              char_space: 0,
              alpha: 170,
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.RIGHT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            btn_bezel = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 203,
              y: 403,
              text: '',
              w: 60,
              h: 60,
              normal_src: 'clean.png',
              press_src: 'clean.png',
              click_func: () => {
               click_Bezel();
               
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btn_bezel.setProperty(hmUI.prop.VISIBLE, true);             

            let screenType = hmSetting.getScreenType();
            //#region time_update
            function time_update() {
              console.log('time_update()');
              let is24h = hmSetting.getTimeFormat() === 1;
              let hour = timeSensor.hour;
              if (!is24h) {
                hour = hour % 12;
                if (hour === 0) hour = 12;
              }
              let hourStr = 'H_' + hour + '.png';
              normal_hour_img.setProperty(hmUI.prop.SRC, hourStr);
              idle_hour_img.setProperty(hmUI.prop.SRC, hourStr);

              let minute = timeSensor.minute;
              let minuteStr = 'M_' + minute + '.png';
              normal_minute_img.setProperty(hmUI.prop.SRC, minuteStr);
              idle_minute_img.setProperty(hmUI.prop.SRC, minuteStr);

              let normal_DOW_Str = normal_DOW_Array[timeSensor.week-1];
              normal_dow_text_font.setProperty(hmUI.prop.TEXT, normal_DOW_Str );

              let normal_dayStr = timeSensor.day.toString();
              normal_day_text_font.setProperty(hmUI.prop.TEXT, normal_dayStr );

              let idle_DOW_Str = idle_DOW_Array[timeSensor.week-1];
              idle_dow_text_font.setProperty(hmUI.prop.TEXT, idle_DOW_Str );

              let idle_dayStr = timeSensor.day.toString();
              idle_day_text_font.setProperty(hmUI.prop.TEXT, idle_dayStr );
            };

            //#endregion
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                time_update();
              }),
            });

            time_update();

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
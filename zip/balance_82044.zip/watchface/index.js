﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

let deviceInfo = hmSetting.getDeviceInfo();

        // Change Theme
        let colornumber_main = 1
        let totalcolors_main = 5
        let namecolor_main = ''

        function click_Color() {
            if(colornumber_main>=totalcolors_main) {
            colornumber_main=1;
                }
            else {
                colornumber_main=colornumber_main+1;
            }

if ( colornumber_main == 1) { namecolor_main = "Theme 1"}
if ( colornumber_main == 2) { namecolor_main = "Theme 2"}
if ( colornumber_main == 3) { namecolor_main = "Theme 3"}
if ( colornumber_main == 4) { namecolor_main = "Theme 4"}
if ( colornumber_main == 5) { namecolor_main = "Theme 5"}

hmUI.showToast({text: namecolor_main });
             normal_fat_burning_icon_img.setProperty(hmUI.prop.SRC, "theme" + parseInt(colornumber_main) + ".png");
                           
        }


        // Change Background
        let colornumber_mainB = 1
        let totalcolors_mainB = 5
        let namecolor_mainB = ''

        function click_ColorB() {
            if(colornumber_mainB>=totalcolors_mainB) {
            colornumber_mainB=1;
                }
            else {
                colornumber_mainB=colornumber_mainB+1;
            }

if ( colornumber_mainB == 1) { namecolor_mainB = "Background 1"}
if ( colornumber_mainB == 2) { namecolor_mainB = "Background 2"}
if ( colornumber_mainB == 3) { namecolor_mainB = "Background 3"}
if ( colornumber_mainB == 4) { namecolor_mainB = "Background 4"}
if ( colornumber_mainB == 5) { namecolor_mainB = "Background 5"}

hmUI.showToast({text: namecolor_mainB });

            normal_image_img.setProperty(hmUI.prop.SRC, "main" + parseInt(colornumber_mainB) + ".png");
            normal_battery_icon_img.setProperty(hmUI.prop.SRC, "select_main" + parseInt(colornumber_mainB) + ".png");
                           
        }



        // LCD Switch
        let elementnumber_1 = 1
        let total_elemente = 2

        function click_elemente() {
            if(elementnumber_1==total_elemente) {
            elementnumber_1=1;
                UpdateElementeOne();
                }
            else {
                elementnumber_1=elementnumber_1+1;
                if(elementnumber_1==2) {
                  UpdateElementeTwo();
                }

            }
            if(elementnumber_1==1) hmUI.showToast({text: 'Black LCD'});
            if(elementnumber_1==2) hmUI.showToast({text: 'White LCD'});
        }

        //Black LCD
        function UpdateElementeOne(){

        normal_temperature_icon_img.setProperty(hmUI.prop.MORE, {
              x: deviceInfo.width / 480 * 92,
              y: deviceInfo.height / 480 * 71,
              src: 'Bg_B_LCD.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
        normal_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
              x: deviceInfo.width / 480 * 146,
              y: deviceInfo.height / 480 * 157,
              font_array: ["act_W_0.png","act_W_1.png","act_W_2.png","act_W_3.png","act_W_4.png","act_W_5.png","act_W_6.png","act_W_7.png","act_W_8.png","act_W_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'weather_W_Symbol1.png',
              unit_tc: 'weather_W_Symbol1.png',
              unit_en: 'weather_W_Symbol1.png',
              imperial_unit_sc: 'weather_W_Symbol1.png',
              imperial_unit_tc: 'weather_W_Symbol1.png',
              imperial_unit_en: 'weather_W_Symbol1.png',
              negative_image: 'weather_W_Symbol2.png',
              invalid_image: 'weather_W_Symbol2.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

          const temperatureUnit = hmSetting.getTemperatureUnit();
            //start of ignored block
            if (temperatureUnit == 1) {
              normal_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
                x: deviceInfo.width / 480 * 146,
                y: deviceInfo.height / 480 * 157,
                font_array: ["act_W_0.png","act_W_1.png","act_W_2.png","act_W_3.png","act_W_4.png","act_W_5.png","act_W_6.png","act_W_7.png","act_W_8.png","act_W_9.png"],
                padding: false,
                h_space: 0,
                unit_sc: 'weather_W_Symbol1.png',
                unit_tc: 'weather_W_Symbol1.png',
                unit_en: 'weather_W_Symbol1.png',
                imperial_unit_sc: 'weather_W_Symbol1.png',
                imperial_unit_tc: 'weather_W_Symbol1.png',
                imperial_unit_en: 'weather_W_Symbol1.png',
                negative_image: 'weather_W_Symbol2.png',
                invalid_image: 'weather_W_Symbol2.png',
                align_h: hmUI.align.CENTER_H,
                type: hmUI.data_type.WEATHER_CURRENT,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
            };

            normal_date_img_date_day.setProperty(hmUI.prop.MORE, {
              day_startX: deviceInfo.width / 480 * 256,
              day_startY: deviceInfo.height / 480 * 156,
              day_sc_array: ["act_W_0.png","act_W_1.png","act_W_2.png","act_W_3.png","act_W_4.png","act_W_5.png","act_W_6.png","act_W_7.png","act_W_8.png","act_W_9.png"],
              day_tc_array: ["act_W_0.png","act_W_1.png","act_W_2.png","act_W_3.png","act_W_4.png","act_W_5.png","act_W_6.png","act_W_7.png","act_W_8.png","act_W_9.png"],
              day_en_array: ["act_W_0.png","act_W_1.png","act_W_2.png","act_W_3.png","act_W_4.png","act_W_5.png","act_W_6.png","act_W_7.png","act_W_8.png","act_W_9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img.setProperty(hmUI.prop.MORE, {
              month_startX: deviceInfo.width / 480 * 328,
              month_startY: deviceInfo.height / 480 * 154,
              month_sc_array: ["Month_W_01.png","Month_W_02.png","Month_W_03.png","Month_W_04.png","Month_W_05.png","Month_W_06.png","Month_W_07.png","Month_W_08.png","Month_W_09.png","Month_W_10.png","Month_W_11.png","Month_W_12.png"],
              month_tc_array: ["Month_W_01.png","Month_W_02.png","Month_W_03.png","Month_W_04.png","Month_W_05.png","Month_W_06.png","Month_W_07.png","Month_W_08.png","Month_W_09.png","Month_W_10.png","Month_W_11.png","Month_W_12.png"],
              month_en_array: ["Month_W_01.png","Month_W_02.png","Month_W_03.png","Month_W_04.png","Month_W_05.png","Month_W_06.png","Month_W_07.png","Month_W_08.png","Month_W_09.png","Month_W_10.png","Month_W_11.png","Month_W_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img.setProperty(hmUI.prop.MORE, {
              x: deviceInfo.width / 480 * 319,
              y: deviceInfo.height / 480 * 177,
              week_en: ["Week_W_01.png","Week_W_02.png","Week_W_03.png","Week_W_04.png","Week_W_05.png","Week_W_06.png","Week_W_07.png"],
              week_tc: ["Week_W_01.png","Week_W_02.png","Week_W_03.png","Week_W_04.png","Week_W_05.png","Week_W_06.png","Week_W_07.png"],
              week_sc: ["Week_W_01.png","Week_W_02.png","Week_W_03.png","Week_W_04.png","Week_W_05.png","Week_W_06.png","Week_W_07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_minute.setProperty(hmUI.prop.MORE, {
              minute_startX: deviceInfo.width / 480 * 254,
              minute_startY: deviceInfo.height / 480 * 94,
              minute_array: ["Time_W_0.png","Time_W_1.png","Time_W_2.png","Time_W_3.png","Time_W_4.png","Time_W_5.png","Time_W_6.png","Time_W_7.png","Time_W_8.png","Time_W_9.png"],
              minute_zero: 1,
              minute_space: 3,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_minute_separator_img.setProperty(hmUI.prop.MORE, {
              x: deviceInfo.width / 480 * 269,
              y: deviceInfo.height / 480 * 196,
              src: 'LCD_dot.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_hour.setProperty(hmUI.prop.MORE, {
              hour_startX: deviceInfo.width / 480 * 136,
              hour_startY: deviceInfo.height / 480 * 94,
              hour_array: ["Time_W_0.png","Time_W_1.png","Time_W_2.png","Time_W_3.png","Time_W_4.png","Time_W_5.png","Time_W_6.png","Time_W_7.png","Time_W_8.png","Time_W_9.png"],
              hour_zero: 1,
              hour_space: 3,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img.setProperty(hmUI.prop.MORE, {
              x: deviceInfo.width / 480 * 233,
              y: deviceInfo.height / 480 * 91,
              src: 'Time_W_Dot.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
        }
////// end LCD Black

        //White LCD
        function UpdateElementeTwo(){

        normal_temperature_icon_img.setProperty(hmUI.prop.MORE, {
              x: deviceInfo.width / 480 * 92,
              y: deviceInfo.height / 480 * 71,
              src: 'Bg_W_LCD.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
        normal_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
              x: deviceInfo.width / 480 * 146,
              y: deviceInfo.height / 480 * 157,
              font_array: ["act_B_0.png","act_B_1.png","act_B_2.png","act_B_3.png","act_B_4.png","act_B_5.png","act_B_6.png","act_B_7.png","act_B_8.png","act_B_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'weather_B_Symbol1.png',
              unit_tc: 'weather_B_Symbol1.png',
              unit_en: 'weather_B_Symbol1.png',
              imperial_unit_sc: 'weather_B_Symbol1.png',
              imperial_unit_tc: 'weather_B_Symbol1.png',
              imperial_unit_en: 'weather_B_Symbol1.png',
              negative_image: 'weather_B_Symbol2.png',
              invalid_image: 'weather_B_Symbol2.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

           const temperatureUnit = hmSetting.getTemperatureUnit();
            //start of ignored block
            if (temperatureUnit == 1) {
              normal_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
                x: deviceInfo.width / 480 * 146,
                y: deviceInfo.height / 480 * 157,
                font_array: ["act_B_0.png","act_B_1.png","act_B_2.png","act_B_3.png","act_B_4.png","act_B_5.png","act_B_6.png","act_B_7.png","act_B_8.png","act_B_9.png"],
                padding: false,
                h_space: 0,
                unit_sc: 'weather_B_Symbol1.png',
                unit_tc: 'weather_B_Symbol1.png',
                unit_en: 'weather_B_Symbol1.png',
                imperial_unit_sc: 'weather_B_Symbol1.png',
                imperial_unit_tc: 'weather_B_Symbol1.png',
                imperial_unit_en: 'weather_B_Symbol1.png',
                negative_image: 'weather_B_Symbol2.png',
                invalid_image: 'weather_B_Symbol2.png',
                align_h: hmUI.align.CENTER_H,
                type: hmUI.data_type.WEATHER_CURRENT,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
            };

            normal_date_img_date_day.setProperty(hmUI.prop.MORE, {
              day_startX: deviceInfo.width / 480 * 256,
              day_startY: deviceInfo.height / 480 * 156,
              day_sc_array: ["act_B_0.png","act_B_1.png","act_B_2.png","act_B_3.png","act_B_4.png","act_B_5.png","act_B_6.png","act_B_7.png","act_B_8.png","act_B_9.png"],
              day_tc_array: ["act_B_0.png","act_B_1.png","act_B_2.png","act_B_3.png","act_B_4.png","act_B_5.png","act_B_6.png","act_B_7.png","act_B_8.png","act_B_9.png"],
              day_en_array: ["act_B_0.png","act_B_1.png","act_B_2.png","act_B_3.png","act_B_4.png","act_B_5.png","act_B_6.png","act_B_7.png","act_B_8.png","act_B_9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img.setProperty(hmUI.prop.MORE, {
              month_startX: deviceInfo.width / 480 * 328,
              month_startY: deviceInfo.height / 480 * 154,
              month_sc_array: ["Month_B_01.png","Month_B_02.png","Month_B_03.png","Month_B_04.png","Month_B_05.png","Month_B_06.png","Month_B_07.png","Month_B_08.png","Month_B_09.png","Month_B_10.png","Month_B_11.png","Month_B_12.png"],
              month_tc_array: ["Month_B_01.png","Month_B_02.png","Month_B_03.png","Month_B_04.png","Month_B_05.png","Month_B_06.png","Month_B_07.png","Month_B_08.png","Month_B_09.png","Month_B_10.png","Month_B_11.png","Month_B_12.png"],
              month_en_array: ["Month_B_01.png","Month_B_02.png","Month_B_03.png","Month_B_04.png","Month_B_05.png","Month_B_06.png","Month_B_07.png","Month_B_08.png","Month_B_09.png","Month_B_10.png","Month_B_11.png","Month_B_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img.setProperty(hmUI.prop.MORE, {
              x: deviceInfo.width / 480 * 319,
              y: deviceInfo.height / 480 * 177,
              week_en: ["Week_B_01.png","Week_B_02.png","Week_B_03.png","Week_B_04.png","Week_B_05.png","Week_B_06.png","Week_B_07.png"],
              week_tc: ["Week_B_01.png","Week_B_02.png","Week_B_03.png","Week_B_04.png","Week_B_05.png","Week_B_06.png","Week_B_07.png"],
              week_sc: ["Week_B_01.png","Week_B_02.png","Week_B_03.png","Week_B_04.png","Week_B_05.png","Week_B_06.png","Week_B_07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_minute.setProperty(hmUI.prop.MORE, {
              minute_startX: deviceInfo.width / 480 * 254,
              minute_startY: deviceInfo.height / 480 * 94,
              minute_array: ["Time_0.png","Time_1.png","Time_2.png","Time_3.png","Time_4.png","Time_5.png","Time_6.png","Time_7.png","Time_8.png","Time_9.png"],
              minute_zero: 1,
              minute_space: 3,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_minute_separator_img.setProperty(hmUI.prop.MORE, {
              x: deviceInfo.width / 480 * 303,
              y: deviceInfo.height / 480 * 196,
              src: 'LCD_dot.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_hour.setProperty(hmUI.prop.MORE, {
              hour_startX: deviceInfo.width / 480 * 136,
              hour_startY: deviceInfo.height / 480 * 94,
              hour_array: ["Time_0.png","Time_1.png","Time_2.png","Time_3.png","Time_4.png","Time_5.png","Time_6.png","Time_7.png","Time_8.png","Time_9.png"],
              hour_zero: 1,
              hour_space: 3,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img.setProperty(hmUI.prop.MORE, {
              x: deviceInfo.width / 480 * 233,
              y: deviceInfo.height / 480 * 91,
              src: 'Time_dot.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
        }
        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_motion_animation_img_1 = '';
        let normal_motion_animation_paramX_1 = null;
        let normal_motion_animation_paramY_1 = null;
        let normal_motion_animation_lastTime_1 = 0;
        let timer_anim_motion_1;
        let normal_motion_animation_count_1 = 0;
        let normal_image_img = ''
        let normal_heart_rate_circle_scale = ''
        let normal_heart_rate_text_text_img = ''
        let normal_calorie_icon_img = ''
        let normal_calorie_circle_scale = ''
        let normal_calorie_current_text_img = ''
        let normal_distance_TextRotate = new Array(5);
        let normal_distance_TextRotate_ASCIIARRAY = new Array(10);
        let normal_distance_TextRotate_img_width = 1;
        let normal_distance_TextRotate_unit = null;
        let normal_distance_TextRotate_unit_width = 24;
        let normal_distance_TextRotate_dot_width = 1;
        let normal_distance_TextRotate_error_img_width = 1;
        let normal_distance_text_text_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_fat_burning_icon_img = ''
        let normal_battery_icon_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_step_circle_scale = ''
        let normal_step_current_text_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_temperature_icon_img = ''
        let normal_temperature_current_text_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_week_img = ''
        let normal_digital_clock_img_time_minute = ''
        let normal_digital_clock_minute_separator_img = ''
        let normal_digital_clock_img_time_hour = ''
        let normal_digital_clock_hour_separator_img = ''
        let idle_background_bg_img = ''
        let idle_image_img = ''
        let idle_heart_rate_circle_scale = ''
        let idle_heart_rate_text_text_img = ''
        let idle_calorie_icon_img = ''
        let idle_calorie_circle_scale = ''
        let idle_calorie_current_text_img = ''
        let idle_distance_TextRotate = new Array(5);
        let idle_distance_TextRotate_ASCIIARRAY = new Array(10);
        let idle_distance_TextRotate_img_width = 1;
        let idle_distance_TextRotate_unit = null;
        let idle_distance_TextRotate_unit_width = 24;
        let idle_distance_TextRotate_dot_width = 1;
        let idle_distance_TextRotate_error_img_width = 1;
        let idle_distance_text_text_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_fat_burning_icon_img = ''
        let idle_battery_icon_img = ''
        let idle_battery_image_progress_img_level = ''
        let idle_step_icon_img = ''
        let idle_step_circle_scale = ''
        let idle_step_current_text_img = ''
        let idle_step_image_progress_img_level = ''
        let idle_temperature_current_text_img = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_week_img = ''
        let idle_digital_clock_img_time_minute = ''
        let idle_digital_clock_minute_separator_img = ''
        let idle_digital_clock_img_time_hour = ''
        let idle_digital_clock_hour_separator_img = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'Bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_motion_animation_img_1 = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 479,
              h: 479,
              pos_x: 79,
              pos_y: 138,
              src: 'animation/S_0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_motion_animation_paramX_1 = {
              anim_steps: [{
                anim_rate: 'linear',
                anim_duration: 1000,
                anim_from: 79,
                anim_to: 79,
                anim_key: "pos_x",
              }],
              anim_fps: 15,
              anim_auto_start: 1,
              anim_repeat: 1,
              anim_auto_destroy: 1,
            };

            normal_motion_animation_paramY_1 = {
              anim_steps: [{
                anim_rate: 'linear',
                anim_duration: 1000,
                anim_from: 138,
                anim_to: 90,
                anim_key: "pos_y",
              }],
              anim_fps: 15,
              anim_auto_start: 1,
              anim_repeat: 1,
              anim_auto_destroy: 1,
            };

            let now = hmSensor.createSensor(hmSensor.id.TIME);

            function anim_motion_1_complete_call() {
              normal_motion_animation_img_1.setProperty(hmUI.prop.ANIM, normal_motion_animation_paramX_1);
              normal_motion_animation_img_1.setProperty(hmUI.prop.ANIM, normal_motion_animation_paramY_1);
                normal_motion_animation_lastTime_1 = now.utc;
              normal_motion_animation_count_1 = normal_motion_animation_count_1 - 1;
              if(normal_motion_animation_count_1 < -1) normal_motion_animation_count_1 = - 1;
              if(normal_motion_animation_count_1 == 0) stop_anim_motion_1();
            }; // end animation callback function
            
            function stop_anim_motion_1() {
              if (timer_anim_motion_1) {
                timer.stopTimer(timer_anim_motion_1);
                timer_anim_motion_1 = undefined;
              };
            }; // end stop_anim_motion function

            // normal_motion_anime_1 = hmUI.createWidget(hmUI.widget.Motion_Animation, {
              // x_start: 79,
              // y_start: 138,
              // x_end: 79,
              // y_end: 90,
              // src: 'S_0.png',
              // anim_fps: 15,
              // anim_duration: 1000,
              // repeat_count: 0,
              // anim_two_sides: False,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'main1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_heart_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 358,
              // center_y: 333,
              // start_angle: 205,
              // end_angle: 515,
              // radius: 44,
              // line_width: 10,
              // line_cap: Flat,
              // color: 0xFF4E4E4E,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            let screenType = hmSetting.getScreenType();
            normal_heart_rate_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 358,
              center_y: 333,
              start_angle: 205,
              end_angle: 515,
              radius: 39,
              line_width: 10,
              corner_flag: 3,
              color: 0xFF4E4E4E,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const heart_rate = hmSensor.createSensor(hmSensor.id.HEART);
            heart_rate.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 337,
              y: 334,
              font_array: ["activity_small_0.png","activity_small_1.png","activity_small_2.png","activity_small_3.png","activity_small_4.png","activity_small_5.png","activity_small_6.png","activity_small_7.png","activity_small_8.png","activity_small_9.png"],
              padding: false,
              h_space: 3,
              invalid_image: '0_Empty.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 110,
              y: 344,
              src: 'cal_unit.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_cal_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 122,
              // center_y: 333,
              // start_angle: 205,
              // end_angle: 515,
              // radius: 44,
              // line_width: 10,
              // line_cap: Flat,
              // color: 0xFF4E4E4E,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_calorie_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 122,
              center_y: 333,
              start_angle: 205,
              end_angle: 515,
              radius: 39,
              line_width: 10,
              corner_flag: 3,
              color: 0xFF4E4E4E,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const calorie = hmSensor.createSensor(hmSensor.id.CALORIE);
            calorie.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 99,
              y: 328,
              font_array: ["activity_small_0.png","activity_small_1.png","activity_small_2.png","activity_small_3.png","activity_small_4.png","activity_small_5.png","activity_small_6.png","activity_small_7.png","activity_small_8.png","activity_small_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_distance_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 225,
              // y: 347,
              // font_array: ["E_0.png","E_1.png","E_2.png","E_3.png","E_4.png","E_5.png","E_6.png","E_7.png","E_8.png","E_9.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: 0,
              // unit_en: 'Dis_KM.png',
              // imperial_unit_en: 'Dis_MI.png',
              // negative_image: 'E_0.png',
              // invalid_image: 'E_0.png',
              // dot_image: 'E_0.png',
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.DISTANCE,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_distance_TextRotate_ASCIIARRAY[0] = 'E_0.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[1] = 'E_1.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[2] = 'E_2.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[3] = 'E_3.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[4] = 'E_4.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[5] = 'E_5.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[6] = 'E_6.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[7] = 'E_7.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[8] = 'E_8.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[9] = 'E_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              normal_distance_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 225,
                center_y: 347,
                pos_x: 225,
                pos_y: 347,
                angle: 0,
                src: 'E_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_distance_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_distance_TextRotate_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              center_x: 225,
              center_y: 347,
              pos_x: 225,
              pos_y: 347,
              angle: 0,
              src: 'Dis_KM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_distance_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);

            const mileageUnit = hmSetting.getMileageUnit();
            if (mileageUnit == 1) {
              normal_distance_TextRotate_unit.setProperty(hmUI.prop.SRC, 'Dis_MI.png');
            };
            //end of ignored block
            
            const distance = hmSensor.createSensor(hmSensor.id.DISTANCE);
            distance.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });
            
            function toDegree (radian) {
              return radian * (180 / Math.PI);
            };

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 214,
              y: 326,
              font_array: ["activity_small_0.png","activity_small_1.png","activity_small_2.png","activity_small_3.png","activity_small_4.png","activity_small_5.png","activity_small_6.png","activity_small_7.png","activity_small_8.png","activity_small_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'E_0.png',
              unit_tc: 'E_0.png',
              unit_en: 'E_0.png',
              imperial_unit_sc: 'E_0.png',
              imperial_unit_tc: 'E_0.png',
              imperial_unit_en: 'E_0.png',
              dot_image: 'Dis_dot.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 235,
              y: 52,
              src: 'System_BT_OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 232,
              y: 200,
              src: 'System_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_fat_burning_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 23,
              y: 171,
              src: 'theme1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 16,
              y: 227,
              src: 'select_main1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 363,
              y: 170,
              image_array: ["Batt_img_01.png","Batt_img_02.png","Batt_img_03.png","Batt_img_04.png","Batt_img_05.png","Batt_img_06.png","Batt_img_07.png","Batt_img_08.png","Batt_img_09.png","Batt_img_10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 240,
              // center_y: 333,
              // start_angle: 205,
              // end_angle: 515,
              // radius: 44,
              // line_width: 10,
              // line_cap: Flat,
              // color: 0xFF4E4E4E,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 240,
              center_y: 333,
              start_angle: 205,
              end_angle: 515,
              radius: 39,
              line_width: 10,
              corner_flag: 3,
              color: 0xFF4E4E4E,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 178,
              y: 401,
              font_array: ["Step_font_0.png","Step_font_1.png","Step_font_2.png","Step_font_3.png","Step_font_4.png","Step_font_5.png","Step_font_6.png","Step_font_7.png","Step_font_8.png","Step_font_9.png"],
              padding: true,
              h_space: 6,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 51,
              y: 262,
              image_array: ["Steps_01.png","Steps_02.png","Steps_03.png","Steps_04.png","Steps_05.png","Steps_06.png","Steps_07.png","Steps_08.png","Steps_09.png","Steps_10.png","Steps_11.png","Steps_12.png","Steps_13.png","Steps_14.png","Steps_15.png"],
              image_length: 15,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 92,
              y: 71,
              src: 'Bg_B_LCD.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 146,
              y: 157,
              font_array: ["act_W_0.png","act_W_1.png","act_W_2.png","act_W_3.png","act_W_4.png","act_W_5.png","act_W_6.png","act_W_7.png","act_W_8.png","act_W_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'weather_W_Symbol1.png',
              unit_tc: 'weather_W_Symbol1.png',
              unit_en: 'weather_W_Symbol1.png',
              imperial_unit_sc: 'weather_W_Symbol1.png',
              imperial_unit_tc: 'weather_W_Symbol1.png',
              imperial_unit_en: 'weather_W_Symbol1.png',
              negative_image: 'weather_W_Symbol2.png',
              invalid_image: 'weather_W_Symbol2.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const temperatureUnit = hmSetting.getTemperatureUnit();
            //start of ignored block
            if (temperatureUnit == 1) {
              normal_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
                x: 146,
                y: 157,
                font_array: ["act_W_0.png","act_W_1.png","act_W_2.png","act_W_3.png","act_W_4.png","act_W_5.png","act_W_6.png","act_W_7.png","act_W_8.png","act_W_9.png"],
                padding: false,
                h_space: 0,
                unit_sc: 'weather_W_Symbol1.png',
                unit_tc: 'weather_W_Symbol1.png',
                unit_en: 'weather_W_Symbol1.png',
                imperial_unit_sc: 'weather_W_Symbol1.png',
                imperial_unit_tc: 'weather_W_Symbol1.png',
                imperial_unit_en: 'weather_W_Symbol1.png',
                negative_image: 'weather_W_Symbol2.png',
                invalid_image: 'weather_W_Symbol2.png',
                align_h: hmUI.align.CENTER_H,
                type: hmUI.data_type.WEATHER_CURRENT,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
            };
            //end of ignored block

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 256,
              day_startY: 156,
              day_sc_array: ["act_W_0.png","act_W_1.png","act_W_2.png","act_W_3.png","act_W_4.png","act_W_5.png","act_W_6.png","act_W_7.png","act_W_8.png","act_W_9.png"],
              day_tc_array: ["act_W_0.png","act_W_1.png","act_W_2.png","act_W_3.png","act_W_4.png","act_W_5.png","act_W_6.png","act_W_7.png","act_W_8.png","act_W_9.png"],
              day_en_array: ["act_W_0.png","act_W_1.png","act_W_2.png","act_W_3.png","act_W_4.png","act_W_5.png","act_W_6.png","act_W_7.png","act_W_8.png","act_W_9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 328,
              month_startY: 154,
              month_sc_array: ["Month_W_01.png","Month_W_02.png","Month_W_03.png","Month_W_04.png","Month_W_05.png","Month_W_06.png","Month_W_07.png","Month_W_08.png","Month_W_09.png","Month_W_10.png","Month_W_11.png","Month_W_12.png"],
              month_tc_array: ["Month_W_01.png","Month_W_02.png","Month_W_03.png","Month_W_04.png","Month_W_05.png","Month_W_06.png","Month_W_07.png","Month_W_08.png","Month_W_09.png","Month_W_10.png","Month_W_11.png","Month_W_12.png"],
              month_en_array: ["Month_W_01.png","Month_W_02.png","Month_W_03.png","Month_W_04.png","Month_W_05.png","Month_W_06.png","Month_W_07.png","Month_W_08.png","Month_W_09.png","Month_W_10.png","Month_W_11.png","Month_W_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 319,
              y: 177,
              week_en: ["Week_W_01.png","Week_W_02.png","Week_W_03.png","Week_W_04.png","Week_W_05.png","Week_W_06.png","Week_W_07.png"],
              week_tc: ["Week_W_01.png","Week_W_02.png","Week_W_03.png","Week_W_04.png","Week_W_05.png","Week_W_06.png","Week_W_07.png"],
              week_sc: ["Week_W_01.png","Week_W_02.png","Week_W_03.png","Week_W_04.png","Week_W_05.png","Week_W_06.png","Week_W_07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 254,
              minute_startY: 94,
              minute_array: ["Time_W_0.png","Time_W_1.png","Time_W_2.png","Time_W_3.png","Time_W_4.png","Time_W_5.png","Time_W_6.png","Time_W_7.png","Time_W_8.png","Time_W_9.png"],
              minute_zero: 1,
              minute_space: 3,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_minute_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 269,
              y: 196,
              src: 'LCD_dot.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 136,
              hour_startY: 94,
              hour_array: ["Time_W_0.png","Time_W_1.png","Time_W_2.png","Time_W_3.png","Time_W_4.png","Time_W_5.png","Time_W_6.png","Time_W_7.png","Time_W_8.png","Time_W_9.png"],
              hour_zero: 1,
              hour_space: 3,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 233,
              y: 91,
              src: 'Time_W_Dot.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'Bg.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'main5.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_heart_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 358,
              // center_y: 333,
              // start_angle: 205,
              // end_angle: 515,
              // radius: 44,
              // line_width: 10,
              // line_cap: Flat,
              // color: 0xFF4E4E4E,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_heart_rate_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 358,
              center_y: 333,
              start_angle: 205,
              end_angle: 515,
              radius: 39,
              line_width: 10,
              corner_flag: 3,
              color: 0xFF4E4E4E,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 337,
              y: 334,
              font_array: ["activity_small_0.png","activity_small_1.png","activity_small_2.png","activity_small_3.png","activity_small_4.png","activity_small_5.png","activity_small_6.png","activity_small_7.png","activity_small_8.png","activity_small_9.png"],
              padding: false,
              h_space: 3,
              invalid_image: '0_Empty.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 110,
              y: 344,
              src: 'cal_unit.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_cal_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 122,
              // center_y: 333,
              // start_angle: 205,
              // end_angle: 515,
              // radius: 44,
              // line_width: 10,
              // line_cap: Flat,
              // color: 0xFF4E4E4E,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_calorie_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 122,
              center_y: 333,
              start_angle: 205,
              end_angle: 515,
              radius: 39,
              line_width: 10,
              corner_flag: 3,
              color: 0xFF4E4E4E,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 99,
              y: 328,
              font_array: ["activity_small_0.png","activity_small_1.png","activity_small_2.png","activity_small_3.png","activity_small_4.png","activity_small_5.png","activity_small_6.png","activity_small_7.png","activity_small_8.png","activity_small_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_distance_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 225,
              // y: 347,
              // font_array: ["E_0.png","E_1.png","E_2.png","E_3.png","E_4.png","E_5.png","E_6.png","E_7.png","E_8.png","E_9.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: 0,
              // unit_en: 'Dis_KM.png',
              // imperial_unit_en: 'Dis_MI.png',
              // negative_image: 'E_0.png',
              // invalid_image: 'E_0.png',
              // dot_image: 'E_0.png',
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.DISTANCE,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_distance_TextRotate_ASCIIARRAY[0] = 'E_0.png';  // set of images with numbers
            idle_distance_TextRotate_ASCIIARRAY[1] = 'E_1.png';  // set of images with numbers
            idle_distance_TextRotate_ASCIIARRAY[2] = 'E_2.png';  // set of images with numbers
            idle_distance_TextRotate_ASCIIARRAY[3] = 'E_3.png';  // set of images with numbers
            idle_distance_TextRotate_ASCIIARRAY[4] = 'E_4.png';  // set of images with numbers
            idle_distance_TextRotate_ASCIIARRAY[5] = 'E_5.png';  // set of images with numbers
            idle_distance_TextRotate_ASCIIARRAY[6] = 'E_6.png';  // set of images with numbers
            idle_distance_TextRotate_ASCIIARRAY[7] = 'E_7.png';  // set of images with numbers
            idle_distance_TextRotate_ASCIIARRAY[8] = 'E_8.png';  // set of images with numbers
            idle_distance_TextRotate_ASCIIARRAY[9] = 'E_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              idle_distance_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 225,
                center_y: 347,
                pos_x: 225,
                pos_y: 347,
                angle: 0,
                src: 'E_0.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_distance_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            idle_distance_TextRotate_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              center_x: 225,
              center_y: 347,
              pos_x: 225,
              pos_y: 347,
              angle: 0,
              src: 'Dis_KM.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            idle_distance_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);

            if (mileageUnit == 1) {
              idle_distance_TextRotate_unit.setProperty(hmUI.prop.SRC, 'Dis_MI.png');
            };
            //end of ignored block

            idle_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 214,
              y: 326,
              font_array: ["activity_small_0.png","activity_small_1.png","activity_small_2.png","activity_small_3.png","activity_small_4.png","activity_small_5.png","activity_small_6.png","activity_small_7.png","activity_small_8.png","activity_small_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'E_0.png',
              unit_tc: 'E_0.png',
              unit_en: 'E_0.png',
              imperial_unit_sc: 'E_0.png',
              imperial_unit_tc: 'E_0.png',
              imperial_unit_en: 'E_0.png',
              dot_image: 'Dis_dot.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 235,
              y: 52,
              src: 'System_BT_OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 232,
              y: 200,
              src: 'System_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_fat_burning_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 22,
              y: 171,
              src: 'theme5.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 16,
              y: 227,
              src: 'select_main1.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 363,
              y: 170,
              image_array: ["Batt_img_01.png","Batt_img_02.png","Batt_img_03.png","Batt_img_04.png","Batt_img_05.png","Batt_img_06.png","Batt_img_07.png","Batt_img_08.png","Batt_img_09.png","Batt_img_10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 92,
              y: 71,
              src: 'Bg_B_LCD.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 240,
              // center_y: 333,
              // start_angle: 205,
              // end_angle: 515,
              // radius: 44,
              // line_width: 10,
              // line_cap: Flat,
              // color: 0xFF4E4E4E,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 240,
              center_y: 333,
              start_angle: 205,
              end_angle: 515,
              radius: 39,
              line_width: 10,
              corner_flag: 3,
              color: 0xFF4E4E4E,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 178,
              y: 401,
              font_array: ["Step_font_0.png","Step_font_1.png","Step_font_2.png","Step_font_3.png","Step_font_4.png","Step_font_5.png","Step_font_6.png","Step_font_7.png","Step_font_8.png","Step_font_9.png"],
              padding: true,
              h_space: 6,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 51,
              y: 262,
              image_array: ["Steps_01.png","Steps_02.png","Steps_03.png","Steps_04.png","Steps_05.png","Steps_06.png","Steps_07.png","Steps_08.png","Steps_09.png","Steps_10.png","Steps_11.png","Steps_12.png","Steps_13.png","Steps_14.png","Steps_15.png"],
              image_length: 15,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 146,
              y: 157,
              font_array: ["act_W_0.png","act_W_1.png","act_W_2.png","act_W_3.png","act_W_4.png","act_W_5.png","act_W_6.png","act_W_7.png","act_W_8.png","act_W_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'weather_W_Symbol1.png',
              unit_tc: 'weather_W_Symbol1.png',
              unit_en: 'weather_W_Symbol1.png',
              imperial_unit_sc: 'weather_W_Symbol1.png',
              imperial_unit_tc: 'weather_W_Symbol1.png',
              imperial_unit_en: 'weather_W_Symbol1.png',
              negative_image: 'weather_W_Symbol2.png',
              invalid_image: 'weather_W_Symbol2.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            //start of ignored block
            if (temperatureUnit == 1) {
              idle_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
                x: 146,
                y: 157,
                font_array: ["act_W_0.png","act_W_1.png","act_W_2.png","act_W_3.png","act_W_4.png","act_W_5.png","act_W_6.png","act_W_7.png","act_W_8.png","act_W_9.png"],
                padding: false,
                h_space: 0,
                unit_sc: 'weather_W_Symbol1.png',
                unit_tc: 'weather_W_Symbol1.png',
                unit_en: 'weather_W_Symbol1.png',
                imperial_unit_sc: 'weather_W_Symbol1.png',
                imperial_unit_tc: 'weather_W_Symbol1.png',
                imperial_unit_en: 'weather_W_Symbol1.png',
                negative_image: 'weather_W_Symbol2.png',
                invalid_image: 'weather_W_Symbol2.png',
                align_h: hmUI.align.CENTER_H,
                type: hmUI.data_type.WEATHER_CURRENT,
                show_level: hmUI.show_level.ONLY_AOD,
              });
            };
            //end of ignored block

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 256,
              day_startY: 156,
              day_sc_array: ["act_W_0.png","act_W_1.png","act_W_2.png","act_W_3.png","act_W_4.png","act_W_5.png","act_W_6.png","act_W_7.png","act_W_8.png","act_W_9.png"],
              day_tc_array: ["act_W_0.png","act_W_1.png","act_W_2.png","act_W_3.png","act_W_4.png","act_W_5.png","act_W_6.png","act_W_7.png","act_W_8.png","act_W_9.png"],
              day_en_array: ["act_W_0.png","act_W_1.png","act_W_2.png","act_W_3.png","act_W_4.png","act_W_5.png","act_W_6.png","act_W_7.png","act_W_8.png","act_W_9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 328,
              month_startY: 154,
              month_sc_array: ["Month_W_01.png","Month_W_02.png","Month_W_03.png","Month_W_04.png","Month_W_05.png","Month_W_06.png","Month_W_07.png","Month_W_08.png","Month_W_09.png","Month_W_10.png","Month_W_11.png","Month_W_12.png"],
              month_tc_array: ["Month_W_01.png","Month_W_02.png","Month_W_03.png","Month_W_04.png","Month_W_05.png","Month_W_06.png","Month_W_07.png","Month_W_08.png","Month_W_09.png","Month_W_10.png","Month_W_11.png","Month_W_12.png"],
              month_en_array: ["Month_W_01.png","Month_W_02.png","Month_W_03.png","Month_W_04.png","Month_W_05.png","Month_W_06.png","Month_W_07.png","Month_W_08.png","Month_W_09.png","Month_W_10.png","Month_W_11.png","Month_W_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 319,
              y: 177,
              week_en: ["Week_W_01.png","Week_W_02.png","Week_W_03.png","Week_W_04.png","Week_W_05.png","Week_W_06.png","Week_W_07.png"],
              week_tc: ["Week_W_01.png","Week_W_02.png","Week_W_03.png","Week_W_04.png","Week_W_05.png","Week_W_06.png","Week_W_07.png"],
              week_sc: ["Week_W_01.png","Week_W_02.png","Week_W_03.png","Week_W_04.png","Week_W_05.png","Week_W_06.png","Week_W_07.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 254,
              minute_startY: 94,
              minute_array: ["Time_W_0.png","Time_W_1.png","Time_W_2.png","Time_W_3.png","Time_W_4.png","Time_W_5.png","Time_W_6.png","Time_W_7.png","Time_W_8.png","Time_W_9.png"],
              minute_zero: 1,
              minute_space: 3,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_minute_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 269,
              y: 196,
              src: 'LCD_dot.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 136,
              hour_startY: 94,
              hour_array: ["Time_W_0.png","Time_W_1.png","Time_W_2.png","Time_W_3.png","Time_W_4.png","Time_W_5.png","Time_W_6.png","Time_W_7.png","Time_W_8.png","Time_W_9.png"],
              hour_zero: 1,
              hour_space: 3,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 233,
              y: 91,
              src: 'Time_W_Dot.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 224,
              y: 91,
              w: 32,
              h: 48,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 68,
              y: 107,
              w: 58,
              h: 44,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 221,
              y: 186,
              w: 37,
              h: 40,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 128,
              y: 149,
              w: 80,
              h: 52,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 91,
              y: 301,
              w: 66,
              h: 69,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 314,
              y: 335,
              w: 87,
              h: 42,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 315,
              y: 291,
              w: 87,
              h: 40,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 183,
              y: 444,
              w: 111,
              h: 28,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 209,
              y: 304,
              w: 63,
              h: 59,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'SportListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 261,
              y: 155,
              w: 101,
              h: 35,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 382,
              y: 184,
              w: 60,
              h: 74,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PowerSaveHintScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 11,
              y: 161,
              w: 91,
              h: 36,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                // change theme
click_Color()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 278,
              y: 200,
              w: 64,
              h: 62,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                //LCD Switch
click_elemente()
const result = hmSetting.setScreenOff()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 13,
              y: 231,
              w: 176,
              h: 47,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                //Change Background
click_ColorB()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            console.log('user_script_end.js');
            // start user_script_end.js

function time_animation_move(){
        let time = hmSensor.createSensor(hmSensor.id.TIME);
        let S = time.second
      normal_motion_animation_img_1.setProperty(hmUI.prop.SRC, "animation/"+"S_" + parseInt(S) + ".png"); // Seconds

}
let intervalId =''
function startInterval() {
intervalId = setInterval(time_animation_move, 1000); // เรียกใช้ฟังก์ชัน scale_call() ทุก 1 วินาที (1000 มิลลิวินาที)
}
startInterval();
            // end user_script_end.js

            //start of ignored block
            function text_update() {
              console.log('text_update()');

              console.log('update text rotate DISTANCE');
              let distanceCurrent = distance.current;
              let normal_distance_rotate_string = (distanceCurrent / 1000).toFixed(2);

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  normal_distance_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_distance_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
                if (distanceCurrent != null && distanceCurrent != undefined && isFinite(distanceCurrent) && normal_distance_rotate_string.length > 0 && normal_distance_rotate_string.length <= 5) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of normal_distance_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_distance_TextRotate[index].setProperty(hmUI.prop.POS_X, 225 + img_offset);
                      normal_distance_TextRotate[index].setProperty(hmUI.prop.SRC, normal_distance_TextRotate_ASCIIARRAY[charCode]);
                      normal_distance_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_distance_TextRotate_img_width;
                      index++;
                    }  // end if digit
                    else { 
                      normal_distance_TextRotate[index].setProperty(hmUI.prop.POS_X, 225 + img_offset);
                      normal_distance_TextRotate[index].setProperty(hmUI.prop.SRC, 'E_0.png');
                      normal_distance_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_distance_TextRotate_dot_width;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                  normal_distance_TextRotate_unit.setProperty(hmUI.prop.POS_X, 225 + img_offset);
                  normal_distance_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite
                else {
                  normal_distance_TextRotate[0].setProperty(hmUI.prop.POS_X, 225);
                  normal_distance_TextRotate[0].setProperty(hmUI.prop.SRC, 'E_0.png');
                  normal_distance_TextRotate[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

              console.log('update text rotate DISTANCE');
              let idle_distance_rotate_string = (distanceCurrent / 1000).toFixed(2);

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  idle_distance_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                idle_distance_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
                if (distanceCurrent != null && distanceCurrent != undefined && isFinite(distanceCurrent) && idle_distance_rotate_string.length > 0 && idle_distance_rotate_string.length <= 5) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of idle_distance_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_distance_TextRotate[index].setProperty(hmUI.prop.POS_X, 225 + img_offset);
                      idle_distance_TextRotate[index].setProperty(hmUI.prop.SRC, idle_distance_TextRotate_ASCIIARRAY[charCode]);
                      idle_distance_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_distance_TextRotate_img_width;
                      index++;
                    }  // end if digit
                    else { 
                      idle_distance_TextRotate[index].setProperty(hmUI.prop.POS_X, 225 + img_offset);
                      idle_distance_TextRotate[index].setProperty(hmUI.prop.SRC, 'E_0.png');
                      idle_distance_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_distance_TextRotate_dot_width;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                  idle_distance_TextRotate_unit.setProperty(hmUI.prop.POS_X, 225 + img_offset);
                  idle_distance_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite
                else {
                  idle_distance_TextRotate[0].setProperty(hmUI.prop.POS_X, 225);
                  idle_distance_TextRotate[0].setProperty(hmUI.prop.SRC, 'E_0.png');
                  idle_distance_TextRotate[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

            };

            //end of ignored block
            function scale_call() {
              console.log('scale_call()');

                console.log('update scales HEART');
                
                let valueHeartRate = heart_rate.last;
                let targetHeartRate = 179;
                let progressHeartRate = (valueHeartRate - 71)/(targetHeartRate - 71);
                if (progressHeartRate < 0) progressHeartRate = 0;
                if (progressHeartRate > 1) progressHeartRate = 1;
                let progress_cs_normal_heart_rate = progressHeartRate;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_heart_rate_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_heart_rate * 100);
                  if (normal_heart_rate_circle_scale) {
                    normal_heart_rate_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 358,
                      center_y: 333,
                      start_angle: 205,
                      end_angle: 515,
                      radius: 39,
                      line_width: 10,
                      corner_flag: 3,
                      color: 0xFF4E4E4E,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales CALORIE');
                
                let valueCalories = calorie.current;
                let targetCalories = calorie.target;
                let progressCalories = valueCalories/targetCalories;
                if (progressCalories > 1) progressCalories = 1;
                let progress_cs_normal_calorie = progressCalories;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_calorie_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_calorie * 100);
                  if (normal_calorie_circle_scale) {
                    normal_calorie_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 122,
                      center_y: 333,
                      start_angle: 205,
                      end_angle: 515,
                      radius: 39,
                      line_width: 10,
                      corner_flag: 3,
                      color: 0xFF4E4E4E,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_cs_normal_step = progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_step * 100);
                  if (normal_step_circle_scale) {
                    normal_step_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 240,
                      center_y: 333,
                      start_angle: 205,
                      end_angle: 515,
                      radius: 39,
                      line_width: 10,
                      corner_flag: 3,
                      color: 0xFF4E4E4E,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales HEART');
                let progress_cs_idle_heart_rate = progressHeartRate;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_heart_rate_circle_scale_circle_scale
                  let level = Math.round(progress_cs_idle_heart_rate * 100);
                  if (idle_heart_rate_circle_scale) {
                    idle_heart_rate_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 358,
                      center_y: 333,
                      start_angle: 205,
                      end_angle: 515,
                      radius: 39,
                      line_width: 10,
                      corner_flag: 3,
                      color: 0xFF4E4E4E,
                      show_level: hmUI.show_level.ONLY_AOD,
                      level: level,
                    });
                  };
                };

                console.log('update scales CALORIE');
                let progress_cs_idle_calorie = progressCalories;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_calorie_circle_scale_circle_scale
                  let level = Math.round(progress_cs_idle_calorie * 100);
                  if (idle_calorie_circle_scale) {
                    idle_calorie_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 122,
                      center_y: 333,
                      start_angle: 205,
                      end_angle: 515,
                      radius: 39,
                      line_width: 10,
                      corner_flag: 3,
                      color: 0xFF4E4E4E,
                      show_level: hmUI.show_level.ONLY_AOD,
                      level: level,
                    });
                  };
                };

                console.log('update scales STEP');
                let progress_cs_idle_step = progressStep;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_step_circle_scale_circle_scale
                  let level = Math.round(progress_cs_idle_step * 100);
                  if (idle_step_circle_scale) {
                    idle_step_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 240,
                      center_y: 333,
                      start_angle: 205,
                      end_angle: 515,
                      radius: 39,
                      line_width: 10,
                      corner_flag: 3,
                      color: 0xFF4E4E4E,
                      show_level: hmUI.show_level.ONLY_AOD,
                      level: level,
                    });
                  };
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                text_update();

                let nawAnimationTime = now.utc;;
                
                let delay_anim_motion_1 = 0;
                let repeat_anim_motion_1 = 1000;
                delay_anim_motion_1 = repeat_anim_motion_1 - (nawAnimationTime - normal_motion_animation_lastTime_1);
                if(delay_anim_motion_1 < 0) delay_anim_motion_1 = 0; 
                if((nawAnimationTime - normal_motion_animation_lastTime_1) > repeat_anim_motion_1) {
                  normal_motion_animation_count_1 = 0;
                  timer_anim_motion_1_mirror = false;
                };

                if (!timer_anim_motion_1) {
                  timer_anim_motion_1 = timer.createTimer(delay_anim_motion_1, repeat_anim_motion_1, (function (option) {
                    anim_motion_1_complete_call()
                  })); // end timer create
                };

              }),
              pause_call: (function () {
                console.log('pause_call()');
                stop_anim_motion_1();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
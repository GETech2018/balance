﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start
        let btn_bezel = ''
        let bezel_num = 1
        let bezel_all = 6
                
        let normal_background_bg_img = ''
        let normal_image_img = ''
        let normal_battery_icon_img = ''
        let normal_battery_circle_scale = ''        
        let normal_date_img_date_week_img = ''        
        let normal_day_text_font = ''
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_text_font = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_font = ''               
        let normal_step_icon_img = ''
        let normal_battery_current_text_font = ''
        let normal_analog_clock_pro_hour_pointer_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_hour_tens_img = ''
        let normal_hour_units_img = ''        
        let normal_analog_clock_pro_minute_pointer_img = ''
        let normal_analog_clock_pro_second_pointer_img = ''
        let normal_minute_tens_img = ''
        let normal_minute_units_img = ''
        let normal_timerUpdateSec = undefined;
        let idle_background_bg = ''
        let idle_image_img = ''
        let idle_analog_clock_pro_hour_pointer_img = ''
        let idle_analog_clock_pro_minute_pointer_img = ''
        let aod_hour_tens_img = ''
        let aod_hour_units_img = ''
        let aod_minute_tens_img = ''
        let aod_minute_units_img = ''          
        let normal_step_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_battery_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_sleep_jumpable_img_click = ''        
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
            function click_Bezel() {
              if(bezel_num>=bezel_all) {bezel_num=1;}
              else { bezel_num=bezel_num+1;}
              hmUI.showToast({text: "Цвет " + parseInt(bezel_num) });
                normal_background_bg_img.setProperty(hmUI.prop.SRC, "osn_" + parseInt(bezel_num) + ".png");
                normal_battery_icon_img.setProperty(hmUI.prop.SRC, "podlbt_" + parseInt(bezel_num) + ".png");
                normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.SRC, "M_" + parseInt(bezel_num) + ".png");
                normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.SRC, "S_" + parseInt(bezel_num) + ".png");
                normal_step_icon_img.setProperty(hmUI.prop.SRC, "logo_" + parseInt(bezel_num) + ".png");

            } 
                
            // FontName: IntroFriday.ttf; FontSize: 24
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 401,
              h: 36,
              text_size: 24,
              char_space: 3,
              line_space: 0,
              font: 'fonts/IntroFriday.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });                    
                
            // FontName: IntroFriday.ttf; FontSize: 25
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 336,
              h: 37,
              text_size: 25,
              char_space: 0,
              line_space: 0,
              font: 'fonts/IntroFriday.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: IntroFriday.ttf; FontSize: 24; Cache: full
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 28,
              h: 28,
              text_size: 24,
              char_space: 0,
              line_space: 0,
              font: 'fonts/IntroFriday.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.NONE,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'osn_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'podl_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 211,
              y: 410,
              src: 'podlbt_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 239,
              // center_y: 439,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 29,
              // line_width: 8,
              // line_cap: Flat,
              // color: 0xFF000000,
              // mirror: False,
              // inversion: True,
              // alpha: 255,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            let screenType = hmSetting.getScreenType();
            normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 239,
              center_y: 439,
              start_angle: 360,
              end_angle: 0,
              radius: 25,
              line_width: 8,
              corner_flag: 3,
              color: 0xFF000000,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 178,
              y: 18,
              week_en: ["D_0.png","D_1.png","D_2.png","D_3.png","D_4.png","D_5.png","D_6.png"],
              week_tc: ["D_0.png","D_1.png","D_2.png","D_3.png","D_4.png","D_5.png","D_6.png"],
              week_sc: ["D_0.png","D_1.png","D_2.png","D_3.png","D_4.png","D_5.png","D_6.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });            

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function() {
              time_update(true);
            });
          
            normal_day_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 190,
              y: 49,
              w: 100,
              h: 30,
              text_size: 24,
              char_space: 3,
              font: 'fonts/IntroFriday.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 406,
              y: 217,
              src: 'heart.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 363,
              y: 238,
              w: 150,
              h: 30,
              text_size: 24,
              char_space: 3,
              font: 'fonts/IntroFriday.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });            

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 13,
              y: 208,
              image_array: ["weather_0.png","weather_1.png","weather_2.png","weather_3.png","weather_4.png","weather_5.png","weather_6.png","weather_7.png","weather_8.png","weather_9.png","weather_10.png","weather_11.png","weather_12.png","weather_13.png","weather_14.png","weather_15.png","weather_16.png","weather_17.png","weather_18.png","weather_19.png","weather_20.png","weather_21.png","weather_22.png","weather_23.png","weather_24.png","weather_25.png","weather_26.png","weather_27.png","weather_28.png"],
              image_length: 29,
              // alpha: 80,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level.setAlpha(80);

            normal_temperature_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: -1,
              y: 238,
              w: 100,
              h: 30,
              text_size: 24,
              char_space: 3,
              font: 'fonts/IntroFriday.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              unit_type: 1,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });           
            

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'logo_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 165,
              y: 429,
              w: 150,
              h: 50,
              text_size: 25,
              char_space: 0,
              font: 'fonts/IntroFriday.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });            

            const deviceInfo = hmSetting.getDeviceInfo();
            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.MINUTEEND, function() {
              let updateHour = timeSensor.minute == 0;

              time_update(updateHour, true);
            });

            // normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'H_1.png',
              // center_x: 240,
              // center_y: 240,
              // x: 239,
              // y: 239,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.hour,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 239,
              pos_y: 240 - 239,
              center_x: 240,
              center_y: 240,
              src: 'H_1.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 231,
              y: 381,
              src: 'bt_off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 230,
              y: 74,
              src: 'alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });            

            const digit_array_hours = ["HH_0.png","HH_1.png","HH_2.png","HH_3.png","HH_4.png","HH_5.png","HH_6.png","HH_7.png","HH_8.png","HH_9.png"];
            const digit_array_minutes = ["HM_0.png","HM_1.png","HM_2.png","HM_3.png","HM_4.png","HM_5.png","HM_6.png","HM_7.png","HM_8.png","HM_9.png"];
            const radius_hours = 122;
            const radius_minutes = 168;
            const digit_w_hours = 27;
            const digit_h_hours = 38;
            const digit_w_minutes = 27;
            const digit_h_minutes = 38;
            const digit_space = -12;
            const sep_hours = digit_h_hours + digit_space;
            const half_sep_hours = sep_hours / 2;
            const sep_minutes = digit_h_minutes + digit_space;
            const half_sep_minutes = sep_minutes / 2;

            normal_hour_tens_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              src: 'HH_0.png',
              pos_x: 0,
              pos_y: 0,
              center_x: 240,
              center_y: 240,
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_hour_units_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              src: 'HH_0.png',
              pos_x: 0,
              pos_y: 0,
              center_x: 240,
              center_y: 240,
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });            

            // normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'M_1.png',
              // center_x: 240,
              // center_y: 240,
              // x: 28,
              // y: 215,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.minute,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 28,
              pos_y: 240 - 215,
              center_x: 240,
              center_y: 240,
              src: 'M_1.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_minute_tens_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              src: 'HM_0.png',
              pos_x: 0,
              pos_y: 0,
              center_x: 240,
              center_y: 240,
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_minute_units_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              src: 'HM_0.png',
              pos_x: 0,
              pos_y: 0,
              center_x: 240,
              center_y: 240,
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });            

            // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'S_1.png',
              // center_x: 240,
              // center_y: 240,
              // x: 240,
              // y: 240,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 240,
              pos_y: 240 - 240,
              center_x: 240,
              center_y: 240,
              src: 'S_1.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'podl_1.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'H_1.png',
              // center_x: 240,
              // center_y: 240,
              // x: 239,
              // y: 239,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.hour,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });


            idle_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 239,
              pos_y: 240 - 239,
              center_x: 240,
              center_y: 240,
              src: 'H_1.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            aod_hour_tens_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              src: 'HH_0.png',
              pos_x: 0,
              pos_y: 0,
              center_x: 240,
              center_y: 240,
              angle: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            aod_hour_units_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              src: 'HH_0.png',
              pos_x: 0,
              pos_y: 0,
              center_x: 240,
              center_y: 240,
              angle: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });            

            // idle_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'MAOD_1.png',
              // center_x: 240,
              // center_y: 240,
              // x: 28,
              // y: 215,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.minute,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });


            idle_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 28,
              pos_y: 240 - 215,
              center_x: 240,
              center_y: 240,
              src: 'MAOD_1.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            aod_minute_tens_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              src: 'HM_0.png',
              pos_x: 0,
              pos_y: 0,
              center_x: 240,
              center_y: 240,
              angle: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            aod_minute_units_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              src: 'HM_0.png',
              pos_x: 0,
              pos_y: 0,
              center_x: 240,
              center_y: 240,
              angle: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });     
            
            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 339,
              y: 72,
              w: 60,
              h: 60,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 407,
              y: 220,
              w: 60,
              h: 60,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 210,
              y: 408,
              w: 60,
              h: 60,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 15,
              y: 209,
              w: 60,
              h: 60,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 78,
              y: 341,
              w: 60,
              h: 60,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 344,
              y: 340,
              w: 60,
              h: 60,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 212,
              y: 70,
              w: 60,
              h: 60,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sleep_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 79,
              y: 74,
              w: 60,
              h: 60,
              type: hmUI.data_type.SLEEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });  
            
            btn_bezel = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 206,
              y: 206,
              text: '',
              w: 60,
              h: 60,
              normal_src: 'clean.png',
              press_src: 'clean.png',
              click_func: () => {
               click_Bezel();
               
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btn_bezel.setProperty(hmUI.prop.VISIBLE, true);            

            //#region time_update
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let millisecond = timeSensor.millisecond;
              let format_hour = timeSensor.format_hour;

              let timeFormat = hmSetting.getTimeFormat();
              let displayHour = (timeFormat == 0) ? (hour % 12 || 12) : hour;  
                            

              console.log('day font');
              if (updateHour) {
                let normal_dayStr = timeSensor.day.toString();
                normal_day_text_font.setProperty(hmUI.prop.TEXT, normal_dayStr );
              };              

              if (updateMinute) { // Hour Pointer
                let normal_hour = hour;
                let normal_fullAngle_hour = 360;
                if (normal_hour > 11) normal_hour -= 12;
                let normal_angle_hour = 0 + normal_fullAngle_hour*normal_hour/12 + (normal_fullAngle_hour/12)*minute/60;
                if (normal_analog_clock_pro_hour_pointer_img) normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_hour);
              };

              if (updateMinute) { // Minute Pointer
                let normal_fullAngle_minute = 360;
                let normal_angle_minute = 0 + normal_fullAngle_minute*minute/60;
                if (normal_analog_clock_pro_minute_pointer_img) normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_minute);
              };

              // Second Pointer
              let normal_fullAngle_second = 360;
              let smooth_second = (timeSensor.utc % 60000) / 1000;
              let normal_angle_second = 0 + normal_fullAngle_second * smooth_second / 60;
              if (normal_analog_clock_pro_second_pointer_img) normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_second);

              if (updateMinute) {
                // Update hours digital
                let hour_tens = Math.floor(displayHour / 10);
                let hour_units = displayHour % 10;
                let angle_hour = 0;
                if (updateMinute) { // recalculate angle_hour
                  let normal_hour = hour;
                  if (normal_hour > 11) normal_hour -= 12;
                  angle_hour = 0 + 360 * normal_hour / 12 + (30) * minute / 60;
                }
                let flip_hour = (angle_hour <= 180);
                let angle_digit_hour = (flip_hour ? angle_hour + 180 : angle_hour) + 90;
                let rad_hour = angle_hour * Math.PI / 180;
                let sin_hour = Math.sin(rad_hour);
                let cos_hour = Math.cos(rad_hour);
                let inner_r_hour = radius_hours - half_sep_hours;
                let outer_r_hour = radius_hours + half_sep_hours;
                let r_tens_hour = flip_hour ? inner_r_hour : outer_r_hour;
                let r_units_hour = flip_hour ? outer_r_hour : inner_r_hour;
                // tens
                let unrot_cx_t_hour = 240 + r_tens_hour * sin_hour;
                let unrot_cy_t_hour = 240 - r_tens_hour * cos_hour;
                let pos_x_t_hour = unrot_cx_t_hour - digit_w_hours / 2;
                let pos_y_t_hour = unrot_cy_t_hour - digit_h_hours / 2;
                if (normal_hour_tens_img) {
                  normal_hour_tens_img.setProperty(hmUI.prop.SRC, digit_array_hours[hour_tens]);
                  normal_hour_tens_img.setProperty(hmUI.prop.POS_X, Math.round(pos_x_t_hour));
                  normal_hour_tens_img.setProperty(hmUI.prop.POS_Y, Math.round(pos_y_t_hour));
                  normal_hour_tens_img.setProperty(hmUI.prop.CENTER_X, Math.round(unrot_cx_t_hour));
                  normal_hour_tens_img.setProperty(hmUI.prop.CENTER_Y, Math.round(unrot_cy_t_hour));
                  normal_hour_tens_img.setProperty(hmUI.prop.ANGLE, angle_digit_hour);
                }
                if (aod_hour_tens_img) {
                  aod_hour_tens_img.setProperty(hmUI.prop.SRC, digit_array_hours[hour_tens]);
                  aod_hour_tens_img.setProperty(hmUI.prop.POS_X, Math.round(pos_x_t_hour));
                  aod_hour_tens_img.setProperty(hmUI.prop.POS_Y, Math.round(pos_y_t_hour));
                  aod_hour_tens_img.setProperty(hmUI.prop.CENTER_X, Math.round(unrot_cx_t_hour));
                  aod_hour_tens_img.setProperty(hmUI.prop.CENTER_Y, Math.round(unrot_cy_t_hour));
                  aod_hour_tens_img.setProperty(hmUI.prop.ANGLE, angle_digit_hour);
                }
                // units
                let unrot_cx_u_hour = 240 + r_units_hour * sin_hour;
                let unrot_cy_u_hour = 240 - r_units_hour * cos_hour;
                let pos_x_u_hour = unrot_cx_u_hour - digit_w_hours / 2;
                let pos_y_u_hour = unrot_cy_u_hour - digit_h_hours / 2;
                if (normal_hour_units_img) {
                  normal_hour_units_img.setProperty(hmUI.prop.SRC, digit_array_hours[hour_units]);
                  normal_hour_units_img.setProperty(hmUI.prop.POS_X, Math.round(pos_x_u_hour));
                  normal_hour_units_img.setProperty(hmUI.prop.POS_Y, Math.round(pos_y_u_hour));
                  normal_hour_units_img.setProperty(hmUI.prop.CENTER_X, Math.round(unrot_cx_u_hour));
                  normal_hour_units_img.setProperty(hmUI.prop.CENTER_Y, Math.round(unrot_cy_u_hour));
                  normal_hour_units_img.setProperty(hmUI.prop.ANGLE, angle_digit_hour);
                }
                if (aod_hour_units_img) {
                  aod_hour_units_img.setProperty(hmUI.prop.SRC, digit_array_hours[hour_units]);
                  aod_hour_units_img.setProperty(hmUI.prop.POS_X, Math.round(pos_x_u_hour));
                  aod_hour_units_img.setProperty(hmUI.prop.POS_Y, Math.round(pos_y_u_hour));
                  aod_hour_units_img.setProperty(hmUI.prop.CENTER_X, Math.round(unrot_cx_u_hour));
                  aod_hour_units_img.setProperty(hmUI.prop.CENTER_Y, Math.round(unrot_cy_u_hour));
                  aod_hour_units_img.setProperty(hmUI.prop.ANGLE, angle_digit_hour);
                }

                // Update minutes digital
                let minute_tens = Math.floor(minute / 10);
                let minute_units = minute % 10;
                let angle_minute = 0 + 360 * minute / 60;
                let flip_minute = (minute <= 30);
                let angle_digit_minute = (flip_minute ? angle_minute + 180 : angle_minute) + 90;
                let rad_minute = angle_minute * Math.PI / 180;
                let sin_minute = Math.sin(rad_minute);
                let cos_minute = Math.cos(rad_minute);
                let inner_r_minute = radius_minutes - half_sep_minutes;
                let outer_r_minute = radius_minutes + half_sep_minutes;
                let r_tens_minute = flip_minute ? inner_r_minute : outer_r_minute;
                let r_units_minute = flip_minute ? outer_r_minute : inner_r_minute;
                // tens
                let unrot_cx_t_minute = 240 + r_tens_minute * sin_minute;
                let unrot_cy_t_minute = 240 - r_tens_minute * cos_minute;
                let pos_x_t_minute = unrot_cx_t_minute - digit_w_minutes / 2;
                let pos_y_t_minute = unrot_cy_t_minute - digit_h_minutes / 2;
                if (normal_minute_tens_img) {
                  normal_minute_tens_img.setProperty(hmUI.prop.SRC, digit_array_minutes[minute_tens]);
                  normal_minute_tens_img.setProperty(hmUI.prop.POS_X, Math.round(pos_x_t_minute));
                  normal_minute_tens_img.setProperty(hmUI.prop.POS_Y, Math.round(pos_y_t_minute));
                  normal_minute_tens_img.setProperty(hmUI.prop.CENTER_X, Math.round(unrot_cx_t_minute));
                  normal_minute_tens_img.setProperty(hmUI.prop.CENTER_Y, Math.round(unrot_cy_t_minute));
                  normal_minute_tens_img.setProperty(hmUI.prop.ANGLE, angle_digit_minute);
                }
                if (aod_minute_tens_img) {
                  aod_minute_tens_img.setProperty(hmUI.prop.SRC, digit_array_minutes[minute_tens]);
                  aod_minute_tens_img.setProperty(hmUI.prop.POS_X, Math.round(pos_x_t_minute));
                  aod_minute_tens_img.setProperty(hmUI.prop.POS_Y, Math.round(pos_y_t_minute));
                  aod_minute_tens_img.setProperty(hmUI.prop.CENTER_X, Math.round(unrot_cx_t_minute));
                  aod_minute_tens_img.setProperty(hmUI.prop.CENTER_Y, Math.round(unrot_cy_t_minute));
                  aod_minute_tens_img.setProperty(hmUI.prop.ANGLE, angle_digit_minute);
                }
                // units
                let unrot_cx_u_minute = 240 + r_units_minute * sin_minute;
                let unrot_cy_u_minute = 240 - r_units_minute * cos_minute;
                let pos_x_u_minute = unrot_cx_u_minute - digit_w_minutes / 2;
                let pos_y_u_minute = unrot_cy_u_minute - digit_h_minutes / 2;
                if (normal_minute_units_img) {
                  normal_minute_units_img.setProperty(hmUI.prop.SRC, digit_array_minutes[minute_units]);
                  normal_minute_units_img.setProperty(hmUI.prop.POS_X, Math.round(pos_x_u_minute));
                  normal_minute_units_img.setProperty(hmUI.prop.POS_Y, Math.round(pos_y_u_minute));
                  normal_minute_units_img.setProperty(hmUI.prop.CENTER_X, Math.round(unrot_cx_u_minute));
                  normal_minute_units_img.setProperty(hmUI.prop.CENTER_Y, Math.round(unrot_cy_u_minute));
                  normal_minute_units_img.setProperty(hmUI.prop.ANGLE, angle_digit_minute);
                }
                if (aod_minute_units_img) {
                  aod_minute_units_img.setProperty(hmUI.prop.SRC, digit_array_minutes[minute_units]);
                  aod_minute_units_img.setProperty(hmUI.prop.POS_X, Math.round(pos_x_u_minute));
                  aod_minute_units_img.setProperty(hmUI.prop.POS_Y, Math.round(pos_y_u_minute));
                  aod_minute_units_img.setProperty(hmUI.prop.CENTER_X, Math.round(unrot_cx_u_minute));
                  aod_minute_units_img.setProperty(hmUI.prop.CENTER_Y, Math.round(unrot_cy_u_minute));
                  aod_minute_units_img.setProperty(hmUI.prop.ANGLE, angle_digit_minute);
                }
              }              

              if (updateMinute) { // Hour Pointer
                let idle_hour = hour;
                let idle_fullAngle_hour = 360;
                if (idle_hour > 11) idle_hour -= 12;
                let idle_angle_hour = 0 + idle_fullAngle_hour*idle_hour/12 + (idle_fullAngle_hour/12)*minute/60;
                if (idle_analog_clock_pro_hour_pointer_img) idle_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.ANGLE, idle_angle_hour);
              };

              if (updateMinute) { // Minute Pointer
                let idle_fullAngle_minute = 360;
                let idle_angle_minute = 0 + idle_fullAngle_minute*minute/60;
                if (idle_analog_clock_pro_minute_pointer_img) idle_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.ANGLE, idle_angle_minute);
              };

            };

            //#endregion
            function scale_call() {
              console.log('scale_call()');

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_cs_normal_battery = 1 - progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_battery * 100);
                  if (normal_battery_circle_scale) {
                    normal_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 239,
                      center_y: 439,
                      start_angle: 360,
                      end_angle: 0,
                      radius: 25,
                      line_width: 8,
                      corner_flag: 3,
                      color: 0xFF000000,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                time_update(true, true);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSec) {
                    let animDelay = 0; // Start immediately
                    let animRepeat = 50; // Update every 50ms for smooth second hand
                    normal_timerUpdateSec = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, false);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerUpdateSec) {
                  timer.stopTimer(normal_timerUpdateSec);
                  normal_timerUpdateSec = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
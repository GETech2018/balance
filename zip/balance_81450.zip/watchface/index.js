﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_month_TextRotate = new Array(2);
        let normal_month_TextRotate_ASCIIARRAY = new Array(10);
        let normal_month_TextRotate_img_width = 30;
        let normal_timerTextUpdate = undefined;
        let normal_day_TextRotate = new Array(2);
        let normal_day_TextRotate_ASCIIARRAY = new Array(10);
        let normal_day_TextRotate_img_width = 30;
        let normal_hour_TextRotate = new Array(2);
        let normal_hour_TextRotate_ASCIIARRAY = new Array(10);
        let normal_hour_TextRotate_img_width = 100;
        let normal_minute_TextRotate = new Array(2);
        let normal_minute_TextRotate_ASCIIARRAY = new Array(10);
        let normal_minute_TextRotate_img_width = 100;
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg_img = ''
        let idle_month_TextRotate = new Array(2);
        let idle_month_TextRotate_ASCIIARRAY = new Array(10);
        let idle_month_TextRotate_img_width = 30;
        let idle_timerTextUpdate = undefined;
        let idle_day_TextRotate = new Array(2);
        let idle_day_TextRotate_ASCIIARRAY = new Array(10);
        let idle_day_TextRotate_img_width = 30;
        let idle_hour_TextRotate = new Array(2);
        let idle_hour_TextRotate_ASCIIARRAY = new Array(10);
        let idle_hour_TextRotate_img_width = 100;
        let idle_minute_TextRotate = new Array(2);
        let idle_minute_TextRotate_ASCIIARRAY = new Array(10);
        let idle_minute_TextRotate_img_width = 100;
        let timeSensor = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'Scales_and_numbers1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_month_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 168,
              // y: 312,
              // font_array: ["b0.png","b1.png","b2.png","b3.png","b4.png","b5.png","b6.png","b7.png","b8.png","b9.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: 0,
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.MONTH,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_month_TextRotate_ASCIIARRAY[0] = 'b0.png';  // set of images with numbers
            normal_month_TextRotate_ASCIIARRAY[1] = 'b1.png';  // set of images with numbers
            normal_month_TextRotate_ASCIIARRAY[2] = 'b2.png';  // set of images with numbers
            normal_month_TextRotate_ASCIIARRAY[3] = 'b3.png';  // set of images with numbers
            normal_month_TextRotate_ASCIIARRAY[4] = 'b4.png';  // set of images with numbers
            normal_month_TextRotate_ASCIIARRAY[5] = 'b5.png';  // set of images with numbers
            normal_month_TextRotate_ASCIIARRAY[6] = 'b6.png';  // set of images with numbers
            normal_month_TextRotate_ASCIIARRAY[7] = 'b7.png';  // set of images with numbers
            normal_month_TextRotate_ASCIIARRAY[8] = 'b8.png';  // set of images with numbers
            normal_month_TextRotate_ASCIIARRAY[9] = 'b9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              normal_month_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 168,
                center_y: 312,
                pos_x: 168,
                pos_y: 312,
                angle: 0,
                src: 'b0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_month_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            let screenType = hmSetting.getScreenType();
            // normal_day_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 258,
              // y: 312,
              // font_array: ["b0.png","b1.png","b2.png","b3.png","b4.png","b5.png","b6.png","b7.png","b8.png","b9.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: 0,
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.DAY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_day_TextRotate_ASCIIARRAY[0] = 'b0.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[1] = 'b1.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[2] = 'b2.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[3] = 'b3.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[4] = 'b4.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[5] = 'b5.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[6] = 'b6.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[7] = 'b7.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[8] = 'b8.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[9] = 'b9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              normal_day_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 258,
                center_y: 312,
                pos_x: 258,
                pos_y: 312,
                angle: 0,
                src: 'b0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_day_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            // normal_hour_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 50,
              // y: 96,
              // font_array: ["a0.png","a1.png","a2.png","a3.png","a4.png","a5.png","a6.png","a7.png","a8.png","a9.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: 0,
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.HOUR,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_hour_TextRotate_ASCIIARRAY[0] = 'a0.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[1] = 'a1.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[2] = 'a2.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[3] = 'a3.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[4] = 'a4.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[5] = 'a5.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[6] = 'a6.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[7] = 'a7.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[8] = 'a8.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[9] = 'a9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              normal_hour_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 50,
                center_y: 96,
                pos_x: 50,
                pos_y: 96,
                angle: 0,
                src: 'a0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_hour_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            // normal_minute_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 231,
              // y: 96,
              // font_array: ["a0.png","a1.png","a2.png","a3.png","a4.png","a5.png","a6.png","a7.png","a8.png","a9.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: 0,
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.MINUTE,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_minute_TextRotate_ASCIIARRAY[0] = 'a0.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[1] = 'a1.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[2] = 'a2.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[3] = 'a3.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[4] = 'a4.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[5] = 'a5.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[6] = 'a6.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[7] = 'a7.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[8] = 'a8.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[9] = 'a9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              normal_minute_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 231,
                center_y: 96,
                pos_x: 231,
                pos_y: 96,
                angle: 0,
                src: 'a0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_minute_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'secs.png',
              second_centerX: 242,
              second_centerY: 241,
              second_posX: 94,
              second_posY: 220,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'Scales_and_numbers2.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_month_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 123,
              // y: 241,
              // font_array: ["b0.png","b1.png","b2.png","b3.png","b4.png","b5.png","b6.png","b7.png","b8.png","b9.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: 45,
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.MONTH,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_month_TextRotate_ASCIIARRAY[0] = 'b0.png';  // set of images with numbers
            idle_month_TextRotate_ASCIIARRAY[1] = 'b1.png';  // set of images with numbers
            idle_month_TextRotate_ASCIIARRAY[2] = 'b2.png';  // set of images with numbers
            idle_month_TextRotate_ASCIIARRAY[3] = 'b3.png';  // set of images with numbers
            idle_month_TextRotate_ASCIIARRAY[4] = 'b4.png';  // set of images with numbers
            idle_month_TextRotate_ASCIIARRAY[5] = 'b5.png';  // set of images with numbers
            idle_month_TextRotate_ASCIIARRAY[6] = 'b6.png';  // set of images with numbers
            idle_month_TextRotate_ASCIIARRAY[7] = 'b7.png';  // set of images with numbers
            idle_month_TextRotate_ASCIIARRAY[8] = 'b8.png';  // set of images with numbers
            idle_month_TextRotate_ASCIIARRAY[9] = 'b9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              idle_month_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 123,
                center_y: 241,
                pos_x: 123,
                pos_y: 241,
                angle: 45,
                src: 'b0.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_month_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            // idle_day_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 209,
              // y: 324,
              // font_array: ["b0.png","b1.png","b2.png","b3.png","b4.png","b5.png","b6.png","b7.png","b8.png","b9.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: 45,
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.DAY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_day_TextRotate_ASCIIARRAY[0] = 'b0.png';  // set of images with numbers
            idle_day_TextRotate_ASCIIARRAY[1] = 'b1.png';  // set of images with numbers
            idle_day_TextRotate_ASCIIARRAY[2] = 'b2.png';  // set of images with numbers
            idle_day_TextRotate_ASCIIARRAY[3] = 'b3.png';  // set of images with numbers
            idle_day_TextRotate_ASCIIARRAY[4] = 'b4.png';  // set of images with numbers
            idle_day_TextRotate_ASCIIARRAY[5] = 'b5.png';  // set of images with numbers
            idle_day_TextRotate_ASCIIARRAY[6] = 'b6.png';  // set of images with numbers
            idle_day_TextRotate_ASCIIARRAY[7] = 'b7.png';  // set of images with numbers
            idle_day_TextRotate_ASCIIARRAY[8] = 'b8.png';  // set of images with numbers
            idle_day_TextRotate_ASCIIARRAY[9] = 'b9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              idle_day_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 209,
                center_y: 324,
                pos_x: 209,
                pos_y: 324,
                angle: 45,
                src: 'b0.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_day_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            // idle_hour_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 188,
              // y: -5,
              // font_array: ["a0.png","a1.png","a2.png","a3.png","a4.png","a5.png","a6.png","a7.png","a8.png","a9.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: 45,
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.HOUR,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_hour_TextRotate_ASCIIARRAY[0] = 'a0.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[1] = 'a1.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[2] = 'a2.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[3] = 'a3.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[4] = 'a4.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[5] = 'a5.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[6] = 'a6.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[7] = 'a7.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[8] = 'a8.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[9] = 'a9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              idle_hour_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 188,
                center_y: -5,
                pos_x: 188,
                pos_y: -5,
                angle: 45,
                src: 'a0.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_hour_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            // idle_minute_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 347,
              // y: 157,
              // font_array: ["a0.png","a1.png","a2.png","a3.png","a4.png","a5.png","a6.png","a7.png","a8.png","a9.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: 45,
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.MINUTE,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_minute_TextRotate_ASCIIARRAY[0] = 'a0.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[1] = 'a1.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[2] = 'a2.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[3] = 'a3.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[4] = 'a4.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[5] = 'a5.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[6] = 'a6.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[7] = 'a7.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[8] = 'a8.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[9] = 'a9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              idle_minute_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 347,
                center_y: 157,
                pos_x: 347,
                pos_y: 157,
                angle: 45,
                src: 'a0.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_minute_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            function text_update() {
              console.log('text_update()');

              console.log('update text rotate month_TIME');
              let valueMonth = timeSensor.month;
              let normal_month_rotate_string = parseInt(valueMonth).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_month_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueMonth != null && valueMonth != undefined && isFinite(valueMonth) && normal_month_rotate_string.length > 0 && normal_month_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of normal_month_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_month_TextRotate[index].setProperty(hmUI.prop.POS_X, 168 + img_offset);
                      normal_month_TextRotate[index].setProperty(hmUI.prop.SRC, normal_month_TextRotate_ASCIIARRAY[charCode]);
                      normal_month_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_month_TextRotate_img_width;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate day_TIME');
              let valueDay = timeSensor.day;
              let normal_day_rotate_string = parseInt(valueDay).toString();
              normal_day_rotate_string = normal_day_rotate_string.padStart(2, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_day_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueDay != null && valueDay != undefined && isFinite(valueDay) && normal_day_rotate_string.length > 0 && normal_day_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of normal_day_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_day_TextRotate[index].setProperty(hmUI.prop.POS_X, 258 + img_offset);
                      normal_day_TextRotate[index].setProperty(hmUI.prop.SRC, normal_day_TextRotate_ASCIIARRAY[charCode]);
                      normal_day_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_day_TextRotate_img_width;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate hour_TIME');
              let valueHour = timeSensor.format_hour;
              let normal_hour_rotate_string = parseInt(valueHour).toString();
              normal_hour_rotate_string = normal_hour_rotate_string.padStart(2, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_hour_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueHour != null && valueHour != undefined && isFinite(valueHour) && normal_hour_rotate_string.length > 0 && normal_hour_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of normal_hour_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_hour_TextRotate[index].setProperty(hmUI.prop.POS_X, 50 + img_offset);
                      normal_hour_TextRotate[index].setProperty(hmUI.prop.SRC, normal_hour_TextRotate_ASCIIARRAY[charCode]);
                      normal_hour_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_hour_TextRotate_img_width;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate minute_TIME');
              let valueMinute = timeSensor.minute;
              let normal_minute_rotate_string = parseInt(valueMinute).toString();
              normal_minute_rotate_string = normal_minute_rotate_string.padStart(2, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_minute_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueMinute != null && valueMinute != undefined && isFinite(valueMinute) && normal_minute_rotate_string.length > 0 && normal_minute_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of normal_minute_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_minute_TextRotate[index].setProperty(hmUI.prop.POS_X, 231 + img_offset);
                      normal_minute_TextRotate[index].setProperty(hmUI.prop.SRC, normal_minute_TextRotate_ASCIIARRAY[charCode]);
                      normal_minute_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_minute_TextRotate_img_width;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate month_TIME');
              let idle_month_rotate_string = parseInt(valueMonth).toString();

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  idle_month_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueMonth != null && valueMonth != undefined && isFinite(valueMonth) && idle_month_rotate_string.length > 0 && idle_month_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of idle_month_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_month_TextRotate[index].setProperty(hmUI.prop.POS_X, 123 + img_offset);
                      idle_month_TextRotate[index].setProperty(hmUI.prop.SRC, idle_month_TextRotate_ASCIIARRAY[charCode]);
                      idle_month_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_month_TextRotate_img_width;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate day_TIME');
              let idle_day_rotate_string = parseInt(valueDay).toString();
              idle_day_rotate_string = idle_day_rotate_string.padStart(2, '0');

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  idle_day_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueDay != null && valueDay != undefined && isFinite(valueDay) && idle_day_rotate_string.length > 0 && idle_day_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of idle_day_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_day_TextRotate[index].setProperty(hmUI.prop.POS_X, 209 + img_offset);
                      idle_day_TextRotate[index].setProperty(hmUI.prop.SRC, idle_day_TextRotate_ASCIIARRAY[charCode]);
                      idle_day_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_day_TextRotate_img_width;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate hour_TIME');
              let idle_hour_rotate_string = parseInt(valueHour).toString();
              idle_hour_rotate_string = idle_hour_rotate_string.padStart(2, '0');

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  idle_hour_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueHour != null && valueHour != undefined && isFinite(valueHour) && idle_hour_rotate_string.length > 0 && idle_hour_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of idle_hour_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_hour_TextRotate[index].setProperty(hmUI.prop.POS_X, 188 + img_offset);
                      idle_hour_TextRotate[index].setProperty(hmUI.prop.SRC, idle_hour_TextRotate_ASCIIARRAY[charCode]);
                      idle_hour_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_hour_TextRotate_img_width;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate minute_TIME');
              let idle_minute_rotate_string = parseInt(valueMinute).toString();
              idle_minute_rotate_string = idle_minute_rotate_string.padStart(2, '0');

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  idle_minute_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueMinute != null && valueMinute != undefined && isFinite(valueMinute) && idle_minute_rotate_string.length > 0 && idle_minute_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of idle_minute_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_minute_TextRotate[index].setProperty(hmUI.prop.POS_X, 347 + img_offset);
                      idle_minute_TextRotate[index].setProperty(hmUI.prop.SRC, idle_minute_TextRotate_ASCIIARRAY[charCode]);
                      idle_minute_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_minute_TextRotate_img_width;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                text_update();
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerTextUpdate) {
                    normal_timerTextUpdate = timer.createTimer(0, 1000, (function (option) {
                      text_update();
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.AOD) {
                  if (!idle_timerTextUpdate) {
                    idle_timerTextUpdate = timer.createTimer(0, 1000, (function (option) {
                      text_update();
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerTextUpdate) {
                  timer.stopTimer(normal_timerTextUpdate);
                  normal_timerTextUpdate = undefined;
                }
                if (idle_timerTextUpdate) {
                  timer.stopTimer(idle_timerTextUpdate);
                  idle_timerTextUpdate = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_digital_clock_img_time = ''
        let normal_moon_image_progress_img_level = ''
        let normal_date_img_date_day = ''
        let normal_distance_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_date_img_date_week_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_pointer_progress_img_pointer = ''
        let normal_system_lock_img = ''
        let normal_system_dnd_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg_img = ''
        let idle_digital_clock_img_time = ''
        let idle_moon_image_progress_img_level = ''
        let idle_date_img_date_day = ''
        let idle_distance_text_text_img = ''
        let idle_step_current_text_img = ''
        let idle_calorie_current_text_img = ''
        let idle_temperature_current_text_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_heart_rate_text_text_img = ''
        let idle_heart_rate_icon_img = ''
        let idle_heart_rate_image_progress_img_level = ''
        let idle_date_img_date_week_img = ''
        let idle_battery_text_text_img = ''
        let idle_battery_pointer_progress_img_pointer = ''
        let idle_system_lock_img = ''
        let idle_system_dnd_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'Bg4.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 192,
              hour_startY: 137,
              hour_array: ["d0.png","d1.png","d2.png","d3.png","d4.png","d5.png","d6.png","d7.png","d8.png","d9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_unit_sc: 'ooo.png',
              hour_unit_tc: 'ooo.png',
              hour_unit_en: 'ooo.png',
              hour_align: hmUI.align.RIGHT,

              minute_startX: 249,
              minute_startY: 137,
              minute_array: ["d0.png","d1.png","d2.png","d3.png","d4.png","d5.png","d6.png","d7.png","d8.png","d9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 101,
              y: 95,
              image_array: ["112.png","113.png","114.png","115.png","116.png","117.png","118.png","119.png","120.png","121.png","122.png","123.png","124.png","125.png","126.png","127.png","128.png","129.png","130.png","131.png","132.png","133.png","135.png","136.png","137.png","138.png","139.png","140.png","141.png","142.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 332,
              day_startY: 99,
              day_sc_array: ["d0.png","d1.png","d2.png","d3.png","d4.png","d5.png","d6.png","d7.png","d8.png","d9.png"],
              day_tc_array: ["d0.png","d1.png","d2.png","d3.png","d4.png","d5.png","d6.png","d7.png","d8.png","d9.png"],
              day_en_array: ["d0.png","d1.png","d2.png","d3.png","d4.png","d5.png","d6.png","d7.png","d8.png","d9.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 210,
              y: 315,
              font_array: ["s0.png","s1.png","s2.png","s3.png","s4.png","s5.png","s6.png","s7.png","s8.png","s9.png"],
              padding: false,
              h_space: 0,
              dot_image: 'ooo3.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 188,
              y: 347,
              font_array: ["d0.png","d1.png","d2.png","d3.png","d4.png","d5.png","d6.png","d7.png","d8.png","d9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 96,
              y: 346,
              font_array: ["s0.png","s1.png","s2.png","s3.png","s4.png","s5.png","s6.png","s7.png","s8.png","s9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 199,
              y: 70,
              font_array: ["s0.png","s1.png","s2.png","s3.png","s4.png","s5.png","s6.png","s7.png","s8.png","s9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 't1.png',
              unit_tc: 't1.png',
              unit_en: 't1.png',
              negative_image: 't2.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 255,
              y: 69,
              image_array: ["00.png","01.png","02.png","03.png","04.png","05.png","06.png","07.png","08.png","09.png","10.png","11.png","12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png","22.png","23.png","24.png","25.png","26.png","27.png","28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 332,
              y: 346,
              font_array: ["s0.png","s1.png","s2.png","s3.png","s4.png","s5.png","s6.png","s7.png","s8.png","s9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'Bg9.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 268,
              y: 146,
              image_array: ["wfs_hr_level_low_80fe076b_26cc_45e5_bee1_196637946318.png","wfs_hr_level_low_80fe076b_26cc_45e5_bee1_196637946319.png","wfs_hr_level_norm_a0a28d77_8a83_4abe_92a1_78552df061eb.png","wfs_hr_level_norm_a0a28d77_8a83_4abe_92a1_78552df061ec.png","wfs_hr_level_norm_a0a28d77_8a83_4abe_92a1_78552df061ed.png","wfs_hr_level_norm_a0a28d77_8a83_4abe_92a1_78552df061ee.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 268,
              y: 145,
              week_en: ["w1.png","w2.png","w3.png","w4.png","w5.png","w6.png","w7.png"],
              week_tc: ["w1.png","w2.png","w3.png","w4.png","w5.png","w6.png","w7.png"],
              week_sc: ["w1.png","w2.png","w3.png","w4.png","w5.png","w6.png","w7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 105,
              y: 266,
              font_array: ["s0.png","s1.png","s2.png","s3.png","s4.png","s5.png","s6.png","s7.png","s8.png","s9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'bat.png',
              center_x: 124,
              center_y: 238,
              x: 79,
              y: 78,
              start_angle: 180,
              end_angle: 540,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 289,
              y: 109,
              src: 'x_z.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 249,
              y: 108,
              src: 'x_m.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 174,
              y: 109,
              src: 'x_bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 210,
              y: 109,
              src: 'x_al.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'h4.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 48,
              hour_posY: 151,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'h5.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 41,
              minute_posY: 195,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'h6.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 36,
              second_posY: 237,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'Bg4.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 192,
              hour_startY: 137,
              hour_array: ["d0.png","d1.png","d2.png","d3.png","d4.png","d5.png","d6.png","d7.png","d8.png","d9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_unit_sc: 'ooo.png',
              hour_unit_tc: 'ooo.png',
              hour_unit_en: 'ooo.png',
              hour_align: hmUI.align.RIGHT,

              minute_startX: 249,
              minute_startY: 137,
              minute_array: ["d0.png","d1.png","d2.png","d3.png","d4.png","d5.png","d6.png","d7.png","d8.png","d9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 101,
              y: 95,
              image_array: ["112.png","113.png","114.png","115.png","116.png","117.png","118.png","119.png","120.png","121.png","122.png","123.png","124.png","125.png","126.png","127.png","128.png","129.png","130.png","131.png","132.png","133.png","135.png","136.png","137.png","138.png","139.png","140.png","141.png","142.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 332,
              day_startY: 99,
              day_sc_array: ["d0.png","d1.png","d2.png","d3.png","d4.png","d5.png","d6.png","d7.png","d8.png","d9.png"],
              day_tc_array: ["d0.png","d1.png","d2.png","d3.png","d4.png","d5.png","d6.png","d7.png","d8.png","d9.png"],
              day_en_array: ["d0.png","d1.png","d2.png","d3.png","d4.png","d5.png","d6.png","d7.png","d8.png","d9.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 210,
              y: 315,
              font_array: ["s0.png","s1.png","s2.png","s3.png","s4.png","s5.png","s6.png","s7.png","s8.png","s9.png"],
              padding: false,
              h_space: 0,
              dot_image: 'ooo3.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 188,
              y: 347,
              font_array: ["d0.png","d1.png","d2.png","d3.png","d4.png","d5.png","d6.png","d7.png","d8.png","d9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 96,
              y: 346,
              font_array: ["s0.png","s1.png","s2.png","s3.png","s4.png","s5.png","s6.png","s7.png","s8.png","s9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 199,
              y: 70,
              font_array: ["s0.png","s1.png","s2.png","s3.png","s4.png","s5.png","s6.png","s7.png","s8.png","s9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 't1.png',
              unit_tc: 't1.png',
              unit_en: 't1.png',
              negative_image: 't2.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 255,
              y: 69,
              image_array: ["00.png","01.png","02.png","03.png","04.png","05.png","06.png","07.png","08.png","09.png","10.png","11.png","12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png","22.png","23.png","24.png","25.png","26.png","27.png","28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 332,
              y: 346,
              font_array: ["s0.png","s1.png","s2.png","s3.png","s4.png","s5.png","s6.png","s7.png","s8.png","s9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'Bg9.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 268,
              y: 146,
              image_array: ["wfs_hr_level_low_80fe076b_26cc_45e5_bee1_196637946318.png","wfs_hr_level_low_80fe076b_26cc_45e5_bee1_196637946319.png","wfs_hr_level_norm_a0a28d77_8a83_4abe_92a1_78552df061eb.png","wfs_hr_level_norm_a0a28d77_8a83_4abe_92a1_78552df061ec.png","wfs_hr_level_norm_a0a28d77_8a83_4abe_92a1_78552df061ed.png","wfs_hr_level_norm_a0a28d77_8a83_4abe_92a1_78552df061ee.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 268,
              y: 145,
              week_en: ["w1.png","w2.png","w3.png","w4.png","w5.png","w6.png","w7.png"],
              week_tc: ["w1.png","w2.png","w3.png","w4.png","w5.png","w6.png","w7.png"],
              week_sc: ["w1.png","w2.png","w3.png","w4.png","w5.png","w6.png","w7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 105,
              y: 266,
              font_array: ["s0.png","s1.png","s2.png","s3.png","s4.png","s5.png","s6.png","s7.png","s8.png","s9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'bat.png',
              center_x: 124,
              center_y: 238,
              x: 79,
              y: 78,
              start_angle: 180,
              end_angle: 540,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 289,
              y: 109,
              src: 'x_z.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 249,
              y: 108,
              src: 'x_m.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 174,
              y: 109,
              src: 'x_bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 210,
              y: 109,
              src: 'x_al.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'h4.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 48,
              hour_posY: 151,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'h5.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 41,
              minute_posY: 195,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 9,
              // disconneсnt_toast_text: Связь потеряна,
              // conneсnt_vibrate_type: 0,
              // conneсnt_toast_text: Связь восстановлена,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              console.log('checkConnection()');
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  hmUI.showToast({text: "Связь потеряна"});
                  vibro(9);
                }
                if(status) {
                  hmUI.showToast({text: "Связь восстановлена"});
                  vibro(0);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              if (scene != 1) timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function
            console.log('Watch_Face.Shortcuts');

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 73,
              y: 182,
              w: 106,
              h: 106,
              src: 'k.png',
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 309,
              y: 183,
              w: 106,
              h: 106,
              src: 'k.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 54,
              y: 53,
              w: 106,
              h: 106,
              src: 'k.png',
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 186,
              y: 0,
              w: 106,
              h: 106,
              src: 'k.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 317,
              y: 320,
              w: 106,
              h: 106,
              src: 'k.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 188,
              y: 303,
              w: 106,
              h: 106,
              src: 'k.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                checkConnection();
                stopVibro();

              }),
              pause_call: (function () {
                console.log('pause_call()');
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
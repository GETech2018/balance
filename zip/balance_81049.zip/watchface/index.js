﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_date_img_date_year = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_heart_rate_text_text_img = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_digital_clock_img_time_second = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'N_0001.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 192,
              year_startY: 374,
              year_sc_array: ["N_0076.png","N_0077.png","N_0078.png","N_0079.png","N_0080.png","N_0081.png","N_0082.png","N_0083.png","N_0084.png","N_0085.png"],
              year_tc_array: ["N_0076.png","N_0077.png","N_0078.png","N_0079.png","N_0080.png","N_0081.png","N_0082.png","N_0083.png","N_0084.png","N_0085.png"],
              year_en_array: ["N_0076.png","N_0077.png","N_0078.png","N_0079.png","N_0080.png","N_0081.png","N_0082.png","N_0083.png","N_0084.png","N_0085.png"],
              year_zero: 1,
              year_space: -23,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 189,
              y: 95,
              week_en: ["N_0029.png","N_0030.png","N_0031.png","N_0032.png","N_0033.png","N_0034.png","N_0035.png"],
              week_tc: ["N_0029.png","N_0030.png","N_0031.png","N_0032.png","N_0033.png","N_0034.png","N_0035.png"],
              week_sc: ["N_0029.png","N_0030.png","N_0031.png","N_0032.png","N_0033.png","N_0034.png","N_0035.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 261,
              month_startY: 96,
              month_sc_array: ["N_0017.png","N_0018.png","N_0019.png","N_0020.png","N_0021.png","N_0022.png","N_0023.png","N_0024.png","N_0025.png","N_0026.png","N_0027.png","N_0028.png"],
              month_tc_array: ["N_0017.png","N_0018.png","N_0019.png","N_0020.png","N_0021.png","N_0022.png","N_0023.png","N_0024.png","N_0025.png","N_0026.png","N_0027.png","N_0028.png"],
              month_en_array: ["N_0017.png","N_0018.png","N_0019.png","N_0020.png","N_0021.png","N_0022.png","N_0023.png","N_0024.png","N_0025.png","N_0026.png","N_0027.png","N_0028.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 219,
              day_startY: 97,
              day_sc_array: ["N_0056.png","N_0057.png","N_0058.png","N_0059.png","N_0060.png","N_0061.png","N_0062.png","N_0063.png","N_0064.png","N_0065.png"],
              day_tc_array: ["N_0056.png","N_0057.png","N_0058.png","N_0059.png","N_0060.png","N_0061.png","N_0062.png","N_0063.png","N_0064.png","N_0065.png"],
              day_en_array: ["N_0056.png","N_0057.png","N_0058.png","N_0059.png","N_0060.png","N_0061.png","N_0062.png","N_0063.png","N_0064.png","N_0065.png"],
              day_zero: 0,
              day_space: -27,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 88,
              y: 222,
              font_array: ["N_0066.png","N_0067.png","N_0068.png","N_0069.png","N_0070.png","N_0071.png","N_0072.png","N_0073.png","N_0074.png","N_0075.png"],
              padding: false,
              h_space: -26,
              unit_sc: 'N_0016.png',
              unit_tc: 'N_0016.png',
              unit_en: 'N_0016.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 12,
              y: 218,
              image_array: ["N_0046.png","N_0047.png","N_0048.png","N_0049.png","N_0050.png","N_0051.png","N_0052.png","N_0053.png","N_0054.png"],
              image_length: 9,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 378,
              y: 224,
              font_array: ["N_0002.png","N_0003.png","N_0004.png","N_0005.png","N_0006.png","N_0007.png","N_0008.png","N_0009.png","N_0010.png","N_0011.png"],
              padding: false,
              h_space: -55,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'N_0012.png',
              hour_centerX: 239,
              hour_centerY: 243,
              hour_posX: 174,
              hour_posY: 4,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'N_0013.png',
              minute_centerX: 238,
              minute_centerY: 244,
              minute_posX: 237,
              minute_posY: 5,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'N_0014.png',
              second_centerX: 239,
              second_centerY: 243,
              second_posX: 229,
              second_posY: 5,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_second = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              second_startX: 417,
              second_startY: 223,
              second_array: ["N_0036.png","N_0037.png","N_0038.png","N_0039.png","N_0040.png","N_0041.png","N_0042.png","N_0043.png","N_0044.png","N_0045.png"],
              second_zero: 0,
              second_space: -43,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });




                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_battery_circle_scale = ''
        let normal_battery_icon_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_step_circle_scale = ''
        let normal_step_icon_img = ''
        let normal_sun_pointer_progress_img_pointer = ''
        let normal_sun_high_text_img = ''
        let normal_sun_high_separator_img = ''
        let normal_sun_low_text_img = ''
        let normal_sun_low_separator_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_month_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_analog_clock_pro_hour_pointer_img = ''
        let normal_analog_clock_pro_minute_pointer_img = ''
        let normal_analog_clock_pro_second_pointer_img = ''
        let normal_timerUpdateSec = undefined;
        let idle_background_bg_img = ''
        let idle_battery_circle_scale = ''
        let idle_battery_icon_img = ''
        let idle_heart_rate_text_text_img = ''
        let idle_distance_text_text_img = ''
        let idle_step_current_text_img = ''
        let idle_step_circle_scale = ''
        let idle_step_icon_img = ''
        let idle_sun_pointer_progress_img_pointer = ''
        let idle_sun_high_text_img = ''
        let idle_sun_high_separator_img = ''
        let idle_sun_low_text_img = ''
        let idle_sun_low_separator_img = ''
        let idle_temperature_current_text_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_month_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_analog_clock_pro_hour_pointer_img = ''
        let idle_analog_clock_pro_minute_pointer_img = ''
        let idle_analog_clock_pro_minute_cover_pointer_img = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: '001.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 240,
              // center_y: 240,
              // start_angle: 225,
              // end_angle: 400,
              // radius: 107,
              // line_width: 8,
              // line_cap: Rounded,
              // color: 0xFFB30909,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            let screenType = hmSetting.getScreenType();
            normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 240,
              center_y: 240,
              start_angle: 225,
              end_angle: 400,
              radius: 103,
              line_width: 8,
              corner_flag: 0,
              color: 0xFFB30909,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: '114.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 85,
              y: 345,
              font_array: ["017_big_numb.png","018_big_numb.png","019_big_numb.png","020_big_numb.png","021_big_numb.png","022_big_numb.png","023_big_numb.png","024_big_numb.png","025_big_numb.png","026_big_numb.png"],
              padding: false,
              h_space: 1,
              invalid_image: '050_q.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 197,
              y: 379,
              font_array: ["037_nomb.png","038_nomb.png","039_nomb.png","040_nomb.png","041_nomb.png","042_nomb.png","043_nomb.png","044_nomb.png","045_nomb.png","046_nomb.png"],
              padding: false,
              h_space: 0,
              unit_sc: '048_km.png',
              unit_tc: '048_km.png',
              unit_en: '048_km.png',
              imperial_unit_sc: '049_ml.png',
              imperial_unit_tc: '049_ml.png',
              imperial_unit_en: '049_ml.png',
              dot_image: '047.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 201,
              y: 337,
              font_array: ["037_nomb.png","038_nomb.png","039_nomb.png","040_nomb.png","041_nomb.png","042_nomb.png","043_nomb.png","044_nomb.png","045_nomb.png","046_nomb.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 240,
              // center_y: 369,
              // start_angle: 84,
              // end_angle: 276,
              // radius: 80,
              // line_width: 11,
              // line_cap: Rounded,
              // color: 0xFFB30909,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 240,
              center_y: 369,
              start_angle: 84,
              end_angle: 276,
              radius: 75,
              line_width: 11,
              corner_flag: 0,
              color: 0xFFB30909,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: '115.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: '101.png',
              center_x: 240,
              center_y: 240,
              x: 20,
              y: 186,
              start_angle: -41,
              end_angle: 41,
              invalid_visible: false,
              cover_path: '103.png',
              cover_x: 0,
              cover_y: 0,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 90,
              y: 116,
              font_array: ["051_numb_small.png","052_numb_small.png","053_numb_small.png","054_numb_small.png","055_numb_small.png","056_numb_small.png","057_numb_small.png","058_numb_small.png","059_numb_small.png","060_numb_small.png"],
              padding: false,
              h_space: -2,
              dot_image: '067_numb_small.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 102,
              y: 80,
              src: '068.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 334,
              y: 116,
              font_array: ["051_numb_small.png","052_numb_small.png","053_numb_small.png","054_numb_small.png","055_numb_small.png","056_numb_small.png","057_numb_small.png","058_numb_small.png","059_numb_small.png","060_numb_small.png"],
              padding: false,
              h_space: -2,
              dot_image: '067_numb_small.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 346,
              y: 80,
              src: '069.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 35,
              y: 245,
              font_array: ["017_big_numb.png","018_big_numb.png","019_big_numb.png","020_big_numb.png","021_big_numb.png","022_big_numb.png","023_big_numb.png","024_big_numb.png","025_big_numb.png","026_big_numb.png"],
              padding: false,
              h_space: 0,
              unit_sc: '028_celseus.png',
              unit_tc: '028_celseus.png',
              unit_en: '028_celseus.png',
              negative_image: '027_big_numb.png',
              invalid_image: '029_q.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 0,
              y: 0,
              image_array: ["072_weather.png","073_weather.png","074_weather.png","075_weather.png","076_weather.png","077_weather.png","078_weather.png","079_weather.png","080_weather.png","081_weather.png","082_weather.png","083_weather.png","084_weather.png","085_weather.png","086_weather.png","087_weather.png","088_weather.png","089_weather.png","090.png","091_weather.png","092_weather.png","093_weather.png","094_weather.png","095_weather.png","096_weather.png","097_weather.png","098_weather.png","099_weather.png","100_weather.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 279,
              y: 143,
              week_en: ["030_day.png","031_day.png","032_day.png","033_day.png","034_day.png","035_day.png","036_day.png"],
              week_tc: ["030_day.png","031_day.png","032_day.png","033_day.png","034_day.png","035_day.png","036_day.png"],
              week_sc: ["030_day.png","031_day.png","032_day.png","033_day.png","034_day.png","035_day.png","036_day.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 353,
              day_startY: 193,
              day_sc_array: ["017_big_numb.png","018_big_numb.png","019_big_numb.png","020_big_numb.png","021_big_numb.png","022_big_numb.png","023_big_numb.png","024_big_numb.png","025_big_numb.png","026_big_numb.png"],
              day_tc_array: ["017_big_numb.png","018_big_numb.png","019_big_numb.png","020_big_numb.png","021_big_numb.png","022_big_numb.png","023_big_numb.png","024_big_numb.png","025_big_numb.png","026_big_numb.png"],
              day_en_array: ["017_big_numb.png","018_big_numb.png","019_big_numb.png","020_big_numb.png","021_big_numb.png","022_big_numb.png","023_big_numb.png","024_big_numb.png","025_big_numb.png","026_big_numb.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 319,
              month_startY: 252,
              month_sc_array: ["005_mount.png","006_mount.png","007_mount.png","008_mount.png","009_mount.png","010_mount.png","011_mount.png","012_mount.png","013_mount.png","014_mount.png","015_mount.png","016_mount.png"],
              month_tc_array: ["005_mount.png","006_mount.png","007_mount.png","008_mount.png","009_mount.png","010_mount.png","011_mount.png","012_mount.png","013_mount.png","014_mount.png","015_mount.png","016_mount.png"],
              month_en_array: ["005_mount.png","006_mount.png","007_mount.png","008_mount.png","009_mount.png","010_mount.png","011_mount.png","012_mount.png","013_mount.png","014_mount.png","015_mount.png","016_mount.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 363,
              y: 337,
              src: '070.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 346,
              y: 385,
              src: '071.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const deviceInfo = hmSetting.getDeviceInfo();
            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.MINUTEEND, function() {
              let updateHour = timeSensor.minute == 0;

              time_update(updateHour, true);
            });

            // normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: '003_hour.png',
              // center_x: 240,
              // center_y: 240,
              // x: 240,
              // y: 240,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.hour,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 240,
              pos_y: 240 - 240,
              center_x: 240,
              center_y: 240,
              src: '003_hour.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: '002_min.png',
              // center_x: 240,
              // center_y: 240,
              // x: 240,
              // y: 240,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.minute,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 240,
              pos_y: 240 - 240,
              center_x: 240,
              center_y: 240,
              src: '002_min.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: '001_sec.png',
              // center_x: 240,
              // center_y: 240,
              // x: 240,
              // y: 240,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 240,
              pos_y: 240 - 240,
              center_x: 240,
              center_y: 240,
              src: '001_sec.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: '001_AOD.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 240,
              // center_y: 240,
              // start_angle: 225,
              // end_angle: 400,
              // radius: 107,
              // line_width: 8,
              // line_cap: Rounded,
              // color: 0xFF620505,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 240,
              center_y: 240,
              start_angle: 225,
              end_angle: 400,
              radius: 103,
              line_width: 8,
              corner_flag: 0,
              color: 0xFF620505,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'AOD_114.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 85,
              y: 345,
              font_array: ["AOD_017_big_numb.png","AOD_018_big_numb.png","AOD_019_big_numb.png","AOD_020_big_numb.png","AOD_021_big_numb.png","AOD_022_big_numb.png","AOD_023_big_numb.png","AOD_024_big_numb.png","AOD_025_big_numb.png","AOD_026_big_numb.png"],
              padding: false,
              h_space: 1,
              invalid_image: 'AOD_050_q.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 197,
              y: 379,
              font_array: ["AOD_037_nomb.png","AOD_038_nomb.png","AOD_039_nomb.png","AOD_040_nomb.png","AOD_041_nomb.png","AOD_042_nomb.png","AOD_043_nomb.png","AOD_044_nomb.png","AOD_045_nomb.png","AOD_046_nomb.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'AOD_048_km.png',
              unit_tc: 'AOD_048_km.png',
              unit_en: 'AOD_048_km.png',
              imperial_unit_sc: 'AOD_049_ml.png',
              imperial_unit_tc: 'AOD_049_ml.png',
              imperial_unit_en: 'AOD_049_ml.png',
              dot_image: 'AOD_047.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 201,
              y: 337,
              font_array: ["AOD_037_nomb.png","AOD_038_nomb.png","AOD_039_nomb.png","AOD_040_nomb.png","AOD_041_nomb.png","AOD_042_nomb.png","AOD_043_nomb.png","AOD_044_nomb.png","AOD_045_nomb.png","AOD_046_nomb.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 240,
              // center_y: 369,
              // start_angle: 84,
              // end_angle: 276,
              // radius: 80,
              // line_width: 11,
              // line_cap: Rounded,
              // color: 0xFF620505,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 240,
              center_y: 369,
              start_angle: 84,
              end_angle: 276,
              radius: 75,
              line_width: 11,
              corner_flag: 0,
              color: 0xFF620505,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'AOD_115.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_sun_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'AOD_101.png',
              center_x: 240,
              center_y: 240,
              x: 20,
              y: 186,
              start_angle: -41,
              end_angle: 41,
              invalid_visible: false,
              cover_path: 'AOD_103.png',
              cover_x: 0,
              cover_y: 0,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 90,
              y: 116,
              font_array: ["AOD_051_numb_small.png","AOD_052_numb_small.png","AOD_053_numb_small.png","AOD_054_numb_small.png","AOD_055_numb_small.png","AOD_056_numb_small.png","AOD_057_numb_small.png","AOD_058_numb_small.png","AOD_059_numb_small.png","AOD_060_numb_small.png"],
              padding: false,
              h_space: -2,
              dot_image: 'AOD_067_numb_small.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_sun_high_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 102,
              y: 80,
              src: 'AOD_068.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 334,
              y: 116,
              font_array: ["AOD_051_numb_small.png","AOD_052_numb_small.png","AOD_053_numb_small.png","AOD_054_numb_small.png","AOD_055_numb_small.png","AOD_056_numb_small.png","AOD_057_numb_small.png","AOD_058_numb_small.png","AOD_059_numb_small.png","AOD_060_numb_small.png"],
              padding: false,
              h_space: -2,
              dot_image: 'AOD_067_numb_small.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_sun_low_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 346,
              y: 80,
              src: 'AOD_069.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 35,
              y: 245,
              font_array: ["AOD_017_big_numb.png","AOD_018_big_numb.png","AOD_019_big_numb.png","AOD_020_big_numb.png","AOD_021_big_numb.png","AOD_022_big_numb.png","AOD_023_big_numb.png","AOD_024_big_numb.png","AOD_025_big_numb.png","AOD_026_big_numb.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'AOD_028_celseus.png',
              unit_tc: 'AOD_028_celseus.png',
              unit_en: 'AOD_028_celseus.png',
              negative_image: 'AOD_027_big_numb.png',
              invalid_image: 'AOD_029_q.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 0,
              y: 0,
              image_array: ["AOD_072_weather.png","AOD_073_weather.png","AOD_074_weather.png","AOD_075_weather.png","AOD_076_weather.png","AOD_077_weather.png","AOD_078_weather.png","AOD_079_weather.png","AOD_080_weather.png","AOD_081_weather.png","AOD_082_weather.png","AOD_083_weather.png","AOD_084_weather.png","AOD_085_weather.png","AOD_086_weather.png","AOD_087_weather.png","AOD_088_weather.png","AOD_089_weather.png","AOD_090.png","AOD_091_weather.png","AOD_092_weather.png","AOD_093_weather.png","AOD_094_weather.png","AOD_095_weather.png","AOD_096_weather.png","AOD_097_weather.png","AOD_098_weather.png","AOD_099_weather.png","AOD_100_weather.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 279,
              y: 143,
              week_en: ["AOD_030_day.png","AOD_031_day.png","AOD_032_day.png","AOD_033_day.png","AOD_034_day.png","AOD_035_day.png","AOD_036_day.png"],
              week_tc: ["AOD_030_day.png","AOD_031_day.png","AOD_032_day.png","AOD_033_day.png","AOD_034_day.png","AOD_035_day.png","AOD_036_day.png"],
              week_sc: ["AOD_030_day.png","AOD_031_day.png","AOD_032_day.png","AOD_033_day.png","AOD_034_day.png","AOD_035_day.png","AOD_036_day.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 353,
              day_startY: 193,
              day_sc_array: ["AOD_017_big_numb.png","AOD_018_big_numb.png","AOD_019_big_numb.png","AOD_020_big_numb.png","AOD_021_big_numb.png","AOD_022_big_numb.png","AOD_023_big_numb.png","AOD_024_big_numb.png","AOD_025_big_numb.png","AOD_026_big_numb.png"],
              day_tc_array: ["AOD_017_big_numb.png","AOD_018_big_numb.png","AOD_019_big_numb.png","AOD_020_big_numb.png","AOD_021_big_numb.png","AOD_022_big_numb.png","AOD_023_big_numb.png","AOD_024_big_numb.png","AOD_025_big_numb.png","AOD_026_big_numb.png"],
              day_en_array: ["AOD_017_big_numb.png","AOD_018_big_numb.png","AOD_019_big_numb.png","AOD_020_big_numb.png","AOD_021_big_numb.png","AOD_022_big_numb.png","AOD_023_big_numb.png","AOD_024_big_numb.png","AOD_025_big_numb.png","AOD_026_big_numb.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 319,
              month_startY: 252,
              month_sc_array: ["AOD_005_mount.png","AOD_006_mount.png","AOD_007_mount.png","AOD_008_mount.png","AOD_009_mount.png","AOD_010_mount.png","AOD_011_mount.png","AOD_012_mount.png","AOD_013_mount.png","AOD_014_mount.png","AOD_015_mount.png","AOD_016_mount.png"],
              month_tc_array: ["AOD_005_mount.png","AOD_006_mount.png","AOD_007_mount.png","AOD_008_mount.png","AOD_009_mount.png","AOD_010_mount.png","AOD_011_mount.png","AOD_012_mount.png","AOD_013_mount.png","AOD_014_mount.png","AOD_015_mount.png","AOD_016_mount.png"],
              month_en_array: ["AOD_005_mount.png","AOD_006_mount.png","AOD_007_mount.png","AOD_008_mount.png","AOD_009_mount.png","AOD_010_mount.png","AOD_011_mount.png","AOD_012_mount.png","AOD_013_mount.png","AOD_014_mount.png","AOD_015_mount.png","AOD_016_mount.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 363,
              y: 337,
              src: 'AOD_070.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 346,
              y: 385,
              src: 'AOD_071.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: '003_hour_AOD.png',
              // center_x: 240,
              // center_y: 240,
              // x: 240,
              // y: 240,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.hour,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });


            idle_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 240,
              pos_y: 240 - 240,
              center_x: 240,
              center_y: 240,
              src: '003_hour_AOD.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: '002_min_AOD.png',
              // center_x: 240,
              // center_y: 240,
              // x: 240,
              // y: 240,
              // start_angle: 0,
              // end_angle: 360,
              // cover_path: '004_centr_AOD.png',
              // cover_x: 0,
              // cover_y: 0,
              // type: hmUI.data_type.minute,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });


            idle_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 240,
              pos_y: 240 - 240,
              center_x: 240,
              center_y: 240,
              src: '002_min_AOD.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_pro_minute_cover_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: '004_centr_AOD.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 322,
              y: 187,
              w: 106,
              h: 106,
              src: '104.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 131,
              y: 0,
              w: 211,
              h: 106,
              src: '104.png',
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 22,
              y: 155,
              w: 106,
              h: 106,
              src: '104.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 54,
              y: 295,
              w: 106,
              h: 106,
              src: '104.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 190,
              y: 319,
              w: 106,
              h: 106,
              src: '104.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            //#region time_update
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              if (updateMinute) {
                let normal_hour = hour;
                let normal_fullAngle_hour = 360;
                if (normal_hour > 11) normal_hour -= 12;
                let normal_angle_hour = 0 + normal_fullAngle_hour*normal_hour/12 + (normal_fullAngle_hour/12)*minute/60;
                if (normal_analog_clock_pro_hour_pointer_img) normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_hour);
              };

              if (updateMinute) {
                let normal_fullAngle_minute = 360;
                let normal_angle_minute = 0 + normal_fullAngle_minute*minute/60;
                if (normal_analog_clock_pro_minute_pointer_img) normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_minute);
              };

              let normal_fullAngle_second = 360;
              let normal_angle_second = 0 + normal_fullAngle_second*second/60;
              if (normal_analog_clock_pro_second_pointer_img) normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_second);

              if (updateMinute) {
                let idle_hour = hour;
                let idle_fullAngle_hour = 360;
                if (idle_hour > 11) idle_hour -= 12;
                let idle_angle_hour = 0 + idle_fullAngle_hour*idle_hour/12 + (idle_fullAngle_hour/12)*minute/60;
                if (idle_analog_clock_pro_hour_pointer_img) idle_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.ANGLE, idle_angle_hour);
              };

              if (updateMinute) {
                let idle_fullAngle_minute = 360;
                let idle_angle_minute = 0 + idle_fullAngle_minute*minute/60;
                if (idle_analog_clock_pro_minute_pointer_img) idle_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.ANGLE, idle_angle_minute);
              };

            };

            //#endregion
            function scale_call() {
              console.log('scale_call()');

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_cs_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_battery * 100);
                  if (normal_battery_circle_scale) {
                    normal_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 240,
                      center_y: 240,
                      start_angle: 225,
                      end_angle: 400,
                      radius: 103,
                      line_width: 8,
                      corner_flag: 0,
                      color: 0xFFB30909,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_cs_normal_step = progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_step * 100);
                  if (normal_step_circle_scale) {
                    normal_step_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 240,
                      center_y: 369,
                      start_angle: 84,
                      end_angle: 276,
                      radius: 75,
                      line_width: 11,
                      corner_flag: 0,
                      color: 0xFFB30909,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales BATTERY');
                let progress_cs_idle_battery = progressBattery;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_battery_circle_scale_circle_scale
                  let level = Math.round(progress_cs_idle_battery * 100);
                  if (idle_battery_circle_scale) {
                    idle_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 240,
                      center_y: 240,
                      start_angle: 225,
                      end_angle: 400,
                      radius: 103,
                      line_width: 8,
                      corner_flag: 0,
                      color: 0xFF620505,
                      show_level: hmUI.show_level.ONLY_AOD,
                      level: level,
                    });
                  };
                };

                console.log('update scales STEP');
                let progress_cs_idle_step = progressStep;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_step_circle_scale_circle_scale
                  let level = Math.round(progress_cs_idle_step * 100);
                  if (idle_step_circle_scale) {
                    idle_step_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 240,
                      center_y: 369,
                      start_angle: 84,
                      end_angle: 276,
                      radius: 75,
                      line_width: 11,
                      corner_flag: 0,
                      color: 0xFF620505,
                      show_level: hmUI.show_level.ONLY_AOD,
                      level: level,
                    });
                  };
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                time_update(true, true);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSec) {
                    let animDelay = timeSensor.utc % 1000;
                    let animRepeat = 1000;
                    normal_timerUpdateSec = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, false);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerUpdateSec) {
                  timer.stopTimer(normal_timerUpdateSec);
                  normal_timerUpdateSec = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

let colornumber_background = 1
        let totalcolors_background = 7
        let namecolor_background = ''

        function click_Color() {
            if(colornumber_background>=totalcolors_background) {
            colornumber_background=1;
                }
            else {
                colornumber_background=colornumber_background+1;
            }
            if ( colornumber_background == 1) { namecolor_background = "M A T T  R O S E"}
			if ( colornumber_background == 2) { namecolor_background = "O L I V E"}
			if ( colornumber_background == 3) { namecolor_background = "V A N I L L A"}
			if ( colornumber_background == 4) { namecolor_background = "I C E  B L U E"}
			if ( colornumber_background == 5) { namecolor_background = "A P R I C O T"}
			if ( colornumber_background == 6) { namecolor_background = "Y E L L O W"}
			if ( colornumber_background == 7) { namecolor_background = "M A T T  W H I T E  C O F F E"}


			hmUI.showToast({text: namecolor_background });
            normal_background_bg_img.setProperty(hmUI.prop.SRC, "color_" + parseInt(colornumber_background) + ".png");
        }
        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_sun_high_text_img = ''
        let normal_sun_low_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_city_name_text = ''
        let normal_battery_text_text_img = ''
        let normal_battery_circle_scale = ''
        let normal_heart_rate_text_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_date_img_date_year = ''
        let normal_dow_text_font = ''
        let normal_DOW_Array = ['LUNDI', 'MARDI', 'MERCREDI', 'JEUDI', 'VENDREDI', 'SAMEDI', 'DIMANCHE'];
        let normal_month_name_font = ''
        let normal_Month_Array = ['JANVIER', 'FEVRIER', 'MARS', 'AVRIL', 'MAI', 'JUIN', 'JUILLET', 'AOUT', 'SEPTEMBRE', 'OCTOBRE', 'NOVEMBRE', 'DECEMBRE', ];
        let normal_date_img_date_day = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg = ''
        let idle_digital_clock_img_time = ''
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'image.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 121,
              y: 58,
              font_array: ["act_0.png","act_0_1.png","act_1.png","act_1_1.png","act_2.png","act_2_1.png","act_3.png","act_3_1.png","act_4.png","act_4_1.png"],
              padding: false,
              h_space: 0,
              invalid_image: 'dot.png',
              dot_image: 'dot.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 273,
              y: 58,
              font_array: ["act_0.png","act_0_1.png","act_1.png","act_1_1.png","act_2.png","act_2_1.png","act_3.png","act_3_1.png","act_4.png","act_4_1.png"],
              padding: false,
              h_space: 1,
              invalid_image: 'dot.png',
              dot_image: 'dot.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 364,
              y: 271,
              font_array: ["small_0.png","small_0_1.png","small_1.png","small_1_1.png","small_2.png","small_2_1.png","small_3.png","small_3_1.png","small_4.png","small_4_1.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'DOT-SMALL_9.png',
              unit_tc: 'DOT-SMALL_9.png',
              unit_en: 'DOT-SMALL_9.png',
              negative_image: 'DOT-SMALL_8.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 346,
              y: 178,
              image_array: ["weather_01.png","weather_01_1.png","weather_02.png","weather_02_1.png","weather_03.png","weather_03_1.png","weather_04.png","weather_04_1.png","weather_05.png","weather_05_1.png","weather_06.png","weather_06_1.png","weather_07.png","weather_07_1.png","weather_08.png","weather_08_1.png","weather_09.png","weather_09_1.png","weather_10.png","weather_10_1.png","weather_12.png","weather_12_1.png","weather_13.png","weather_13_1.png","weather_14.png","weather_14_1.png","weather_15.png","weather_15_1.png","weather_16.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 157,
              y: 86,
              w: 150,
              h: 30,
              text_size: 23,
              char_space: 0,
              line_space: 0,
              color: 0xFFFF8C00,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 361,
              y: 325,
              font_array: ["act_0.png","act_0_1.png","act_1.png","act_1_1.png","act_2.png","act_2_1.png","act_3.png","act_3_1.png","act_4.png","act_4_1.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'percent.png',
              unit_tc: 'percent.png',
              unit_en: 'percent.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 239,
              // center_y: 239,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 240,
              // line_width: 10,
              // line_cap: Rounded,
              // color: 0xFFFF8C00,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            let screenType = hmSetting.getScreenType();
            normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 239,
              center_y: 239,
              start_angle: 0,
              end_angle: 360,
              radius: 235,
              line_width: 10,
              corner_flag: 0,
              color: 0xFFFF8C00,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 136,
              y: 325,
              font_array: ["act_0.png","act_0_1.png","act_1.png","act_1_1.png","act_2.png","act_2_1.png","act_3.png","act_3_1.png","act_4.png","act_4_1.png"],
              padding: false,
              h_space: 1,
              invalid_image: 'dot.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 101,
              y: 397,
              font_array: ["act_0.png","act_0_1.png","act_1.png","act_1_1.png","act_2.png","act_2_1.png","act_3.png","act_3_1.png","act_4.png","act_4_1.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 201,
              y: 397,
              font_array: ["act_0.png","act_0_1.png","act_1.png","act_1_1.png","act_2.png","act_2_1.png","act_3.png","act_3_1.png","act_4.png","act_4_1.png"],
              padding: false,
              h_space: 1,
              dot_image: 'dot.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 296,
              y: 397,
              font_array: ["act_0.png","act_0_1.png","act_1.png","act_1_1.png","act_2.png","act_2_1.png","act_3.png","act_3_1.png","act_4.png","act_4_1.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 343,
              year_startY: 126,
              year_sc_array: ["small_0.png","small_0_1.png","small_1.png","small_1_1.png","small_2.png","small_2_1.png","small_3.png","small_3_1.png","small_4.png","small_4_1.png"],
              year_tc_array: ["small_0.png","small_0_1.png","small_1.png","small_1_1.png","small_2.png","small_2_1.png","small_3.png","small_3_1.png","small_4.png","small_4_1.png"],
              year_en_array: ["small_0.png","small_0_1.png","small_1.png","small_1_1.png","small_2.png","small_2_1.png","small_3.png","small_3_1.png","small_4.png","small_4_1.png"],
              year_zero: 1,
              year_space: 1,
              year_align: hmUI.align.CENTER_H,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function() {
              time_update(true);
            });

            normal_dow_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 42,
              y: 120,
              w: 150,
              h: 30,
              text_size: 18,
              char_space: 0,
              line_space: 0,
              color: 0xFF000000,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              // unit_string: LUNDI, MARDI, MERCREDI, JEUDI, VENDREDI, SAMEDI, DIMANCHE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_month_name_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 198,
              y: 119,
              w: 150,
              h: 30,
              text_size: 18,
              char_space: 0,
              line_space: 1,
              color: 0xFF000000,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              // unit_string: JANVIER, FEVRIER, MARS, AVRIL, MAI, JUIN, JUILLET, AOUT, SEPTEMBRE, OCTOBRE, NOVEMBRE, DECEMBRE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 173,
              day_startY: 123,
              day_sc_array: ["act_0.png","act_0_1.png","act_1.png","act_1_1.png","act_2.png","act_2_1.png","act_3.png","act_3_1.png","act_4.png","act_4_1.png"],
              day_tc_array: ["act_0.png","act_0_1.png","act_1.png","act_1_1.png","act_2.png","act_2_1.png","act_3.png","act_3_1.png","act_4.png","act_4_1.png"],
              day_en_array: ["act_0.png","act_0_1.png","act_1.png","act_1_1.png","act_2.png","act_2_1.png","act_3.png","act_3_1.png","act_4.png","act_4_1.png"],
              day_zero: 0,
              day_space: 1,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 51,
              hour_startY: 202,
              hour_array: ["time_0.png","time_0_1.png","time_1.png","time_1_1.png","time_2.png","time_2_1.png","time_3.png","time_3_1.png","time_4.png","time_4_1.png"],
              hour_zero: 1,
              hour_space: 9,
              hour_angle: 0,
              hour_unit_sc: 'pointer_0.png',
              hour_unit_tc: 'pointer_0.png',
              hour_unit_en: 'pointer_0.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 193,
              minute_startY: 202,
              minute_array: ["time_0.png","time_0_1.png","time_1.png","time_1_1.png","time_2.png","time_2_1.png","time_3.png","time_3_1.png","time_4.png","time_4_1.png"],
              minute_zero: 1,
              minute_space: 9,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 243,
              second_startY: 324,
              second_array: ["act_0.png","act_0_1.png","act_1.png","act_1_1.png","act_2.png","act_2_1.png","act_3.png","act_3_1.png","act_4.png","act_4_1.png"],
              second_zero: 0,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFF555555',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 104,
              hour_startY: 203,
              hour_array: ["time_0.png","time_0_1.png","time_1.png","time_1_1.png","time_2.png","time_2_1.png","time_3.png","time_3_1.png","time_4.png","time_4_1.png"],
              hour_zero: 1,
              hour_space: 9,
              hour_angle: 0,
              hour_unit_sc: 'pointer_0.png',
              hour_unit_tc: 'pointer_0.png',
              hour_unit_en: 'pointer_0.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 244,
              minute_startY: 202,
              minute_array: ["time_0.png","time_0_1.png","time_1.png","time_1_1.png","time_2.png","time_2_1.png","time_3.png","time_3_1.png","time_4.png","time_4_1.png"],
              minute_zero: 1,
              minute_space: 9,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            //start of ignored block
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              console.log('day of week font');
              if (updateHour) {
                let normal_DOW_Str = normal_DOW_Array[timeSensor.week-1];
                normal_dow_text_font.setProperty(hmUI.prop.TEXT, normal_DOW_Str );
              };

              console.log('month font');
              if (updateHour) {
                let normal_Month_Str = normal_Month_Array[timeSensor.month-1];
                normal_month_name_font.setProperty(hmUI.prop.TEXT, normal_Month_Str );
              };

            };

            //end of ignored block
            function scale_call() {
              console.log('scale_call()');

              console.log('Weather city name');
              let weatherData = weatherSensor.getForecastWeather();
              normal_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_cs_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_battery * 100);
                  if (normal_battery_circle_scale) {
                    normal_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 239,
                      center_y: 239,
                      start_angle: 0,
                      end_angle: 360,
                      radius: 235,
                      line_width: 10,
                      corner_flag: 0,
                      color: 0xFFFF8C00,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                time_update(true, true);
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_battery_pointer_progress_img_pointer = ''
        let normal_step_icon_img = ''
        let normal_step_current_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_system_lock_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let idle_background_bg_img = ''
        let idle_battery_pointer_progress_img_pointer = ''
        let idle_step_icon_img = ''
        let idle_step_current_text_img = ''
        let idle_temperature_current_text_img = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_week_img = ''
        let idle_heart_rate_icon_img = ''
        let idle_heart_rate_text_text_img = ''
        let idle_moon_image_progress_img_level = ''
        let idle_system_lock_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let editableTimePointers = ''
        let normal_step_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_battery_jumpable_img_click = ''
        let normal_moon_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_altitude_jumpable_img_click = ''
        let Button_Switch_BG = ''

        let backgroundIndex = 0;
        let backgroundList = ['bg_0_black.png', 'bg_1_white.png', 'bg_2_red.png', 'bg_3_green.png', 'bg_4_orange.png', 'bg_5_violet.png', 'bg_6_blu.png'];
        let backgroundToastList = ['Sfondo %s', 'Sfondo %s', 'Sfondo %s', 'Sfondo %s', 'Sfondo %s', 'Sfondo %s', 'Sfondo %s'];
        const watchfaceId = hmApp.packageInfo().watchfaceId;


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            //start of ignored block
            console.log('SwitchBackground');
            function switchBackground() {
              backgroundIndex++;
              if (backgroundIndex >= backgroundList.length) backgroundIndex = 0;
              hmFS.SysProSetInt(`backgroundIndex_${watchfaceId}`, backgroundIndex);
              let toastText = backgroundToastList[backgroundIndex].replace('%s', `${backgroundIndex + 1}`);
              if (toastText.length > 0) hmUI.showToast({text: toastText});
              normal_background_bg_img.setProperty(hmUI.prop.SRC, backgroundList[backgroundIndex]);
            };
            //end of ignored block

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg_0_black.png',
              show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT,
            });

            normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: '0056.png',
              center_x: 240,
              center_y: 240,
              x: 24,
              y: 240,
              start_angle: 0,
              end_angle: 300,
              invalid_visible: false,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 226,
              y: 336,
              src: 'icon_steps.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 174,
              y: 370,
              font_array: ["0024b.png","0025b.png","0026b.png","0027b.png","0028b.png","0029b.png","0030b.png","0031b.png","0032b.png","0033b.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 218,
              y: 300,
              font_array: ["t0017.png","t0018.png","t0019.png","t0020.png","t0021.png","t0022.png","t0023.png","t0024.png","t0025.png","t0026.png"],
              padding: false,
              h_space: 0,
              unit_sc: 't0050.png',
              unit_tc: 't0050.png',
              unit_en: 't0050.png',
              negative_image: 't0048.png',
              invalid_image: 't0048.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 365,
              day_startY: 223,
              day_sc_array: ["0024b.png","0025b.png","0026b.png","0027b.png","0028b.png","0029b.png","0030b.png","0031b.png","0032b.png","0033b.png"],
              day_tc_array: ["0024b.png","0025b.png","0026b.png","0027b.png","0028b.png","0029b.png","0030b.png","0031b.png","0032b.png","0033b.png"],
              day_en_array: ["0024b.png","0025b.png","0026b.png","0027b.png","0028b.png","0029b.png","0030b.png","0031b.png","0032b.png","0033b.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 296,
              y: 221,
              week_en: ["6.png","7.png","8.png","9.png","10.png","11.png","12.png"],
              week_tc: ["6.png","7.png","8.png","9.png","10.png","11.png","12.png"],
              week_sc: ["6.png","7.png","8.png","9.png","10.png","11.png","12.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 146,
              y: 231,
              src: 'i0064.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 64,
              y: 223,
              font_array: ["0024b.png","0025b.png","0026b.png","0027b.png","0028b.png","0029b.png","0030b.png","0031b.png","0032b.png","0033b.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 170,
              y: 54,
              image_array: ["moon01.png","moon02.png","moon03.png","moon04.png","moon05.png","moon06.png","moon07.png","moon08.png","moon09.png","moon10.png","moon11.png","moon12.png","moon13.png","moon14.png","moon15.png","moon16.png","moon17.png","moon18.png","moon19.png","moon20.png","moon21.png","moon22.png","moon23.png","moon24.png","moon25.png","moon26.png","moon27.png","moon28.png","moon29.png","moon30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 227,
              y: 184,
              src: 'i026.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 292,
              y: 27,
              src: 'bt_off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 153,
              y: 28,
              src: 'i0094.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg_0_black.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: '0056.png',
              center_x: 240,
              center_y: 240,
              x: 24,
              y: 240,
              start_angle: 0,
              end_angle: 300,
              invalid_visible: false,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 226,
              y: 336,
              src: 'icon_steps.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 174,
              y: 370,
              font_array: ["0024b.png","0025b.png","0026b.png","0027b.png","0028b.png","0029b.png","0030b.png","0031b.png","0032b.png","0033b.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 218,
              y: 300,
              font_array: ["t0017.png","t0018.png","t0019.png","t0020.png","t0021.png","t0022.png","t0023.png","t0024.png","t0025.png","t0026.png"],
              padding: false,
              h_space: 0,
              unit_sc: 't0050.png',
              unit_tc: 't0050.png',
              unit_en: 't0050.png',
              negative_image: 't0048.png',
              invalid_image: 't0048.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 365,
              day_startY: 223,
              day_sc_array: ["0024b.png","0025b.png","0026b.png","0027b.png","0028b.png","0029b.png","0030b.png","0031b.png","0032b.png","0033b.png"],
              day_tc_array: ["0024b.png","0025b.png","0026b.png","0027b.png","0028b.png","0029b.png","0030b.png","0031b.png","0032b.png","0033b.png"],
              day_en_array: ["0024b.png","0025b.png","0026b.png","0027b.png","0028b.png","0029b.png","0030b.png","0031b.png","0032b.png","0033b.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 296,
              y: 221,
              week_en: ["6.png","7.png","8.png","9.png","10.png","11.png","12.png"],
              week_tc: ["6.png","7.png","8.png","9.png","10.png","11.png","12.png"],
              week_sc: ["6.png","7.png","8.png","9.png","10.png","11.png","12.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 146,
              y: 231,
              src: 'i0064.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 64,
              y: 223,
              font_array: ["0024b.png","0025b.png","0026b.png","0027b.png","0028b.png","0029b.png","0030b.png","0031b.png","0032b.png","0033b.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 170,
              y: 54,
              image_array: ["moon01.png","moon02.png","moon03.png","moon04.png","moon05.png","moon06.png","moon07.png","moon08.png","moon09.png","moon10.png","moon11.png","moon12.png","moon13.png","moon14.png","moon15.png","moon16.png","moon17.png","moon18.png","moon19.png","moon20.png","moon21.png","moon22.png","moon23.png","moon24.png","moon25.png","moon26.png","moon27.png","moon28.png","moon29.png","moon30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 227,
              y: 184,
              src: 'i026.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 292,
              y: 27,
              src: 'bt_off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 153,
              y: 28,
              src: 'i0094.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.ElementEditablePointers');

            const pointerEdit = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_POINTER, {
              edit_id: 1003,
              x: 0,
              y: 0,
              config: [
                {
                  id: 1,
                  second: {
                    centerX: 240,
                    centerY: 240,
                    posX: 7,
                    posY: 234,
                    path: 'Sec.png',
                  },
                  hour: {
                    centerX: 240,
                    centerY: 240,
                    posX: 13,
                    posY: 238,
                    path: 'pt.hor1.png',
                  },
                  minute: {
                    centerX: 240,
                    centerY: 240,
                    posX: 14,
                    posY: 239,
                    path: 'pt.min1.png',
                  },
                  preview: 'pointer_edit_1_preview.png',
                },
                {
                  id: 2,
                  second: {
                    centerX: 240,
                    centerY: 240,
                    posX: 7,
                    posY: 234,
                    path: 'Sec.png',
                  },
                  hour: {
                    centerX: 240,
                    centerY: 240,
                    posX: 18,
                    posY: 153,
                    path: '0034.png',
                  },
                  minute: {
                    centerX: 240,
                    centerY: 240,
                    posX: 22,
                    posY: 236,
                    path: '0035.png',
                  },
                  preview: 'pointer_edit_2_preview.png',
                },
                {
                  id: 3,
                  second: {
                    centerX: 240,
                    centerY: 240,
                    posX: 7,
                    posY: 234,
                    path: 'Sec.png',
                  },
                  hour: {
                    centerX: 240,
                    centerY: 240,
                    posX: 11,
                    posY: 158,
                    path: '0023.png',
                  },
                  minute: {
                    centerX: 240,
                    centerY: 240,
                    posX: 11,
                    posY: 234,
                    path: '0024.png',
                  },
                  preview: 'pointer_edit_3_preview.png',
                },
                {
                  id: 4,
                  second: {
                    centerX: 240,
                    centerY: 240,
                    posX: 7,
                    posY: 234,
                    path: 'Sec.png',
                  },
                  hour: {
                    centerX: 240,
                    centerY: 240,
                    posX: 23,
                    posY: 158,
                    path: 'h_5.png',
                  },
                  minute: {
                    centerX: 240,
                    centerY: 240,
                    posX: 37,
                    posY: 258,
                    path: 'm_5.png',
                  },
                  preview: 'pointer_edit_4_preview.png',
                },
              ],
              count: 4,
              default_id: 1,
              fg: '.png',
              tips_x: 0,
              tips_y: 0,
              tips_bg: '.png',
            });
            const screenTypeForETP = hmSetting.getScreenType();
            const aodModel = screenTypeForETP == hmSetting.screen_type.AOD;
            const pointerProp = pointerEdit.getProperty(hmUI.prop.CURRENT_CONFIG, !aodModel);
            editableTimePointers = hmUI.createWidget(hmUI.widget.TIME_POINTER, pointerProp);
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 190,
              y: 342,
              w: 100,
              h: 85,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 65,
              y: 190,
              w: 100,
              h: 100,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 0,
              y: 190,
              w: 65,
              h: 100,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 190,
              y: 70,
              w: 100,
              h: 100,
              type: hmUI.data_type.MOON_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 190,
              y: 272,
              w: 100,
              h: 70,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 360,
              y: 280,
              w: 100,
              h: 120,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 360,
              y: 80,
              w: 100,
              h: 120,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altitude_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 190,
              y: 0,
              w: 100,
              h: 70,
              type: hmUI.data_type.ALTITUDE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.SwitchBackground');
            // Button_Switch_BG = hmUI.createWidget(hmUI.widget.SwitchBackground, {
              // x: 200,
              // y: 204,
              // w: 80,
              // h: 70,
              // text: '',
              // color: 0xFFFF8C00,
              // text_size: 25,
              // press_src: '2141.png',
              // normal_src: '2141.png',
              // bg_list: bg_0_black|bg_1_white|bg_2_red|bg_3_green|bg_4_orange|bg_5_violet|bg_6_blu,
              // toast_list: Sfondo %s|Sfondo %s|Sfondo %s|Sfondo %s|Sfondo %s|Sfondo %s|Sfondo %s,
              // use_crown: False,
              // use_in_AOD: False,
              // vibro: False,
            // });

            Button_Switch_BG = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 200,
              y: 204,
              w: 80,
              h: 70,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '2141.png',
              normal_src: '2141.png',
              click_func: (button_widget) => {
                switchBackground();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            let screenType = hmSetting.getScreenType();
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');

                //SwitchBackground
                if (hmFS.SysProGetInt(`backgroundIndex_${watchfaceId}`) === undefined) {
                  backgroundIndex = 0;
                  hmFS.SysProSetInt(`backgroundIndex_${watchfaceId}`, backgroundIndex);
                } else {
                  backgroundIndex = hmFS.SysProGetInt(`backgroundIndex_${watchfaceId}`);
                };
                if (screenType == hmSetting.screen_type.WATCHFACE && normal_background_bg_img) normal_background_bg_img.setProperty(hmUI.prop.SRC, backgroundList[backgroundIndex]);
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
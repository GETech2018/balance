﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_lock_img = ''
        let normal_system_dnd_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_distance_text_text_img = ''
        let normal_distance_text_separator_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_text_separator_img = ''
        let normal_spo2_text_text_img = ''
        let normal_spo2_text_separator_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_text_separator_img = ''
        let normal_wind_direction_image_progress_img_level = ''
        let normal_wind_text_text_img = ''
        let normal_wind_text_separator_img = ''
        let normal_calorie_current_text_img = ''
        let normal_calorie_current_separator_img = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_temperature_current_separator_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_year = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg_img = ''
        let idle_system_lock_img = ''
        let idle_system_dnd_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_distance_text_text_img = ''
        let idle_distance_text_separator_img = ''
        let idle_battery_text_text_img = ''
        let idle_battery_text_separator_img = ''
        let idle_spo2_text_text_img = ''
        let idle_spo2_text_separator_img = ''
        let idle_heart_rate_text_text_img = ''
        let idle_heart_rate_text_separator_img = ''
        let idle_wind_direction_image_progress_img_level = ''
        let idle_wind_text_text_img = ''
        let idle_wind_text_separator_img = ''
        let idle_calorie_current_text_img = ''
        let idle_calorie_current_separator_img = ''
        let idle_step_current_text_img = ''
        let idle_step_current_separator_img = ''
        let idle_moon_image_progress_img_level = ''
        let idle_temperature_current_text_img = ''
        let idle_temperature_current_separator_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_year = ''
        let idle_date_img_date_month = ''
        let idle_date_img_date_day = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'face5ch.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 277,
              y: 429,
              src: 'STATlock.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 174,
              y: 429,
              src: 'STATdnd.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 208,
              y: 430,
              src: 'STATblue.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 243,
              y: 430,
              src: 'STATalarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 30,
              y: 288,
              font_array: ["CD0.png","CD1a.png","CD2.png","CD3.png","CD4.png","CD5.png","CD6.png","CD7a.png","CD8.png","CD9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'DistKM.png',
              unit_tc: 'DistKM.png',
              unit_en: 'DistKM.png',
              imperial_unit_sc: 'DistMI.png',
              imperial_unit_tc: 'DistMI.png',
              imperial_unit_en: 'DistMI.png',
              dot_image: 'CDperiod.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 208,
              y: 288,
              src: 'CDlocation.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 89,
              y: 388,
              font_array: ["CD0.png","CD1a.png","CD2.png","CD3.png","CD4.png","CD5.png","CD6.png","CD7a.png","CD8.png","CD9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'CDper.png',
              unit_tc: 'CDper.png',
              unit_en: 'CDper.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 208,
              y: 388,
              src: 'CDbattery.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 272,
              y: 338,
              font_array: ["CD0.png","CD1a.png","CD2.png","CD3.png","CD4.png","CD5.png","CD6.png","CD7a.png","CD8.png","CD9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'CDper.png',
              unit_tc: 'CDper.png',
              unit_en: 'CDper.png',
              invalid_image: 'CDmin.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 242,
              y: 338,
              src: 'CDoxy.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 272,
              y: 388,
              font_array: ["CD0.png","CD1a.png","CD2.png","CD3.png","CD4.png","CD5.png","CD6.png","CD7a.png","CD8.png","CD9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 242,
              y: 388,
              src: 'CDheart.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_direction_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 392,
              y: 95,
              image_array: ["WDC0.png","WDC1.png","WDC2.png","WDC3.png","WDC4.png","WDC5.png","WDC6.png","WDC7.png"],
              image_length: 8,
              type: hmUI.data_type.WIND_DIRECTION,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 272,
              y: 95,
              font_array: ["CD0.png","CD1a.png","CD2.png","CD3.png","CD4.png","CD5.png","CD6.png","CD7a.png","CD8.png","CD9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'DistKM.png',
              unit_tc: 'DistKM.png',
              unit_en: 'DistKM.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WIND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 242,
              y: 95,
              src: 'CDwind.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 89,
              y: 338,
              font_array: ["CD0.png","CD1a.png","CD2.png","CD3.png","CD4.png","CD5.png","CD6.png","CD7a.png","CD8.png","CD9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 208,
              y: 338,
              src: 'CDcal.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 272,
              y: 288,
              font_array: ["CD0.png","CD1a.png","CD2.png","CD3.png","CD4.png","CD5.png","CD6.png","CD7a.png","CD8.png","CD9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 242,
              y: 288,
              src: 'CDwalk.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 164,
              y: 20,
              image_array: ["MPH00.png","MPH01.png","MPH02.png","MPH03.png","MPH04.png","MPH05.png","MPH06.png","MPH07.png","MPH08.png","MPH09.png","MPH10.png","MPH11.png","MPH12.png","MPH13.png","MPH14.png","MPH15.png","MPH16.png","MPH17.png","MPH18.png","MPH19.png","MPH20.png","MPH21.png","MPH22.png","MPH23.png","MPH24.png","MPH25.png","MPH26.png","MPH27.png"],
              image_length: 28,
              shortcut: true,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 88,
              y: 95,
              font_array: ["CD0.png","CD1a.png","CD2.png","CD3.png","CD4.png","CD5.png","CD6.png","CD7a.png","CD8.png","CD9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'CHC.png',
              unit_tc: 'CHC.png',
              unit_en: 'CHC.png',
              negative_image: 'CDmin.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 205,
              y: 95,
              src: 'CDtemperature.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 261,
              y: 11,
              image_array: ["xw0069.png","xw0070.png","xw0071.png","xw0072.png","xw0073.png","xw0074.png","xw0075.png","xw0076.png","xw0077.png","xw0078.png","xw0079.png","xw0080.png","xw0081.png","xw0082.png","xw0083.png","xw0084.png","xw0085.png","xw0086.png","xw0087.png","xw0088.png","xw0089.png","xw0090.png","xw0091.png","xw0092.png","xw0093.png","xw0094.png","xw0095.png","xw0096.png","xw0097.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 300,
              y: 150,
              week_en: ["WKD-DE-1-MON.png","WKD-DE-2-DIE.png","WKD-DE-3-MIT.png","WKD-DE-4-DON.png","WKD-DE-5-FRE.png","WKD-DE-6-SAM.png","WKD-DE-7-SON.png"],
              week_tc: ["WKD-DE-1-MON.png","WKD-DE-2-DIE.png","WKD-DE-3-MIT.png","WKD-DE-4-DON.png","WKD-DE-5-FRE.png","WKD-DE-6-SAM.png","WKD-DE-7-SON.png"],
              week_sc: ["WKD-DE-1-MON.png","WKD-DE-2-DIE.png","WKD-DE-3-MIT.png","WKD-DE-4-DON.png","WKD-DE-5-FRE.png","WKD-DE-6-SAM.png","WKD-DE-7-SON.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 30,
              year_startY: 150,
              year_sc_array: ["CD0.png","CD1a.png","CD2.png","CD3.png","CD4.png","CD5.png","CD6.png","CD7a.png","CD8.png","CD9.png"],
              year_tc_array: ["CD0.png","CD1a.png","CD2.png","CD3.png","CD4.png","CD5.png","CD6.png","CD7a.png","CD8.png","CD9.png"],
              year_en_array: ["CD0.png","CD1a.png","CD2.png","CD3.png","CD4.png","CD5.png","CD6.png","CD7a.png","CD8.png","CD9.png"],
              year_zero: 1,
              year_space: 0,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 150,
              month_startY: 150,
              month_sc_array: ["CD0.png","CD1a.png","CD2.png","CD3.png","CD4.png","CD5.png","CD6.png","CD7a.png","CD8.png","CD9.png"],
              month_tc_array: ["CD0.png","CD1a.png","CD2.png","CD3.png","CD4.png","CD5.png","CD6.png","CD7a.png","CD8.png","CD9.png"],
              month_en_array: ["CD0.png","CD1a.png","CD2.png","CD3.png","CD4.png","CD5.png","CD6.png","CD7a.png","CD8.png","CD9.png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 210,
              day_startY: 150,
              day_sc_array: ["CD0.png","CD1a.png","CD2.png","CD3.png","CD4.png","CD5.png","CD6.png","CD7a.png","CD8.png","CD9.png"],
              day_tc_array: ["CD0.png","CD1a.png","CD2.png","CD3.png","CD4.png","CD5.png","CD6.png","CD7a.png","CD8.png","CD9.png"],
              day_en_array: ["CD0.png","CD1a.png","CD2.png","CD3.png","CD4.png","CD5.png","CD6.png","CD7a.png","CD8.png","CD9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 430,
              am_y: 193,
              am_sc_path: 'CDam.png',
              am_en_path: 'CDam.png',
              pm_x: 430,
              pm_y: 193,
              pm_sc_path: 'CDpm.png',
              pm_en_path: 'CDpm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 51,
              hour_startY: 190,
              hour_array: ["CZZ0.png","CZZ1a.png","CZZ2.png","CZZ3.png","CZZ4.png","CZZ5.png","CZZ6.png","CZZ7a.png","CZZ8.png","CZZ9.png"],
              hour_zero: 0,
              hour_space: 0,
              hour_angle: 0,
              hour_unit_sc: 'CZcol.png',
              hour_unit_tc: 'CZcol.png',
              hour_unit_en: 'CZcol.png',
              hour_align: hmUI.align.RIGHT,

              minute_startX: 0,
              minute_startY: 0,
              minute_array: ["CZZ0.png","CZZ1a.png","CZZ2.png","CZZ3.png","CZZ4.png","CZZ5.png","CZZ6.png","CZZ7a.png","CZZ8.png","CZZ9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 1,
              minute_unit_sc: 'CZcol.png',
              minute_unit_tc: 'CZcol.png',
              minute_unit_en: 'CZcol.png',
              minute_align: hmUI.align.LEFT,

              second_startX: 0,
              second_startY: 0,
              second_array: ["CZZ0.png","CZZ1a.png","CZZ2.png","CZZ3.png","CZZ4.png","CZZ5.png","CZZ6.png","CZZ7a.png","CZZ8.png","CZZ9.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 1,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'face5aod.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 277,
              y: 429,
              src: 'STATlock.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 174,
              y: 429,
              src: 'STATdnd.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 208,
              y: 430,
              src: 'STATblue.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 243,
              y: 430,
              src: 'STATalarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 30,
              y: 288,
              font_array: ["CD0.png","CD1a.png","CD2.png","CD3.png","CD4.png","CD5.png","CD6.png","CD7a.png","CD8.png","CD9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'DistKM.png',
              unit_tc: 'DistKM.png',
              unit_en: 'DistKM.png',
              imperial_unit_sc: 'DistMI.png',
              imperial_unit_tc: 'DistMI.png',
              imperial_unit_en: 'DistMI.png',
              dot_image: 'CDperiod.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_distance_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 208,
              y: 288,
              src: 'CDlocation.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 89,
              y: 388,
              font_array: ["CD0.png","CD1a.png","CD2.png","CD3.png","CD4.png","CD5.png","CD6.png","CD7a.png","CD8.png","CD9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'CDper.png',
              unit_tc: 'CDper.png',
              unit_en: 'CDper.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 208,
              y: 388,
              src: 'CDbattery.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_spo2_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 272,
              y: 338,
              font_array: ["CD0.png","CD1a.png","CD2.png","CD3.png","CD4.png","CD5.png","CD6.png","CD7a.png","CD8.png","CD9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'CDper.png',
              unit_tc: 'CDper.png',
              unit_en: 'CDper.png',
              invalid_image: 'CDmin.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_spo2_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 242,
              y: 338,
              src: 'CDoxy.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 272,
              y: 388,
              font_array: ["CD0.png","CD1a.png","CD2.png","CD3.png","CD4.png","CD5.png","CD6.png","CD7a.png","CD8.png","CD9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 242,
              y: 388,
              src: 'CDheart.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_wind_direction_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 392,
              y: 95,
              image_array: ["WDC0.png","WDC1.png","WDC2.png","WDC3.png","WDC4.png","WDC5.png","WDC6.png","WDC7.png"],
              image_length: 8,
              type: hmUI.data_type.WIND_DIRECTION,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_wind_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 272,
              y: 95,
              font_array: ["CD0.png","CD1a.png","CD2.png","CD3.png","CD4.png","CD5.png","CD6.png","CD7a.png","CD8.png","CD9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'DistKM.png',
              unit_tc: 'DistKM.png',
              unit_en: 'DistKM.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WIND,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_wind_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 242,
              y: 95,
              src: 'CDwind.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 89,
              y: 338,
              font_array: ["CD0.png","CD1a.png","CD2.png","CD3.png","CD4.png","CD5.png","CD6.png","CD7a.png","CD8.png","CD9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 208,
              y: 338,
              src: 'CDcal.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 272,
              y: 288,
              font_array: ["CD0.png","CD1a.png","CD2.png","CD3.png","CD4.png","CD5.png","CD6.png","CD7a.png","CD8.png","CD9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 242,
              y: 288,
              src: 'CDwalk.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 164,
              y: 20,
              image_array: ["MPH00.png","MPH01.png","MPH02.png","MPH03.png","MPH04.png","MPH05.png","MPH06.png","MPH07.png","MPH08.png","MPH09.png","MPH10.png","MPH11.png","MPH12.png","MPH13.png","MPH14.png","MPH15.png","MPH16.png","MPH17.png","MPH18.png","MPH19.png","MPH20.png","MPH21.png","MPH22.png","MPH23.png","MPH24.png","MPH25.png","MPH26.png","MPH27.png"],
              image_length: 28,
              shortcut: true,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 88,
              y: 95,
              font_array: ["CD0.png","CD1a.png","CD2.png","CD3.png","CD4.png","CD5.png","CD6.png","CD7a.png","CD8.png","CD9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'CHC.png',
              unit_tc: 'CHC.png',
              unit_en: 'CHC.png',
              negative_image: 'CDmin.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 205,
              y: 95,
              src: 'CDtemperature.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 261,
              y: 11,
              image_array: ["xw0069.png","xw0070.png","xw0071.png","xw0072.png","xw0073.png","xw0074.png","xw0075.png","xw0076.png","xw0077.png","xw0078.png","xw0079.png","xw0080.png","xw0081.png","xw0082.png","xw0083.png","xw0084.png","xw0085.png","xw0086.png","xw0087.png","xw0088.png","xw0089.png","xw0090.png","xw0091.png","xw0092.png","xw0093.png","xw0094.png","xw0095.png","xw0096.png","xw0097.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 300,
              y: 150,
              week_en: ["WKD-DE-1-MON.png","WKD-DE-2-DIE.png","WKD-DE-3-MIT.png","WKD-DE-4-DON.png","WKD-DE-5-FRE.png","WKD-DE-6-SAM.png","WKD-DE-7-SON.png"],
              week_tc: ["WKD-DE-1-MON.png","WKD-DE-2-DIE.png","WKD-DE-3-MIT.png","WKD-DE-4-DON.png","WKD-DE-5-FRE.png","WKD-DE-6-SAM.png","WKD-DE-7-SON.png"],
              week_sc: ["WKD-DE-1-MON.png","WKD-DE-2-DIE.png","WKD-DE-3-MIT.png","WKD-DE-4-DON.png","WKD-DE-5-FRE.png","WKD-DE-6-SAM.png","WKD-DE-7-SON.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 30,
              year_startY: 150,
              year_sc_array: ["CD0.png","CD1a.png","CD2.png","CD3.png","CD4.png","CD5.png","CD6.png","CD7a.png","CD8.png","CD9.png"],
              year_tc_array: ["CD0.png","CD1a.png","CD2.png","CD3.png","CD4.png","CD5.png","CD6.png","CD7a.png","CD8.png","CD9.png"],
              year_en_array: ["CD0.png","CD1a.png","CD2.png","CD3.png","CD4.png","CD5.png","CD6.png","CD7a.png","CD8.png","CD9.png"],
              year_zero: 1,
              year_space: 0,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 150,
              month_startY: 150,
              month_sc_array: ["CD0.png","CD1a.png","CD2.png","CD3.png","CD4.png","CD5.png","CD6.png","CD7a.png","CD8.png","CD9.png"],
              month_tc_array: ["CD0.png","CD1a.png","CD2.png","CD3.png","CD4.png","CD5.png","CD6.png","CD7a.png","CD8.png","CD9.png"],
              month_en_array: ["CD0.png","CD1a.png","CD2.png","CD3.png","CD4.png","CD5.png","CD6.png","CD7a.png","CD8.png","CD9.png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 210,
              day_startY: 150,
              day_sc_array: ["CD0.png","CD1a.png","CD2.png","CD3.png","CD4.png","CD5.png","CD6.png","CD7a.png","CD8.png","CD9.png"],
              day_tc_array: ["CD0.png","CD1a.png","CD2.png","CD3.png","CD4.png","CD5.png","CD6.png","CD7a.png","CD8.png","CD9.png"],
              day_en_array: ["CD0.png","CD1a.png","CD2.png","CD3.png","CD4.png","CD5.png","CD6.png","CD7a.png","CD8.png","CD9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 430,
              am_y: 193,
              am_sc_path: 'CDam.png',
              am_en_path: 'CDam.png',
              pm_x: 430,
              pm_y: 193,
              pm_sc_path: 'CDpm.png',
              pm_en_path: 'CDpm.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 51,
              hour_startY: 190,
              hour_array: ["CZZ0.png","CZZ1a.png","CZZ2.png","CZZ3.png","CZZ4.png","CZZ5.png","CZZ6.png","CZZ7a.png","CZZ8.png","CZZ9.png"],
              hour_zero: 0,
              hour_space: 0,
              hour_angle: 0,
              hour_unit_sc: 'CZcol.png',
              hour_unit_tc: 'CZcol.png',
              hour_unit_en: 'CZcol.png',
              hour_align: hmUI.align.RIGHT,

              minute_startX: 0,
              minute_startY: 0,
              minute_array: ["CZZ0.png","CZZ1a.png","CZZ2.png","CZZ3.png","CZZ4.png","CZZ5.png","CZZ6.png","CZZ7a.png","CZZ8.png","CZZ9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 1,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 0,
              y: 140,
              w: 480,
              h: 130,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 0,
              y: 0,
              w: 480,
              h: 140,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 240,
              y: 331,
              w: 240,
              h: 70,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 240,
              y: 401,
              w: 240,
              h: 80,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 0,
              y: 268,
              w: 480,
              h: 65,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}
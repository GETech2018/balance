﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_image_img = ''
        let normal_system_disconnect_img = ''
        let normal_sun_icon_img = ''
        let normal_sun_high_text_img = ''
        let normal_sun_low_text_img = ''
        let normal_battery_text_text_img = ''
        let normal_altimeter_icon_img = ''
        let normal_altitude_target_text_img = ''
        let normal_step_icon_img = ''
        let normal_step_current_text_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_digital_clock_img_time = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg_img = ''
        let idle_system_disconnect_img = ''
        let idle_sun_icon_img = ''
        let idle_sun_high_text_img = ''
        let idle_sun_low_text_img = ''
        let idle_battery_text_text_img = ''
        let idle_altimeter_icon_img = ''
        let idle_altitude_target_text_img = ''
        let idle_step_icon_img = ''
        let idle_step_current_text_img = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_day = ''
        let idle_digital_clock_img_time = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let Button_7 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'BCK-00.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'image.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 0,
              y: 0,
              src: 'ico-bluet.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 249,
              y: 67,
              src: 'ico-albatra.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 290,
              y: 73,
              font_array: ["di-0.png","di-1.png","di-2.png","di-3.png","di-4.png","di-5.png","di-6.png","di-7.png","di-8.png","di-9.png"],
              padding: false,
              h_space: 3,
              dot_image: 'di-duepunti.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 290,
              y: 128,
              font_array: ["di-0.png","di-1.png","di-2.png","di-3.png","di-4.png","di-5.png","di-6.png","di-7.png","di-8.png","di-9.png"],
              padding: false,
              h_space: 3,
              dot_image: 'di-duepunti.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 211,
              y: 31,
              font_array: ["di-0.png","di-1.png","di-2.png","di-3.png","di-4.png","di-5.png","di-6.png","di-7.png","di-8.png","di-9.png"],
              padding: false,
              h_space: 3,
              unit_sc: 'di-PERCENT.png',
              unit_tc: 'di-PERCENT.png',
              unit_en: 'di-PERCENT.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 130,
              y: 385,
              src: 'ico-altitude.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altitude_target_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 174,
              y: 381,
              font_array: ["dig-00.png","dig-01.png","dig-02.png","dig-03.png","dig-04.png","dig-05.png","dig-06.png","dig-07.png","dig-08.png","dig-09.png"],
              padding: false,
              h_space: 6,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.ALTITUDE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 130,
              y: 321,
              src: 'ico-step.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 174,
              y: 317,
              font_array: ["dig-00.png","dig-01.png","dig-02.png","dig-03.png","dig-04.png","dig-05.png","dig-06.png","dig-07.png","dig-08.png","dig-09.png"],
              padding: true,
              h_space: 6,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 177,
              month_startY: 124,
              month_sc_array: ["m-01.png","m-02.png","m-03.png","m-04.png","m-05.png","m-06.png","m-07.png","m-08.png","m-09.png","m-10.png","m-11.png","m-12.png"],
              month_tc_array: ["m-01.png","m-02.png","m-03.png","m-04.png","m-05.png","m-06.png","m-07.png","m-08.png","m-09.png","m-10.png","m-11.png","m-12.png"],
              month_en_array: ["m-01.png","m-02.png","m-03.png","m-04.png","m-05.png","m-06.png","m-07.png","m-08.png","m-09.png","m-10.png","m-11.png","m-12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 177,
              y: 89,
              week_en: ["d-1.png","d-2.png","d-3.png","d-4.png","d-5.png","d-6.png","d-7.png"],
              week_tc: ["d-1.png","d-2.png","d-3.png","d-4.png","d-5.png","d-6.png","d-7.png"],
              week_sc: ["d-1.png","d-2.png","d-3.png","d-4.png","d-5.png","d-6.png","d-7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 102,
              day_startY: 91,
              day_sc_array: ["dig-00.png","dig-01.png","dig-02.png","dig-03.png","dig-04.png","dig-05.png","dig-06.png","dig-07.png","dig-08.png","dig-09.png"],
              day_tc_array: ["dig-00.png","dig-01.png","dig-02.png","dig-03.png","dig-04.png","dig-05.png","dig-06.png","dig-07.png","dig-08.png","dig-09.png"],
              day_en_array: ["dig-00.png","dig-01.png","dig-02.png","dig-03.png","dig-04.png","dig-05.png","dig-06.png","dig-07.png","dig-08.png","dig-09.png"],
              day_zero: 1,
              day_space: 6,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 40,
              hour_startY: 180,
              hour_array: ["digit-00.png","digit-01.png","digit-02.png","digit-03.png","digit-04.png","digit-05.png","digit-06.png","digit-07.png","digit-08.png","digit-09.png"],
              hour_zero: 1,
              hour_space: 10,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 181,
              minute_startY: 180,
              minute_array: ["digit-00.png","digit-01.png","digit-02.png","digit-03.png","digit-04.png","digit-05.png","digit-06.png","digit-07.png","digit-08.png","digit-09.png"],
              minute_zero: 1,
              minute_space: 10,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 349,
              second_startY: 211,
              second_array: ["dig-00.png","dig-01.png","dig-02.png","dig-03.png","dig-04.png","dig-05.png","dig-06.png","dig-07.png","dig-08.png","dig-09.png"],
              second_zero: 1,
              second_space: 6,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'sec-big.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 15,
              second_posY: 240,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'BCK-00.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 0,
              y: 0,
              src: 'ico-bluet.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_sun_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 249,
              y: 67,
              src: 'ico-albatra.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 290,
              y: 73,
              font_array: ["di-0.png","di-1.png","di-2.png","di-3.png","di-4.png","di-5.png","di-6.png","di-7.png","di-8.png","di-9.png"],
              padding: false,
              h_space: 3,
              dot_image: 'di-duepunti.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 290,
              y: 128,
              font_array: ["di-0.png","di-1.png","di-2.png","di-3.png","di-4.png","di-5.png","di-6.png","di-7.png","di-8.png","di-9.png"],
              padding: false,
              h_space: 3,
              dot_image: 'di-duepunti.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 211,
              y: 31,
              font_array: ["di-0.png","di-1.png","di-2.png","di-3.png","di-4.png","di-5.png","di-6.png","di-7.png","di-8.png","di-9.png"],
              padding: false,
              h_space: 3,
              unit_sc: 'di-PERCENT.png',
              unit_tc: 'di-PERCENT.png',
              unit_en: 'di-PERCENT.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_altimeter_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 130,
              y: 385,
              src: 'ico-altitude.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_altitude_target_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 174,
              y: 381,
              font_array: ["dig-00.png","dig-01.png","dig-02.png","dig-03.png","dig-04.png","dig-05.png","dig-06.png","dig-07.png","dig-08.png","dig-09.png"],
              padding: false,
              h_space: 6,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.ALTITUDE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 130,
              y: 321,
              src: 'ico-step.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 174,
              y: 317,
              font_array: ["dig-00.png","dig-01.png","dig-02.png","dig-03.png","dig-04.png","dig-05.png","dig-06.png","dig-07.png","dig-08.png","dig-09.png"],
              padding: true,
              h_space: 6,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 177,
              month_startY: 124,
              month_sc_array: ["m-01.png","m-02.png","m-03.png","m-04.png","m-05.png","m-06.png","m-07.png","m-08.png","m-09.png","m-10.png","m-11.png","m-12.png"],
              month_tc_array: ["m-01.png","m-02.png","m-03.png","m-04.png","m-05.png","m-06.png","m-07.png","m-08.png","m-09.png","m-10.png","m-11.png","m-12.png"],
              month_en_array: ["m-01.png","m-02.png","m-03.png","m-04.png","m-05.png","m-06.png","m-07.png","m-08.png","m-09.png","m-10.png","m-11.png","m-12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 177,
              y: 89,
              week_en: ["d-1.png","d-2.png","d-3.png","d-4.png","d-5.png","d-6.png","d-7.png"],
              week_tc: ["d-1.png","d-2.png","d-3.png","d-4.png","d-5.png","d-6.png","d-7.png"],
              week_sc: ["d-1.png","d-2.png","d-3.png","d-4.png","d-5.png","d-6.png","d-7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 102,
              day_startY: 91,
              day_sc_array: ["dig-00.png","dig-01.png","dig-02.png","dig-03.png","dig-04.png","dig-05.png","dig-06.png","dig-07.png","dig-08.png","dig-09.png"],
              day_tc_array: ["dig-00.png","dig-01.png","dig-02.png","dig-03.png","dig-04.png","dig-05.png","dig-06.png","dig-07.png","dig-08.png","dig-09.png"],
              day_en_array: ["dig-00.png","dig-01.png","dig-02.png","dig-03.png","dig-04.png","dig-05.png","dig-06.png","dig-07.png","dig-08.png","dig-09.png"],
              day_zero: 1,
              day_space: 6,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 40,
              hour_startY: 179,
              hour_array: ["digit-00.png","digit-01.png","digit-02.png","digit-03.png","digit-04.png","digit-05.png","digit-06.png","digit-07.png","digit-08.png","digit-09.png"],
              hour_zero: 1,
              hour_space: 10,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 181,
              minute_startY: 179,
              minute_array: ["digit-00.png","digit-01.png","digit-02.png","digit-03.png","digit-04.png","digit-05.png","digit-06.png","digit-07.png","digit-08.png","digit-09.png"],
              minute_zero: 1,
              minute_space: 10,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 200,
              y: 200,
              w: 80,
              h: 80,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'null.png',
              normal_src: 'null.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'AppListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 102,
              y: 80,
              w: 80,
              h: 80,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'null.png',
              normal_src: 'null.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 200,
              y: 340,
              w: 80,
              h: 80,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'null.png',
              normal_src: 'null.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'SportListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 34,
              y: 126,
              w: 60,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'null.png',
              normal_src: 'null.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'CompassScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 384,
              y: 126,
              w: 60,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'null.png',
              normal_src: 'null.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'FlashLightScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 385,
              y: 292,
              w: 60,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'null.png',
              normal_src: 'null.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'WeatherScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_7 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 34,
              y: 292,
              w: 60,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'null.png',
              normal_src: 'null.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'StopWatchScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}